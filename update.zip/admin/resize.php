<?php

session_start();
session_write_close();

if (isset($_SESSION['hash'])) {
	set_time_limit(2);
	ini_set('default_socket_timeout', 2);
	define('XUI_HOME', '/home/xui/');
	define('WWW_PATH', XUI_HOME . 'www/');
	define('IMAGES_PATH', WWW_PATH . 'images/');
	define('TMP_PATH', XUI_HOME . 'tmp/');
	define('CACHE_TMP_PATH', TMP_PATH . 'cache/');
	$a8bb73cba48fb7f6 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'servers'));
	$C700a2b357e5ed65 = $_GET['url'];
	$D8e1dc68b81d5702 = 0;
	$ea69abb4ad0055aa = 0;

	if (!isset($_GET['maxw'])) {
	} else {
		$D8e1dc68b81d5702 = intval($_GET['maxw']);
	}

	if (!isset($_GET['maxh'])) {
	} else {
		$ea69abb4ad0055aa = intval($_GET['maxh']);
	}

	if (!isset($_GET['max'])) {
	} else {
		$D8e1dc68b81d5702 = intval($_GET['max']);
		$ea69abb4ad0055aa = intval($_GET['max']);
	}

	if (substr($C700a2b357e5ed65, 0, 2) != 's:') {
	} else {
		$B211d7401e6242f3 = explode(':', $C700a2b357e5ed65, 3);
		$d58b4f8653a391d8 = intval($B211d7401e6242f3[1]);
		$Caecf2bcd39a1efe = (empty($a8bb73cba48fb7f6[$d58b4f8653a391d8]['domain_name']) ? $a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_ip'] : explode(',', $a8bb73cba48fb7f6[$d58b4f8653a391d8]['domain_name'])[0]);
		$f4116b9928c8b494 = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_protocol'] . '://' . $Caecf2bcd39a1efe . ':' . $a8bb73cba48fb7f6[$d58b4f8653a391d8]['request_port'] . '/';
		$C700a2b357e5ed65 = $f4116b9928c8b494 . 'images/' . basename($C700a2b357e5ed65);
	}

	if (!($C700a2b357e5ed65 && 0 < $D8e1dc68b81d5702 && 0 < $ea69abb4ad0055aa)) {
	} else {
		$cff016622381f6ab = IMAGES_PATH . 'admin/' . md5($C700a2b357e5ed65) . '_' . $D8e1dc68b81d5702 . '_' . $ea69abb4ad0055aa . '.png';

		if (file_exists($cff016622381f6ab) && filesize($cff016622381f6ab) != 0) {
		} else {
			if (d3b3a460213c50ee($C700a2b357e5ed65)) {
				$a37e8780318ad4bb = $C700a2b357e5ed65;
			} else {
				$a37e8780318ad4bb = IMAGES_PATH . basename($C700a2b357e5ed65);
			}

			$ec80f61435f9402e = getimagesize($a37e8780318ad4bb);
			$D4f101ff179f7d78 = acd6af5761f21e7c($ec80f61435f9402e[0], $ec80f61435f9402e[1], $D8e1dc68b81d5702, $ea69abb4ad0055aa);

			if (!($D4f101ff179f7d78['width'] && $D4f101ff179f7d78['height'])) {
			} else {
				if ($ec80f61435f9402e['mime'] == 'image/png') {
					$A639a7baefc720ee = imagecreatefrompng($a37e8780318ad4bb);
				} else {
					if ($ec80f61435f9402e['mime'] == 'image/jpeg') {
						$A639a7baefc720ee = imagecreatefromjpeg($a37e8780318ad4bb);
					} else {
						$A639a7baefc720ee = null;
					}
				}

				if (!$A639a7baefc720ee) {
				} else {
					$Ade25d0ea49cbef5 = imagecreatetruecolor($D4f101ff179f7d78['width'], $D4f101ff179f7d78['height']);
					imagealphablending($Ade25d0ea49cbef5, false);
					imagesavealpha($Ade25d0ea49cbef5, true);
					imagecopyresampled($Ade25d0ea49cbef5, $A639a7baefc720ee, 0, 0, 0, 0, $D4f101ff179f7d78['width'], $D4f101ff179f7d78['height'], $ec80f61435f9402e[0], $ec80f61435f9402e[1]);
					imagepng($Ade25d0ea49cbef5, $cff016622381f6ab);
				}
			}
		}

		if (!file_exists($cff016622381f6ab)) {
		} else {
			header('Content-Type: image/png');
			echo file_get_contents($cff016622381f6ab);

			exit();
		}
	}

	header('Content-Type: image/png');
	$A639a7baefc720ee = imagecreatetruecolor(1, 1);
	imagesavealpha($A639a7baefc720ee, true);
	imagefill($A639a7baefc720ee, 0, 0, imagecolorallocatealpha($A639a7baefc720ee, 0, 0, 0, 127));
	imagepng($A639a7baefc720ee);
} else {
	exit();
}

function Acd6aF5761F21e7c($d8a4881c582e2a3b, $a6456d2c57df0603, $a0823d4a2de30431, $b61c83ca0fef311e)
{
	if ($a0823d4a2de30431 != 0) {
	} else {
		$a0823d4a2de30431 = $d8a4881c582e2a3b;
	}

	if ($b61c83ca0fef311e != 0) {
	} else {
		$b61c83ca0fef311e = $a6456d2c57df0603;
	}

	$C6147bf9a509b6cb = $a0823d4a2de30431 / (($d8a4881c582e2a3b ?: 1));
	$b6448faba596a90d = $b61c83ca0fef311e / (($a6456d2c57df0603 ?: 1));
	$c8bc885ceee305ea = min($C6147bf9a509b6cb, $b6448faba596a90d);

	if ($c8bc885ceee305ea < 1) {
		$ce0e1db0c5b7c9b1 = (int) $d8a4881c582e2a3b * $c8bc885ceee305ea;
		$Cafa4c31cfd7ae7f = (int) $a6456d2c57df0603 * $c8bc885ceee305ea;
	} else {
		$Cafa4c31cfd7ae7f = $a6456d2c57df0603;
		$ce0e1db0c5b7c9b1 = $d8a4881c582e2a3b;
	}

	return array('height' => round($Cafa4c31cfd7ae7f, 0), 'width' => round($ce0e1db0c5b7c9b1, 0));
}

function D3b3a460213C50eE($C700a2b357e5ed65)
{
	$B213d02f48d88809 = "/^(?:ftp|https?|feed)?:?\\/\\/(?:(?:(?:[\\w\\.\\-\\+!\$&'\\(\\)*\\+,;=]|%[0-9a-f]{2})+:)*" . "\r\n" . "    (?:[\\w\\.\\-\\+%!\$&'\\(\\)*\\+,;=]|%[0-9a-f]{2})+@)?(?:" . "\r\n" . '    (?:[a-z0-9\\-\\.]|%[0-9a-f]{2})+|(?:\\[(?:[0-9a-f]{0,4}:)*(?:[0-9a-f]{0,4})\\]))(?::[0-9]+)?(?:[\\/|\\?]' . "\r\n" . "    (?:[\\w#!:\\.\\?\\+\\|=&@\$'~*,;\\/\\(\\)\\[\\]\\-]|%[0-9a-f]{2})*)?\$/xi";

	return (bool) preg_match($B213d02f48d88809, $C700a2b357e5ed65);
}
