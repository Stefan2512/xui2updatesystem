<?php

include 'functions.php';
$c790d8a5c681996d = true;
$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `count` FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `users_groups`.`is_admin` = 1;');

if (0 >= $Fee0d5a474c96306->get_row()['count']) {
} else {
	$c790d8a5c681996d = false;
	include 'session.php';

	if (b1882dF698b44754()) {
	} else {
		b46F5dd76F3C7421();
	}
}

$C3790d786638ecab = false;

if (!(file_exists(TMP_PATH . '.migration.status') && file_exists(TMP_PATH . '.migration.pid'))) {
} else {
	$f9b07d216a168dcc = file_get_contents(TMP_PATH . '.migration.pid');

	if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
	} else {
		$C3790d786638ecab = true;
	}
}

if (!isset(XUI::$rRequest['update'])) {
	if (isset(XUI::$rRequest['migrate'])) {
		$E6ac1d398140e1b7 = array();

		foreach (XUI::$rRequest as $D3fa098be3f297cd => $b6842cb20051e925) {
			if (substr($D3fa098be3f297cd, 0, 8) != 'migrate#') {
			} else {
				list(, $E6ac1d398140e1b7[]) = explode('#', $D3fa098be3f297cd);
			}
		}

		if (count($E6ac1d398140e1b7) != 0) {
			if (!file_exists(TMP_PATH . '.migration.pid')) {
			} else {
				$f9b07d216a168dcc = intval(file_get_contents(TMP_PATH . '.migration.pid'));
				exec('kill -9 ' . $f9b07d216a168dcc);
			}

			file_put_contents(TMP_PATH . '.migration.options', json_encode($E6ac1d398140e1b7));
			unlink(TMP_PATH . '.migration.status');
			unlink(TMP_PATH . '.migration.pid');
			unlink(TMP_PATH . '.migration.log');
			shell_exec(PHP_BIN . ' ' . CLI_PATH . 'migrate.php > ' . TMP_PATH . '.migration.log 2>&1 &');
			$C3790d786638ecab = true;
		} else {
			header('Location: ./setup');

			exit();
		}
	} else {
		if (!(isset(XUI::$rRequest['new_user']) && $c790d8a5c681996d)) {
		} else {
			if (strlen(XUI::$rRequest['password']) < 8 || strlen(XUI::$rRequest['username']) < 8) {
				XUI::$rRequest['new'] = 1;
				$B4a5f8dc1f8d260c = STATUS_FAILURE;
			} else {
				$d49041d5f05a9270 = b9da5D708fc1c079('users');
				$d49041d5f05a9270['username'] = XUI::$rRequest['username'];
				$d49041d5f05a9270['password'] = DF65d36beA77Ae8C(XUI::$rRequest['password']);
				$d49041d5f05a9270['email'] = XUI::$rRequest['email'];
				$d49041d5f05a9270['last_login'] = time();
				$d49041d5f05a9270['date_registered'] = $d49041d5f05a9270['last_login'];
				$d49041d5f05a9270['member_group_id'] = 1;
				$d49041d5f05a9270['ip'] = C7afD69EDC2a2940();
				$d49041d5f05a9270['last_login'] = time();
				$acd0eb2c8a975903 = F4817DC607d9981d($d49041d5f05a9270);
				$A6d7047f2fda966c = 'INSERT INTO `users`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$_SESSION['hash'] = $Fee0d5a474c96306->last_insert_id();
					$_SESSION['ip'] = c7Afd69EdC2a2940();
					$_SESSION['code'] = E787D2298dBdA85d();
					$_SESSION['verify'] = md5($d49041d5f05a9270['username'] . '||' . $d49041d5f05a9270['password']);
					$Fee0d5a474c96306->query('UPDATE `servers` SET `server_ip` = ? WHERE `is_main` = 1 AND `server_type` = 0 LIMIT 1;', $_SERVER['SERVER_ADDR']);

					if ($_SESSION['code'] == 'setup') {
						header('Location: ./codes');

						exit();
					}

					header('Location: ./dashboard');

					exit();
				}

				XUI::$rRequest['new'] = 1;
				$B4a5f8dc1f8d260c = STATUS_FAILURE;
			}
		}
	}

	if ($C3790d786638ecab) {
	} else {
		$a2c13914f5950cd3 = false;
		$C18806ee1e68227d = false;
		$B3baea524daa88e8 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', true);

		if (!$B3baea524daa88e8->connected) {
		} else {
			$a2c13914f5950cd3 = true;
		}

		$B3baea524daa88e8->query("SHOW TABLES LIKE 'access_codes';");

		if (0 >= $B3baea524daa88e8->num_rows()) {
		} else {
			$C18806ee1e68227d = true;
		}

		$Aa8d8af3d37ca869 = array('reg_users' => array('Users & Resellers', 0), 'users' => array('Lines - Standard, MAG & Enigma2 Devices', 0), 'enigma2_devices' => array('Device Info - Engima2', 0), 'mag_devices' => array('Device Info - MAG', 0), 'user_output' => array('Line Output - HLS, MPEG-TS & RTMP', 0), 'streaming_servers' => array('Servers - Load Balancers', 0), 'series' => array('TV Series', 0), 'series_episodes' => array('TV Episodes', 0), 'streams' => array('Streams - Live, Radio, Created & VOD', 0), 'streams_sys' => array('Stream Servers', 0), 'streams_options' => array('Stream Options', 0), 'stream_categories' => array('Stream Categories', 0), 'bouquets' => array('Bouquets', 0), 'member_groups' => array('Member Groups', 0), 'packages' => array('Reseller Packages', 0), 'rtmp_ips' => array("RTMP IP's", 0), 'epg' => array('EPG Providers ', 0), 'blocked_ips' => array('Blocked IP Addresses', 0), 'blocked_user_agents' => array('Blocked User-Agents', 0), 'isp_addon' => array("Blocked ISP's", 0), 'tickets' => array('Tickets', 0), 'tickets_replies' => array('Ticket Replies', 0), 'transcoding_profiles' => array('Transcoding Profile', 0), 'watch_folders' => array('Watch Folders', 0), 'members' => array('Users & Resellers', 0), 'epg_sources' => array('EPG Providers', 0), 'blocked_isps' => array("Blocked ISP's", 0), 'categories' => array('Stream Categories', 0), 'groups' => array('Member Groups', 0), 'servers' => array('Servers - Load Balancers', 0), 'stream_servers' => array('Stream Servers', 0));

		foreach (array_keys($Aa8d8af3d37ca869) as $B1a1e80ba9ae29c7) {
			try {
				$B3baea524daa88e8->query("SHOW TABLES LIKE '" . $B1a1e80ba9ae29c7 . "';");

				if (0 >= $B3baea524daa88e8->num_rows()) {
				} else {
					$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `' . $B1a1e80ba9ae29c7 . '`;');
					$Aa8d8af3d37ca869[$B1a1e80ba9ae29c7][1] = $B3baea524daa88e8->get_row()['count'];
				}
			} catch (Exception $c34ae71903f0d920) {
			}
		}
		$b6727cb7779668f9 = 0;

		foreach ($Aa8d8af3d37ca869 as $B1a1e80ba9ae29c7 => $Fcf7001697d4fe21) {
			$b6727cb7779668f9 += $Fcf7001697d4fe21[1];
		}
		ksort($Aa8d8af3d37ca869);
	}

	if ($c790d8a5c681996d || b1882dF698b44754()) {
	} else {
		B46f5DD76F3c7421();
	}

	$bcf587bb39f95fd5 = 'Database Migration';
	$A4d9bff1e2402340 = true;
	include 'header.php';
	echo '<div class="wrapper boxed-layout"';

	if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	} else {
		echo ' style="display: none;"';
	}

	echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">Database Migration</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-xl-12">' . "\r\n" . '                <div class="card-box">' . "\r\n" . '                    ';

	if ($C3790d786638ecab) {
		echo "\t\t\t\t\t" . '<div class="col-md-12 align-self-center">' . "\r\n" . '                        <div class="text-center" style="padding-top: 15px;">' . "\r\n" . '                            <i class="mdi mdi-creation avatar-title font-24 text-info"></i><br/>' . "\r\n" . '                            <h4 class="header-title text-info">Migrating...</h4>' . "\r\n" . '                            <textarea readonly style="padding: 15px; margin-top: 20px; background: #56c2d6; color: #fff; border: 0; width: 100%; height: 300px; scroll-y: auto;" id="migration_progress"></textarea>' . "\r\n" . '                            <ul class="list-inline wizard mb-4">' . "\r\n" . '                                <li class="float-right">' . "\r\n" . '                                    <button disabled onClick="migrateServer();" class="btn btn-info" id="migrate_button">Try Again</button>' . "\r\n" . '                                </li>' . "\r\n" . '                            </ul>' . "\r\n" . '                        </div>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n" . '                    ';
	} else {
		if (isset(XUI::$rRequest['new']) && $c790d8a5c681996d) {
			echo '                    <form action="./setup" method="POST" data-parsley-validate="">' . "\r\n" . '                        <div class="row">' . "\r\n" . '                            <div class="col-12">' . "\r\n" . '                                ';

			if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_FAILURE) {
				echo '                                <div class="alert alert-danger mb-4" role="alert">' . "\r\n" . '                                    Please ensure your username and password are at least 8 characters long.' . "\r\n" . '                                </div>' . "\r\n" . '                                ';
			} else {
				echo '                                <div class="alert alert-info mb-4" role="alert">' . "\r\n" . "                                    As you've decided not to migrate a previous database, you need to create an admin account below.<br/>Choose a strong username and password or you may be susceptible to attacks." . "\r\n" . '                                </div>' . "\r\n" . '                                ';
			}

			echo '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-4 col-form-label" for="username">Admin Username</label>' . "\r\n" . '                                    <div class="col-md-8">' . "\r\n" . '                                        <input type="text" class="form-control" id="username" name="username" value="" required data-parsley-trigger="change">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-4 col-form-label" for="password">Admin Password</label>' . "\r\n" . '                                    <div class="col-md-8">' . "\r\n" . '                                        <input type="password" class="form-control" id="password" name="password" value="" required data-parsley-trigger="change">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-4 col-form-label" for="email">Email Address</label>' . "\r\n" . '                                    <div class="col-md-8">' . "\r\n" . '                                        <input type="text" class="form-control" id="email" name="email" value="">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                            </div> ' . "\r\n" . '                        </div> ' . "\r\n" . '                        <ul class="list-inline wizard mb-4">' . "\r\n" . '                            <li class="list-inline-item float-right">' . "\r\n" . '                                <input name="new_user" type="submit" class="btn btn-primary" value="Create" />' . "\r\n" . '                            </li>' . "\r\n" . '                        </ul>' . "\r\n" . '                    </form>' . "\r\n" . '                    ';
		} else {
			echo '                    <form action="./setup" method="POST" data-parsley-validate="">' . "\r\n" . '                        <div class="row">' . "\r\n" . '                            <div class="col-12">' . "\r\n" . '                                <div class="alert alert-secondary mb-4" role="alert">' . "\r\n" . "                                    In order to migrate your database from a previous installation of Xtream UI, ZapX (original and NXT), StreamCreed or generic Xtream Codes v2 installation, you will need to restore your migration database to the <strong>xui_migrate</strong> database as XUI will have access to it.<br/><br/>The script will then loop through all of your previously existing data and alter it to work with XUI. No logs will be migrated and some clean up may need to be done post-migration but this tool should help significantly in carrying over your data to your new panel.<br/><br/>For instructions visit the <a href=\"https://xui.one/billing/index.php?rp=/knowledgebase/3\">XUI FAQ here</a>.<br/><br/>Once you're done, refresh the page." . "\r\n" . '                                </div>' . "\r\n" . '                                ';

			if ($a2c13914f5950cd3) {
			} else {
				echo '                                <div class="alert alert-danger mb-4" role="alert">' . "\r\n" . '                                    A connection to the xui_migrate database could not be made. Please ensure the database exists, if it does not, create it.' . "\r\n" . '                                </div>' . "\r\n" . '                                ';
			}

			if (!$C18806ee1e68227d) {
			} else {
				echo '                                <div class="alert alert-danger mb-4" role="alert">' . "\r\n" . '                                    The data restored to the xui_migrate database seems to contain tables attributed with XUI.one. You cannot migrate using this data, you need to restore it via the Databases section in the admin panel.' . "\r\n" . '                                </div>' . "\r\n" . '                                ';
			}

			echo '                            </div> ' . "\r\n" . '                        </div> ' . "\r\n" . '                        ';

			if (!($a2c13914f5950cd3 && !$C18806ee1e68227d && 0 < $b6727cb7779668f9)) {
			} else {
				echo '                        <div class="row">' . "\r\n" . '                            <div class="col-12">' . "\r\n" . '                                <div class="alert alert-secondary mb-4" role="alert">' . "\r\n" . "                                    Below is a list of records found in the migration database. Please check this over and click Migrate when you're ready to begin. You can also uncheck tables you don't want to migrate." . "\r\n" . '                                </div>' . "\r\n" . '                                <table class="table table-striped table-borderless mb-4">' . "\r\n" . '                                    <thead>' . "\r\n" . '                                        <tr>' . "\r\n" . '                                            <th>Description</th>' . "\r\n" . '                                            <th>Table Name</th>' . "\r\n" . '                                            <th class="text-center">Records</th>' . "\r\n" . '                                            <th class="text-center">Migrate</th>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                    </thead>' . "\r\n" . '                                    <tbody>' . "\r\n" . '                                        ';

				foreach ($Aa8d8af3d37ca869 as $B1a1e80ba9ae29c7 => $bb2621204e39e62d) {
					if ($bb2621204e39e62d[1] != 0) {
						echo '                                        <tr>' . "\r\n" . '                                            <td>';
						echo $bb2621204e39e62d[0];
						echo '</td>' . "\r\n" . '                                            <td>';
						echo $B1a1e80ba9ae29c7;
						echo '</td>' . "\r\n" . '                                            <td class="text-center"><button type="button" class="btn btn-';
						echo(0 < $bb2621204e39e62d[1] ? 'info' : 'secondary');
						echo ' btn-xs waves-effect waves-light">';
						echo $bb2621204e39e62d[1];
						echo '</button></td>' . "\r\n" . '                                            <td class="text-center">' . "\r\n" . '                                                <div class="checkbox checkbox-single checkbox-info">' . "\r\n" . '                                                    <input name="migrate#';
						echo $B1a1e80ba9ae29c7;
						echo '" ';
						echo(0 < $bb2621204e39e62d[1] ? 'checked' : 'disabled');
						echo ' type="checkbox" class="activate">' . "\r\n" . '                                                    <label></label>' . "\r\n" . '                                                </div>' . "\r\n" . '                                            </td>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                        ';
					}
				}
				echo '                                    </tbody>' . "\r\n" . '                                </table>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
			}

			echo '                        <div class="row">' . "\r\n" . '                            <div class="col-12">' . "\r\n" . '                                <ul class="list-inline wizard">' . "\r\n" . '                                    ';

			if (!$c790d8a5c681996d) {
			} else {
				echo '                                    <li class="list-inline-item">' . "\r\n" . "                                        <a href=\"./setup?new\"><button name=\"dont_migrate\" class=\"btn btn-danger\" type=\"button\">Don't Migrate</button></a>" . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
			}

			if (!($a2c13914f5950cd3 && !$C18806ee1e68227d && 0 < $b6727cb7779668f9)) {
			} else {
				echo '                                    <li class="list-inline-item float-right">' . "\r\n" . '                                        <input name="migrate" type="submit" class="btn btn-primary" value="Migrate" />' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
			}

			echo '                                </ul>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                    </form>' . "\r\n" . '                    ';
		}
	}

	echo "\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div> ' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
	include 'footer.php';
} else {
	if (file_exists(TMP_PATH . '.migration.log')) {
		$fa2807b514bf8d02 = file_get_contents(TMP_PATH . '.migration.log');
		$Ba23222f3ed2dc08 = intval(file_get_contents(TMP_PATH . '.migration.status'));

		if ($Ba23222f3ed2dc08) {
		} else {
			$Ba23222f3ed2dc08 = 1;
		}

		if ($Ba23222f3ed2dc08 != 2) {
		} else {
			unlink(TMP_PATH . '.migration.options');
			unlink(TMP_PATH . '.migration.status');
			unlink(TMP_PATH . '.migration.pid');
			unlink(TMP_PATH . '.migration.log');
		}

		echo json_encode(array('result' => true, 'status' => $Ba23222f3ed2dc08, 'data' => $fa2807b514bf8d02));
	} else {
		echo json_encode(array('result' => false));
	}

	exit();
}
