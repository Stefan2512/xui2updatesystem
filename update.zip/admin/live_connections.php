<?php

include 'session.php';
include 'functions.php';

if (b1882df698B44754()) {
} else {
	b46F5dD76f3C7421();
}

if (!isset(XUI::$rRequest['user_id'])) {
} else {
	$cd6f747ef348d4bc = b4036ef9a1db8473(XUI::$rRequest['user_id']);
}

if (!isset(XUI::$rRequest['stream_id'])) {
} else {
	$d550d3261242f0a6 = e5eCeB32f67d5E70(XUI::$rRequest['stream_id']);
}

$bcf587bb39f95fd5 = 'Live Connections';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['live_connections'];
echo '</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t";

if (XUI::$rSettings['redis_handler']) {
	echo '                            <div class="col-md-3">' . "\r\n" . '                                <select id="live_server" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value=""';

	if (isset(XUI::$rRequest['server'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $_['all_servers'];
	echo '</option>' . "\r\n" . '                                    ';

	foreach (XUI::$rServers as $e81220b4451f37c9) {
		if (!$e81220b4451f37c9['enabled']) {
		} else {
			echo '                                    <option value="';
			echo $e81220b4451f37c9['id'];
			echo '"';

			if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo $e81220b4451f37c9['server_name'];
			echo '</option>' . "\r\n" . '                                    ';
		}
	}
	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-4">' . "\r\n" . '                                <select id="live_stream" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

	if (!isset($d550d3261242f0a6)) {
	} else {
		echo '                                    <option value="';
		echo intval($d550d3261242f0a6['id']);
		echo '" selected="selected">';
		echo $d550d3261242f0a6['stream_display_name'];
		echo '</option>' . "\r\n" . '                                    ';
	}

	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-3">' . "\r\n" . '                                <select id="live_line" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

	if (!isset($cd6f747ef348d4bc)) {
	} else {
		echo '                                    <option value="';
		echo intval($cd6f747ef348d4bc['id']);
		echo '" selected="selected">';
		echo $cd6f747ef348d4bc['username'];
		echo '</option>' . "\r\n" . '                                    ';
	}

	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <label class="col-md-1 col-form-label text-center" for="live_show_entries">';
	echo $_['show'];
	echo '</label>' . "\r\n" . '                            <div class="col-md-1">' . "\r\n" . '                                <select id="live_show_entries" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

	foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
		echo '                                    <option';

		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}

		echo ' value="';
		echo $C9e42207e95f03ed;
		echo '">';
		echo $C9e42207e95f03ed;
		echo '</option>' . "\r\n" . '                                    ';
	}
	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n\t\t\t\t\t\t\t";
} else {
	echo "\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n" . '                                <input type="text" class="form-control" id="live_search" value="';

	if (!isset(XUI::$rRequest['search'])) {
	} else {
		echo htmlspecialchars(XUI::$rRequest['search']);
	}

	echo '" placeholder="';
	echo $_['search_logs'];
	echo '...">' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="live_server" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value=""';

	if (isset(XUI::$rRequest['server'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $_['all_servers'];
	echo '</option>' . "\r\n" . '                                    ';

	foreach (XUI::$rServers as $e81220b4451f37c9) {
		if (!$e81220b4451f37c9['enabled']) {
		} else {
			echo '                                    <option value="';
			echo $e81220b4451f37c9['id'];
			echo '"';

			if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo $e81220b4451f37c9['server_name'];
			echo '</option>' . "\r\n" . '                                    ';
		}
	}
	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="live_stream" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

	if (!isset($d550d3261242f0a6)) {
	} else {
		echo '                                    <option value="';
		echo intval($d550d3261242f0a6['id']);
		echo '" selected="selected">';
		echo $d550d3261242f0a6['stream_display_name'];
		echo '</option>' . "\r\n" . '                                    ';
	}

	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="live_line" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

	if (!isset($cd6f747ef348d4bc)) {
	} else {
		echo '                                    <option value="';
		echo intval($cd6f747ef348d4bc['id']);
		echo '" selected="selected">';
		echo $cd6f747ef348d4bc['username'];
		echo '</option>' . "\r\n" . '                                    ';
	}

	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="live_filter" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value=""';

	if (isset(XUI::$rRequest['filter'])) {
	} else {
		echo ' selected';
	}

	echo '>No Filter</option>' . "\r\n" . '                                    <option value="1"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 1)) {
	} else {
		echo ' selected';
	}

	echo '>User Lines</option>' . "\r\n" . '                                    <option value="2"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 2)) {
	} else {
		echo ' selected';
	}

	echo '>MAG Devices</option>' . "\r\n" . '                                    <option value="3"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 3)) {
	} else {
		echo ' selected';
	}

	echo '>Enigma2 Devices</option>' . "\r\n" . '                                    <option value="4"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 4)) {
	} else {
		echo ' selected';
	}

	echo '>Trial Lines</option>' . "\r\n" . '                                    <option value="5"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 5)) {
	} else {
		echo ' selected';
	}

	echo '>Restreamers</option>' . "\r\n" . '                                    <option value="6"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 6)) {
	} else {
		echo ' selected';
	}

	echo '>Ministra Lines</option>' . "\r\n" . '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <label class="col-md-1 col-form-label text-center" for="live_show_entries">';
	echo $_['show'];
	echo '</label>' . "\r\n" . '                            <div class="col-md-1">' . "\r\n" . '                                <select id="live_show_entries" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

	foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
		echo '                                    <option';

		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}

		echo ' value="';
		echo $C9e42207e95f03ed;
		echo '">';
		echo $C9e42207e95f03ed;
		echo '</option>' . "\r\n" . '                                    ';
	}
	echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n\t\t\t\t\t\t\t";
}

echo '                        </div>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n" . '                                    <th class="text-center">ID</th>' . "\r\n" . '                                    <th class="text-center">Quality</th>' . "\r\n" . '                                    <th>Line</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Stream</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Server</th>' . "\r\n" . '                                    <th>Player</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>ISP</th>' . "\r\n" . '                                    <th class="text-center">IP</th>' . "\r\n" . '                                    <th class="text-center">Duration</th>' . "\r\n" . '                                    <th class="text-center">Output</th>' . "\r\n" . '                                    <th class="text-center">Restreamer</th>' . "\r\n" . '                                    <th class="text-center">';
echo $_['actions'];
echo '</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
