<?php

if (!Xui\Functions::verifyLicense()) {
	$e4f047a540694248 = $_SERVER['SERVER_ADDR'];
	$cc5f26dd881329b7 = getserverinfo();
	$Ff5cc379dac51e99 = false;
	$ac40d15db80765c2 = false;

	if (isset($_POST['update_license'])) {
		$E78d1cdfdd1a013e = $_POST['whmcs_license'];

		if (strlen($E78d1cdfdd1a013e) == 16 && ctype_xdigit($E78d1cdfdd1a013e)) {
			$A8cd97ab4e563b9a = false;
			$C136781201b1b896 = array();
			$B76ac07451d0e3e0 = explode("\n", file_get_contents('../config/config.ini'));

			foreach ($B76ac07451d0e3e0 as $Ff014d0ebd314fcd) {
				if (strtolower(substr($Ff014d0ebd314fcd, 0, 7)) != 'license') {
				} else {
					$Ff014d0ebd314fcd = 'license     =   "' . $E78d1cdfdd1a013e . '"';
					$A8cd97ab4e563b9a = true;
				}

				$C136781201b1b896[] = $Ff014d0ebd314fcd;
			}

			if ($A8cd97ab4e563b9a) {
				$B76ac07451d0e3e0 = implode("\n", $C136781201b1b896);

				if (file_put_contents('../config/config.ini', $B76ac07451d0e3e0)) {
					$Affa53fde645e67d = Xui\Functions::updateLicense('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', intval($_SERVER['SERVER_PORT']));

					if (!$Affa53fde645e67d['status']) {
					} else {
						shell_exec('/home/xui/bin/php/bin/php /home/xui/crons/epg.php > /dev/null 2>/dev/null &');
						shell_exec('/home/xui/bin/php/bin/php /home/xui/crons/license.php');
						shell_exec('/home/xui/bin/php/bin/php /home/xui/includes/cli/startup.php');
						header('Location: ./index');

						exit();
					}
				} else {
					$Affa53fde645e67d = array('status' => false, 'error' => 'STATUS_WRITE_FAILED');
				}
			} else {
				$Affa53fde645e67d = array('status' => false, 'error' => 'STATUS_WRITE_FAILED');
			}

			$Ff5cc379dac51e99 = true;
		} else {
			$ac40d15db80765c2 = true;
		}
	} else {
		$E78d1cdfdd1a013e = parse_ini_file('../config/config.ini')['license'];
	}

	$d34e4fb1bc09629e = Xui\Functions::getLicense();
	$dc3e92fdb8358633 = false;

	if ($d34e4fb1bc09629e[3] >= time()) {
	} else {
		$dc3e92fdb8358633 = true;
	}

	$c023ff5aa4a28b27 = false;

	if (trim($d34e4fb1bc09629e[5]) == $cc5f26dd881329b7[2]) {
	} else {
		$c023ff5aa4a28b27 = true;
	}

	echo '<!DOCTYPE html>' . "\r\n" . '<html lang="en">' . "\r\n" . '    <head>' . "\r\n" . '        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . "\r\n" . '        <title>XUI | License</title>' . "\r\n" . '        <meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\r\n" . '        <meta http-equiv="X-UA-Compatible" content="IE=edge" />' . "\r\n" . '        <meta name="robots" content="noindex,nofollow">' . "\r\n" . '        <link rel="shortcut icon" href="assets/images/favicon.ico">' . "\r\n\t\t" . '<link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/css/app.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/css/extra.css" rel="stylesheet" type="text/css" />' . "\r\n" . '    </head>' . "\r\n" . '    <body>' . "\r\n" . '        <header id="topnav">' . "\r\n" . '            <div class="navbar-overlay bg-animate"></div>' . "\r\n" . '            <div class="navbar-custom">' . "\r\n" . '                <div class="container-fluid">' . "\r\n" . '                    <div class="logo-box">' . "\r\n" . '                        <a href="javascript: void(0);" class="logo text-center">' . "\r\n" . '                            <span class="logo-lg">' . "\r\n" . '                                <img src="assets/images/logo-topbar.png" alt="" height="26">' . "\r\n" . '                            </span>' . "\r\n" . '                            <span class="logo-sm">' . "\r\n" . '                                <img src="assets/images/logo-topbar.png" alt="" height="28">' . "\r\n" . '                            </span>' . "\r\n" . '                        </a>' . "\r\n" . '                    </div>' . "\r\n" . '                    <div class="clearfix"></div>' . "\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n" . '        </header>' . "\r\n" . '        <div class="wrapper boxed-layout"';

	if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	} else {
		echo ' style="display: none;"';
	}

	echo '>' . "\r\n" . '            <div class="container-fluid">' . "\r\n" . '                <div class="row">' . "\r\n" . '                    <div class="col-12">' . "\r\n" . '                        <div class="page-title-box">' . "\r\n" . '                            <h4 class="page-title">XUI License</h4>' . "\r\n" . '                        </div>' . "\r\n" . '                    </div>' . "\r\n" . '                </div>' . "\r\n" . '                <div class="row">' . "\r\n" . '                    <div class="col-xl-12">' . "\r\n" . '                        <div class="card-box">' . "\r\n" . '                            <form action="./license" method="POST" data-parsley-validate="">' . "\r\n" . '                                <div class="row">' . "\r\n" . '                                    <div class="col-12">' . "\r\n" . '                                        ';

	if ($ac40d15db80765c2) {
		echo '                                        <div class="alert alert-warning" role="alert">' . "\r\n" . "                                            The WHMCS License key you entered isn't valid, please ensure it is a 16 character hexadecimal string." . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
	} else {
		if (!$d34e4fb1bc09629e) {
			if ($Ff5cc379dac51e99) {
				echo '                                                    <div class="alert alert-danger" role="alert">' . "\r\n" . '                                                    ';

				if ($Affa53fde645e67d['error'] == 'STATUS_IP_BANNED') {
					echo '<strong>Licensing Failed:</strong> Your IP has been banned by the flood detection system.';
				} else {
					if ($Affa53fde645e67d['error'] == 'STATUS_DECRYPT_FAILED') {
						echo '<strong>Licensing Failed:</strong> Licensing system failed to decrypt the request.';
					} else {
						if ($Affa53fde645e67d['error'] == 'STATUS_NO_SERVER_ID') {
							echo '<strong>Licensing Failed:</strong> No server ID detected, check your configuration file.';
						} else {
							if ($Affa53fde645e67d['error'] == 'STATUS_NO_NETWORK') {
								echo '<strong>Licensing Failed:</strong> No network configuration details detected.';
							} else {
								if ($Affa53fde645e67d['error'] == 'STATUS_INVALID_LICENSE') {
									echo '<strong>Licensing Failed:</strong> Invalid license key entered.';
								} else {
									if ($Affa53fde645e67d['error'] == 'STATUS_BILLING_INACTIVE') {
										echo '<strong>Licensing Failed:</strong> This license is no longer active, please check your billing details.';
									} else {
										if ($Affa53fde645e67d['error'] == 'STATUS_INVALID_MAC') {
											echo "<strong>Licensing Failed:</strong> Couldn't match your MAC address to your system.";
										} else {
											if ($Affa53fde645e67d['error'] == 'STATUS_INVALID_IP') {
												echo "<strong>Licensing Failed:</strong> Couldn't match your outgoing IP address to your system.";
											} else {
												if ($Affa53fde645e67d['error'] == 'STATUS_REVOKED') {
													echo '<strong>Licensing Failed:</strong> License has been revoked! Please check the billing panel.';
												} else {
													if ($Affa53fde645e67d['error'] == 'STATUS_REISSUES_USED') {
														echo '<strong>Licensing Failed:</strong> Maximum number of reissues has been used. Please contact support.';
													} else {
														if ($Affa53fde645e67d['error'] == 'STATUS_INVALID_PRODUCT') {
															echo '<strong>Licensing Failed:</strong> Invalid product selected. Please contact support.';
														} else {
															if ($Affa53fde645e67d['error'] == 'STATUS_LICENSE_FAILED') {
																echo '<strong>Licensing Failed:</strong> License failed to generate with an unknown error. Please contact support.';
															} else {
																if ($Affa53fde645e67d['error'] == 'STATUS_WRITE_FAILED') {
																	echo "<strong>Licensing Failed:</strong> Config file couldn't be written to safely. Please check permissions.";
																} else {
																	echo "Could not generate a license, please checked your <strong>WHMCS License</strong> below and ensure your license is set to <strong>Reissued</strong> in the billing panel. If it still doesn't work, contact support.";
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}

				echo '                                                </div>' . "\r\n" . '                                            ';
			} else {
				echo '                                                <div class="alert alert-info" role="alert">' . "\r\n" . '                                                    ';

				if (0 < !$cc5f26dd881329b7[0]) {
					echo "Your server isn't giving XUI information about the installed network devices, such as your external IP Address and MAC Address. Please contact support!";
				} else {
					if (!$cc5f26dd881329b7[1]) {
						echo 'The stored IP address information on your server is showing a different IP (' . $cc5f26dd881329b7[3] . ') to what XUI expected (' . $e4f047a540694248 . "). This will likely mean a license won't generate. Contact support with both IP addresses and we will map them to your account.";
					} else {
						if (0 < strlen($E78d1cdfdd1a013e)) {
							echo 'No license has been generated for this server. If the <strong>WHMCS License</strong> below is correct and matches your XUI Account, click the <strong>Update License</strong> button to force an update.';
						} else {
							echo 'Welcome to XUI! Please visit the <strong><a href="https://xui.one/billing/">XUI Billing Panel</a></strong> to find your license number and enter it in the box below, then click <strong>Update License</strong> to generate your license file.';
						}
					}
				}

				echo '                                                </div>' . "\r\n" . '                                            ';
			}
		} else {
			if ($dc3e92fdb8358633 && $c023ff5aa4a28b27) {
				echo '                                        <div class="alert alert-info" role="alert">' . "\r\n" . '                                            Your license has expired, and it also seems your server configuration has changed since first generating your license. Please visit the <strong><a href="https://xui.one/billing/">XUI Billing Panel</a></strong>, pay your invoices, then click the <strong>Update License</strong> button to generate a new license.' . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
			} else {
				if ($dc3e92fdb8358633) {
					echo '                                        <div class="alert alert-info" role="alert">' . "\r\n" . '                                            Your license has expired. Please visit the <strong><a href="https://xui.one/billing/">XUI Billing Panel</a></strong> and pay your invoices, you can then click the <strong>Update License</strong> button to generate a new license.' . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
				} else {
					echo '                                        <div class="alert alert-info" role="alert">' . "\r\n" . '                                            Your server configuration has changed since first generating your license. You can click the <strong>Update License</strong> button to generate a new license, this will reissue your license ensuring you have enough reissues to continue.' . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
				}
			}
		}
	}

	if (!$cc5f26dd881329b7[0]) {
	} else {
		echo '                                        <div class="form-group row mt-4 mb-4">' . "\r\n" . '                                            <label class="col-md-4 col-form-label" for="whmcs_license">WHMCS License</label>' . "\r\n" . '                                            <div class="col-md-8">' . "\r\n" . '                                                <input type="text" class="form-control" id="whmcs_license" name="whmcs_license" maxlength="16" value="';
		echo $E78d1cdfdd1a013e;
		echo '">' . "\r\n" . '                                            </div>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
	}

	if ($d34e4fb1bc09629e) {
		echo '                                        <div class="form-group row mb-4">' . "\r\n" . '                                            <label class="col-md-4 col-form-label" for="whmcs_account">WHMCS Account</label>' . "\r\n" . '                                            <div class="col-md-8">' . "\r\n" . '                                                <input id="whmcs_account" type="text" class="form-control"  value="';
		echo $d34e4fb1bc09629e[1];
		echo '" readonly>' . "\r\n" . '                                            </div>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <div class="form-group row mb-4">' . "\r\n" . '                                            <label class="col-md-4 col-form-label" for="server_ip">Licensed Server IP</label>' . "\r\n" . '                                            <div class="col-md-8">' . "\r\n" . '                                                <input id="server_ip" type="text" class="form-control" value="';
		echo $d34e4fb1bc09629e[2];
		echo '" readonly>' . "\r\n" . '                                            </div>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <div class="form-group row mb-4">' . "\r\n" . '                                            <label class="col-md-4 col-form-label" for="expiration_date">Expiration Date</label>' . "\r\n" . '                                            <div class="col-md-8">' . "\r\n" . '                                                <input id="expiration_date" type="text" class="form-control" value="';
		echo date('jS F Y', $d34e4fb1bc09629e[3]);
		echo '" readonly>' . "\r\n" . '                                            </div>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
	} else {
		if (!$cc5f26dd881329b7[0]) {
		} else {
			echo '                                        <div class="form-group row mb-4">' . "\r\n" . '                                            <label class="col-md-4 col-form-label" for="server_ip">Server IP</label>' . "\r\n" . '                                            <div class="col-md-8">' . "\r\n" . '                                                <input id="server_ip" type="text" class="form-control"  value="';
			echo $e4f047a540694248;
			echo '" readonly>' . "\r\n" . '                                            </div>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <div class="form-group row mb-4">' . "\r\n" . '                                            <label class="col-md-4 col-form-label" for="mac_address">MAC Address</label>' . "\r\n" . '                                            <div class="col-md-8">' . "\r\n" . '                                                <input id="mac_address" type="text" class="form-control"  value="';
			echo $cc5f26dd881329b7[0];
			echo '" readonly>' . "\r\n" . '                                            </div>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        ';
		}
	}

	echo '                                    </div> ' . "\r\n" . '                                </div> ' . "\r\n" . '                                ';

	if (!$cc5f26dd881329b7[0]) {
	} else {
		echo '                                <ul class="list-inline wizard mb-4">' . "\r\n" . '                                    <li class="list-inline-item float-right">' . "\r\n" . '                                        <input name="update_license" type="submit" class="btn btn-primary" value="Update License" />' . "\r\n" . '                                    </li>' . "\r\n" . '                                </ul>' . "\r\n" . '                                ';
	}

	echo '                            </form>' . "\r\n" . '                        </div>' . "\r\n" . '                    </div> ' . "\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n" . '        </div>' . "\r\n" . '        <footer class="footer">' . "\r\n" . '            <div class="container-fluid">' . "\r\n" . '                <div class="row">' . "\r\n" . "                    <div class=\"col-md-12 copyright text-center\">&copy; <img height='20px' style='padding-left: 10px; padding-right: 10px; margin-top: -2px;' class='whiteout' src='./assets/images/logo-topbar.png' /> 2021</div>" . "\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n" . '        </footer>' . "\r\n" . '    </body>' . "\r\n" . '</html>';
} else {
	header('Location: ./index');

	exit();
}

function getServerInfo()
{
	global $e4f047a540694248;
	$Cec7eb8a067db8d7 = json_decode(shell_exec('ip --json address list'), true);
	$ee7553b0caebc8c4 = false;
	$Fee4ddc6e0fd83b9 = null;
	$C5cb908c90bfad7e = null;

	foreach ($Cec7eb8a067db8d7 as $A629f73d84bee6f2) {
		foreach ($A629f73d84bee6f2['addr_info'] as $d9ad9627c40dff4d) {
			if (!(filter_var($A629f73d84bee6f2['address'], FILTER_VALIDATE_MAC) && $A629f73d84bee6f2['address'] != '00:00:00:00:00:00')) {
			} else {
				if ($d9ad9627c40dff4d['local'] == $e4f047a540694248) {
					$Fee4ddc6e0fd83b9 = $A629f73d84bee6f2['address'];
					$ee7553b0caebc8c4 = true;

					break;
				}

				if ($Fee4ddc6e0fd83b9) {
				} else {
					$Fee4ddc6e0fd83b9 = $A629f73d84bee6f2['address'];
					$C5cb908c90bfad7e = $d9ad9627c40dff4d['local'];
				}
			}
		}
	}

	return array($Fee4ddc6e0fd83b9, $ee7553b0caebc8c4, trim(explode("\n", shell_exec('../bin/blkid -o value -s UUID'))[0]), $C5cb908c90bfad7e);
}
