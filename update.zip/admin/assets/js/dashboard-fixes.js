/**
 * XUI Dashboard Production Fixes
 * File: dashboard-fixes.js
 * Version: 1.0 Production
 */

(function() {
    'use strict';

    // Initialize dashboard fixes when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        console.log('? Dashboard Production Fixes loaded');
        
        initializeChartFixes();
        initializeProgressBarFixes();
        initializeFooterFix();
        initializeResponsiveFixes();
    });

    /**
     * Fix chart display issues
     */
    function initializeChartFixes() {
        // Wait for Peity to initialize
        setTimeout(function() {
            const peityElements = document.querySelectorAll('[data-plugin="peity-line"]');
            
            peityElements.forEach(function(element) {
                // Check if Peity successfully created a chart
                const hasChart = element.querySelector('svg') || element.querySelector('canvas');
                
                if (!hasChart || element.textContent.includes(',')) {
                    // Peity failed or showing raw data, create fallback
                    createFallbackChart(element);
                } else {
                    // Peity worked, just ensure proper styling
                    stylePeityChart(element);
                }
            });
        }, 1500); // Give Peity time to initialize
    }

    /**
     * Create fallback chart when Peity fails
     */
    function createFallbackChart(element) {
        // Extract data from element text content
        const rawData = element.textContent || '';
        const dataPoints = rawData.split(',').filter(val => val.trim() !== '');
        
        // Clear element
        element.innerHTML = '';
        element.className = 'chart-fallback-container';
        
        // Create bars
        const maxBars = Math.min(dataPoints.length || 15, 20);
        
        for (let i = 0; i < maxBars; i++) {
            const bar = document.createElement('div');
            bar.className = 'chart-fallback-bar';
            
            // Use real data if available
            let height;
            if (dataPoints[i] && !isNaN(dataPoints[i])) {
                height = Math.max(10, Math.min(90, parseInt(dataPoints[i])));
            } else {
                // Default height pattern for empty data
                height = 30 + (i % 3) * 20;
            }
            
            bar.style.height = height + '%';
            bar.style.animationDelay = (i * 0.05) + 's';
            
            element.appendChild(bar);
        }
    }

    /**
     * Style existing Peity charts
     */
    function stylePeityChart(element) {
        // Hide the text content
        element.style.fontSize = '0';
        element.style.color = 'transparent';
        element.style.textIndent = '-9999px';
        element.style.overflow = 'hidden';
        
        // Ensure SVG/Canvas is properly sized
        const chart = element.querySelector('svg') || element.querySelector('canvas');
        if (chart) {
            chart.style.width = '100%';
            chart.style.height = '50px';
            chart.style.display = 'block';
        }
    }

    /**
     * Fix progress bar display issues
     */
    function initializeProgressBarFixes() {
        // Find all progress bars and ensure they show percentages
        const progressBars = document.querySelectorAll('.progress-bar, .progress-bar-enhanced');
        
        progressBars.forEach(function(bar) {
            fixProgressBarText(bar);
            
            // Watch for changes
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'attributes' && 
                        (mutation.attributeName === 'aria-valuenow' || mutation.attributeName === 'style')) {
                        fixProgressBarText(bar);
                    }
                });
            });
            
            observer.observe(bar, { 
                attributes: true, 
                attributeFilter: ['aria-valuenow', 'style'] 
            });
        });
    }

    /**
     * Fix individual progress bar text display
     */
    function fixProgressBarText(progressBar) {
        const percentage = progressBar.getAttribute('aria-valuenow') || 
                          progressBar.style.width.replace('%', '') || '0';
        const clampedPercentage = Math.min(100, Math.max(0, parseInt(percentage)));
        
        // Find or create progress text element
        let progressText = progressBar.querySelector('.progress-text');
        if (!progressText) {
            progressText = document.createElement('span');
            progressText.className = 'progress-text';
            progressBar.appendChild(progressText);
        }
        
        // Update text
        progressText.textContent = clampedPercentage + '%';
        
        // Ensure proper styling
        progressText.style.position = 'absolute';
        progressText.style.left = '50%';
        progressText.style.top = '50%';
        progressText.style.transform = 'translate(-50%, -50%)';
        progressText.style.color = 'white';
        progressText.style.fontSize = '11px';
        progressText.style.fontWeight = '700';
        progressText.style.textShadow = '0 1px 2px rgba(0,0,0,0.5)';
        progressText.style.zIndex = '10';
        progressText.style.pointerEvents = 'none';
    }

    /**
     * Ensure footer is properly positioned
     */
    function initializeFooterFix() {
        // Remove any conflicting footers
        const existingFooters = document.querySelectorAll('footer:not(.footer-fixed-correct)');
        existingFooters.forEach(function(footer) {
            footer.style.display = 'none';
        });
        
        // Ensure body has proper bottom padding
        document.body.style.paddingBottom = '60px';
        
        // Ensure wrapper has proper margin
        const wrapper = document.querySelector('.wrapper');
        if (wrapper) {
            wrapper.style.marginBottom = '60px';
        }
    }

    /**
     * Handle responsive adjustments
     */
    function initializeResponsiveFixes() {
        function handleResize() {
            const screenWidth = window.innerWidth;
            
            // Adjust dashboard cards for mobile
            const dashboardCards = document.querySelectorAll('.dashboard-card, .card.cta-box');
            dashboardCards.forEach(function(card) {
                if (screenWidth <= 768) {
                    card.style.height = '100px';
                    card.style.padding = '0 16px';
                } else if (screenWidth <= 1200) {
                    card.style.height = '110px';
                    card.style.padding = '0 20px';
                } else {
                    card.style.height = '120px';
                    card.style.padding = '0 24px';
                }
            });
            
            // Adjust footer for mobile
            const footerContent = document.querySelector('.footer-content-fixed');
            if (footerContent && screenWidth <= 768) {
                footerContent.style.flexDirection = 'column';
                footerContent.style.gap = '8px';
                footerContent.style.textAlign = 'center';
            } else if (footerContent) {
                footerContent.style.flexDirection = 'row';
                footerContent.style.gap = '0';
                footerContent.style.textAlign = 'left';
            }
        }
        
        // Initial call
        handleResize();
        
        // Listen for resize events
        window.addEventListener('resize', debounce(handleResize, 250));
    }

    /**
     * Utility: Debounce function
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = function() {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    /**
     * Public API for external usage
     */
    window.DashboardFixes = {
        /**
         * Update progress bar with percentage
         */
        updateProgressBar: function(elementId, percentage) {
            const element = document.getElementById(elementId);
            if (element) {
                const clampedPercentage = Math.min(100, Math.max(0, Math.round(percentage)));
                element.style.width = clampedPercentage + '%';
                element.setAttribute('aria-valuenow', clampedPercentage);
                fixProgressBarText(element);
                
                // Add visual feedback
                element.style.boxShadow = '0 0 10px rgba(102, 126, 234, 0.5)';
                setTimeout(function() {
                    element.style.boxShadow = '';
                }, 1000);
            }
        },
        
        /**
         * Update server statistic with animation
         */
        updateServerStat: function(elementId, value) {
            const element = document.getElementById(elementId);
            if (element) {
                element.style.transform = 'scale(1.05)';
                element.style.transition = 'transform 0.2s ease';
                
                setTimeout(function() {
                    element.textContent = value;
                    element.style.transform = 'scale(1)';
                }, 100);
            }
        },
        
        /**
         * Refresh all charts (useful after AJAX updates)
         */
        refreshCharts: function() {
            initializeChartFixes();
        },
        
        /**
         * Refresh all progress bars
         */
        refreshProgressBars: function() {
            initializeProgressBarFixes();
        },
        
        /**
         * Update dashboard card counter with animation
         */
        updateDashboardCard: function(selector, newValue) {
            const element = document.querySelector(selector);
            if (element) {
                // Add highlight effect
                element.style.transform = 'scale(1.05)';
                element.style.transition = 'transform 0.3s ease';
                element.style.boxShadow = '0 0 10px rgba(102, 126, 234, 0.5)';
                
                setTimeout(function() {
                    element.textContent = typeof newValue === 'number' ? 
                        newValue.toLocaleString() : newValue;
                    element.style.transform = 'scale(1)';
                    element.style.boxShadow = '';
                }, 150);
            }
        }
    };

    // Compatibility with existing code
    window.updateProgressBar = window.DashboardFixes.updateProgressBar;
    window.updateServerStat = window.DashboardFixes.updateServerStat;
    window.updateServerProgressBar = window.DashboardFixes.updateProgressBar;
    window.updateDashboardCard = window.DashboardFixes.updateDashboardCard;

})();