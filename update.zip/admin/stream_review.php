<?php

include 'session.php';
include 'functions.php';

if (B1882Df698b44754()) {
} else {
	B46F5dD76f3c7421();
}

if (isset(XUI::$rRequest['save_changes'])) {
	$a6b40128767dfe4f = array();

	foreach (array_keys(XUI::$rRequest) as $D3fa098be3f297cd) {
		$B211d7401e6242f3 = explode('_', $D3fa098be3f297cd);

		if (!($B211d7401e6242f3[0] == 'modified' && XUI::$rRequest[$D3fa098be3f297cd] == 1)) {
		} else {
			$C3c8913edb801c35 = intval($B211d7401e6242f3[1]);
			$a6b40128767dfe4f[$C3c8913edb801c35] = array();

			foreach (array('name', 'channel_id', 'epg_id') as $e20b41fb3d650793) {
				$a6b40128767dfe4f[$C3c8913edb801c35][$e20b41fb3d650793] = XUI::$rRequest[$e20b41fb3d650793 . '_' . $C3c8913edb801c35];
			}

			foreach (array('bouquets', 'categories') as $e20b41fb3d650793) {
				$a6b40128767dfe4f[$C3c8913edb801c35][$e20b41fb3d650793] = json_decode(XUI::$rRequest[$e20b41fb3d650793 . '_' . $C3c8913edb801c35], true);
			}
		}
	}

	foreach ($a6b40128767dfe4f as $C3c8913edb801c35 => $f523e362fb81d6c8) {
		if (!XUI::$rRequest['save_bouquets']) {
		} else {
			$cf2a0ca10e8fe2aa = array();

			foreach (XUI::$rBouquets as $C52c0b6b0f74407b => $ddf0508b312dbfb8) {
				if (!(in_array($C3c8913edb801c35, $ddf0508b312dbfb8['streams']) || in_array($C3c8913edb801c35, $ddf0508b312dbfb8['channels']))) {
				} else {
					$cf2a0ca10e8fe2aa[] = $C52c0b6b0f74407b;
				}
			}
			$fb5ea0f21131b307 = $ed2502d79a409dc0 = array();

			foreach ($cf2a0ca10e8fe2aa as $C52c0b6b0f74407b) {
				if (in_array($C52c0b6b0f74407b, $f523e362fb81d6c8['bouquets'])) {
				} else {
					D83CFf66bcDBEe05('stream', $C52c0b6b0f74407b, $C3c8913edb801c35);
				}
			}

			foreach ($f523e362fb81d6c8['bouquets'] as $C52c0b6b0f74407b) {
				if (in_array($C52c0b6b0f74407b, $cf2a0ca10e8fe2aa)) {
				} else {
					$ed2502d79a409dc0[] = $C52c0b6b0f74407b;
					d7e7F81f646193B2('stream', $C52c0b6b0f74407b, $C3c8913edb801c35);
				}
			}
		}

		if (XUI::$rRequest['save_epg'] && !empty($f523e362fb81d6c8['channel_id']) && $f523e362fb81d6c8['epg_id'] == 0) {
			$afa7705b805afe9a = 1;
		} else {
			$afa7705b805afe9a = 0;
		}

		if (XUI::$rRequest['save_categories'] && XUI::$rRequest['save_epg']) {
			$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_display_name` = ?, `category_id` = ?, `channel_id` = ?, `epg_id` = ?, `epg_api` = ? WHERE `id` = ?;', $f523e362fb81d6c8['name'], '[' . implode(',', array_map('intval', $f523e362fb81d6c8['categories'])) . ']', ($f523e362fb81d6c8['channel_id'] ?: null), (is_null($f523e362fb81d6c8['epg_id']) ? null : $f523e362fb81d6c8['epg_id']), $afa7705b805afe9a, $C3c8913edb801c35);
		} else {
			if (XUI::$rRequest['save_categories']) {
				$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_display_name` = ?, `category_id` = ? WHERE `id` = ?;', $f523e362fb81d6c8['name'], '[' . implode(',', array_map('intval', $f523e362fb81d6c8['categories'])) . ']', $C3c8913edb801c35);
			} else {
				if (XUI::$rRequest['save_epg']) {
					$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_display_name` = ?, `channel_id` = ?, `epg_id` = ?, `epg_api` = ? WHERE `id` = ?;', $f523e362fb81d6c8['name'], ($f523e362fb81d6c8['channel_id'] ?: null), (is_null($f523e362fb81d6c8['epg_id']) ? null : $f523e362fb81d6c8['epg_id']), $afa7705b805afe9a, $C3c8913edb801c35);
				} else {
					$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_display_name` = ? WHERE `id` = ?;', $f523e362fb81d6c8['name'], $C3c8913edb801c35);
				}
			}
		}
	}
	header('Location: ./streams?status=' . STATUS_SUCCESS);

	exit();
} else {
	if (!isset(XUI::$rRequest['streams'])) {
	} else {
		$A2b85ede89f9df0c = json_decode(XUI::$rRequest['streams'], true);
		$A5dcdeb6ecbbf6bd = cBE87E2A9a996111('live');
		$cb498e4dcaac05cc = D7A15E0C2d9bECE1();
		$a70429ce0b17dfee = array();

		foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
			$f2d9cb45c932b21d = json_decode($ddf0508b312dbfb8['bouquet_channels'], true);

			foreach ($f2d9cb45c932b21d as $F26087d31c2bbe4d) {
				if (!in_array($F26087d31c2bbe4d, $A2b85ede89f9df0c)) {
				} else {
					$a70429ce0b17dfee[$F26087d31c2bbe4d][] = $ddf0508b312dbfb8['id'];
				}
			}
		}
		$Be3590384c940166 = array('categories' => isset(XUI::$rRequest['edit_categories']), 'epg' => isset(XUI::$rRequest['edit_epg']), 'bouquets' => isset(XUI::$rRequest['edit_bouquets']));
		$c29dfa683545802c = array(25, 20, 20);

		if ($Be3590384c940166['categories'] || $Be3590384c940166['bouquets'] || $Be3590384c940166['epg']) {
		} else {
			$c29dfa683545802c = array(90, 0, 0);
		}

		$D19861e3f008e509 = array();

		if (0 >= count($A2b85ede89f9df0c)) {
		} else {
			$Fee0d5a474c96306->query('SELECT * FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $A2b85ede89f9df0c)) . ');');

			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$D19861e3f008e509[] = array('id' => $C740da31596f24ef['id'], 'channel_id' => ($C740da31596f24ef['channel_id'] ?: ''), 'epg_id' => ($C740da31596f24ef['epg_id'] ?: ''), 'title' => ($C740da31596f24ef['stream_display_name'] ?: ''), 'category' => json_decode($C740da31596f24ef['category_id'], true), 'bouquets' => ($a70429ce0b17dfee[$C740da31596f24ef['id']] ?: array()));
			}
		}

		if (count($D19861e3f008e509) != 0) {
		} else {
			$B4a5f8dc1f8d260c = STATUS_NO_SOURCES;
			$D19861e3f008e509 = null;
		}
	}

	$bcf587bb39f95fd5 = 'Review';
	include 'header.php';
	echo '<div class="wrapper';
	echo($D19861e3f008e509 ? '' : ' boxed-layout-ext');
	echo '"';

	if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	} else {
		echo ' style="display: none;"';
	}

	echo '>' . "\n" . '    <div class="container-fluid">' . "\n" . '        <form action="./stream_review" method="POST" id="stream_form" data-parsley-validate="">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n" . '                    <div class="page-title-right">' . "\n" . '                        ';
	include 'topbar.php';
	echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Mass Edit & Review <small id="selected_count"></small></h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

	if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_NO_SOURCES)) {
	} else {
		echo '                <div class="alert alert-danger alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    No streams were selected for review.' . "\n" . '                </div>' . "\n" . '                ';
	}

	echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n" . '                        ';

	if (isset($D19861e3f008e509)) {
		echo '                        <input type="hidden" name="save_changes" value="1" />' . "\n" . '                        <input type="hidden" name="save_categories" value="';
		echo intval($Be3590384c940166['categories']);
		echo '" />' . "\n" . '                        <input type="hidden" name="save_bouquets" value="';
		echo intval($Be3590384c940166['bouquets']);
		echo '" />' . "\n" . '                        <input type="hidden" name="save_epg" value="';
		echo intval($Be3590384c940166['epg']);
		echo '" />' . "\n" . '                        ';

		foreach ($D19861e3f008e509 as $f523e362fb81d6c8) {
			echo '<input type="hidden" name="modified_' . $f523e362fb81d6c8['id'] . '" id="modified_' . $f523e362fb81d6c8['id'] . '" value="0" />';
			echo '<input type="hidden" name="name_' . $f523e362fb81d6c8['id'] . '" id="name_s_' . $f523e362fb81d6c8['id'] . '" value="' . htmlentities($f523e362fb81d6c8['title']) . '" />';

			if (!$Be3590384c940166['bouquets']) {
			} else {
				echo '<input type="hidden" name="bouquets_' . $f523e362fb81d6c8['id'] . '" id="bouquets_s_' . $f523e362fb81d6c8['id'] . '" value="' . htmlentities('[' . implode(',', $f523e362fb81d6c8['bouquets']) . ']') . '" />';
			}

			if (!$Be3590384c940166['categories']) {
			} else {
				echo '<input type="hidden" name="categories_' . $f523e362fb81d6c8['id'] . '" id="categories_s_' . $f523e362fb81d6c8['id'] . '" value="' . htmlentities('[' . implode(',', $f523e362fb81d6c8['category']) . ']') . '" />';
			}

			if (!$Be3590384c940166['epg']) {
			} else {
				echo '<input type="hidden" name="channel_id_' . $f523e362fb81d6c8['id'] . '" id="channel_id_s_' . $f523e362fb81d6c8['id'] . '" value="' . htmlentities($f523e362fb81d6c8['channel_id']) . '" />';
				echo '<input type="hidden" name="epg_id_' . $f523e362fb81d6c8['id'] . '" id="epg_id_s_' . $f523e362fb81d6c8['id'] . '" value="' . htmlentities($f523e362fb81d6c8['epg_id']) . '" />';
				echo '<input type="hidden" name="epg_type_' . $f523e362fb81d6c8['id'] . '" id="epg_type_s_' . $f523e362fb81d6c8['id'] . '" value="0" />';
			}
		}
		echo '                        <div class="row">' . "\n" . '                            <div class="col-12">' . "\n" . '                                <table id="datatable" class="table table-striped table-borderless dt-responsive nowrap" data-count="';
		echo count($D19861e3f008e509);
		echo '">' . "\n" . '                                    <thead>' . "\n" . '                                        <tr>' . "\n" . '                                            <th width="10%" class="text-center">ID</th>' . "\n" . '                                            <th width="';
		echo $c29dfa683545802c[0];
		echo '%">Stream Name</th>' . "\n" . '                                            ';

		if (!$Be3590384c940166['categories']) {
		} else {
			echo '                                            <th width="';
			echo $c29dfa683545802c[1];
			echo '%">Categories</th>' . "\n" . '                                            ';
		}

		if (!$Be3590384c940166['bouquets']) {
		} else {
			echo '                                            <th width="';
			echo $c29dfa683545802c[2];
			echo '%">Bouquets</th>' . "\n" . '                                            ';
		}

		if (!$Be3590384c940166['epg']) {
		} else {
			echo '                                            <th>EPG Search</th>' . "\n" . '                                            <th class="text-center">Language</th>' . "\n" . '                                            <th></th>' . "\n" . '                                            ';
		}

		echo '                                        </tr>' . "\n" . '                                    </thead>' . "\n" . '                                    <tbody>' . "\n" . '                                        ';

		foreach ($D19861e3f008e509 as $f523e362fb81d6c8) {
			echo '                                        <tr id="stream_';
			echo $f523e362fb81d6c8['id'];
			echo '" data-id="';
			echo $f523e362fb81d6c8['id'];
			echo '">' . "\n" . '                                            <td class="text-center">';
			echo $f523e362fb81d6c8['id'];
			echo '</td>' . "\n" . '                                            <td>' . "\n" . '                                                <div class="input-group">' . "\n" . '                                                    <input type="text" class="form-control name_input" id="name_';
			echo $f523e362fb81d6c8['id'];
			echo '" value="';
			echo htmlspecialchars($f523e362fb81d6c8['title']);
			echo '" data-id="';
			echo $f523e362fb81d6c8['id'];
			echo '">' . "\n" . '                                                    ';

			if (!$Be3590384c940166['epg']) {
			} else {
				echo '                                                    <div class="input-group-append">' . "\n" . '                                                        <a href="javascript: void(0);" onClick="scanEPG(';
				echo $f523e362fb81d6c8['id'];
				echo ');" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-magnify text-white"></i></a>' . "\n" . '                                                    </div>' . "\n" . '                                                    ';
			}

			echo '                                                </div>' . "\n" . '                                            </td>' . "\n" . '                                            ';

			if (!$Be3590384c940166['categories']) {
			} else {
				echo '                                            <td>' . "\n" . '                                                <select id="category_id_';
				echo $f523e362fb81d6c8['id'];
				echo '" class="form-control select2-multiple category_id" data-id="';
				echo $f523e362fb81d6c8['id'];
				echo '" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n" . '                                                    ';

				foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
					echo '                                                    <option ';

					if (!in_array($A1925ae53e9307eb['id'], $f523e362fb81d6c8['category'])) {
					} else {
						echo 'selected ';
					}

					echo 'value="';
					echo $A1925ae53e9307eb['id'];
					echo '">';
					echo $A1925ae53e9307eb['category_name'];
					echo '</option>' . "\n" . '                                                    ';
				}
				echo '                                                </select>' . "\n" . '                                            </td>' . "\n" . '                                            ';
			}

			if (!$Be3590384c940166['bouquets']) {
			} else {
				echo '                                            <td>' . "\n" . '                                                <select id="bouquets_';
				echo $f523e362fb81d6c8['id'];
				echo '" data-id="';
				echo $f523e362fb81d6c8['id'];
				echo '" class="form-control select2-multiple bouquet" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n" . '                                                    ';

				foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
					echo '                                                    <option ';

					if (!in_array($ddf0508b312dbfb8['id'], $f523e362fb81d6c8['bouquets'])) {
					} else {
						echo 'selected ';
					}

					echo 'value="';
					echo $ddf0508b312dbfb8['id'];
					echo '">';
					echo $ddf0508b312dbfb8['bouquet_name'];
					echo '</option>' . "\n" . '                                                    ';
				}
				echo '                                                </select>' . "\n" . '                                            </td>' . "\n" . '                                            ';
			}

			if (!$Be3590384c940166['epg']) {
			} else {
				echo '                                            <td>' . "\n" . '                                                <select id="epg_api_';
				echo $f523e362fb81d6c8['id'];
				echo '" data-id="';
				echo $f523e362fb81d6c8['id'];
				echo '" class="form-control epg_api" data-toggle="select2"></select>' . "\n" . '                                            </td>' . "\n" . '                                            <td style="width: 80px;">' . "\n" . '                                                <input type="text" class="form-control text-center" id="epg_lang_';
				echo $f523e362fb81d6c8['id'];
				echo '" readonly value=""></input>' . "\n" . '                                            </td>' . "\n" . '                                            <td class="text-center">' . "\n" . '                                                <button onClick="clearEPG(this);" id="clear_epg_';
				echo $f523e362fb81d6c8['id'];
				echo '" data-id="';
				echo $f523e362fb81d6c8['id'];
				echo '" type="button" title="Clear EPG" class="tooltip btn btn-secondary btn-xs waves-effect waves-light"><i class="text-white fas fa-times"></i></button>' . "\n" . '                                                <button onClick="viewEPG(this);" id="view_epg_';
				echo $f523e362fb81d6c8['id'];
				echo '" data-id="';
				echo $f523e362fb81d6c8['id'];
				echo '" type="button" title="View EPG API" class="tooltip btn btn-secondary btn-xs waves-effect waves-light"><i class="text-white far fa-circle"></i></button>' . "\n" . '                                            </td>' . "\n" . '                                            ';
			}

			echo '                                        </tr>' . "\n" . '                                        ';
		}
		echo '                                    </tbody>' . "\n" . '                                </table>' . "\n" . '                            </div>' . "\n" . '                        </div> ' . "\n" . '                        ';
	} else {
		echo '                        <input type="hidden" name="streams" id="streams" value="" />' . "\n" . '                        <div id="basicwizard">' . "\n" . '                            <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n" . '                                <li class="nav-item">' . "\n" . '                                    <a href="#stream-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n" . '                                        <i class="mdi mdi-play mr-1"></i>' . "\n" . '                                        <span class="d-none d-sm-inline">Stream Selection</span>' . "\n" . '                                    </a>' . "\n" . '                                </li>' . "\n" . '                            </ul>' . "\n" . '                            <div class="tab-content b-0 mb-0 pt-0">' . "\n" . '                                <div class="tab-pane" id="stream-selection">' . "\n" . '                                    <div class="row" style="margin-bottom: 40px;">' . "\n" . '                                        <label class="col-md-2 col-form-label" for="edit_categories">Edit Categories</label>' . "\n" . '                                        <div class="col-md-2">' . "\n" . '                                            <input name="edit_categories" id="edit_categories" type="checkbox" checked data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                        </div>' . "\n" . '                                        <label class="col-md-2 col-form-label" for="edit_bouquets">Edit Bouquets</label>' . "\n" . '                                        <div class="col-md-2">' . "\n" . '                                            <input name="edit_bouquets" id="edit_bouquets" type="checkbox" checked data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                        </div>' . "\n" . '                                        <label class="col-md-2 col-form-label" for="edit_epg">Edit EPG</label>' . "\n" . '                                        <div class="col-md-2">' . "\n" . '                                            <input name="edit_epg" id="edit_epg" type="checkbox" checked data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                        </div>' . "\n" . '                                    </div>' . "\n" . '                                    <div class="row">' . "\n" . '                                        <div class="col-md-3 col-6">' . "\n" . '                                            <input type="text" class="form-control" id="stream_search" value="" placeholder="Search Streams...">' . "\n" . '                                        </div>' . "\n" . '                                        <div class="col-md-3 col-6">' . "\n" . '                                            <select id="category_search" class="form-control" data-toggle="select2">' . "\n" . '                                                <option value="" selected>All Categories</option>' . "\n" . '                                                ';

		foreach (cbe87e2a9A996111('live') as $A1925ae53e9307eb) {
			echo '                                                <option value="';
			echo intval($A1925ae53e9307eb['id']);
			echo '"';

			if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $A1925ae53e9307eb['id'])) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo htmlspecialchars($A1925ae53e9307eb['category_name']);
			echo '</option>' . "\n" . '                                                ';
		}
		echo '                                            </select>' . "\n" . '                                        </div>' . "\n" . '                                        <div class="col-md-3 col-6">' . "\n" . '                                            <select id="stream_filter" class="form-control" data-toggle="select2">' . "\n" . '                                                <option value="">No Filter</option>' . "\n" . '                                                <option value="1">Online</option>' . "\n" . '                                                <option value="2">Down</option>' . "\n" . '                                                <option value="3">Stopped</option>' . "\n" . '                                                <option value="4">Starting</option>' . "\n" . '                                                <option value="5">On Demand</option>' . "\n" . '                                                <option value="6">Direct</option>' . "\n" . '                                                <option value="7">Timeshift</option>' . "\n" . '                                                <option value="8">Looping</option>' . "\n" . '                                                <option value="9">Has EPG</option>' . "\n" . '                                                <option value="10">No EPG</option>' . "\n" . '                                            </select>' . "\n" . '                                        </div>' . "\n" . '                                        <div class="col-md-2 col-8">' . "\n" . '                                            <select id="show_entries" class="form-control" data-toggle="select2">' . "\n" . '                                                ';

		foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
			echo '                                                <option';

			if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
			} else {
				echo ' selected';
			}

			echo ' value="';
			echo $C9e42207e95f03ed;
			echo '">';
			echo $C9e42207e95f03ed;
			echo '</option>' . "\n" . '                                                ';
		}
		echo '                                            </select>' . "\n" . '                                        </div>' . "\n" . '                                        <div class="col-md-1 col-2">' . "\n" . '                                            <button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleStreams()">' . "\n" . '                                                <i class="mdi mdi-selection"></i>' . "\n" . '                                            </button>' . "\n" . '                                        </div>' . "\n" . '                                        <table id="datatable-mass" class="table table-borderless mb-0">' . "\n" . '                                            <thead class="bg-light">' . "\n" . '                                                <tr>' . "\n" . '                                                    <th class="text-center">ID</th>' . "\n" . '                                                    <th>Stream Name</th>' . "\n" . '                                                    <th>Category</th>' . "\n" . '                                                    <th class="text-center">Status</th>' . "\n" . '                                                </tr>' . "\n" . '                                            </thead>' . "\n" . '                                            <tbody></tbody>' . "\n" . '                                        </table>' . "\n" . '                                    </div>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                        ';
	}

	echo '                    </div> ' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '        </div>' . "\n" . '        </form>' . "\n" . '    </div>' . "\n" . '</div>' . "\n";
	include 'footer.php';
}
