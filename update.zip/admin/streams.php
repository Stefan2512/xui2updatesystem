<?php

include 'session.php';
include 'functions.php';

// Verificare autentificare - numele funcțiilor rămân obfuscate
if (b1882dF698B44754()) {
    // User autentificat
} else {
    b46f5dd76F3c7421(); // Probabil redirect sau exit
}

// Inițializare array-uri pentru codec-uri
$audio_codecs = array();
$video_codecs = array();

// $Fee0d5a474c96306 pare să fie obiectul de database
// Query pentru audio codec-uri distincte
$Fee0d5a474c96306->query('SELECT DISTINCT(`audio_codec`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `audio_codec` IS NOT NULL AND `type` = 1 ORDER BY `audio_codec` ASC;');

foreach ($Fee0d5a474c96306->get_rows() as $row) {
    $audio_codecs[] = $row['audio_codec'];
}

// Query pentru video codec-uri distincte
$Fee0d5a474c96306->query('SELECT DISTINCT(`video_codec`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `video_codec` IS NOT NULL AND `type` = 1 ORDER BY `video_codec` ASC;');

foreach ($Fee0d5a474c96306->get_rows() as $row) {
    $video_codecs[] = $row['video_codec'];
}

$page_title = 'Streams';
include 'header.php';

echo '<div class="wrapper"';

// Verificare dacă este request AJAX
if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
    // Nu este AJAX
} else {
    echo ' style="display: none;"';
}

echo '>' . "\n" . 
'    <div class="container-fluid">' . "\n\t\t" . 
'<div class="row">' . "\n\t\t\t" . 
'<div class="col-12">' . "\n\t\t\t\t" . 
'<div class="page-title-box">' . "\n\t\t\t\t\t" . 
'<div class="page-title-right">' . "\n" . 
'                        ';

include 'topbar.php';

echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . 
'<h4 class="page-title">Streams</h4>' . "\n\t\t\t\t" . 
'</div>' . "\n\t\t\t" . 
'</div>' . "\n\t\t" . 
'</div>' . "\n\t\t" . 
'<div class="row">' . "\n\t\t\t" . 
'<div class="col-12">' . "\n" . 
'                ';

// Afișare mesaj de succes
if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
    // Nu există mesaj de succes
} else {
    echo '                <div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n" . 
    '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . 
    '                        <span aria-hidden="true">&times;</span>' . "\n" . 
    '                    </button>' . "\n" . 
    '                    ';
    echo $_['stream_success']; // Mesaj de succes din array de traduceri
    echo '                </div>' . "\n" . 
    '                ';
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . 
'<div class="card-body" style="overflow-x:auto;">' . "\n" . 
'                        <div id="collapse_filters" class="';

// $F61f585ee1fe12b7 controlează dacă filtrele sunt collapsed
if (!$F61f585ee1fe12b7) {
    // Filtrele sunt expanded
} else {
    echo 'collapse';
}

echo ' form-group row mb-4">' . "\n" . 
'                            <div class="col-md-2">' . "\n" . 
'                                <input type="text" class="form-control" id="stream_search" value="';

// Input pentru căutare streams
if (!isset(XUI::$rRequest['search'])) {
    // Nu există parametru de căutare
} else {
    echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="Search Streams...">' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-2">' . "\n" . 
'                                <select id="stream_server_id" class="form-control" data-toggle="select2">' . "\n" . 
'                                    <option value=""';

if (isset(XUI::$rRequest['server'])) {
    // Există parametru server
} else {
    echo ' selected';
}

echo '>';
echo $_['all_servers']; // Text din array de traduceri
echo '</option>' . "\n" . 
'                                    <option value="-1"';

if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == -1)) {
    // Nu este selectat "No Servers"
} else {
    echo ' selected';
}

echo '>No Servers</option>' . "\n" . 
'                                    ';

// Iterare prin servere - f6Da964066f2F5E4() returnează lista de servere
foreach (f6Da964066f2F5E4() as $server) {
    echo '                                    <option value="';
    echo intval($server['id']);
    echo '"';

    if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $server['id'])) {
        // Serverul nu este selectat
    } else {
        echo ' selected';
    }

    echo '>';
    echo $server['server_name'];
    echo '</option>' . "\n" . 
    '                                    ';
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-2">' . "\n" . 
'                                <select id="stream_category_id" class="form-control" data-toggle="select2">' . "\n" . 
'                                    <option value=""';

if (isset(XUI::$rRequest['category'])) {
    // Există parametru categorie
} else {
    echo ' selected';
}

echo '>';
echo $_['all_categories']; // Text din array de traduceri
echo '</option>' . "\n" . 
'                                    <option value="-1"';

if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == -1)) {
    // Nu este selectat "No Categories"
} else {
    echo ' selected';
}

echo '>No Categories</option>' . "\n" . 
'                                    ';

// Iterare prin categorii - CbE87e2a9a996111('live') returnează categoriile live
foreach (CbE87e2a9a996111('live') as $category) {
    echo '                                    <option value="';
    echo intval($category['id']);
    echo '"';

    if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $category['id'])) {
        // Categoria nu este selectată
    } else {
        echo ' selected';
    }

    echo '>';
    echo $category['category_name'];
    echo '</option>' . "\n" . 
    '                                    ';
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-2">' . "\n" . 
'                                <select id="stream_filter" class="form-control" data-toggle="select2">' . "\n" . 
'                                    <option value=""';

if (isset(XUI::$rRequest['filter'])) {
    // Există parametru filter
} else {
    echo ' selected';
}

echo '>No Filter</option>' . "\n";

// Opțiuni de filtrare pentru status-ul stream-urilor
$filter_options = array(
    1 => 'Online',
    2 => 'Down', 
    3 => 'Stopped',
    4 => 'Starting',
    5 => 'On Demand',
    6 => 'Direct',
    7 => 'Timeshift',
    8 => 'Looping',
    9 => 'Has EPG',
    10 => 'No EPG',
    11 => 'Adaptive Link',
    12 => 'Title Sync',
    13 => 'Transcoding'
);

foreach ($filter_options as $value => $label) {
    echo '                                    <option value="' . $value . '"';
    
    if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == $value)) {
        // Filtrul nu este selectat
    } else {
        echo ' selected';
    }
    
    echo '>' . $label . '</option>' . "\n";
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-1">' . "\n" . 
'                                <select id="stream_audio" class="form-control" data-toggle="select2">' . "\n" . 
'                                    <option value=""';

if (isset(XUI::$rRequest['audio'])) {
    // Există parametru audio
} else {
    echo ' selected';
}

echo '>Audio</option>' . "\n" . 
'                                    <option value="-1"';

if (!(isset(XUI::$rRequest['audio']) && XUI::$rRequest['audio'] == '-1')) {
    // Nu este selectat "None"
} else {
    echo ' selected';
}

echo '>None</option>' . "\n" . 
'                                    ';

// Afișare opțiuni audio codec
foreach ($audio_codecs as $codec) {
    echo '                                    <option value="';
    echo $codec;
    echo '"';

    if (!(isset(XUI::$rRequest['audio']) && XUI::$rRequest['audio'] == $codec)) {
        // Codec-ul nu este selectat
    } else {
        echo ' selected';
    }

    echo '>';
    echo $codec;
    echo '</option>' . "\n" . 
    '                                    ';
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-1">' . "\n" . 
'                                <select id="stream_video" class="form-control" data-toggle="select2">' . "\n" . 
'                                    <option value=""';

if (isset(XUI::$rRequest['video'])) {
    // Există parametru video
} else {
    echo ' selected';
}

echo '>Video</option>' . "\n" . 
'                                    <option value="-1"';

if (!(isset(XUI::$rRequest['video']) && XUI::$rRequest['video'] == '-1')) {
    // Nu este selectat "None"
} else {
    echo ' selected';
}

echo '>None</option>' . "\n" . 
'                                    ';

// Afișare opțiuni video codec
foreach ($video_codecs as $codec) {
    echo '                                    <option value="';
    echo $codec;
    echo '"';

    if (!(isset(XUI::$rRequest['video']) && XUI::$rRequest['video'] == $codec)) {
        // Codec-ul nu este selectat
    } else {
        echo ' selected';
    }

    echo '>';
    echo $codec;
    echo '</option>' . "\n" . 
    '                                    ';
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-1">' . "\n" . 
'                                <select id="stream_resolution" class="form-control" data-toggle="select2">' . "\n" . 
'                                    <option value=""';

if (isset(XUI::$rRequest['resolution'])) {
    // Există parametru rezoluție
} else {
    echo ' selected';
}

echo '>Quality</option>' . "\n" . 
'                                    ';

// Opțiuni de rezoluție predefinite
$resolutions = array(240, 360, 480, 576, 720, 1080, 1440, 2160);
foreach ($resolutions as $resolution) {
    echo '                                    <option value="';
    echo $resolution;
    echo '"';

    if (!(isset(XUI::$rRequest['resolution']) && XUI::$rRequest['resolution'] == $resolution)) {
        // Rezoluția nu este selectată
    } else {
        echo ' selected';
    }

    echo '>';
    echo $resolution;
    echo 'p</option>' . "\n" . 
    '                                    ';
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                            <div class="col-md-1">' . "\n" . 
'                                <select id="stream_show_entries" class="form-control" data-toggle="select2">' . "\n" . 
'                                    ';

// Opțiuni pentru numărul de înregistrări pe pagină
$entries_options = array(10, 25, 50, 250, 500, 1000);
foreach ($entries_options as $entries_count) {
    echo '                                    <option';

    if (isset(XUI::$rRequest['entries'])) {
        if (XUI::$rRequest['entries'] != $entries_count) {
            // Numărul de intrări nu este selectat
        } else {
            echo ' selected';
        }
    } else {
        // Folosește valoarea default din configurație
        if ($F2d4d8f7981ac574['default_entries'] != $entries_count) {
            // Nu este valoarea default
        } else {
            echo ' selected';
        }
    }

    echo ' value="';
    echo $entries_count;
    echo '">';
    echo $entries_count;
    echo '</option>' . "\n" . 
    '                                    ';
}

echo '                                </select>' . "\n" . 
'                            </div>' . "\n" . 
'                        </div>' . "\n\t\t\t\t\t\t" . 
'<table id="datatable-streampage" class="table table-borderless table-striped dt-responsive nowrap font-normal">' . "\n\t\t\t\t\t\t\t" . 
'<thead>' . "\n\t\t\t\t\t\t\t\t" . 
'<tr>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">ID</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">Icon</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th>Name</th>' . "\n" . 
'                                    ';

// Verificare dacă stream-urile sunt grupate
if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
    echo "\t\t\t\t\t\t\t\t\t" . '<th>Servers</th>' . "\n" . 
    '                                    ';
} else {
    echo '                                    <th>Source</th>' . "\n\t\t\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">Clients</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">Uptime</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">Player</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">EPG</th>' . "\n\t\t\t\t\t\t\t\t\t" . 
'<th class="text-center">Stream Info</th>' . "\n\t\t\t\t\t\t\t\t" . 
'</tr>' . "\n\t\t\t\t\t\t\t" . 
'</thead>' . "\n\t\t\t\t\t\t\t" . 
'<tbody></tbody>' . "\n\t\t\t\t\t\t" . 
'</table>' . "\n\t\t\t\t\t" . 
'</div>' . "\n\t\t\t\t" . 
'</div>' . "\n\t\t\t" . 
'</div>' . "\n\t\t" . 
'</div>' . "\n\t" . 
'</div>' . "\n" . 
'</div>' . "\n";

include 'footer.php';

?>