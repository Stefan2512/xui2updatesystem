<?php

include 'session.php';
include 'functions.php';
$bcf587bb39f95fd5 = 'On-Demand Scanner';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n" . '                    <div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">On-Demand Scanner</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>       ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t";

if (XUI::$rSettings['on_demand_checker']) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-info alert-dismissible fade show" role="alert">' . "\r\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\r\n" . '                        <span aria-hidden="true">×</span>' . "\r\n" . '                    </button>' . "\r\n" . "                    On-Demand Scanner isn't active, please enable it in the <a href=\"settings\">Settings</a> menu to continue." . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="search" value="" placeholder="Search Streams...">' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n" . '                                <select id="server" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value="" selected>All Servers</option>' . "\r\n" . '                                    ';

foreach (F6dA964066f2F5e4() as $e81220b4451f37c9) {
	echo '                                    <option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\r\n" . '                                    ';
}
echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n" . '                                <select id="category" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value="" selected>All Categories</option>' . "\r\n" . '                                    ';

foreach (CbE87E2a9a996111('live') as $A1925ae53e9307eb) {
	echo '                                    <option value="';
	echo $A1925ae53e9307eb['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $A1925ae53e9307eb['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\r\n" . '                                    ';
}
echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n" . '                                <select id="filter" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['filter'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['no_filter'];
echo '</option>' . "\r\n" . '                                    <option value="1"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 1)) {
} else {
	echo ' selected';
}

echo '>Ready</option>' . "\r\n" . '                                    <option value="2"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 2)) {
} else {
	echo ' selected';
}

echo '>Down</option>' . "\r\n" . '                                    <option value="3"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 3)) {
} else {
	echo ' selected';
}

echo '>Not Scanned</option>' . "\r\n" . '                                </select>' . "\r\n" . '                            </div>' . "\r\n\t\t\t\t\t\t\t" . '<label class="col-md-1 col-form-label text-center" for="show_entries">Show</label>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-1">' . "\r\n\t\t\t\t\t\t\t\t" . '<select id="show_entries" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\r\n" . '                                    <th class="text-center">Icon</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Stream</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Server</th>' . "\r\n" . '                                    <th class="text-center">Status</th>' . "\r\n" . '                                    <th class="text-center">Response</th>' . "\r\n" . '                                    <th class="text-center">Stream Info</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Last Scanned</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n" . '    </div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
