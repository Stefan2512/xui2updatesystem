<?php

if (Xui\Functions::verifyLicense()) {
	header('Location: ./login');

	exit();
}

header('Location: ./license');

exit();
