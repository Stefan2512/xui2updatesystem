<?php

include 'session.php';
include 'functions.php';

if (b1882DF698B44754()) {
} else {
	B46F5Dd76f3C7421();
}

$c43b488500f8fab7 = $a8bb73cba48fb7f6 = array();
$f523e362fb81d6c8 = $D5570348fee60119 = null;

if (isset(XUI::$rRequest['id'])) {
	$f523e362fb81d6c8 = e5ECEb32f67d5e70(XUI::$rRequest['id']);
	$D5570348fee60119 = XUI::getProgramme(XUI::$rRequest['id'], XUI::$rRequest['programme']);

	if ($f523e362fb81d6c8 && $f523e362fb81d6c8['type'] == 1 && $D5570348fee60119) {
	} else {
		b46f5dd76F3c7421();
	}
} else {
	if (isset(XUI::$rRequest['archive'])) {
		$f665b8e041442d05 = json_decode(base64_decode(XUI::$rRequest['archive']), true);
		$f523e362fb81d6c8 = E5eceB32F67D5E70($f665b8e041442d05['stream_id']);
		$D5570348fee60119 = array('start' => $f665b8e041442d05['start'], 'end' => $f665b8e041442d05['end'], 'title' => $f665b8e041442d05['title'], 'description' => $f665b8e041442d05['description'], 'archive' => true);

		if ($f523e362fb81d6c8 && $f523e362fb81d6c8['type'] == 1 && $D5570348fee60119) {
		} else {
			b46F5dD76F3c7421();
		}
	} else {
		if (!isset(XUI::$rRequest['stream_id'])) {
		} else {
			$f523e362fb81d6c8 = E5ECeB32f67d5E70(XUI::$rRequest['stream_id']);
			$D5570348fee60119 = array('start' => strtotime(XUI::$rRequest['start_date']), 'end' => strtotime(XUI::$rRequest['start_date']) + intval(XUI::$rRequest['duration']) * 60, 'title' => '', 'description' => '');

			if (!(!$f523e362fb81d6c8 || $f523e362fb81d6c8['type'] != 1 || !$D5570348fee60119 || $D5570348fee60119['end'] < time())) {
			} else {
				header('Location: record');
			}
		}
	}
}

if (!$f523e362fb81d6c8) {
} else {
	$aa2e54fde620d6b3 = null;
	$Fee0d5a474c96306->query('SELECT `server_id`, `bitrate` FROM `streams_servers` WHERE `stream_id` = ?;', $f523e362fb81d6c8['id']);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$c43b488500f8fab7[] = $C740da31596f24ef['server_id'];

		if (!(!$aa2e54fde620d6b3 && $C740da31596f24ef['bitrate'] || $C740da31596f24ef['bitrate'] && $aa2e54fde620d6b3 < $C740da31596f24ef['bitrate'])) {
		} else {
			$aa2e54fde620d6b3 = $C740da31596f24ef['bitrate'];
		}
	}
}

$bcf587bb39f95fd5 = 'Record';
include 'header.php';
echo '<div class="wrapper boxed-layout"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Record an Event</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t\t" . '<div class="row">' . "\n" . '            <div class="col-xl-12">' . "\n" . '                <div class="card">' . "\n" . '                    <div class="card-body">' . "\n" . '                        ';

if ($f523e362fb81d6c8) {
} else {
	echo '<form action="record" method="POST" data-parsley-validate="">';
}

echo '                        <table class="table table-borderless mb-0">' . "\n" . '                            <thead class="thead-light">' . "\n" . '                                <tr>' . "\n" . '                                    <th>Channel</th>' . "\n" . '                                    <th class="text-center">Start</th>' . "\n" . '                                    <th class="text-center">';
echo($f523e362fb81d6c8 ? 'Finish' : 'Minutes');
echo '</th>' . "\n" . '                                </tr>' . "\n" . '                            </thead>' . "\n" . '                            <tbody>' . "\n" . '                                <tr>' . "\n" . '                                    ';

if ($f523e362fb81d6c8) {
	echo '                                    <td>';
	echo $f523e362fb81d6c8['stream_display_name'];
	echo '</td>' . "\n" . '                                    <td class="text-center">';
	echo date(XUI::$rSettings['date_format'], $D5570348fee60119['start']);
	echo '<br/>';
	echo date('H:i', $D5570348fee60119['start']);
	echo '</td>' . "\n" . '                                    <td class="text-center">';
	echo date(XUI::$rSettings['date_format'], $D5570348fee60119['end']);
	echo '<br/>';
	echo date('H:i', $D5570348fee60119['end']);
	echo '</td>' . "\n" . '                                    ';
} else {
	echo '                                    <td><select id="stream_id" name="stream_id" class="form-control" data-toggle="select2"></select></td>' . "\n" . '                                    <td style="max-width:120px;" class="text-center"><input type="text" class="form-control text-center date" id="start_date" name="start_date" value="" data-toggle="date-picker" data-single-date-picker="true"></td>' . "\n" . '                                    <td style="max-width:40px;" class="text-center"><input type="text" class="form-control text-center" id="duration" name="duration" value="0"></td>' . "\n" . '                                    ';
}

echo '                                </tr>' . "\n" . '                            </tbody>' . "\n" . '                        </table>' . "\n" . '                        ';

if ($f523e362fb81d6c8) {
} else {
	echo '                        <ul class="list-inline wizard mb-0">' . "\n" . '                            <li class="list-inline-item float-right">' . "\n" . '                                <input type="submit" class="btn btn-primary" value="Continue" />' . "\n" . '                            </li>' . "\n" . '                        </ul>' . "\n" . '                        </form>' . "\n" . '                        ';
}

echo '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            ';

if (!$f523e362fb81d6c8) {
} else {
	echo "\t\t\t" . '<div class="col-xl-12">' . "\n" . '                ';

	if ($D5570348fee60119['archive'] || $D5570348fee60119['start'] > time()) {
	} else {
		echo '                <div class="alert alert-warning text-center" role="alert">' . "\n" . '                    The programme you are intending to record has already started!' . "\n" . '                </div>' . "\n" . '                ';
	}

	echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t" . '<form';

	if (!isset(XUI::$rRequest['import'])) {
	} else {
		echo ' enctype="multipart/form-data"';
	}

	echo ' action="#" method="POST" data-parsley-validate="">' . "\n\t\t\t\t\t\t\t" . '<input type="hidden" name="stream_id" value="';
	echo intval($f523e362fb81d6c8['id']);
	echo '" />' . "\n" . '                            <input type="hidden" name="start" value="';
	echo intval($D5570348fee60119['start']);
	echo '" />' . "\n" . '                            <input type="hidden" name="end" value="';
	echo intval($D5570348fee60119['end']);
	echo '" />' . "\n" . '                            <input type="hidden" name="archive" value="';
	echo(isset($D5570348fee60119['archive']) ? 1 : 0);
	echo '" />' . "\n\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#stream-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account-card-details-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
	echo $_['details'];
	echo '</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                </ul>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="stream-details">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="title">Event Title</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-8">' . "\n" . '                                                        <input type="text" class="form-control" id="title" name="title" value="';
	echo str_replace('"', '&quot;', $D5570348fee60119['title']);
	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="description">Event Description</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<textarea rows="6" class="form-control" id="description" name="description">';
	echo htmlspecialchars($D5570348fee60119['description']);
	echo '</textarea>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="stream_icon">';
	echo $_['poster_url'];
	echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-8 input-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="stream_icon" name="stream_icon" value="">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="input-group-append">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript:void(0)" onClick="openImage(this)" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-eye"></i></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="category_id">Categories</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-8">' . "\n" . '                                                        <select name="category_id[]" id="category_id" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	foreach (cBE87e2A9a996111('movie') as $A1925ae53e9307eb) {
		echo '                                                            <option value="';
		echo $A1925ae53e9307eb['id'];
		echo '">';
		echo $A1925ae53e9307eb['category_name'];
		echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="bouquets">';

	if (!XUI::$rRequest['import']) {
	} else {
		echo 'Fallback ';
	}

	echo $_['bouquets'];
	echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="bouquets[]" id="bouquets" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="';
	echo $_['choose'];
	echo '...">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	foreach (D7A15e0c2D9BEcE1() as $ddf0508b312dbfb8) {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
		echo $ddf0508b312dbfb8['id'];
		echo '">';
		echo $ddf0508b312dbfb8['bouquet_name'];
		echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="source_id">Recording Server</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="source_id" id="source_id" class="form-control" data-toggle="select2">' . "\n" . '                                                            ';

	if ($D5570348fee60119['archive']) {
		echo '                                                                <option selected value="';
		echo XUI::$rServers[$f523e362fb81d6c8['tv_archive_server_id']]['id'];
		echo '">';
		echo XUI::$rServers[$f523e362fb81d6c8['tv_archive_server_id']]['server_name'];
		echo ' - ';
		echo XUI::$rServers[$f523e362fb81d6c8['tv_archive_server_id']]['server_ip'];
		echo '</option>' . "\n" . '                                                            ';
	} else {
		foreach ($c43b488500f8fab7 as $d58b4f8653a391d8) {
			echo '                                                                <option value="';
			echo XUI::$rServers[$d58b4f8653a391d8]['id'];
			echo '">';
			echo XUI::$rServers[$d58b4f8653a391d8]['server_name'];
			echo ' - ';
			echo XUI::$rServers[$d58b4f8653a391d8]['server_ip'];
			echo '</option>' . "\n" . '                                                                ';
		}
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="submit" class="btn btn-primary" value="Schedule" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div> ' . "\n" . '            ';
}

echo "\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
