<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
echo 'Test PHP: OK<br>';
try {
    $db = new PDO('mysql:host=127.0.0.1;dbname=xui', '6JHzUDgnGG3hr9jXJFxxEgD2R7HCueDT', 'password_here');
    echo 'Database: OK<br>';
} catch(Exception $e) {
    echo 'Database Error: ' . $e->getMessage();
}
?>
