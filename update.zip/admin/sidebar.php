<?php

if (!defined('XUI_LOADED')) {
    exit();
}

$sidebar_menu = array(
    'dashboard' => array('Dashboard' => array('dashboard', 'dashboard')),
    'streams' => array(
        'Manage Streams' => array('streams', 'streams'),
        'Add Stream' => array('stream', 'add_stream'),
        'Categories' => array('stream_categories', 'categories'),
        'Stream Tools' => array('stream_tools', 'stream_tools'),
        'Stream Error Logs' => array('stream_errors', 'stream_errors')
    ),
    'movies' => array(
        'Manage Movies' => array('movies', 'movies'),
        'Add Movie' => array('movie', 'add_movie'),
        'Categories' => array('stream_categories', 'categories'),
        'Movie Tools' => array('movie_tools', 'movie_tools')
    ),
    'users' => array(
        'Manage Users' => array('users', 'mng_regusers'),
        'Add User' => array('user', 'add_reguser'),
        'Groups' => array('groups', 'mng_groups'),
        'Packages' => array('packages', 'mng_packages')
    ),
    'settings' => array(
        'General Settings' => array('settings', 'settings'),
        'Backup Settings' => array('backups', 'database'),
        'Cache Settings' => array('cache', 'backups')
    )
);

function renderSidebar($menu)
{
    echo '<ul class="sidebar-menu">';
    foreach ($menu as $key => $items) {
        echo '<li class="menu-header">' . ucfirst($key) . '</li>';
        foreach ($items as $name => $data) {
            echo '<li><a href="' . $data[0] . '">' . $name . '</a></li>';
        }
    }
    echo '</ul>';
}

?>
