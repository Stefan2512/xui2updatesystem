<?php

include 'session.php';
include 'functions.php';

if (B1882df698B44754()) {
} else {
	B46f5DD76f3c7421();
}

$cb498e4dcaac05cc = d7a15e0C2D9BECe1();
$bcf587bb39f95fd5 = 'Watch Settings';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo '                    </div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">Folder Watch Settings</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-xl-12">' . "\r\n\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\r\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\r\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\r\n\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t" . 'Watch settings sucessfully updated!' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body">' . "\r\n\t\t\t\t\t\t" . '<form action="#" method="POST">' . "\r\n\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\r\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#setup" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account-card-details-outline mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Setup</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#categories" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-movie mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Movie Categories</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#categories-tv" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-youtube-tv mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">TV Categories</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="setup">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="scan_seconds">Scan Frequency <i title="Scan a folder every X seconds." class="tooltip text-secondary far fa-circle"></i></label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="scan_seconds" name="scan_seconds" value="';
echo htmlspecialchars($F2d4d8f7981ac574['scan_seconds']);
echo '" required data-parsley-trigger="change">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="percentage_match">Match Percentage <i title="TMDb match tolerance. Will not accept match if below this percentage threshold." class="tooltip text-secondary far fa-circle"></i></label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="percentage_match" name="percentage_match" value="';
echo htmlspecialchars($F2d4d8f7981ac574['percentage_match']);
echo '" required data-parsley-trigger="change">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="thread_count">Thread Count <i title="Number of threads to run simultaneously." class="tooltip text-secondary far fa-circle"></i></label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="thread_count" name="thread_count" value="';
echo htmlspecialchars($F2d4d8f7981ac574['thread_count']);
echo '" required data-parsley-trigger="change">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n" . '                                                    <label class="col-md-4 col-form-label" for="max_genres">Max Categories & Bouquets <i title="Maximum number of TMDb genres to convert into categories and bouquets. Enter 0 for unlimited." class="tooltip text-secondary far fa-circle"></i></label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="max_genres" name="max_genres" value="';
echo htmlspecialchars($F2d4d8f7981ac574['max_genres']);
echo '" required data-parsley-trigger="change">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n" . '                                                <div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="max_items">Max Items <i title="Maximum number of items to add per folder per scan. Set this to 0 to scan everything." class="tooltip text-secondary far fa-circle"></i></label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="max_items" name="max_items" value="';
echo htmlspecialchars($F2d4d8f7981ac574['max_items']);
echo '" required data-parsley-trigger="change">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n" . '                                                </div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="alternative_titles">Check Alternative Titles <i title="If a title partially matches a TMDb result, check the alternative titles of that Movie or TV Show to see if any of those match the title." class="tooltip text-secondary far fa-circle"></i></label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="alternative_titles" id="alternative_titles" type="checkbox"';

if ($F2d4d8f7981ac574['alternative_titles'] != 1) {
} else {
	echo ' checked ';
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<label class=\"col-md-4 col-form-label\" for=\"fallback_parser\">Use Fallback Parser <i title=\"If no match is found using your preferred title parser, fallback to the parser you didn't select and run again.\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="fallback_parser" id="fallback_parser" type="checkbox"';

if ($F2d4d8f7981ac574['fallback_parser'] != 1) {
} else {
	echo ' checked ';
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_settings" type="submit" class="btn btn-primary" value="Save Changes" />' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="categories">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="sub-header">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'Select a Category and / or Bouquet to apply to each Genre.' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</p>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t";
$Fee0d5a474c96306->query('SELECT * FROM `watch_categories` WHERE `type` = 1 ORDER BY `genre` ASC;');

if (0 >= $Fee0d5a474c96306->num_rows()) {
} else {
	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-2 col-form-label" for="genre_';
		echo $C740da31596f24ef['genre_id'];
		echo '">';
		echo $C740da31596f24ef['genre'];
		echo '</label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="genre_';
		echo $C740da31596f24ef['genre_id'];
		echo '" id="genre_';
		echo $C740da31596f24ef['genre_id'];
		echo '" class="form-control select2" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

		if (intval($C740da31596f24ef['category_id']) != 0) {
		} else {
			echo 'selected ';
		}

		echo 'value="0">Do Not Use</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

		foreach (cBe87e2A9A996111('movie') as $A1925ae53e9307eb) {
			echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

			if (intval($C740da31596f24ef['category_id']) != intval($A1925ae53e9307eb['id'])) {
			} else {
				echo 'selected ';
			}

			echo 'value="';
			echo $A1925ae53e9307eb['id'];
			echo '">';
			echo $A1925ae53e9307eb['category_name'];
			echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-2 col-form-label" for="bouquet_';
		echo $C740da31596f24ef['genre_id'];
		echo '">Bouquets</label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="bouquet_';
		echo $C740da31596f24ef['genre_id'];
		echo '[]" id="bouquet_';
		echo $C740da31596f24ef['genre_id'];
		echo '" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

		foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
			echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

			if (!in_array(intval($ddf0508b312dbfb8['id']), json_decode($C740da31596f24ef['bouquets'], true))) {
			} else {
				echo 'selected ';
			}

			echo 'value="';
			echo $ddf0508b312dbfb8['id'];
			echo '">';
			echo $ddf0508b312dbfb8['bouquet_name'];
			echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t";
	}
}

echo "\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_settings" type="submit" class="btn btn-primary" value="Save Changes" />' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="categories-tv">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="sub-header">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'Select a Category and / or Bouquet to apply to each Genre.' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</p>' . "\r\n" . '                                                ';
$Fee0d5a474c96306->query('SELECT * FROM `watch_categories` WHERE `type` = 2 ORDER BY `genre` ASC;');

if (0 >= $Fee0d5a474c96306->num_rows()) {
} else {
	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-2 col-form-label" for="genretv_';
		echo $C740da31596f24ef['genre_id'];
		echo '">';
		echo $C740da31596f24ef['genre'];
		echo '</label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="genretv_';
		echo $C740da31596f24ef['genre_id'];
		echo '" id="genretv_';
		echo $C740da31596f24ef['genre_id'];
		echo '" class="form-control select2" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

		if (intval($C740da31596f24ef['category_id']) != 0) {
		} else {
			echo 'selected ';
		}

		echo 'value="0">Do Not Use</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

		foreach (CbE87e2A9A996111('series') as $A1925ae53e9307eb) {
			echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

			if (intval($C740da31596f24ef['category_id']) != intval($A1925ae53e9307eb['id'])) {
			} else {
				echo 'selected ';
			}

			echo 'value="';
			echo $A1925ae53e9307eb['id'];
			echo '">';
			echo $A1925ae53e9307eb['category_name'];
			echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-2 col-form-label" for="bouquettv_';
		echo $C740da31596f24ef['genre_id'];
		echo '">Bouquets</label>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-4">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="bouquettv_';
		echo $C740da31596f24ef['genre_id'];
		echo '[]" id="bouquettv_';
		echo $C740da31596f24ef['genre_id'];
		echo '" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

		foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
			echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

			if (!in_array(intval($ddf0508b312dbfb8['id']), json_decode($C740da31596f24ef['bouquets'], true))) {
			} else {
				echo 'selected ';
			}

			echo 'value="';
			echo $ddf0508b312dbfb8['id'];
			echo '">';
			echo $ddf0508b312dbfb8['bouquet_name'];
			echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t";
	}
}

echo "\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_settings" type="submit" class="btn btn-primary" value="Save Changes" />' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t" . '</form>' . "\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div> ' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
