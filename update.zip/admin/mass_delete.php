<?php

include 'session.php';
include 'functions.php';

if (B1882dF698B44754()) {
} else {
	b46f5DD76F3C7421();
}

set_time_limit(0);
ini_set('max_execution_time', 0);
$bcf587bb39f95fd5 = 'Mass Delete';
include 'header.php';
echo '<div class="wrapper boxed-layout-xl"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n" . '                    <div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['mass_delete'];
echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-xl-12">' . "\n\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == 1)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Mass delete has been executed.' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#stream-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-play mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['streams'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#movie-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account-card-details-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['movies'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#radio-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-radio mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['stations'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#episodes-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-folder-open-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['episodes'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#series-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-youtube-tv mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['series'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#line-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-wallet-membership mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['lines'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#user-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Users</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#mag-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-monitor mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">MAGs</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#enigma-selection" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-desktop-tower-monitor mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Enigmas</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="stream-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="stream_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="streams" id="streams" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="stream_search" value="" placeholder="';
echo $_['search_streams'];
echo '...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3 col-6">' . "\n" . '                                                <select id="stream_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                                    <option value="" selected>All Servers</option>' . "\n" . '                                                    <option value="-1">No Servers</option>' . "\n" . '                                                    ';

foreach (F6da964066F2f5e4() as $e81220b4451f37c9) {
	echo '                                                    <option value="';
	echo intval($e81220b4451f37c9['id']);
	echo '">';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                                    ';
}
echo '                                                </select>' . "\n" . '                                            </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="stream_category_search" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>';
echo $_['all_categories'];
echo '</option>' . "\n" . '                                                    <option value="-1">No Categories</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (CBe87E2A9a996111('live') as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $A1925ae53e9307eb['id'];
	echo '">';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n" . '                                                <select id="stream_filter" class="form-control" data-toggle="select2">' . "\n" . '                                                    <option value="">No Filter</option>' . "\n" . '                                                    <option value="1">Online</option>' . "\n" . '                                                    <option value="2">Down</option>' . "\n" . '                                                    <option value="3">Stopped</option>' . "\n" . '                                                    <option value="4">Starting</option>' . "\n" . '                                                    <option value="5">On Demand</option>' . "\n" . '                                                    <option value="6">Direct</option>' . "\n" . '                                                    <option value="7">Timeshift</option>' . "\n" . '                                                    <option value="8">Looping</option>' . "\n" . '                                                    <option value="9">Has EPG</option>' . "\n" . '                                                    <option value="10">No EPG</option>' . "\n" . '                                                    <option value="11">Adaptive Link</option>' . "\n" . '                                                    <option value="12">Title Sync</option>' . "\n" . '                                                    <option value="13">Transcoding</option>' . "\n" . '                                                </select>' . "\n" . '                                            </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleStreams()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md1" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                                        <th class="text-center">Icon</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Stream Name</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Category</th>' . "\n" . '                                                        <th>Server</th>' . "\n" . '                                                        <th class="text-center">Status</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_streams" type="submit" class="btn btn-primary" value="';
echo $_['delete_streams'];
echo '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="movie-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="movie_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="movies" id="movies" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="movie_search" value="" placeholder="';
echo $_['search_movies'];
echo '...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3 col-6">' . "\n" . '                                                <select id="movie_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                                    <option value="" selected>All Servers</option>' . "\n" . '                                                    <option value="-1">No Servers</option>' . "\n" . '                                                    ';

foreach (f6da964066f2f5e4() as $e81220b4451f37c9) {
	echo '                                                    <option value="';
	echo intval($e81220b4451f37c9['id']);
	echo '">';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                                    ';
}
echo '                                                </select>' . "\n" . '                                            </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="movie_category_search" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>';
echo $_['all_categories'];
echo '</option>' . "\n" . '                                                    <option value="-1">No Categories</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (cbE87E2A9a996111('movie') as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $A1925ae53e9307eb['id'];
	echo '">';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="movie_filter" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>';
echo $_['no_filter'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="1">';
echo $_['encoded'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="2">';
echo $_['encoding'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="3">';
echo $_['down'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="4">';
echo $_['ready'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="5">';
echo $_['direct'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="6">';
echo $_['no_tmdb_match'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="movie_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleMovies()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md2" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                                        <th class="text-center">Image</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['name'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['category'];
echo '</th>' . "\n" . '                                                        <th>';
echo $_['servers'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['status'];
echo '</th>' . "\n" . '                                                        <th class="text-center">TMDb</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_movies" type="submit" class="btn btn-primary" value="';
echo $_['delete_movies'];
echo '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                <div class="tab-pane" id="radio-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="radio_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="radios" id="radios" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="radio_search" value="" placeholder="Search Stations...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3 col-6">' . "\n" . '                                                <select id="station_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                                    <option value="" selected>All Servers</option>' . "\n" . '                                                    <option value="-1">No Servers</option>' . "\n" . '                                                    ';

foreach (F6Da964066F2F5e4() as $e81220b4451f37c9) {
	echo '                                                    <option value="';
	echo intval($e81220b4451f37c9['id']);
	echo '">';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                                    ';
}
echo '                                                </select>' . "\n" . '                                            </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="radio_category_search" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>';
echo $_['all_categories'];
echo '</option>' . "\n" . '                                                    <option value="-1">No Categories</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (cBE87e2A9A996111('radio') as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $A1925ae53e9307eb['id'];
	echo '">';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n" . '                                                <select id="radio_filter" class="form-control" data-toggle="select2">' . "\n" . '                                                    <option value="">No Filter</option>' . "\n" . '                                                    <option value="1">Online</option>' . "\n" . '                                                    <option value="2">Down</option>' . "\n" . '                                                    <option value="3">Stopped</option>' . "\n" . '                                                    <option value="4">Starting</option>' . "\n" . '                                                    <option value="5">On Demand</option>' . "\n" . '                                                    <option value="6">Direct</option>' . "\n" . '                                                </select>' . "\n" . '                                            </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="radio_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleRadios()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md6" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                                        <th class="text-center">Icon</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Station Name</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Category</th>' . "\n" . '                                                        <th>';
echo $_['servers'];
echo '</th>' . "\n" . '                                                        <th class="text-center">Status</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_streams" type="submit" class="btn btn-primary" value="Delete Stations" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="series-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="series_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="series" id="series" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-6 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="series_search" value="" placeholder="';
echo $_['search_series'];
echo '...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="series_category_search" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>';
echo $_['all_categories'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="-1">';
echo $_['no_tmdb_match'];
echo '</option>' . "\n" . '                                                    <option value="-2">No Categories</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (CBE87e2a9a996111('series') as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $A1925ae53e9307eb['id'];
	echo '">';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="series_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleSeries()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md4" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                                        <th class="text-center">Image</th>' . "\n" . '                                                        <th>Name</th>' . "\n" . '                                                        <th>Category</th>' . "\n" . '                                                        <th class="text-center">Seasons</th>' . "\n" . '                                                        <th class="text-center">Episodes</th>' . "\n" . '                                                        <th class="text-center">TMDb</th>' . "\n" . '                                                        <th class="text-center">First Aired</th>' . "\n" . '                                                        <th class="text-center">Last Updated</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_series" type="submit" class="btn btn-primary" value="';
echo $_['delete_series'];
echo '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="episodes-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="episodes_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="episodes" id="episodes" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="episode_search" value="" placeholder="';
echo $_['search_episodes'];
echo '...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="episode_series" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="">';
echo $_['all_series'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (DB69D33C1707e715() as $Dec214f3d04ff338) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $Dec214f3d04ff338['id'];
	echo '">';
	echo $Dec214f3d04ff338['title'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3 col-6">' . "\n" . '                                                <select id="episode_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                                    <option value="" selected>All Servers</option>' . "\n" . '                                                    <option value="-1">No Servers</option>' . "\n" . '                                                    ';

foreach (F6DA964066F2f5e4() as $e81220b4451f37c9) {
	echo '                                                    <option value="';
	echo intval($e81220b4451f37c9['id']);
	echo '">';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                                    ';
}
echo '                                                </select>' . "\n" . '                                            </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="episode_filter" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>';
echo $_['no_filter'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="1">';
echo $_['encoded'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="2">';
echo $_['encoding'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="3">';
echo $_['down'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="4">';
echo $_['ready'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="5">';
echo $_['direct'];
echo '</option>' . "\n" . '                                                    <option value="7">Transcoding</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="episode_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleEpisodes()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md5" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n" . '                                                        <th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                                        <th class="text-center">Image</th>' . "\n" . '                                                        <th>';
echo $_['name'];
echo '</th>' . "\n" . '                                                        <th>';
echo $_['server'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['status'];
echo '</th>' . "\n" . '                                                    </tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_episodes" type="submit" class="btn btn-primary" value="';
echo $_['delete_episodes'];
echo '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="line-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="line_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="lines" id="lines" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="line_search" value="" placeholder="Search Lines...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n" . '                                                <select id="reseller_search" class="form-control" data-toggle="select2">' . "\n" . '                                                    ';

if (!(isset(XUI::$rRequest['owner']) && ($Dbb9e190755fc819 = FE76C4bCAF81BaA4(intval(XUI::$rRequest['owner']))))) {
} else {
	echo '                                                    <option value="';
	echo intval($Dbb9e190755fc819['id']);
	echo '" selected="selected">';
	echo $Dbb9e190755fc819['username'];
	echo '</option>' . "\n" . '                                                    ';
}

echo '                                                </select>' . "\n" . '                                            </div>' . "\n" . '                                            <label class="col-md-1 col-form-label text-center" for="reseller_search"><button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="clearOwner();">CLEAR</button></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="line_filter" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>No Filter</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="1">Active</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="2">Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="3">Banned</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="4">Expired</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="5">Trial</option>' . "\n" . '                                                    <option value="6">Restreamer</option>' . "\n" . '                                                    <option value="7">Ministra</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="line_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleLines()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md3" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Username</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Owner</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Status</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Trial</th>' . "\n" . '                                                        <th class="text-center">Restreamer</th>' . "\n" . '                                                        <th></th>' . "\n" . '                                                        <th class="text-center">Connections</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Expiration</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_lines" type="submit" class="btn btn-primary" value="Delete Lines" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                <div class="tab-pane" id="user-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="user_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="users" id="users" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="user_search" value="" placeholder="Search Users...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3">' . "\n" . '                                                <select id="user_reseller_search" class="form-control" data-toggle="select2">' . "\n" . '                                                    ';

if (!(isset(XUI::$rRequest['owner']) && ($Dbb9e190755fc819 = FE76C4Bcaf81BAA4(intval(XUI::$rRequest['owner']))))) {
} else {
	echo '                                                    <option value="';
	echo intval($Dbb9e190755fc819['id']);
	echo '" selected="selected">';
	echo $Dbb9e190755fc819['username'];
	echo '</option>' . "\n" . '                                                    ';
}

echo '                                                </select>' . "\n" . '                                            </div>' . "\n" . '                                            <label class="col-md-1 col-form-label text-center" for="user_reseller_search"><button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="clearUserOwner();">CLEAR</button></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="user_filter" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>No Filter</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="-1">Active</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="-2">Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="user_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleUsers()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md7" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                                        <th>Username</th>' . "\n" . '                                                        <th>Owner</th>' . "\n" . '                                                        <th class="text-center">IP</th>' . "\n" . '                                                        <th class="text-center">Type</th>' . "\n" . '                                                        <th class="text-center">Status</th>' . "\n" . '                                                        <th class="text-center">Credits</th>' . "\n" . '                                                        <th class="text-center">Users</th>' . "\n" . '                                                        <th class="text-center">Last Login</th>' . "\n" . '                                                        <th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_users" type="submit" class="btn btn-primary" value="Delete Users" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                <div class="tab-pane" id="mag-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="mag_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="mags" id="mags" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="mag_search" value="" placeholder="Search Devices...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3">' . "\n" . '                                                <select id="mag_reseller_search" class="form-control" data-toggle="select2">' . "\n" . '                                                    ';

if (!(isset(XUI::$rRequest['owner']) && ($Dbb9e190755fc819 = Fe76C4BCaf81bAA4(intval(XUI::$rRequest['owner']))))) {
} else {
	echo '                                                    <option value="';
	echo intval($Dbb9e190755fc819['id']);
	echo '" selected="selected">';
	echo $Dbb9e190755fc819['username'];
	echo '</option>' . "\n" . '                                                    ';
}

echo '                                                </select>' . "\n" . '                                            </div>' . "\n" . '                                            <label class="col-md-1 col-form-label text-center" for="mag_reseller_search"><button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="clearMagOwner();">CLEAR</button></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="mag_filter" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>No Filter</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="1">Active</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="2">Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="3">Banned</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="4">Expired</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="5">Trial</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="mag_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleMags()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md8" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                                        <th>';
echo $_['username'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['mac_address'];
echo '</th>' . "\n" . '                                                        <th class="text-center">Device</th>' . "\n" . '                                                        <th>';
echo $_['owner'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['status'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['online'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['trial'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['expiration'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_mags" type="submit" class="btn btn-primary" value="Delete Devices" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                <div class="tab-pane" id="enigma-selection">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="enigma_form">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" name="enigmas" id="enigmas" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3 col-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="enigma_search" value="" placeholder="Search Devices...">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            <div class="col-md-3">' . "\n" . '                                                <select id="enigma_reseller_search" class="form-control" data-toggle="select2">' . "\n" . '                                                    ';

if (!(isset(XUI::$rRequest['owner']) && ($Dbb9e190755fc819 = FE76C4BCaf81bAA4(intval(XUI::$rRequest['owner']))))) {
} else {
	echo '                                                    <option value="';
	echo intval($Dbb9e190755fc819['id']);
	echo '" selected="selected">';
	echo $Dbb9e190755fc819['username'];
	echo '</option>' . "\n" . '                                                    ';
}

echo '                                                </select>' . "\n" . '                                            </div>' . "\n" . '                                            <label class="col-md-1 col-form-label text-center" for="enigma_reseller_search"><button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="clearE2Owner();">CLEAR</button></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="enigma_filter" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="" selected>No Filter</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="1">Active</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="2">Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="3">Banned</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="4">Expired</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="5">Trial</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2 col-8">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="enigma_show_entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-1 col-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-info waves-effect waves-light" onClick="toggleEnigmas()" style="width: 100%">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-selection"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-md9" class="table table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead class="bg-light">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                                        <th>';
echo $_['username'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['mac_address'];
echo '</th>' . "\n" . '                                                        <th class="text-center">Device</th>' . "\n" . '                                                        <th>';
echo $_['owner'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['status'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['online'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['trial'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['expiration'];
echo '</th>' . "\n" . '                                                        <th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:20px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_enigmas" type="submit" class="btn btn-primary" value="Delete Devices" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div> ' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
