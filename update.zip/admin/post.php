<?php

$addcc4b6cad6c6a9 = count(get_included_files());
include 'session.php';
include 'functions.php';
$A00aec9eca037ce9 = D451DbaDaA63FD18();
$b6f6dd705fb93d5e = array();

foreach (get_defined_constants(true)['user'] as $D3fa098be3f297cd => $b6842cb20051e925) {
	if (substr($D3fa098be3f297cd, 0, 7) != 'STATUS_') {
	} else {
		$b6f6dd705fb93d5e[intval($b6842cb20051e925)] = $D3fa098be3f297cd;
	}
}

if (1 < $addcc4b6cad6c6a9) {
	echo '<script>' . "\r\n" . 'var rCurrentPage = "';
	echo $A00aec9eca037ce9;
	echo '";' . "\r\n" . 'var rReferer = null;' . "\r\n" . 'var rErrors = ';
	echo json_encode($b6f6dd705fb93d5e);
	echo ';' . "\r\n" . 'function submitForm(rType, rData, rReferer=null) {' . "\r\n" . '    $(".wrapper").fadeOut();' . "\r\n" . '    $("#status").fadeIn();' . "\r\n" . '    if (!rReferer) {' . "\r\n" . '        rReferer = "";' . "\r\n" . '    }' . "\r\n" . '    $.ajax({' . "\r\n" . '        type: "POST",' . "\r\n" . '        url: "post.php?action=" + encodeURIComponent(rType) + "&referer=" + encodeURIComponent(rReferer),' . "\r\n" . '        data: rData,' . "\r\n" . '        processData: false,' . "\r\n" . '        contentType: false,' . "\r\n" . '        success: function(rReturn) {' . "\r\n" . '            try {' . "\r\n" . '                var rJSON = $.parseJSON(rReturn);' . "\r\n" . '            } catch (e) {' . "\r\n" . '                var rJSON = {"status": 0, "result": false};' . "\r\n" . '              }' . "\r\n" . '            callbackForm(rJSON);' . "\r\n" . '        }' . "\r\n" . '    });' . "\r\n" . '}' . "\r\n" . 'function callbackForm(rData) {' . "\r\n" . '    if (rData.location) {' . "\r\n\t\t" . 'if (self !== top) {' . "\r\n\t\t\t" . 'parent.closeEditModal();' . "\r\n\t\t\t" . 'parent.showSuccess("Item has been saved.");' . "\r\n\t\t" . '} else if (rData.reload) {' . "\r\n" . '            window.location.href = rData.location;' . "\r\n" . '        } else {' . "\r\n" . '            navigate(rData.location);' . "\r\n" . '        }' . "\r\n" . '    } else {' . "\r\n" . '        $(".wrapper").fadeIn();' . "\r\n" . '        $("#status").fadeOut();' . "\r\n" . "        \$(':input[type=\"submit\"]').prop('disabled', false);" . "\r\n\r\n" . '        if (window.rErrors[rData.status] == "STATUS_INVALID_INPUT") {' . "\r\n" . '            showError("Required entry fields have not been populated. Please check the form.");' . "\r\n" . '            return;' . "\r\n" . '        }' . "\r\n\r\n" . '        switch (window.rCurrentPage) {' . "\r\n" . '            case "record":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_NO_TITLE":' . "\r\n" . '                        showError("Please enter a title for the recorded event.");' . "\r\n" . '                        break;' . "\r\n" . '                    ' . "\r\n" . '                    case "STATUS_NO_SOURCE":' . "\r\n" . '                        showError("Please select a source server to record the event from.");' . "\r\n" . '                        break;' . "\r\n" . '                    ' . "\r\n" . '                    case "STATUS_NO_DESTINATION":' . "\r\n" . '                        showError("Please select a destination server to record the event to.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "quick_tools":' . "\r\n" . '                showSuccess("Quick tool was successfully executed.");' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "code":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_CODE_LENGTH":' . "\r\n" . '                        showError("Your access code needs to be at least 8 characters long.");' . "\r\n" . '                        break;' . "\r\n" . '                    ' . "\r\n" . '                    case "STATUS_INVALID_CODE":' . "\r\n" . '                        showError("Please enter an access code.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_RESERVED_CODE":' . "\r\n" . '                        showError("Sorry, this code is reserved for system functions.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_CODE":' . "\r\n" . '                        showError("This access code already exists, please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n" . '            ' . "\r\n" . '            case "hmac":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_NO_DESCRIPTION":' . "\r\n" . '                        showError("Please enter a description.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_HMAC":' . "\r\n" . '                        showError("This HMAC Key already exists, please use another.");' . "\r\n" . '                        break;' . "\r\n" . '                    ' . "\r\n" . '                    case "STATUS_NO_KEY":' . "\r\n" . '                        showError("Please generate a key.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "edit_profile":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_EMAIL":' . "\r\n" . '                        showError("Please enter a valid email address.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "ip":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_IP":' . "\r\n" . '                        showError("Please enter a valid IP address / CIDR.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n\t\t\t" . 'case "user":' . "\r\n\t\t\t\t" . 'switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_GROUP":' . "\r\n" . '                        showError("Please select a member group.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_USERNAME":' . "\r\n" . '                        showError("The username you selected already exists. Please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n" . '            ' . "\r\n" . '            case "provider":' . "\r\n\t\t\t\t" . 'switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_EXISTS_IP":' . "\r\n" . '                        showError("This provider is already being tracked on the system.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "created_channel":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_NO_SOURCES":' . "\r\n" . '                        showError("Please select at least one source for your channel.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "group":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_NAME":' . "\r\n" . '                        showError("This group name is already in use. Please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "isp":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_NAME":' . "\r\n" . '                        showError("This ISP has already been blocked.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "package":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_NAME":' . "\r\n" . '                        showError("This package name is already in use. Please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "mag":' . "\r\n" . '            case "enigma":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_DATE":' . "\r\n" . '                        showError("Please enter a valid date.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_INVALID_USER":' . "\r\n" . '                        showError("The paired user does not exist! Please unlink it.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_INVALID_MAC":' . "\r\n" . '                        showError("Please enter a valid MAC address.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_MAC":' . "\r\n" . '                        showError("The MAC address you entered is already in use.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n\t\t\t" . 'case "serie":' . "\r\n\t\t\t\t" . 'switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_EXISTS_CODE":' . "\r\n" . '                        showError("This series already exists in your database.");' . "\r\n" . '                        break;' . "\r\n" . '                    ' . "\r\n" . '                    case "STATUS_NO_SOURCES":' . "\r\n" . '                        showError("No new episodes could be found in the playlist or folder.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "movie":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_EXISTS_NAME":' . "\r\n" . '                        showError("This movie already exists in your database. Please use another name.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_NO_SOURCES":' . "\r\n" . '                        showError("Please select at least one source for your movie.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "radio":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_EXISTS_SOURCE":' . "\r\n" . '                        showError("This station source is already in your database. Please use another URL.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_NO_SOURCES":' . "\r\n" . '                        showError("Please select at least one source for your station.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "server_install":' . "\r\n" . '            case "proxy":' . "\r\n" . '            case "server":' . "\r\n" . '            case "rtmp_ip":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_IP":' . "\r\n" . '                        showError("Please enter a valid IP address / CIDR.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_IP":' . "\r\n" . '                        showError("This IP address is already in the database. Please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "stream":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_FILE":' . "\r\n" . '                        showError("Could not process M3U file, please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_SOURCE":' . "\r\n" . '                        showError("This stream source is already in your database. Please use another URL.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_NO_SOURCES":' . "\r\n" . '                        showError("Please select at least one source for your stream.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "ticket":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_DATA":' . "\r\n" . '                        showError("Please ensure you enter both a title and message.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "watch_add":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_EXISTS_DIR":' . "\r\n" . '                        showError("This directory is already being watched, please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_INVALID_DIR":' . "\r\n" . '                        showError("An invalid directory was entered, please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n" . '            ' . "\r\n" . '            case "plex_add":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_EXISTS_DIR":' . "\r\n" . '                        showError("This library is already being synced, please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            case "line":' . "\r\n" . '                switch (window.rErrors[rData.status]) {' . "\r\n" . '                    case "STATUS_INVALID_DATE":' . "\r\n" . '                        showError("Please enter a valid date.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    case "STATUS_EXISTS_USERNAME":' . "\r\n" . '                        showError("The username you selected already exists. Please use another.");' . "\r\n" . '                        break;' . "\r\n\r\n" . '                    default:' . "\r\n" . '                        showError("An error occured while processing your request.");' . "\r\n" . '                        break;' . "\r\n" . '                }' . "\r\n" . '                break;' . "\r\n\r\n" . '            default:' . "\r\n" . '                showError("An error occured while processing your request.");' . "\r\n" . '                break;' . "\r\n" . '        }' . "\r\n" . '    }' . "\r\n" . '}' . "\r\n" . '</script>' . "\r\n";
} else {
	if (B1882DF698B44754($A00aec9eca037ce9)) {
		if (isset(XUI::$rRequest['referer'])) {
			$a3486ca94f1ff0e2 = XUI::$rRequest['referer'];
			unset(XUI::$rRequest['referer']);
		} else {
			$a3486ca94f1ff0e2 = null;
		}

		$fa7da6c202358e0c = XUI::$rRequest['action'];
		$a27e64cc6ce01033 = XUI::$rRequest;
		unset($a27e64cc6ce01033['action']);

		if (count($a27e64cc6ce01033) != 0) {
		} else {
			$a27e64cc6ce01033 = json_decode(file_get_contents('php://input'), true);

			if (is_array($a27e64cc6ce01033)) {
			} else {
				$a27e64cc6ce01033 = array(file_get_contents('php://input') => 1);
			}
		}

		if (!$a27e64cc6ce01033) {
			echo json_encode(array('result' => false));

			exit();
		}

		switch ($fa7da6c202358e0c) {
			case 'quick_tools':
				set_time_limit(0);

				if (isset($a27e64cc6ce01033['cleanup_streams'])) {
					$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE (`server_id` NOT IN (SELECT `id` FROM `servers`)) OR (`stream_id` NOT IN (SELECT `id` FROM `streams`));');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_null_lines'])) {
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `username` IS NULL AND `password` IS NULL;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_expired'])) {
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 0 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP());');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_trial'])) {
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 0 AND `is_trial` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_expired_trial'])) {
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 0 AND `is_trial` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP());');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_isp'])) {
					$Fee0d5a474c96306->query("UPDATE `lines` SET `isp_desc` = '', `as_number` = NULL WHERE `is_mag` = 0 AND `is_e2` = 0;");
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['enable_isp'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `is_isplock` = 1 WHERE `is_mag` = 0 AND `is_e2` = 0;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['disable_isp'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `is_isplock` = 0 WHERE `is_mag` = 0 AND `is_e2` = 0;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_expired_mag'])) {
					$Fee0d5a474c96306->query('DELETE FROM `mag_devices` WHERE `user_id` IN (SELECT `id` FROM `lines` WHERE `is_mag` = 1 AND `is_e2` = 0 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP()));');
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 1 AND `is_e2` = 0 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP());');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_trial_mag'])) {
					$Fee0d5a474c96306->query('DELETE FROM `mag_devices` WHERE `user_id` IN (SELECT `id` FROM `lines` WHERE `is_mag` = 1 AND `is_e2` = 0 AND `is_trial` = 1);');
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 1 AND `is_e2` = 0 AND `is_trial` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_expired_trial_mag'])) {
					$Fee0d5a474c96306->query('DELETE FROM `mag_devices` WHERE `user_id` IN (SELECT `id` FROM `lines` WHERE `is_mag` = 1 AND `is_e2` = 0 AND `is_trial` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP()));');
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 1 AND `is_e2` = 0 AND `is_trial` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP());');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_isp_mag'])) {
					$Fee0d5a474c96306->query("UPDATE `lines` SET `isp_desc` = '', `as_number` = NULL WHERE `is_mag` = 1 AND `is_e2` = 0;");
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['enable_isp_mag'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `is_isplock` = 1 WHERE `is_mag` = 1 AND `is_e2` = 0;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['disable_isp_mag'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `is_isplock` = 0 WHERE `is_mag` = 1 AND `is_e2` = 0;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['enable_mag_lock'])) {
					$Fee0d5a474c96306->query('UPDATE `mag_devices` SET `lock_device` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['disable_mag_lock'])) {
					$Fee0d5a474c96306->query('UPDATE `mag_devices` SET `lock_device` = 0;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_mag_lock'])) {
					$Fee0d5a474c96306->query('UPDATE `mag_devices` SET `ip` = NULL, `ver` = NULL, `image_version` = NULL, `stb_type` = NULL, `sn` = NULL, `device_id` = NULL, `device_id2` = NULL, `hw_version` = NULL, `token` = NULL;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_expired_e2'])) {
					$Fee0d5a474c96306->query('DELETE FROM `enigma2_devices` WHERE `user_id` IN (SELECT `id` FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP()));');
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP());');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_trial_e2'])) {
					$Fee0d5a474c96306->query('DELETE FROM `enigma2_devices` WHERE `user_id` IN (SELECT `id` FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 1 AND `is_trial` = 1);');
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 1 AND `is_trial` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['remove_expired_trial_e2'])) {
					$Fee0d5a474c96306->query('DELETE FROM `enigma2_devices` WHERE `user_id` IN (SELECT `id` FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 1 AND `is_trial` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP()));');
					$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 1 AND `is_trial` = 1 AND (`exp_date` IS NOT NULL AND `exp_date` < UNIX_TIMESTAMP());');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_isp_e2'])) {
					$Fee0d5a474c96306->query("UPDATE `lines` SET `isp_desc` = '', `as_number` = NULL WHERE `is_mag` = 0 AND `is_e2` = 1;");
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['enable_isp_e2'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `is_isplock` = 1 WHERE `is_mag` = 0 AND `is_e2` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['disable_isp_e2'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `is_isplock` = 0 WHERE `is_mag` = 0 AND `is_e2` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_activity_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `lines_activity`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_client_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `lines_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_credit_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `users_credits_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_login_flood'])) {
					$Fee0d5a474c96306->query("DELETE FROM `login_logs` WHERE `status` = 'INVALID_LOGIN';");
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_login_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `login_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_mag_events'])) {
					$Fee0d5a474c96306->query('TRUNCATE `mag_events`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_panel_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `panel_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_stream_errors'])) {
					$Fee0d5a474c96306->query('TRUNCATE `streams_errors`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_stream_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `streams_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_user_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `users_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['clear_watch_logs'])) {
					$Fee0d5a474c96306->query('TRUNCATE `watch_logs`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['block_trial_lines'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `is_trial` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['unblock_trial_lines'])) {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `is_trial` = 1;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_blocked_asns'])) {
					$Fee0d5a474c96306->query('UPDATE `blocked_asns` SET `blocked` = 0;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_blocked_ips'])) {
					Fa3A80bA9EfF25dA();
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_blocked_isps'])) {
					$Fee0d5a474c96306->query('TRUNCATE `blocked_isps`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_blocked_uas'])) {
					$Fee0d5a474c96306->query('TRUNCATE `blocked_uas`;');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['flush_country_lock'])) {
					$Fee0d5a474c96306->query("UPDATE `lines` SET `forced_country` = '';");
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['force_epg_update'])) {
					shell_exec(XUI_HOME . '/php/bin/php ' . XUI_HOME . '/crons/epg.php > /dev/null 2>/dev/null &');
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				}

				if (isset($a27e64cc6ce01033['force_update_movies'])) {
					$Fee0d5a474c96306->query('DELETE FROM `watch_refresh` WHERE `type` = 1;');
					$Fee0d5a474c96306->query('SELECT `id` FROM `streams` WHERE `type` = 2;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$Fee0d5a474c96306->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES(1, ?, 0);', $C740da31596f24ef['id']);
					}
					echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

					exit();
				} else {
					if (isset($a27e64cc6ce01033['force_update_series'])) {
						$Fee0d5a474c96306->query('DELETE FROM `watch_refresh` WHERE `type` = 2;');
						$Fee0d5a474c96306->query('SELECT `id` FROM `streams_series`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$Fee0d5a474c96306->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES(2, ?, 0);', $C740da31596f24ef['id']);
						}
						echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

						exit();
					} else {
						if (isset($a27e64cc6ce01033['force_update_episodes'])) {
							$Fee0d5a474c96306->query('DELETE FROM `watch_refresh` WHERE `type` = 3;');
							$Fee0d5a474c96306->query('SELECT `id` FROM `streams` WHERE `type` = 5;');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$Fee0d5a474c96306->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES(3, ?, 0);', $C740da31596f24ef['id']);
							}
							echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

							exit();
						} else {
							if (isset($a27e64cc6ce01033['reauthorise_mysql'])) {
								fCf52F24c866C872();
								echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

								exit();
							}

							if (isset($a27e64cc6ce01033['restart_all_streams'])) {
								$E708d4730d21125b = $Cdb85875fd50f459 = array();
								$Fee0d5a474c96306->query('SELECT DISTINCT(`stream_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1;');

								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
									$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
								}
								$Fee0d5a474c96306->query('SELECT DISTINCT(`server_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1;');

								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
									$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
								}

								if (0 >= count($Cdb85875fd50f459)) {
								} else {
									$B95dc1bd2d8c3a31 = e36eC1583e223BF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => $Cdb85875fd50f459, 'servers' => $E708d4730d21125b));
								}

								echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

								exit();
							} else {
								if (isset($a27e64cc6ce01033['restart_online_streams'])) {
									$E708d4730d21125b = $Cdb85875fd50f459 = array();
									$Fee0d5a474c96306->query('SELECT DISTINCT(`stream_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND `streams_servers`.`pid` IS NOT NULL AND `streams_servers`.`pid` > 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

									foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
										$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
									}
									$Fee0d5a474c96306->query('SELECT DISTINCT(`server_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND `streams_servers`.`pid` IS NOT NULL AND `streams_servers`.`pid` > 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

									foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
										$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
									}

									if (0 >= count($Cdb85875fd50f459)) {
									} else {
										$B95dc1bd2d8c3a31 = e36ec1583e223bF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => $Cdb85875fd50f459, 'servers' => $E708d4730d21125b));
									}

									echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

									exit();
								} else {
									if (isset($a27e64cc6ce01033['restart_down_streams'])) {
										$E708d4730d21125b = $Cdb85875fd50f459 = array();
										$Fee0d5a474c96306->query('SELECT DISTINCT(`stream_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

										foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
											$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
										}
										$Fee0d5a474c96306->query('SELECT DISTINCT(`server_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

										foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
											$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
										}

										if (0 >= count($Cdb85875fd50f459)) {
										} else {
											$B95dc1bd2d8c3a31 = E36eC1583E223bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => $Cdb85875fd50f459, 'servers' => $E708d4730d21125b));
										}

										echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

										exit();
									} else {
										if (isset($a27e64cc6ce01033['start_offline_streams'])) {
											$E708d4730d21125b = $Cdb85875fd50f459 = array();
											$Fee0d5a474c96306->query('SELECT DISTINCT(`stream_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND (`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND `streams_servers`.`on_demand` = 0);');

											foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
												$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
											}
											$Fee0d5a474c96306->query('SELECT DISTINCT(`server_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND (`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND `streams_servers`.`on_demand` = 0);');

											foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
												$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
											}

											if (0 >= count($Cdb85875fd50f459)) {
											} else {
												$B95dc1bd2d8c3a31 = E36Ec1583E223bF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => $Cdb85875fd50f459, 'servers' => $E708d4730d21125b));
											}

											echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

											exit();
										} else {
											if (isset($a27e64cc6ce01033['stop_down_streams'])) {
												$E708d4730d21125b = $Cdb85875fd50f459 = array();
												$Fee0d5a474c96306->query('SELECT DISTINCT(`stream_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

												foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
													$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
												}
												$Fee0d5a474c96306->query('SELECT DISTINCT(`server_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

												foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
													$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
												}

												if (0 >= count($Cdb85875fd50f459)) {
												} else {
													$B95dc1bd2d8c3a31 = E36EC1583e223bf6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => $Cdb85875fd50f459, 'servers' => $E708d4730d21125b));
												}

												echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

												exit();
											} else {
												if (isset($a27e64cc6ce01033['stop_online_streams'])) {
													$E708d4730d21125b = $Cdb85875fd50f459 = array();
													$Fee0d5a474c96306->query('SELECT DISTINCT(`stream_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND `streams_servers`.`pid` IS NOT NULL AND `streams_servers`.`pid` > 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

													foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
														$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
													}
													$Fee0d5a474c96306->query('SELECT DISTINCT(`server_id`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams`.`type` = 1 AND `streams_servers`.`pid` IS NOT NULL AND `streams_servers`.`pid` > 0 AND `streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0;');

													foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
														$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
													}

													if (0 >= count($Cdb85875fd50f459)) {
													} else {
														$B95dc1bd2d8c3a31 = E36EC1583E223bF6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => $Cdb85875fd50f459, 'servers' => $E708d4730d21125b));
													}

													echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

													exit();
												} else {
													if (isset($a27e64cc6ce01033['block_all_isps'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 1 WHERE `type` = 'isp';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['unblock_all_isps'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 0 WHERE `type` = 'isp';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['block_all_servers'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 1 WHERE `type` = 'hosting';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['unblock_all_servers'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 0 WHERE `type` = 'hosting';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['block_all_education'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 1 WHERE `type` = 'education';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['unblock_all_education'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 0 WHERE `type` = 'education';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['block_all_businesses'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 1 WHERE `type` = 'business';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['unblock_all_businesses'])) {
														$Fee0d5a474c96306->query("UPDATE `blocked_asns` SET `blocked` = 0 WHERE `type` = 'business';");
														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													}

													if (isset($a27e64cc6ce01033['purge_unlinked_lines_mag'])) {
														$Aa8c918a2a91966f = array();
														$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `is_mag` = 1 AND `id` NOT IN (SELECT `user_id` FROM `mag_devices`);');

														foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
															$Aa8c918a2a91966f[] = $C740da31596f24ef['id'];
														}

														if (0 >= count($Aa8c918a2a91966f)) {
														} else {
															$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `id` IN (' . implode(',', array_map('intval', $Aa8c918a2a91966f)) . ');');
														}

														echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

														exit();
													} else {
														if (isset($a27e64cc6ce01033['purge_unlinked_lines_e2'])) {
															$Aa8c918a2a91966f = array();
															$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `is_e2` = 1 AND `id` NOT IN (SELECT `user_id` FROM `enigma2_devices`);');

															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																$Aa8c918a2a91966f[] = $C740da31596f24ef['id'];
															}

															if (0 >= count($Aa8c918a2a91966f)) {
															} else {
																$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `id` IN (' . implode(',', array_map('intval', $Aa8c918a2a91966f)) . ');');
															}

															echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

															exit();
														} else {
															if (isset($a27e64cc6ce01033['symlink_all_movies'])) {
																$Fee0d5a474c96306->query('SELECT `streams`.`id`, `streams_servers`.`server_id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` WHERE `type` = 2 AND `movie_symlink` = 1;');
																$A2b85ede89f9df0c = $Fee0d5a474c96306->get_rows();
																$Cdb85875fd50f459 = array();

																foreach ($A2b85ede89f9df0c as $f523e362fb81d6c8) {
																	$Cdb85875fd50f459[] = $f523e362fb81d6c8['id'];
																}

																if (0 >= count($Cdb85875fd50f459)) {
																} else {
																	$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL, `current_source` = NULL, `to_analyze` = 0, `pid` = NULL, `stream_started` = NULL, `stream_info` = NULL, `stream_status` = 0, `monitor_pid` = NULL WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ');');
																}

																foreach ($A2b85ede89f9df0c as $f523e362fb81d6c8) {
																	XUI::queueMovie($f523e362fb81d6c8['id'], $f523e362fb81d6c8['server_id']);
																}
																echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

																exit();
															} else {
																if (isset($a27e64cc6ce01033['symlink_all_episodes'])) {
																	$Fee0d5a474c96306->query('SELECT `streams`.`id`, `streams_servers`.`server_id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` WHERE `type` = 5 AND `movie_symlink` = 1;');
																	$A2b85ede89f9df0c = $Fee0d5a474c96306->get_rows();
																	$Cdb85875fd50f459 = array();

																	foreach ($A2b85ede89f9df0c as $f523e362fb81d6c8) {
																		$Cdb85875fd50f459[] = $f523e362fb81d6c8['id'];
																	}

																	if (0 >= count($Cdb85875fd50f459)) {
																	} else {
																		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL, `current_source` = NULL, `to_analyze` = 0, `pid` = NULL, `stream_started` = NULL, `stream_info` = NULL, `stream_status` = 0, `monitor_pid` = NULL WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ');');
																	}

																	foreach ($A2b85ede89f9df0c as $f523e362fb81d6c8) {
																		XUI::queueMovie($f523e362fb81d6c8['id'], $f523e362fb81d6c8['server_id']);
																	}
																	echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

																	exit();
																} else {
																	if (isset($a27e64cc6ce01033['recreate_channels'])) {
																		$Fee0d5a474c96306->query('SELECT `id` FROM `streams` WHERE `type` = 3;');
																		$Cdb85875fd50f459 = array_map('intval', array_keys($Fee0d5a474c96306->get_rows(true, 'id')));

																		if (0 >= count($Cdb85875fd50f459)) {
																		} else {
																			$Fee0d5a474c96306->query("UPDATE `streams_servers` SET `cchannel_rsources` = '[]', `pids_create_channel` = '[]', `bitrate` = NULL,`current_source` = NULL,`to_analyze` = 0,`pid` = NULL,`stream_started` = NULL,`stream_info` = NULL,`stream_status` = 0,`monitor_pid` = NULL WHERE `stream_id` IN (" . implode(',', $Cdb85875fd50f459) . ');');
																		}

																		echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

																		exit();
																	}

																	if (isset($a27e64cc6ce01033['delete_duplicates'])) {
																		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'tools.php "duplicates" > /dev/null 2>/dev/null &');
																		echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

																		exit();
																	}

																	if (isset($a27e64cc6ce01033['restore_images'])) {
																		restoreImages();
																		echo json_encode(array('result' => true, 'status' => STATUS_SUCCESS));

																		exit();
																	}

																	if (isset($a27e64cc6ce01033['replace_movie_years'])) {
																		$Fee0d5a474c96306->query('SELECT `id`, `year`, `movie_properties`, `stream_display_name` FROM `streams` WHERE `type` = 2 ORDER BY `id` DESC;');

																		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																			$C2b442d46f74050c = $C740da31596f24ef;

																			if (!empty($C740da31596f24ef['year'])) {
																			} else {
																				$C740da31596f24ef['year'] = substr(json_decode($C740da31596f24ef['movie_properties'], true)['release_date'], 0, 4);
																			}

																			$B71e407f03516d91 = '/\\(([0-9)]+)\\)/';
																			preg_match($B71e407f03516d91, $C740da31596f24ef['stream_display_name'], $b85ce31cd1118ad2, PREG_OFFSET_CAPTURE, 0);
																			$d242d1b36e29f10f = null;
																			$A2e6f68800d7b157 = 0;

																			if (count($b85ce31cd1118ad2) == 2) {
																				$d242d1b36e29f10f = intval($b85ce31cd1118ad2[1][0]);
																				$A2e6f68800d7b157 = 1;
																			} else {
																				$B211d7401e6242f3 = explode('-', $C740da31596f24ef['stream_display_name']);

																				if (!(1 < count($B211d7401e6242f3) && is_numeric(trim(end($B211d7401e6242f3))))) {
																				} else {
																					$d242d1b36e29f10f = intval(trim(end($B211d7401e6242f3)));
																					$A2e6f68800d7b157 = 2;
																				}
																			}

																			if (0 >= $A2e6f68800d7b157) {
																			} else {
																				if (!(1900 <= $d242d1b36e29f10f && $d242d1b36e29f10f <= intval(date('Y') + 1))) {
																				} else {
																					if (!empty($C740da31596f24ef['year'])) {
																					} else {
																						$C740da31596f24ef['year'] = $d242d1b36e29f10f;
																					}

																					if ($A2e6f68800d7b157 == 1) {
																						$C740da31596f24ef['stream_display_name'] = trim(preg_replace('!\\s+!', ' ', str_replace($b85ce31cd1118ad2[0][0], '', $C740da31596f24ef['stream_display_name'])));
																					} else {
																						$C740da31596f24ef['stream_display_name'] = trim(implode('-', array_slice($B211d7401e6242f3, 0, -1)));
																					}
																				}
																			}

																			if (!($C740da31596f24ef['year'] != $C2b442d46f74050c['year'] || $C740da31596f24ef['stream_display_name'] != $C2b442d46f74050c['stream_display_name'])) {
																			} else {
																				$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_display_name` = ?, `year` = ? WHERE `id` = ?;', $C740da31596f24ef['stream_display_name'], $C740da31596f24ef['year'], $C740da31596f24ef['id']);
																			}
																		}
																	} else {
																		if (isset($a27e64cc6ce01033['replace_series_years'])) {
																			$Fee0d5a474c96306->query('SELECT `id`, `year`, `release_date`, `title` FROM `streams_series`;');

																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$C2b442d46f74050c = $C740da31596f24ef;

																				if (!empty($C740da31596f24ef['year'])) {
																				} else {
																					$C740da31596f24ef['year'] = substr($C740da31596f24ef['release_date'], 0, 4);
																				}

																				$B71e407f03516d91 = '/\\(([0-9)]+)\\)/';
																				preg_match($B71e407f03516d91, $C740da31596f24ef['title'], $b85ce31cd1118ad2, PREG_OFFSET_CAPTURE, 0);
																				$d242d1b36e29f10f = null;
																				$A2e6f68800d7b157 = 0;

																				if (count($b85ce31cd1118ad2) == 2) {
																					$d242d1b36e29f10f = intval($b85ce31cd1118ad2[1][0]);
																					$A2e6f68800d7b157 = 1;
																				} else {
																					$B211d7401e6242f3 = explode('-', $C740da31596f24ef['title']);

																					if (!(1 < count($B211d7401e6242f3) && is_numeric(trim(end($B211d7401e6242f3))))) {
																					} else {
																						$d242d1b36e29f10f = intval(trim(end($B211d7401e6242f3)));
																						$A2e6f68800d7b157 = 2;
																					}
																				}

																				if (0 >= $A2e6f68800d7b157) {
																				} else {
																					if (!(1900 <= $d242d1b36e29f10f && $d242d1b36e29f10f <= intval(date('Y') + 1))) {
																					} else {
																						if (!empty($C740da31596f24ef['year'])) {
																						} else {
																							$C740da31596f24ef['year'] = $d242d1b36e29f10f;
																						}

																						if ($A2e6f68800d7b157 == 1) {
																							$C740da31596f24ef['title'] = trim(preg_replace('!\\s+!', ' ', str_replace($b85ce31cd1118ad2[0][0], '', $C740da31596f24ef['title'])));
																						} else {
																							$C740da31596f24ef['title'] = trim(implode('-', array_slice($B211d7401e6242f3, 0, -1)));
																						}
																					}
																				}

																				if (!($C740da31596f24ef['year'] != $C2b442d46f74050c['year'] || $C740da31596f24ef['title'] != $C2b442d46f74050c['title'])) {
																				} else {
																					$Fee0d5a474c96306->query('UPDATE `streams_series` SET `title` = ?, `year` = ? WHERE `id` = ?;', $C740da31596f24ef['title'], $C740da31596f24ef['year'], $C740da31596f24ef['id']);
																				}
																			}
																		} else {
																			if (isset($a27e64cc6ce01033['check_compatibility'])) {
																				$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` WHERE `stream_info` IS NOT NULL;');
																				$Aa8d8af3d37ca869 = $Fee0d5a474c96306->get_row()['count'];

																				if (0 >= $Aa8d8af3d37ca869) {
																				} else {
																					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

																					if ($Fffb76b482d3afe0) {
																					} else {
																						$Fffb76b482d3afe0 = array(0);
																					}

																					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
																						$Fee0d5a474c96306->query('SELECT `server_stream_id`, `stream_info`, `compatible` FROM `streams_servers` WHERE `stream_info` IS NOT NULL LIMIT ' . $be001d5ed5a7c58d . ', 1000;');

																						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																							$f03f005ea6f01679 = XUI::a267181C61BDFff9($C740da31596f24ef['stream_info']);

																							if ($f03f005ea6f01679 == $C740da31596f24ef['compatible']) {
																							} else {
																								$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `compatible` = ? WHERE `server_stream_id` = ?;', $f03f005ea6f01679, $C740da31596f24ef['server_stream_id']);
																							}
																						}
																					}
																				}

																				$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `compatible` = 0 WHERE `stream_info` IS NULL;');
																			} else {
																				if (isset($a27e64cc6ce01033['rescan_vod'])) {
																					$Fee0d5a474c96306->query('UPDATE `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` SET `to_analyze` = 1, `pid` = IF(`pid`, `pid`, 1) WHERE `type` IN (2,5) AND `direct_source` = 0;');
																				} else {
																					if (isset($a27e64cc6ce01033['update_ratings'])) {
																						$Fee0d5a474c96306->query('SELECT `id`, `movie_properties`, `rating` FROM `streams` WHERE `type` = 2;');

																						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																							$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);
																							$Fc297f7900530e67 = (floatval($D92b16dc36690ab9['rating']) ?: 0);

																							if ($C740da31596f24ef['rating'] == $Fc297f7900530e67) {
																							} else {
																								$Fee0d5a474c96306->query('UPDATE `streams` SET `rating` = ? WHERE `id` = ?;', $Fc297f7900530e67, $C740da31596f24ef['id']);
																							}
																						}
																					} else {
																						if (!isset($a27e64cc6ce01033['add_tmdb_ids'])) {
																						} else {
																							$Fee0d5a474c96306->query('SELECT `id`, `movie_properties`, `tmdb_id` FROM `streams` WHERE `type` = 2 AND `tmdb_id` IS NULL;');

																							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																								$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);
																								$Ddb572d71804d3a6 = ($D92b16dc36690ab9['tmdb_id'] ?: null);

																								if ($C740da31596f24ef['tmdb_id'] == $Ddb572d71804d3a6) {
																								} else {
																									$Fee0d5a474c96306->query('UPDATE `streams` SET `tmdb_id` = ? WHERE `id` = ?;', $Ddb572d71804d3a6, $C740da31596f24ef['id']);
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}

																	break;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}

				// no break
			case 'stream_tools':
				if (isset($a27e64cc6ce01033['replace_dns'])) {
					API::aDDe0be331F79aAd($a27e64cc6ce01033);
					echo json_encode(array('result' => true, 'location' => 'stream_tools?status=1', 'status' => 1));

					exit();
				}

				if (!isset($a27e64cc6ce01033['move_streams'])) {
					break;
				}

				API::b6076D4E3feD8702($a27e64cc6ce01033);
				echo json_encode(array('result' => true, 'location' => 'stream_tools?status=2', 'status' => 2));

				exit();

			case 'bouquet':
				$a85e1b7d42c346a0 = API::c6CEf67e40287E05($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'bouquets?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'stream':
				$a85e1b7d42c346a0 = API::E0407C2c64b2C037($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'streams') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					if (isset($_FILES['m3u_file'])) {
						echo json_encode(array('result' => true, 'location' => 'streams?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'stream_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'movie':
				if (!empty($a27e64cc6ce01033['import_folder']) || !empty($_FILES['m3u_file']['tmp_name'])) {
					$a85e1b7d42c346a0 = API::importMovies($a27e64cc6ce01033);
					echo json_encode(array('result' => true, 'location' => 'movies?status=2', 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				$a85e1b7d42c346a0 = API::D4E96AC013E38c70($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'movies') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					if (isset($_FILES['m3u_file'])) {
						echo json_encode(array('result' => true, 'location' => 'movies?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'stream_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'backups':
				$a85e1b7d42c346a0 = API::B345aE7d1A648eda($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'backups?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'cache':
				$a85e1b7d42c346a0 = API::editCacheCron($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'cache?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'bouquet_order':
				$a85e1b7d42c346a0 = API::bA3868Dc0Ef46144($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'bouquet_order?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS_REPLACE) {
					echo json_encode(array('result' => true, 'location' => 'bouquet_order?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'bouquet_sort':
				$a85e1b7d42c346a0 = API::c6EbA7c2D99567E2($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'bouquet_sort?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'channel_order':
				$a85e1b7d42c346a0 = API::B09A32C4530444E9($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'channel_order?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'code':
				$a85e1b7d42c346a0 = API::c26a6946575A9b88($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (E787d2298dbda85d() == $a85e1b7d42c346a0['data']['orig_code']) {
						echo json_encode(array('result' => true, 'location' => acE67C2bfe9aDaD5() . '://' . $a8bb73cba48fb7f6[SERVER_ID]['server_ip'] . ':' . $_SERVER['SERVER_PORT'] . '/' . $a85e1b7d42c346a0['data']['new_code'] . '/codes?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'codes?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'hmac':
				$a85e1b7d42c346a0 = API::D991Ba25e32737CE($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'hmacs?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'record':
				$a85e1b7d42c346a0 = API::scheduleRecording($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'archive?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'created_channel':
				$a85e1b7d42c346a0 = API::f3b2be29c4dd0b5E($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'created_channels') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'stream_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'edit_profile':
				$a85e1b7d42c346a0 = API::E63650987aA344aE($a27e64cc6ce01033);
				setcookie('hue', $a27e64cc6ce01033['hue'], time() + 315360000);
				setcookie('theme', $a27e64cc6ce01033['theme'], time() + 315360000);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'edit_profile?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status'], 'reload' => true));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'epg':
				$a85e1b7d42c346a0 = API::D4c0BD97CAFDFaf7($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'epgs?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'provider':
				$a85e1b7d42c346a0 = API::processProvider($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'providers?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'episode':
				$a85e1b7d42c346a0 = API::B490BccEcc0e1AD3($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'episodes') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'stream_view?sid=' . intval($a85e1b7d42c346a0['data']['series_id']) . '&id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status'])));

					exit();
				}

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS_MULTI) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'episodes') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'episodes?series=' . intval($a85e1b7d42c346a0['data']['series_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'episodes_mass':
				$a85e1b7d42c346a0 = API::E6376d32625FEC98($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'episodes_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'line_mass':
				$a85e1b7d42c346a0 = API::aD583f76cCC9BD2A($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'line_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'user_mass':
				$a85e1b7d42c346a0 = API::CFa8a15C57DD64f2($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'user_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mag_mass':
				$a85e1b7d42c346a0 = API::FBb31Eea1c81D1f8($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mag_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'enigma_mass':
				$a85e1b7d42c346a0 = API::c86d70b28399d723($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'enigma_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'stream_mass':
				$a85e1b7d42c346a0 = API::E10dA8800b7e2241($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'stream_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'created_channel_mass':
				$a85e1b7d42c346a0 = API::massEditChannels($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'created_channel_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'movie_mass':
				$a85e1b7d42c346a0 = API::C687a3D22C3A694a($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'movie_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'radio_mass':
				$a85e1b7d42c346a0 = API::f109967aC71cc0da($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'radio_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'series_mass':
				$a85e1b7d42c346a0 = API::DeFa8D6cB43b3D68($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'series_mass?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'group':
				$a85e1b7d42c346a0 = API::Bde4E1a0450D3CD0($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'groups?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'ip':
				$a85e1b7d42c346a0 = API::C638aD4f75Ff57a6($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'ips?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'isp':
				$a85e1b7d42c346a0 = API::CBB044eB5B5FA5a2($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'isps?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'line':
				$a85e1b7d42c346a0 = API::D4CdF8772E0D536B($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'lines') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'lines?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mag':
				$a85e1b7d42c346a0 = API::EB9eaD5B16d184F3($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'mags') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'mags?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'enigma':
				$a85e1b7d42c346a0 = API::ecaf66B237906519($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'enigmas') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'enigmas?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_streams':
				$a85e1b7d42c346a0 = API::bdB7989B92819df0($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_movies':
				$a85e1b7d42c346a0 = API::ef104395E7B7Db39($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_lines':
				$a85e1b7d42c346a0 = API::eBB672e1975480Ed($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_series':
				$a85e1b7d42c346a0 = API::c0781Dfd0B51D96d($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_episodes':
				$a85e1b7d42c346a0 = API::a45cb66cf614Da21($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_radios':
				$a85e1b7d42c346a0 = API::b65C3404392B5deD($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_users':
				$a85e1b7d42c346a0 = API::da73459e65F37dfB($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_mags':
				$a85e1b7d42c346a0 = API::DF67d3811748bba2($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'mass_delete_enigmas':
				$a85e1b7d42c346a0 = API::C852a2B372281bCf($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'mass_delete?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'package':
				$a85e1b7d42c346a0 = API::bA66921612Ed64b0($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'packages?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'profile':
				$a85e1b7d42c346a0 = API::A6c9CF2C4EDC8627($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'profiles?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'radio':
				$a85e1b7d42c346a0 = API::bFeCE7B7Fa4F9Dc0($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'radios') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'stream_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'rtmp_ip':
				$a85e1b7d42c346a0 = API::a6858093B7b0EdA5($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'rtmp_ips?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'serie':
				if (!empty($a27e64cc6ce01033['import_folder']) || !empty($_FILES['m3u_file']['tmp_name'])) {
					$a85e1b7d42c346a0 = API::importSeries($a27e64cc6ce01033);
					echo json_encode(array('result' => true, 'location' => 'series?status=2', 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				$a85e1b7d42c346a0 = API::DEFd4d23B6637937($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'series') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'series?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'proxy':
				$a85e1b7d42c346a0 = API::fA3E5a3ea20dA904($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'server_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'server':
				$a27e64cc6ce01033['server_type'] = 0;
				$a85e1b7d42c346a0 = API::f6891f9C339Ac681($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if ($a27e64cc6ce01033['regenerate_ssl'] == 1) {
						$Fee0d5a474c96306->query('UPDATE `servers` SET `certbot_ssl` = null WHERE `id` = ?;', $a85e1b7d42c346a0['data']['insert_id']);
						$f3f2185d635db9d9 = array('action' => 'certbot_generate', 'domain' => array());

						if (is_array($a27e64cc6ce01033['domain_name'])) {
						} else {
							$a27e64cc6ce01033['domain_name'] = explode(',', $a27e64cc6ce01033['domain_name']);
						}

						foreach ($a27e64cc6ce01033['domain_name'] as $Caecf2bcd39a1efe) {
							if (filter_var($Caecf2bcd39a1efe, FILTER_VALIDATE_IP)) {
							} else {
								$f3f2185d635db9d9['domain'][] = $Caecf2bcd39a1efe;
							}
						}

						if (0 < count($f3f2185d635db9d9['domain'])) {
							$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $a85e1b7d42c346a0['data']['insert_id'], time(), json_encode($f3f2185d635db9d9));
							echo json_encode(array('result' => true, 'location' => 'server_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . STATUS_CERTBOT, 'status' => STATUS_CERTBOT));

							exit();
						}

						echo json_encode(array('result' => true, 'location' => 'server_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . STATUS_CERTBOT_INVALID, 'status' => STATUS_CERTBOT_INVALID));

						exit();
					} else {
						echo json_encode(array('result' => true, 'location' => 'server_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}
				} else {
					echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				// no break
			case 'server_install':
				$a85e1b7d42c346a0 = API::bAAB8972232156eE($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'server_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'settings':
				$a85e1b7d42c346a0 = API::aff4E84a1b89b55F($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'settings?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'settings_plex':
				$a85e1b7d42c346a0 = API::editPlexSettings($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'settings_plex?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'settings_watch':
				$a85e1b7d42c346a0 = API::a5Ed159e8bfd9e84($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'settings_watch?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'server_order':
				$a85e1b7d42c346a0 = API::orderServers($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'server_order?status=' . STATUS_SUCCESS, 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'stream_categories':
				$a85e1b7d42c346a0 = API::B33b7A37bC32714a($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'stream_categories?status=' . STATUS_SUCCESS_MULTI, 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'stream_category':
				$a85e1b7d42c346a0 = API::dC7b22871Ac995e5($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'stream_categories?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'ticket':
				$a85e1b7d42c346a0 = API::aE1C2E59b87c9b1b($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'ticket_view?id=' . intval($a85e1b7d42c346a0['data']['insert_id']) . '&status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'user':
				$a85e1b7d42c346a0 = API::E8eBe0D3E389584E($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					if (isset($a27e64cc6ce01033['edit']) && getPageFromURL($a3486ca94f1ff0e2) == 'users') {
						echo json_encode(array('result' => true, 'location' => $a3486ca94f1ff0e2, 'status' => $a85e1b7d42c346a0['status']));

						exit();
					}

					echo json_encode(array('result' => true, 'location' => 'users?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'useragent':
				$a85e1b7d42c346a0 = API::AC56fd7A04748A62($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'useragents?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'watch_add':
				$a85e1b7d42c346a0 = API::A85970F9953c4294($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'watch?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();

			case 'plex_add':
				$a85e1b7d42c346a0 = API::processPlexSync($a27e64cc6ce01033);

				if ($a85e1b7d42c346a0['status'] == STATUS_SUCCESS) {
					echo json_encode(array('result' => true, 'location' => 'plex?status=' . intval($a85e1b7d42c346a0['status']), 'status' => $a85e1b7d42c346a0['status']));

					exit();
				}

				echo json_encode(array('result' => false, 'data' => $a85e1b7d42c346a0['data'], 'status' => $a85e1b7d42c346a0['status']));

				exit();
		}
	} else {
		echo json_encode(array('result' => false));

		exit();
	}
}
