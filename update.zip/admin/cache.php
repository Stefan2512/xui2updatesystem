<?php

include 'session.php';
include 'functions.php';

if (b1882DF698b44754()) {
} else {
	B46f5dd76f3C7421();
}

XUI::$rSettings = XUI::d761E78dA5eB70Fb(true);
$F2d4d8f7981ac574 = XUI::$rSettings;
$bcf587bb39f95fd5 = 'Cache & Redis Settings';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<form action="#" method="POST">' . "\n\t\t\t" . '<div class="row">' . "\n\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t" . '<div class="page-title-box">' . "\n" . '                        <div class="page-title-right">' . "\n" . '                            ';
include 'topbar.php';
echo '                        </div>' . "\n\t\t\t\t\t\t" . '<h4 class="page-title">Cache & Redis Settings</h4>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>     ' . "\n\t\t\t" . '<div class="row">' . "\n\t\t\t\t" . '<div class="col-xl-12">' . "\n\t\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo "\t\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t\t" . 'Cache & Redis settings sucessfully updated!' . "\n\t\t\t\t\t" . '</div>' . "\n" . '                    ';
}

echo "\t\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t";

if (XUI::$rSettings['enable_cache'] && XUI::$rSettings['redis_handler']) {
	$b6c1b012e942c0b8 = 100;
	$Ac54397e06e8e862 = 'pink';
	$Eb5dde5d027876ce = 'Maximum';
	$Ce1f39c684b3082c = "You're using both Caching and Redis Connection Handler, your service is optimised for <strong>maximum performance</strong>!";
} else {
	if (XUI::$rSettings['enable_cache'] || XUI::$rSettings['redis_handler']) {
		$Eb5dde5d027876ce = 'Good';
		$Ac54397e06e8e862 = 'info';

		if (!XUI::$rSettings['enable_cache']) {
			$b6c1b012e942c0b8 = 50;
			$Ce1f39c684b3082c = 'Caching is disabled on your service, this will impact performance significantly under load compared to having it enabled.';
		} else {
			$b6c1b012e942c0b8 = 75;
			$Ce1f39c684b3082c = "Redis Connection Handler is disabled on your service, if you have a lot of throughput you will see better performance with Redis enabled.<br/>If you maintain active connections of over 10,000 for example you should consider this. Below this amount you're unlikely to see any benefit.";
		}
	} else {
		$b6c1b012e942c0b8 = 25;
		$Eb5dde5d027876ce = 'Poor';
		$Ac54397e06e8e862 = 'secondary';
		$Ce1f39c684b3082c = "You're using neither Caching or Redis Connection Handler, the server will perform poorly compared to having either enabled.";
	}
}

echo "\t\t\t\t\t\t\t" . '<h5 class="card-title">';
echo $Eb5dde5d027876ce;
echo ' Performance</h5>' . "\n\t\t\t\t\t\t\t" . '<p>';
echo $Ce1f39c684b3082c;
echo '</p>' . "\n\t\t\t\t\t\t\t" . '<div class="progress mb-2">' . "\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar progress-bar-striped progress-bar-animated bg-';
echo $Ac54397e06e8e862;
echo '" role="progressbar" aria-valuenow="';
echo $b6c1b012e942c0b8;
echo '" aria-valuemin="0" aria-valuemax="100" style="width: ';
echo $b6c1b012e942c0b8;
echo '%"></div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#cache" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-cached mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">XUI Caching System</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                    <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#connections" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-lan-connect mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Redis Connection Handler</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="cache">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n" . '                                                ';

if ($F2d4d8f7981ac574['enable_cache']) {
	$Fee0d5a474c96306->query("SELECT `time` FROM `crontab` WHERE `filename` = 'cache_engine.php';");
	list($e3c95294a1debc47, $d08bd3f46de523f4, $D616dc2f0e0a7bd6, $f01ae1008c6933f7, $A8d2ff1788d6f686) = explode(' ', $Fee0d5a474c96306->get_row()['time']);
	$Fee0d5a474c96306->query('SELECT `id` FROM `lines`;');
	$Ee60e729075f9d1b = $Fee0d5a474c96306->result->rowCount();
	$Fee0d5a474c96306->query('SELECT `id` FROM `streams`;');
	$Acd740cd0959cdfd = $Fee0d5a474c96306->result->rowCount();
	$Fee0d5a474c96306->query('SELECT `id` FROM `streams_series`;');
	$ac498f333d474130 = $Fee0d5a474c96306->result->rowCount();
	$Cade224ddccf2558 = count(glob(LINES_TMP_PATH . 'line_i_*'));
	$b27a0766bc4fb317 = count(glob(STREAMS_TMP_PATH . 'stream_*'));
	$D26e1d203e266834 = count(glob(SERIES_TMP_PATH . 'series_*')) - 2;

	if ($D26e1d203e266834 >= 0) {
	} else {
		$D26e1d203e266834 = 0;
	}

	$e654d90f4bc8fc34 = 100 - intval(disk_free_space(XUI_HOME . 'tmp') / disk_total_space(XUI_HOME . 'tmp') * 100);

	if (90 > $e654d90f4bc8fc34) {
	} else {
		echo '                                                <div class="alert alert-danger mb-4" role="alert">' . "\n" . '                                                    Your cache tmpfs mount is <strong>';
		echo $e654d90f4bc8fc34;
		echo '% full</strong>! This can stop new lines and streams from caching and when the mount is completely full cache will not work correctly.<br/><br/><strong>You should increase the size of your tmpfs size in /etc/fstab and reboot.</strong>' . "\n" . '                                                </div>' . "\n" . '                                                ';
	}

	if (file_exists(CACHE_TMP_PATH . 'cache_complete')) {
	} else {
		echo '                                                <div class="alert alert-warning mb-4" role="alert">' . "\n" . "                                                    Cache isn't complete yet! If you have a lot of streams and lines, the caching process can take a while to complete. For now, no users will be able to connect to the service.<br/><br/>Player API and Playlist functionality will be limited until cache is complete. This is a requirement regardless of whether cache is enabled or not." . "\n" . '                                                </div>' . "\n" . '                                                ';
	}

	echo '                                                <h5 class="card-title">Cache Cron Execution</h5>' . "\n" . '                                                <p>Your last cron execution was at <strong>';
	echo date($F2d4d8f7981ac574['datetime_format'], $F2d4d8f7981ac574['last_cache']);
	echo "</strong>. If it takes longer to run a cron than the time between executions, you will have issues as the caching will be cut off before completion.<br/><br/>The default is to run the cron every 5 minutes, but when your Streams and Lines tables grow larger it can take a fair amount of time to grab and cache this data. You can change the time to achieve a better balance between performance and data accuracy.<br/><br/><strong>Please ensure the cron format is correct, otherwise it won't run.</strong></p>" . "\n" . '                                                <div class="form-group row mb-4">' . "\n" . '                                                    <table class="table table-striped table-borderless mb-0" id="datatable-cache">' . "\n" . '                                                        <tbody>' . "\n" . '                                                            <tr>' . "\n" . '                                                                <td class="text-center">Minute</td>' . "\n" . '                                                                <td style="width:250px;"><input type="text" class="form-control text-center" id="minute" name="minute" value="';
	echo $e3c95294a1debc47;
	echo '"></td>' . "\n" . '                                                                <td class="text-center">Hour</td>' . "\n" . '                                                                <td style="width:250px;"><input type="text" class="form-control text-center" id="hour" name="hour" value="';
	echo $d08bd3f46de523f4;
	echo '"></td>' . "\n" . '                                                            </tr>' . "\n" . '                                                            <tr>' . "\n" . '                                                                <td class="text-center">Thread Count</td>' . "\n" . '                                                                <td style="width:250px;"><input type="text" class="form-control text-center" id="cache_thread_count" name="cache_thread_count" value="';
	echo intval($F2d4d8f7981ac574['cache_thread_count']);
	echo '"></td>' . "\n" . '                                                                <td class="text-center">Update Changes Only</td>' . "\n" . '                                                                <td style="width:250px;">' . "\n" . '                                                                    <input name="cache_changes" id="cache_changes" type="checkbox"';

	if ($F2d4d8f7981ac574['cache_changes'] != 1) {
	} else {
		echo ' checked ';
	}

	echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                                </td>' . "\n" . '                                                            </tr>' . "\n" . '                                                            <tr>' . "\n" . '                                                                <td class="text-center">Streams</td>' . "\n" . '                                                                <td class="text-center">' . "\n" . '                                                                    <button type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-xl">';
	echo number_format($b27a0766bc4fb317, 0);
	echo ' / ';
	echo number_format($Acd740cd0959cdfd, 0);
	echo '</button>' . "\n" . '                                                                </td>' . "\n" . '                                                                <td class="text-center">Lines</td>' . "\n" . '                                                                <td class="text-center">' . "\n" . '                                                                    <button type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-xl">';
	echo number_format($Cade224ddccf2558, 0);
	echo ' / ';
	echo number_format($Ee60e729075f9d1b, 0);
	echo '</button>' . "\n" . '                                                                </td>' . "\n" . '                                                            </tr>' . "\n" . '                                                            <tr>' . "\n" . '                                                                <td class="text-center">Series</td>' . "\n" . '                                                                <td class="text-center">' . "\n" . '                                                                    <button type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-xl">';
	echo number_format($D26e1d203e266834, 0);
	echo ' / ';
	echo number_format($ac498f333d474130, 0);
	echo '</button>' . "\n" . '                                                                </td>' . "\n" . '                                                                <td class="text-center">Time Taken</td>' . "\n" . '                                                                <td class="text-center">' . "\n" . '                                                                    <button type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-xl">';
	echo XUI::f01c2E2cfc16141E($F2d4d8f7981ac574['last_cache_taken']);
	echo '</button>' . "\n" . '                                                                </td>' . "\n" . '                                                            </tr>' . "\n" . '                                                        </tbody>' . "\n" . '                                                    </table>' . "\n" . '                                                </div>' . "\n" . '                                                ';
} else {
	echo '                                                <h5 class="card-title">Cache is Disabled</h5>' . "\n" . '                                                <p>You have chosen to disable Cache system. You can re-enable it by clicking the Enable Cache box below, however when doing so you would get best results restarting XUI on this server.</p>' . "\n" . '                                                ';
}

echo "\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:30px;">' . "\n" . '                                            ';

if ($F2d4d8f7981ac574['enable_cache']) {
	echo '                                            <li class="list-inline-item">' . "\n" . "                                                <button id=\"disable_cache\" onClick=\"api('disable_cache')\" class=\"btn btn-danger\" type=\"button\">Disable Cache</button>" . "\n" . "                                                <button id=\"regenerate_cache\" onClick=\"api('regenerate_cache')\" class=\"btn btn-info\" type=\"button\">Regenerate Cache</button>" . "\n" . '                                            </li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n" . '                                                <input name="submit_settings" type="submit" class="btn btn-primary" value="Save Cron" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                            ';
} else {
	echo '                                            <li class="list-inline-item">' . "\n" . "                                                <button id=\"enable_cache\" onClick=\"api('enable_cache')\" class=\"btn btn-success\" type=\"button\">Enable Cache</button>" . "\n" . '                                            </li>' . "\n" . '                                            ';
}

echo "\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                    <div class="tab-pane" id="connections">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n" . '                                                <h5 class="card-title">Redis Connection Handler</h5>' . "\n" . '                                                <p>The handler will allow all connections from clients to load balancers to be verified and managed using Redis rather than through mysql connections.<br/><br/><strong>Disabling Redis handler will disconnect all of your active clients, enabling it however should move the live connections from MySQL to Redis without disconnects.</strong></p>' . "\n" . '                                                <h5 class="card-title mt-4">Pros & Cons</h5>' . "\n" . "                                                <p>Before deciding whether Redis Connection Handler is right for you, you should know a few things. Firstly, enabling Redis will significantly increase XUI's ability to handle connections as the previous bottleneck would be from MySQL not being able to handle the amount of incoming client requests. You'll also find that zap time will be quicker, CPU should be lower and things will generally run quite smoothly.<br/><br/>The drawbacks from using Redis is that the live connection database is stored in memory, although a backup is periodically written, restarting XUI can result in connection losses. In addition to this, your ability to filter or search some content in the Admin or Reseller interface will be diminished. For example, with Redis on you can only sort Live Connections by Time Active ascending or descending and you cannot search the live connection list. You also lose the ability to sort by Active Connections in Lines or Content pages etc.<br/><br/>The best way to decide if Redis is right for you is to try it for yourself.</p>" . "\n" . '                                                ';

if ($F2d4d8f7981ac574['redis_handler']) {
	try {
		XUI::$redis = new Redis();
		XUI::$redis->connect(XUI::$rServers[SERVER_ID]['server_ip'], 6379);
		$Ba23222f3ed2dc08 = true;
	} catch (Exception $c34ae71903f0d920) {
		$Ba23222f3ed2dc08 = false;
	}

	try {
		XUI::$redis->auth(XUI::$rSettings['redis_password']);
		$A30685adf7a9c62d = true;
	} catch (Exception $c34ae71903f0d920) {
		$A30685adf7a9c62d = false;
	}
	echo '                                                <div class="form-group row mb-4 mt-4">' . "\n" . '                                                    <table class="table table-striped table-borderless mb-0" id="datatable-redis">' . "\n" . '                                                        <tbody>' . "\n" . '                                                            <tr>' . "\n" . '                                                                <td class="text-center">Server Status</td>' . "\n" . '                                                                <td class="text-center">' . "\n" . '                                                                    ';

	if ($Ba23222f3ed2dc08) {
		echo '                                                                    <button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed-xl">ONLINE</button>' . "\n" . '                                                                    ';
	} else {
		echo '                                                                    <button type="button" class="btn btn-danger btn-xs waves-effect waves-light btn-fixed-xl">OFFLINE</button>' . "\n" . '                                                                    ';
	}

	echo '                                                                </td>' . "\n" . '                                                                <td class="text-center">Authentication</td>' . "\n" . '                                                                <td class="text-center">' . "\n" . '                                                                    ';

	if ($A30685adf7a9c62d) {
		echo '                                                                    <button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed-xl">AUTHENTICATED</button>' . "\n" . '                                                                    ';
	} else {
		echo '                                                                    <button type="button" class="btn btn-danger btn-xs waves-effect waves-light btn-fixed-xl">INVALID PASSWORD</button>' . "\n" . '                                                                    ';
	}

	echo '                                                                </td>' . "\n" . '                                                            </tr>' . "\n" . '                                                        </tbody>' . "\n" . '                                                    </table>' . "\n" . '                                                </div>' . "\n" . '                                                ';
} else {
	echo '                                                <p><strong>You have chosen to disable Redis Connection Handler. Click the button below to re-enable it.</strong></p>' . "\n" . '                                                ';
}

echo "\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0" style="margin-top:30px;">' . "\n" . '                                            ';

if ($F2d4d8f7981ac574['redis_handler']) {
	echo '                                            <li class="list-inline-item">' . "\n" . "                                                <button id=\"disable_handler\" onClick=\"api('disable_handler')\" class=\"btn btn-danger\" type=\"button\">Disable Handler</button>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<button id=\"clear_redis\" onClick=\"api('clear_redis')\" class=\"btn btn-info\" type=\"button\">Clear Database</button>" . "\n" . '                                            </li>' . "\n" . '                                            ';
} else {
	echo '                                            <li class="list-inline-item">' . "\n" . "                                                <button id=\"enable_handler\" onClick=\"api('enable_handler')\" class=\"btn btn-success\" type=\"button\">Enable Handler</button>" . "\n" . '                                            </li>' . "\n" . '                                            ';
}

echo "\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</form>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
