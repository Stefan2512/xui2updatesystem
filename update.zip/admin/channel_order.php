<?php

include 'session.php';
include 'functions.php';

if (b1882Df698B44754()) {
} else {
	b46F5dd76F3c7421();
}

$B4a5141c87d1c427 = isset(XUI::$rRequest['override']);
$D38042213c4415a7 = array('stream' => array(), 'movie' => array(), 'series' => array(), 'radio' => array());
$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `count` FROM `streams`;');
$Aa8d8af3d37ca869 = $Fee0d5a474c96306->get_row()['count'];

if (!($Aa8d8af3d37ca869 <= 50000 || $B4a5141c87d1c427)) {
} else {
	$Fee0d5a474c96306->query('SELECT `id`, `type`, `stream_display_name`, `category_id` FROM `streams` ORDER BY `order` ASC, `stream_display_name` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if ($C740da31596f24ef['type'] == 1 || $C740da31596f24ef['type'] == 3) {
				$D38042213c4415a7['stream'][] = $C740da31596f24ef;
			} else {
				if ($C740da31596f24ef['type'] == 2) {
					$D38042213c4415a7['movie'][] = $C740da31596f24ef;
				} else {
					if ($C740da31596f24ef['type'] == 4) {
						$D38042213c4415a7['radio'][] = $C740da31596f24ef;
					} else {
						if ($C740da31596f24ef['type'] != 5) {
						} else {
							$D38042213c4415a7['series'][] = $C740da31596f24ef;
						}
					}
				}
			}
		}
	}
}

$bcf587bb39f95fd5 = 'Channel Order';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n" . '                    <div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo '                    </div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['channel_order'];
echo '</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-xl-12">' . "\r\n" . '                ';

if (50000 < $Aa8d8af3d37ca869 && !$B4a5141c87d1c427) {
	echo '                <div class="alert alert-danger" role="alert">' . "\r\n\t\t\t\t\t" . 'You have ';
	echo number_format($Aa8d8af3d37ca869, 0);
	echo ' streams in your database! This is far too many to manually order on this page and will crash your browser attempting to display them in a list, therefore manual channel ordering has been disabled.' . "\r\n" . '                    ';

	if ($B4a5141c87d1c427) {
	} else {
		echo "\t\t\t\t\t\t" . '<br/><br/><a href="channel_order?override=1" class="btn btn-danger">Continue Anyway</a>' . "\r\n\t\t\t\t\t";
	}

	echo "\t\t\t\t" . '</div>' . "\r\n" . '                ';
} else {
	echo "\t\t\t\t";

	if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == 1)) {
	} else {
		echo '                <div class="alert alert-success alert-dismissible fade show" role="alert">' . "\r\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\r\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\r\n\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t" . 'Channel order has been modified.' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
	}

	if ($F2d4d8f7981ac574['channel_number_type'] == 'manual') {
	} else {
		echo '                <div class="alert alert-warning alert-dismissible fade show" role="alert">' . "\r\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\r\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\r\n\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t";
		echo $_['channel_order_info'];
		echo "\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
	}

	echo "\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body">' . "\r\n\t\t\t\t\t\t" . '<form action="#" method="POST">' . "\r\n\t\t\t\t\t\t\t" . '<input type="hidden" id="stream_order_array" name="stream_order_array" value="" />' . "\r\n\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\r\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#order-stream" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-play mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
	echo $_['streams'];
	echo '</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#order-movie" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-movie mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
	echo $_['movies'];
	echo '</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#order-series" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-youtube-tv mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
	echo $_['episodes'];
	echo '</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#order-radio" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-radio mr-1"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
	echo $_['stations'];
	echo '</span>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\r\n" . '                                    <div class="tab-pane" id="order-stream">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_stream_l" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['stream'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-2 text-center" style="display: flex; justify-content: center; align-items: center; margin-top:-18px;">' . "\r\n" . '                                                <ul class="list-inline wizard mb-0">' . "\r\n" . '                                                    <li class="list-inline-item">' . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveLeft('stream')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-left\"></i></a>" . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveRight('stream')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-right\"></i></a>" . "\r\n" . '                                                    </li>' . "\r\n" . '                                                </ul>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_stream_r" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['stream'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n" . '                                        <ul class="list-inline wizard mb-0 add-margin-top-20">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveUp('stream')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveDown('stream')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveTop('stream')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveBottom('stream')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"AtoZ('stream')\" class=\"btn btn-info\">";
	echo $_['a_to_z'];
	echo '</a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">';
	echo $_['save_changes'];
	echo '</button>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="order-movie">' . "\r\n" . '                                        <div class="row">' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_movie_l" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['movie'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-2 text-center" style="display: flex; justify-content: center; align-items: center; margin-top:-18px;">' . "\r\n" . '                                                <ul class="list-inline wizard mb-0">' . "\r\n" . '                                                    <li class="list-inline-item">' . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveLeft('movie')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-left\"></i></a>" . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveRight('movie')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-right\"></i></a>" . "\r\n" . '                                                    </li>' . "\r\n" . '                                                </ul>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_movie_r" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['movie'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveUp('movie')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveDown('movie')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveTop('movie')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveBottom('movie')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"AtoZ('movie')\" class=\"btn btn-info\">";
	echo $_['a_to_z'];
	echo '</a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">';
	echo $_['save_changes'];
	echo '</button>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="order-series">' . "\r\n" . '                                        <div class="row">' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_series_l" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['series'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-2 text-center" style="display: flex; justify-content: center; align-items: center; margin-top:-18px;">' . "\r\n" . '                                                <ul class="list-inline wizard mb-0">' . "\r\n" . '                                                    <li class="list-inline-item">' . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveLeft('series')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-left\"></i></a>" . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveRight('series')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-right\"></i></a>" . "\r\n" . '                                                    </li>' . "\r\n" . '                                                </ul>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_series_r" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['series'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveUp('series')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveDown('series')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveTop('series')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveBottom('series')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"AtoZ('series')\" class=\"btn btn-info\">";
	echo $_['a_to_z'];
	echo '</a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">';
	echo $_['save_changes'];
	echo '</button>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="order-radio">' . "\r\n" . '                                        <div class="row">' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_radio_l" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['radio'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-2 text-center" style="display: flex; justify-content: center; align-items: center; margin-top:-18px;">' . "\r\n" . '                                                <ul class="list-inline wizard mb-0">' . "\r\n" . '                                                    <li class="list-inline-item">' . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveLeft('radio')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-left\"></i></a>" . "\r\n" . "                                                        <a href=\"javascript: void(0);\" onClick=\"MoveRight('radio')\" class=\"btn btn-info\"><i class=\"mdi mdi-chevron-right\"></i></a>" . "\r\n" . '                                                    </li>' . "\r\n" . '                                                </ul>' . "\r\n" . '                                            </div>' . "\r\n" . '                                            <div class="col-5">' . "\r\n" . '                                                <select multiple id="sort_radio_r" class="form-control" style="min-height:400px;">' . "\r\n" . '                                                ';

	foreach ($D38042213c4415a7['radio'] as $f523e362fb81d6c8) {
		echo '                                                    <option value="';
		echo intval($f523e362fb81d6c8['id']);
		echo '">';
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
		echo '</option>' . "\r\n" . '                                                ';
	}
	echo '                                                </select>' . "\r\n" . '                                            </div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveUp('radio')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveDown('radio')\" class=\"btn btn-purple\"><i class=\"mdi mdi-chevron-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveTop('radio')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-up\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"MoveBottom('radio')\" class=\"btn btn-pink\"><i class=\"mdi mdi-chevron-triple-down\"></i></a>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<a href=\"javascript: void(0);\" onClick=\"AtoZ('radio')\" class=\"btn btn-info\">";
	echo $_['a_to_z'];
	echo '</a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">';
	echo $_['save_changes'];
	echo '</button>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t" . '</form>' . "\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div>' . "\r\n" . '                ';
}

echo "\t\t\t" . '</div> ' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
