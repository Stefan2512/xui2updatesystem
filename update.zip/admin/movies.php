<?php

include 'session.php';
include 'functions.php';

if (B1882Df698B44754()) {
} else {
	b46F5DD76f3c7421();
}

$A5dcdeb6ecbbf6bd = CbE87e2A9a996111('movie');
$E6652981ffae09cc = $E79a0db1471ddfdf = array();
$Fee0d5a474c96306->query('SELECT DISTINCT(`audio_codec`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `audio_codec` IS NOT NULL AND `type` = 2 ORDER BY `audio_codec` ASC;');

foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
	$E6652981ffae09cc[] = $C740da31596f24ef['audio_codec'];
}
$Fee0d5a474c96306->query('SELECT DISTINCT(`video_codec`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `video_codec` IS NOT NULL AND `type` = 2 ORDER BY `video_codec` ASC;');

foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
	$E79a0db1471ddfdf[] = $C740da31596f24ef['video_codec'];
}
$bcf587bb39f95fd5 = 'Movies';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['movies'];
echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS) {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Movie has been added / modified.' . "\n\t\t\t\t" . '</div>' . "\n" . '                ';
} else {
	if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS_MULTI)) {
	} else {
		echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Movies are being imported in the background...' . "\n\t\t\t\t" . '</div>' . "\n" . '                ';
	}
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <input type="text" class="form-control" id="movies_search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="';
echo $_['search_movies'];
echo '...">' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="movies_server" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['server'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['all_servers'];
echo '</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == -1)) {
} else {
	echo ' selected';
}

echo '>No Servers</option>' . "\n" . '                                    ';

foreach (F6DA964066F2f5e4() as $e81220b4451f37c9) {
	echo '                                    <option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="movies_category_id" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['category'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['all_categories'];
echo '</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == -1)) {
} else {
	echo ' selected';
}

echo '>No Categories</option>' . "\n" . '                                    ';

foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
	echo '                                    <option value="';
	echo $A1925ae53e9307eb['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $A1925ae53e9307eb['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="movies_filter" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['filter'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['no_filter'];
echo '</option>' . "\n" . '                                    <option value="1"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 1)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['encoded'];
echo '</option>' . "\n" . '                                    <option value="2"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 2)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['encoding'];
echo '</option>' . "\n" . '                                    <option value="3"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 3)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['down'];
echo '</option>' . "\n" . '                                    <option value="4"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 4)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['ready'];
echo '</option>' . "\n" . '                                    <option value="5"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 5)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['direct'];
echo '</option>' . "\n" . '                                    <option value="6"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 6)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['no_tmdb_match'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t" . '<option value="7"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 7)) {
} else {
	echo ' selected';
}

echo '>Duplicate</option>' . "\n\t\t\t\t\t\t\t\t\t" . '<option value="8"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 8)) {
} else {
	echo ' selected';
}

echo '>Transcoding</option>' . "\n" . '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="movies_audio" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['audio'])) {
} else {
	echo ' selected';
}

echo '>Audio</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['audio']) && XUI::$rRequest['audio'] == '-1')) {
} else {
	echo ' selected';
}

echo '>None</option>' . "\n" . '                                    ';

foreach ($E6652981ffae09cc as $A387578f69b4c724) {
	echo '                                    <option value="';
	echo $A387578f69b4c724;
	echo '"';

	if (!(isset(XUI::$rRequest['audio']) && XUI::$rRequest['audio'] == $A387578f69b4c724)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A387578f69b4c724;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="movies_video" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['video'])) {
} else {
	echo ' selected';
}

echo '>Video</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['video']) && XUI::$rRequest['video'] == '-1')) {
} else {
	echo ' selected';
}

echo '>None</option>' . "\n" . '                                    ';

foreach ($E79a0db1471ddfdf as $A387578f69b4c724) {
	echo '                                    <option value="';
	echo $A387578f69b4c724;
	echo '"';

	if (!(isset(XUI::$rRequest['video']) && XUI::$rRequest['video'] == $A387578f69b4c724)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A387578f69b4c724;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="movies_resolution" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['resolution'])) {
} else {
	echo ' selected';
}

echo '>Quality</option>' . "\n" . '                                    ';

foreach (array(240, 360, 480, 576, 720, 1080, 1440, 2160) as $fbf4f3f4868222b7) {
	echo '                                    <option value="';
	echo $fbf4f3f4868222b7;
	echo '"';

	if (!(isset(XUI::$rRequest['resolution']) && XUI::$rRequest['resolution'] == $fbf4f3f4868222b7)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $fbf4f3f4868222b7;
	echo 'p</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="movies_show_entries" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo '                                    <option';

	if (isset(XUI::$rRequest['entries'])) {
		if (XUI::$rRequest['entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	} else {
		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n\t\t\t\t\t\t" . '<table id="datatable-streampage" class="table table-striped table-borderless dt-responsive nowrap font-normal">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                    <th class="text-center">Image</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['name'];
echo '</th>' . "\n" . '                                    ';

if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
	echo "\t\t\t\t\t\t\t\t\t" . '<th>';
	echo $_['servers'];
	echo '</th>' . "\n" . '                                    ';
} else {
	echo '                                    <th>';
	echo $_['server'];
	echo '</th>' . "\n\t\t\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['clients'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['status'];
echo '</th>' . "\n" . '                                    <th class="text-center">TMDb</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['player'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['stream_info'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
