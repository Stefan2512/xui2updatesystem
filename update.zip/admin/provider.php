<?php

include 'session.php';
include 'functions.php';

if (b1882df698b44754()) {
} else {
	b46F5Dd76F3c7421();
}

if (!isset(XUI::$rRequest['id']) || ($Ad973fd3103e20dc = getStreamProvider(XUI::$rRequest['id']))) {
	$bcf587bb39f95fd5 = 'Stream Provider';
	include 'header.php';
	echo '<div class="wrapper boxed-layout-ext"';

	if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	} else {
		echo ' style="display: none;"';
	}

	echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
	include 'topbar.php';
	echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';

	if (isset($Ad973fd3103e20dc)) {
		echo $_['edit'];
	} else {
		echo $_['add'];
	}

	echo ' Provider</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-xl-12">' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t" . '<form action="#" method="POST" data-parsley-validate="">' . "\n\t\t\t\t\t\t\t";

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="edit" value="';
		echo $Ad973fd3103e20dc['id'];
		echo '" />' . "\n" . "                            <input class='copyfrom' tabindex='-1' aria-hidden='true' id=\"stream_url\" value=\"\" style=\"position: absolute; left: -9999px;\">" . "\n\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#category-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account-card-details-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
	echo $_['details'];
	echo '</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t";

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#view-streams" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-play mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Available Streams</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                    <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#view-movies" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-movie mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Available Movies</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="category-details">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="name">Provider Name</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="name" name="name" value="';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo htmlspecialchars($Ad973fd3103e20dc['name']);
	}

	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="ip">Server IP / Domain</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="ip" name="ip" value="';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo htmlspecialchars($Ad973fd3103e20dc['ip']);
	}

	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="port">Broadcast Port</label>' . "\n" . '                                                    <div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="port" name="port" value="';

	if (isset($Ad973fd3103e20dc)) {
		echo htmlspecialchars($Ad973fd3103e20dc['port']);
	} else {
		echo '80';
	}

	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="username">Username</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="username" name="username" value="';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo htmlspecialchars($Ad973fd3103e20dc['username']);
	}

	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="password">Password</label>' . "\n" . '                                                    <div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="password" name="password" value="';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo htmlspecialchars($Ad973fd3103e20dc['password']);
	}

	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="enabled">Enabled</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="enabled" id="enabled" type="checkbox" ';

	if (isset($Ad973fd3103e20dc)) {
		if ($Ad973fd3103e20dc['enabled'] != 1) {
		} else {
			echo 'checked ';
		}
	} else {
		echo 'checked ';
	}

	echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="ssl">SSL</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="ssl" id="ssl" type="checkbox" ';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		if ($Ad973fd3103e20dc['ssl'] != 1) {
		} else {
			echo 'checked ';
		}
	}

	echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                </div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="legacy">Legacy XC</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="legacy" id="legacy" type="checkbox" ';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		if ($Ad973fd3103e20dc['legacy'] != 1) {
		} else {
			echo 'checked ';
		}
	}

	echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="hls">Use HLS</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="hls" id="hls" type="checkbox" ';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		if ($Ad973fd3103e20dc['hls'] != 1) {
		} else {
			echo 'checked ';
		}
	}

	echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_provider" type="submit" class="btn btn-primary" value="';

	if (isset($Ad973fd3103e20dc)) {
		echo $_['edit'];
	} else {
		echo $_['add'];
	}

	echo '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                    ';

	if (!isset($Ad973fd3103e20dc)) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="view-streams">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-streams" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Stream Name</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Categories</th>' . "\n" . '                                                            <th class="text-center">Modified</th>' . "\n" . '                                                            <th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		$Fee0d5a474c96306->query("SELECT `stream_id`, `category_array`, `stream_display_name`, `modified`, `stream_icon` FROM `providers_streams` WHERE `provider_id` = ? AND `type` = 'live' ORDER BY `modified` DESC, `stream_id` ASC;", $Ad973fd3103e20dc['id']);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$Eb6eccfbed89f039 = (($Ad973fd3103e20dc['ssl'] ? 'https' : 'http')) . '://' . $Ad973fd3103e20dc['ip'] . ':' . $Ad973fd3103e20dc['port'] . '/live/' . $Ad973fd3103e20dc['username'] . '/' . $Ad973fd3103e20dc['password'] . '/' . $C740da31596f24ef['stream_id'] . (($Ad973fd3103e20dc['hls'] ? '.m3u8' : ($Ad973fd3103e20dc['legacy'] ? '.ts' : '')));
			echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>    ' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
			echo $C740da31596f24ef['stream_id'];
			echo '</td>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<td>';
			echo $C740da31596f24ef['stream_display_name'];
			echo '</td>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<td>';
			echo implode(', ', json_decode($C740da31596f24ef['category_array'], true));
			echo '</td>' . "\n" . '                                                            <td class="text-center">';
			echo date('Y-m-d', $C740da31596f24ef['modified']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['modified']) . '</small>';
			echo '</td>' . "\n" . '                                                            <td class="text-center">' . "\n" . '                                                                <a href="stream?title=';
			echo urlencode($C740da31596f24ef['stream_display_name']);
			echo '&url=';
			echo urlencode($Eb6eccfbed89f039);
			echo '&icon=';
			echo urlencode($C740da31596f24ef['stream_icon']);
			echo '"><button type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-plus"></i></button></a>' . "\n" . "                                                                <button type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" title=\"Copy URL\" onClick=\"copyURL('";
			echo $Eb6eccfbed89f039;
			echo "');\"><i class=\"mdi mdi-clipboard\"></i></button>" . "\n" . '                                                            </td>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                    <div class="tab-pane" id="view-movies">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-movies" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Movie Name</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Categories</th>' . "\n" . '                                                            <th class="text-center">Modified</th>' . "\n" . '                                                            <th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		$Fee0d5a474c96306->query("SELECT `stream_id`, `category_array`, `stream_display_name`, `modified`, `stream_icon`, `channel_id` FROM `providers_streams` WHERE `provider_id` = ? AND `type` = 'movie' ORDER BY `modified` DESC, `stream_id` ASC;", $Ad973fd3103e20dc['id']);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$Eb6eccfbed89f039 = (($C740da31596f24ef['ssl'] ? 'https' : 'http')) . '://' . $Ad973fd3103e20dc['ip'] . ':' . $Ad973fd3103e20dc['port'] . '/movie/' . $Ad973fd3103e20dc['username'] . '/' . $Ad973fd3103e20dc['password'] . '/' . $C740da31596f24ef['stream_id'] . '.' . $C740da31596f24ef['channel_id'];
			echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>    ' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
			echo $C740da31596f24ef['stream_id'];
			echo '</td>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<td>';
			echo $C740da31596f24ef['stream_display_name'];
			echo '</td>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<td>';
			echo implode(', ', json_decode($C740da31596f24ef['category_array'], true));
			echo '</td>' . "\n" . '                                                            <td class="text-center">';
			echo date('Y-m-d', $C740da31596f24ef['modified']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['modified']) . '</small>';
			echo '</td>' . "\n" . '                                                            <td class="text-center">' . "\n" . '                                                                <a href="movie?title=';
			echo urlencode($C740da31596f24ef['stream_display_name']);
			echo '&path=';
			echo urlencode($Eb6eccfbed89f039);
			echo '"><button type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-plus"></i></button></a>' . "\n" . "                                                                <button type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" title=\"Copy URL\" onClick=\"copyURL('";
			echo $Eb6eccfbed89f039;
			echo "');\"><i class=\"mdi mdi-clipboard\"></i></button>" . "\n" . '                                                            </td>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                    ';
	}

	echo "\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
	include 'footer.php';
} else {
	exit();
}
