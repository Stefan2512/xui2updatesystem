<?php

include 'session.php';
include 'functions.php';

if (b1882DF698B44754()) {
} else {
	b46F5dD76F3C7421();
}

XUI::$rServers = XUI::f99d78E199d641D5(true);
$bcf587bb39f95fd5 = 'Servers';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n\t\t\t\t\t\t";
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Servers</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Order</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Status</th>' . "\n" . '                                    <th class="text-center">Proxied</th>' . "\n" . '                                    <th>Server Name</th>' . "\n" . '                                    <th class="text-center">Server IP</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Connections</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Network</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">CPU %</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">MEM %</th>' . "\n" . '                                    <th class="text-center">Ping</th>' . "\n" . '                                    <th class="text-center">Version</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach (XUI::$rServers as $e81220b4451f37c9) {
	if ($e81220b4451f37c9['server_type'] == 0) {
		$C39e5afe2a23deaa = json_decode($e81220b4451f37c9['watchdog_data'], true);

		if (is_array($C39e5afe2a23deaa)) {
		} else {
			$C39e5afe2a23deaa = array('total_mem_used_percent' => '0', 'cpu' => '0');
		}

		if (XUI::$rServers[$e81220b4451f37c9['id']]['server_online']) {
		} else {
			$C39e5afe2a23deaa['cpu'] = 0;
			$C39e5afe2a23deaa['total_mem_used_percent'] = 0;
		}

		echo "\t\t\t\t\t\t\t\t" . '<tr id="server-';
		echo $e81220b4451f37c9['id'];
		echo '">' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center"><a data-id="';
		echo $e81220b4451f37c9['id'];
		echo '" href="server_view?id=';
		echo $e81220b4451f37c9['id'];
		echo '">';
		echo($e81220b4451f37c9['order'] ?: $e81220b4451f37c9['id']);
		echo '</a></td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

		if (!$e81220b4451f37c9['enabled']) {
			echo '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
		} else {
			if ($e81220b4451f37c9['server_online']) {
				if (!$D8d681f377d877d4 && !$Ab5b854e25293d6b && $e81220b4451f37c9['xui_version'] && ($e81220b4451f37c9['xui_version'] != $a8bb73cba48fb7f6[SERVER_ID]['xui_version'] || $e81220b4451f37c9['xui_revision'] != $a8bb73cba48fb7f6[SERVER_ID]['xui_revision'])) {
					echo '<a href="javascript: void(0);" onClick="api(' . intval($e81220b4451f37c9['id']) . ", 'update');\"><i class=\"text-success mdi mdi-download tooltip\" style=\"font-size:14pt;\" title=\"An update is available! v" . $a8bb73cba48fb7f6[SERVER_ID]['xui_version'] . '"></i></a>';
				} else {
					echo '<i class="text-success fas fa-square tooltip" title="Online"></i>';
				}
			} else {
				if (0 < $e81220b4451f37c9['last_check_ago']) {
					$Af547236269d8f66 = date($F2d4d8f7981ac574['datetime_format'], $e81220b4451f37c9['last_check_ago']);
				} else {
					$Af547236269d8f66 = 'Never';
				}

				if ($e81220b4451f37c9['status'] == 3) {
					echo '<i class="text-info fas fa-square tooltip" title="Installing..."></i>';
				} else {
					if ($e81220b4451f37c9['status'] == 4) {
						echo '<i class="text-warning fas fa-square tooltip" title="Installation Failed!"></i>';
					} else {
						if ($e81220b4451f37c9['status'] == 5) {
							echo '<i class="text-info fas fa-square tooltip" title="Updating..."></i>';
						} else {
							if (!$e81220b4451f37c9['remote_status']) {
								echo "<i class=\"text-danger fas fa-square tooltip\" title=\"Can't connect on " . htmlentities($e81220b4451f37c9['server_ip']) . ':' . intval($e81220b4451f37c9['http_broadcast_port']) . '<br/>Last Ping: ' . $Af547236269d8f66 . '"></i>';
							} else {
								echo '<i class="text-danger fas fa-square tooltip" title="Last Ping: ' . $Af547236269d8f66 . '"></i>';
							}
						}
					}
				}
			}
		}

		echo '                                    </td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

		if ($e81220b4451f37c9['enable_proxy']) {
			echo '<i class="text-success fas fa-square"></i>';
		} else {
			echo '<i class="text-secondary fas fa-square"></i>';
		}

		echo '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td><a href="server_view?id=';
		echo $e81220b4451f37c9['id'];
		echo '">';
		echo $e81220b4451f37c9['server_name'];
		echo(!empty($e81220b4451f37c9['domain_name']) ? '<br/><small>' . explode(',', $e81220b4451f37c9['domain_name'])[0] . '</small>' : '');
		echo '</a></td>' . "\n" . '                                    <td class="text-center">' . "\n" . "                                        <a onClick=\"whois('";
		echo $e81220b4451f37c9['server_ip'];
		echo "');\" href=\"javascript: void(0);\">";
		echo $e81220b4451f37c9['server_ip'];
		echo '</a>' . "\n" . '                                        ';

		if (0 >= strlen($e81220b4451f37c9['private_ip'])) {
		} else {
			echo "                                        <br/><small style=\"font-size: 8pt;\">private: <a onClick=\"whois('";
			echo $e81220b4451f37c9['private_ip'];
			echo "');\" href=\"javascript: void(0);\">";
			echo $e81220b4451f37c9['private_ip'];
			echo '</a></small>' . "\n" . '                                        ';
		}

		echo '                                    </td>' . "\n" . '                                    <td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t";

		if (XUI::$rSettings['redis_handler']) {
			$ec5b28bb1cbf9f2d = $e81220b4451f37c9['connections'];
		} else {
			$ec5b28bb1cbf9f2d = bEeb53575450629a($e81220b4451f37c9['id']);
		}

		if (aACD47D8157A1A09('adv', 'live_connections')) {
			$ec5b28bb1cbf9f2d = '<a href="./live_connections?server=' . $e81220b4451f37c9['id'] . "\"><button type='button' class='btn btn-dark bg-animate btn-xs waves-effect waves-light no-border'>" . number_format($ec5b28bb1cbf9f2d, 0) . '</button></a>';
		} else {
			$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-dark bg-animate btn-xs waves-effect waves-light no-border'>" . number_format($ec5b28bb1cbf9f2d, 0) . '</button>';
		}

		echo $ec5b28bb1cbf9f2d;
		echo "\t\t\t\t\t\t\t\t\t" . '<br/><small>of ';
		echo number_format($e81220b4451f37c9['total_clients'], 0);
		echo '</small>' . "\n" . '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n" . '                                        <button type="button" class="btn btn-dark bg-animate btn-xs waves-effect waves-light no-border"><span id="header_streams_up">';
		echo number_format($C39e5afe2a23deaa['bytes_sent'] / 125000, 0);
		echo '</span> <i class="mdi mdi-arrow-up-thick"></i> &nbsp; <span id="header_streams_down">';
		echo number_format($C39e5afe2a23deaa['bytes_received'] / 125000, 0);
		echo '</span> <i class="mdi mdi-arrow-down-thick"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<br/><small>';
		echo number_format($e81220b4451f37c9['network_guaranteed_speed'], 0);
		echo ' Mbps</small>' . "\n" . '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n" . '                                        ';

		if (intval($C39e5afe2a23deaa['cpu']) <= 34) {
			$Ac54397e06e8e862 = '#23b397';
		} else {
			if (intval($C39e5afe2a23deaa['cpu']) <= 67) {
				$Ac54397e06e8e862 = '#f8cc6b';
			} else {
				$Ac54397e06e8e862 = '#f0643b';
			}
		}

		echo '                                        <input data-plugin="knob" data-width="48" data-height="48" data-bgColor="';

		if ($D4253f9520627819['theme'] == 1) {
			echo '#7e8e9d';
		} else {
			echo '#ebeff2';
		}

		echo '" data-fgColor="';
		echo $Ac54397e06e8e862;
		echo '" data-readOnly=true value="';
		echo intval($C39e5afe2a23deaa['cpu']);
		echo '"/>' . "\n" . '                                    </td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

		if (intval($C39e5afe2a23deaa['total_mem_used_percent']) <= 34) {
			$Ac54397e06e8e862 = '#23b397';
		} else {
			if (intval($C39e5afe2a23deaa['total_mem_used_percent']) <= 67) {
				$Ac54397e06e8e862 = '#f8cc6b';
			} else {
				$Ac54397e06e8e862 = '#f0643b';
			}
		}

		echo '                                        <input data-plugin="knob" data-width="48" data-height="48" data-bgColor="';

		if ($D4253f9520627819['theme'] == 1) {
			echo '#7e8e9d';
		} else {
			echo '#ebeff2';
		}

		echo '" data-fgColor="';
		echo $Ac54397e06e8e862;
		echo '" data-readOnly=true value="';
		echo intval($C39e5afe2a23deaa['total_mem_used_percent']);
		echo '"/>' . "\n" . '                                    </td>' . "\n" . "                                    <td class=\"text-center\"><button type='button' class='btn btn-light btn-xs waves-effect waves-light'>";
		echo number_format(($e81220b4451f37c9['server_online'] ? $e81220b4451f37c9['ping'] : 0), 0);
		echo ' ms</button></td>' . "\n" . '                                    <td class="text-center">' . "\n" . "                                        <button type='button' class='btn ";

		if ($e81220b4451f37c9['xui_version'] != $a8bb73cba48fb7f6[SERVER_ID]['xui_version'] || $e81220b4451f37c9['xui_revision'] != $a8bb73cba48fb7f6[SERVER_ID]['xui_revision']) {
			echo 'btn-warning';
		} else {
			echo 'btn-light';
		}

		echo " btn-xs waves-effect waves-light'>" . "\n" . '                                            ';

		if ($e81220b4451f37c9['xui_version']) {
			echo $e81220b4451f37c9['xui_version'];

			if (!$e81220b4451f37c9['xui_revision']) {
			} else {
				echo ' R' . $e81220b4451f37c9['xui_revision'];
			}
		} else {
			echo 'N/A';
		}

		echo '                                        </button>' . "\n" . '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t\t";

		if (aacd47d8157a1A09('adv', 'edit_server')) {
			if (XUI::$rSettings['group_buttons']) {
				echo "\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group dropdown">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dropdown-menu dropdown-menu-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item btn-reboot-server" href="javascript:void(0);" data-id="';
				echo $e81220b4451f37c9['id'];
				echo '">Server Tools</a>' . "\n" . '                                                <a class="dropdown-item" href="javascript:void(0);" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'restart');\">Restart Live Streams</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'start');\">Start All Streams</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'stop');\">Stop All Streams</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'kill');\">Kill Connections</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="./server?id=';
				echo $e81220b4451f37c9['id'];
				echo '">Edit Server</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";

				if ($e81220b4451f37c9['enable_proxy']) {
					echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'disable_proxy');\">Disable Proxy</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
				} else {
					echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'enable_proxy');\">Enable Proxy</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
				}

				if ($e81220b4451f37c9['is_main'] != 0) {
				} else {
					if ($e81220b4451f37c9['enabled']) {
						echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
						echo $e81220b4451f37c9['id'];
						echo ", 'disable');\">Disable Server</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
					} else {
						echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
						echo $e81220b4451f37c9['id'];
						echo ", 'enable');\">Enable Server</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
					}

					echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'delete');\">Delete Server</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t";
			} else {
				echo "\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="Server Tools" class="btn btn-light waves-effect waves-light btn-xs btn-reboot-server tooltip" data-id="';
				echo $e81220b4451f37c9['id'];
				echo '"><i class="mdi mdi-creation"></i></button>' . "\n" . '                                            <button type="button" title="Restart Live Streams" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'restart');\"><i class=\"mdi mdi-refresh\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="Start All Streams" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'start');\"><i class=\"mdi mdi-play\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="Stop All Streams" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="Kill All Connections" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'kill');\"><i class=\"fas fa-hammer\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./server?id=';
				echo $e81220b4451f37c9['id'];
				echo '"><button type="button" title="Edit Server" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>' . "\n" . '                                            ';

				if ($e81220b4451f37c9['enable_proxy']) {
					echo '                                            <button type="button" title="Disable Proxy" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'disable_proxy');\"><i class=\"mdi mdi-shield-off-outline\"></i></button>" . "\n" . '                                            ';
				} else {
					echo '                                            <button type="button" title="Enable Proxy" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'enable_proxy');\"><i class=\"mdi mdi-shield-check-outline\"></i></button>" . "\n" . '                                            ';
				}

				if ($e81220b4451f37c9['is_main'] == 0) {
					if ($e81220b4451f37c9['enabled']) {
						echo '                                            <button type="button" title="Disable Server" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
						echo $e81220b4451f37c9['id'];
						echo ", 'disable');\"><i class=\"mdi mdi-close-network-outline\"></i></button>" . "\n" . '                                            ';
					} else {
						echo '                                            <button type="button" title="Enable Server" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
						echo $e81220b4451f37c9['id'];
						echo ", 'enable');\"><i class=\"mdi mdi-access-point-network\"></i></button>" . "\n" . '                                            ';
					}

					echo '                                            <button type="button" title="Delete Server" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t";
				} else {
					echo '                                            <button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-access-point-network"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-close"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t";
			}
		} else {
			echo '--';
		}

		echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t";
	}
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
