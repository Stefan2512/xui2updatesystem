<?php

if (defined('XUI_HOME')) {
} else {
	define('XUI_HOME', '/home/xui/');
}

require_once XUI_HOME . 'includes/admin.php';

if (!$F61f585ee1fe12b7) {
} else {
	$F2d4d8f7981ac574['js_navigate'] = 0;
}

if (!isset($_SESSION['hash'])) {
} else {
	$D4253f9520627819 = FE76C4BCaf81BAA4($_SESSION['hash']);

	if (0 >= strlen($D4253f9520627819['timezone'])) {
	} else {
		date_default_timezone_set($D4253f9520627819['timezone']);
	}

	if (isset($_COOKIE['hue']) && $_COOKIE['hue'] == $D4253f9520627819['hue']) {
	} else {
		setcookie('hue', $D4253f9520627819['hue'], time() + 604800);
	}

	if (isset($_COOKIE['theme']) && $_COOKIE['theme'] == $D4253f9520627819['theme']) {
	} else {
		setcookie('theme', $D4253f9520627819['theme'], time() + 604800);
	}

	$B2ff75c438fb3031 = F0AcF9DE3389B116($D4253f9520627819['member_group_id']);
	$B2ff75c438fb3031['advanced'] = json_decode($B2ff75c438fb3031['allowed_pages'], true);
	$c59ec257c284c894 = c7aFD69eDc2a2940();
	$ee7553b0caebc8c4 = ($F2d4d8f7981ac574['ip_subnet_match'] ? implode('.', array_slice(explode('.', $_SESSION['ip']), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $_SESSION['ip'] == $c59ec257c284c894);

	if (!$D4253f9520627819 || !$B2ff75c438fb3031 || !$B2ff75c438fb3031['is_admin'] || !$ee7553b0caebc8c4 && $F2d4d8f7981ac574['ip_logout'] || $_SESSION['verify'] != md5($D4253f9520627819['username'] . '||' . $D4253f9520627819['password'])) {
		unset($D4253f9520627819, $B2ff75c438fb3031);

		bC6a5B2af3Da765D();
		header('Location: index');

		exit();
	}

	if ($_SESSION['ip'] == $c59ec257c284c894 || $F2d4d8f7981ac574['ip_logout']) {
	} else {
		$_SESSION['ip'] = $c59ec257c284c894;
	}

	$f0a85bb7cb144853 = false;

	foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
		if (!(!$e81220b4451f37c9['server_online'] && $e81220b4451f37c9['enabled'] && $e81220b4451f37c9['status'] != 3 && $e81220b4451f37c9['status'] != 5)) {
		} else {
			$f0a85bb7cb144853 = true;
		}
	}
	$D8a272f675608cb9 = false;

	foreach ($Fd8279be5302940a as $e81220b4451f37c9) {
		if (!(!$e81220b4451f37c9['server_online'] && $e81220b4451f37c9['enabled'] && $e81220b4451f37c9['status'] != 3 && $e81220b4451f37c9['status'] != 5)) {
		} else {
			$D8a272f675608cb9 = true;
		}
	}
	$F9bec54f0f809272 = false;

	if (version_compare($a8bb73cba48fb7f6[SERVER_ID]['xui_version'], XUI::$rSettings['update_version'], '>=')) {
	} else {
		$F9bec54f0f809272 = true;
	}
}

if (!isset(XUI::$rRequest['status'])) {
} else {
	$B4a5f8dc1f8d260c = intval(XUI::$rRequest['status']);
	$C4afe46ee5612bc9 = XUI::$rRequest;
	unset($C4afe46ee5612bc9['status']);
	$f797597e1012696d = d83F89aB0B71b235($C4afe46ee5612bc9);
}

if (D451DBADaA63fD18() == 'setup') {
} else {
	$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `count` FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `users_groups`.`is_admin` = 1;');

	if ($Fee0d5a474c96306->get_row()['count'] != 0) {
	} else {
		header('Location: ./setup');

		exit();
	}
}
