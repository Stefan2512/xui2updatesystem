<?php

include 'session.php';
include 'functions.php';

if (B1882df698B44754()) {
} else {
	b46F5DD76f3c7421();
}

if (!isset(XUI::$rRequest['id'])) {
} else {
	if (!isset(XUI::$rRequest['import']) && AAcd47d8157a1A09('adv', 'edit_stream')) {
		$f523e362fb81d6c8 = e5eceb32f67D5e70(XUI::$rRequest['id']);

		if ($f523e362fb81d6c8 && $f523e362fb81d6c8['type'] == 1) {
		} else {
			b46f5dd76f3C7421();
		}
	} else {
		exit();
	}
}

$C880bd9f48000558 = Eaa3B74E26a5B8DC();
$f86c7f12032c787a = cCe66F113d4f4390();
$fec9c81ecb7b04b5 = eFe0cE577Fb769bC();
$Beb96c2a189d2e62 = array();
$d8c7b811bd049853 = array(array());

foreach ($C880bd9f48000558 as $d8a1409105424710) {
	$d8c7b811bd049853[$d8a1409105424710['id']] = json_decode($d8a1409105424710['data'], true);
}
$e80d13748eba016a = array(array('id' => 'source', 'parent' => '#', 'text' => "<strong class='btn btn-success waves-effect waves-light btn-xs'>Online</strong>", 'icon' => 'mdi mdi-play', 'state' => array('opened' => true)), array('id' => 'offline', 'parent' => '#', 'text' => "<strong class='btn btn-secondary waves-effect waves-light btn-xs'>Offline</strong>", 'icon' => 'mdi mdi-stop', 'state' => array('opened' => true)));
$c619fbf397c935f7 = $Dfb9bf4b40a2ec4c = array();

foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
	$Dfb9bf4b40a2ec4c[$e81220b4451f37c9['id']] = $e81220b4451f37c9['video_devices'];
	$c619fbf397c935f7[$e81220b4451f37c9['id']] = $e81220b4451f37c9['audio_devices'];
}

if (isset($f523e362fb81d6c8)) {
	$c1af28817ca114e6 = Cb4FCdA8e433B44e(XUI::$rRequest['id']);
	$B8616a8de43e3fe8 = BB9fe2fDE295e476(XUI::$rRequest['id']);

	foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
		if (isset($B8616a8de43e3fe8[intval($e81220b4451f37c9['id'])])) {
			if ($B8616a8de43e3fe8[intval($e81220b4451f37c9['id'])]['parent_id'] != 0) {
				$cceca8bbcbeb112d = intval($B8616a8de43e3fe8[intval($e81220b4451f37c9['id'])]['parent_id']);
			} else {
				$cceca8bbcbeb112d = 'source';
			}

			if (!$B8616a8de43e3fe8[intval($e81220b4451f37c9['id'])]['on_demand']) {
			} else {
				$Beb96c2a189d2e62[] = intval($e81220b4451f37c9['id']);
			}
		} else {
			$cceca8bbcbeb112d = 'offline';
		}

		$e80d13748eba016a[] = array('id' => $e81220b4451f37c9['id'], 'parent' => $cceca8bbcbeb112d, 'text' => $e81220b4451f37c9['server_name'], 'icon' => 'mdi mdi-server-network', 'state' => array('opened' => true));
	}

	if (!($f523e362fb81d6c8['epg_api'] && 0 < strlen($f523e362fb81d6c8['channel_id']))) {
	} else {
		$Fee0d5a474c96306->query('SELECT `name` FROM `epg_api` WHERE `callSign` = ?;', $f523e362fb81d6c8['channel_id']);

		if (0 < $Fee0d5a474c96306->num_rows()) {
			$f523e362fb81d6c8['epg_api_name'] = $Fee0d5a474c96306->get_row()['name'];
		} else {
			$f523e362fb81d6c8['epg_api_name'] = 'No longer available.';
		}
	}
} else {
	if (aAcD47d8157a1a09('adv', 'add_stream')) {
		foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
			$e80d13748eba016a[] = array('id' => $e81220b4451f37c9['id'], 'parent' => 'offline', 'text' => $e81220b4451f37c9['server_name'], 'icon' => 'mdi mdi-server-network', 'state' => array('opened' => true));
		}
	} else {
		exit();
	}
}

$bcf587bb39f95fd5 = 'Stream';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';

if (isset($f523e362fb81d6c8['id'])) {
	echo $f523e362fb81d6c8['stream_display_name'];
} else {
	if (isset(XUI::$rRequest['import'])) {
		echo 'Import Streams';
	} else {
		echo 'Add Stream';
	}
}

echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-xl-12">' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t" . '<form';

if (!isset(XUI::$rRequest['import'])) {
} else {
	echo ' enctype="multipart/form-data"';
}

echo ' action="#" method="POST" id="stream_form" data-parsley-validate="">' . "\n\t\t\t\t\t\t\t";

if (!isset($f523e362fb81d6c8['id'])) {
} else {
	echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="edit" value="';
	echo $f523e362fb81d6c8['id'];
	echo '" />' . "\n\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="server_tree_data" id="server_tree_data" value="" />' . "\n" . '                            <input type="hidden" name="od_tree_data" id="od_tree_data" value="" />' . "\n" . '                            <input type="hidden" name="epg_api" id="epg_api" value="';
echo(isset($f523e362fb81d6c8) ? $f523e362fb81d6c8['epg_api'] : 0);
echo '" />' . "\n" . '                            <input type="hidden" name="external_push" id="external_push" value="" />' . "\n" . '                            <input type="hidden" name="bouquet_create_list" id="bouquet_create_list" value="" />' . "\n" . '                            <input type="hidden" name="category_create_list" id="category_create_list" value="" />' . "\n\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#stream-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account-card-details-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Details</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                    ';

if (isset(XUI::$rRequest['import'])) {
} else {
	echo '                                    <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#stream-sources" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-arrow-up-down-bold-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Sources</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                    ';
}

echo "\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#advanced-options" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-folder-alert-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Advanced</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t";

if (isset(XUI::$rRequest['import'])) {
} else {
	echo "\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#stream-map" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-map mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Map</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#epg-options" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-television-guide mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">EPG</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                    ';

	if ($F61f585ee1fe12b7) {
	} else {
		echo '                                    <li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#rtmp-push" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-upload-network-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">RTMP Push</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                    ';
	}
}

echo "\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#load-balancing" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-server-network mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Servers</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="stream-details">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";

if (!isset(XUI::$rRequest['import'])) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="stream_display_name">Stream Name</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="stream_display_name" name="stream_display_name" value="';

	if (isset($f523e362fb81d6c8)) {
		echo htmlspecialchars($f523e362fb81d6c8['stream_display_name']);
	} else {
		if (!isset(XUI::$rRequest['title'])) {
		} else {
			echo str_replace('"', '&quot;', XUI::$rRequest['title']);
		}
	}

	echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="stream_icon">Stream Logo</label>' . "\n" . '                                                    <div class="col-md-9 input-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="stream_icon" name="stream_icon" value="';

	if (isset($f523e362fb81d6c8)) {
		echo htmlspecialchars($f523e362fb81d6c8['stream_icon']);
	} else {
		if (!isset(XUI::$rRequest['icon'])) {
		} else {
			echo str_replace('"', '&quot;', XUI::$rRequest['icon']);
		}
	}

	echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="input-group-append">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript:void(0)" onclick="openImage(this)" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-eye"></i></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
} else {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="m3u_file">M3U</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="file" id="m3u_file" name="m3u_file" style="padding-top: 5px;" />' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="category_id">Categories</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n" . '                                                        <select name="category_id[]" id="category_id" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (cBE87e2A9a996111('live') as $A1925ae53e9307eb) {
	echo '                                                            <option ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		if (!in_array(intval($A1925ae53e9307eb['id']), json_decode($f523e362fb81d6c8['category_id'], true))) {
		} else {
			echo 'selected ';
		}
	}

	echo 'value="';
	echo $A1925ae53e9307eb['id'];
	echo '">';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n" . '                                                        <div id="category_create" class="alert bg-dark text-white border-0 mt-2 mb-0" role="alert" style="display: none;">' . "\n" . '                                                            <strong>New Categories:</strong> <span id="category_new"></span>' . "\n" . '                                                        </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                </div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="bouquets">Bouquets</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="bouquets[]" id="bouquets" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (d7A15E0C2d9BECe1() as $ddf0508b312dbfb8) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		if (!in_array($f523e362fb81d6c8['id'], json_decode($ddf0508b312dbfb8['bouquet_channels'], true))) {
		} else {
			echo 'selected ';
		}
	}

	echo 'value="';
	echo $ddf0508b312dbfb8['id'];
	echo '">';
	echo $ddf0508b312dbfb8['bouquet_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n" . '                                                        <div id="bouquet_create" class="alert bg-dark text-white border-0 mt-2 mb-0" role="alert" style="display: none;">' . "\n" . '                                                            <strong>New Bouquets:</strong> <span id="bouquet_new"></span>' . "\n" . '                                                        </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="notes">Notes</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<textarea id="notes" name="notes" class="form-control" rows="3" placeholder="">';

if (!isset($f523e362fb81d6c8)) {
} else {
	echo htmlspecialchars($f523e362fb81d6c8['notes']);
}

echo '</textarea>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="nextb list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Next</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                    ';

if (isset(XUI::$rRequest['import'])) {
} else {
	echo '                                    <div class="tab-pane" id="stream-sources">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n" . '                                                <table id="datatable-sources" class="table table-striped table-borderless mb-0">' . "\n" . '                                                    <thead>' . "\n" . '                                                        <tr>' . "\n" . '                                                            <th>URL</th>' . "\n" . '                                                            ';

	if ($F61f585ee1fe12b7) {
	} else {
		echo '                                                            <th class="text-center">Stream Info</th>' . "\n" . '                                                            ';
	}

	echo '                                                        </tr>' . "\n" . '                                                    </thead>' . "\n" . '                                                    <tbody class="streams">' . "\n" . '                                                        ';

	if (isset($f523e362fb81d6c8)) {
		$C12bfc7c1eac9fdf = json_decode($f523e362fb81d6c8['stream_source'], true);

		if ($C12bfc7c1eac9fdf) {
		} else {
			$C12bfc7c1eac9fdf = array('');
		}
	} else {
		if (isset(XUI::$rRequest['url'])) {
			$C12bfc7c1eac9fdf = array(str_replace('"', '&quot;', XUI::$rRequest['url']));
		} else {
			$C12bfc7c1eac9fdf = array('');
		}
	}

	$Ea22c4a9ab5b2176 = 0;

	foreach ($C12bfc7c1eac9fdf as $c8d91fcd2309e48a) {
		$Ea22c4a9ab5b2176++;
		echo '                                                        <tr class="stream_info">' . "\n" . '                                                            <td class="input-group">' . "\n" . '                                                                <div class="input-group-append">' . "\n" . '                                                                    <button class="btn btn-secondary waves-effect waves-light btn-fixed-xs" onClick="moveUp(this);" type="button"><i class="mdi mdi-chevron-up"></i></button>' . "\n" . '                                                                    <button class="btn btn-secondary waves-effect waves-light btn-fixed-xs" onClick="moveDown(this);" type="button"><i class="mdi mdi-chevron-down"></i></button>' . "\n" . '                                                                </div>' . "\n" . '                                                                <input type="text" id="stream_source" name="stream_source[]" class="form-control" value="';
		echo htmlspecialchars($c8d91fcd2309e48a);
		echo '">' . "\n" . '                                                                <div class="input-group-append">' . "\n" . '                                                                    <button class="btn btn-danger waves-effect waves-light btn-fixed-xs" onClick="removeStream(this);" type="button"><i class="mdi mdi-close"></i></button>' . "\n" . '                                                                </div>' . "\n" . '                                                            </td>' . "\n" . '                                                            ';

		if ($F61f585ee1fe12b7) {
		} else {
			echo '                                                            <td class="text-center" id="stream_info" style="width:380px;">' . "\n" . "                                                                <table class='table-data' style='width: 380px;' align='center'><tbody><tr><td colspan='5'>Not scanned</td></tr></tbody></table>" . "\n" . '                                                            </td>' . "\n" . '                                                            ';
		}

		echo '                                                        </tr>' . "\n" . '                                                        ';
	}
	echo '                                                    </tbody>' . "\n" . '                                                </table>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div id="capture_form" style="display: none;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="capture_server_id">Capture Server</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="capture_server_id" id="capture_server_id" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
		echo $e81220b4451f37c9['id'];
		echo '"';

		if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['capture_server_id'] == $e81220b4451f37c9['id'])) {
		} else {
			echo ' selected';
		}

		echo '>';
		echo $e81220b4451f37c9['server_name'];
		echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="video_device_id">Video Input</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="video_device_id" id="video_device_id" class="form-control" data-toggle="select2"></select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="audio_device_id">Audio Input</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="audio_device_id" id="audio_device_id" class="form-control" data-toggle="select2"></select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                            </div>' . "\n" . '                                        </div>' . "\n" . '                                        <ul class="list-inline wizard mb-0" style="padding-top: 30px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="prevb list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n" . '                                            </li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span id="source_form">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<a onClick="addStream();" class="btn btn-primary btn-pointer">Add Row</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";

	if ($F61f585ee1fe12b7) {
	} else {
		echo '                                                <li class="list-inline-item">' . "\n" . '                                                    <button type="button" style="width: 100%" class="btn btn-pink btn-pointer" id="provider-streams">Providers</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<a onClick="scanSources();" class="btn btn-info btn-pointer">Scan Sources</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<!--<a onClick="toggleCapture();" class="btn btn-info btn-pointer">Toggle Mode</a>-->' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary nextb">Next</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n" . '                                    </div>' . "\n" . '                                    ';
}

echo "\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="advanced-options">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="gen_timestamps">Generate PTS <i title="Allow FFmpeg to generate presentation timestamps for you to achieve better synchronization with the stream codecs. In some streams this can cause de-sync." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="gen_timestamps" id="gen_timestamps" type="checkbox" ';

if (isset($f523e362fb81d6c8)) {
	if ($f523e362fb81d6c8['gen_timestamps'] != 1) {
	} else {
		echo 'checked ';
	}
} else {
	echo 'checked ';
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="read_native">Native Frames <i title="You should always read live streams as non-native frames. However if you are streaming static video files, set this to true otherwise the encoding process will fail." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="read_native" id="read_native" type="checkbox" ';

if (!isset($f523e362fb81d6c8)) {
} else {
	if ($f523e362fb81d6c8['read_native'] != 1) {
	} else {
		echo 'checked ';
	}
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="stream_all">Stream All Codecs <i title="This option will stream all codecs from your stream. Some streams have more than one audio/video/subtitles channels." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="stream_all" id="stream_all" type="checkbox" ';

if (!isset($f523e362fb81d6c8)) {
} else {
	if ($f523e362fb81d6c8['stream_all'] != 1) {
	} else {
		echo 'checked ';
	}
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="allow_record">Allow Recording</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="allow_record" id="allow_record" type="checkbox" ';

if (isset($f523e362fb81d6c8)) {
	if ($f523e362fb81d6c8['allow_record'] != 1) {
	} else {
		echo 'checked ';
	}
} else {
	echo 'checked ';
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<label class=\"col-md-3 col-form-label\" for=\"direct_source\">Direct Source <i title=\"Don't run source through XUI, just redirect instead.\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="direct_source" id="direct_source" type="checkbox" ';

if (!isset($f523e362fb81d6c8)) {
} else {
	if ($f523e362fb81d6c8['direct_source'] != 1) {
	} else {
		echo 'checked ';
	}
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-4 col-form-label" for="direct_proxy">Direct Stream <i title="When using direct source, hide the original URL by proxying the live stream through your servers via UDP. MPEG-TS and HLS is supported as an input format, however only MPEG-TS is supported as an output format to clients.<br/><br/>Experimental! This may not work for all streams." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="direct_proxy" id="direct_proxy" type="checkbox" ';

if (!isset($f523e362fb81d6c8)) {
} else {
	if ($f523e362fb81d6c8['direct_proxy'] != 1) {
	} else {
		echo 'checked ';
	}
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                ';

if (!isset(XUI::$rRequest['import'])) {
} else {
	echo '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="add_source_as_backup">Add Source as Backup <i title="If an identical stream name is found, or the XMLTV ID matches an existing stream, the source will be added as a backup. The existing stream options will be kept." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="add_source_as_backup" id="add_source_as_backup" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-4 col-form-label" for="update_existing">Update Existing <i title="If the source exists, overwrite it with the new title and stream options." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="update_existing" id="update_existing" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                ';
}

echo '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="fps_restart">Restart on FPS Drop <i title="Enable restart on FPS drop, set the threshold accordingly." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="fps_restart" id="fps_restart" type="checkbox" ';

if (!isset($f523e362fb81d6c8)) {
} else {
	if ($f523e362fb81d6c8['fps_restart'] != 1) {
	} else {
		echo 'checked ';
	}
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<label class=\"col-md-4 col-form-label\" for=\"fps_threshold\">FPS Threshold % <i title=\"Stream will restart if it drops below x% of it's original FPS. Maximum of 100%.\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="fps_threshold" name="fps_threshold" value="';

if (isset($f523e362fb81d6c8)) {
	echo $f523e362fb81d6c8['fps_threshold'];
} else {
	echo '90';
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<label class=\"col-md-3 col-form-label\" for=\"custom_sid\">Custom Channel SID <i title=\"Here you can specify the SID of the channel in order to work with the epg on the enigma2 devices. You have to specify the code with the ':' but without the first number, 1 or 4097 . Example: if we have this code:  '1:0:1:13f:157c:13e:820000:0:0:0:2097' then you have to add on this field:  ':0:1:13f:157c:13e:820000:0:0:0:\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="custom_sid" name="custom_sid" value="';

if (!isset($f523e362fb81d6c8)) {
} else {
	echo htmlspecialchars($f523e362fb81d6c8['custom_sid']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="probesize_ondemand">On Demand Probesize <i title="Adjustable probesize for ondemand streams. Adjust this setting if you experience issues with no audio." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="probesize_ondemand" name="probesize_ondemand" value="';

if (isset($f523e362fb81d6c8)) {
	echo $f523e362fb81d6c8['probesize_ondemand'];
} else {
	echo $F2d4d8f7981ac574['probesize_ondemand'];
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-4 col-form-label" for="delay_minutes">Minute Delay <i title="Delay stream by X minutes. Will not work with on demand streams." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="delay_minutes" name="delay_minutes" value="';

if (isset($f523e362fb81d6c8)) {
	echo $f523e362fb81d6c8['delay_minutes'];
} else {
	echo '0';
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="user_agent">User Agent</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="user_agent" name="user_agent" value="';

if (isset($c1af28817ca114e6[1])) {
	echo htmlspecialchars($c1af28817ca114e6[1]['value']);
} else {
	echo htmlspecialchars($f86c7f12032c787a['user_agent']['argument_default_value']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="http_proxy">HTTP Proxy <i title="Format: ip:port" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="http_proxy" name="http_proxy" value="';

if (isset($c1af28817ca114e6[2])) {
	echo htmlspecialchars($c1af28817ca114e6[2]['value']);
} else {
	echo htmlspecialchars($f86c7f12032c787a['proxy']['argument_default_value']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="cookie">Cookie <i title="Format: key=value;" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="cookie" name="cookie" value="';

if (isset($c1af28817ca114e6[17])) {
	echo htmlspecialchars($c1af28817ca114e6[17]['value']);
} else {
	echo htmlspecialchars($f86c7f12032c787a['cookie']['argument_default_value']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="headers">Headers <i title="FFmpeg -headers command." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="headers" name="headers" value="';

if (isset($c1af28817ca114e6[19])) {
	echo htmlspecialchars($c1af28817ca114e6[19]['value']);
} else {
	echo htmlspecialchars($f86c7f12032c787a['headers']['argument_default_value']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="transcode_profile_id">Transcoding Profile <i title="Sometimes, in order to make a stream compatible with most devices, it must be transcoded. Please note that the transcode will only be applied to the server(s) that take the stream directly from the source, all other servers attached to the transcoding server will not transcode the stream." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="transcode_profile_id" id="transcode_profile_id" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

if (!isset($f523e362fb81d6c8)) {
} else {
	if (intval($f523e362fb81d6c8['transcode_profile_id']) != 0) {
	} else {
		echo 'selected ';
	}
}

echo 'value="0">Transcoding Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($fec9c81ecb7b04b5 as $b8a339227222357b) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		if (intval($f523e362fb81d6c8['transcode_profile_id']) != intval($b8a339227222357b['profile_id'])) {
		} else {
			echo 'selected ';
		}
	}

	echo 'value="';
	echo $b8a339227222357b['profile_id'];
	echo '">';
	echo $b8a339227222357b['profile_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="days_to_restart">Auto-Restart</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-7">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
$ad9e78094ea46852 = array('days' => array(), 'at' => '06:00');

if (!isset($f523e362fb81d6c8)) {
} else {
	if (!strlen($f523e362fb81d6c8['auto_restart'])) {
	} else {
		$ad9e78094ea46852 = json_decode($f523e362fb81d6c8['auto_restart'], true);

		if (isset($ad9e78094ea46852['days'])) {
		} else {
			$ad9e78094ea46852['days'] = array();
		}

		if (isset($ad9e78094ea46852['at'])) {
		} else {
			$ad9e78094ea46852['at'] = '06:00';
		}
	}
}

echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="days_to_restart" name="days_to_restart[]" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose ...">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') as $d20afc15ac839efc) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $d20afc15ac839efc;
	echo '"';

	if (!in_array($d20afc15ac839efc, $ad9e78094ea46852['days'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $d20afc15ac839efc;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="input-group clockpicker" data-placement="top" data-align="top" data-autoclose="true">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input id="time_to_restart" name="time_to_restart" type="text" class="form-control text-center" value="';
echo $ad9e78094ea46852['at'];
echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="input-group-append">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="input-group-text"><i class="mdi mdi-clock-outline"></i></span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n" . '                                                    ';
$Ab17a088c3341b0d = (isset($f523e362fb81d6c8) ? (json_decode($f523e362fb81d6c8['adaptive_link'], true) ?: array()) : array());
$E68805a618a568a6 = array();

if (0 >= count($Ab17a088c3341b0d)) {
} else {
	$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Ab17a088c3341b0d)) . ');');

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$E68805a618a568a6[$C740da31596f24ef['id']] = '[' . $C740da31596f24ef['id'] . '] ' . $C740da31596f24ef['stream_display_name'];
	}
}

echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<label class=\"col-md-3 col-form-label\" for=\"adaptive_link\">Adaptive Link  <i title=\"Link multiple streams together when HLS is requested, the player will select a suitable stream based on the available bandwidth. The selected streams do not need to be in the line's bouquet, or any bouquet at all. MPEG-TS will play this stream normally.\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="adaptive_link[]" id="adaptive_link" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose ...">' . "\n" . '                                                            ';

foreach ($Ab17a088c3341b0d as $ba78a3ba07e942ec) {
	echo '                                                            <option value="';
	echo $ba78a3ba07e942ec;
	echo '" selected="selected">';
	echo $E68805a618a568a6[$ba78a3ba07e942ec];
	echo '</option>' . "\n" . '                                                            ';
}
echo '                                                        </select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="title_sync">Sync Title <i title="Synchronise stream title with a provider stream. You need to add your strema providers to XUI in order for this to work, the title will be updated every time the cron runs." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-7">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="title_sync" name="title_sync" class="form-control" data-toggle="select2">' . "\n" . '                                                            ';

if (!isset($f523e362fb81d6c8['title_sync'])) {
} else {
	list($ce94c6f90e778d4d, $Ef8a7f0abbf3ee36) = array_map('intval', explode('_', $f523e362fb81d6c8['title_sync']));
	$Fee0d5a474c96306->query('SELECT `stream_display_name` FROM `providers_streams` WHERE `provider_id` = ? AND `stream_id` = ?;', $ce94c6f90e778d4d, $Ef8a7f0abbf3ee36);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		echo '<option value="' . $ce94c6f90e778d4d . '_' . $Ef8a7f0abbf3ee36 . '" selected="selected">[' . $Ef8a7f0abbf3ee36 . '] ' . $Fee0d5a474c96306->get_row()['stream_display_name'] . '</option>';
	}
}

echo '                                                        </select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <div class="col-md-2">' . "\n" . '                                                        <a href="javascript: void(0);" onClick="clearTitle();" class="btn btn-warning" style="width: 100%">Clear</a>' . "\n" . '                                                    </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="prevb list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="nextb list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Next</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t";

if (isset(XUI::$rRequest['import'])) {
} else {
	echo "\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="stream-map">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n" . '                                                <div class="alert bg-info text-white border-0" role="alert">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'Custom maps can only be applied to single source streams, if you have more than one and the active source changes, a custom map could prevent that source from working.' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <table class="table table-striped table-borderless mb-4">' . "\n" . '                                                    <thead>' . "\n" . '                                                        <tr>' . "\n" . '                                                            <th>Custom Map</th>' . "\n" . '                                                        </tr>' . "\n" . '                                                    </thead>' . "\n" . '                                                    <tbody>' . "\n" . '                                                        <tr>' . "\n" . '                                                            <td class="input-group">' . "\n" . '                                                                <input type="text" class="form-control" id="custom_map" name="custom_map" value="';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		echo htmlspecialchars($f523e362fb81d6c8['custom_map']);
	}

	echo '">' . "\n" . '                                                                <div class="input-group-append">' . "\n" . '                                                                    <button class="btn btn-primary waves-effect waves-light" id="load_maps" type="button"><i class="mdi mdi-magnify"></i></button>' . "\n" . '                                                                </div>' . "\n" . '                                                            </td>' . "\n" . '                                                        </tr>' . "\n" . '                                                    </tbody>' . "\n" . '                                                </table>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<table id="datatable-map" class="table table-striped table-borderless mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>#</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Type</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<th>Information</th>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="prevb list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="nextb list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Next</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="epg-options">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n" . '                                                <ul class="nav nav-pills navtab-bg nav-justified">' . "\n" . '                                                    <li class="nav-item">' . "\n" . '                                                        <a href="#quick-search" data-toggle="tab" aria-expanded="true" class="nav-link';

	if (isset($f523e362fb81d6c8)) {
	} else {
		echo ' active';
	}

	echo '">' . "\n" . '                                                            Quick Search' . "\n" . '                                                        </a>' . "\n" . '                                                    </li>' . "\n" . '                                                    <li class="nav-item">' . "\n" . '                                                        <a href="#xui-epg" id="tab-xui-epg" data-toggle="tab" aria-expanded="true" class="nav-link';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['epg_api'])) {
	} else {
		echo ' active';
	}

	echo '">' . "\n" . '                                                            XUI EPG' . "\n" . '                                                        </a>' . "\n" . '                                                    </li>' . "\n" . '                                                    <li class="nav-item">' . "\n" . '                                                        <a href="#xmltv-epg" id="tab-xml-epg" data-toggle="tab" aria-expanded="false" class="nav-link';

	if (!isset($f523e362fb81d6c8) || $f523e362fb81d6c8['epg_api']) {
	} else {
		echo ' active';
	}

	echo '">' . "\n" . '                                                            XMLTV EPG' . "\n" . '                                                        </a>' . "\n" . '                                                    </li>' . "\n" . '                                                </ul>' . "\n" . '                                                <div class="tab-content" style="padding-top: 30px;">' . "\n" . '                                                    <div class="tab-pane';

	if (isset($f523e362fb81d6c8)) {
	} else {
		echo ' active';
	}

	echo '" id="quick-search">' . "\n" . '                                                        <div class="form-group row mb-4">' . "\n" . '                                                            <label class="col-md-3 col-form-label" for="quick_search">Search EPG</label>' . "\n" . '                                                            <div class="col-md-9">' . "\n" . '                                                                <select id="quick_search" class="form-control" data-toggle="select2"></select>' . "\n" . '                                                            </div>' . "\n" . '                                                        </div>' . "\n" . '                                                    </div>' . "\n" . '                                                    <div class="tab-pane';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['epg_api'])) {
	} else {
		echo ' active';
	}

	echo '" id="xui-epg">' . "\n" . '                                                        <div class="form-group row mb-4">' . "\n" . '                                                            <label class="col-md-3 col-form-label" for="epg_api_name">Channel Name</label>' . "\n" . '                                                            <div class="col-md-5">' . "\n" . '                                                                <input readonly id="epg_api_name" name="epg_api_name" type="text" class="form-control" value="';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['epg_api'])) {
	} else {
		echo $f523e362fb81d6c8['epg_api_name'];
	}

	echo '">' . "\n" . '                                                            </div>' . "\n" . '                                                            <div class="col-md-2">' . "\n" . '                                                                <input readonly id="epg_api_id" name="epg_api_id" type="text" class="form-control text-center" value="';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['epg_api'])) {
	} else {
		echo $f523e362fb81d6c8['channel_id'];
	}

	echo '">' . "\n" . '                                                            </div>' . "\n" . '                                                            <div class="col-md-2">' . "\n" . '                                                                <button type="button" style="width: 100%" class="btn btn-info waves-effect waves-light btn-xl" id="epg-api"><i class="mdi mdi-magnify"></i></button>' . "\n" . '                                                            </div>' . "\n" . '                                                        </div>' . "\n" . '                                                        <div class="table-responsive" id="table-epg-data" style="display: none; padding-bottom: 30px;">' . "\n" . '                                                            <table class="table table-striped table-borderless mb-0">' . "\n" . '                                                                <thead>' . "\n" . '                                                                    <tr>' . "\n" . '                                                                        <th class="text-center">Time</th>' . "\n" . '                                                                        <th>Title</th>' . "\n" . '                                                                        <th>Description</th>' . "\n" . '                                                                    </tr>' . "\n" . '                                                                </thead>' . "\n" . '                                                                <tbody></tbody>' . "\n" . '                                                            </table>' . "\n" . '                                                        </div>' . "\n" . '                                                    </div>' . "\n" . '                                                    <div class="tab-pane';

	if (!isset($f523e362fb81d6c8) || $f523e362fb81d6c8['epg_api']) {
	} else {
		echo ' active';
	}

	echo '" id="xmltv-epg">' . "\n" . '                                                        <div class="form-group row mb-4">' . "\n" . '                                                            <label class="col-md-4 col-form-label" for="epg_id">EPG Source</label>' . "\n" . '                                                            <div class="col-md-8">' . "\n" . '                                                                <select name="epg_id" id="epg_id" class="form-control" data-toggle="select2">' . "\n" . '                                                                    <option ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		if (intval($f523e362fb81d6c8['epg_id']) != 0) {
		} else {
			echo 'selected ';
		}
	}

	echo 'value="0">No EPG</option>' . "\n" . '                                                                    ';

	foreach ($C880bd9f48000558 as $d8a1409105424710) {
		echo '                                                                    <option ';

		if (!isset($f523e362fb81d6c8)) {
		} else {
			if (intval($f523e362fb81d6c8['epg_id']) != $d8a1409105424710['id']) {
			} else {
				echo 'selected ';
			}
		}

		echo 'value="';
		echo $d8a1409105424710['id'];
		echo '">';
		echo $d8a1409105424710['epg_name'];
		echo '</option>' . "\n" . '                                                                    ';
	}
	echo '                                                                </select>' . "\n" . '                                                            </div>' . "\n" . '                                                        </div>' . "\n" . '                                                        <div class="form-group row mb-4">' . "\n" . '                                                            <label class="col-md-4 col-form-label" for="channel_id">EPG Channel ID</label>' . "\n" . '                                                            <div class="col-md-8">' . "\n" . '                                                                <select name="channel_id" id="channel_id" class="form-control" data-toggle="select2">' . "\n" . '                                                                ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		foreach (json_decode($C880bd9f48000558[intval($f523e362fb81d6c8['epg_id'])]['data'], true) as $D3fa098be3f297cd => $F750d2abf70fd2af) {
			echo '                                                                    <option value="';
			echo $D3fa098be3f297cd;
			echo '"';

			if ($f523e362fb81d6c8['channel_id'] != $D3fa098be3f297cd) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo $F750d2abf70fd2af['display_name'];
			echo '</option>' . "\n" . '                                                                    ';
		}
	}

	echo '                                                                </select>' . "\n" . '                                                            </div>' . "\n" . '                                                        </div>' . "\n" . '                                                        <div class="form-group row mb-4">' . "\n" . '                                                            <label class="col-md-4 col-form-label" for="epg_lang">EPG Language</label>' . "\n" . '                                                            <div class="col-md-4">' . "\n" . '                                                                <select name="epg_lang" id="epg_lang" class="form-control" data-toggle="select2">' . "\n" . '                                                                ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		foreach (json_decode($C880bd9f48000558[intval($f523e362fb81d6c8['epg_id'])]['data'], true)[$f523e362fb81d6c8['channel_id']]['langs'] as $C3c8913edb801c35 => $C54c804377e62501) {
			echo '                                                                    <option value="';
			echo $C54c804377e62501;
			echo '"';

			if ($f523e362fb81d6c8['epg_lang'] != $C54c804377e62501) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo $C54c804377e62501;
			echo '</option>' . "\n" . '                                                                    ';
		}
	}

	echo '                                                                </select>' . "\n" . '                                                            </div>' . "\n" . '                                                            <label class="col-md-2 col-form-label" for="epg_offset">Minute Offset</label>' . "\n" . '                                                            <div class="col-md-2">' . "\n" . '                                                                <input type="text" class="form-control text-center" id="epg_offset" name="epg_offset" value="';

	if (isset($f523e362fb81d6c8)) {
		echo(intval($f523e362fb81d6c8['epg_offset']) ?: 0);
	} else {
		echo '0';
	}

	echo '" required data-parsley-trigger="change">' . "\n" . '                                                            </div>' . "\n" . '                                                        </div>' . "\n" . '                                                    </div>' . "\n" . '                                                </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="prevb list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="nextb list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Next</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                    <div class="tab-pane" id="rtmp-push">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n" . '                                                <div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-9 col-form-label" for="rtmp_output">Output RTMP <i title="Feed stream to the RTMP server for output to RTMP clients." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                    <div class="col-md-3">' . "\n" . '                                                        <input name="rtmp_output" id="rtmp_output" type="checkbox" ';

	if (!isset($f523e362fb81d6c8)) {
	} else {
		if ($f523e362fb81d6c8['rtmp_output'] != 1) {
		} else {
			echo 'checked ';
		}
	}

	echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                    </div>' . "\n" . '                                                </div>' . "\n" . '                                                <div class="alert bg-info text-white border-0" role="alert">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'RTMP Push will allow you to push your streams to RTMP servers, such as the one that runs with XUI. The `Push From` server needs to be enabled in the servers tab for this to be activated.' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <table id="datatable-rtmp" class="table table-striped table-borderless mb-0">' . "\n" . '                                                    <thead>' . "\n" . '                                                        <tr>' . "\n" . '                                                            <th>Push From</th>' . "\n" . '                                                            <th>RTMP URL</th>' . "\n" . '                                                        </tr>' . "\n" . '                                                    </thead>' . "\n" . '                                                    <tbody class="rtmp">' . "\n" . '                                                        ';

	if (isset($f523e362fb81d6c8)) {
		$e0f8b4d30e1aa9f1 = json_decode($f523e362fb81d6c8['external_push'], true);

		if ($e0f8b4d30e1aa9f1) {
		} else {
			$e0f8b4d30e1aa9f1 = array(array(''));
		}
	} else {
		$e0f8b4d30e1aa9f1 = array(array(''));
	}

	$Ea22c4a9ab5b2176 = 0;

	foreach ($e0f8b4d30e1aa9f1 as $d58b4f8653a391d8 => $bbfc9bd8432031f5) {
		foreach ($bbfc9bd8432031f5 as $c8d91fcd2309e48a) {
			echo '                                                                <tr class="rtmp_info">' . "\n" . '                                                                    <td class="rtmp_server">' . "\n" . '                                                                        <select id="rtmp_push_';
			echo $Ea22c4a9ab5b2176;
			echo '" class="form-control" data-toggle="select2">' . "\n" . '                                                                            ';

			foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
				echo '                                                                            <option value="';
				echo $e81220b4451f37c9['id'];
				echo '"';

				if (!(isset($f523e362fb81d6c8) && $d58b4f8653a391d8 == $e81220b4451f37c9['id'])) {
				} else {
					echo ' selected';
				}

				echo '>';
				echo $e81220b4451f37c9['server_name'];
				echo '</option>' . "\n" . '                                                                            ';
			}
			echo '                                                                        </select>' . "\n" . '                                                                    </td>' . "\n" . '                                                                    <td class="input-group">' . "\n" . '                                                                        <input type="text" class="form-control" value="';
			echo htmlspecialchars($c8d91fcd2309e48a);
			echo '">' . "\n" . '                                                                        <div class="input-group-append">' . "\n" . '                                                                            <button class="btn btn-danger waves-effect waves-light btn-fixed-xs" onClick="removeRTMP(this);" type="button"><i class="mdi mdi-close"></i></button>' . "\n" . '                                                                        </div>' . "\n" . '                                                                    </td>' . "\n" . '                                                                </tr>' . "\n" . '                                                            ';
			$Ea22c4a9ab5b2176++;
		}
	}
	echo '                                                    </tbody>' . "\n" . '                                                </table>' . "\n" . '                                            </div>' . "\n" . '                                        </div>' . "\n" . '                                        <ul class="list-inline wizard mb-0" style="padding-top: 30px;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="prevb list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n" . '                                            </li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n" . '                                                <a onClick="addRTMP();" class="btn btn-info btn-pointer">Add RTMP URL</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn nextb btn-secondary">Next</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n" . '                                    </div>' . "\n\t\t\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="load-balancing">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="servers">Server Tree</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div id="server_tree"></div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="on_demand">On-Demand Servers</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n" . '                                                        <select name="on_demand[]" id="on_demand" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset($f523e362fb81d6c8) && in_array($e81220b4451f37c9['id'], $Beb96c2a189d2e62))) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . "                                                    <label class=\"col-md-3 col-form-label\" for=\"llod\">Low Latency On-Demand <i title=\"<strong>LLOD v2 - FFMPEG</strong><br/>The first source is selected without probing and passed directly to FFMPEG for processing. If the first source is down, the stream will not start.<br/><br/>LLOD v3 - PHP<br/>A bespoke segment parser developed by XUI.one to take incoming MPEG-TS streams and identify keyframes in order to segment the stream to deliver back to the client. Very fast, still experimental however. This method doesn't suffer from issues such as lost audio as ffmpeg isn't involved at all but does not support anything but MPEG-TS sources.\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="llod" id="llod" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('Disabled', 'LLOD v2 - FFMPEG', 'LLOD v3 - PHP') as $b6842cb20051e925 => $Fa016cbf0b72bfdd) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $b6842cb20051e925;
	echo '"';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['llod'] == $b6842cb20051e925)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $Fa016cbf0b72bfdd;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="tv_archive_server_id">Timeshift Server</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="tv_archive_server_id" id="tv_archive_server_id" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="0">Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['tv_archive_server_id'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="tv_archive_duration">Timeshift Days</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control text-center" id="tv_archive_duration" name="tv_archive_duration" value="';

if (isset($f523e362fb81d6c8)) {
	echo $f523e362fb81d6c8['tv_archive_duration'];
} else {
	echo '0';
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n" . '                                                    <label class="col-md-3 col-form-label" for="vframes_server_id">Thumbnail Server</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="vframes_server_id" id="vframes_server_id" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="0">Disabled</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset($f523e362fb81d6c8) && $f523e362fb81d6c8['vframes_server_id'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="restart_on_edit">';

if (isset($f523e362fb81d6c8['id'])) {
	echo 'Restart on Edit';
} else {
	echo 'Start Stream Now';
}

echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="restart_on_edit" id="restart_on_edit" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="prevb list-inline-item">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n" . '                                            <li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_stream" type="submit" class="btn btn-primary" value="Save" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div> ' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
