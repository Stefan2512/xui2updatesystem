<?php

include 'functions.php';
session_write_close();

if (PHP_ERRORS) {
} else {
	if (!(empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest')) {
	} else {
		exit();
	}
}

if (isset($_SESSION['hash'])) {
	if (!XUI::$rSettings['redis_handler']) {
	} else {
		XUI::BfA8b6FE314DEd7F();
	}

	if (!isset(XUI::$rRequest['action'])) {
	} else {
		if (XUI::$rRequest['action'] == 'stream') {
			if (AacD47d8157A1A09('adv', 'edit_stream')) {
				$F26087d31c2bbe4d = intval(XUI::$rRequest['stream_id']);
				$d58b4f8653a391d8 = intval(XUI::$rRequest['server_id']);
				$b4cd770ed1b094fe = XUI::$rRequest['sub'];

				if (in_array($b4cd770ed1b094fe, array('start', 'stop', 'restart'))) {
					if ($b4cd770ed1b094fe != 'restart') {
					} else {
						$b4cd770ed1b094fe = 'start';
					}

					if ($d58b4f8653a391d8 == -1) {
						$E708d4730d21125b = array();
						$Fee0d5a474c96306->query('SELECT `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
						}

						if (0 >= count($E708d4730d21125b)) {
						} else {
							echo E36Ec1583E223Bf6(array('action' => 'stream', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => array($F26087d31c2bbe4d), 'servers' => $E708d4730d21125b));

							exit();
						}
					} else {
						echo e36EC1583E223Bf6(array('action' => 'stream', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => array($F26087d31c2bbe4d), 'servers' => array($d58b4f8653a391d8)));

						exit();
					}
				} else {
					if ($b4cd770ed1b094fe == 'force') {
						$Cc34cb9d37801a94 = intval(XUI::$rRequest['force_id']);
						$E708d4730d21125b = array_keys(bB9fe2FDE295e476($F26087d31c2bbe4d));

						if (0 >= count($E708d4730d21125b)) {
							echo json_encode(array('result' => false));

							exit();
						}

						$cf1c389bda3e30fd = array('action' => 'force_stream', 'stream_id' => $F26087d31c2bbe4d, 'force_id' => $Cc34cb9d37801a94);
						echo json_encode(a8eD5BC26Ea63263($E708d4730d21125b, $cf1c389bda3e30fd));

						exit();
					}

					if ($b4cd770ed1b094fe == 'delete') {
						D13C1A44A4495b05($F26087d31c2bbe4d, $d58b4f8653a391d8, false);
						echo json_encode(array('result' => true));

						exit();
					}

					if ($b4cd770ed1b094fe == 'kill') {
						XUI::E8E9d6b2b107d8Ae(XUI::$rRequest['stream_id']);
						echo json_encode(array('result' => true));

						exit();
					}

					if ($b4cd770ed1b094fe == 'purge') {
						if (XUI::$rSettings['redis_handler']) {
							foreach (XUI::d92De48C36cF9438(null, ($d58b4f8653a391d8 == -1 ? null : $d58b4f8653a391d8), $F26087d31c2bbe4d, true, false, false) as $e110a2ab6d3a4734) {
								XUI::E8E9D6b2b107D8AE($e110a2ab6d3a4734);
							}
						} else {
							if ($d58b4f8653a391d8 == -1) {
								$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);
							} else {
								$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `stream_id` = ? AND `server_id` = ?;', $F26087d31c2bbe4d, $d58b4f8653a391d8);
							}

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								XUI::E8E9D6b2B107D8ae($C740da31596f24ef);
							}
						}

						echo json_encode(array('result' => true));

						exit();
					} else {
						echo json_encode(array('result' => false));

						exit();
					}
				}
			} else {
				echo json_encode(array('result' => false));

				exit();
			}
		} else {
			if (XUI::$rRequest['action'] == 'movie') {
				if (aAcd47D8157a1a09('adv', 'edit_movie')) {
					$F26087d31c2bbe4d = intval(XUI::$rRequest['stream_id']);
					$d58b4f8653a391d8 = intval(XUI::$rRequest['server_id']);
					$b4cd770ed1b094fe = XUI::$rRequest['sub'];

					if (in_array($b4cd770ed1b094fe, array('start', 'stop'))) {
						if ($d58b4f8653a391d8 == -1) {
							$E708d4730d21125b = array();
							$Fee0d5a474c96306->query('SELECT `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
							}

							if (0 >= count($E708d4730d21125b)) {
							} else {
								echo e36ec1583e223bf6(array('action' => 'vod', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => array($F26087d31c2bbe4d), 'servers' => $E708d4730d21125b, 'force' => true));

								exit();
							}
						} else {
							echo E36Ec1583E223Bf6(array('action' => 'vod', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => array($F26087d31c2bbe4d), 'servers' => array($d58b4f8653a391d8), 'force' => true));

							exit();
						}
					} else {
						if ($b4cd770ed1b094fe == 'delete') {
							D13c1A44A4495b05($F26087d31c2bbe4d, $d58b4f8653a391d8, true);
							echo json_encode(array('result' => true));

							exit();
						}

						if ($b4cd770ed1b094fe == 'kill') {
							XUI::E8E9d6b2B107d8ae(XUI::$rRequest['stream_id']);
							echo json_encode(array('result' => true));

							exit();
						}

						if ($b4cd770ed1b094fe == 'purge') {
							if (XUI::$rSettings['redis_handler']) {
								foreach (XUI::d92dE48C36Cf9438(null, ($d58b4f8653a391d8 == -1 ? null : $d58b4f8653a391d8), $F26087d31c2bbe4d, true, false, false) as $e110a2ab6d3a4734) {
									XUI::e8e9D6b2B107d8Ae($e110a2ab6d3a4734);
								}
							} else {
								if ($d58b4f8653a391d8 == -1) {
									$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);
								} else {
									$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `stream_id` = ? AND `server_id` = ?;', $F26087d31c2bbe4d, $d58b4f8653a391d8);
								}

								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
									XUI::e8e9d6b2b107D8AE($C740da31596f24ef);
								}
							}

							echo json_encode(array('result' => true));

							exit();
						} else {
							echo json_encode(array('result' => false));

							exit();
						}
					}
				} else {
					echo json_encode(array('result' => false));

					exit();
				}
			} else {
				if (XUI::$rRequest['action'] == 'episode') {
					if (AAcD47D8157a1a09('adv', 'edit_episode')) {
						$F26087d31c2bbe4d = intval(XUI::$rRequest['stream_id']);
						$d58b4f8653a391d8 = intval(XUI::$rRequest['server_id']);
						$b4cd770ed1b094fe = XUI::$rRequest['sub'];

						if (in_array($b4cd770ed1b094fe, array('start', 'stop'))) {
							if ($d58b4f8653a391d8 == -1) {
								$E708d4730d21125b = array();
								$Fee0d5a474c96306->query('SELECT `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);

								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
									$E708d4730d21125b[] = intval($C740da31596f24ef['server_id']);
								}

								if (0 >= count($E708d4730d21125b)) {
								} else {
									echo e36eC1583e223bf6(array('action' => 'vod', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => array($F26087d31c2bbe4d), 'servers' => $E708d4730d21125b, 'force' => true));

									exit();
								}
							} else {
								echo E36EC1583e223Bf6(array('action' => 'vod', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => array($F26087d31c2bbe4d), 'servers' => array($d58b4f8653a391d8), 'force' => true));

								exit();
							}
						} else {
							if ($b4cd770ed1b094fe == 'delete') {
								D13c1a44a4495b05($F26087d31c2bbe4d, $d58b4f8653a391d8, true);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'kill') {
								XUI::e8E9d6b2B107d8ae(XUI::$rRequest['stream_id']);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'purge') {
								if (XUI::$rSettings['redis_handler']) {
									foreach (XUI::D92dE48c36Cf9438(null, ($d58b4f8653a391d8 == -1 ? null : $d58b4f8653a391d8), $F26087d31c2bbe4d, true, false, false) as $e110a2ab6d3a4734) {
										XUI::E8e9d6B2b107d8ae($e110a2ab6d3a4734);
									}
								} else {
									if ($d58b4f8653a391d8 == -1) {
										$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);
									} else {
										$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `stream_id` = ? AND `server_id` = ?;', $F26087d31c2bbe4d, $d58b4f8653a391d8);
									}

									foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
										XUI::e8e9D6B2b107D8aE($C740da31596f24ef);
									}
								}

								echo json_encode(array('result' => true));

								exit();
							} else {
								echo json_encode(array('result' => false));

								exit();
							}
						}
					} else {
						echo json_encode(array('result' => false));

						exit();
					}
				} else {
					if (XUI::$rRequest['action'] == 'line') {
						if (aaCd47d8157A1a09('adv', 'edit_user')) {
							$D78ff1d0edade5eb = intval(XUI::$rRequest['user_id']);
							$b4cd770ed1b094fe = XUI::$rRequest['sub'];

							if ($b4cd770ed1b094fe == 'delete') {
								f8E4778E49869D84($D78ff1d0edade5eb);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'enable') {
								$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $D78ff1d0edade5eb);
								XUI::bC77EDC4169f1bAa($D78ff1d0edade5eb);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'disable') {
								$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $D78ff1d0edade5eb);
								XUI::bC77EDC4169f1Baa($D78ff1d0edade5eb);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'ban') {
								$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $D78ff1d0edade5eb);
								XUI::bC77edc4169F1BAa($D78ff1d0edade5eb);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'unban') {
								$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` = ?;', $D78ff1d0edade5eb);
								XUI::bC77eDC4169F1baA($D78ff1d0edade5eb);
								echo json_encode(array('result' => true));

								exit();
							}

							if ($b4cd770ed1b094fe == 'kill') {
								if (XUI::$rSettings['redis_handler']) {
									foreach (XUI::D92DE48C36cF9438($D78ff1d0edade5eb, null, null, true, false, false) as $e110a2ab6d3a4734) {
										XUI::e8e9d6b2b107D8ae($e110a2ab6d3a4734);
									}
								} else {
									$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `user_id` = ?;', $D78ff1d0edade5eb);

									foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
										XUI::e8E9D6b2B107D8aE($C740da31596f24ef);
									}
								}

								echo json_encode(array('result' => true));

								exit();
							} else {
								echo json_encode(array('result' => false));

								exit();
							}
						} else {
							echo json_encode(array('result' => false));

							exit();
						}
					} else {
						if (XUI::$rRequest['action'] == 'line_activity') {
							if (AACd47d8157A1A09('adv', 'connection_logs')) {
								$b4cd770ed1b094fe = XUI::$rRequest['sub'];

								if ($b4cd770ed1b094fe != 'kill') {
									echo json_encode(array('result' => false));

									exit();
								}

								XUI::e8E9d6b2b107D8Ae(XUI::$rRequest['pid']);
								echo json_encode(array('result' => true));

								exit();
							}

							echo json_encode(array('result' => false));

							exit();
						}

						if (XUI::$rRequest['action'] == 'process') {
							if (AacD47D8157a1A09('adv', 'process_monitor')) {
								A200986BBae4b322(XUI::$rRequest['server'], array('action' => 'kill_pid', 'pid' => intval(XUI::$rRequest['pid'])));
								echo json_encode(array('result' => true));

								exit();
							}

							echo json_encode(array('result' => false));

							exit();
						}

						if (XUI::$rRequest['action'] == 'adjust_credits') {
							if (aAcd47D8157A1A09('adv', 'edit_reguser')) {
								$d51e425eb7375255 = FE76c4BCAF81Baa4(XUI::$rRequest['id']);

								if ($d51e425eb7375255 && is_numeric(XUI::$rRequest['credits'])) {
									$F17f20a56056dab3 = intval($d51e425eb7375255['credits']) + intval(XUI::$rRequest['credits']);

									if (0 <= $F17f20a56056dab3) {
										$Fee0d5a474c96306->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $F17f20a56056dab3, $d51e425eb7375255['id']);
										$Fee0d5a474c96306->query('INSERT INTO `users_credits_logs`(`target_id`, `admin_id`, `amount`, `date`, `reason`) VALUES(?, ?, ?, ?, ?);', $d51e425eb7375255['id'], $D4253f9520627819['id'], XUI::$rRequest['credits'], time(), XUI::$rRequest['reason']);
										echo json_encode(array('result' => true));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								echo json_encode(array('result' => false));

								exit();
							}

							echo json_encode(array('result' => false));

							exit();
						}

						if (XUI::$rRequest['action'] == 'reg_user') {
							if (AaCd47D8157a1a09('adv', 'edit_reguser')) {
								$b4cd770ed1b094fe = XUI::$rRequest['sub'];

								if ($b4cd770ed1b094fe == 'delete') {
									e4c6429A95C776CF(XUI::$rRequest['user_id'], false, false, $D4253f9520627819['id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'enable') {
									$Fee0d5a474c96306->query('UPDATE `users` SET `status` = 1 WHERE `id` = ?;', XUI::$rRequest['user_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'disable') {
									$Fee0d5a474c96306->query('UPDATE `users` SET `status` = 0 WHERE `id` = ?;', XUI::$rRequest['user_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								echo json_encode(array('result' => false));

								exit();
							}

							echo json_encode(array('result' => false));

							exit();
						}

						if (XUI::$rRequest['action'] == 'ticket') {
							if (AAcD47D8157A1a09('adv', 'ticket')) {
								$b4cd770ed1b094fe = XUI::$rRequest['sub'];

								if ($b4cd770ed1b094fe == 'delete') {
									D920c9a4B3D6d84E(XUI::$rRequest['ticket_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'close') {
									$Fee0d5a474c96306->query('UPDATE `tickets` SET `status` = 0 WHERE `id` = ?;', XUI::$rRequest['ticket_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'reopen') {
									$Fee0d5a474c96306->query('UPDATE `tickets` SET `status` = 1 WHERE `id` = ?;', XUI::$rRequest['ticket_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								echo json_encode(array('result' => false));

								exit();
							}

							echo json_encode(array('result' => false));

							exit();
						}

						if (XUI::$rRequest['action'] == 'mag') {
							if (AACD47D8157A1A09('adv', 'edit_mag')) {
								$b4cd770ed1b094fe = XUI::$rRequest['sub'];
								$d447f4d157b9b653 = BfE9937c6D242a3D(intval(XUI::$rRequest['mag_id']));

								if ($b4cd770ed1b094fe == 'delete') {
									D8974b51b74c80eE(XUI::$rRequest['mag_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'enable') {
									$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $d447f4d157b9b653['user_id']);
									XUI::BC77edc4169F1BAA($d447f4d157b9b653['user_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'disable') {
									$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $d447f4d157b9b653['user_id']);
									XUI::BC77EdC4169f1baA($d447f4d157b9b653['user_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'ban') {
									$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $d447f4d157b9b653['user_id']);
									XUI::bc77edc4169f1Baa($d447f4d157b9b653['user_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'unban') {
									$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` = ?;', $d447f4d157b9b653['user_id']);
									XUI::bc77eDc4169f1BaA($d447f4d157b9b653['user_id']);
									echo json_encode(array('result' => true));

									exit();
								}

								if ($b4cd770ed1b094fe == 'convert') {
									D8974B51b74c80eE(XUI::$rRequest['mag_id'], false, false, true);
									echo json_encode(array('result' => true, 'line_id' => $d447f4d157b9b653['user']['id']));

									exit();
								}

								if ($b4cd770ed1b094fe == 'kill') {
									if (XUI::$rSettings['redis_handler']) {
										foreach (XUI::D92de48c36cf9438($d447f4d157b9b653['user_id'], null, null, true, false, false) as $e110a2ab6d3a4734) {
											XUI::E8E9d6b2B107d8ae($e110a2ab6d3a4734);
										}
									} else {
										$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `user_id` = ?;', $d447f4d157b9b653['user_id']);

										foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
											XUI::E8E9d6B2b107d8Ae($C740da31596f24ef);
										}
									}

									echo json_encode(array('result' => true));

									exit();
								} else {
									echo json_encode(array('result' => false));

									exit();
								}
							} else {
								echo json_encode(array('result' => false));

								exit();
							}
						} else {
							if (XUI::$rRequest['action'] == 'enigma') {
								if (AaCd47d8157a1A09('adv', 'edit_e2')) {
									$b4cd770ed1b094fe = XUI::$rRequest['sub'];
									$b53c724c59fe65fc = bA960cAb7fE0cD93(intval(XUI::$rRequest['e2_id']));

									if ($b4cd770ed1b094fe == 'delete') {
										a8cd7c1Df629A648(XUI::$rRequest['e2_id']);
										echo json_encode(array('result' => true));

										exit();
									}

									if ($b4cd770ed1b094fe == 'enable') {
										$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $b53c724c59fe65fc['user_id']);
										XUI::Bc77eDC4169f1BaA($b53c724c59fe65fc['user_id']);
										echo json_encode(array('result' => true));

										exit();
									}

									if ($b4cd770ed1b094fe == 'disable') {
										$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $b53c724c59fe65fc['user_id']);
										XUI::bC77Edc4169F1bAa($b53c724c59fe65fc['user_id']);
										echo json_encode(array('result' => true));

										exit();
									}

									if ($b4cd770ed1b094fe == 'ban') {
										$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $b53c724c59fe65fc['user_id']);
										XUI::BC77Edc4169f1bAA($b53c724c59fe65fc['user_id']);
										echo json_encode(array('result' => true));

										exit();
									}

									if ($b4cd770ed1b094fe == 'unban') {
										$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` = ?;', $b53c724c59fe65fc['user_id']);
										XUI::BC77edc4169F1BAA($b53c724c59fe65fc['user_id']);
										echo json_encode(array('result' => true));

										exit();
									}

									if ($b4cd770ed1b094fe == 'convert') {
										A8cD7c1df629A648(XUI::$rRequest['e2_id'], false, false, true);
										echo json_encode(array('result' => true, 'line_id' => $b53c724c59fe65fc['user']['id']));

										exit();
									}

									if ($b4cd770ed1b094fe == 'kill') {
										if (XUI::$rSettings['redis_handler']) {
											foreach (XUI::D92dE48c36cF9438($b53c724c59fe65fc['user_id'], null, null, true, false, false) as $e110a2ab6d3a4734) {
												XUI::e8e9d6b2b107D8ae($e110a2ab6d3a4734);
											}
										} else {
											$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `user_id` = ?;', $b53c724c59fe65fc['user_id']);

											foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
												XUI::e8e9D6B2B107D8Ae($C740da31596f24ef);
											}
										}

										echo json_encode(array('result' => true));

										exit();
									} else {
										echo json_encode(array('result' => false));

										exit();
									}
								} else {
									echo json_encode(array('result' => false));

									exit();
								}
							} else {
								if (XUI::$rRequest['action'] == 'mag_event') {
									if (aAcD47d8157A1A09('adv', 'manage_events')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											$Fee0d5a474c96306->query('DELETE FROM `mag_events` WHERE `id` = ?;', XUI::$rRequest['mag_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'regenerate_cache') {
									if (AAcd47d8157a1A09('adv', 'backups')) {
										shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php "force"');
										echo json_encode(array('result' => true));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'enable_cache') {
									if (aacD47d8157A1A09('adv', 'backups')) {
										$Fee0d5a474c96306->query('UPDATE `settings` SET `enable_cache` = 1;');

										if (!file_exists(CACHE_TMP_PATH . 'settings')) {
										} else {
											unlink(CACHE_TMP_PATH . 'settings');
										}

										shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php');
										$Eace02ff35917268 = intval(trim(shell_exec('pgrep -U xui | xargs ps -f -p | grep cache_handler | grep -v grep | grep -v pgrep | wc -l')));

										if ($Eace02ff35917268 != 0) {
										} else {
											shell_exec(PHP_BIN . ' ' . CLI_PATH . 'cache_handler.php > /dev/null 2>/dev/null &');
										}

										echo json_encode(array('result' => true));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'disable_cache') {
									if (aACd47D8157A1A09('adv', 'backups')) {
										$Fee0d5a474c96306->query('UPDATE `settings` SET `enable_cache` = 0;');

										if (!file_exists(CACHE_TMP_PATH . 'settings')) {
										} else {
											unlink(CACHE_TMP_PATH . 'settings');
										}

										shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache.php');
										echo json_encode(array('result' => true));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'epg') {
									if (Aacd47d8157a1A09('adv', 'epg_edit')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											f62970f78A40cD4c(XUI::$rRequest['epg_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										if ($b4cd770ed1b094fe == 'reload') {
											shell_exec(PHP_BIN . ' ' . CRON_PATH . 'epg.php "' . intval(XUI::$rRequest['epg_id']) . '" > /dev/null 2>/dev/null &');
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'provider') {
									if (aACd47d8157A1a09('adv', 'streams')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											deleteProvider(XUI::$rRequest['id']);
											echo json_encode(array('result' => true));

											exit();
										}

										if ($b4cd770ed1b094fe == 'reload') {
											shell_exec(PHP_BIN . ' ' . CRON_PATH . 'providers.php "' . intval(XUI::$rRequest['id']) . '" > /dev/null 2>/dev/null &');
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'profile') {
									if (AaCD47d8157A1a09('adv', 'tprofiles')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											E35e424Dd2c18a18(XUI::$rRequest['profile_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'series') {
									if (AACd47D8157a1a09('adv', 'edit_series')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											bC3dfBaA6322045E(XUI::$rRequest['series_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'kill_watch') {
									if (aacd47d8157A1A09('adv', 'folder_watch')) {
										C807Fa5b46e2de60();
										echo json_encode(array('result' => true));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'kill_plex') {
									if (Aacd47d8157a1a09('adv', 'folder_watch')) {
										E6699420777697c4();
										echo json_encode(array('result' => true));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'folder') {
									if (AACd47d8157A1A09('adv', 'folder_watch')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											EEC455fA54e2999d(XUI::$rRequest['folder_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										if ($b4cd770ed1b094fe == 'force') {
											$b53b03db133532c7 = E6E296dD0051114B(XUI::$rRequest['folder_id']);

											if ($b53b03db133532c7) {
												forceWatch($b53b03db133532c7['server_id'], $b53b03db133532c7['id']);
												echo json_encode(array('result' => true));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'library') {
									if (aACD47D8157a1A09('adv', 'folder_watch')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											eec455fa54E2999d(XUI::$rRequest['folder_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										if ($b4cd770ed1b094fe == 'force') {
											$b53b03db133532c7 = E6E296Dd0051114B(XUI::$rRequest['folder_id']);

											if ($b53b03db133532c7) {
												forcePlex($b53b03db133532c7['server_id'], $b53b03db133532c7['id']);
												echo json_encode(array('result' => true));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'useragent') {
									if (AAcd47D8157A1A09('adv', 'block_uas')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											A67f300C600b609B(XUI::$rRequest['ua_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'isp') {
									if (AaCd47d8157a1A09('adv', 'block_isps')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											BC0ec13F813C4ec5(XUI::$rRequest['isp_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'mysql_syslog') {
									if (aacd47D8157A1a09('adv', 'block_ips')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'block' && filter_var(XUI::$rRequest['ip'], FILTER_VALIDATE_IP)) {
											$Fee0d5a474c96306->query("INSERT INTO `blocked_ips`(`ip`, `notes`, `date`) VALUES(?, 'MySQL Bruteforce', ?);", XUI::$rRequest['ip'], time());
											touch(FLOOD_TMP_PATH . 'block_' . XUI::$rRequest['ip']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'ip') {
									if (aAcd47d8157a1A09('adv', 'block_ips')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											aa1526517E33A365(XUI::$rRequest['ip']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'rtmp_ip') {
									if (aACd47D8157A1A09('adv', 'add_rtmp')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											babDBae2bE721C62(XUI::$rRequest['ip']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'watch_output') {
									if (AAcd47D8157A1a09('adv', 'folder_watch_output')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `id` = ?;', XUI::$rRequest['result_id']);
											echo json_encode(array('result' => true));

											exit();
										}

										echo json_encode(array('result' => false));

										exit();
									}

									echo json_encode(array('result' => false));

									exit();
								}

								if (XUI::$rRequest['action'] == 'server') {
									if (aacD47d8157a1A09('adv', 'edit_server')) {
										$b4cd770ed1b094fe = XUI::$rRequest['sub'];

										if ($b4cd770ed1b094fe == 'delete') {
											if ($a8bb73cba48fb7f6[XUI::$rRequest['server_id']]['is_main'] == 0) {
												C234aE70b52D65a2(XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if ($b4cd770ed1b094fe == 'update') {
											if (!is_numeric(XUI::$rRequest['server_id'])) {
												$Aa8c918a2a91966f = json_decode(XUI::$rRequest['server_id'], true);
											} else {
												$Aa8c918a2a91966f = array(intval(XUI::$rRequest['server_id']));
											}

											foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
												$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $C3c8913edb801c35, time(), json_encode(array('action' => 'update')));
											}
											echo json_encode(array('result' => true));

											exit();
										} else {
											if ($b4cd770ed1b094fe == 'enable') {
												$Fee0d5a474c96306->query('UPDATE `servers` SET `enabled` = 1 WHERE `id` = ?;', XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'disable') {
												$Fee0d5a474c96306->query('UPDATE `servers` SET `enabled` = 0 WHERE `id` = ? AND `is_main` = 0;', XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'enable_proxy') {
												$Fee0d5a474c96306->query('UPDATE `servers` SET `enable_proxy` = 1 WHERE `id` = ?;', XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'disable_proxy') {
												$Fee0d5a474c96306->query('UPDATE `servers` SET `enable_proxy` = 0 WHERE `id` = ?;', XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'kill') {
												if (XUI::$rSettings['redis_handler']) {
													foreach (XUI::D92DE48C36cf9438(null, XUI::$rRequest['server_id'], null, true, false, false) as $e110a2ab6d3a4734) {
														XUI::E8E9d6b2b107d8Ae($e110a2ab6d3a4734);
													}
												} else {
													$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `server_id` = ?;', XUI::$rRequest['server_id']);

													foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
														XUI::E8E9d6B2B107D8Ae($C740da31596f24ef);
													}
												}

												echo json_encode(array('result' => true));

												exit();
											} else {
												if ($b4cd770ed1b094fe == 'restart') {
													$Cdb85875fd50f459 = array();
													$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_servers` WHERE `server_id` = ? AND `on_demand` = 0 AND `monitor_pid` > 0 AND `pid` > 0 AND `stream_status` = 0;', XUI::$rRequest['server_id']);

													if (0 >= $Fee0d5a474c96306->num_rows()) {
													} else {
														foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
															$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
														}
													}

													if (0 >= count($Cdb85875fd50f459)) {
													} else {
														$B59c127fecf35c15 = e36eC1583e223bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array_values($Cdb85875fd50f459), 'servers' => array(intval(XUI::$rRequest['server_id']))));
													}

													echo json_encode(array('result' => true));

													exit();
												}

												if ($b4cd770ed1b094fe == 'start') {
													$Cdb85875fd50f459 = array();
													$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_servers` WHERE `server_id` = ? AND `on_demand` = 0;', XUI::$rRequest['server_id']);

													if (0 >= $Fee0d5a474c96306->num_rows()) {
													} else {
														foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
															$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
														}
													}

													if (0 >= count($Cdb85875fd50f459)) {
													} else {
														$B59c127fecf35c15 = e36EC1583E223bF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array_values($Cdb85875fd50f459), 'servers' => array(intval(XUI::$rRequest['server_id']))));
													}

													echo json_encode(array('result' => true));

													exit();
												}

												if ($b4cd770ed1b094fe == 'stop') {
													$Cdb85875fd50f459 = array();
													$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_servers` WHERE `server_id` = ? AND `on_demand` = 0;', XUI::$rRequest['server_id']);

													if (0 >= $Fee0d5a474c96306->num_rows()) {
													} else {
														foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
															$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
														}
													}

													if (0 >= count($Cdb85875fd50f459)) {
													} else {
														$B59c127fecf35c15 = e36eC1583E223bF6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => array_values($Cdb85875fd50f459), 'servers' => array(intval(XUI::$rRequest['server_id']))));
													}

													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}
										}
									} else {
										echo json_encode(array('result' => false));

										exit();
									}
								} else {
									if (XUI::$rRequest['action'] == 'proxy') {
										if (AAcd47d8157A1A09('adv', 'edit_server')) {
											$b4cd770ed1b094fe = XUI::$rRequest['sub'];

											if ($b4cd770ed1b094fe == 'delete') {
												C234Ae70b52D65a2(XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'enable') {
												$Fee0d5a474c96306->query('UPDATE `servers` SET `enabled` = 1 WHERE `id` = ?;', XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'disable') {
												$Fee0d5a474c96306->query('UPDATE `servers` SET `enabled` = 0 WHERE `id` = ?;', XUI::$rRequest['server_id']);
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'update') {
												$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', XUI::$rRequest['server_id'], time(), json_encode(array('action' => 'update')));
												echo json_encode(array('result' => true));

												exit();
											}

											if ($b4cd770ed1b094fe == 'kill') {
												if (XUI::$rSettings['redis_handler']) {
													foreach (XUI::$rServers[$d58b4f8653a391d8]['parent_id'] as $fcae8575b94f8564) {
														foreach (XUI::d92de48C36cF9438(null, $fcae8575b94f8564, null, true, false, false) as $e110a2ab6d3a4734) {
															if ($e110a2ab6d3a4734['proxy_id'] != XUI::$rRequest['server_id']) {
															} else {
																XUI::E8E9D6B2b107d8Ae($e110a2ab6d3a4734);
															}
														}
													}
												} else {
													$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `proxy_id` = ?;', XUI::$rRequest['server_id']);

													foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
														XUI::E8E9D6B2b107d8aE($C740da31596f24ef);
													}
												}

												echo json_encode(array('result' => true));

												exit();
											} else {
												echo json_encode(array('result' => false));

												exit();
											}
										} else {
											echo json_encode(array('result' => false));

											exit();
										}
									} else {
										if (XUI::$rRequest['action'] == 'package') {
											if (aACD47D8157a1A09('adv', 'edit_package')) {
												$b4cd770ed1b094fe = XUI::$rRequest['sub'];

												if ($b4cd770ed1b094fe == 'delete') {
													C6084D728c503734(XUI::$rRequest['package_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												if (in_array($b4cd770ed1b094fe, array('is_trial', 'is_official', 'can_gen_mag', 'can_gen_e2', 'only_mag', 'only_e2'))) {
													$Fee0d5a474c96306->query('UPDATE `users_packages` SET ? = ? WHERE `id` = ?;', $b4cd770ed1b094fe, XUI::$rRequest['value'], XUI::$rRequest['package_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if (XUI::$rRequest['action'] == 'code') {
											if (aacD47D8157A1A09('adv', 'add_code')) {
												$b4cd770ed1b094fe = XUI::$rRequest['sub'];

												if ($b4cd770ed1b094fe == 'delete') {
													CEa678961006676D(XUI::$rRequest['code_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if (XUI::$rRequest['action'] == 'hmac') {
											if (AaCD47d8157A1A09('adv', 'add_hmac')) {
												$b4cd770ed1b094fe = XUI::$rRequest['sub'];

												if ($b4cd770ed1b094fe == 'delete') {
													Ce67E6ac1132a14c(XUI::$rRequest['hmac_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if (XUI::$rRequest['action'] == 'group') {
											if (AaCd47d8157A1A09('adv', 'edit_group')) {
												$b4cd770ed1b094fe = XUI::$rRequest['sub'];

												if ($b4cd770ed1b094fe == 'delete') {
													B7e0f83FC2bfc30b(XUI::$rRequest['group_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												if (in_array($b4cd770ed1b094fe, array('is_admin', 'is_reseller'))) {
													$Fee0d5a474c96306->query('UPDATE `users_groups` SET ? = ? WHERE `group_id` = ?;', $b4cd770ed1b094fe, XUI::$rRequest['value'], XUI::$rRequest['group_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if (XUI::$rRequest['action'] == 'bouquet') {
											if (aaCd47d8157A1A09('adv', 'edit_bouquet')) {
												$b4cd770ed1b094fe = XUI::$rRequest['sub'];

												if ($b4cd770ed1b094fe == 'delete') {
													dC08dDCE27705ECF(XUI::$rRequest['bouquet_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if (XUI::$rRequest['action'] == 'category') {
											if (Aacd47D8157A1A09('adv', 'edit_cat')) {
												$b4cd770ed1b094fe = XUI::$rRequest['sub'];

												if ($b4cd770ed1b094fe == 'delete') {
													DBC1BC20914D084b(XUI::$rRequest['category_id']);
													echo json_encode(array('result' => true));

													exit();
												}

												echo json_encode(array('result' => false));

												exit();
											}

											echo json_encode(array('result' => false));

											exit();
										}

										if (XUI::$rRequest['action'] == 'get_package') {
											$a85e1b7d42c346a0 = array();
											$B4a5141c87d1c427 = json_decode($D4253f9520627819['override_packages'], true);
											$Fee0d5a474c96306->query('SELECT `id`, `bouquets`, `official_credits` AS `cost_credits`, `official_duration`, `official_duration_in`, `max_connections`, `can_gen_mag`, `can_gen_e2`, `only_mag`, `only_e2` FROM `users_packages` WHERE `id` = ?;', XUI::$rRequest['package_id']);

											if ($Fee0d5a474c96306->num_rows() == 1) {
												$a27e64cc6ce01033 = $Fee0d5a474c96306->get_row();

												if (!(isset($B4a5141c87d1c427[$a27e64cc6ce01033['id']]['official_credits']) && 0 < strlen($B4a5141c87d1c427[$a27e64cc6ce01033['id']]['official_credits']))) {
												} else {
													$a27e64cc6ce01033['cost_credits'] = $B4a5141c87d1c427[$a27e64cc6ce01033['id']]['official_credits'];
												}

												$a27e64cc6ce01033['exp_date'] = date('Y-m-d', strtotime('+' . intval($a27e64cc6ce01033['official_duration']) . ' ' . $a27e64cc6ce01033['official_duration_in']));

												if (!isset(XUI::$rRequest['user_id'])) {
												} else {
													if (!($d51e425eb7375255 = b4036ef9A1db8473(XUI::$rRequest['user_id']))) {
													} else {
														if (time() < $d51e425eb7375255['exp_date']) {
															$a27e64cc6ce01033['exp_date'] = date('Y-m-d', strtotime('+' . intval($a27e64cc6ce01033['official_duration']) . ' ' . $a27e64cc6ce01033['official_duration_in'], $d51e425eb7375255['exp_date']));
														} else {
															$a27e64cc6ce01033['exp_date'] = date('Y-m-d', strtotime('+' . intval($a27e64cc6ce01033['official_duration']) . ' ' . $a27e64cc6ce01033['official_duration_in']));
														}
													}
												}

												foreach (json_decode($a27e64cc6ce01033['bouquets'], true) as $ddf0508b312dbfb8) {
													$Fee0d5a474c96306->query('SELECT * FROM `bouquets` WHERE `id` = ?;', $ddf0508b312dbfb8);

													if ($Fee0d5a474c96306->num_rows() != 1) {
													} else {
														$C740da31596f24ef = $Fee0d5a474c96306->get_row();
														$a85e1b7d42c346a0[] = array('id' => $C740da31596f24ef['id'], 'bouquet_name' => str_replace("'", "\\'", $C740da31596f24ef['bouquet_name']), 'bouquet_channels' => json_decode($C740da31596f24ef['bouquet_channels'], true), 'bouquet_radios' => json_decode($C740da31596f24ef['bouquet_radios'], true), 'bouquet_movies' => json_decode($C740da31596f24ef['bouquet_movies'], true), 'bouquet_series' => json_decode($C740da31596f24ef['bouquet_series'], true));
													}
												}
												echo json_encode(array('result' => true, 'bouquets' => $a85e1b7d42c346a0, 'data' => $a27e64cc6ce01033));
											} else {
												echo json_encode(array('result' => false));
											}

											exit();
										} else {
											if (XUI::$rRequest['action'] == 'get_package_trial') {
												$a85e1b7d42c346a0 = array();
												$Fee0d5a474c96306->query('SELECT `bouquets`, `trial_credits` AS `cost_credits`, `trial_duration`, `trial_duration_in`, `max_connections`, `can_gen_mag`, `can_gen_e2`, `only_mag`, `only_e2` FROM `users_packages` WHERE `id` = ?;', XUI::$rRequest['package_id']);

												if ($Fee0d5a474c96306->num_rows() == 1) {
													$a27e64cc6ce01033 = $Fee0d5a474c96306->get_row();
													$a27e64cc6ce01033['exp_date'] = date('Y-m-d', strtotime('+' . intval($a27e64cc6ce01033['trial_duration']) . ' ' . $a27e64cc6ce01033['trial_duration_in']));

													foreach (json_decode($a27e64cc6ce01033['bouquets'], true) as $ddf0508b312dbfb8) {
														$Fee0d5a474c96306->query('SELECT * FROM `bouquets` WHERE `id` = ?;', $ddf0508b312dbfb8);

														if ($Fee0d5a474c96306->num_rows() != 1) {
														} else {
															$C740da31596f24ef = $Fee0d5a474c96306->get_row();
															$a85e1b7d42c346a0[] = array('id' => $C740da31596f24ef['id'], 'bouquet_name' => str_replace("'", "\\'", $C740da31596f24ef['bouquet_name']), 'bouquet_channels' => json_decode($C740da31596f24ef['bouquet_channels'], true), 'bouquet_radios' => json_decode($C740da31596f24ef['bouquet_radios'], true), 'bouquet_movies' => json_decode($C740da31596f24ef['bouquet_movies'], true), 'bouquet_series' => json_decode($C740da31596f24ef['bouquet_series'], true));
														}
													}
													echo json_encode(array('result' => true, 'bouquets' => $a85e1b7d42c346a0, 'data' => $a27e64cc6ce01033));
												} else {
													echo json_encode(array('result' => false));
												}

												exit();
											} else {
												if (XUI::$rRequest['action'] == 'graph_stats') {
													$E400a3101514583e = 3600;
													$C4af185e24cf9086 = bAeb48317196f323(time(), 10);
													$B34176766a53ef44 = $C4af185e24cf9086 - $E400a3101514583e;
													$b2dbef523fae7e66 = 60;
													$b9e9dedd629168b8 = array();

													foreach (range($B34176766a53ef44, $C4af185e24cf9086, $b2dbef523fae7e66) as $Ea22c4a9ab5b2176) {
														$b9e9dedd629168b8[] = $Ea22c4a9ab5b2176;
													}
													$b7a45be2d6027d36 = array();

													if (isset(XUI::$rRequest['server_id'])) {
														$Fee0d5a474c96306->query('SELECT `server_id`, `time`, `cpu`, `iostat_info`, `total_mem_used_percent`, `connections`, `streams`, `users`, `total_users`, `bytes_received`, `bytes_sent` FROM `servers_stats` WHERE `time` >= ? AND `server_id` = ? ORDER BY `time` DESC;', $B34176766a53ef44, XUI::$rRequest['server_id']);
													} else {
														$Fee0d5a474c96306->query('SELECT `server_id`, `time`, `cpu`, `iostat_info`, `total_mem_used_percent`, `connections`, `streams`, `users`, `total_users`, `bytes_received`, `bytes_sent` FROM `servers_stats` WHERE `server_id` IN (SELECT `id` FROM `servers` WHERE `server_type` = 0) AND `time` >= ? ORDER BY `time` DESC;', $B34176766a53ef44);
													}

													if (0 >= $Fee0d5a474c96306->num_rows()) {
													} else {
														foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
															if (!$a8bb73cba48fb7f6[$C740da31596f24ef['server_id']]['server_online']) {
															} else {
																$c7e1cc208c3e6c9d = DEE5eF17195EC0CF($b9e9dedd629168b8, intval($C740da31596f24ef['time']));

																if (isset($b9e9dedd629168b8[$c7e1cc208c3e6c9d][intval($C740da31596f24ef['server_id'])])) {
																} else {
																	$b7a45be2d6027d36[$c7e1cc208c3e6c9d][intval($C740da31596f24ef['server_id'])] = $C740da31596f24ef;
																}
															}
														}
													}

													$e19876d9ba369ed1 = array('cpu' => array(), 'memory' => array(), 'users' => array(), 'io' => array(), 'input' => array(), 'output' => array(), 'dates' => array(null, null));

													foreach (array_keys($b7a45be2d6027d36) as $C4af185e24cf9086) {
														$fb79146f783ec33f = 0;
														$c13d5aea2e6ed6f4 = 0;
														$Aaecffcde8295860 = 0;
														$E8f5c2caf16a2ec4 = 0;
														$C43d8823ea86c9f7 = 0;
														$Facc348fab688218 = 0;
														$a6116b52848e87c1 = 0;
														$Dec4937fa3d3feba = 0;
														$E9046c9b35948a4e = 0;
														$A75367a47c34297a = 0;
														$D2b8fe3d07ca94db = 0;

														if (isset(XUI::$rRequest['server_id'])) {
															$D2b8fe3d07ca94db = $b7a45be2d6027d36[$C4af185e24cf9086][XUI::$rRequest['server_id']]['users'];
														} else {
															$D2b8fe3d07ca94db = $b7a45be2d6027d36[$C4af185e24cf9086][SERVER_ID]['total_users'];
														}

														foreach ($b7a45be2d6027d36[$C4af185e24cf9086] as $d58b4f8653a391d8 => $a27e64cc6ce01033) {
															$fb79146f783ec33f += $a27e64cc6ce01033['cpu'];
															$c13d5aea2e6ed6f4++;
															$c2157b04a8a2204a = json_decode($a27e64cc6ce01033['iostat_info'], true);

															if (!$c2157b04a8a2204a) {
															} else {
																$C43d8823ea86c9f7 += $c2157b04a8a2204a['avg-cpu']['iowait'];
																$Facc348fab688218++;
															}

															$Aaecffcde8295860 += $a27e64cc6ce01033['total_mem_used_percent'];
															$E8f5c2caf16a2ec4++;
															$E9046c9b35948a4e += $a27e64cc6ce01033['connections'];
															$A75367a47c34297a += $a27e64cc6ce01033['streams'];
															$a6116b52848e87c1 += $a27e64cc6ce01033['bytes_received'];
															$Dec4937fa3d3feba += $a27e64cc6ce01033['bytes_sent'];
														}

														if ($e19876d9ba369ed1['dates'][0] && $C4af185e24cf9086 * 1000 >= $e19876d9ba369ed1['dates'][0]) {
														} else {
															$e19876d9ba369ed1['dates'][0] = $C4af185e24cf9086 * 1000;
														}

														if ($e19876d9ba369ed1['dates'][1] && $e19876d9ba369ed1['dates'][1] >= $C4af185e24cf9086 * 1000) {
														} else {
															$e19876d9ba369ed1['dates'][1] = $C4af185e24cf9086 * 1000;
														}

														$e19876d9ba369ed1['cpu'][] = array($C4af185e24cf9086 * 1000, round($fb79146f783ec33f / $c13d5aea2e6ed6f4, 2));
														$e19876d9ba369ed1['memory'][] = array($C4af185e24cf9086 * 1000, round($Aaecffcde8295860 / $E8f5c2caf16a2ec4, 2));
														$e19876d9ba369ed1['io'][] = array($C4af185e24cf9086 * 1000, round($C43d8823ea86c9f7 / $Facc348fab688218, 2));
														$e19876d9ba369ed1['connections'][] = array($C4af185e24cf9086 * 1000, $E9046c9b35948a4e);
														$e19876d9ba369ed1['streams'][] = array($C4af185e24cf9086 * 1000, $A75367a47c34297a);
														$e19876d9ba369ed1['users'][] = array($C4af185e24cf9086 * 1000, $D2b8fe3d07ca94db);
														$e19876d9ba369ed1['input'][] = array($C4af185e24cf9086 * 1000, round($a6116b52848e87c1 / 125000, 0));
														$e19876d9ba369ed1['output'][] = array($C4af185e24cf9086 * 1000, round($Dec4937fa3d3feba / 125000, 0));
													}
													echo json_encode($e19876d9ba369ed1, JSON_PARTIAL_OUTPUT_ON_ERROR);

													exit();
												} else {
													if (XUI::$rRequest['action'] == 'stats') {
														if (AaCd47D8157A1a09('adv', 'index')) {
															$a8bb73cba48fb7f6 = XUI::F99D78e199D641d5(true);
															$a85e1b7d42c346a0 = array('cpu' => 0, 'mem' => 0, 'io' => 0, 'fs' => 0, 'uptime' => '--', 'bytes_sent' => 0, 'bytes_received' => 0, 'open_connections' => 0, 'total_connections' => 0, 'online_users' => 0, 'total_users' => 0, 'total_streams' => 0, 'total_running_streams' => 0, 'offline_streams' => 0, 'requests_per_second' => 0, 'servers' => array());

															if (XUI::$rSettings['redis_handler']) {
																$a85e1b7d42c346a0['total_users'] = XUI::$rSettings['total_users'];
															} else {
																$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');

																if (0 >= $Fee0d5a474c96306->num_rows()) {
																} else {
																	$a85e1b7d42c346a0['total_users'] = $Fee0d5a474c96306->num_rows();
																}
															}

															if (isset(XUI::$rRequest['server_id'])) {
																$d58b4f8653a391d8 = intval(XUI::$rRequest['server_id']);
																$C39e5afe2a23deaa = json_decode($a8bb73cba48fb7f6[$d58b4f8653a391d8]['watchdog_data'], true);

																if (!is_array($C39e5afe2a23deaa)) {
																} else {
																	$a85e1b7d42c346a0['uptime'] = $C39e5afe2a23deaa['uptime'];
																	$a85e1b7d42c346a0['mem'] = round($C39e5afe2a23deaa['total_mem_used_percent'], 0);
																	$a85e1b7d42c346a0['cpu'] = round($C39e5afe2a23deaa['cpu'], 0);

																	if (!isset($C39e5afe2a23deaa['iostat_info'])) {
																	} else {
																		$a85e1b7d42c346a0['io'] = round($C39e5afe2a23deaa['iostat_info']['avg-cpu']['iowait'], 0);
																	}

																	if (!isset($C39e5afe2a23deaa['total_disk_space'])) {
																	} else {
																		$a85e1b7d42c346a0['fs'] = intval(($C39e5afe2a23deaa['total_disk_space'] - $C39e5afe2a23deaa['free_disk_space']) / $C39e5afe2a23deaa['total_disk_space'] * 100);
																	}

																	$a85e1b7d42c346a0['bytes_received'] = intval($C39e5afe2a23deaa['bytes_received']);
																	$a85e1b7d42c346a0['bytes_sent'] = intval($C39e5afe2a23deaa['bytes_sent']);
																}

																$a85e1b7d42c346a0['requests_per_second'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['requests_per_second'];

																if (XUI::$rSettings['redis_handler']) {
																	$a85e1b7d42c346a0['open_connections'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['connections'];
																	$a85e1b7d42c346a0['online_users'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['users'];

																	foreach (array_keys($a8bb73cba48fb7f6) as $e154835c9fa166f7) {
																		if (!$a8bb73cba48fb7f6[$e154835c9fa166f7]['server_online']) {
																		} else {
																			$a85e1b7d42c346a0['total_connections'] += $a8bb73cba48fb7f6[$e154835c9fa166f7]['connections'];
																		}
																	}
																} else {
																	$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `server_id` = ? AND `hls_end` = 0;', $d58b4f8653a391d8);

																	if (0 >= $Fee0d5a474c96306->num_rows()) {
																	} else {
																		$a85e1b7d42c346a0['open_connections'] = $Fee0d5a474c96306->get_row()['count'];
																	}

																	$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `hls_end` = 0;');

																	if (0 >= $Fee0d5a474c96306->num_rows()) {
																	} else {
																		$a85e1b7d42c346a0['total_connections'] = $Fee0d5a474c96306->get_row()['count'];
																	}

																	$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `server_id` = ? AND `hls_end` = 0 GROUP BY `user_id`;', $d58b4f8653a391d8);

																	if (0 >= $Fee0d5a474c96306->num_rows()) {
																	} else {
																		$a85e1b7d42c346a0['online_users'] = $Fee0d5a474c96306->num_rows();
																	}
																}

																$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `stream_status` <> 2 AND `type` = 1;', $d58b4f8653a391d8);

																if (0 >= $Fee0d5a474c96306->num_rows()) {
																} else {
																	$a85e1b7d42c346a0['total_streams'] = $Fee0d5a474c96306->get_row()['count'];
																}

																$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `pid` > 0 AND `type` = 1;', $d58b4f8653a391d8);

																if (0 >= $Fee0d5a474c96306->num_rows()) {
																} else {
																	$a85e1b7d42c346a0['total_running_streams'] = $Fee0d5a474c96306->get_row()['count'];
																}

																$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `type` = 1 AND (`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0);', $d58b4f8653a391d8);

																if (0 >= $Fee0d5a474c96306->num_rows()) {
																} else {
																	$a85e1b7d42c346a0['offline_streams'] = $Fee0d5a474c96306->get_row()['count'];
																}

																$a85e1b7d42c346a0['network_guaranteed_speed'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['network_guaranteed_speed'];
															} else {
																$fad73125a2cca3ed = 0;

																if (XUI::$rSettings['redis_handler']) {
																} else {
																	$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `hls_end` = 0;');

																	if (0 < $Fee0d5a474c96306->num_rows()) {
																		$E9046c9b35948a4e = $Fee0d5a474c96306->get_row()['count'];
																	} else {
																		$E9046c9b35948a4e = 0;
																	}

																	$Fee0d5a474c96306->query('SELECT `activity_id` AS `count` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');

																	if (0 < $Fee0d5a474c96306->num_rows()) {
																		$D2b8fe3d07ca94db = $Fee0d5a474c96306->num_rows();
																	} else {
																		$D2b8fe3d07ca94db = 0;
																	}

																	$Fee0d5a474c96306->query('SELECT `user_id` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');
																	$a85e1b7d42c346a0['online_users'] = $Fee0d5a474c96306->num_rows();
																	$a85e1b7d42c346a0['open_connections'] = $E9046c9b35948a4e;
																}

																$A75367a47c34297a = $Fbf6990070637022 = $B14ecad105178a33 = $E8ad3bf5b87114a3 = $Fe223acd5287f873 = array();
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(*) AS `count` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$Fe223acd5287f873[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(DISTINCT(`user_id`)) AS `count` FROM `lines_live` GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$E8ad3bf5b87114a3[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `stream_status` <> 2 AND `type` = 1 GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$A75367a47c34297a[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `type` = 1 AND (`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0) GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$B14ecad105178a33[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `pid` > 0 AND `type` = 1 GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$Fbf6990070637022[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}

																foreach (array_keys($a8bb73cba48fb7f6) as $d58b4f8653a391d8) {
																	if (!$a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_online']) {
																	} else {
																		$d49041d5f05a9270 = array();

																		if (XUI::$rSettings['redis_handler']) {
																			$d49041d5f05a9270['open_connections'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['connections'];
																			$a85e1b7d42c346a0['open_connections'] += $a8bb73cba48fb7f6[$d58b4f8653a391d8]['connections'];
																			$a85e1b7d42c346a0['total_connections'] += $a8bb73cba48fb7f6[$d58b4f8653a391d8]['connections'];
																			$d49041d5f05a9270['online_users'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['users'];
																			$a85e1b7d42c346a0['online_users'] += $a8bb73cba48fb7f6[$d58b4f8653a391d8]['users'];
																			$a85e1b7d42c346a0['total_users'] += $a8bb73cba48fb7f6[$d58b4f8653a391d8]['users'];
																		} else {
																			$d49041d5f05a9270['open_connections'] = ($Fe223acd5287f873[$d58b4f8653a391d8] ?: 0);
																			$d49041d5f05a9270['online_users'] = ($E8ad3bf5b87114a3[$d58b4f8653a391d8] ?: 0);
																		}

																		$d49041d5f05a9270['requests_per_second'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['requests_per_second'];
																		$d49041d5f05a9270['total_streams'] = ($A75367a47c34297a[$d58b4f8653a391d8] ?: 0);
																		$d49041d5f05a9270['total_running_streams'] = ($Fbf6990070637022[$d58b4f8653a391d8] ?: 0);
																		$d49041d5f05a9270['offline_streams'] = ($B14ecad105178a33[$d58b4f8653a391d8] ?: 0);
																		$d49041d5f05a9270['network_guaranteed_speed'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['network_guaranteed_speed'];
																		$C39e5afe2a23deaa = json_decode($a8bb73cba48fb7f6[$d58b4f8653a391d8]['watchdog_data'], true);

																		if (!is_array($C39e5afe2a23deaa)) {
																		} else {
																			$d49041d5f05a9270['uptime'] = $C39e5afe2a23deaa['uptime'];
																			$d49041d5f05a9270['mem'] = round($C39e5afe2a23deaa['total_mem_used_percent'], 0);
																			$d49041d5f05a9270['cpu'] = round($C39e5afe2a23deaa['cpu'], 0);

																			if (!isset($C39e5afe2a23deaa['iostat_info'])) {
																			} else {
																				$d49041d5f05a9270['io'] = round($C39e5afe2a23deaa['iostat_info']['avg-cpu']['iowait'], 0);
																			}

																			if (!isset($C39e5afe2a23deaa['total_disk_space'])) {
																			} else {
																				$d49041d5f05a9270['fs'] = intval(($C39e5afe2a23deaa['total_disk_space'] - $C39e5afe2a23deaa['free_disk_space']) / $C39e5afe2a23deaa['total_disk_space'] * 100);
																			}

																			$d49041d5f05a9270['bytes_received'] = intval($C39e5afe2a23deaa['bytes_received']);
																			$d49041d5f05a9270['bytes_sent'] = intval($C39e5afe2a23deaa['bytes_sent']);
																			$a85e1b7d42c346a0['bytes_received'] += intval($C39e5afe2a23deaa['bytes_received']);
																			$a85e1b7d42c346a0['bytes_sent'] += intval($C39e5afe2a23deaa['bytes_sent']);
																		}

																		$d49041d5f05a9270['total_connections'] = $E9046c9b35948a4e;
																		$d49041d5f05a9270['server_id'] = $d58b4f8653a391d8;
																		$d49041d5f05a9270['server_type'] = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_type'];
																		$a85e1b7d42c346a0['servers'][] = $d49041d5f05a9270;
																	}
																}

																foreach ($a85e1b7d42c346a0['servers'] as $fcdd8fd7a8500c08) {
																	$a85e1b7d42c346a0['total_streams'] += $fcdd8fd7a8500c08['total_streams'];
																	$a85e1b7d42c346a0['total_running_streams'] += $fcdd8fd7a8500c08['total_running_streams'];
																	$a85e1b7d42c346a0['offline_streams'] += $fcdd8fd7a8500c08['offline_streams'];
																}
																$a85e1b7d42c346a0['online_users'] = XUI::$rSettings['total_users'];
															}

															echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

															exit();
														} else {
															echo json_encode(array('result' => false));

															exit();
														}
													} else {
														if (XUI::$rRequest['action'] == 'header_stats') {
															if (AACd47d8157a1a09('adv', 'index')) {
																$a85e1b7d42c346a0 = array('bytes_sent' => 0, 'bytes_received' => 0, 'total_connections' => 0, 'total_users' => 0, 'total_running_streams' => 0, 'offline_streams' => 0);

																if (!XUI::$rSettings['redis_handler']) {
																	$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `hls_end` = 0;');

																	if (0 >= $Fee0d5a474c96306->num_rows()) {
																	} else {
																		$a85e1b7d42c346a0['total_connections'] = $Fee0d5a474c96306->get_row()['count'];
																	}

																	$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');

																	if (0 >= $Fee0d5a474c96306->num_rows()) {
																	} else {
																		$a85e1b7d42c346a0['total_users'] = $Fee0d5a474c96306->num_rows();
																	}
																} else {
																	$a85e1b7d42c346a0['total_users'] = XUI::$rSettings['total_users'];
																}

																$C10abf2c20c0664b = $b091609b9130bea9 = array();
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `pid` > 0 AND `type` = 1 GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$C10abf2c20c0664b[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}
																$Fee0d5a474c96306->query('SELECT `server_id`, COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `type` = 1 AND (`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0) GROUP BY `server_id`;');

																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																	$b091609b9130bea9[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['count']);
																}

																foreach (array_keys($a8bb73cba48fb7f6) as $d58b4f8653a391d8) {
																	if (!$a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_online']) {
																	} else {
																		if (!XUI::$rSettings['redis_handler']) {
																		} else {
																			$a85e1b7d42c346a0['total_connections'] += $a8bb73cba48fb7f6[$d58b4f8653a391d8]['connections'];
																		}

																		$a85e1b7d42c346a0['total_running_streams'] += ($C10abf2c20c0664b[$d58b4f8653a391d8] ?: 0);
																		$a85e1b7d42c346a0['offline_streams'] += ($b091609b9130bea9[$d58b4f8653a391d8] ?: 0);
																		$C39e5afe2a23deaa = json_decode($a8bb73cba48fb7f6[$d58b4f8653a391d8]['watchdog_data'], true);

																		if (!is_array($C39e5afe2a23deaa)) {
																		} else {
																			$a85e1b7d42c346a0['bytes_received'] += intval($C39e5afe2a23deaa['bytes_received']);
																			$a85e1b7d42c346a0['bytes_sent'] += intval($C39e5afe2a23deaa['bytes_sent']);
																		}
																	}
																}
																echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																exit();
															} else {
																echo json_encode(array('result' => false));

																exit();
															}
														} else {
															if (XUI::$rRequest['action'] == 'review_selection') {
																if (AAcD47D8157a1a09('adv', 'edit_cchannel') || aACd47D8157a1A09('adv', 'create_channel')) {
																	$a85e1b7d42c346a0 = array('streams' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['data'])) {
																	} else {
																		foreach (XUI::$rRequest['data'] as $F26087d31c2bbe4d) {
																			$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name`, `stream_source` FROM `streams` WHERE `id` = ?;', $F26087d31c2bbe4d);

																			if ($Fee0d5a474c96306->num_rows() != 1) {
																			} else {
																				$a85e1b7d42c346a0['streams'][] = $Fee0d5a474c96306->get_row();
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'review_bouquet') {
																if (aacd47D8157a1A09('adv', 'edit_bouquet') || aAcd47D8157A1A09('adv', 'add_bouquet')) {
																	$a85e1b7d42c346a0 = array('streams' => array(), 'movies' => array(), 'series' => array(), 'radios' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['data']['stream'])) {
																	} else {
																		foreach (XUI::$rRequest['data']['stream'] as $F26087d31c2bbe4d) {
																			$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name`, `type` FROM `streams` WHERE `id` = ? AND `type` IN (1,3);', $F26087d31c2bbe4d);

																			if ($Fee0d5a474c96306->num_rows() != 1) {
																			} else {
																				$a27e64cc6ce01033 = $Fee0d5a474c96306->get_row();
																				$a85e1b7d42c346a0['streams'][] = $a27e64cc6ce01033;
																			}
																		}
																	}

																	if (!isset(XUI::$rRequest['data']['movies'])) {
																	} else {
																		foreach (XUI::$rRequest['data']['movies'] as $F26087d31c2bbe4d) {
																			$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name`, `type` FROM `streams` WHERE `id` = ? AND `type` = 2;', $F26087d31c2bbe4d);

																			if ($Fee0d5a474c96306->num_rows() != 1) {
																			} else {
																				$a27e64cc6ce01033 = $Fee0d5a474c96306->get_row();
																				$a85e1b7d42c346a0['movies'][] = $a27e64cc6ce01033;
																			}
																		}
																	}

																	if (!isset(XUI::$rRequest['data']['radios'])) {
																	} else {
																		foreach (XUI::$rRequest['data']['radios'] as $F26087d31c2bbe4d) {
																			$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name`, `type` FROM `streams` WHERE `id` = ? AND `type` = 4;', $F26087d31c2bbe4d);

																			if ($Fee0d5a474c96306->num_rows() != 1) {
																			} else {
																				$a27e64cc6ce01033 = $Fee0d5a474c96306->get_row();
																				$a85e1b7d42c346a0['radios'][] = $a27e64cc6ce01033;
																			}
																		}
																	}

																	if (!isset(XUI::$rRequest['data']['series'])) {
																	} else {
																		foreach (XUI::$rRequest['data']['series'] as $A2d65843292b5c59) {
																			$Fee0d5a474c96306->query('SELECT `id`, `title` FROM `streams_series` WHERE `id` = ?;', $A2d65843292b5c59);

																			if ($Fee0d5a474c96306->num_rows() != 1) {
																			} else {
																				$a27e64cc6ce01033 = $Fee0d5a474c96306->get_row();
																				$a85e1b7d42c346a0['series'][] = $a27e64cc6ce01033;
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'epglist') {
																if (aaCd47D8157A1a09('adv', 'import_streams')) {
																	$ca518e82bd328243 = array();
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		$bcd2ef56fb56b9e6 = $Ba25df693881b5a7 = array();
																		$Fee0d5a474c96306->query('SELECT `epg_channels`.`epg_id`, `epg_channels`.`channel_id`, `epg_channels`.`name`, `epg_channels`.`langs`, `epg`.`epg_name` FROM `epg_channels` LEFT JOIN `epg` ON `epg_channels`.`epg_id` = `epg`.`id` WHERE (LOWER(`epg_channels`.`channel_id`) LIKE ? OR LOWER(`epg_channels`.`name`) LIKE ?) ORDER BY `epg_channels`.`name` ASC LIMIT 50;', strtolower(XUI::$rRequest['search']) . '%', strtolower(XUI::$rRequest['search']) . '%');

																		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																			if (isset($bcd2ef56fb56b9e6[$C740da31596f24ef['epg_id']])) {
																			} else {
																				$bcd2ef56fb56b9e6[$C740da31596f24ef['epg_id']] = $C740da31596f24ef['epg_name'];
																			}

																			$bf25322090210c4b = json_decode($C740da31596f24ef['langs'], true);
																			$Ba25df693881b5a7[$C740da31596f24ef['epg_id']][] = array('id' => $C740da31596f24ef['channel_id'], 'text' => $C740da31596f24ef['name'], 'icon' => null, 'lang' => (isset($bf25322090210c4b[0]) ? $bf25322090210c4b[0] : ''), 'epg_id' => $C740da31596f24ef['epg_id'], 'type' => 0);
																		}

																		foreach ($Ba25df693881b5a7 as $b68956643e52e9b7 => $c15d5b523e931f51) {
																			$a85e1b7d42c346a0['items'][] = array('text' => $bcd2ef56fb56b9e6[$b68956643e52e9b7], 'children' => $c15d5b523e931f51);
																			$a85e1b7d42c346a0['total_count'] += count($c15d5b523e931f51);
																		}
																		$Da1a9973a707fdfe = array('#' => 'Undefined Language');
																		$Fee0d5a474c96306->query('SELECT `language`, `name` FROM `epg_languages`;');

																		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																			$Da1a9973a707fdfe[$C740da31596f24ef['language']] = $C740da31596f24ef['name'];
																		}
																		$Dc841b3d596ba97b = array();
																		$Fee0d5a474c96306->query('SELECT `callSign`, `bcastLangs`, `name`, `picon` FROM `epg_api` WHERE (`callSign` LIKE ? OR `name` LIKE ?) GROUP BY CONCAT(`name`, `bcastLangs`) ORDER BY `name` ASC LIMIT 50;', XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%');

																		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																			$bf25322090210c4b = json_decode($C740da31596f24ef['bcastLangs'], true);

																			if (count($bf25322090210c4b) != 0) {
																			} else {
																				$bf25322090210c4b = array('#');
																			}

																			foreach ($bf25322090210c4b as $C54c804377e62501) {
																				if (isset($Dc841b3d596ba97b[$C54c804377e62501])) {
																				} else {
																					$Dc841b3d596ba97b[$C54c804377e62501] = array();
																				}

																				$Dc841b3d596ba97b[$C54c804377e62501][] = array('id' => $C740da31596f24ef['callSign'], 'text' => $C740da31596f24ef['name'], 'icon' => $C740da31596f24ef['picon'], 'lang' => $C54c804377e62501, 'type' => 1);
																			}
																		}

																		foreach ($Dc841b3d596ba97b as $C54c804377e62501 => $c15d5b523e931f51) {
																			$a85e1b7d42c346a0['items'][] = array('text' => 'EPG API - ' . $Da1a9973a707fdfe[$C54c804377e62501], 'children' => $c15d5b523e931f51);
																			$a85e1b7d42c346a0['total_count'] += count($c15d5b523e931f51);
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'serieslist') {
																if (AAcd47d8157a1a09('adv', 'episodes')) {
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		if (isset(XUI::$rRequest['page'])) {
																			$ddf21fc658e95052 = intval(XUI::$rRequest['page']);
																		} else {
																			$ddf21fc658e95052 = 1;
																		}

																		$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `count` FROM `streams_series` WHERE `title` LIKE ?;', '%' . XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] = $Fee0d5a474c96306->get_row()['count'];
																		$Fee0d5a474c96306->query('SELECT `id`, `title` FROM `streams_series` WHERE `title` LIKE ? ORDER BY `title` ASC LIMIT ' . ($ddf21fc658e95052 - 1) * 100 . ', 100;', '%' . XUI::$rRequest['search'] . '%');

																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																		} else {
																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$a85e1b7d42c346a0['items'][] = array('id' => $C740da31596f24ef['id'], 'text' => $C740da31596f24ef['title']);
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'reguserlist') {
																if (AacD47D8157a1A09('adv', 'mng_regusers') || AaCD47D8157A1A09('adv', 'manage_mag') || AaCd47d8157A1A09('adv', 'manage_e2') || Aacd47D8157a1a09('adv', 'edit_e2') || AaCD47D8157A1A09('adv', 'add_e2') || AAcd47d8157A1a09('adv', 'add_mag') || AaCD47d8157A1a09('adv', 'edit_mag')) {
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		if (isset(XUI::$rRequest['page'])) {
																			$ddf21fc658e95052 = intval(XUI::$rRequest['page']);
																		} else {
																			$ddf21fc658e95052 = 1;
																		}

																		$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `id` FROM `users` WHERE `username` LIKE ?;', '%' . XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] = $Fee0d5a474c96306->get_row()['id'];
																		$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `users` WHERE `username` LIKE ? ORDER BY `username` ASC LIMIT ' . ($ddf21fc658e95052 - 1) * 100 . ', 100;', '%' . XUI::$rRequest['search'] . '%');

																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																		} else {
																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$a85e1b7d42c346a0['items'][] = array('id' => $C740da31596f24ef['id'], 'text' => $C740da31596f24ef['username']);
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'userlist') {
																if (aAcD47d8157A1A09('adv', 'edit_e2') || Aacd47D8157A1A09('adv', 'add_e2') || AACD47D8157A1a09('adv', 'add_mag') || aacd47d8157A1A09('adv', 'edit_mag')) {
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		if (isset(XUI::$rRequest['page'])) {
																			$ddf21fc658e95052 = intval(XUI::$rRequest['page']);
																		} else {
																			$ddf21fc658e95052 = 1;
																		}

																		$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `id` FROM `lines` WHERE `username` LIKE ? AND `is_e2` = 0 AND `is_mag` = 0;', XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] = $Fee0d5a474c96306->get_row()['id'];
																		$Fee0d5a474c96306->query('SELECT COUNT(`device_id`) AS `id` FROM `enigma2_devices` WHERE `mac` LIKE ?;', XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] += $Fee0d5a474c96306->get_row()['id'];
																		$Fee0d5a474c96306->query('SELECT COUNT(`mag_id`) AS `id` FROM `mag_devices` WHERE `mac` LIKE ?;', XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] += $Fee0d5a474c96306->get_row()['id'];
																		$Fee0d5a474c96306->query('SELECT `id`, IF(`lines`.`is_mag`, `mag_devices`.`mac`, IF(`lines`.`is_e2`, `enigma2_devices`.`mac`, `lines`.`username`)) AS `username` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` WHERE `lines`.`username` LIKE ? OR `mag_devices`.`mac` LIKE ? OR `enigma2_devices`.`mac` LIKE ? ORDER BY `username` ASC LIMIT ' . ($ddf21fc658e95052 - 1) * 100 . ', 100;', XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%');

																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																		} else {
																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$a85e1b7d42c346a0['items'][] = array('id' => $C740da31596f24ef['id'], 'text' => $C740da31596f24ef['username']);
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'streamlist') {
																if (aacD47d8157A1a09('adv', 'manage_mag')) {
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		if (isset(XUI::$rRequest['page'])) {
																			$ddf21fc658e95052 = intval(XUI::$rRequest['page']);
																		} else {
																			$ddf21fc658e95052 = 1;
																		}

																		$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `id` FROM `streams` WHERE `stream_display_name` LIKE ?;', '%' . XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] = $Fee0d5a474c96306->get_row()['id'];
																		$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `stream_display_name` LIKE ? ORDER BY `stream_display_name` ASC LIMIT ' . ($ddf21fc658e95052 - 1) * 100 . ', 100;', '%' . XUI::$rRequest['search'] . '%');

																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																		} else {
																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$a85e1b7d42c346a0['items'][] = array('id' => $C740da31596f24ef['id'], 'text' => $C740da31596f24ef['stream_display_name']);
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'adaptivelist') {
																if (AacD47d8157A1a09('adv', 'edit_stream')) {
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		if (isset(XUI::$rRequest['page'])) {
																			$ddf21fc658e95052 = intval(XUI::$rRequest['page']);
																		} else {
																			$ddf21fc658e95052 = 1;
																		}

																		$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `id` FROM `streams` WHERE (`stream_display_name` LIKE ? OR `id` LIKE ?) AND `type` = 1;', '%' . XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] = $Fee0d5a474c96306->get_row()['id'];
																		$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE (`stream_display_name` LIKE ? OR `id` LIKE ?) AND `type` = 1 ORDER BY `stream_display_name` ASC LIMIT ' . ($ddf21fc658e95052 - 1) * 100 . ', 100;', '%' . XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%');

																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																		} else {
																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$a85e1b7d42c346a0['items'][] = array('id' => $C740da31596f24ef['id'], 'text' => '[' . $C740da31596f24ef['id'] . '] ' . $C740da31596f24ef['stream_display_name']);
																			}
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'titlesync') {
																if (aACd47d8157A1a09('adv', 'edit_stream')) {
																	$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);

																	if (!isset(XUI::$rRequest['search'])) {
																	} else {
																		if (isset(XUI::$rRequest['page'])) {
																			$ddf21fc658e95052 = intval(XUI::$rRequest['page']);
																		} else {
																			$ddf21fc658e95052 = 1;
																		}

																		$Fee0d5a474c96306->query("SELECT COUNT(`stream_id`) AS `stream_id` FROM `providers_streams` WHERE `type` = 'live' AND (`stream_display_name` LIKE ? OR `stream_id` LIKE ?);", '%' . XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%');
																		$a85e1b7d42c346a0['total_count'] = $Fee0d5a474c96306->get_row()['stream_id'];
																		$Fee0d5a474c96306->query("SELECT `providers`.`name`, `providers_streams`.`provider_id`, `providers_streams`.`stream_id`, `providers_streams`.`stream_display_name` FROM `providers_streams` LEFT JOIN `providers` ON `providers`.`id` = `providers_streams`.`provider_id` WHERE `providers_streams`.`type` = 'live' AND (`stream_display_name` LIKE ? OR `stream_id` LIKE ?) ORDER BY `stream_display_name` ASC LIMIT " . ($ddf21fc658e95052 - 1) * 100 . ', 100;', '%' . XUI::$rRequest['search'] . '%', XUI::$rRequest['search'] . '%');
																		$ca518e82bd328243 = array();

																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																		} else {
																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																				$ca518e82bd328243[$C740da31596f24ef['provider_id']][] = $C740da31596f24ef;
																			}
																		}

																		foreach ($ca518e82bd328243 as $e41ee48af2b8e2a5 => $b3439582205053ea) {
																			$C3f4349149fa1662 = array('text' => $b3439582205053ea[0]['name'], 'children' => array());

																			foreach ($b3439582205053ea as $C740da31596f24ef) {
																				$C3f4349149fa1662['children'][] = array('id' => $C740da31596f24ef['provider_id'] . '_' . $C740da31596f24ef['stream_id'], 'text' => '[' . $C740da31596f24ef['stream_id'] . '] ' . $C740da31596f24ef['stream_display_name']);
																			}
																			$a85e1b7d42c346a0['items'][] = $C3f4349149fa1662;
																		}
																	}

																	echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'force_epg') {
																if (AAcd47d8157A1A09('adv', 'epg')) {
																	shell_exec(PHP_BIN . ' ' . CRON_PATH . 'epg.php > /dev/null 2>/dev/null &');
																	echo json_encode(array('result' => true));

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'tmdb_search') {
																if (aacD47d8157a1a09('adv', 'add_series') || aACd47d8157a1a09('adv', 'edit_series') || aAcD47d8157a1a09('adv', 'add_movie') || AaCD47d8157a1A09('adv', 'edit_movie') || aACD47D8157a1A09('adv', 'add_episode') || aACd47d8157A1A09('adv', 'edit_episode')) {
																	$Be47c94a460069d8 = XUI::$rRequest['term'];

																	if (0 >= strlen($Be47c94a460069d8)) {
																	} else {
																		include XUI_HOME . 'includes/libs/tmdb.php';

																		if (0 < strlen(XUI::$rRequest['language'])) {
																			$a69d576081840514 = new TMDB($F2d4d8f7981ac574['tmdb_api_key'], XUI::$rRequest['language']);
																		} else {
																			if (0 < strlen($F2d4d8f7981ac574['tmdb_language'])) {
																				$a69d576081840514 = new TMDB($F2d4d8f7981ac574['tmdb_api_key'], $F2d4d8f7981ac574['tmdb_language']);
																			} else {
																				$a69d576081840514 = new TMDB($F2d4d8f7981ac574['tmdb_api_key']);
																			}
																		}

																		if (!(is_numeric($Be47c94a460069d8) && in_array(XUI::$rRequest['type'], array('movie', 'series', 'episode')))) {
																		} else {
																			if (XUI::$rRequest['type'] == 'movie') {
																				$B59c127fecf35c15 = array(json_decode($a69d576081840514->getMovie($Be47c94a460069d8)->getJSON(), true));
																			} else {
																				if (XUI::$rRequest['type'] == 'series') {
																					$B59c127fecf35c15 = array(json_decode($a69d576081840514->getTVShow($Be47c94a460069d8)->getJSON(), true));
																				} else {
																					$B59c127fecf35c15 = json_decode($a69d576081840514->getSeason($Be47c94a460069d8, intval(XUI::$rRequest['season']))->getJSON(), true);

																					if (!(isset($B59c127fecf35c15['tvshow_id']) && $B59c127fecf35c15['tvshow_id'] == 0)) {
																					} else {
																						$B59c127fecf35c15 = null;
																					}
																				}
																			}

																			if (!is_array($B59c127fecf35c15)) {
																			} else {
																				echo json_encode(array('result' => true, 'data' => $B59c127fecf35c15));

																				exit();
																			}
																		}

																		$fab84a7bc25d47ab = e6C35233AD4E96CD($Be47c94a460069d8);
																		$Be47c94a460069d8 = $fab84a7bc25d47ab['title'];
																		$Bec25219bd671a85 = array();

																		if (XUI::$rRequest['type'] == 'movie') {
																			$c15d5b523e931f51 = $a69d576081840514->searchMovie($Be47c94a460069d8);

																			foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
																				$Bec25219bd671a85[] = json_decode($B59c127fecf35c15->getJSON(), true);
																			}
																		} else {
																			if (XUI::$rRequest['type'] != 'series') {
																			} else {
																				$c15d5b523e931f51 = $a69d576081840514->searchTVShow($Be47c94a460069d8);

																				foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
																					$Bec25219bd671a85[] = json_decode($B59c127fecf35c15->getJSON(), true);
																				}
																			}
																		}

																		if (0 >= count($Bec25219bd671a85)) {
																		} else {
																			echo json_encode(array('result' => true, 'data' => $Bec25219bd671a85));

																			exit();
																		}
																	}

																	echo json_encode(array('result' => false));

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'tmdb') {
																if (AAcd47d8157a1A09('adv', 'add_series') || AacD47D8157A1a09('adv', 'edit_series') || AacD47d8157A1a09('adv', 'add_movie') || AAcd47D8157A1A09('adv', 'edit_movie') || aAcD47D8157A1A09('adv', 'add_episode') || aaCd47D8157a1A09('adv', 'edit_episode')) {
																	include XUI_HOME . 'includes/libs/tmdb.php';

																	if (0 < strlen(XUI::$rRequest['language'])) {
																		$a69d576081840514 = new TMDB($F2d4d8f7981ac574['tmdb_api_key'], XUI::$rRequest['language']);
																	} else {
																		if (0 < strlen($F2d4d8f7981ac574['tmdb_language'])) {
																			$a69d576081840514 = new TMDB($F2d4d8f7981ac574['tmdb_api_key'], $F2d4d8f7981ac574['tmdb_language']);
																		} else {
																			$a69d576081840514 = new TMDB($F2d4d8f7981ac574['tmdb_api_key']);
																		}
																	}

																	$C3c8913edb801c35 = XUI::$rRequest['id'];

																	if (XUI::$rRequest['type'] == 'movie') {
																		$a417725f28d75ef7 = $a69d576081840514->getMovie($C3c8913edb801c35);
																		$B59c127fecf35c15 = json_decode($a417725f28d75ef7->getJSON(), true);
																		$B59c127fecf35c15['trailer'] = $a417725f28d75ef7->getTrailer();
																	} else {
																		if (XUI::$rRequest['type'] != 'series') {
																		} else {
																			$bbc84f53c534450d = $a69d576081840514->getTVShow($C3c8913edb801c35);
																			$B59c127fecf35c15 = json_decode($bbc84f53c534450d->getJSON(), true);
																			$B59c127fecf35c15['trailer'] = e6D2AeD48f58352C($C3c8913edb801c35, (!empty(XUI::$rRequest['language']) ? XUI::$rRequest['language'] : $F2d4d8f7981ac574['tmdb_language']));
																		}
																	}

																	if (!$B59c127fecf35c15) {
																		echo json_encode(array('result' => false));

																		exit();
																	}

																	echo json_encode(array('result' => true, 'data' => $B59c127fecf35c15));

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'listdir') {
																if (aaCd47d8157A1A09('adv', 'add_episode') || aAcD47D8157a1a09('adv', 'edit_episode') || AacD47D8157A1a09('adv', 'add_movie') || aaCD47d8157a1A09('adv', 'edit_movie') || AaCD47d8157A1A09('adv', 'create_channel') || aaCD47d8157A1a09('adv', 'edit_cchannel') || aACd47D8157A1a09('adv', 'folder_watch_add')) {
																	if (XUI::$rRequest['filter'] == 'video') {
																		$d87ef185288a0924 = array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts');
																	} else {
																		if (XUI::$rRequest['filter'] == 'subs') {
																			$d87ef185288a0924 = array('srt', 'sub', 'sbv');
																		} else {
																			$d87ef185288a0924 = array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts', 'srt', 'sub', 'sbv');
																		}
																	}

																	if (!(isset(XUI::$rRequest['server']) && isset(XUI::$rRequest['dir']))) {
																		echo json_encode(array('result' => false));

																		exit();
																	}

																	echo json_encode(array('result' => true, 'data' => A2C50e6040039E78(intval(XUI::$rRequest['server']), XUI::$rRequest['dir'], $d87ef185288a0924)));

																	exit();
																}

																echo json_encode(array('result' => false));

																exit();
															}

															if (XUI::$rRequest['action'] == 'fingerprint') {
																if (aACD47D8157A1A09('adv', 'fingerprint')) {
																	$a27e64cc6ce01033 = json_decode(XUI::$rRequest['data'], true);
																	$fe4ab20bd2e08875 = array();

																	foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
																		if ((360 < time() - $e81220b4451f37c9['last_check_ago'] || $e81220b4451f37c9['status'] == 2) && $e81220b4451f37c9['is_main'] == 0 && $e81220b4451f37c9['status'] != 3) {
																			$f0a85bb7cb144853 = true;
																		} else {
																			$f0a85bb7cb144853 = false;
																		}

																		if ($e81220b4451f37c9['status'] != 1 || $f0a85bb7cb144853) {
																		} else {
																			$fe4ab20bd2e08875[] = $e81220b4451f37c9['id'];
																		}
																	}

																	if (!(0 < $a27e64cc6ce01033['id'] && 0 < $a27e64cc6ce01033['font_size'] && 0 < strlen($a27e64cc6ce01033['font_color']) && 0 < strlen($a27e64cc6ce01033['xy_offset']) && (0 < strlen($a27e64cc6ce01033['message']) || $a27e64cc6ce01033['type'] < 3))) {
																	} else {
																		if (XUI::$rSettings['redis_handler']) {
																			if (isset($a27e64cc6ce01033['user'])) {
																				$b3439582205053ea = XUI::d92dE48c36Cf9438($a27e64cc6ce01033['id'], null, null, true, false, false);
																			} else {
																				$b3439582205053ea = XUI::D92De48c36cf9438(null, null, $a27e64cc6ce01033['id'], true, false, false);
																			}

																			$dec4b1df9997c4d4 = $b174976b99c4ec48 = array();

																			foreach ($b3439582205053ea as $C740da31596f24ef) {
																				if (in_array($C740da31596f24ef['user_id'], $b174976b99c4ec48)) {
																				} else {
																					$b174976b99c4ec48[] = intval($C740da31596f24ef['user_id']);
																				}
																			}

																			if (0 >= count($b174976b99c4ec48)) {
																			} else {
																				$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `lines` WHERE `id` IN (' . implode(',', $b174976b99c4ec48) . ');');

																				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																					$dec4b1df9997c4d4[$C740da31596f24ef['id']] = $C740da31596f24ef['username'];
																				}
																			}
																		} else {
																			if (isset($a27e64cc6ce01033['user'])) {
																				$Fee0d5a474c96306->query('SELECT `lines_live`.`activity_id`, `lines_live`.`uuid`, `lines_live`.`user_id`, `lines_live`.`server_id`, `lines`.`username` FROM `lines_live` LEFT JOIN `lines` ON `lines`.`id` = `lines_live`.`user_id` WHERE `user_id` = ?;', $a27e64cc6ce01033['id']);
																			} else {
																				$Fee0d5a474c96306->query('SELECT `lines_live`.`activity_id`, `lines_live`.`uuid`, `lines_live`.`user_id`, `lines_live`.`server_id`, `lines`.`username` FROM `lines_live` LEFT JOIN `lines` ON `lines`.`id` = `lines_live`.`user_id` WHERE `stream_id` = ?;', $a27e64cc6ce01033['id']);
																			}

																			$b3439582205053ea = $Fee0d5a474c96306->get_rows();
																		}

																		if (0 >= count($b3439582205053ea)) {
																		} else {
																			set_time_limit(360);
																			ini_set('max_execution_time', 360);
																			ini_set('default_socket_timeout', 15);

																			foreach ($b3439582205053ea as $C740da31596f24ef) {
																				if (!in_array($C740da31596f24ef['server_id'], $fe4ab20bd2e08875)) {
																				} else {
																					$d49041d5f05a9270 = array('font_size' => $a27e64cc6ce01033['font_size'], 'font_color' => $a27e64cc6ce01033['font_color'], 'xy_offset' => $a27e64cc6ce01033['xy_offset'], 'message' => '', 'uuid' => $C740da31596f24ef['uuid']);

																					if ($a27e64cc6ce01033['type'] == 1) {
																						$d49041d5f05a9270['message'] = $C740da31596f24ef['uuid'];
																					} else {
																						if ($a27e64cc6ce01033['type'] == 2) {
																							$d49041d5f05a9270['message'] = (XUI::$rSettings['redis_handler'] ? $dec4b1df9997c4d4[$C740da31596f24ef['user_id']] : $C740da31596f24ef['username']);
																						} else {
																							if ($a27e64cc6ce01033['type'] != 3) {
																							} else {
																								$d49041d5f05a9270['message'] = $a27e64cc6ce01033['message'];
																							}
																						}
																					}

																					$d49041d5f05a9270['action'] = 'signal_send';
																					$b0466cedbfdd5040 = a200986BBAe4B322(intval($C740da31596f24ef['server_id']), $d49041d5f05a9270);
																				}
																			}
																		}
																	}

																	echo json_encode(array('result' => true));

																	exit();
																} else {
																	echo json_encode(array('result' => false));

																	exit();
																}
															} else {
																if (XUI::$rRequest['action'] == 'restart_all_services') {
																	if (aACd47D8157A1a09('adv', 'servers')) {
																		foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
																			if (!$e81220b4451f37c9['server_online']) {
																			} else {
																				$Fee0d5a474c96306->query("INSERT INTO `signals`(`server_id`, `custom_data`, `time`) VALUES(?, '{\"action\": \"restart_services\"}', ?);", $e81220b4451f37c9['id'], time());
																			}
																		}
																		echo json_encode(array('result' => true));

																		exit();
																	} else {
																		echo json_encode(array('result' => false));

																		exit();
																	}
																} else {
																	if (XUI::$rRequest['action'] == 'restart_services') {
																		if (AAcD47D8157A1A09('adv', 'edit_server')) {
																			if (!is_numeric(XUI::$rRequest['server_id'])) {
																				$Aa8c918a2a91966f = json_decode(XUI::$rRequest['server_id'], true);
																			} else {
																				$Aa8c918a2a91966f = array(intval(XUI::$rRequest['server_id']));
																			}

																			foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
																				$Fee0d5a474c96306->query("INSERT INTO `signals`(`server_id`, `custom_data`, `time`) VALUES(?, '{\"action\": \"restart_services\"}', ?);", $C3c8913edb801c35, time());
																			}
																			echo json_encode(array('result' => true));

																			exit();
																		} else {
																			echo json_encode(array('result' => false));

																			exit();
																		}
																	} else {
																		if (XUI::$rRequest['action'] == 'reboot_server') {
																			if (AacD47D8157a1a09('adv', 'edit_server')) {
																				if (!is_numeric(XUI::$rRequest['server_id'])) {
																					$Aa8c918a2a91966f = json_decode(XUI::$rRequest['server_id'], true);
																				} else {
																					$Aa8c918a2a91966f = array(intval(XUI::$rRequest['server_id']));
																				}

																				foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
																					$Fee0d5a474c96306->query("INSERT INTO `signals`(`server_id`, `custom_data`, `time`) VALUES(?, '{\"action\": \"reboot\"}', ?);", $C3c8913edb801c35, time());
																				}
																				echo json_encode(array('result' => true));

																				exit();
																			} else {
																				echo json_encode(array('result' => false));

																				exit();
																			}
																		} else {
																			if (XUI::$rRequest['action'] == 'update_binaries') {
																				if (aACD47D8157A1a09('adv', 'edit_server')) {
																					if (!is_numeric(XUI::$rRequest['server_id'])) {
																						$Aa8c918a2a91966f = json_decode(XUI::$rRequest['server_id'], true);
																					} else {
																						$Aa8c918a2a91966f = array(intval(XUI::$rRequest['server_id']));
																					}

																					foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
																						$Fee0d5a474c96306->query("INSERT INTO `signals`(`server_id`, `custom_data`, `time`) VALUES(?, '{\"action\": \"update_binaries\"}', ?);", $C3c8913edb801c35, time());
																					}
																					echo json_encode(array('result' => true));

																					exit();
																				} else {
																					echo json_encode(array('result' => false));

																					exit();
																				}
																			} else {
																				if (XUI::$rRequest['action'] == 'probe_stream') {
																					if (Aacd47D8157A1a09('adv', 'add_stream') || aaCd47d8157A1a09('adv', 'edit_stream')) {
																						$a8d6b4f70a067a08 = abs(intval(XUI::$rSettings['stream_max_analyze']));
																						$cd2a4260ef308305 = intval($a8d6b4f70a067a08 / 1000000) + XUI::$rSettings['probe_extra_wait'];
																						set_time_limit(intval($cd2a4260ef308305));
																						ini_set('max_execution_time', intval($cd2a4260ef308305));
																						ini_set('default_socket_timeout', intval($cd2a4260ef308305));
																						$d58b4f8653a391d8 = SERVER_ID;

																						if (empty(XUI::$rRequest['server']) || !$a8bb73cba48fb7f6[intval(XUI::$rRequest['server'])]['server_online']) {
																						} else {
																							$d58b4f8653a391d8 = intval(XUI::$rRequest['server']);
																						}

																						$b5e8b95fdf13ba62 = "<table style='width: 380px;' class='table-data' align='center'><tbody><tr><td colspan='4'>Stream probe failed!</td></tr></tbody></table>";
																						$bb0071da5a239b0c = null;

																						if (empty(XUI::$rRequest['url'])) {
																						} else {
																							$C700a2b357e5ed65 = XUI::cE3BA3178bc00d1C(XUI::$rRequest['url']);

																							if (!(XUI::c7c23F3aAeA4F10e($C700a2b357e5ed65) && XUI::$rSettings['api_probe'])) {
																							} else {
																								$e97435234acb895c = parse_url($C700a2b357e5ed65);
																								$d88a567c47b3ff49 = $e97435234acb895c['scheme'] . '://' . $e97435234acb895c['host'] . (($e97435234acb895c['port'] ? ':' . $e97435234acb895c['port'] : '')) . '/probe/' . base64_encode($e97435234acb895c['path']);

																								if (!($F0751c5c0b3e723a = json_decode(XUI::A2AF9198cFd841A1($d88a567c47b3ff49), true))) {
																								} else {
																									$bb0071da5a239b0c = array();

																									foreach ($F0751c5c0b3e723a['codecs'] as $E379394c7b1a273f => $A387578f69b4c724) {
																										$bb0071da5a239b0c['streams'][] = $A387578f69b4c724;
																									}
																									$bb0071da5a239b0c['container'] = $F0751c5c0b3e723a['container'];
																								}
																							}

																							if ($bb0071da5a239b0c) {
																							} else {
																								$bb0071da5a239b0c = probeSource($d58b4f8653a391d8, XUI::$rRequest['url'], (XUI::$rRequest['user_agent'] ?: null), (XUI::$rRequest['http_proxy'] ?: null), (XUI::$rRequest['cookies'] ?: null), (XUI::$rRequest['headers'] ?: null))['data'];
																								$bb0071da5a239b0c['container'] = $bb0071da5a239b0c['format']['format_name'];
																							}
																						}

																						if (isset(XUI::$rRequest['map'])) {
																							echo json_encode($bb0071da5a239b0c);

																							exit();
																						}

																						if (0 >= count($bb0071da5a239b0c['streams'])) {
																						} else {
																							$Eea1b980ebbe2a33 = array();

																							foreach ($bb0071da5a239b0c['streams'] as $A387578f69b4c724) {
																								if ($A387578f69b4c724['codec_type'] == 'video') {
																									$Eea1b980ebbe2a33['width'] = intval($A387578f69b4c724['width']);
																									$Eea1b980ebbe2a33['height'] = intval($A387578f69b4c724['height']);
																									$Eea1b980ebbe2a33['vbitrate'] = intval($A387578f69b4c724['bit_rate']);
																									$Eea1b980ebbe2a33['vcodec'] = $A387578f69b4c724['codec_name'];
																									$Eea1b980ebbe2a33['fps'] = intval(explode('/', $A387578f69b4c724['r_frame_rate'])[0]);

																									if ($Eea1b980ebbe2a33['fps']) {
																									} else {
																										$Eea1b980ebbe2a33['fps'] = intval(explode('/', $A387578f69b4c724['avg_frame_rate'])[0]);
																									}
																								} else {
																									if ($A387578f69b4c724['codec_type'] != 'audio') {
																									} else {
																										$Eea1b980ebbe2a33['abitrate'] = intval($A387578f69b4c724['bit_rate']);
																										$Eea1b980ebbe2a33['acodec'] = $A387578f69b4c724['codec_name'];
																									}
																								}
																							}

																							if (0 < $Eea1b980ebbe2a33['fps']) {
																								if (1000 > $Eea1b980ebbe2a33['fps']) {
																								} else {
																									$Eea1b980ebbe2a33['fps'] = intval($Eea1b980ebbe2a33['fps'] / 1000);
																								}

																								$Fc6b82af9a3c82e5 = $Eea1b980ebbe2a33['fps'] . '&nbsp;FPS';
																							} else {
																								$Fc6b82af9a3c82e5 = '--';
																							}

																							if (0 < $Eea1b980ebbe2a33['abitrate'] && 0 < $Eea1b980ebbe2a33['vbitrate']) {
																								$aa2e54fde620d6b3 = intval(($Eea1b980ebbe2a33['abitrate'] + $Eea1b980ebbe2a33['vbitrate']) / 1024);
																							} else {
																								$aa2e54fde620d6b3 = 'N/A';
																							}

																							$b5e8b95fdf13ba62 = "<table class='table-data' style='width: 380px;' align='center'><tbody><tr><td class='nowrap' style='color: #20a009;width: 25%;'><i class='mdi mdi-image-size-select-large' data-name='mdi-image-size-select-large'></i></td><td class='nowrap' style='color: #20a009;'><i class='mdi mdi-video' data-name='mdi-video'></i></td><td class='nowrap' style='color: #20a009;'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td><td class='nowrap' style='color: #20a009;width: 20%;'><i class='mdi mdi-layers' data-name='mdi-layers'></i></td><td class='nowrap' style='color: #" . ((strtolower($bb0071da5a239b0c['container']) == 'mpegts' ? '20a009' : 'd65656')) . ";width: 18%;'><i class='mdi " . ((strtolower($bb0071da5a239b0c['container']) == 'mpegts' ? 'mdi-check' : 'mdi-close')) . "' data-name='" . ((strtolower($bb0071da5a239b0c['container']) == 'mpegts' ? 'mdi-check' : 'mdi-close')) . "'></i></td></tr><tr><td class='nowrap'>" . $Eea1b980ebbe2a33['width'] . '&nbsp;x&nbsp;' . $Eea1b980ebbe2a33['height'] . "</td><td class='nowrap'>" . $Eea1b980ebbe2a33['vcodec'] . "</td><td class='nowrap'>" . $Eea1b980ebbe2a33['acodec'] . "</td><td class='nowrap'>" . $Fc6b82af9a3c82e5 . "</td><td class='nowrap'>LLOD&nbsp;v3</td></tr></tbody></table>";
																						}

																						echo $b5e8b95fdf13ba62;

																						exit();
																					}

																					echo json_encode(array('result' => false));

																					exit();
																				}

																				if (XUI::$rRequest['action'] == 'check_stream') {
																					if (Aacd47D8157a1A09('adv', 'add_stream') || AACd47d8157a1A09('adv', 'edit_stream')) {
																						$a8d6b4f70a067a08 = abs(intval(XUI::$rSettings['stream_max_analyze']));
																						$cd2a4260ef308305 = intval($a8d6b4f70a067a08 / 1000000) + XUI::$rSettings['probe_extra_wait'];
																						set_time_limit(intval($cd2a4260ef308305));
																						ini_set('max_execution_time', intval($cd2a4260ef308305));
																						ini_set('default_socket_timeout', intval($cd2a4260ef308305));

																						if (isset(XUI::$rRequest['url'])) {
																							$C700a2b357e5ed65 = XUI::ce3Ba3178bc00d1c(XUI::$rRequest['url']);

																							if (isset(XUI::$rRequest['ua'])) {
																								$b56e071c6f8e20e6 = ' -user_agent ' . escapeshellarg(XUI::$rRequest['ua']);
																							} else {
																								$b56e071c6f8e20e6 = '';
																							}

																							if (isset(XUI::$rRequest['cookie'])) {
																								$F5bd74e6a8ba5c58 = ' -cookies ' . escapeshellarg(XUI::A52d5062b20AE826(XUI::$rRequest['cookie']));
																							} else {
																								$F5bd74e6a8ba5c58 = '';
																							}
																						} else {
																							$f523e362fb81d6c8 = E5ECeb32F67d5e70(XUI::$rRequest['stream']);
																							$c1af28817ca114e6 = cb4fcdA8E433b44E(XUI::$rRequest['stream']);

																							if (0 < strlen($c1af28817ca114e6[1]['value'])) {
																								$b56e071c6f8e20e6 = ' -user_agent ' . escapeshellarg($c1af28817ca114e6[1]['value']);
																							} else {
																								$b56e071c6f8e20e6 = '';
																							}

																							if (isset(XUI::$rRequest['cookie'])) {
																								$F5bd74e6a8ba5c58 = ' -cookies ' . escapeshellarg(XUI::a52d5062b20aE826($c1af28817ca114e6[17]['value']));
																							} else {
																								$F5bd74e6a8ba5c58 = '';
																							}

																							$C700a2b357e5ed65 = XUI::CE3ba3178BC00d1c(json_decode($f523e362fb81d6c8['stream_source'], true)[intval(XUI::$rRequest['id'])]);
																						}

																						if (0 >= strlen($C700a2b357e5ed65)) {
																						} else {
																							$b5e8b95fdf13ba62 = "<table style='width: 300px;' class='table-data' align='center'><tbody><tr><td colspan='4'>Stream probe failed!</td></tr></tbody></table>";
																							$bb0071da5a239b0c = null;

																							if (!(XUI::C7c23F3AAeA4f10e($C700a2b357e5ed65) && XUI::$rSettings['api_probe'])) {
																							} else {
																								$e97435234acb895c = parse_url($C700a2b357e5ed65);
																								$d88a567c47b3ff49 = $e97435234acb895c['scheme'] . '://' . $e97435234acb895c['host'] . (($e97435234acb895c['port'] ? ':' . $e97435234acb895c['port'] : '')) . '/probe/' . base64_encode($e97435234acb895c['path']);

																								if (!($F0751c5c0b3e723a = json_decode(XUI::a2af9198Cfd841a1($d88a567c47b3ff49), true))) {
																								} else {
																									$bb0071da5a239b0c = array();

																									foreach ($F0751c5c0b3e723a['codecs'] as $E379394c7b1a273f => $A387578f69b4c724) {
																										$bb0071da5a239b0c['streams'][] = $A387578f69b4c724;
																									}
																								}
																							}

																							if ($bb0071da5a239b0c) {
																							} else {
																								$bb0071da5a239b0c = json_decode(shell_exec('timeout ' . intval($cd2a4260ef308305) . ' ' . XUI::$rFFPROBE . $b56e071c6f8e20e6 . $F5bd74e6a8ba5c58 . ' -v quiet -probesize 5000000 -print_format json -show_format -show_streams ' . escapeshellarg($C700a2b357e5ed65)), true);
																							}

																							if (0 >= count($bb0071da5a239b0c['streams'])) {
																							} else {
																								$Eea1b980ebbe2a33 = array();

																								foreach ($bb0071da5a239b0c['streams'] as $A387578f69b4c724) {
																									if ($A387578f69b4c724['codec_type'] == 'video') {
																										$Eea1b980ebbe2a33['width'] = intval($A387578f69b4c724['width']);
																										$Eea1b980ebbe2a33['height'] = intval($A387578f69b4c724['height']);
																										$Eea1b980ebbe2a33['vbitrate'] = intval($A387578f69b4c724['bit_rate']);
																										$Eea1b980ebbe2a33['vcodec'] = $A387578f69b4c724['codec_name'];
																										$Eea1b980ebbe2a33['fps'] = intval(explode('/', $A387578f69b4c724['r_frame_rate'])[0]);

																										if ($Eea1b980ebbe2a33['fps']) {
																										} else {
																											$Eea1b980ebbe2a33['fps'] = intval(explode('/', $A387578f69b4c724['avg_frame_rate'])[0]);
																										}
																									} else {
																										if ($A387578f69b4c724['codec_type'] != 'audio') {
																										} else {
																											$Eea1b980ebbe2a33['abitrate'] = intval($A387578f69b4c724['bit_rate']);
																											$Eea1b980ebbe2a33['acodec'] = $A387578f69b4c724['codec_name'];
																										}
																									}
																								}

																								if (0 < $Eea1b980ebbe2a33['fps']) {
																									if (1000 > $Eea1b980ebbe2a33['fps']) {
																									} else {
																										$Eea1b980ebbe2a33['fps'] = intval($Eea1b980ebbe2a33['fps'] / 1000);
																									}

																									$Fc6b82af9a3c82e5 = $Eea1b980ebbe2a33['fps'] . '&nbsp;FPS';
																								} else {
																									$Fc6b82af9a3c82e5 = '--';
																								}

																								if (0 < $Eea1b980ebbe2a33['abitrate'] && 0 < $Eea1b980ebbe2a33['vbitrate']) {
																									$aa2e54fde620d6b3 = intval(($Eea1b980ebbe2a33['abitrate'] + $Eea1b980ebbe2a33['vbitrate']) / 1024);
																								} else {
																									$aa2e54fde620d6b3 = 'N/A';
																								}

																								$b5e8b95fdf13ba62 = "<table class='table-data' style='width: 300px;' align='center'><tbody><tr><td style='color: #20a009;width: 34%;'><i class='mdi mdi-image-size-select-large' data-name='mdi-image-size-select-large'></i></td><td style='color: #20a009;width: 23%;'><i class='mdi mdi-video' data-name='mdi-video'></i></td><td style='color: #20a009;width: 23%;'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td><td style='color: #20a009;width: 23%;'><i class='mdi mdi-layers' data-name='mdi-layers'></i></td></tr><tr><td class='double'>" . $Eea1b980ebbe2a33['width'] . '&nbsp;x&nbsp;' . $Eea1b980ebbe2a33['height'] . '</td><td>' . $Eea1b980ebbe2a33['vcodec'] . '</td><td>' . $Eea1b980ebbe2a33['acodec'] . '</td><td>' . $Fc6b82af9a3c82e5 . '</td></tr></tbody></table>';
																							}

																							echo $b5e8b95fdf13ba62;
																						}

																						exit();
																					}

																					echo json_encode(array('result' => false));

																					exit();
																				}

																				if (XUI::$rRequest['action'] == 'clear_logs') {
																					if (AaCd47d8157a1a09('adv', 'reg_userlog') || AACd47d8157a1A09('adv', 'client_request_log') || AacD47d8157a1a09('adv', 'connection_logs') || AACd47d8157a1A09('adv', 'stream_errors') || aAcd47D8157A1a09('adv', 'credits_log') || AaCd47d8157a1A09('adv', 'folder_watch_settings')) {
																						if (strlen(XUI::$rRequest['from']) == 0) {
																							$a859a0996bb0f1ff = null;
																						} else {
																							if ($a859a0996bb0f1ff = strtotime(XUI::$rRequest['from'] . ' 00:00:00')) {
																							} else {
																								echo json_encode(array('result' => false));

																								exit();
																							}
																						}

																						if (strlen(XUI::$rRequest['to']) == 0) {
																							$B37c1f185be84c33 = null;
																						} else {
																							if ($B37c1f185be84c33 = strtotime(XUI::$rRequest['to'] . ' 23:59:59')) {
																							} else {
																								echo json_encode(array('result' => false));

																								exit();
																							}
																						}

																						if (in_array(XUI::$rRequest['type'], array('lines_logs', 'streams_errors', 'lines_activity', 'users_credits_logs', 'users_logs'))) {
																							if (XUI::$rRequest['type'] == 'lines_activity') {
																								$f8d6610081a97651 = 'date_start';
																							} else {
																								$f8d6610081a97651 = 'date';
																							}

																							if ($a859a0996bb0f1ff && $B37c1f185be84c33) {
																								$Fee0d5a474c96306->query('DELETE FROM ' . C4a6F6f0DeBd5f57(XUI::$rRequest['type']) . ' WHERE `' . $f8d6610081a97651 . '` >= ? AND `' . $f8d6610081a97651 . '` <= ?;', $a859a0996bb0f1ff, $B37c1f185be84c33);
																							} else {
																								if ($a859a0996bb0f1ff) {
																									$Fee0d5a474c96306->query('DELETE FROM ' . c4a6f6F0DEbD5F57(XUI::$rRequest['type']) . ' WHERE `' . $f8d6610081a97651 . '` >= ?;', $a859a0996bb0f1ff);
																								} else {
																									if ($B37c1f185be84c33) {
																										$Fee0d5a474c96306->query('DELETE FROM ' . C4A6F6F0debd5f57(XUI::$rRequest['type']) . ' WHERE `' . $f8d6610081a97651 . '` <= ?;', $B37c1f185be84c33);
																									} else {
																										$Fee0d5a474c96306->query('TRUNCATE ' . c4A6f6F0dEbD5F57(XUI::$rRequest['type']) . ';');
																									}
																								}
																							}
																						} else {
																							if (XUI::$rRequest['type'] != 'watch_logs') {
																							} else {
																								if ($a859a0996bb0f1ff && $B37c1f185be84c33) {
																									$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE UNIX_TIMESTAMP(`dateadded`) >= ? AND UNIX_TIMESTAMP(`dateadded`) <= ?;', $a859a0996bb0f1ff, $B37c1f185be84c33);
																								} else {
																									if ($a859a0996bb0f1ff) {
																										$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE UNIX_TIMESTAMP(`dateadded`) >= ?;', $a859a0996bb0f1ff);
																									} else {
																										if ($B37c1f185be84c33) {
																											$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE UNIX_TIMESTAMP(`dateadded`) <= ?;', $B37c1f185be84c33);
																										} else {
																											$Fee0d5a474c96306->query('TRUNCATE `watch_logs`;');
																										}
																									}
																								}
																							}
																						}

																						echo json_encode(array('result' => true));

																						exit();
																					}

																					echo json_encode(array('result' => false));

																					exit();
																				}

																				if (XUI::$rRequest['action'] == 'backup') {
																					if (AaCd47D8157a1a09('adv', 'database')) {
																						$b4cd770ed1b094fe = XUI::$rRequest['sub'];

																						if ($b4cd770ed1b094fe == 'delete') {
																							$db13ebf912ff273c = pathinfo(XUI::$rRequest['filename'])['filename'];

																							if (!file_exists(XUI_HOME . 'backups/' . $db13ebf912ff273c . '.sql')) {
																							} else {
																								unlink(XUI_HOME . 'backups/' . $db13ebf912ff273c . '.sql');
																							}

																							if (0 >= strlen($F2d4d8f7981ac574['dropbox_token'])) {
																							} else {
																								FC9601411d1D90E4('/' . $db13ebf912ff273c . '.sql');
																							}

																							echo json_encode(array('result' => true));

																							exit();
																						}

																						if ($b4cd770ed1b094fe == 'restore') {
																							$db13ebf912ff273c = pathinfo(XUI::$rRequest['filename'])['filename'];
																							$bc2874292e0d9ece = XUI_HOME . 'backups/' . $db13ebf912ff273c . '.sql';

																							if (file_exists($bc2874292e0d9ece)) {
																							} else {
																								$bc2874292e0d9ece = XUI_HOME . 'tmp/restore.sql';

																								if (0 < strlen($F2d4d8f7981ac574['dropbox_token'])) {
																									if (e401F74F56e9367f('/' . $db13ebf912ff273c . '.sql', $bc2874292e0d9ece)) {
																									} else {
																										echo json_encode(array('result' => false));

																										exit();
																									}
																								} else {
																									echo json_encode(array('result' => false));

																									exit();
																								}
																							}

																							Xui\Functions::restore('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', $bc2874292e0d9ece);
																							echo json_encode(array('result' => true));

																							exit();
																						}

																						if ($b4cd770ed1b094fe != 'backup') {
																							echo json_encode(array('result' => false));

																							exit();
																						}

																						$cf1c389bda3e30fd = PHP_BIN . ' ' . CRON_PATH . 'backups.php 1 > /dev/null 2>/dev/null &';
																						$B95dc1bd2d8c3a31 = shell_exec($cf1c389bda3e30fd);
																						echo json_encode(array('result' => true));

																						exit();
																					}

																					echo json_encode(array('result' => false));

																					exit();
																				}

																				if (XUI::$rRequest['action'] == 'send_event') {
																					if (AacD47D8157A1A09('adv', 'manage_events')) {
																						$a27e64cc6ce01033 = json_decode(XUI::$rRequest['data'], true);

																						if (!is_numeric($a27e64cc6ce01033['id'])) {
																							$Aa8c918a2a91966f = json_decode($a27e64cc6ce01033['id'], true);
																						} else {
																							$Aa8c918a2a91966f = array(intval($a27e64cc6ce01033['id']));
																						}

																						foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
																							if ($a27e64cc6ce01033['type'] == 'send_msg') {
																								$a27e64cc6ce01033['need_confirm'] = 1;
																							} else {
																								if ($a27e64cc6ce01033['type'] == 'play_channel') {
																									$a27e64cc6ce01033['need_confirm'] = 0;
																									$a27e64cc6ce01033['reboot_portal'] = 0;
																									$a27e64cc6ce01033['message'] = intval($a27e64cc6ce01033['channel']);
																								} else {
																									if ($a27e64cc6ce01033['type'] == 'reset_stb_lock') {
																										f59F57f8317aB8Be($a27e64cc6ce01033['id']);
																									} else {
																										$a27e64cc6ce01033['need_confirm'] = 0;
																										$a27e64cc6ce01033['reboot_portal'] = 0;
																										$a27e64cc6ce01033['message'] = '';
																									}
																								}
																							}

																							$Fee0d5a474c96306->query('INSERT INTO `mag_events`(`status`, `mag_device_id`, `event`, `need_confirm`, `msg`, `reboot_after_ok`, `send_time`) VALUES (0, ?, ?, ?, ?, ?, ?);', $C3c8913edb801c35, $a27e64cc6ce01033['type'], $a27e64cc6ce01033['need_confirm'], $a27e64cc6ce01033['message'], $a27e64cc6ce01033['reboot_portal'], time());
																						}
																						echo json_encode(array('result' => true));

																						exit();
																					} else {
																						echo json_encode(array('result' => false));

																						exit();
																					}
																				} else {
																					if (XUI::$rRequest['action'] == 'ip_whois') {
																						$c59ec257c284c894 = XUI::$rRequest['ip'];
																						$Ba28503b8f6b59ed = new MaxMind\Db\Reader(GEOLITE2C_BIN);
																						$c7488e8420e934e2 = $Ba28503b8f6b59ed->get($c59ec257c284c894);

																						if (!isset($c7488e8420e934e2['location']['time_zone'])) {
																						} else {
																							$c94b497359f8aed9 = new DateTime('now', new DateTimeZone($c7488e8420e934e2['location']['time_zone']));
																							$c7488e8420e934e2['location']['time'] = $c94b497359f8aed9->format('Y-m-d H:i:s');
																						}

																						$Ba28503b8f6b59ed->close();

																						if (!isset(XUI::$rRequest['isp'])) {
																						} else {
																							$Ba28503b8f6b59ed = new MaxMind\Db\Reader(GEOISP_BIN);
																							$c7488e8420e934e2['isp'] = $Ba28503b8f6b59ed->get($c59ec257c284c894);
																							$Ba28503b8f6b59ed->close();
																						}

																						$c7488e8420e934e2['type'] = null;

																						if (!$c7488e8420e934e2['isp']['autonomous_system_number']) {
																						} else {
																							$Fcd691b0388768ab = $c7488e8420e934e2['isp']['autonomous_system_number'];
																							$Fee0d5a474c96306->query('SELECT `type` FROM `blocked_asns` WHERE `asn` = ?;', $Fcd691b0388768ab);

																							if (0 >= $Fee0d5a474c96306->num_rows()) {
																							} else {
																								$c7488e8420e934e2['type'] = $Fee0d5a474c96306->get_row()['type'];
																							}

																							if (!file_exists(CIDR_TMP_PATH . $Fcd691b0388768ab)) {
																							} else {
																								$D25e7c9f6776261b = json_decode(file_get_contents(CIDR_TMP_PATH . $Fcd691b0388768ab), true);

																								foreach ($D25e7c9f6776261b as $Da967f0a787f6b51 => $a27e64cc6ce01033) {
																									if (!(ip2long($a27e64cc6ce01033[1]) <= ip2long($c59ec257c284c894) && ip2long($c59ec257c284c894) <= ip2long($a27e64cc6ce01033[2]))) {
																									} else {
																										$Ef11b70791ef1059 = array();

																										if (!$a27e64cc6ce01033[3]) {
																										} else {
																											$Ef11b70791ef1059[] = 'HOSTING';
																										}

																										if (!$a27e64cc6ce01033[4]) {
																										} else {
																											$Ef11b70791ef1059[] = 'PROXY';
																										}

																										$c7488e8420e934e2['type'] = implode(', ', $Ef11b70791ef1059);

																										break;
																									}
																								}
																							}
																						}

																						echo json_encode(array('result' => true, 'data' => $c7488e8420e934e2));

																						exit();
																					}

																					if (XUI::$rRequest['action'] == 'asn') {
																						if (aACD47d8157A1a09('adv', 'block_isps')) {
																							$b4cd770ed1b094fe = XUI::$rRequest['sub'];
																							$Fcd691b0388768ab = XUI::$rRequest['id'];

																							if ($b4cd770ed1b094fe == 'allow') {
																								$Fee0d5a474c96306->query('UPDATE `blocked_asns` SET `blocked` = 0 WHERE `id` = ?;', $Fcd691b0388768ab);
																								echo json_encode(array('result' => true));

																								exit();
																							}

																							if ($b4cd770ed1b094fe == 'block') {
																								$Fee0d5a474c96306->query('UPDATE `blocked_asns` SET `blocked` = 1 WHERE `id` = ?;', $Fcd691b0388768ab);
																								echo json_encode(array('result' => true));

																								exit();
																							}

																							if ($b4cd770ed1b094fe == 'allow_all') {
																								$Fee0d5a474c96306->query('UPDATE `blocked_asns` SET `blocked` = 0 WHERE `type` = ?;', $Fcd691b0388768ab);
																								echo json_encode(array('result' => true));

																								exit();
																							}

																							if ($b4cd770ed1b094fe != 'block_all') {
																							} else {
																								$Fee0d5a474c96306->query('UPDATE `blocked_asns` SET `blocked` = 1 WHERE `type` = ?;', $Fcd691b0388768ab);
																								echo json_encode(array('result' => true));

																								exit();
																							}
																						} else {
																							echo json_encode(array('result' => false));

																							exit();
																						}
																					} else {
																						if (XUI::$rRequest['action'] == 'server_view') {
																							if (aAcd47D8157a1A09('adv', 'add_server') || AaCd47d8157a1A09('adv', 'edit_server')) {
																								if (isset($a8bb73cba48fb7f6[XUI::$rRequest['server_id']])) {
																									$e81220b4451f37c9 = $a8bb73cba48fb7f6[XUI::$rRequest['server_id']];
																								} else {
																									if (isset($Fd8279be5302940a[XUI::$rRequest['server_id']])) {
																										$e81220b4451f37c9 = $Fd8279be5302940a[XUI::$rRequest['server_id']];
																									} else {
																										echo json_encode(array('result' => false));

																										exit();
																									}
																								}

																								$e19876d9ba369ed1 = array('open_connections' => 0, 'total_running_streams' => 0, 'online_users' => 0, 'offline_streams' => 0, 'gpu_info' => json_decode($e81220b4451f37c9['gpu_info'], true), 'watchdog' => json_decode($e81220b4451f37c9['watchdog_data'], true));
																								$e19876d9ba369ed1['open_connections'] = ($e81220b4451f37c9['connections'] ?: 0);
																								$e19876d9ba369ed1['online_users'] = ($e81220b4451f37c9['users'] ?: 0);
																								$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `pid` > 0 AND `type` = 1;', $e81220b4451f37c9['id']);
																								$e19876d9ba369ed1['total_running_streams'] = $Fee0d5a474c96306->get_row()['count'];
																								$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `type` = 1 AND ((`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0);', $e81220b4451f37c9['id']);
																								$e19876d9ba369ed1['offline_streams'] = $Fee0d5a474c96306->get_row()['count'];
																								echo json_encode(array('result' => true, 'data' => $e19876d9ba369ed1, 'netspeed' => (intval($e81220b4451f37c9['network_guaranteed_speed']) ?: 1000)));

																								exit();
																							}

																							echo json_encode(array('result' => false));

																							exit();
																						}

																						if (XUI::$rRequest['action'] == 'server_stats') {
																							if (aAcd47d8157a1A09('adv', 'add_server') || aAcD47D8157a1a09('adv', 'edit_server')) {
																								$C3c8913edb801c35 = intval(XUI::$rRequest['id']);

																								if (isset($a8bb73cba48fb7f6[$C3c8913edb801c35])) {
																									$ffd0802c4358f6d2 = bf7791Bd46BEc674($C3c8913edb801c35);
																									$a85e1b7d42c346a0 = array();

																									foreach ($ffd0802c4358f6d2 as $a27e64cc6ce01033) {
																										$a85e1b7d42c346a0[] = array('cpu' => $a27e64cc6ce01033['cpu'], 'memory' => $a27e64cc6ce01033['total_mem_used_percent'], 'input' => $a27e64cc6ce01033['bytes_received'], 'output' => $a27e64cc6ce01033['bytes_sent'], 'date' => $a27e64cc6ce01033['time']);
																									}
																									echo json_encode(array('result' => true, 'data' => $a85e1b7d42c346a0));

																									exit();
																								} else {
																									echo json_encode(array('result' => false));

																									exit();
																								}
																							} else {
																								echo json_encode(array('result' => false));

																								exit();
																							}
																						} else {
																							if (XUI::$rRequest['action'] == 'epg_api_single') {
																								$C3c8913edb801c35 = 0;

																								if (0 < strlen(XUI::$rRequest['id']) && !is_numeric(XUI::$rRequest['id'])) {
																									$Fee0d5a474c96306->query('SELECT `stationId` FROM `epg_api` WHERE `callSign` = ?;', XUI::$rRequest['id']);

																									if (0 >= $Fee0d5a474c96306->num_rows()) {
																									} else {
																										$C3c8913edb801c35 = intval($Fee0d5a474c96306->get_row()['stationId']);
																									}
																								} else {
																									$C3c8913edb801c35 = intval(XUI::$rRequest['id']);
																								}

																								$c15d5b523e931f51 = array();

																								if (0 >= $C3c8913edb801c35) {
																								} else {
																									$E330444f58f09645 = array('action' => 'epg', 'id' => $C3c8913edb801c35, 'days' => 2);
																									$Fe753328765ad26c = Xui\Functions::getEPG('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', $E330444f58f09645);
																									$Ee415a632c5c0dcd = null;

																									foreach ($Fe753328765ad26c[array_keys($Fe753328765ad26c)[0]] as $B59c127fecf35c15) {
																										if (!(time() < strtotime($B59c127fecf35c15['endTime']) && (!$Ee415a632c5c0dcd || strtotime($B59c127fecf35c15['startTime']) < $Ee415a632c5c0dcd + 86400))) {
																										} else {
																											if ($Ee415a632c5c0dcd) {
																											} else {
																												$Ee415a632c5c0dcd = strtotime($B59c127fecf35c15['startTime']);
																											}

																											$B59c127fecf35c15['startTime'] = date('H:i:s', strtotime($B59c127fecf35c15['startTime']));

																											if ($B59c127fecf35c15['program']['shortDescription'] && strlen($B59c127fecf35c15['program']['shortDescription']) != 0) {
																											} else {
																												$B59c127fecf35c15['program']['shortDescription'] = 'No description.';
																											}

																											$c15d5b523e931f51[] = $B59c127fecf35c15;
																										}
																									}
																								}

																								echo json_encode(array('result' => true, 'data' => $c15d5b523e931f51));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'report_epg') {
																								$a27e64cc6ce01033 = array('action' => 'report', 'id' => intval(XUI::$rRequest['id']), 'type' => XUI::$rRequest['type'], 'report' => XUI::$rRequest['report']);
																								$Be3590384c940166 = array('http' => array('header' => 'Content-type: application/x-www-form-urlencoded' . "\r\n", 'method' => 'POST', 'content' => http_build_query($a27e64cc6ce01033)));
																								$B2976aadbf91a696 = stream_context_create($Be3590384c940166);
																								$B59c127fecf35c15 = file_get_contents($F2d4d8f7981ac574['epg_api_url'], false, $B2976aadbf91a696);
																								echo json_encode(array('result' => true));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'guess_epg') {
																								$d9ee1cc8e0f43f6e = str_replace(array(':', '|', '-', ' hd', ' fhd', ' 4k', ' sd'), array('#', '#', '#', '', '', '', ''), strtolower(XUI::$rRequest['name']));
																								$d4d6c242ee6f6592 = (!empty(XUI::$rRequest['id']) ? strtolower(XUI::$rRequest['id']) : null);

																								if (stripos($d9ee1cc8e0f43f6e, '#') !== false) {
																									$E52b5c53f2df521b = explode('#', $d9ee1cc8e0f43f6e);
																									usort(
																										$E52b5c53f2df521b,
																										function($d7e6e8fcd8d94d98, $dbc1091ca2977adb) {
																											return strlen($d7e6e8fcd8d94d98) < strlen($dbc1091ca2977adb);
																										}
																									);
																									$bbf487337b8f5211 = $E52b5c53f2df521b[0];
																								} else {
																									$bbf487337b8f5211 = $d9ee1cc8e0f43f6e;
																								}

																								$bbf487337b8f5211 = preg_replace('/[^A-Za-z0-9 ]/', '', $bbf487337b8f5211);
																								$rLanguage = null;
																								$f0d90482e9c61a22 = array('af' => 'af', 'sq' => 'sq', 'ar' => 'ar', 'arc' => 'arc', 'arp' => 'arp', 'hy' => 'hy', 'eu' => 'eu', 'be' => 'be', 'bn' => 'bn', 'bg' => 'bg', 'km' => 'km', 'zh' => 'zh', 'hr' => 'hr', 'cs' => 'cs', 'da' => 'da', 'nl' => 'nl', 'en' => 'en', 'fa' => 'fa', 'fi' => 'fi', 'fr' => 'fr-FR', 'gd' => 'gd', 'de' => 'de', 'el' => 'el', 'he' => 'he', 'hi' => 'hi', 'hu' => 'hu', 'iu' => 'iu', 'it' => 'it', 'ja' => 'ja', 'ko' => 'ko', 'ku' => 'ku', 'mk' => 'mk', 'ml' => 'ml', 'no' => 'no', 'pl' => 'pl', 'pt' => 'pt', 'br' => 'pt-BR', 'pa' => 'pa', 'ro' => 'ro', 'ru' => 'ru', 'sr' => 'sr', 'so' => 'so', 'es' => 'es', 'sv' => 'sv', 'tl' => 'tl', 'ta' => 'ta', 'te' => 'te', 'tr' => 'tr', 'ur' => 'ur', 'vi' => 'vi', 'yi' => 'yi', 'uk' => 'en-GB', 'us' => 'en', 'ca' => 'en');
																								$Acacae5d24e92d0d = explode(' ', preg_replace('/[^A-Za-z0-9 ]/', '', XUI::$rRequest['name']));

																								if (1 >= count($Acacae5d24e92d0d)) {
																								} else {
																									foreach (array(0, count($Acacae5d24e92d0d) - 1) as $Ea22c4a9ab5b2176) {
																										$Eb40a01879a37d71 = strtolower($Acacae5d24e92d0d[$Ea22c4a9ab5b2176]);

																										if (!isset($f0d90482e9c61a22[$Eb40a01879a37d71])) {
																										} else {
																											$rLanguage = $f0d90482e9c61a22[$Eb40a01879a37d71];

																											break;
																										}
																									}
																								}

																								$d8a1409105424710 = null;
																								$b792983f62587674 = 0;

																								if (!$rLanguage) {
																								} else {
																									$Fee0d5a474c96306->query("SELECT `callSign`, `name`, `picon` FROM `epg_api` WHERE (LOWER(`name`) LIKE ? OR `callSign` = ?) AND `bcastLangs` LIKE '%\"" . $rLanguage . "\"%' ORDER BY `name` ASC;", trim($bbf487337b8f5211) . '%', $d4d6c242ee6f6592);

																									foreach ($Fee0d5a474c96306->get_rows() as $cfe5858b37d01860) {
																										if ($d4d6c242ee6f6592 && strtolower($cfe5858b37d01860['callSign']) == $d4d6c242ee6f6592) {
																											$d8a1409105424710 = array('id' => $cfe5858b37d01860['callSign'], 'text' => $cfe5858b37d01860['name'], 'icon' => $cfe5858b37d01860['picon'], 'lang' => $rLanguage, 'type' => 1, 'epg_id' => 0);
																										} else {
																											similar_text(strtolower($cfe5858b37d01860['name']), trim(strtolower($bbf487337b8f5211)), $Ee06f57eb50b4b36);

																											if (!($b792983f62587674 < $Ee06f57eb50b4b36 && 90 <= $Ee06f57eb50b4b36)) {
																											} else {
																												$d8a1409105424710 = array('id' => $cfe5858b37d01860['callSign'], 'text' => $cfe5858b37d01860['name'], 'icon' => $cfe5858b37d01860['picon'], 'lang' => $rLanguage, 'type' => 1, 'epg_id' => 0);
																												$b792983f62587674 = $Ee06f57eb50b4b36;
																											}
																										}
																									}
																								}

																								if ($d8a1409105424710) {
																								} else {
																									$Fee0d5a474c96306->query('SELECT `callSign`, `bcastLangs`, `name`, `picon` FROM `epg_api` WHERE LOWER(`name`) LIKE ? OR `callSign` = ? ORDER BY `name` ASC, `eng` DESC;', trim($bbf487337b8f5211) . '%', $d4d6c242ee6f6592);

																									foreach ($Fee0d5a474c96306->get_rows() as $cfe5858b37d01860) {
																										$bf25322090210c4b = json_decode($cfe5858b37d01860['bcastLangs'], true);

																										if ($d4d6c242ee6f6592 && strtolower($cfe5858b37d01860['callSign']) == $d4d6c242ee6f6592) {
																											$d8a1409105424710 = array('id' => $cfe5858b37d01860['callSign'], 'text' => $cfe5858b37d01860['name'], 'icon' => $cfe5858b37d01860['picon'], 'lang' => (isset($bf25322090210c4b[0]) ? $bf25322090210c4b[0] : ''), 'type' => 1, 'epg_id' => 0);
																										} else {
																											similar_text(strtolower($cfe5858b37d01860['name']), trim(strtolower($bbf487337b8f5211)), $Ee06f57eb50b4b36);

																											if (!($b792983f62587674 < $Ee06f57eb50b4b36 && 90 <= $Ee06f57eb50b4b36)) {
																											} else {
																												$d8a1409105424710 = array('id' => $cfe5858b37d01860['callSign'], 'text' => $cfe5858b37d01860['name'], 'icon' => $cfe5858b37d01860['picon'], 'lang' => (isset($bf25322090210c4b[0]) ? $bf25322090210c4b[0] : ''), 'type' => 1, 'epg_id' => 0);
																												$b792983f62587674 = $Ee06f57eb50b4b36;
																											}
																										}
																									}
																								}

																								if ($d8a1409105424710) {
																								} else {
																									$Fee0d5a474c96306->query('SELECT `epg_channels`.`epg_id`, `epg_channels`.`channel_id`, `epg_channels`.`name`, `epg_channels`.`langs`, `epg`.`epg_name` FROM `epg_channels` LEFT JOIN `epg` ON `epg_channels`.`epg_id` = `epg`.`id` WHERE LOWER(`epg_channels`.`name`) LIKE ? OR LOWER(`epg_channels`.`channel_id`) = ? ORDER BY `epg_channels`.`name` ASC;', trim($bbf487337b8f5211) . '%', $d4d6c242ee6f6592);

																									foreach ($Fee0d5a474c96306->get_rows() as $cfe5858b37d01860) {
																										if ($d4d6c242ee6f6592 && strtolower($cfe5858b37d01860['channel_id']) == $d4d6c242ee6f6592) {
																											$bf25322090210c4b = json_decode($cfe5858b37d01860['langs'], true);
																											$d8a1409105424710 = array('id' => $cfe5858b37d01860['channel_id'], 'text' => $cfe5858b37d01860['name'], 'icon' => null, 'lang' => (isset($bf25322090210c4b[0]) ? $bf25322090210c4b[0] : ''), 'epg_id' => $cfe5858b37d01860['epg_id'], 'type' => 0);

																											break;
																										}

																										similar_text(strtolower($cfe5858b37d01860['name']), trim(strtolower($bbf487337b8f5211)), $Ee06f57eb50b4b36);

																										if (!($b792983f62587674 < $Ee06f57eb50b4b36 && 90 <= $Ee06f57eb50b4b36)) {
																										} else {
																											$bf25322090210c4b = json_decode($cfe5858b37d01860['langs'], true);
																											$d8a1409105424710 = array('id' => $cfe5858b37d01860['channel_id'], 'text' => $cfe5858b37d01860['name'], 'icon' => null, 'lang' => (isset($bf25322090210c4b[0]) ? $bf25322090210c4b[0] : ''), 'epg_id' => $cfe5858b37d01860['epg_id'], 'type' => 0);
																											$b792983f62587674 = $Ee06f57eb50b4b36;
																										}
																									}
																								}

																								if ($d8a1409105424710) {
																								} else {
																									$bcd2ef56fb56b9e6 = B7B42FfAff30BB02(trim($bbf487337b8f5211));

																									foreach ($bcd2ef56fb56b9e6 as $cfe5858b37d01860) {
																										similar_text(strtolower($cfe5858b37d01860['name']), trim(strtolower($bbf487337b8f5211)), $Ee06f57eb50b4b36);

																										if (!($b792983f62587674 < $Ee06f57eb50b4b36 && 90 <= $Ee06f57eb50b4b36)) {
																										} else {
																											$bf25322090210c4b = json_decode($cfe5858b37d01860['bcastLangs'], true);
																											$d8a1409105424710 = array('id' => $cfe5858b37d01860['callSign'], 'text' => $cfe5858b37d01860['name'], 'icon' => $cfe5858b37d01860['picon'], 'lang' => (isset($bf25322090210c4b[0]) ? $bf25322090210c4b[0] : ''), 'type' => 1, 'epg_id' => 0);
																											$b792983f62587674 = $Ee06f57eb50b4b36;
																										}
																									}
																								}

																								if ($d8a1409105424710) {
																									echo json_encode(array('result' => true, 'data' => $d8a1409105424710));

																									exit();
																								}

																								echo json_encode(array('result' => false));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'rtmp_kill') {
																								if (aaCD47D8157A1A09('adv', 'rtmp')) {
																									echo A200986BbAe4B322(intval(XUI::$rRequest['server']), array('action' => 'rtmp_kill', 'name' => XUI::$rRequest['name']));

																									exit();
																								}

																								echo json_encode(array('result' => false));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'install_status') {
																								if (aACD47d8157a1A09('adv', 'add_server') || AacD47D8157a1A09('adv', 'edit_server')) {
																									XUI::$rServers = XUI::f99D78E199D641D5(true);
																									$d58b4f8653a391d8 = intval(XUI::$rRequest['server_id']);
																									$bc2874292e0d9ece = BIN_PATH . 'install/' . $d58b4f8653a391d8 . '.install';

																									if (file_exists($bc2874292e0d9ece)) {
																										echo json_encode(array('result' => true, 'data' => trim(file_get_contents($bc2874292e0d9ece)), 'status' => intval(XUI::$rServers[$d58b4f8653a391d8]['status'])));

																										exit();
																									}

																									echo json_encode(array('result' => false));

																									exit();
																								}

																								echo json_encode(array('result' => false));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'reinstall_server' && !$D8d681f377d877d4 && !$Ab5b854e25293d6b) {
																								if (aacD47d8157a1a09('adv', 'add_server') || aAcD47D8157a1A09('adv', 'edit_server')) {
																									$d58b4f8653a391d8 = intval(XUI::$rRequest['server_id']);

																									if ($a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_type'] == 0) {
																										$E379394c7b1a273f = 2;
																									} else {
																										$E379394c7b1a273f = 1;
																									}

																									$bc2874292e0d9ece = BIN_PATH . 'install/' . $d58b4f8653a391d8 . '.json';

																									if (file_exists($bc2874292e0d9ece)) {
																										$f0a0900c0afc1c32 = json_decode(file_get_contents($bc2874292e0d9ece), true);
																										$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 3 WHERE `id` = ?;', $d58b4f8653a391d8);

																										if (isset($f0a0900c0afc1c32['http_broadcast_port'])) {
																											$cf1c389bda3e30fd = PHP_BIN . ' ' . CLI_PATH . 'balancer.php ' . $E379394c7b1a273f . ' ' . intval($d58b4f8653a391d8) . ' ' . intval($f0a0900c0afc1c32['ssh_port']) . ' ' . escapeshellarg($f0a0900c0afc1c32['root_username']) . ' ' . escapeshellarg($f0a0900c0afc1c32['root_password']) . ' ' . intval($f0a0900c0afc1c32['http_broadcast_port']) . ' ' . intval($f0a0900c0afc1c32['https_broadcast_port']) . ' > "' . BIN_PATH . 'install/' . intval($d58b4f8653a391d8) . '.install" 2>/dev/null &';
																										} else {
																											$cf1c389bda3e30fd = PHP_BIN . ' ' . CLI_PATH . 'balancer.php ' . $E379394c7b1a273f . ' ' . intval($d58b4f8653a391d8) . ' ' . intval($f0a0900c0afc1c32['ssh_port']) . ' ' . escapeshellarg($f0a0900c0afc1c32['root_username']) . ' ' . escapeshellarg($f0a0900c0afc1c32['root_password']) . ' > "' . BIN_PATH . 'install/' . intval($d58b4f8653a391d8) . '.install" 2>/dev/null &';
																										}

																										shell_exec($cf1c389bda3e30fd);
																										echo json_encode(array('result' => true));

																										exit();
																									}

																									echo json_encode(array('result' => false));

																									exit();
																								}

																								echo json_encode(array('result' => false));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'fpm_status') {
																								if (aAcD47D8157a1A09('adv', 'add_server') || AaCD47d8157a1a09('adv', 'edit_server')) {
																									$a27e64cc6ce01033 = str_replace("\n", '<br/>', getFPMStatus(XUI::$rRequest['server_id']));

																									if (empty($a27e64cc6ce01033)) {
																										$a27e64cc6ce01033 = '<strong>No response from status page.</strong>';
																									} else {
																										$F4456cb30e99d3e9 = intval($a8bb73cba48fb7f6[XUI::$rRequest['server_id']]['total_services']);

																										if (!$F4456cb30e99d3e9) {
																										} else {
																											$a27e64cc6ce01033 .= '<br/><br/><strong>Results from 1 of ' . $F4456cb30e99d3e9 . ' PHP-FPM instances</strong>';
																										}
																									}

																									echo json_encode(array('result' => true, 'data' => $a27e64cc6ce01033));

																									exit();
																								}

																								echo json_encode(array('result' => false));

																								exit();
																							}

																							if (XUI::$rRequest['action'] == 'update_all_servers' && !$D8d681f377d877d4 && !$Ab5b854e25293d6b) {
																								if (AAcd47D8157a1A09('adv', 'servers')) {
																									foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
																										if (!$e81220b4451f37c9['server_online']) {
																										} else {
																											$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $e81220b4451f37c9['id'], time(), json_encode(array('action' => 'update')));
																										}
																									}
																									echo json_encode(array('result' => true));

																									exit();
																								} else {
																									echo json_encode(array('result' => false));

																									exit();
																								}
																							} else {
																								if (XUI::$rRequest['action'] == 'update_all_binaries' && !$D8d681f377d877d4 && !$Ab5b854e25293d6b) {
																									if (Aacd47D8157a1A09('adv', 'servers')) {
																										foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
																											if (!$e81220b4451f37c9['server_online']) {
																											} else {
																												$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $e81220b4451f37c9['id'], time(), json_encode(array('action' => 'update_binaries')));
																											}
																										}
																										echo json_encode(array('result' => true));

																										exit();
																									} else {
																										echo json_encode(array('result' => false));

																										exit();
																									}
																								} else {
																									if (XUI::$rRequest['action'] == 'disable_watch') {
																										if (aacD47d8157A1a09('adv', 'folder_watch_settings')) {
																											$Fee0d5a474c96306->query("UPDATE `watch_folders` SET `active` = 0 WHERE `type` <> 'plex';");
																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'enable_watch') {
																										if (aAcD47d8157a1A09('adv', 'folder_watch_settings')) {
																											$Fee0d5a474c96306->query("UPDATE `watch_folders` SET `active` = 1 WHERE `type` <> 'plex';");
																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'disable_plex') {
																										if (aacd47d8157a1A09('adv', 'folder_watch_settings')) {
																											$Fee0d5a474c96306->query("UPDATE `watch_folders` SET `active` = 0 WHERE `type` = 'plex';");
																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'enable_plex') {
																										if (AACD47d8157a1A09('adv', 'folder_watch_settings')) {
																											$Fee0d5a474c96306->query("UPDATE `watch_folders` SET `active` = 1 WHERE `type` = 'plex';");
																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'plex_sections') {
																										if (AACd47D8157a1A09('adv', 'folder_watch_settings')) {
																											$a27e64cc6ce01033 = getPlexLogin(XUI::$rRequest['username'], XUI::$rRequest['password']);

																											if (!isset($a27e64cc6ce01033['user']['authToken'])) {
																											} else {
																												$ea5296071288c730 = $a27e64cc6ce01033['user']['authToken'];
																												$F8fc019bd5a71db2 = getPlexSections(XUI::$rRequest['ip'], XUI::$rRequest['port'], $ea5296071288c730);

																												if (!($F8fc019bd5a71db2 && 0 < count($F8fc019bd5a71db2))) {
																												} else {
																													echo json_encode(array('result' => true, 'data' => $F8fc019bd5a71db2));

																													exit();
																												}
																											}

																											echo json_encode(array('result' => false));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'enable_handler') {
																										if (AAcd47D8157A1A09('adv', 'backups')) {
																											$Fee0d5a474c96306->query('UPDATE `settings` SET `redis_handler` = 1;');

																											if (!file_exists(CACHE_TMP_PATH . 'settings')) {
																											} else {
																												unlink(CACHE_TMP_PATH . 'settings');
																											}

																											exec('pgrep -u xui redis-server', $F42a951cf0a3370a);

																											if (!(0 < count($F42a951cf0a3370a) && is_numeric($F42a951cf0a3370a[0]))) {
																											} else {
																												$f9b07d216a168dcc = intval($F42a951cf0a3370a[0]);
																												shell_exec('kill -9 ' . $f9b07d216a168dcc);
																											}

																											shell_exec(XUI_HOME . 'bin/redis/redis-server ' . XUI_HOME . '/bin/redis/redis.conf > /dev/null 2>/dev/null &');
																											sleep(1);
																											exec("pgrep -U xui | xargs ps | grep signals | awk '{print \$1}'", $f9b07d216a168dcc);

																											if (!(0 < count($f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc[0]))) {
																											} else {
																												$f9b07d216a168dcc = intval($f9b07d216a168dcc[0]);
																												shell_exec('kill -9 ' . $f9b07d216a168dcc);
																												shell_exec(PHP_BIN . ' ' . CLI_PATH . 'signals.php > /dev/null 2>/dev/null &');
																											}

																											exec("pgrep -U xui | xargs ps | grep watchdog | awk '{print \$1}'", $f9b07d216a168dcc);

																											if (!(0 < count($f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc[0]))) {
																											} else {
																												$f9b07d216a168dcc = intval($f9b07d216a168dcc[0]);
																												shell_exec('kill -9 ' . $f9b07d216a168dcc);
																												shell_exec(PHP_BIN . ' ' . CLI_PATH . 'watchdog.php > /dev/null 2>/dev/null &');
																											}

																											shell_exec(PHP_BIN . ' ' . CRON_PATH . 'users.php 1 > /dev/null 2>/dev/null &');
																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'disable_handler') {
																										if (aACD47d8157a1A09('adv', 'backups')) {
																											$Fee0d5a474c96306->query('UPDATE `settings` SET `redis_handler` = 0;');

																											if (!file_exists(CACHE_TMP_PATH . 'settings')) {
																											} else {
																												unlink(CACHE_TMP_PATH . 'settings');
																											}

																											exec('pgrep -u xui redis-server', $F42a951cf0a3370a);

																											if (!(0 < count($F42a951cf0a3370a) && is_numeric($F42a951cf0a3370a[0]))) {
																											} else {
																												$f9b07d216a168dcc = intval($F42a951cf0a3370a[0]);
																												shell_exec('kill -9 ' . $f9b07d216a168dcc);
																											}

																											exec("pgrep -U xui | xargs ps | grep signals | awk '{print \$1}'", $f9b07d216a168dcc);

																											if (!(0 < count($f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc[0]))) {
																											} else {
																												$f9b07d216a168dcc = intval($f9b07d216a168dcc[0]);
																												shell_exec('kill -9 ' . $f9b07d216a168dcc);
																												shell_exec(PHP_BIN . ' ' . CLI_PATH . 'signals.php > /dev/null 2>/dev/null &');
																											}

																											exec("pgrep -U xui | xargs ps | grep watchdog | awk '{print \$1}'", $f9b07d216a168dcc);

																											if (!(0 < count($f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc[0]))) {
																											} else {
																												$f9b07d216a168dcc = intval($f9b07d216a168dcc[0]);
																												shell_exec('kill -9 ' . $f9b07d216a168dcc);
																												shell_exec(PHP_BIN . ' ' . CLI_PATH . 'watchdog.php > /dev/null 2>/dev/null &');
																											}

																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'clear_redis') {
																										if (AAcD47d8157A1a09('adv', 'backups')) {
																											XUI::$redis->flushAll();
																											echo json_encode(array('result' => true));

																											exit();
																										}

																										echo json_encode(array('result' => false));

																										exit();
																									}

																									if (XUI::$rRequest['action'] == 'report') {
																										if (aACd47d8157A1A09('adv', 'backups')) {
																											$C700a2b357e5ed65 = pathinfo('http://127.0.0.1:' . $a8bb73cba48fb7f6[SERVER_ID]['http_broadcast_port'] . $_SERVER['REQUEST_URI'])['dirname'] . '/table';
																											set_time_limit(60);
																											ini_set('memory_limit', '-1');
																											$f0a0900c0afc1c32 = json_decode(XUI::$rRequest['params'], true);

																											foreach (array() as $D3fa098be3f297cd) {
																												unset($f0a0900c0afc1c32[$D3fa098be3f297cd]);
																											}
																											$f0a0900c0afc1c32['api_user_id'] = $D4253f9520627819['id'];
																											$f0a0900c0afc1c32['report'] = true;
																											$f0a0900c0afc1c32['start'] = 0;
																											$f0a0900c0afc1c32['length'] = 100000;
																											$a27e64cc6ce01033 = json_decode(generateReport($C700a2b357e5ed65, $f0a0900c0afc1c32), true);
																											header('Content-Type: text/csv; charset=utf-8');
																											header('Content-Disposition: attachment; filename=report_' . preg_replace('/[^A-Za-z0-9 ]/', '', $f0a0900c0afc1c32['id']) . '_' . date('YmdHis') . '.csv');

																											if (0 >= count(($a27e64cc6ce01033['data'] ?: array()))) {
																											} else {
																												echo file_get_contents(convertToCSV($a27e64cc6ce01033['data']));
																											}

																											exit();
																										} else {
																											echo json_encode(array('result' => false));

																											exit();
																										}
																									} else {
																										if (XUI::$rRequest['action'] == 'decrypt_text') {
																											if (AAcd47D8157a1A09('adv', 'stream_tools')) {
																												$Cf1726816e259ec2 = array();
																												$Fa016cbf0b72bfdd = (XUI::$rRequest['text'] ?: null);

																												if (!$Fa016cbf0b72bfdd) {
																												} else {
																													$f2cc0807b1dc8948 = explode("\n", $Fa016cbf0b72bfdd);

																													foreach ($f2cc0807b1dc8948 as $Ff014d0ebd314fcd) {
																														$B211d7401e6242f3 = explode('/', $Ff014d0ebd314fcd);

																														foreach ($B211d7401e6242f3 as $Eb40a01879a37d71) {
																															if (stripos($Eb40a01879a37d71, 'token=') === false) {
																															} else {
																																list(, $Eb40a01879a37d71) = explode('token=', $Eb40a01879a37d71);
																															}

																															$d156d70a98f8b08c = base64_decode(strtr($Eb40a01879a37d71, '-_', '+/'));

																															if (empty($d156d70a98f8b08c)) {
																															} else {
																																try {
																																	$e0c0d6359f5bd8d6 = Xui\Functions::decrypt($Eb40a01879a37d71, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
																																} catch (Exception $c34ae71903f0d920) {
																																	$e0c0d6359f5bd8d6 = null;
																																}

																																if (!$e0c0d6359f5bd8d6) {
																																} else {
																																	$Cf1726816e259ec2[] = utf8_decode($e0c0d6359f5bd8d6);
																																}
																															}
																														}
																													}
																												}

																												if (0 < count($Cf1726816e259ec2)) {
																													echo json_encode(array('result' => true, 'data' => $Cf1726816e259ec2));

																													exit();
																												}

																												echo json_encode(array('result' => false));

																												exit();
																											}

																											echo json_encode(array('result' => false));

																											exit();
																										}

																										if (XUI::$rRequest['action'] == 'get_episode_ids') {
																											if (aaCD47d8157a1a09('adv', 'add_episode')) {
																												$a85e1b7d42c346a0 = array();
																												$a27e64cc6ce01033 = json_decode(XUI::$rRequest['data'], true);

																												if (!is_array($a27e64cc6ce01033)) {
																													echo json_encode(array('result' => false));

																													exit();
																												}

																												$a68b12348744a7ff = array();

																												if (XUI::$rSettings['parse_type'] == 'guessit') {
																													foreach ($a27e64cc6ce01033 as $c15bdcf528f98303 => $d9ee1cc8e0f43f6e) {
																														$a68b12348744a7ff[$c15bdcf528f98303] = pathinfo($d9ee1cc8e0f43f6e)['filename'];
																													}
																													$cf1c389bda3e30fd = XUI_HOME . 'bin/guess ' . escapeshellarg(json_encode($a68b12348744a7ff));
																												} else {
																													foreach ($a27e64cc6ce01033 as $c15bdcf528f98303 => $d9ee1cc8e0f43f6e) {
																														$a68b12348744a7ff[$c15bdcf528f98303] = pathinfo(str_replace('-', '_', $d9ee1cc8e0f43f6e))['filename'];
																													}
																													$cf1c389bda3e30fd = '/usr/bin/python3 ' . XUI_HOME . 'includes/python/release.py ' . escapeshellarg(json_encode($a68b12348744a7ff));
																												}

																												$b1fa0ad0bb84d114 = json_decode(shell_exec($cf1c389bda3e30fd), true);

																												foreach ($b1fa0ad0bb84d114 as $c15bdcf528f98303 => $Bd43537fab08ca31) {
																													if (!isset($Bd43537fab08ca31['episode'])) {
																													} else {
																														if (is_array($Bd43537fab08ca31['episode'])) {
																															$a85e1b7d42c346a0[] = array($c15bdcf528f98303, intval($Bd43537fab08ca31['episode'][0]));
																														} else {
																															$a85e1b7d42c346a0[] = array($c15bdcf528f98303, intval($Bd43537fab08ca31['episode']));
																														}
																													}
																												}
																												echo json_encode(array('result' => true, 'data' => $a85e1b7d42c346a0));

																												exit();
																											} else {
																												echo json_encode(array('result' => false));

																												exit();
																											}
																										} else {
																											if (XUI::$rRequest['action'] == 'send_panel_logs') {
																												XUI::submitPanelLogs();
																												echo json_encode(array('result' => true));

																												exit();
																											}

																											if (XUI::$rRequest['action'] == 'get_epg') {
																												if (aaCD47d8157A1A09('adv', 'manage_streams')) {
																													$f338147e1f8d2e97 = (XUI::$rRequest['timezone'] ?: 'Europe/London');
																													date_default_timezone_set($f338147e1f8d2e97);
																													$a85e1b7d42c346a0 = array('Channels' => array());
																													$f46da30a01f7b2d7 = array_map('intval', explode(',', XUI::$rRequest['channels']));

																													if (count($f46da30a01f7b2d7) != 0) {
																														$cfd208d2a440ee12 = (intval(XUI::$rRequest['hours']) ?: 3);
																														$a63ba41c5c63ce14 = (intval(strtotime(XUI::$rRequest['startdate'])) ?: time());
																														$cdc10b88b0856b7b = $a63ba41c5c63ce14 + $cfd208d2a440ee12 * 3600;
																														$E1514647500a0f17 = floatval(100 / ($cfd208d2a440ee12 * 60));
																														$A8ac391b1f39fea4 = $f46da30a01f7b2d7;
																														sort($A8ac391b1f39fea4);
																														$C90c2eaf5bf12357 = array();

																														if (0 >= count($f46da30a01f7b2d7)) {
																														} else {
																															$Ac46667df5353a3d = array();
																															$Fee0d5a474c96306->query('SELECT `id`, `tv_archive_server_id`, `tv_archive_duration` FROM `streams` WHERE `id` IN (' . implode(',', $f46da30a01f7b2d7) . ');');

																															if (0 >= $Fee0d5a474c96306->num_rows()) {
																															} else {
																																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																	$Ac46667df5353a3d[$C740da31596f24ef['id']] = $C740da31596f24ef;
																																}
																															}

																															$d8a1409105424710 = XUI::faE50DEE78ECD0FB($f46da30a01f7b2d7, $a63ba41c5c63ce14, $cdc10b88b0856b7b);

																															foreach ($d8a1409105424710 as $F8c99b2741720390 => $E05d5c8afb9dc282) {
																																$f023cab07639b662 = 0;

																																foreach ($E05d5c8afb9dc282 as $cfe5858b37d01860) {
																																	$aeed52390092b102 = ($cfe5858b37d01860['start'] < $a63ba41c5c63ce14 ? $a63ba41c5c63ce14 : $cfe5858b37d01860['start']);
																																	$e17366debb94d4d3 = ($cdc10b88b0856b7b < $cfe5858b37d01860['end'] ? $cdc10b88b0856b7b : $cfe5858b37d01860['end']);
																																	$C5034884ed44603a = ($e17366debb94d4d3 - $aeed52390092b102) / 60;
																																	$f665b8e041442d05 = null;

																																	if (!isset($Ac46667df5353a3d[$F8c99b2741720390])) {
																																	} else {
																																		if (!(0 < $Ac46667df5353a3d[$F8c99b2741720390]['tv_archive_server_id'] && 0 < $Ac46667df5353a3d[$F8c99b2741720390]['tv_archive_duration'])) {
																																		} else {
																																			if (time() - $Ac46667df5353a3d[$F8c99b2741720390]['tv_archive_duration'] * 86400 > $cfe5858b37d01860['start']) {
																																			} else {
																																				$f665b8e041442d05 = array($cfe5858b37d01860['start'], intval(($cfe5858b37d01860['end'] - $cfe5858b37d01860['start']) / 60));
																																			}
																																		}
																																	}

																																	$d900b05a324062bb = round($C5034884ed44603a * $E1514647500a0f17, 2);
																																	$f023cab07639b662 += $d900b05a324062bb;

																																	if (100 >= $f023cab07639b662) {
																																	} else {
																																		$d900b05a324062bb -= $f023cab07639b662 - 100;
																																	}

																																	$C90c2eaf5bf12357[$F8c99b2741720390][] = array('ListingId' => $cfe5858b37d01860['id'], 'ChannelId' => $F8c99b2741720390, 'Title' => $cfe5858b37d01860['title'], 'RelativeSize' => $d900b05a324062bb, 'StartTime' => date('h:iA', $aeed52390092b102), 'EndTime' => date('h:iA', $e17366debb94d4d3), 'Start' => $cfe5858b37d01860['start'], 'End' => $cfe5858b37d01860['end'], 'Specialisation' => 'tv', 'Archive' => $f665b8e041442d05);
																																}
																															}
																														}

																														$abaa62e1905e65f3 = array('ChannelId' => null, 'Title' => 'No Programme Information...', 'RelativeSize' => 100, 'StartTime' => 'Not Available', 'EndTime' => '', 'Specialisation' => 'tv', 'Archive' => null);
																														$Fee0d5a474c96306->query('SELECT `id`, `stream_icon`, `stream_display_name`, `tv_archive_duration`, `tv_archive_server_id`, `category_id` FROM `streams` WHERE `id` IN (' . implode(',', $f46da30a01f7b2d7) . ') ORDER BY FIELD(`id`, ' . implode(',', $f46da30a01f7b2d7) . ') ASC;');

																														foreach ($Fee0d5a474c96306->get_rows() as $f523e362fb81d6c8) {
																															if (0 < $f523e362fb81d6c8['tv_archive_duration'] && 0 < $f523e362fb81d6c8['tv_archive_server_id']) {
																																$f665b8e041442d05 = $f523e362fb81d6c8['tv_archive_duration'];
																															} else {
																																$f665b8e041442d05 = 0;
																															}

																															$d181e44c558407ca = $abaa62e1905e65f3;
																															$d181e44c558407ca['ChannelId'] = $f523e362fb81d6c8['id'];
																															$A38b42a281e3c3cf = json_decode($f523e362fb81d6c8['category_id'], true);
																															$A5dcdeb6ecbbf6bd = CBe87E2a9A996111('live');

																															if (0 < strlen(XUI::$rRequest['category'])) {
																																$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
																															} else {
																																$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
																															}

																															if (1 >= count($A38b42a281e3c3cf)) {
																															} else {
																																$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
																															}

																															$a85e1b7d42c346a0['Channels'][] = array('Id' => $f523e362fb81d6c8['id'], 'DisplayName' => $f523e362fb81d6c8['stream_display_name'], 'CategoryName' => $A1925ae53e9307eb, 'Archive' => $f665b8e041442d05, 'Image' => (XUI::b8f3DEf724810918($f523e362fb81d6c8['stream_icon']) ?: ''), 'TvListings' => ($C90c2eaf5bf12357[$f523e362fb81d6c8['id']] ?: array($d181e44c558407ca)));
																														}
																														echo json_encode($a85e1b7d42c346a0);

																														exit();
																													} else {
																														echo json_encode($a85e1b7d42c346a0);

																														exit();
																													}
																												} else {
																													echo json_encode(array('result' => false));

																													exit();
																												}
																											} else {
																												if (XUI::$rRequest['action'] == 'get_programme') {
																													if (AACd47d8157a1a09('adv', 'manage_streams')) {
																														$f338147e1f8d2e97 = (XUI::$rRequest['timezone'] ?: 'Europe/London');
																														date_default_timezone_set($f338147e1f8d2e97);

																														if (!isset(XUI::$rRequest['id'])) {
																														} else {
																															$C740da31596f24ef = XUI::getProgramme(XUI::$rRequest['stream_id'], XUI::$rRequest['id']);

																															if (!$C740da31596f24ef) {
																															} else {
																																$f665b8e041442d05 = $A4d7b7db36f83f3e = false;

																																if (time() >= $C740da31596f24ef['end']) {
																																} else {
																																	$Fee0d5a474c96306->query('SELECT `server_id`, `direct_source`, `monitor_pid`, `pid`, `stream_status`, `on_demand` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` WHERE `streams`.`id` = ? AND `server_id` IS NOT NULL;', XUI::$rRequest['stream_id']);

																																	if (0 >= $Fee0d5a474c96306->num_rows()) {
																																	} else {
																																		foreach ($Fee0d5a474c96306->get_rows() as $C2c9bb154c711e06) {
																																			if (!$C2c9bb154c711e06['server_id'] || $C2c9bb154c711e06['direct_source']) {
																																			} else {
																																				$A4d7b7db36f83f3e = true;

																																				break;
																																			}
																																		}
																																	}
																																}

																																$C740da31596f24ef['date'] = date('H:i', $C740da31596f24ef['start']) . ' - ' . date('H:i', $C740da31596f24ef['end']);
																																echo json_encode(array('result' => true, 'data' => $C740da31596f24ef, 'available' => $A4d7b7db36f83f3e, 'archive' => $f665b8e041442d05));

																																exit();
																															}
																														}

																														echo json_encode(array('result' => false));

																														exit();
																													}

																													echo json_encode(array('result' => false));

																													exit();
																												}

																												if (XUI::$rRequest['action'] == 'queue') {
																													if (aACD47D8157A1a09('adv', 'streams') || AacD47d8157A1A09('adv', 'series') || aaCD47D8157A1A09('adv', 'episodes')) {
																														$b4cd770ed1b094fe = XUI::$rRequest['sub'];
																														$Fee0d5a474c96306->query('SELECT * FROM `queue` WHERE `id` = ?;', XUI::$rRequest['id']);

																														if ($Fee0d5a474c96306->num_rows() != 1) {
																														} else {
																															$C740da31596f24ef = $Fee0d5a474c96306->get_row();

																															if ($b4cd770ed1b094fe == 'delete') {
																																$Fee0d5a474c96306->query('DELETE FROM `queue` WHERE `id` = ?;', XUI::$rRequest['id']);
																																echo json_encode(array('result' => true));

																																exit();
																															}

																															if ($b4cd770ed1b094fe != 'stop') {
																															} else {
																																if (0 >= $C740da31596f24ef['pid']) {
																																} else {
																																	killPID($C740da31596f24ef['server_id'], $C740da31596f24ef['pid']);
																																}

																																$Fee0d5a474c96306->query('DELETE FROM `queue` WHERE `id` = ?;', XUI::$rRequest['id']);
																																echo json_encode(array('result' => true));

																																exit();
																															}
																														}

																														echo json_encode(array('result' => false));

																														exit();
																													}

																													echo json_encode(array('result' => false));

																													exit();
																												}

																												if (XUI::$rRequest['action'] == 'search') {
																													$a85e1b7d42c346a0 = array('total_count' => 0, 'items' => array(), 'result' => true);
																													$Ce638dbade6c8824 = array('lines' => array('Lines', 'line?id=', '`username`, `admin_notes`, `reseller_notes`, `last_ip`, `contact`', 'id', 'username'), 'mag_devices' => array('MAG Devices', 'mag?id=', '`mac_filter`, `ip`', 'mag_id', 'mac'), 'enigma2_devices' => array('Enigma2 Devices', 'enigma?id=', '`mac_filter`, `public_ip`', 'device_id', 'mac'), 'users' => array('Users', 'user?id=', '`username`, `email`, `ip`, `notes`, `reseller_dns`', 'id', 'username'), 'streams' => array('Streams, Movies & Episodes', 'stream_view?id=', '`stream_display_name`, `stream_source`, `notes`, `channel_id`', 'id', 'stream_display_name'), 'streams_series' => array('TV Series', 'serie?id=', '`title`, `plot`, `cast`, `director`', 'id', 'title'));
																													$E400a3101514583e = 100;
																													$Be47c94a460069d8 = strtolower(preg_replace('/[^[:alnum:][:space:]]/u', '', XUI::$rRequest['search']));
																													$Be7a74fe8ecf3cfe = strtolower(preg_replace('/[^[:alnum:][:space:]]/u', ' ', XUI::$rRequest['search']));

																													if (empty($Be7a74fe8ecf3cfe)) {
																													} else {
																														$Ef44992a6c30afea = array();

																														foreach ($Ce638dbade6c8824 as $B1a1e80ba9ae29c7 => $F5ba091f949ce999) {
																															if ($B1a1e80ba9ae29c7 == 'streams') {
																																$Fee0d5a474c96306->query('SELECT `' . $B1a1e80ba9ae29c7 . '`.*, MATCH(' . $F5ba091f949ce999[2] . ') AGAINST (? IN BOOLEAN MODE) AS `score1`, MATCH(' . $F5ba091f949ce999[2] . ') AGAINST (? IN BOOLEAN MODE) AS `score2` FROM `' . $B1a1e80ba9ae29c7 . '` WHERE MATCH(' . $F5ba091f949ce999[2] . ') AGAINST (? IN BOOLEAN MODE) OR `id` = ? ORDER BY `score1` + `score2` DESC LIMIT ' . $E400a3101514583e . ';', $Be7a74fe8ecf3cfe, $Be7a74fe8ecf3cfe . '*', $Be7a74fe8ecf3cfe . '*', intval($Be47c94a460069d8));
																															} else {
																																$Fee0d5a474c96306->query('SELECT `' . $B1a1e80ba9ae29c7 . '`.*, MATCH(' . $F5ba091f949ce999[2] . ') AGAINST (? IN BOOLEAN MODE) AS `score1`, MATCH(' . $F5ba091f949ce999[2] . ') AGAINST (? IN BOOLEAN MODE) AS `score2` FROM `' . $B1a1e80ba9ae29c7 . '` WHERE MATCH(' . $F5ba091f949ce999[2] . ') AGAINST (? IN BOOLEAN MODE) ORDER BY `score1` + `score2` DESC LIMIT ' . $E400a3101514583e . ';', $Be7a74fe8ecf3cfe, $Be7a74fe8ecf3cfe . '*', $Be7a74fe8ecf3cfe . '*');
																															}

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																similar_text($Be47c94a460069d8, strtolower(preg_replace('/[^[:alnum:][:space:]]/u', '', $C740da31596f24ef[$F5ba091f949ce999[4]])), $c87d9d608a724773);

																																if (!($B1a1e80ba9ae29c7 == 'streams' && $C740da31596f24ef['id'] == intval($Be47c94a460069d8))) {
																																} else {
																																	$c87d9d608a724773 = 1000;
																																}

																																if ($Be47c94a460069d8 != strtolower(preg_replace('/[^[:alnum:][:space:]]/u', '', $C740da31596f24ef[$F5ba091f949ce999[4]]))) {
																																} else {
																																	$c87d9d608a724773 = 1000;
																																}

																																$C740da31596f24ef['score'] = $C740da31596f24ef['score1'] + $C740da31596f24ef['score2'] + $c87d9d608a724773;
																																$C740da31596f24ef['table'] = $B1a1e80ba9ae29c7;
																																$Ef44992a6c30afea[] = $C740da31596f24ef;
																															}
																														}
																														array_multisort(array_column($Ef44992a6c30afea, 'score'), SORT_DESC, $Ef44992a6c30afea);
																														$Ef44992a6c30afea = array_slice($Ef44992a6c30afea, 0, (intval(XUI::$rSettings['search_items']) ?: 50));
																														$Ea4c8228489dbd48 = $Dd941dc92e49a2ab = $Cde0ba71e2c62c4c = $Ed94fed7e6680a78 = $b174976b99c4ec48 = $b58b71142a808858 = $Cdb85875fd50f459 = array();

																														foreach ($Ef44992a6c30afea as $bb2621204e39e62d) {
																															if ($bb2621204e39e62d['table'] == 'streams') {
																																if (0 >= intval($bb2621204e39e62d['id'])) {
																																} else {
																																	$Cdb85875fd50f459[] = intval($bb2621204e39e62d['id']);
																																}
																															} else {
																																if ($bb2621204e39e62d['table'] == 'streams_series') {
																																	if (0 >= intval($bb2621204e39e62d['id'])) {
																																	} else {
																																		$b58b71142a808858[] = intval($bb2621204e39e62d['id']);
																																	}
																																} else {
																																	if ($bb2621204e39e62d['table'] == 'users') {
																																		if (0 >= intval($bb2621204e39e62d['id'])) {
																																		} else {
																																			$b174976b99c4ec48[] = intval($bb2621204e39e62d['id']);
																																		}

																																		if (0 >= intval($bb2621204e39e62d['owner_id'])) {
																																		} else {
																																			$Ed94fed7e6680a78[] = intval($bb2621204e39e62d['owner_id']);
																																		}
																																	} else {
																																		if ($bb2621204e39e62d['table'] == 'lines') {
																																			if (0 >= intval($bb2621204e39e62d['id'])) {
																																			} else {
																																				$Cde0ba71e2c62c4c[] = intval($bb2621204e39e62d['id']);
																																			}

																																			if (0 >= intval($bb2621204e39e62d['member_id'])) {
																																			} else {
																																				$Ed94fed7e6680a78[] = intval($bb2621204e39e62d['member_id']);
																																			}

																																			$A202b3c93cf6536c = json_decode($bb2621204e39e62d['last_activity_array'], true);

																																			if (!(is_array($A202b3c93cf6536c) && 0 < intval($A202b3c93cf6536c['stream_id']))) {
																																			} else {
																																				$Ea4c8228489dbd48[] = intval($A202b3c93cf6536c['stream_id']);
																																			}
																																		} else {
																																			if (!($bb2621204e39e62d['table'] == 'mag_devices' || $bb2621204e39e62d['table'] == 'enigma2_devices')) {
																																			} else {
																																				if (0 >= intval($bb2621204e39e62d['user_id'])) {
																																				} else {
																																					$Dd941dc92e49a2ab[] = intval($bb2621204e39e62d['user_id']);
																																					$Cde0ba71e2c62c4c[] = intval($bb2621204e39e62d['user_id']);
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																														$A6e6647236c59634 = $c92aec5c90838930 = $ffa397dce49c9928 = $Ad42be2d728f55b7 = $Dbe14b0046f69b40 = $b58f88305f02dad1 = $Be8acff8875eca91 = $dd1f15ced480823a = $A22e90fc2c4763f8 = $caa77b80211665a0 = $bde5957fb5fa9547 = $aa7c56b92b4e4962 = array();
																														$Dd941dc92e49a2ab = confirmIDs($Dd941dc92e49a2ab);

																														if (0 >= count($Dd941dc92e49a2ab)) {
																														} else {
																															$Fee0d5a474c96306->query('SELECT * FROM `lines` WHERE `id` IN (' . implode(',', $Dd941dc92e49a2ab) . ');');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$A6e6647236c59634[$C740da31596f24ef['id']] = $C740da31596f24ef;

																																if (0 >= intval($C740da31596f24ef['member_id'])) {
																																} else {
																																	$Ed94fed7e6680a78[] = $C740da31596f24ef['member_id'];
																																}
																															}
																														}

																														$Cdb85875fd50f459 = confirmIDs($Cdb85875fd50f459);

																														if (0 >= count($Cdb85875fd50f459)) {
																														} else {
																															$Fee0d5a474c96306->query('SELECT `streams_episodes`.`stream_id`, `streams_series`.`id`, `streams_series`.`title` FROM `streams_episodes` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` WHERE `streams_episodes`.`stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$dd1f15ced480823a[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['title'];
																															}
																															$Fee0d5a474c96306->query('SELECT * FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$caa77b80211665a0[$C740da31596f24ef['stream_id']]++;

																																if ($a8bb73cba48fb7f6[$C740da31596f24ef['server_id']]['server_online']) {
																																	$C740da31596f24ef['priority'] = (0 < $C740da31596f24ef['pid'] ? 1 : 0);
																																} else {
																																	$C740da31596f24ef['priority'] = 0;
																																}

																																$A22e90fc2c4763f8[$C740da31596f24ef['stream_id']][] = $C740da31596f24ef;
																															}

																															foreach (array_keys($A22e90fc2c4763f8) as $F26087d31c2bbe4d) {
																																array_multisort(array_column($b72c70c2ef4f8e06[$F26087d31c2bbe4d], 'priority'), SORT_DESC, $b72c70c2ef4f8e06[$F26087d31c2bbe4d]);
																															}

																															if (XUI::$rSettings['redis_handler']) {
																																$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, true, true);
																															} else {
																																$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(*) AS `count` FROM `lines_live` WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ') AND `hls_end` = 0;');

																																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																	$bde5957fb5fa9547[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
																																}
																															}
																														}

																														$b58b71142a808858 = confirmIDs($b58b71142a808858);

																														if (0 >= count($b58b71142a808858)) {
																														} else {
																															$Fee0d5a474c96306->query('SELECT `series_id`, MAX(`season_num`) AS `latest_season`, COUNT(*) AS `episodes` FROM `streams_episodes` WHERE `series_id` IN (' . implode(',', $b58b71142a808858) . ') GROUP BY `series_id`;');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$Be8acff8875eca91[$C740da31596f24ef['series_id']] = array($C740da31596f24ef['latest_season'], $C740da31596f24ef['episodes']);
																															}
																														}

																														$b174976b99c4ec48 = confirmIDs($b174976b99c4ec48);

																														if (0 >= count($b174976b99c4ec48)) {
																														} else {
																															$Fee0d5a474c96306->query('SELECT `owner_id`, COUNT(*) AS `count` FROM `users` WHERE `owner_id` IN (' . implode(',', $b174976b99c4ec48) . ') GROUP BY `owner_id`;');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$Dbe14b0046f69b40[$C740da31596f24ef['owner_id']] = $C740da31596f24ef['count'];
																															}
																															$Fee0d5a474c96306->query('SELECT `member_id`, COUNT(*) AS `count` FROM `lines` WHERE `member_id` IN (' . implode(',', $b174976b99c4ec48) . ') GROUP BY `member_id`;');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$b58f88305f02dad1[$C740da31596f24ef['member_id']] = $C740da31596f24ef['count'];
																															}
																														}

																														$Ed94fed7e6680a78 = confirmIDs($Ed94fed7e6680a78);

																														if (0 >= count($Ed94fed7e6680a78)) {
																														} else {
																															$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `users` WHERE `id` IN (' . implode(',', $Ed94fed7e6680a78) . ');');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$Ad42be2d728f55b7[$C740da31596f24ef['id']] = $C740da31596f24ef['username'];
																															}
																														}

																														$Cde0ba71e2c62c4c = confirmIDs($Cde0ba71e2c62c4c);

																														if (0 >= count($Cde0ba71e2c62c4c)) {
																														} else {
																															if (XUI::$rSettings['redis_handler']) {
																																$aa7c56b92b4e4962 = XUI::DE78B5E00A0718d6($Cde0ba71e2c62c4c, true);
																																$C7dc44e2b269673a = XUI::getFirstConnection($Cde0ba71e2c62c4c);
																																$Ce55624efb64200c = array();

																																foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
																																	if (in_array($e110a2ab6d3a4734['stream_id'], $Cdb85875fd50f459)) {
																																	} else {
																																		$Ce55624efb64200c[] = intval($e110a2ab6d3a4734['stream_id']);
																																	}
																																}
																																$F36bea2698ecb4fa = array();

																																if (0 >= count($Ce55624efb64200c)) {
																																} else {
																																	$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Ce55624efb64200c) . ');');

																																	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																		$F36bea2698ecb4fa[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
																																	}
																																}

																																foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
																																	$ffa397dce49c9928[$D78ff1d0edade5eb]['stream_id'] = $e110a2ab6d3a4734['stream_id'];
																																	$ffa397dce49c9928[$D78ff1d0edade5eb]['last_active'] = $e110a2ab6d3a4734['date_start'];
																																	$ffa397dce49c9928[$D78ff1d0edade5eb]['online'] = true;
																																	$Ea4c8228489dbd48[] = intval($e110a2ab6d3a4734['stream_id']);
																																}
																																unset($C7dc44e2b269673a);
																															} else {
																																$Fee0d5a474c96306->query('SELECT `lines_live`.`user_id`, `lines_live`.`stream_id`, `lines_live`.`date_start` AS `last_active`, `streams`.`stream_display_name` FROM `lines_live` LEFT JOIN `streams` ON `streams`.`id` = `lines_live`.`stream_id` INNER JOIN (SELECT `user_id`, MAX(`date_start`) AS `ts` FROM `lines_live` GROUP BY `user_id`) `maxt` ON (`lines_live`.`user_id` = `maxt`.`user_id` AND `lines_live`.`date_start` = `maxt`.`ts`) WHERE `lines_live`.`hls_end` = 0 AND `lines_live`.`user_id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

																																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																	$ffa397dce49c9928[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
																																	$ffa397dce49c9928[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
																																	$ffa397dce49c9928[$C740da31596f24ef['user_id']]['online'] = true;
																																	$Ea4c8228489dbd48[] = intval($C740da31596f24ef['stream_id']);
																																}
																																$Fee0d5a474c96306->query('SELECT `user_id`, COUNT(*) AS `count` FROM `lines_live` WHERE `user_id` IN (' . implode(',', array_map('intval', $Cde0ba71e2c62c4c)) . ') AND `hls_end` = 0;');

																																foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																	$aa7c56b92b4e4962[$C740da31596f24ef['user_id']] = $C740da31596f24ef['count'];
																																}
																															}
																														}

																														$Ea4c8228489dbd48 = confirmIDs($Ea4c8228489dbd48);

																														if (0 >= count($Ea4c8228489dbd48)) {
																														} else {
																															$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', array_unique($Ea4c8228489dbd48)) . ');');

																															foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																$c92aec5c90838930[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
																															}
																														}

																														$A5dcdeb6ecbbf6bd = CbE87E2a9A996111(null);
																														$ca518e82bd328243 = bA348B5700ee9FF3();

																														foreach ($Ef44992a6c30afea as $bb2621204e39e62d) {
																															$F5ba091f949ce999 = $Ce638dbade6c8824[$bb2621204e39e62d['table']];

																															switch ($bb2621204e39e62d['table']) {
																																case 'streams':
																																	$b72c70c2ef4f8e06 = ($A22e90fc2c4763f8[$bb2621204e39e62d['id']][0] ?: null);
																																	$A38b42a281e3c3cf = json_decode($bb2621204e39e62d['category_id'], true);
																																	$D92b16dc36690ab9 = json_decode($bb2621204e39e62d['movie_properties'], true);

																																	if ($bb2621204e39e62d['type'] != 5) {
																																		if (aacd47d8157A1A09('adv', 'manage_streams')) {
																																			$c608db3e24256b76 = "<span style='cursor: pointer;' onClick=\"navigate('stream_view?id=" . intval($bb2621204e39e62d['id']) . "');\">" . $bb2621204e39e62d['stream_display_name'] . '</span>';
																																		} else {
																																			$c608db3e24256b76 = $bb2621204e39e62d['stream_display_name'];
																																		}

																																		$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');

																																		if (1 >= count($A38b42a281e3c3cf)) {
																																		} else {
																																			$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ')';
																																		}
																																	} else {
																																		if (AaCD47D8157a1A09('adv', 'manage_streams')) {
																																			$c608db3e24256b76 = ($dd1f15ced480823a[$bb2621204e39e62d['id']] ? "<span style='cursor: pointer;' onClick=\"navigate('stream_view?id=" . intval($bb2621204e39e62d['id']) . "');\">" . $dd1f15ced480823a[$bb2621204e39e62d['id']] . '</span>' : 'No Series');
																																		} else {
																																			$c608db3e24256b76 = ($dd1f15ced480823a[$bb2621204e39e62d['id']] ?: 'No Series');
																																		}

																																		if (stripos($bb2621204e39e62d['stream_display_name'], $c608db3e24256b76) !== 0) {
																																		} else {
																																			$A1925ae53e9307eb = ltrim(substr($bb2621204e39e62d['stream_display_name'], strlen($c608db3e24256b76), strlen($bb2621204e39e62d['stream_display_name']) - strlen($c608db3e24256b76)));

																																			if (substr($A1925ae53e9307eb, 0, 1) != '-') {
																																			} else {
																																				$A1925ae53e9307eb = trim(ltrim($A1925ae53e9307eb, '-'));
																																			}
																																		}
																																	}

																																	if ($bb2621204e39e62d['type'] != 2) {
																																	} else {
																																		$e962a80487b84e46 = '';

																																		if (!$D92b16dc36690ab9['rating']) {
																																		} else {
																																			$B0ac3a61df74ba36 = round($D92b16dc36690ab9['rating']) / 2;
																																			$d25560ad0b146132 = floor($B0ac3a61df74ba36);
																																			$b39c3caa0856cfa2 = 0 < $B0ac3a61df74ba36 - $d25560ad0b146132;
																																			$D46dfa8113384246 = 5 - ($d25560ad0b146132 + (($b39c3caa0856cfa2 ? 1 : 0)));

																																			if (0 >= $d25560ad0b146132) {
																																			} else {
																																				foreach (range(1, $d25560ad0b146132) as $Ea22c4a9ab5b2176) {
																																					$e962a80487b84e46 .= "<i class='mdi mdi-star'></i>";
																																				}
																																			}

																																			if (!$b39c3caa0856cfa2) {
																																			} else {
																																				$e962a80487b84e46 .= "<i class='mdi mdi-star-half'></i>";
																																			}

																																			if (0 >= $D46dfa8113384246) {
																																			} else {
																																				foreach (range(1, $D46dfa8113384246) as $Ea22c4a9ab5b2176) {
																																					$e962a80487b84e46 .= "<i class='mdi mdi-star-outline'></i>";
																																				}
																																			}
																																		}

																																		$A02729c83b6cd395 = ($bb2621204e39e62d['year'] ? '<strong>' . $bb2621204e39e62d['year'] . '</strong> &nbsp;' : '');
																																		$c608db3e24256b76 .= "<br><span style='font-size:11px;'>" . $A02729c83b6cd395 . $e962a80487b84e46 . '</span></a>';
																																	}

																																	$bb2621204e39e62d['server_id'] = ($b72c70c2ef4f8e06['server_id'] ?: null);

																																	if ($bb2621204e39e62d['server_id']) {
																																		$B00ef71aa2cd7a26 = $a8bb73cba48fb7f6[$bb2621204e39e62d['server_id']]['server_name'];

																																		if (1 >= $caa77b80211665a0[$bb2621204e39e62d['id']]) {
																																		} else {
																																			$B00ef71aa2cd7a26 .= ' (+' . ($caa77b80211665a0[$bb2621204e39e62d['id']] - 1) . ')';
																																		}
																																	} else {
																																		$B00ef71aa2cd7a26 = '';
																																	}

																																	if ($b72c70c2ef4f8e06) {
																																		$fad73125a2cca3ed = time() - intval($b72c70c2ef4f8e06['stream_started']);

																																		if ($bb2621204e39e62d['type'] == 1 || $bb2621204e39e62d['type'] == 4) {
																																			if (intval($bb2621204e39e62d['direct_source']) == 1) {
																																				$b45800af0138159b = 5;
																																			} else {
																																				if ($b72c70c2ef4f8e06['monitor_pid']) {
																																					if ($b72c70c2ef4f8e06['pid'] && 0 < $b72c70c2ef4f8e06['pid']) {
																																						if (intval($b72c70c2ef4f8e06['stream_status']) == 2) {
																																							$b45800af0138159b = 2;
																																						} else {
																																							$b45800af0138159b = 1;
																																						}
																																					} else {
																																						if ($b72c70c2ef4f8e06['stream_status'] == 0) {
																																							$b45800af0138159b = 2;
																																						} else {
																																							$b45800af0138159b = 3;
																																						}
																																					}
																																				} else {
																																					if (intval($b72c70c2ef4f8e06['on_demand']) == 1) {
																																						$b45800af0138159b = 4;
																																					} else {
																																						$b45800af0138159b = 0;
																																					}
																																				}
																																			}
																																		} else {
																																			if ($bb2621204e39e62d['type'] == 2 || $bb2621204e39e62d['type'] == 5) {
																																				if (intval($bb2621204e39e62d['direct_source']) == 1) {
																																					$b45800af0138159b = 5;
																																				} else {
																																					if (!is_null($b72c70c2ef4f8e06['pid']) && 0 < $b72c70c2ef4f8e06['pid']) {
																																						if ($b72c70c2ef4f8e06['to_analyze'] == 1) {
																																							$b45800af0138159b = 7;
																																						} else {
																																							if ($b72c70c2ef4f8e06['stream_status'] == 1) {
																																								$b45800af0138159b = 10;
																																							} else {
																																								$b45800af0138159b = 9;
																																							}
																																						}
																																					} else {
																																						$b45800af0138159b = 8;
																																					}
																																				}
																																			} else {
																																				if ($bb2621204e39e62d['type'] != 3) {
																																				} else {
																																					if ($b72c70c2ef4f8e06['monitor_pid']) {
																																						if ($b72c70c2ef4f8e06['pid'] && 0 < $b72c70c2ef4f8e06['pid']) {
																																							if (intval($b72c70c2ef4f8e06['stream_status']) == 2) {
																																								$b45800af0138159b = 2;
																																							} else {
																																								$b45800af0138159b = 1;
																																							}
																																						} else {
																																							if ($b72c70c2ef4f8e06['stream_status'] == 0) {
																																								$b45800af0138159b = 2;
																																							} else {
																																								$b45800af0138159b = 3;
																																							}
																																						}
																																					} else {
																																						$b45800af0138159b = 0;
																																					}

																																					if (count(json_decode($b72c70c2ef4f8e06['cchannel_rsources'], true)) == count(json_decode($bb2621204e39e62d['stream_source'], true)) || $b72c70c2ef4f8e06['parent_id']) {
																																					} else {
																																						$b45800af0138159b = 6;
																																					}
																																				}
																																			}
																																		}
																																	} else {
																																		if (intval($bb2621204e39e62d['direct_source']) == 1) {
																																			$b45800af0138159b = 5;
																																		} else {
																																			$b45800af0138159b = -1;
																																		}
																																	}

																																	if ($b45800af0138159b == 1) {
																																		if (86400 <= $fad73125a2cca3ed) {
																																			$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
																																		} else {
																																			$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
																																		}

																																		$fad73125a2cca3ed = "<button type='button' class='btn bg-animate-info btn-xs waves-effect waves-light no-border btn-fixed-xl'>" . $fad73125a2cca3ed . '</button>';
																																	} else {
																																		if ($b45800af0138159b == 6) {
																																			$bbfc9bd8432031f5 = json_decode($bb2621204e39e62d['stream_source'], true);
																																			$Fb362f76a7dd37ee = count(array_diff($bbfc9bd8432031f5, json_decode($b72c70c2ef4f8e06['cchannel_rsources'], true)));
																																			$a4c39aca5bca0ec1 = intval((count($bbfc9bd8432031f5) - $Fb362f76a7dd37ee) / count($bbfc9bd8432031f5) * 100);
																																			$fad73125a2cca3ed = "<button type='button' class='btn bg-animate-primary btn-xs waves-effect waves-light no-border btn-fixed-xl'>" . $a4c39aca5bca0ec1 . '% DONE</button>';
																																		} else {
																																			$fad73125a2cca3ed = $Fb789833d0ff5a8b[$b45800af0138159b];
																																		}
																																	}

																																	if ($bb2621204e39e62d['type'] == 1) {
																																		$ae61e4e240417fd0 = $ddf21fc658e95052 = 'stream';
																																	} else {
																																		if ($bb2621204e39e62d['type'] == 2) {
																																			$ae61e4e240417fd0 = $ddf21fc658e95052 = 'movie';
																																		} else {
																																			if ($bb2621204e39e62d['type'] == 3) {
																																				$ae61e4e240417fd0 = 'channel';
																																				$ddf21fc658e95052 = 'created_channel';
																																			} else {
																																				if ($bb2621204e39e62d['type'] == 4) {
																																					$ae61e4e240417fd0 = $ddf21fc658e95052 = 'radio';
																																				} else {
																																					if ($bb2621204e39e62d['type'] != 5) {
																																					} else {
																																						$ae61e4e240417fd0 = $ddf21fc658e95052 = 'episode';
																																					}
																																				}
																																			}
																																		}
																																	}

																																	$Bbd2c904b7ebe265 = false;
																																	$ebab77ef4bee81e0 = '<div class="btn-group bg-animate-info">';

																																	if (in_array($bb2621204e39e62d['type'], array(1, 3, 4))) {
																																		if (!AAcd47D8157a1a09('adv', 'edit_stream')) {
																																		} else {
																																			$Bbd2c904b7ebe265 = true;
																																			$ebab77ef4bee81e0 .= "<button title=\"Edit\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"navigate('" . $ddf21fc658e95052 . '?id=' . intval($bb2621204e39e62d['id']) . "');\"><i class=\"mdi mdi-pencil\"></i></button>";

																																			if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $bb2621204e39e62d['on_demand'] == 1 || $b45800af0138159b == 5 || $b45800af0138159b == 7) {
																																				$ebab77ef4bee81e0 .= "<button title=\"Stop\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"searchAPI('stream', " . intval($bb2621204e39e62d['id']) . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
																																				$Ba23222f3ed2dc08 = '';
																																			} else {
																																				$ebab77ef4bee81e0 .= "<button title=\"Start\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"searchAPI('stream', " . intval($bb2621204e39e62d['id']) . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
																																				$Ba23222f3ed2dc08 = ' disabled';
																																			}

																																			$ebab77ef4bee81e0 .= "<button title=\"Restart\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"searchAPI('stream', " . intval($bb2621204e39e62d['id']) . ", 'restart');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-refresh"></i></button>';
																																			$ebab77ef4bee81e0 .= "<button title=\"Purge\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"searchAPI('stream', " . intval($bb2621204e39e62d['id']) . ", 'purge');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-hammer"></i></button>';

																																			if ($bb2621204e39e62d['type'] != 1) {
																																			} else {
																																				if (($bde5957fb5fa9547[$bb2621204e39e62d['id']] ?: false)) {
																																					$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-xs waves-effect waves-light no-border tooltip" onClick="modalFingerprint(' . $bb2621204e39e62d['id'] . ", 'stream');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
																																				} else {
																																					$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-xs waves-effect waves-light no-border tooltip"><i class="mdi mdi-fingerprint"></i></button>';
																																				}
																																			}
																																		}
																																	} else {
																																		if (!aACd47D8157A1A09('adv', 'edit_' . $ddf21fc658e95052)) {
																																		} else {
																																			$Bbd2c904b7ebe265 = true;
																																			$ebab77ef4bee81e0 .= "<button title=\"Edit\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"navigate('" . $ddf21fc658e95052 . '?id=' . intval($bb2621204e39e62d['id']) . "');\"><i class=\"mdi mdi-pencil\"></i></button>";

																																			if (intval($b45800af0138159b) == 9) {
																																				$ebab77ef4bee81e0 .= "<button title=\"Re-Encode\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('" . $ddf21fc658e95052 . "', " . intval($bb2621204e39e62d['id']) . ", 'start');\"><i class=\"mdi mdi-refresh\"></i></button>";
																																			} else {
																																				if (intval($b45800af0138159b) == 5) {
																																					$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-xs waves-effect waves-light no-border tooltip"><i class="mdi mdi-stop"></i></button>';
																																				} else {
																																					if (intval($b45800af0138159b) == 7) {
																																						$ebab77ef4bee81e0 .= "<button title=\"Stop Encoding\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('" . $ddf21fc658e95052 . "', " . intval($bb2621204e39e62d['id']) . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
																																					} else {
																																						$ebab77ef4bee81e0 .= "<button title=\"Start Encoding\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('" . $ddf21fc658e95052 . "', " . intval($bb2621204e39e62d['id']) . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
																																					}
																																				}
																																			}

																																			$ebab77ef4bee81e0 .= "<button title=\"Purge\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onclick=\"searchAPI('" . $ddf21fc658e95052 . "', " . intval($bb2621204e39e62d['id']) . ", 'purge');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-hammer"></i></button>';
																																		}
																																	}

																																	$ebab77ef4bee81e0 .= '</div>';

																																	if (in_array($bb2621204e39e62d['type'], array(1, 3, 4))) {
																																		$E9c8d08bfb6ef33c = urlencode($bb2621204e39e62d['stream_icon']);
																																		$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">' . $c608db3e24256b76 . '</h3>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate"><small>' . $A1925ae53e9307eb . '<br/>' . $B00ef71aa2cd7a26 . '</small></p>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="float-right text-center search-icon">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<img src="resize?maxw=96&maxh=96&url=' . $E9c8d08bfb6ef33c . '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="card-body action-block">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="media align-items-center align-center">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%; display: flex;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn bg-animate-success btn-xs waves-effect waves-light no-border">' . strtoupper($ae61e4e240417fd0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<i class=\"fe-zap text-white\"></i> &nbsp; <button onClick=\"navigate('live_connections?stream_id=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn bg-animate-info btn-xs waves-effect waves-light no-border\">" . number_format($bde5957fb5fa9547[$bb2621204e39e62d['id']], 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-clock text-white"></i> &nbsp; ' . $fad73125a2cca3ed . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>';

																																		if (!$Bbd2c904b7ebe265) {
																																		} else {
																																			$Aec1063e97236589 .= '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-sliders text-white"></i> &nbsp; ' . $ebab77ef4bee81e0 . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>';
																																		}

																																		$Aec1063e97236589 .= '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>';
																																	} else {
																																		$E9c8d08bfb6ef33c = urlencode($D92b16dc36690ab9['movie_image']);
																																		$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t\t\t\t\t" . '<div class="search-fade">' . "\n\t\t\t\t\t\t\t\t\t" . "<div class=\"search-image\" style=\"background: url('resize?maxw=512&maxh=512&url=" . $E9c8d08bfb6ef33c . "');\"></div>" . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">' . $c608db3e24256b76 . '</h3>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate"><small>' . $A1925ae53e9307eb . '<br/>' . $B00ef71aa2cd7a26 . '</small></p>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="card-body action-block">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="media align-items-center align-center">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%; display: flex;">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn bg-animate-primary btn-xs waves-effect waves-light no-border">' . strtoupper($ddf21fc658e95052) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<i class=\"fe-zap text-white\"></i> &nbsp; <button onClick=\"navigate('live_connections?stream_id=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn bg-animate-info btn-xs waves-effect waves-light no-border\">" . number_format($bde5957fb5fa9547[$bb2621204e39e62d['id']], 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-clock text-white"></i> &nbsp; ' . $fad73125a2cca3ed . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>';

																																		if (!$Bbd2c904b7ebe265) {
																																		} else {
																																			$Aec1063e97236589 .= '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-sliders text-white"></i> &nbsp; ' . $ebab77ef4bee81e0 . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>';
																																		}

																																		$Aec1063e97236589 .= '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>';
																																	}

																																	break;

																																case 'streams_series':
																																	$B2f4ba52951b74ae = ($Be8acff8875eca91[$bb2621204e39e62d['id']] ?: array());
																																	$A38b42a281e3c3cf = json_decode($bb2621204e39e62d['category_id'], true);
																																	$c608db3e24256b76 = $bb2621204e39e62d['title'];
																																	$e962a80487b84e46 = '';

																																	if (!$bb2621204e39e62d['rating']) {
																																	} else {
																																		$B0ac3a61df74ba36 = round($bb2621204e39e62d['rating']) / 2;
																																		$d25560ad0b146132 = floor($B0ac3a61df74ba36);
																																		$b39c3caa0856cfa2 = 0 < $B0ac3a61df74ba36 - $d25560ad0b146132;
																																		$D46dfa8113384246 = 5 - ($d25560ad0b146132 + (($b39c3caa0856cfa2 ? 1 : 0)));

																																		if (0 >= $d25560ad0b146132) {
																																		} else {
																																			foreach (range(1, $d25560ad0b146132) as $Ea22c4a9ab5b2176) {
																																				$e962a80487b84e46 .= "<i class='mdi mdi-star'></i>";
																																			}
																																		}

																																		if (!$b39c3caa0856cfa2) {
																																		} else {
																																			$e962a80487b84e46 .= "<i class='mdi mdi-star-half'></i>";
																																		}

																																		if (0 >= $D46dfa8113384246) {
																																		} else {
																																			foreach (range(1, $D46dfa8113384246) as $Ea22c4a9ab5b2176) {
																																				$e962a80487b84e46 .= "<i class='mdi mdi-star-outline'></i>";
																																			}
																																		}
																																	}

																																	$A02729c83b6cd395 = ($bb2621204e39e62d['year'] ? '<strong>' . $bb2621204e39e62d['year'] . '</strong> &nbsp;' : '');
																																	$c608db3e24256b76 .= "<br><span style='font-size:11px;'>" . $A02729c83b6cd395 . $e962a80487b84e46 . '</span></a>';
																																	$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');

																																	if (1 >= count($A38b42a281e3c3cf)) {
																																	} else {
																																		$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ')';
																																	}

																																	$Bbd2c904b7ebe265 = false;
																																	$ebab77ef4bee81e0 = '<div class="btn-group bg-animate-info">';

																																	if (!Aacd47D8157A1a09('adv', 'add_episode')) {
																																	} else {
																																		$Bbd2c904b7ebe265 = true;
																																		$ebab77ef4bee81e0 .= "<button title=\"Add Episode(s)\" onClick=\"navigate('episode?sid=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\"><i class=\"mdi mdi-plus-circle-outline\"></i></button>";
																																	}

																																	if (!aAcD47D8157A1A09('adv', 'episodes')) {
																																	} else {
																																		$Bbd2c904b7ebe265 = true;
																																		$ebab77ef4bee81e0 .= "<button title=\"View Episodes\" onClick=\"navigate('episodes?series=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\"><i class=\"mdi mdi-eye\"></i></button>";
																																	}

																																	if (!AACD47D8157a1a09('adv', 'edit_series')) {
																																	} else {
																																		$Bbd2c904b7ebe265 = true;
																																		$ebab77ef4bee81e0 .= "<button title=\"Edit\" onClick=\"navigate('serie?id=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\"><i class=\"mdi mdi-pencil\"></i></button>";
																																	}

																																	$ebab77ef4bee81e0 .= '</div>';
																																	$E9c8d08bfb6ef33c = urlencode($bb2621204e39e62d['cover']);
																																	$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t\t\t\t" . '<div class="search-fade">' . "\n\t\t\t\t\t\t\t\t" . "<div class=\"search-image\" style=\"background: url('resize?maxw=512&maxh=512&url=" . $E9c8d08bfb6ef33c . "');\"></div>" . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">' . $c608db3e24256b76 . '</h3>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate"><small>' . $A1925ae53e9307eb . '<br/>' . $B00ef71aa2cd7a26 . '</small></p>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="card-body action-block">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center align-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%; display: flex;">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn bg-animate-danger btn-xs waves-effect waves-light no-border">TV SERIES</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'S &nbsp; <button type="button" class="btn bg-animate-info btn-xs waves-effect waves-light no-border">' . number_format($B2f4ba52951b74ae[0], 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'E &nbsp; <button type="button" class="btn bg-animate-info btn-xs waves-effect waves-light no-border">' . number_format($B2f4ba52951b74ae[1], 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';

																																	if (!$Bbd2c904b7ebe265) {
																																	} else {
																																		$Aec1063e97236589 .= '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-sliders text-white"></i> &nbsp; ' . $ebab77ef4bee81e0 . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';
																																	}

																																	$Aec1063e97236589 .= '</ul>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>';

																																	break;

																																case 'users':
																																	$c926828403592095 = ($Dbe14b0046f69b40[$bb2621204e39e62d['id']] ?: 0);
																																	$Ee60e729075f9d1b = ($b58f88305f02dad1[$bb2621204e39e62d['id']] ?: 0);
																																	$bead195351fb7ad9 = ($Ad42be2d728f55b7[$bb2621204e39e62d['owner_id']] ?: null);
																																	$Bbd2c904b7ebe265 = false;
																																	$ebab77ef4bee81e0 = '<div class="btn-group bg-animate-info">';

																																	if (!AacD47D8157a1a09('adv', 'edit_reguser')) {
																																	} else {
																																		$Bbd2c904b7ebe265 = true;

																																		if (!$ca518e82bd328243[$bb2621204e39e62d['member_group_id']]['is_reseller']) {
																																		} else {
																																			$ebab77ef4bee81e0 .= '<button title="Add Credits" type="button" class="btn btn-xs waves-effect waves-light no-border tooltip" onClick="addCredits(' . $bb2621204e39e62d['id'] . ');"><i class="mdi mdi-coin"></i></button>';
																																		}

																																		$ebab77ef4bee81e0 .= "<button title=\"Edit\" onClick=\"navigate('user?id=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\"><i class=\"mdi mdi-pencil\"></i></button>";

																																		if ($bb2621204e39e62d['status'] == 1) {
																																			$ebab77ef4bee81e0 .= "<button title=\"Disable\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('user', " . $bb2621204e39e62d['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
																																		} else {
																																			$ebab77ef4bee81e0 .= "<button title=\"Enable\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('user', " . $bb2621204e39e62d['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
																																		}
																																	}

																																	$ebab77ef4bee81e0 .= '</div>';

																																	if ($bb2621204e39e62d['status'] == 1) {
																																		$Ba23222f3ed2dc08 = 'Active';
																																		$D9aac12363ab83b0 = 'info';
																																	} else {
																																		$Ba23222f3ed2dc08 = 'Inactive';
																																		$D9aac12363ab83b0 = 'warning';
																																	}

																																	$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">';

																																	if ($ca518e82bd328243[$bb2621204e39e62d['member_group_id']]['is_reseller']) {
																																		$Aec1063e97236589 .= '<div class="col-9">';
																																	} else {
																																		$Aec1063e97236589 .= '<div class="col-12">';
																																	}

																																	$Aec1063e97236589 .= '<div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">' . $bb2621204e39e62d['username'] . '</h3>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-lighter mb-1 text-truncate"><small>' . (($ca518e82bd328243[$bb2621204e39e62d['member_group_id']]['group_name'] ? '<span class="text-white">' . $ca518e82bd328243[$bb2621204e39e62d['member_group_id']]['group_name'] . '</span><br/>' : '')) . (($bead195351fb7ad9 ? '<span class="text-white">owner:</span> ' . $bead195351fb7ad9 : '')) . '</small></p>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>';

																																	if (!$ca518e82bd328243[$bb2621204e39e62d['member_group_id']]['is_reseller']) {
																																	} else {
																																		$Aec1063e97236589 .= '<div class="col-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="float-right text-center font-24 search-icon-xl">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-coin text-white"></i><br/>' . number_format($bb2621204e39e62d['credits'], 0) . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>';
																																	}

																																	$Aec1063e97236589 .= '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="card-body action-block">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center align-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%; display: flex;">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn bg-animate-warning btn-xs waves-effect waves-light no-border">USER</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-user-check text-white"></i> &nbsp; <button type="button" class="btn bg-animate-' . $D9aac12363ab83b0 . ' btn-xs waves-effect waves-light no-border">' . $Ba23222f3ed2dc08 . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-users text-white"></i> &nbsp; <button type="button" class="btn bg-animate-info btn-xs waves-effect waves-light no-border">' . number_format($c926828403592095, 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-tv text-white"></i> &nbsp; <button type="button" class="btn bg-animate-info btn-xs waves-effect waves-light no-border">' . number_format($Ee60e729075f9d1b, 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';

																																	if (!$Bbd2c904b7ebe265) {
																																	} else {
																																		$Aec1063e97236589 .= '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-sliders text-white"></i> &nbsp; ' . $ebab77ef4bee81e0 . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';
																																	}

																																	$Aec1063e97236589 .= '</ul>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>';

																																	break;

																																case 'lines':
																																	$bead195351fb7ad9 = ($Ad42be2d728f55b7[$bb2621204e39e62d['member_id']] ?: null);
																																	$Bbd2c904b7ebe265 = false;
																																	$ebab77ef4bee81e0 = '<div class="btn-group bg-animate-info">';

																																	if (!aAcd47D8157A1a09('adv', 'edit_user')) {
																																	} else {
																																		$Bbd2c904b7ebe265 = true;
																																		$ebab77ef4bee81e0 .= "<button title=\"Edit\" onClick=\"navigate('line?id=" . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\"><i class=\"mdi mdi-pencil\"></i></button>";
																																		$ebab77ef4bee81e0 .= "<button title=\"Kill Connections\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $bb2621204e39e62d['id'] . ", 'kill');\"><i class=\"fas fa-hammer\"></i></button>";

																																		if ($bb2621204e39e62d['admin_enabled']) {
																																			$ebab77ef4bee81e0 .= "<button title=\"Ban Line\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $bb2621204e39e62d['id'] . ", 'ban');\"><i class=\"mdi mdi-power\"></i></button>";
																																		} else {
																																			$ebab77ef4bee81e0 .= "<button title=\"Unban Line\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $bb2621204e39e62d['id'] . ", 'unban');\"><i class=\"mdi mdi-power\"></i></button>";
																																		}

																																		if ($bb2621204e39e62d['enabled']) {
																																			$ebab77ef4bee81e0 .= "<button title=\"Disable Line\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $bb2621204e39e62d['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
																																		} else {
																																			$ebab77ef4bee81e0 .= "<button title=\"Enable Line\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $bb2621204e39e62d['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
																																		}

																																		if (($aa7c56b92b4e4962[$bb2621204e39e62d['id']] ?: false)) {
																																			$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-xs waves-effect waves-light no-border tooltip" onClick="modalFingerprint(' . $bb2621204e39e62d['id'] . ", 'user');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
																																		} else {
																																			$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-xs waves-effect waves-light no-border tooltip"><i class="mdi mdi-fingerprint"></i></button>';
																																		}
																																	}

																																	$ebab77ef4bee81e0 .= '</div>';

																																	if (!$bb2621204e39e62d['admin_enabled']) {
																																		$Ba23222f3ed2dc08 = 'Banned';
																																		$D9aac12363ab83b0 = 'danger';
																																	} else {
																																		if (!$bb2621204e39e62d['enabled']) {
																																			$Ba23222f3ed2dc08 = 'Disabled';
																																			$D9aac12363ab83b0 = 'warning';
																																		} else {
																																			$Ba23222f3ed2dc08 = 'Active';
																																			$D9aac12363ab83b0 = 'info';
																																		}
																																	}

																																	$E5ae9288fdfb3b75 = (isset($ffa397dce49c9928[$bb2621204e39e62d['id']]) ? $ffa397dce49c9928[$bb2621204e39e62d['id']] : json_decode($bb2621204e39e62d['last_activity_array'], true));

																																	if (is_array($E5ae9288fdfb3b75)) {
																																		$E5ae9288fdfb3b75['stream_display_name'] = $c92aec5c90838930[$E5ae9288fdfb3b75['stream_id']];

																																		if ($E5ae9288fdfb3b75['online']) {
																																			$Dda8beb221295d37 = "<a class='text-white' href='javascript:void(0);' onClick=\"navigate('stream_view?id=" . intval($E5ae9288fdfb3b75['stream_id']) . "');\">" . $E5ae9288fdfb3b75['stream_display_name'] . "</a><br/><small class='text-lighter'>Online: " . XUI::F01C2E2cFc16141e(time() - $E5ae9288fdfb3b75['last_active']) . '</small>';
																																		} else {
																																			$Dda8beb221295d37 = "Last Active<br/><small class='text-lighter'>" . (($E5ae9288fdfb3b75['date_end'] ? date(XUI::$rSettings['date_format'], $E5ae9288fdfb3b75['date_end']) . '<br/>' . date('H:i:s', $E5ae9288fdfb3b75['date_end']) : 'Never')) . '</small>';
																																		}
																																	} else {
																																		$Dda8beb221295d37 = "Last Active<br/><small class='text-lighter'>Never</small>";
																																	}

																																	$bae85948a6f4b7de = ($bb2621204e39e62d['exp_date'] ? date(XUI::$rSettings['datetime_format'], $bb2621204e39e62d['exp_date']) : null);
																																	$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">' . $bb2621204e39e62d['username'] . '</h3>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-lighter mb-1 text-truncate"><small>' . (($bae85948a6f4b7de ? '<span class="text-white">expires:</span> ' . $bae85948a6f4b7de . '<br/>' : '')) . (($bead195351fb7ad9 ? '<span class="text-white">owner:</span> ' . $bead195351fb7ad9 : '')) . '</small></p>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="float-right text-center search-icon-xl mt-1">' . $Dda8beb221295d37 . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="card-body action-block">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center align-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%; display: flex;">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn bg-animate-pink btn-xs waves-effect waves-light no-border">' . (($bb2621204e39e62d['is_restreamer'] ? "<i title='Restreamer' class='mdi mdi-swap-horizontal tooltip'></i> " : ($bb2621204e39e62d['is_trial'] ? "<i title='Trial' class='mdi mdi-gavel tooltip'></i> " : ''))) . 'LINE</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-user-check text-white"></i> &nbsp; <button type="button" class="btn bg-animate-' . $D9aac12363ab83b0 . ' btn-xs waves-effect waves-light no-border">' . $Ba23222f3ed2dc08 . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-zap text-white"></i> &nbsp; <button type="button" class="btn bg-animate-info btn-xs waves-effect waves-light no-border">' . number_format(($aa7c56b92b4e4962[$bb2621204e39e62d['id']] ?: 0), 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';

																																	if (!$Bbd2c904b7ebe265) {
																																	} else {
																																		$Aec1063e97236589 .= '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-sliders text-white"></i> &nbsp; ' . $ebab77ef4bee81e0 . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';
																																	}

																																	$Aec1063e97236589 .= '</ul>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>';

																																	break;

																																case 'enigma_devices':
																																case 'mag_devices':
																																	$a4dd92d2bc66e08d = ($A6e6647236c59634[$bb2621204e39e62d['user_id']] ?: null);

																																	if ($a4dd92d2bc66e08d) {
																																		$fd2f28ba628730b5 = ($bb2621204e39e62d['table'] == 'mag_devices' ? 'mag' : 'enigma');
																																		$bead195351fb7ad9 = ($Ad42be2d728f55b7[$a4dd92d2bc66e08d['member_id']] ?: null);
																																		$Bbd2c904b7ebe265 = false;
																																		$ebab77ef4bee81e0 = '<div class="btn-group bg-animate-info">';

																																		if (!aACd47d8157a1a09('adv', 'edit_user')) {
																																		} else {
																																			$Bbd2c904b7ebe265 = true;
																																			$ebab77ef4bee81e0 .= "<button title=\"Edit\" onClick=\"navigate('" . $fd2f28ba628730b5 . '?id=' . $bb2621204e39e62d['id'] . "');\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\"><i class=\"mdi mdi-pencil\"></i></button>";
																																			$ebab77ef4bee81e0 .= "<button title=\"Kill Connection\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $a4dd92d2bc66e08d['id'] . ", 'kill');\"><i class=\"fas fa-hammer\"></i></button>";

																																			if ($bb2621204e39e62d['admin_enabled']) {
																																				$ebab77ef4bee81e0 .= "<button title=\"Ban Device\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $a4dd92d2bc66e08d['id'] . ", 'ban');\"><i class=\"mdi mdi-power\"></i></button>";
																																			} else {
																																				$ebab77ef4bee81e0 .= "<button title=\"Unban Device\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $a4dd92d2bc66e08d['id'] . ", 'unban');\"><i class=\"mdi mdi-power\"></i></button>";
																																			}

																																			if ($bb2621204e39e62d['enabled']) {
																																				$ebab77ef4bee81e0 .= "<button title=\"Disable Device\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $a4dd92d2bc66e08d['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
																																			} else {
																																				$ebab77ef4bee81e0 .= "<button title=\"Enable Device\" type=\"button\" class=\"btn btn-xs waves-effect waves-light no-border tooltip\" onClick=\"searchAPI('line', " . $a4dd92d2bc66e08d['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
																																			}

																																			if (($aa7c56b92b4e4962[$a4dd92d2bc66e08d['id']] ?: false)) {
																																				$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-xs waves-effect waves-light no-border tooltip" onClick="modalFingerprint(' . $a4dd92d2bc66e08d['id'] . ", 'user');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
																																			} else {
																																				$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-xs waves-effect waves-light no-border tooltip"><i class="mdi mdi-fingerprint"></i></button>';
																																			}
																																		}

																																		$ebab77ef4bee81e0 .= '</div>';

																																		if (!$a4dd92d2bc66e08d['admin_enabled']) {
																																			$Ba23222f3ed2dc08 = 'Banned';
																																			$D9aac12363ab83b0 = 'danger';
																																		} else {
																																			if (!$a4dd92d2bc66e08d['enabled']) {
																																				$Ba23222f3ed2dc08 = 'Disabled';
																																				$D9aac12363ab83b0 = 'warning';
																																			} else {
																																				$Ba23222f3ed2dc08 = 'Active';
																																				$D9aac12363ab83b0 = 'info';
																																			}
																																		}

																																		$E5ae9288fdfb3b75 = (isset($ffa397dce49c9928[$a4dd92d2bc66e08d['id']]) ? $ffa397dce49c9928[$a4dd92d2bc66e08d['id']] : json_decode($a4dd92d2bc66e08d['last_activity_array'], true));

																																		if (is_array($E5ae9288fdfb3b75)) {
																																			$E5ae9288fdfb3b75['stream_display_name'] = $c92aec5c90838930[$E5ae9288fdfb3b75['stream_id']];

																																			if ($E5ae9288fdfb3b75['online']) {
																																				$Dda8beb221295d37 = "<a class='text-white' href='javascript:void(0);' onClick=\"navigate('stream_view?id=" . intval($E5ae9288fdfb3b75['stream_id']) . "');\">" . $E5ae9288fdfb3b75['stream_display_name'] . "</a><br/><small class='text-lighter'>Online: " . XUI::F01c2e2CFc16141E(time() - $E5ae9288fdfb3b75['last_active']) . '</small>';
																																			} else {
																																				$Dda8beb221295d37 = "Last Active<br/><small class='text-lighter'>" . (($E5ae9288fdfb3b75['date_end'] ? date(XUI::$rSettings['date_format'], $E5ae9288fdfb3b75['date_end']) . '<br/>' . date('H:i:s', $E5ae9288fdfb3b75['date_end']) : 'Never')) . '</small>';
																																			}
																																		} else {
																																			$Dda8beb221295d37 = "Last Active<br/><small class='text-lighter'>Never</small>";
																																		}

																																		$bae85948a6f4b7de = ($a4dd92d2bc66e08d['exp_date'] ? date(XUI::$rSettings['datetime_format'], $a4dd92d2bc66e08d['exp_date']) : null);
																																		$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">' . $bb2621204e39e62d['mac'] . '</h3>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-lighter mb-1 text-truncate"><small>' . (($bae85948a6f4b7de ? '<span class="text-white">expires:</span> ' . $bae85948a6f4b7de . '<br/>' : '')) . (($bead195351fb7ad9 ? '<span class="text-white">owner:</span> ' . $bead195351fb7ad9 : '')) . '</small></p>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="float-right text-center search-icon-xl mt-1">' . $Dda8beb221295d37 . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="card-body action-block">' . "\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center align-center">' . "\n\t\t\t\t\t\t\t\t\t" . '<ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%; display: flex;">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn bg-animate-pink btn-xs waves-effect waves-light no-border">' . (($a4dd92d2bc66e08d['is_trial'] ? "<i class='mdi mdi-gavel'></i> " : '')) . strtoupper($fd2f28ba628730b5) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-user-check text-white"></i> &nbsp; <button type="button" class="btn bg-animate-' . $D9aac12363ab83b0 . ' btn-xs waves-effect waves-light no-border">' . $Ba23222f3ed2dc08 . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-zap text-white"></i> &nbsp; <button type="button" class="btn bg-animate-info btn-xs waves-effect waves-light no-border">' . number_format(($aa7c56b92b4e4962[$a4dd92d2bc66e08d['id']] ?: 0), 0) . '</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';

																																		if (!$Bbd2c904b7ebe265) {
																																		} else {
																																			$Aec1063e97236589 .= '<li class="dropdown notification-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a class="mr-0 waves-effect pd-left pd-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="pro-user-name text-white ml-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-sliders text-white"></i> &nbsp; ' . $ebab77ef4bee81e0 . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</li>';
																																		}

																																		$Aec1063e97236589 .= '</ul>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>';

																																		break;
																																	}

																																	break;
																															}
																															$a85e1b7d42c346a0['items'][] = array('id' => $B1a1e80ba9ae29c7 . '#' . $bb2621204e39e62d[$F5ba091f949ce999[3]], 'url' => $F5ba091f949ce999[1] . $bb2621204e39e62d[$F5ba091f949ce999[3]], 'text' => $bb2621204e39e62d[$F5ba091f949ce999[4]], 'html' => $Aec1063e97236589);
																														}
																													}

																													$a85e1b7d42c346a0['total_count'] = count($a85e1b7d42c346a0['items']);

																													if ($a85e1b7d42c346a0['total_count'] != 0) {
																													} else {
																														$Aec1063e97236589 = '<div class="card-search text-white">' . "\n\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t" . '<div class="media align-items-center">' . "\n\t\t\t\t\t\t" . '<div class="col-9">' . "\n\t\t\t\t\t\t\t" . '<div>' . "\n\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1 text-truncate">No Results Found</h3>' . "\n\t\t\t\t\t\t\t\t" . "<p class=\"text-lighter mb-1\"><small>Try refining your search or manually locating the content you're looking for.</small></p>" . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '<div class="col-3">' . "\n\t\t\t\t\t\t\t" . '<div class="float-right text-center search-icon-xl mt-1" style="font-size: 72px;"><i class="fe-alert-circle"></i></div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>';
																														$a85e1b7d42c346a0['items'][] = array('id' => 'no_results', 'url' => null, 'text' => 'No Results', 'html' => $Aec1063e97236589);
																													}

																													echo json_encode($a85e1b7d42c346a0, JSON_PARTIAL_OUTPUT_ON_ERROR);

																													exit();
																												}

																												if (XUI::$rRequest['action'] == 'delete_recording') {
																													if (AACD47d8157a1a09('adv', 'edit_movie')) {
																														if (!(isset(XUI::$rRequest['id']) && 0 < intval(XUI::$rRequest['id']))) {
																															echo json_encode(array('result' => false));

																															exit();
																														}

																														deleteRecording(XUI::$rRequest['id']);
																														echo json_encode(array('result' => true));

																														exit();
																													}

																													echo json_encode(array('result' => false));

																													exit();
																												}

																												if (XUI::$rRequest['action'] == 'clear_failures') {
																													if (aACD47d8157a1a09('adv', 'streams')) {
																														if (!(isset(XUI::$rRequest['id']) && 0 < intval(XUI::$rRequest['id']))) {
																															echo json_encode(array('result' => false));

																															exit();
																														}

																														$Fee0d5a474c96306->query('DELETE FROM `streams_logs` WHERE `stream_id` = ?;', XUI::$rRequest['id']);
																														echo json_encode(array('result' => true));

																														exit();
																													}

																													echo json_encode(array('result' => false));

																													exit();
																												}

																												if (XUI::$rRequest['action'] != 'multi') {
																												} else {
																													$E379394c7b1a273f = XUI::$rRequest['type'];
																													$B8406498f9eccb3c = json_decode(XUI::$rRequest['ids'], true);
																													$b4cd770ed1b094fe = XUI::$rRequest['sub'];

																													if (count($B8406498f9eccb3c) != 0) {
																														switch ($E379394c7b1a273f) {
																															case 'line':
																																if (aAcD47D8157a1a09('adv', 'edit_line')) {
																																	if ($b4cd770ed1b094fe == 'delete') {
																																		deleteLines($B8406498f9eccb3c);
																																	} else {
																																		if ($b4cd770ed1b094fe == 'enable') {
																																			$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 1 WHERE `id`IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																			XUI::updateLines($B8406498f9eccb3c);
																																		} else {
																																			if ($b4cd770ed1b094fe == 'disable') {
																																				$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																				XUI::updateLines($B8406498f9eccb3c);
																																			} else {
																																				if ($b4cd770ed1b094fe == 'ban') {
																																					$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																					XUI::updateLines($B8406498f9eccb3c);
																																				} else {
																																					if ($b4cd770ed1b094fe == 'unban') {
																																						$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																						XUI::updateLines($B8406498f9eccb3c);
																																					} else {
																																						if ($b4cd770ed1b094fe != 'purge') {
																																						} else {
																																							if (XUI::$rSettings['redis_handler']) {
																																								foreach ($B8406498f9eccb3c as $D78ff1d0edade5eb) {
																																									foreach (XUI::D92de48c36cf9438($D78ff1d0edade5eb, null, null, true, false, false) as $e110a2ab6d3a4734) {
																																										XUI::E8E9d6B2B107D8Ae($e110a2ab6d3a4734);
																																									}
																																								}
																																							} else {
																																								$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `user_id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');

																																								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																									XUI::E8e9D6B2B107d8Ae($C740da31596f24ef);
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}

																																	echo json_encode(array('result' => true));

																																	exit();
																																}

																																echo json_encode(array('result' => false));

																																exit();

																															case 'mag':
																															case 'enigma':
																																$d48363bb091686d2 = array('mag' => 'edit_mag', 'enigma2' => 'edit_e2')[$E379394c7b1a273f];

																																if (aAcd47d8157A1A09('adv', $d48363bb091686d2)) {
																																	$b174976b99c4ec48 = array();

																																	if ($E379394c7b1a273f == 'mag') {
																																		$Fee0d5a474c96306->query('SELECT `user_id` FROM `mag_devices` WHERE `mag_id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																	} else {
																																		$Fee0d5a474c96306->query('SELECT `user_id` FROM `enigma2_devices` WHERE `device_id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																	}

																																	foreach ($Fee0d5a474c96306->get_Rows() as $C740da31596f24ef) {
																																		$b174976b99c4ec48[] = $C740da31596f24ef['user_id'];
																																	}

																																	if (0 >= count($b174976b99c4ec48)) {
																																	} else {
																																		if ($b4cd770ed1b094fe == 'delete') {
																																			if ($E379394c7b1a273f == 'mag') {
																																				deleteMAGs($B8406498f9eccb3c);
																																			} else {
																																				deleteEnigmas($B8406498f9eccb3c);
																																			}
																																		} else {
																																			if ($b4cd770ed1b094fe == 'enable') {
																																				$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` IN (' . implode(',', array_map('intval', $b174976b99c4ec48)) . ');');
																																			} else {
																																				if ($b4cd770ed1b094fe == 'disable') {
																																					$Fee0d5a474c96306->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` IN (' . implode(',', array_map('intval', $b174976b99c4ec48)) . ');');
																																				} else {
																																					if ($b4cd770ed1b094fe == 'ban') {
																																						$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` IN (' . implode(',', array_map('intval', $b174976b99c4ec48)) . ');');
																																					} else {
																																						if ($b4cd770ed1b094fe == 'unban') {
																																							$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` IN (' . implode(',', array_map('intval', $b174976b99c4ec48)) . ');');
																																						} else {
																																							if ($b4cd770ed1b094fe == 'purge') {
																																								if (XUI::$rSettings['redis_handler']) {
																																									foreach ($b174976b99c4ec48 as $D78ff1d0edade5eb) {
																																										foreach (XUI::d92De48c36CF9438($D78ff1d0edade5eb, null, null, true, false, false) as $e110a2ab6d3a4734) {
																																											XUI::e8e9d6B2b107d8aE($e110a2ab6d3a4734);
																																										}
																																									}
																																								} else {
																																									$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `user_id` IN (' . implode(',', array_map('intval', $b174976b99c4ec48)) . ');');

																																									foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																										XUI::e8e9D6b2B107D8AE($C740da31596f24ef);
																																									}
																																								}
																																							} else {
																																								if (!($b4cd770ed1b094fe == 'convert' && in_array($E379394c7b1a273f, array('mag', 'enigma')))) {
																																								} else {
																																									foreach ($B8406498f9eccb3c as $Bcb41d44b619234f) {
																																										if ($E379394c7b1a273f == 'mag') {
																																											D8974B51B74C80ee($Bcb41d44b619234f, false, false, true);
																																										} else {
																																											A8Cd7C1DF629a648($Bcb41d44b619234f, false, false, true);
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}

																																		XUI::updateLines($b174976b99c4ec48);
																																	}

																																	echo json_encode(array('result' => true));

																																	exit();
																																} else {
																																	echo json_encode(array('result' => false));

																																	exit();
																																}

																																// no break
																															case 'user':
																																if (AACd47D8157a1A09('adv', 'edit_reguser')) {
																																	if ($b4cd770ed1b094fe == 'enable') {
																																		$Fee0d5a474c96306->query('UPDATE `users` SET `status` = 1 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																	} else {
																																		if ($b4cd770ed1b094fe == 'disable') {
																																			$Fee0d5a474c96306->query('UPDATE `users` SET `status` = 0 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																		} else {
																																			if ($b4cd770ed1b094fe != 'delete') {
																																			} else {
																																				deleteUsers($B8406498f9eccb3c);
																																			}
																																		}
																																	}

																																	echo json_encode(array('result' => true));

																																	exit();
																																}

																																echo json_encode(array('result' => false));

																																exit();

																															case 'server':
																															case 'proxy':
																																if (Aacd47D8157a1a09('adv', 'edit_server')) {
																																	if ($E379394c7b1a273f == 'server' && in_array($b4cd770ed1b094fe, array('restart', 'start', 'stop'))) {
																																		$F36bea2698ecb4fa = array();

																																		if ($b4cd770ed1b094fe == 'start') {
																																			$Fee0d5a474c96306->query('SELECT `server_id`, `stream_id` FROM `streams_servers` WHERE `server_id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ') AND `on_demand` = 0;');
																																		} else {
																																			$Fee0d5a474c96306->query('SELECT `server_id`, `stream_id` FROM `streams_servers` WHERE `server_id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ') AND `on_demand` = 0 AND `monitor_pid` IS NOT NULL AND `monitor_pid` > 0;');
																																		}

																																		if (0 >= $Fee0d5a474c96306->num_rows()) {
																																		} else {
																																			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																				$F36bea2698ecb4fa[intval($C740da31596f24ef['server_id'])][] = intval($C740da31596f24ef['stream_id']);
																																			}
																																		}

																																		if (0 >= count($F36bea2698ecb4fa)) {
																																		} else {
																																			foreach ($F36bea2698ecb4fa as $d58b4f8653a391d8 => $Cdb85875fd50f459) {
																																				if ($b4cd770ed1b094fe == 'stop') {
																																					E36EC1583E223bf6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => $Cdb85875fd50f459, 'servers' => array($d58b4f8653a391d8)));
																																				} else {
																																					e36eC1583e223bF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => $Cdb85875fd50f459, 'servers' => array($d58b4f8653a391d8)));
																																				}
																																			}
																																		}
																																	} else {
																																		if ($b4cd770ed1b094fe == 'purge') {
																																			foreach ($B8406498f9eccb3c as $d58b4f8653a391d8) {
																																				if (XUI::$rSettings['redis_handler']) {
																																					if ($E379394c7b1a273f == 'proxy') {
																																						foreach (XUI::$rServers[$d58b4f8653a391d8]['parent_id'] as $fcae8575b94f8564) {
																																							foreach (XUI::d92dE48C36CF9438(null, $fcae8575b94f8564, null, true, false, false) as $e110a2ab6d3a4734) {
																																								if ($e110a2ab6d3a4734['proxy_id'] != $d58b4f8653a391d8) {
																																								} else {
																																									XUI::E8e9D6B2B107D8aE($e110a2ab6d3a4734);
																																								}
																																							}
																																						}
																																					} else {
																																						foreach (XUI::d92dE48C36Cf9438(null, $d58b4f8653a391d8, null, true, false, false) as $e110a2ab6d3a4734) {
																																							XUI::e8E9D6b2B107D8AE($e110a2ab6d3a4734);
																																						}
																																					}
																																				} else {
																																					if ($E379394c7b1a273f == 'proxy') {
																																						$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `proxy_id` = ?;', $d58b4f8653a391d8);
																																					} else {
																																						$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `server_id` = ?;', $d58b4f8653a391d8);
																																					}

																																					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																						XUI::e8e9d6b2B107D8Ae($C740da31596f24ef);
																																					}
																																				}
																																			}
																																		} else {
																																			if ($b4cd770ed1b094fe == 'enable') {
																																				$Fee0d5a474c96306->query('UPDATE `servers` SET `enabled` = 1 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																			} else {
																																				if ($b4cd770ed1b094fe == 'disable') {
																																					$Fee0d5a474c96306->query('UPDATE `servers` SET `enabled` = 0 WHERE `is_main` = 0 AND `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																				} else {
																																					if ($b4cd770ed1b094fe == 'enable_proxy' && $E379394c7b1a273f == 'server') {
																																						$Fee0d5a474c96306->query('UPDATE `servers` SET `enable_proxy` = 1 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																					} else {
																																						if ($b4cd770ed1b094fe == 'disable_proxy' && $E379394c7b1a273f == 'server') {
																																							$Fee0d5a474c96306->query('UPDATE `servers` SET `enable_proxy` = 0 WHERE `id` IN (' . implode(',', array_map('intval', $B8406498f9eccb3c)) . ');');
																																						} else {
																																							foreach ($B8406498f9eccb3c as $d58b4f8653a391d8) {
																																								if ($a8bb73cba48fb7f6[$d58b4f8653a391d8]['is_main'] != 0) {
																																								} else {
																																									C234AE70b52D65A2($d58b4f8653a391d8);
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}

																																	echo json_encode(array('result' => true));

																																	exit();
																																}

																																echo json_encode(array('result' => false));

																																exit();

																															case 'series':
																																if ($b4cd770ed1b094fe != 'delete') {
																																} else {
																																	deleteSeriesMass($B8406498f9eccb3c);
																																}

																																echo json_encode(array('result' => true));

																																exit();

																															case 'stream':
																															case 'movie':
																															case 'episode':
																															case 'cchannel':
																															case 'radio':
																																if (Aacd47d8157A1a09('adv', 'edit_' . $E379394c7b1a273f)) {
																																	$ff3d5388a00f03dd = $F36bea2698ecb4fa = array();

																																	foreach ($B8406498f9eccb3c as $f523e362fb81d6c8) {
																																		list($F26087d31c2bbe4d, $d58b4f8653a391d8) = explode('-', $f523e362fb81d6c8);

																																		if (!$d58b4f8653a391d8) {
																																			$ff3d5388a00f03dd[] = $F26087d31c2bbe4d;
																																		} else {
																																			$F36bea2698ecb4fa[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
																																		}
																																	}
																																	$E736d0266164be61 = $d0cacd2fc6769361 = array();

																																	if (0 >= count($ff3d5388a00f03dd)) {
																																	} else {
																																		$Fee0d5a474c96306->query('SELECT `stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $ff3d5388a00f03dd)) . ');');

																																		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																			$F36bea2698ecb4fa[intval($C740da31596f24ef['server_id'])][] = intval($C740da31596f24ef['stream_id']);

																																			if (in_array(intval($C740da31596f24ef['stream_id']), $d0cacd2fc6769361)) {
																																			} else {
																																				$d0cacd2fc6769361[] = intval($C740da31596f24ef['stream_id']);
																																			}
																																		}
																																	}

																																	foreach ($ff3d5388a00f03dd as $F26087d31c2bbe4d) {
																																		if (in_array($F26087d31c2bbe4d, $d0cacd2fc6769361)) {
																																		} else {
																																			$E736d0266164be61[] = $F26087d31c2bbe4d;
																																		}
																																	}

																																	if (!(0 < count($F36bea2698ecb4fa) || $b4cd770ed1b094fe == 'delete' && 0 < count($E736d0266164be61))) {
																																	} else {
																																		if (in_array($b4cd770ed1b094fe, array('start', 'stop', 'restart'))) {
																																			if ($b4cd770ed1b094fe != 'restart') {
																																			} else {
																																				$b4cd770ed1b094fe = 'start';
																																			}

																																			foreach ($F36bea2698ecb4fa as $d58b4f8653a391d8 => $Cdb85875fd50f459) {
																																				if (in_array($E379394c7b1a273f, array('stream', 'radio', 'cchannel'))) {
																																					e36ec1583e223BF6(array('action' => 'stream', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => $Cdb85875fd50f459, 'servers' => array($d58b4f8653a391d8)));
																																				} else {
																																					E36EC1583e223bf6(array('action' => 'vod', 'sub' => $b4cd770ed1b094fe, 'stream_ids' => $Cdb85875fd50f459, 'servers' => array($d58b4f8653a391d8)));
																																				}
																																			}
																																		} else {
																																			if ($b4cd770ed1b094fe == 'delete') {
																																				if (0 >= count($F36bea2698ecb4fa)) {
																																				} else {
																																					foreach ($F36bea2698ecb4fa as $d58b4f8653a391d8 => $Cdb85875fd50f459) {
																																						deleteStreamsByServer($Cdb85875fd50f459, $d58b4f8653a391d8, $Ab3c1ec7e2add5a3 = true);
																																					}
																																				}

																																				if (0 >= count($E736d0266164be61)) {
																																				} else {
																																					deleteStreams($E736d0266164be61, true);
																																				}
																																			} else {
																																				if ($b4cd770ed1b094fe != 'purge') {
																																				} else {
																																					foreach ($F36bea2698ecb4fa as $d58b4f8653a391d8 => $Cdb85875fd50f459) {
																																						if (XUI::$rSettings['redis_handler']) {
																																							foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
																																								foreach (XUI::D92dE48C36cf9438(null, $d58b4f8653a391d8, $F26087d31c2bbe4d, true, false, false) as $e110a2ab6d3a4734) {
																																									XUI::e8E9D6B2b107d8aE($e110a2ab6d3a4734);
																																								}
																																							}
																																						} else {
																																							$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `server_id` = ? AND `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');', $d58b4f8653a391d8);

																																							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
																																								XUI::E8E9D6b2B107d8ae($C740da31596f24ef);
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}

																																	echo json_encode(array('result' => true));

																																	exit();
																																} else {
																																	echo json_encode(array('result' => false));

																																	exit();
																																}

																																// no break
																															default:
																																break;
																														}
																													} else {
																														echo json_encode(array('result' => false));

																														exit();
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	echo json_encode(array('result' => false));
} else {
	echo json_encode(array('result' => false, 'error' => 'Not logged in'));

	exit();
}
