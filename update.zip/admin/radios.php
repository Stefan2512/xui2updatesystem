<?php

include 'session.php';
include 'functions.php';

if (b1882DF698B44754()) {
} else {
	b46f5dD76f3c7421();
}

$A5dcdeb6ecbbf6bd = cBe87e2A9A996111('radio');
$bcf587bb39f95fd5 = 'Radio Stations';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Radio Stations</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <input type="text" class="form-control" id="station_search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="Search Stations...">' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-3">' . "\n" . '                                <select id="station_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value="" selected>';
echo $_['all_servers'];
echo '</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == -1)) {
} else {
	echo ' selected';
}

echo '>No Servers</option>' . "\n" . '                                    ';

foreach (f6Da964066F2F5E4() as $e81220b4451f37c9) {
	echo '                                    <option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-3">' . "\n" . '                                <select id="station_category_id" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value="" selected>';
echo $_['all_categories'];
echo '</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == -1)) {
} else {
	echo ' selected';
}

echo '>No Categories</option>' . "\n" . '                                    ';

foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
	echo '                                    <option value="';
	echo $A1925ae53e9307eb['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $A1925ae53e9307eb['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="station_filter" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['filter'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['no_filter'];
echo '</option>' . "\n" . '                                    <option value="1"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 1)) {
} else {
	echo ' selected';
}

echo '>Online</option>' . "\n" . '                                    <option value="2"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 2)) {
} else {
	echo ' selected';
}

echo '>Down</option>' . "\n" . '                                    <option value="3"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 3)) {
} else {
	echo ' selected';
}

echo '>Stopped</option>' . "\n" . '                                    <option value="4"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 4)) {
} else {
	echo ' selected';
}

echo '>Starting</option>' . "\n" . '                                    <option value="5"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 5)) {
} else {
	echo ' selected';
}

echo '>On Demand</option>' . "\n" . '                                    <option value="6"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 6)) {
} else {
	echo ' selected';
}

echo '>Direct</option>' . "\n" . '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <label class="col-md-1 col-form-label text-center" for="station_show_entries">Show</label>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="station_show_entries" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo '                                    <option';

	if (isset(XUI::$rRequest['entries'])) {
		if (XUI::$rRequest['entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	} else {
		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n\t\t\t\t\t\t" . '<table id="datatable-streampage" class="table table-striped table-borderless dt-responsive nowrap font-normal">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                    <th class="text-center">Icon</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Name</th>' . "\n\t\t\t\t\t\t\t\t\t";

if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
	echo "\t\t\t\t\t\t\t\t\t" . '<th>';
	echo $_['servers'];
	echo '</th>' . "\n" . '                                    ';
} else {
	echo '                                    <th>';
	echo $_['server'];
	echo '</th>' . "\n\t\t\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Clients</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Uptime</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Stream Info</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
