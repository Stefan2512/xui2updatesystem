<?php

include 'session.php';
include 'functions.php';

if (B1882DF698b44754()) {
} else {
	b46F5DD76f3c7421();
}

$bcf587bb39f95fd5 = 'EPG Files';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['epgs'];
echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'EPG has been added and will be scanned during the next cron run.' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['epg_name'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['source'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['days_to_keep'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['last_updated'];
echo '</th>' . "\n" . '                                    <th class="text-center">Channels</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach (Baea42B3F8e1780c() as $d8a1409105424710) {
	echo "\t\t\t\t\t\t\t\t" . '<tr id="epg-';
	echo $d8a1409105424710['id'];
	echo '">' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo $d8a1409105424710['id'];
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo $d8a1409105424710['epg_name'];
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo parse_url($d8a1409105424710['epg_file'])['host'];
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">';
	echo $d8a1409105424710['days_keep'];
	echo '</button></td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';

	if ($d8a1409105424710['last_updated']) {
		echo date('Y-m-d H:i', $d8a1409105424710['last_updated']);
	} else {
		echo $_['never'];
	}

	echo '</td>' . "\n" . '                                    <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">';
	echo number_format(count(json_decode($d8a1409105424710['data'], true)), 0);
	echo '</button></td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t\t";

	if (aaCd47d8157A1a09('adv', 'epg_edit')) {
		echo "\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./epg?id=';
		echo $d8a1409105424710['id'];
		echo '"><button type="button" title="';
		echo $_['edit_epg'];
		echo '" class="tooltip btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-pencil-outline"></i></button></a>' . "\n" . '                                            <button type="button" title="Force Reload" class="tooltip btn btn-light waves-effect waves-light btn-xs" onClick="api(';
		echo $d8a1409105424710['id'];
		echo ", 'reload');\"><i class=\"mdi mdi-refresh\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="';
		echo $_['delete_epg'];
		echo '" class="tooltip btn btn-light waves-effect waves-light btn-xs" onClick="api(';
		echo $d8a1409105424710['id'];
		echo ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t";
	} else {
		echo '--';
	}

	echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n" . '    </div>' . "\n" . '</div>' . "\n";
include 'footer.php';
