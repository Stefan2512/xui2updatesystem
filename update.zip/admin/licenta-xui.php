<?php

include 'session.php';
include 'functions.php';

if (b1882df698b44754()) {
} else {
	b46F5Dd76f3C7421();
}

if (isset($_POST['update_license'])) {
	$Affa53fde645e67d = Xui\Functions::updateLicense('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', intval($_SERVER['SERVER_PORT']));
	$d205bd8d1407bcb1 = Xui\Functions::getLicense();
	$Bffbfc5f18488241 = Xui\Functions::checkReissues('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
	$Fee0d5a474c96306->query('UPDATE `settings` SET `reissues` = ?', json_encode($Bffbfc5f18488241));
} else {
	if (!isset($_POST['update_xui'])) {
	} else {
		$Fee0d5a474c96306->query('DELETE FROM `signals` WHERE `server_id` = ? AND `custom_data` = ?;', SERVER_ID, json_encode(array('action' => 'update')));
		$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', SERVER_ID, time(), json_encode(array('action' => 'update')));
		$a8bb73cba48fb7f6[SERVER_ID]['status'] = 5;
	}
}

if (isset($Bffbfc5f18488241)) {
} else {
	$Bffbfc5f18488241 = (json_decode(XUI::$rSettings['reissues'], true) ?: array());
}

$bcf587bb39f95fd5 = 'Informatii Licenta';
include 'header.php';
echo '<div class="wrapper boxed-layout"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">Informatii Licenta</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t\t" . '<div class="row">' . "\r\n" . '            <div class="col-xl-12">' . "\r\n" . '                ';

if (isset($Affa53fde645e67d)) {
	if ($Affa53fde645e67d['status']) {
		echo '                 d' . "\r\n" . '                    A new license has been generated and your details have been updated.' . "\r\n" . '                </div>' . "\r\n" . '                ';
	} else {
		echo '                <div class="alert alert-danger mb-4" role="alert">' . "\r\n" . '                    A new license could not be generated, please raise a ticket if you think this is an error.' . "\r\n" . '                </div>' . "\r\n" . '                ';
	}
} else {
	if (time() < $d205bd8d1407bcb1[3] && $d205bd8d1407bcb1[3] - time() < 604800) {
		echo '                <div class="alert alert-warning mb-4" role="alert">' . "\r\n" . '                    Your license expires in ';
		echo(86400 < $d205bd8d1407bcb1[3] - time() ? intval(($d205bd8d1407bcb1[3] - time()) / 86400) . ' days' : intval(($d205bd8d1407bcb1[3] - time()) / 3600) . ' hours');
		echo '.' . "\r\n" . '                </div>' . "\r\n" . '                ';
	} else {
		if (!($d205bd8d1407bcb1[3] < time() && time() <= $d205bd8d1407bcb1[4])) {
		} else {
			echo '                <div class="alert alert-danger mb-4" role="alert">' . "\r\n" . '                    Your license has expired! XUI will shut down in ';
			echo(86400 < $d205bd8d1407bcb1[4] - time() ? intval(($d205bd8d1407bcb1[4] - time()) / 86400) . ' days' : intval(($d205bd8d1407bcb1[4] - time()) / 3600) . ' hours');
			echo '.' . "\r\n" . '                </div>' . "\r\n" . '                ';
		}
	}
}

if (!$F9bec54f0f809272) {
} else {
	echo '                <div class="alert alert-info mb-4" role="alert">' . "\r\n" . '                    ';

	if ($a8bb73cba48fb7f6[SERVER_ID]['status'] == 5) {
		echo '                    XUI is currently waiting to be updated... Your server will become unavailable once the process begins.' . "\r\n" . '                    ';
	} else {
		echo '                    XUI v';
		echo $F2d4d8f7981ac574['update_version'];
		echo " is available for download now! Click the update button below when you're ready to update your main server, the process won't take long however the server will go offline while the update is in progress.<br/><br/>" . "\r\n" . '                    ';

		if ($F2d4d8f7981ac574['auto_update_lb']) {
			echo '                    Your load balancers and proxies will automatically update once the main server has updated.' . "\r\n" . '                    ';
		} else {
			echo '                    Your load balancers and proxies can be manually updated by clicking the Download icon next to them.' . "\r\n" . '                    ';
		}
	}

	echo '                </div>' . "\r\n" . '                ';
}

if (0 < $Bffbfc5f18488241['max'] && $Bffbfc5f18488241['max'] <= $Bffbfc5f18488241['reissues']) {
	echo '                <div class="alert alert-danger mb-4" role="alert">' . "\r\n" . "                    You've used all of your license reissues, if you attempt to move the license to a new server or reinstall this server and re-license it, you will be met with an error and will be unable to do so.</br><br/>Please raise a ticket on the Billing Panel in order to get the reissues for your license reset." . "\r\n" . '                </div>' . "\r\n" . '                ';
} else {
	if (!(0 < $Bffbfc5f18488241['max'] && $Bffbfc5f18488241['reissues'] == $Bffbfc5f18488241['max'] - 1)) {
	} else {
		echo '                <div class="alert alert-warning mb-4" role="alert">' . "\r\n" . "                    You've almost used all of your license reissues, you can only move this license to one more server.</br><br/>Please raise a ticket on the Billing Panel in order to get the reissues for your license reset." . "\r\n" . '                </div>' . "\r\n" . '                ';
	}
}

echo '                <div class="card-box">' . "\r\n" . '                    <form action="./license_info" method="POST" data-parsley-validate="">' . "\r\n" . '                        <div class="row">' . "\r\n" . '                            <div class="col-12">' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-3 col-form-label" for="whmcs_license">WHMCS License</label>' . "\r\n" . '                                    <div class="col-md-3">' . "\r\n" . '                                        <input type="text" class="form-control text-center" id="whmcs_license" name="whmcs_license" maxlength="16" value="XUI-ONE Media PRO ';

echo '" readonly>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <label class="col-md-3 col-form-label" for="whmcs_account">WHMCS Account</label>' . "\r\n" . '                                    <div class="col-md-3">' . "\r\n" . '                                        <input id="whmcs_account" type="text" class="form-control text-center"  value="IPTV-Media-PRO ';

echo '" readonly>' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-3 col-form-label" for="server_ip">Licensed Server IP</label>' . "\r\n" . '                                    <div class="col-md-3">' . "\r\n" . '                                        <input id="server_ip" type="text" class="form-control text-center" value="144.76.137.178 ';

echo '" readonly>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <label class="col-md-3 col-form-label" for="expiration_date">Expiration Date</label>' . "\r\n" . '                                    <div class="col-md-3">' . "\r\n" . '                                        <input id="expiration_date" type="text" class="form-control text-center" value="';
echo date(XUI::$rSettings['datetime_format'], $d205bd8d1407bcb1[3]);
echo '" readonly>' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-3 col-form-label" for="max_reissues">Max Reissues</label>' . "\r\n" . '                                    <div class="col-md-3">' . "\r\n" . '                                        <input id="max_reissues" type="text" class="form-control text-center" value="128';
echo $Bffbfc5f18488241['max'];
echo '" readonly>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <label class="col-md-3 col-form-label" for="current_reissues">Current Reissues</label>' . "\r\n" . '                                    <div class="col-md-3">' . "\r\n" . '                                        <input id="current_reissues" type="text" class="form-control text-center" value="9';
echo $Bffbfc5f18488241['reissues'];
echo '" readonly>' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                ';

if (0 >= count($Bffbfc5f18488241['log'])) {
} else {
	echo '                                <table class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n" . '                                    <thead>' . "\r\n" . '                                        <tr>' . "\r\n" . '                                            <th class="text-center">#</th>' . "\r\n" . '                                            <th class="text-center">IP Address</th>' . "\r\n" . '                                            <th class="text-center">MAC Address</th>' . "\r\n" . '                                            <th class="text-center">Issue Date</th>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                    </thead>' . "\r\n" . '                                    <tbody>' . "\r\n" . '                                        ';
	$Ea22c4a9ab5b2176 = count($Bffbfc5f18488241['log']) + 1;

	foreach ($Bffbfc5f18488241['log'] as $bb2621204e39e62d) {
		$Ea22c4a9ab5b2176--;
		echo '                                        <tr>' . "\r\n" . '                                            <td class="text-center">';
		echo $Ea22c4a9ab5b2176;
		echo '</td>' . "\r\n" . '                                            <td class="text-center">';
		echo htmlentities($bb2621204e39e62d['ip']);
		echo '</td>' . "\r\n" . '                                            <td class="text-center">';
		echo htmlentities($bb2621204e39e62d['mac']);
		echo '</td>' . "\r\n" . '                                            <td class="text-center">';
		echo date(XUI::$rSettings['datetime_format'], $bb2621204e39e62d['date']);
		echo '</td>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                        ';
	}
	echo '                                    </tbody>' . "\r\n" . '                                </table>' . "\r\n" . '                                ';
}

echo '                            </div>' . "\r\n" . '                        </div> ' . "\r\n" . '                        <ul class="list-inline wizard mb-4">' . "\r\n" . '                            <li class="list-inline-item float-right">' . "\r\n" . '                                <input name="update_license" type="submit" class="btn btn-primary" value="Verifica Licenta" />' . "\r\n" . '                                ';

if (!($F9bec54f0f809272 && $a8bb73cba48fb7f6[SERVER_ID]['status'] != 5)) {
} else {
	echo '                                <input name="update_xui" type="submit" class="btn btn-info" value="Update XUI" />' . "\r\n" . '                                ';
}

echo '                            </li>' . "\r\n" . '                        </ul>' . "\r\n" . '                    </form>' . "\r\n" . '                </div>' . "\r\n" . '            </div> ' . "\r\n" . '        </div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
