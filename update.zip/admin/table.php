<?php

session_start();
session_write_close();

if (file_exists('../www/init.php')) {
	require_once '../www/init.php';
} else {
	require_once '../../../www/init.php';
}

if (PHP_ERRORS) {
} else {
	if (!(empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest')) {
	} else {
		exit();
	}
}

$a85e1b7d42c346a0 = array('draw' => intval(XUI::$rRequest['draw']), 'recordsTotal' => 0, 'recordsFiltered' => 0, 'data' => array());
$B3f0f4a134021073 = false;

if (isset(XUI::$rRequest['api_key'])) {
	$a85e1b7d42c346a0 = array('status' => 'STATUS_SUCCESS', 'data' => array());
	$Fee0d5a474c96306->query('SELECT `id` FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `api_key` = ? AND LENGTH(`api_key`) > 0 AND `is_admin` = 1 AND `status` = 1;', XUI::$rRequest['api_key']);

	if ($Fee0d5a474c96306->num_rows() != 0) {
		$D78ff1d0edade5eb = $Fee0d5a474c96306->get_row()['id'];
		$B3f0f4a134021073 = true;
		require_once XUI_HOME . 'includes/admin.php';
		$D4253f9520627819 = fe76c4BCAf81baa4($D78ff1d0edade5eb);
		$B2ff75c438fb3031 = F0acf9dE3389B116($D4253f9520627819['member_group_id']);
		$B2ff75c438fb3031['advanced'] = json_decode($B2ff75c438fb3031['allowed_pages'], true);

		if (0 >= strlen($D4253f9520627819['timezone'])) {
		} else {
			date_default_timezone_set($D4253f9520627819['timezone']);
		}
	} else {
		echo json_encode(array('status' => 'STATUS_FAILURE', 'error' => 'Invalid API key.'));

		exit();
	}
} else {
	if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1' && isset(XUI::$rRequest['api_user_id'])) {
		$B3f0f4a134021073 = true;
		require_once XUI_HOME . 'includes/admin.php';
		$D4253f9520627819 = fe76c4Bcaf81Baa4(XUI::$rRequest['api_user_id']);
		$B2ff75c438fb3031 = F0ACf9DE3389b116($D4253f9520627819['member_group_id']);
		$B2ff75c438fb3031['advanced'] = json_decode($B2ff75c438fb3031['allowed_pages'], true);

		if (0 >= strlen($D4253f9520627819['timezone'])) {
		} else {
			date_default_timezone_set($D4253f9520627819['timezone']);
		}
	} else {
		if (isset($_SESSION['hash'])) {
			include 'functions.php';
		} else {
			echo json_encode($a85e1b7d42c346a0);

			exit();
		}
	}
}

if (!$F61f585ee1fe12b7) {
} else {
	XUI::$rSettings['modal_edit'] = false;
	XUI::$rSettings['group_buttons'] = false;
}

$E379394c7b1a273f = XUI::$rRequest['id'];
$D031c48a1422c07e = intval(XUI::$rRequest['start']);
$E400a3101514583e = intval(XUI::$rRequest['length']);

if (!(1000 < $E400a3101514583e || $E400a3101514583e <= 0) || $B3f0f4a134021073) {
} else {
	$E400a3101514583e = 1000;
}

if (!XUI::$rSettings['redis_handler']) {
} else {
	XUI::bfA8b6fE314ded7f();
}

if ($E379394c7b1a273f == 'lines') {
	if (AaCD47d8157A1a09('adv', 'users') || aACD47d8157A1A09('adv', 'mass_edit_users')) {
		$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
		$c6c389b9adf3a40c = array('`lines`.`id`', '`lines`.`username`', '`lines`.`password`', '`lines`.`member_id`', '`lines`.`enabled` - `lines`.`admin_enabled`', '`active_connections` > 0', '`lines`.`is_trial`', '`lines`.`is_restreamer`', '`active_connections`', '`lines`.`max_connections`', '`lines`.`exp_date`', '`active_connections` ' . $cb10faf5ade31619 . ', `last_activity`', false);

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
		$f86e19bdb1e7dae8[] = '(`is_mag` + `is_e2`) = 0';

		if (0 >= strlen(XUI::$rRequest['search']['value'])) {
		} else {
			foreach (range(1, 6) as $b6f0b24a56fe41b6) {
				$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
			}
			$f86e19bdb1e7dae8[] = '(`lines`.`username` LIKE ? OR `lines`.`password` LIKE ? OR FROM_UNIXTIME(`exp_date`) LIKE ? OR `lines`.`max_connections` LIKE ? OR `lines`.`reseller_notes` LIKE ? OR `lines`.`admin_notes` LIKE ?)';
		}

		if (0 >= strlen(XUI::$rRequest['filter'])) {
		} else {
			if (XUI::$rRequest['filter'] == 1) {
				$f86e19bdb1e7dae8[] = '(`lines`.`admin_enabled` = 1 AND `lines`.`enabled` = 1 AND (`lines`.`exp_date` IS NULL OR `lines`.`exp_date` > UNIX_TIMESTAMP()))';
			} else {
				if (XUI::$rRequest['filter'] == 2) {
					$f86e19bdb1e7dae8[] = '`lines`.`enabled` = 0';
				} else {
					if (XUI::$rRequest['filter'] == 3) {
						$f86e19bdb1e7dae8[] = '`lines`.`admin_enabled` = 0';
					} else {
						if (XUI::$rRequest['filter'] == 4) {
							$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` <= UNIX_TIMESTAMP())';
						} else {
							if (XUI::$rRequest['filter'] == 5) {
								$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
							} else {
								if (XUI::$rRequest['filter'] == 6) {
									$f86e19bdb1e7dae8[] = '`lines`.`is_restreamer` = 1';
								} else {
									if (XUI::$rRequest['filter'] == 7) {
										$f86e19bdb1e7dae8[] = '`lines`.`is_stalker` = 1';
									} else {
										if (XUI::$rRequest['filter'] != 8) {
										} else {
											$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` > UNIX_TIMESTAMP() AND `lines`.`exp_date` <= (UNIX_TIMESTAMP() + (86400*14)))';
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (0 >= strlen(XUI::$rRequest['reseller'])) {
		} else {
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		$Fc3bbe383da3a3f3 = 'SELECT COUNT(`id`) AS `count` FROM `lines` ' . $ff9d21c7a9d310b1 . ';';

		if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
		} else {
			$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
		}

		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			$A6d7047f2fda966c = 'SELECT `lines`.`id`, `lines`.`member_id`, `lines`.`last_activity`, `lines`.`last_activity_array`, `lines`.`username`, `lines`.`password`, `lines`.`exp_date`, `lines`.`admin_enabled`, `lines`.`is_restreamer`, `lines`.`enabled`, `lines`.`admin_notes`, `lines`.`reseller_notes`, `lines`.`max_connections`, `lines`.`is_trial`, (SELECT COUNT(*) AS `active_connections` FROM `lines_live` WHERE `user_id` = `lines`.`id` AND `hls_end` = 0) AS `active_connections` FROM `lines` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$c189216dc4083b79 = $a4dd92d2bc66e08d = $Cde0ba71e2c62c4c = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					$Cde0ba71e2c62c4c[] = intval($C740da31596f24ef['id']);
					$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])] = array('owner_name' => null, 'stream_display_name' => null, 'stream_id' => null, 'last_active' => null);

					if ($E5ae9288fdfb3b75 = json_decode($C740da31596f24ef['last_activity_array'], true)) {
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['stream_id'] = $E5ae9288fdfb3b75['stream_id'];
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['last_active'] = $E5ae9288fdfb3b75['date_end'];
					} else {
						if (!$C740da31596f24ef['last_activity']) {
						} else {
							$c189216dc4083b79[] = intval($C740da31596f24ef['last_activity']);
						}
					}
				}

				if (0 >= count($Cde0ba71e2c62c4c)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `users`.`username`, `lines`.`id` FROM `users` LEFT JOIN `lines` ON `lines`.`member_id` = `users`.`id` WHERE `lines`.`id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$a4dd92d2bc66e08d[$C740da31596f24ef['id']]['owner_name'] = $C740da31596f24ef['username'];
					}

					if (XUI::$rSettings['redis_handler']) {
						$bde5957fb5fa9547 = XUI::De78b5e00a0718d6($Cde0ba71e2c62c4c, true);
						$C7dc44e2b269673a = XUI::getFirstConnection($Cde0ba71e2c62c4c);
						$Cdb85875fd50f459 = array();

						foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
							if (in_array($e110a2ab6d3a4734['stream_id'], $Cdb85875fd50f459)) {
							} else {
								$Cdb85875fd50f459[] = intval($e110a2ab6d3a4734['stream_id']);
							}
						}
						$F36bea2698ecb4fa = array();

						if (0 >= count($Cdb85875fd50f459)) {
						} else {
							$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F36bea2698ecb4fa[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
							}
						}

						foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_display_name'] = $F36bea2698ecb4fa[$e110a2ab6d3a4734['stream_id']];
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_id'] = $e110a2ab6d3a4734['stream_id'];
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['last_active'] = $e110a2ab6d3a4734['date_start'];
						}
						unset($C7dc44e2b269673a);
					} else {
						$Fee0d5a474c96306->query('SELECT `lines_live`.`user_id`, `lines_live`.`stream_id`, `lines_live`.`date_start` AS `last_active`, `streams`.`stream_display_name` FROM `lines_live` LEFT JOIN `streams` ON `streams`.`id` = `lines_live`.`stream_id` INNER JOIN (SELECT `user_id`, MAX(`date_start`) AS `ts` FROM `lines_live` GROUP BY `user_id`) `maxt` ON (`lines_live`.`user_id` = `maxt`.`user_id` AND `lines_live`.`date_start` = `maxt`.`ts`) WHERE `lines_live`.`hls_end` = 0 AND `lines_live`.`user_id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_display_name'] = $C740da31596f24ef['stream_display_name'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
						}
					}
				}

				if (0 >= count($c189216dc4083b79)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `user_id`, `stream_id`, `date_end` AS `last_active` FROM `lines_activity` WHERE `activity_id` IN (' . implode(',', $c189216dc4083b79) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (isset($a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'])) {
						} else {
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
						}
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					$C740da31596f24ef = array_merge($C740da31596f24ef, $a4dd92d2bc66e08d[$C740da31596f24ef['id']]);

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						$C740da31596f24ef['active_connections'] = (isset($bde5957fb5fa9547[$C740da31596f24ef['id']]) ? $bde5957fb5fa9547[$C740da31596f24ef['id']] : 0);
					}

					if (!$B3f0f4a134021073) {
						if (!$C740da31596f24ef['admin_enabled']) {
							$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="Banned"></i>';
						} else {
							if (!$C740da31596f24ef['enabled']) {
								$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
							} else {
								if ($C740da31596f24ef['exp_date'] && $C740da31596f24ef['exp_date'] < time()) {
									$Ba23222f3ed2dc08 = '<i class="text-warning far fa-square tooltip" title="Expired"></i>';
								} else {
									$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square tooltip" title="Active"></i>';
								}
							}
						}

						if (0 < $C740da31596f24ef['active_connections']) {
							$ccf88201f4394db1 = '<i class="text-success fas fa-square"></i>';
						} else {
							$ccf88201f4394db1 = '<i class="text-secondary far fa-square"></i>';
						}

						if ($C740da31596f24ef['is_trial']) {
							$Faa3eac96f7d5cc3 = '<i class="text-warning fas fa-square"></i>';
						} else {
							$Faa3eac96f7d5cc3 = '<i class="text-secondary far fa-square"></i>';
						}

						if ($C740da31596f24ef['is_restreamer']) {
							$Ca6b8df5f3f02b26 = '<i class="text-info fas fa-square"></i>';
						} else {
							$Ca6b8df5f3f02b26 = '<i class="text-secondary far fa-square"></i>';
						}

						if ($C740da31596f24ef['exp_date']) {
							if ($C740da31596f24ef['exp_date'] < time()) {
								$e2b9f3089939b18c = '<span class="expired">' . date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . '<br/><small>' . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small></span>';
							} else {
								$e2b9f3089939b18c = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small>';
							}
						} else {
							$e2b9f3089939b18c = '&infin;';
						}

						if (0 < $C740da31596f24ef['active_connections']) {
							$D893e54c76761cd5 = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['active_connections'] . '</button>';
						} else {
							$D893e54c76761cd5 = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
						}

						if (!(AaCd47D8157a1a09('adv', 'live_connections') && 0 < $C740da31596f24ef['active_connections'])) {
						} else {
							$D893e54c76761cd5 = '<a href="live_connections?user_id=' . $C740da31596f24ef['id'] . '">' . $D893e54c76761cd5 . '</a>';
						}

						if ($C740da31596f24ef['max_connections'] == 0) {
							$B68ac2238b156add = "<button type='button' class='btn btn-dark text-white btn-xs waves-effect waves-light'>&infin;</button>";
						} else {
							$B68ac2238b156add = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>" . $C740da31596f24ef['max_connections'] . '</button>';
						}

						$Fe8647e101f37537 = '';

						if (0 >= strlen($C740da31596f24ef['admin_notes'])) {
						} else {
							$Fe8647e101f37537 .= $C740da31596f24ef['admin_notes'];
						}

						if (0 >= strlen($C740da31596f24ef['reseller_notes'])) {
						} else {
							if (strlen($Fe8647e101f37537) == 0) {
							} else {
								$Fe8647e101f37537 .= "\n";
							}

							$Fe8647e101f37537 .= $C740da31596f24ef['reseller_notes'];
						}

						if (XUI::$rSettings['group_buttons']) {
							$ebab77ef4bee81e0 = '';

							if (0 >= strlen($Fe8647e101f37537)) {
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

							if (!aacD47D8157a1A09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="line?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'line', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['username'])) . "')\" data-modal=\"true\"" : '')) . '>Edit Line</a>';
							}

							if (!(aaCd47D8157a1a09('adv', 'fingerprint') && 0 < $C740da31596f24ef['active_connections'])) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="modalFingerprint(' . $C740da31596f24ef['id'] . ", 'user');\">Fingerprint</a>";
							}

							$ebab77ef4bee81e0 .= "<a class=\"dropdown-item\" href=\"javascript:void(0);\" onClick=\"openDownload('" . $C740da31596f24ef['username'] . "', '" . $C740da31596f24ef['password'] . "');\">Download Playlist</a>";

							if (!aACD47d8157a1a09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'kill');\">Kill Connections</a>";

								if ($C740da31596f24ef['admin_enabled']) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'ban');\">Ban Line</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'unban');\">Unban Line</a>";
								}

								if ($C740da31596f24ef['enabled']) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'disable');\">Disable Line</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'enable');\">Enable Line</a>";
								}

								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\">Delete Line</a>";
							}

							$ebab77ef4bee81e0 .= '</div></div>';
						} else {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if (0 < strlen($Fe8647e101f37537)) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
							}

							if (!AAcd47d8157a1a09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<a href="line?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'line', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['username'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>';
							}

							if (!AACD47d8157A1a09('adv', 'fingerprint')) {
							} else {
								if (0 < $C740da31596f24ef['active_connections']) {
									$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="modalFingerprint(' . $C740da31596f24ef['id'] . ", 'user');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-fingerprint"></i></button>';
								}
							}

							$ebab77ef4bee81e0 .= "<button type=\"button\" title=\"Download Playlist\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"openDownload('" . $C740da31596f24ef['username'] . "', '" . $C740da31596f24ef['password'] . "');\"><i class=\"mdi mdi-download\"></i></button>";

							if (!Aacd47d8157A1a09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'kill');\"><i class=\"fas fa-hammer\"></i></button>";

								if ($C740da31596f24ef['admin_enabled']) {
									$ebab77ef4bee81e0 .= '<button title="Ban" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'ban');\"><i class=\"mdi mdi-power\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Unban" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'unban');\"><i class=\"mdi mdi-power\"></i></button>";
								}

								if ($C740da31596f24ef['enabled']) {
									$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
								}

								$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '</div>';
						}

						if ($C740da31596f24ef['active_connections'] && $C740da31596f24ef['last_active']) {
							$Fc75284164e5b696 = "<a href='stream_view?id=" . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . "</a><br/><small class='text-secondary'>Online: " . XUI::F01c2e2CFC16141e(time() - $C740da31596f24ef['last_active']) . '</small>';
						} else {
							if ($C740da31596f24ef['last_active']) {
								$Fc75284164e5b696 = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['last_active']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['last_active']) . '</small>';
							} else {
								$Fc75284164e5b696 = 'Never';
							}
						}

						if (0 < $C740da31596f24ef['member_id']) {
							$Dbb9e190755fc819 = "<a href='user?id=" . $C740da31596f24ef['member_id'] . "'>" . $C740da31596f24ef['owner_name'] . '</a>';
						} else {
							$Dbb9e190755fc819 = $C740da31596f24ef['owner_name'];
						}

						if (!isset(XUI::$rRequest['no_url'])) {
							$a85e1b7d42c346a0['data'][] = array("<a href='line?id=" . $C740da31596f24ef['id'] . "'>" . $C740da31596f24ef['id'] . '</a>', "<a href='line?id=" . $C740da31596f24ef['id'] . "'>" . $C740da31596f24ef['username'] . '</a>', $C740da31596f24ef['password'], $Dbb9e190755fc819, $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $Ca6b8df5f3f02b26, $D893e54c76761cd5, $B68ac2238b156add, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['username'], $C740da31596f24ef['password'], $C740da31596f24ef['owner_name'], $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $Ca6b8df5f3f02b26, $D893e54c76761cd5, $B68ac2238b156add, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						}
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'mags') {
	if (aacd47D8157a1A09('adv', 'manage_mag')) {
		$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
		$c6c389b9adf3a40c = array('`lines`.`id`', '`lines`.`username`', '`mag_devices`.`mac`', '`mag_devices`.`stb_type`', '`lines`.`member_id`', '`lines`.`enabled`', '`active_connections` > 0', '`lines`.`is_trial`', '`lines`.`exp_date`', '`active_connections` ' . $cb10faf5ade31619 . ', `last_activity`', false);

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

		if (0 >= strlen(XUI::$rRequest['search']['value'])) {
		} else {
			foreach (range(1, 6) as $b6f0b24a56fe41b6) {
				$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
			}
			$f86e19bdb1e7dae8[] = '(`lines`.`username` LIKE ? OR `mag_devices`.`mac` LIKE ? OR `mag_devices`.`stb_type` LIKE ? OR FROM_UNIXTIME(`exp_date`) LIKE ? OR `lines`.`reseller_notes` LIKE ? OR `lines`.`admin_notes` LIKE ?)';
		}

		if (0 >= strlen(XUI::$rRequest['filter'])) {
		} else {
			if (XUI::$rRequest['filter'] == 1) {
				$f86e19bdb1e7dae8[] = '(`lines`.`admin_enabled` = 1 AND `lines`.`enabled` = 1 AND (`lines`.`exp_date` IS NULL OR `lines`.`exp_date` > UNIX_TIMESTAMP()))';
			} else {
				if (XUI::$rRequest['filter'] == 2) {
					$f86e19bdb1e7dae8[] = '`lines`.`enabled` = 0';
				} else {
					if (XUI::$rRequest['filter'] == 3) {
						$f86e19bdb1e7dae8[] = '`lines`.`admin_enabled` = 0';
					} else {
						if (XUI::$rRequest['filter'] == 4) {
							$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` <= UNIX_TIMESTAMP())';
						} else {
							if (XUI::$rRequest['filter'] != 5) {
							} else {
								$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
							}
						}
					}
				}
			}
		}

		if (0 >= strlen(XUI::$rRequest['reseller'])) {
		} else {
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
		} else {
			$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
		}

		$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines` RIGHT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ';';
		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			$A6d7047f2fda966c = 'SELECT `lines`.`id`, `lines`.`username`, `lines`.`member_id`, `lines`.`last_activity`, `lines`.`last_activity_array`, `mag_devices`.`mac`, `mag_devices`.`stb_type`, `mag_devices`.`mag_id`, `lines`.`exp_date`, `lines`.`admin_enabled`, `lines`.`enabled`, `lines`.`admin_notes`, `lines`.`reseller_notes`, `lines`.`max_connections`, `lines`.`is_trial`, (SELECT count(*) FROM `lines_live` WHERE `lines`.`id` = `lines_live`.`user_id` AND `hls_end` = 0) AS `active_connections` FROM `lines` RIGHT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$c189216dc4083b79 = $a4dd92d2bc66e08d = $Cde0ba71e2c62c4c = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!$C740da31596f24ef['id']) {
					} else {
						$Cde0ba71e2c62c4c[] = intval($C740da31596f24ef['id']);
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])] = array('owner_name' => null, 'stream_display_name' => null, 'stream_id' => null, 'last_active' => null);
					}

					if ($E5ae9288fdfb3b75 = json_decode($C740da31596f24ef['last_activity_array'], true)) {
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['stream_id'] = $E5ae9288fdfb3b75['stream_id'];
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['last_active'] = $E5ae9288fdfb3b75['date_end'];
					} else {
						if (!$C740da31596f24ef['last_activity']) {
						} else {
							$c189216dc4083b79[] = intval($C740da31596f24ef['last_activity']);
						}
					}
				}

				if (0 >= count($Cde0ba71e2c62c4c)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `users`.`username`, `lines`.`id` FROM `users` LEFT JOIN `lines` ON `lines`.`member_id` = `users`.`id` WHERE `lines`.`id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$a4dd92d2bc66e08d[$C740da31596f24ef['id']]['owner_name'] = $C740da31596f24ef['username'];
					}

					if (XUI::$rSettings['redis_handler']) {
						$bde5957fb5fa9547 = XUI::DE78b5E00a0718D6($Cde0ba71e2c62c4c, true);
						$C7dc44e2b269673a = XUI::getFirstConnection($Cde0ba71e2c62c4c);
						$Cdb85875fd50f459 = array();

						foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
							if (in_array($e110a2ab6d3a4734['stream_id'], $Cdb85875fd50f459)) {
							} else {
								$Cdb85875fd50f459[] = intval($e110a2ab6d3a4734['stream_id']);
							}
						}
						$F36bea2698ecb4fa = array();

						if (0 >= count($Cdb85875fd50f459)) {
						} else {
							$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F36bea2698ecb4fa[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
							}
						}

						foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_display_name'] = $F36bea2698ecb4fa[$e110a2ab6d3a4734['stream_id']];
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_id'] = $e110a2ab6d3a4734['stream_id'];
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['last_active'] = $e110a2ab6d3a4734['date_start'];
						}
						unset($C7dc44e2b269673a);
					} else {
						$Fee0d5a474c96306->query('SELECT `lines_live`.`user_id`, `lines_live`.`stream_id`, `lines_live`.`date_start` AS `last_active`, `streams`.`stream_display_name` FROM `lines_live` LEFT JOIN `streams` ON `streams`.`id` = `lines_live`.`stream_id` INNER JOIN (SELECT `user_id`, MAX(`date_start`) AS `ts` FROM `lines_live` GROUP BY `user_id`) `maxt` ON (`lines_live`.`user_id` = `maxt`.`user_id` AND `lines_live`.`date_start` = `maxt`.`ts`) WHERE `lines_live`.`user_id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_display_name'] = $C740da31596f24ef['stream_display_name'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
						}
					}
				}

				if (0 >= count($c189216dc4083b79)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `user_id`, `stream_id`, `date_end` AS `last_active` FROM `lines_activity` WHERE `activity_id` IN (' . implode(',', $c189216dc4083b79) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (isset($a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'])) {
						} else {
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
						}
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!isset($a4dd92d2bc66e08d[$C740da31596f24ef['id']])) {
					} else {
						$C740da31596f24ef = array_merge($C740da31596f24ef, $a4dd92d2bc66e08d[$C740da31596f24ef['id']]);
					}

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						$C740da31596f24ef['active_connections'] = (isset($bde5957fb5fa9547[$C740da31596f24ef['id']]) ? $bde5957fb5fa9547[$C740da31596f24ef['id']] : 0);
					}

					if (!$B3f0f4a134021073) {
						if (!$C740da31596f24ef['id']) {
							$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="Damaged - Line Missing"></i>';
						} else {
							if (!$C740da31596f24ef['admin_enabled']) {
								$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="Banned"></i>';
							} else {
								if (!$C740da31596f24ef['enabled']) {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
								} else {
									if ($C740da31596f24ef['exp_date'] && $C740da31596f24ef['exp_date'] < time()) {
										$Ba23222f3ed2dc08 = '<i class="text-warning far fa-square tooltip" title="Expired"></i>';
									} else {
										$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square tooltip" title="Active"></i>';
									}
								}
							}
						}

						if (0 < $C740da31596f24ef['active_connections']) {
							$ccf88201f4394db1 = '<i class="text-success fas fa-square"></i>';
						} else {
							$ccf88201f4394db1 = '<i class="text-warning far fa-square"></i>';
						}

						if ($C740da31596f24ef['is_trial']) {
							$Faa3eac96f7d5cc3 = '<i class="text-warning fas fa-square"></i>';
						} else {
							$Faa3eac96f7d5cc3 = '<i class="text-secondary far fa-square"></i>';
						}

						if ($C740da31596f24ef['exp_date']) {
							if ($C740da31596f24ef['exp_date'] < time()) {
								$e2b9f3089939b18c = '<span class="expired">' . date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . '<br/><small>' . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small></span>';
							} else {
								$e2b9f3089939b18c = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small>';
							}
						} else {
							$e2b9f3089939b18c = '&infin;';
						}

						if (AacD47D8157a1a09('adv', 'live_connections')) {
							$D893e54c76761cd5 = '<a href="live_connections?user_id=' . $C740da31596f24ef['id'] . '">' . $C740da31596f24ef['active_connections'] . '</a>';
						} else {
							$D893e54c76761cd5 = $C740da31596f24ef['active_connections'];
						}

						$Fe8647e101f37537 = '';

						if (0 >= strlen($C740da31596f24ef['admin_notes'])) {
						} else {
							$Fe8647e101f37537 .= $C740da31596f24ef['admin_notes'];
						}

						if (0 >= strlen($C740da31596f24ef['reseller_notes'])) {
						} else {
							if (strlen($Fe8647e101f37537) == 0) {
							} else {
								$Fe8647e101f37537 .= "\n";
							}

							$Fe8647e101f37537 .= $C740da31596f24ef['reseller_notes'];
						}

						if (XUI::$rSettings['group_buttons']) {
							$ebab77ef4bee81e0 = '';

							if (0 >= strlen($Fe8647e101f37537)) {
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

							if (!aAcD47d8157a1A09('adv', 'manage_events')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="message(' . $C740da31596f24ef['mag_id'] . ", '" . $C740da31596f24ef['mac'] . "');\">MAG Event</a>";
							}

							if (!aACD47D8157a1a09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'convert');\">Convert to Line</a>";
							}

							if (!(AAcD47d8157a1A09('adv', 'fingerprint') && $C740da31596f24ef['user_id'] && 0 < $C740da31596f24ef['active_connections'])) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="modalFingerprint(' . $C740da31596f24ef['user_id'] . ", 'user');\">Fingerprint</a>";
							}

							if (!AACD47d8157a1A09('adv', 'edit_mag')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="mag?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'mag', " . intval($C740da31596f24ef['mag_id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['username'])) . "')\" data-modal=\"true\"" : '')) . '>Edit Device</a>';

								if ($C740da31596f24ef['admin_enabled']) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'ban');\">Ban Device</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'unban');\">Unban Device</a>";
								}

								if ($C740da31596f24ef['enabled'] == 1) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'disable');\">Disable Device</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'enable');\">Enable Device</a>";
								}

								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'delete');\">Delete Device</a>";
							}

							$ebab77ef4bee81e0 .= '</div>';
						} else {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if (0 < strlen($Fe8647e101f37537)) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
							}

							if (!AaCd47d8157a1a09('adv', 'manage_events')) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="MAG Event" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="message(' . $C740da31596f24ef['mag_id'] . ", '" . $C740da31596f24ef['mac'] . "');\"><i class=\"mdi mdi-message-alert\"></i></button>";
							}

							if (!Aacd47d8157A1A09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Convert to User Line" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'convert');\"><i class=\"fas fa-retweet\"></i></button>";
							}

							if (!aacD47d8157A1a09('adv', 'fingerprint')) {
							} else {
								if ($C740da31596f24ef['user_id'] && 0 < $C740da31596f24ef['active_connections']) {
									$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="modalFingerprint(' . $C740da31596f24ef['user_id'] . ", 'user');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-fingerprint"></i></button>';
								}
							}

							if (!aacD47d8157a1A09('adv', 'edit_mag')) {
							} else {
								$ebab77ef4bee81e0 .= '<a href="mag?id=' . $C740da31596f24ef['mag_id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'mag', " . intval($C740da31596f24ef['mag_id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['mac'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>';

								if ($C740da31596f24ef['admin_enabled']) {
									$ebab77ef4bee81e0 .= '<button title="Ban" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'ban');\"><i class=\"mdi mdi-power\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Unban" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'unban');\"><i class=\"mdi mdi-power\"></i></button>";
								}

								if ($C740da31596f24ef['enabled'] == 1) {
									$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
								}

								$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '</div>';
						}

						if (0 < $C740da31596f24ef['member_id']) {
							$Dbb9e190755fc819 = "<a href='user?id=" . $C740da31596f24ef['member_id'] . "'>" . $C740da31596f24ef['owner_name'] . '</a>';
						} else {
							$Dbb9e190755fc819 = $C740da31596f24ef['owner_name'];
						}

						if ($C740da31596f24ef['active_connections'] && $C740da31596f24ef['last_active']) {
							$Fc75284164e5b696 = "<a href='stream_view?id=" . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . "</a><br/><small class='text-secondary'>Online: " . XUI::f01c2e2cfC16141e(time() - $C740da31596f24ef['last_active']) . '</small>';
						} else {
							if ($C740da31596f24ef['last_active']) {
								$Fc75284164e5b696 = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['last_active']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['last_active']) . '</small>';
							} else {
								$Fc75284164e5b696 = 'Never';
							}
						}

						if (!isset(XUI::$rRequest['no_url'])) {
							$a85e1b7d42c346a0['data'][] = array("<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['mag_id'] . '</a>', $C740da31596f24ef['username'], "<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['mac'] . '</a>', $C740da31596f24ef['stb_type'], $Dbb9e190755fc819, $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['mag_id'], $C740da31596f24ef['username'], $C740da31596f24ef['mac'], $C740da31596f24ef['stb_type'], $C740da31596f24ef['owner_name'], $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						}
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'enigmas') {
	if (aAcD47D8157a1a09('adv', 'manage_e2')) {
		$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
		$c6c389b9adf3a40c = array('`lines`.`id`', '`lines`.`username`', '`enigma2_devices`.`mac`', '`enigma2_devices`.`public_ip`', '`lines`.`member_id`', '`lines`.`enabled`', '`active_connections` > 0', '`lines`.`is_trial`', '`lines`.`exp_date`', '`active_connections` ' . $cb10faf5ade31619 . ', `last_activity`', false);

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

		if (0 >= strlen(XUI::$rRequest['search']['value'])) {
		} else {
			foreach (range(1, 6) as $b6f0b24a56fe41b6) {
				$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
			}
			$f86e19bdb1e7dae8[] = '(`lines`.`username` LIKE ? OR `enigma2_devices`.`mac` LIKE ? OR `enigma2_devices`.`public_ip` LIKE ? OR FROM_UNIXTIME(`exp_date`) LIKE ? OR `lines`.`reseller_notes` LIKE ? OR `lines`.`admin_notes` LIKE ?)';
		}

		if (0 >= strlen(XUI::$rRequest['filter'])) {
		} else {
			if (XUI::$rRequest['filter'] == 1) {
				$f86e19bdb1e7dae8[] = '(`lines`.`admin_enabled` = 1 AND `lines`.`enabled` = 1 AND (`lines`.`exp_date` IS NULL OR `lines`.`exp_date` > UNIX_TIMESTAMP()))';
			} else {
				if (XUI::$rRequest['filter'] == 2) {
					$f86e19bdb1e7dae8[] = '`lines`.`enabled` = 0';
				} else {
					if (XUI::$rRequest['filter'] == 3) {
						$f86e19bdb1e7dae8[] = '`lines`.`admin_enabled` = 0';
					} else {
						if (XUI::$rRequest['filter'] == 4) {
							$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` <= UNIX_TIMESTAMP())';
						} else {
							if (XUI::$rRequest['filter'] != 5) {
							} else {
								$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
							}
						}
					}
				}
			}
		}

		if (0 >= strlen(XUI::$rRequest['reseller'])) {
		} else {
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
		} else {
			$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
		}

		$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines` RIGHT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ';';
		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			$A6d7047f2fda966c = 'SELECT `lines`.`id`, `lines`.`username`, `lines`.`member_id`, `lines`.`last_activity`, `lines`.`last_activity_array`, `enigma2_devices`.`mac`, `enigma2_devices`.`public_ip`, `enigma2_devices`.`device_id`, `lines`.`exp_date`, `lines`.`admin_enabled`, `lines`.`enabled`, `lines`.`admin_notes`, `lines`.`reseller_notes`, `lines`.`max_connections`, `lines`.`is_trial`, (SELECT count(*) FROM `lines_live` WHERE `lines`.`id` = `lines_live`.`user_id` AND `hls_end` = 0) AS `active_connections` FROM `lines` RIGHT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$c189216dc4083b79 = $a4dd92d2bc66e08d = $Cde0ba71e2c62c4c = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!$C740da31596f24ef['id']) {
					} else {
						$Cde0ba71e2c62c4c[] = intval($C740da31596f24ef['id']);
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])] = array('owner_name' => null, 'stream_display_name' => null, 'stream_id' => null, 'last_active' => null);
					}

					if ($E5ae9288fdfb3b75 = json_decode($C740da31596f24ef['last_activity_array'], true)) {
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['stream_id'] = $E5ae9288fdfb3b75['stream_id'];
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['last_active'] = $E5ae9288fdfb3b75['date_end'];
					} else {
						if (!$C740da31596f24ef['last_activity']) {
						} else {
							$c189216dc4083b79[] = intval($C740da31596f24ef['last_activity']);
						}
					}
				}

				if (0 >= count($Cde0ba71e2c62c4c)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `users`.`username`, `lines`.`id` FROM `users` LEFT JOIN `lines` ON `lines`.`member_id` = `users`.`id` WHERE `lines`.`id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$a4dd92d2bc66e08d[$C740da31596f24ef['id']]['owner_name'] = $C740da31596f24ef['username'];
					}

					if (XUI::$rSettings['redis_handler']) {
						$bde5957fb5fa9547 = XUI::dE78b5E00a0718D6($Cde0ba71e2c62c4c, true);
						$C7dc44e2b269673a = XUI::getFirstConnection($Cde0ba71e2c62c4c);
						$Cdb85875fd50f459 = array();

						foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
							if (in_array($e110a2ab6d3a4734['stream_id'], $Cdb85875fd50f459)) {
							} else {
								$Cdb85875fd50f459[] = intval($e110a2ab6d3a4734['stream_id']);
							}
						}
						$F36bea2698ecb4fa = array();

						if (0 >= count($Cdb85875fd50f459)) {
						} else {
							$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F36bea2698ecb4fa[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
							}
						}

						foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $e110a2ab6d3a4734) {
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_display_name'] = $F36bea2698ecb4fa[$e110a2ab6d3a4734['stream_id']];
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_id'] = $e110a2ab6d3a4734['stream_id'];
							$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['last_active'] = $e110a2ab6d3a4734['date_start'];
						}
						unset($C7dc44e2b269673a);
					} else {
						$Fee0d5a474c96306->query('SELECT `lines_live`.`user_id`, `lines_live`.`stream_id`, `lines_live`.`date_start` AS `last_active`, `streams`.`stream_display_name` FROM `lines_live` LEFT JOIN `streams` ON `streams`.`id` = `lines_live`.`stream_id` INNER JOIN (SELECT `user_id`, MAX(`date_start`) AS `ts` FROM `lines_live` GROUP BY `user_id`) `maxt` ON (`lines_live`.`user_id` = `maxt`.`user_id` AND `lines_live`.`date_start` = `maxt`.`ts`) WHERE `lines_live`.`user_id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_display_name'] = $C740da31596f24ef['stream_display_name'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
						}
					}
				}

				if (0 >= count($c189216dc4083b79)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `user_id`, `stream_id`, `date_end` AS `last_active` FROM `lines_activity` WHERE `activity_id` IN (' . implode(',', $c189216dc4083b79) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (isset($a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'])) {
						} else {
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
							$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
						}
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!isset($a4dd92d2bc66e08d[$C740da31596f24ef['id']])) {
					} else {
						$C740da31596f24ef = array_merge($C740da31596f24ef, $a4dd92d2bc66e08d[$C740da31596f24ef['id']]);
					}

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						$C740da31596f24ef['active_connections'] = (isset($bde5957fb5fa9547[$C740da31596f24ef['id']]) ? $bde5957fb5fa9547[$C740da31596f24ef['id']] : 0);
					}

					if (!$B3f0f4a134021073) {
						if (!$C740da31596f24ef['id']) {
							$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="Damaged - Line Missing"></i>';
						} else {
							if (!$C740da31596f24ef['admin_enabled']) {
								$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="Banned"></i>';
							} else {
								if (!$C740da31596f24ef['enabled']) {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
								} else {
									if ($C740da31596f24ef['exp_date'] && $C740da31596f24ef['exp_date'] < time()) {
										$Ba23222f3ed2dc08 = '<i class="text-warning far fa-square tooltip" title="Expired"></i>';
									} else {
										$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square tooltip" title="Active"></i>';
									}
								}
							}
						}

						if (0 < $C740da31596f24ef['active_connections']) {
							$ccf88201f4394db1 = '<i class="text-success fas fa-square"></i>';
						} else {
							$ccf88201f4394db1 = '<i class="text-warning far fa-square"></i>';
						}

						if ($C740da31596f24ef['is_trial']) {
							$Faa3eac96f7d5cc3 = '<i class="text-warning fas fa-square"></i>';
						} else {
							$Faa3eac96f7d5cc3 = '<i class="text-secondary far fa-square"></i>';
						}

						if ($C740da31596f24ef['exp_date']) {
							if ($C740da31596f24ef['exp_date'] < time()) {
								$e2b9f3089939b18c = '<span class="expired">' . date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . '<br/><small>' . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small></span>';
							} else {
								$e2b9f3089939b18c = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small>';
							}
						} else {
							$e2b9f3089939b18c = '&infin;';
						}

						if (AaCd47d8157a1A09('adv', 'live_connections')) {
							$D893e54c76761cd5 = '<a href="live_connections?user_id=' . $C740da31596f24ef['id'] . '">' . $C740da31596f24ef['active_connections'] . '</a>';
						} else {
							$D893e54c76761cd5 = $C740da31596f24ef['active_connections'];
						}

						$Fe8647e101f37537 = '';

						if (0 >= strlen($C740da31596f24ef['admin_notes'])) {
						} else {
							$Fe8647e101f37537 .= $C740da31596f24ef['admin_notes'];
						}

						if (0 >= strlen($C740da31596f24ef['reseller_notes'])) {
						} else {
							if (strlen($Fe8647e101f37537) == 0) {
							} else {
								$Fe8647e101f37537 .= "\n";
							}

							$Fe8647e101f37537 .= $C740da31596f24ef['reseller_notes'];
						}

						if (XUI::$rSettings['group_buttons']) {
							$ebab77ef4bee81e0 = '';

							if (0 >= strlen($Fe8647e101f37537)) {
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

							if (!aAcd47D8157A1A09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'convert');\">Convert to Line</a>";
							}

							if (!(aaCd47d8157a1A09('adv', 'fingerprint') && $C740da31596f24ef['user_id'] && 0 < $C740da31596f24ef['active_connections'])) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="modalFingerprint(' . $C740da31596f24ef['user_id'] . ", 'user');\">Fingerprint</a>";
							}

							if (!Aacd47D8157a1a09('adv', 'edit_e2')) {
							} else {
								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="enigma?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'enigma', " . intval($C740da31596f24ef['device_id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['username'])) . "')\" data-modal=\"true\"" : '')) . '>Edit Device</a>';

								if ($C740da31596f24ef['admin_enabled']) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'ban');\">Ban Device</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'unban');\">Unban Device</a>";
								}

								if ($C740da31596f24ef['enabled'] == 1) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'disable');\">Disable Device</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'enable');\">Enable Device</a>";
								}

								$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'delete');\">Delete Device</a>";
							}

							$ebab77ef4bee81e0 .= '</div>';
						} else {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if (0 < strlen($Fe8647e101f37537)) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
							}

							if (!AacD47d8157A1A09('adv', 'edit_user')) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Convert to User Line" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'convert');\"><i class=\"fas fa-retweet\"></i></button>";
							}

							if (!AAcd47D8157A1a09('adv', 'fingerprint')) {
							} else {
								if ($C740da31596f24ef['user_id'] && 0 < $C740da31596f24ef['active_connections']) {
									$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="modalFingerprint(' . $C740da31596f24ef['user_id'] . ", 'user');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-fingerprint"></i></button>';
								}
							}

							if (!AaCD47d8157a1a09('adv', 'edit_e2')) {
							} else {
								$ebab77ef4bee81e0 .= '<a href="enigma?id=' . $C740da31596f24ef['device_id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'enigma', " . intval($C740da31596f24ef['device_id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['mac'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>';

								if ($C740da31596f24ef['admin_enabled']) {
									$ebab77ef4bee81e0 .= '<button title="Ban" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'ban');\"><i class=\"mdi mdi-power\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Unban" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'unban');\"><i class=\"mdi mdi-power\"></i></button>";
								}

								if ($C740da31596f24ef['enabled'] == 1) {
									$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
								}

								$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '</div>';
						}

						if (0 < $C740da31596f24ef['member_id']) {
							$Dbb9e190755fc819 = "<a href='user?id=" . $C740da31596f24ef['member_id'] . "'>" . $C740da31596f24ef['owner_name'] . '</a>';
						} else {
							$Dbb9e190755fc819 = $C740da31596f24ef['owner_name'];
						}

						if ($C740da31596f24ef['active_connections'] && $C740da31596f24ef['last_active']) {
							$Fc75284164e5b696 = "<a href='stream_view?id=" . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . "</a><br/><small class='text-secondary'>Online: " . XUI::f01c2E2cfC16141E(time() - $C740da31596f24ef['last_active']) . '</small>';
						} else {
							if ($C740da31596f24ef['last_active']) {
								$Fc75284164e5b696 = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['last_active']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['last_active']) . '</small>';
							} else {
								$Fc75284164e5b696 = 'Never';
							}
						}

						if (!isset(XUI::$rRequest['no_url'])) {
							$a85e1b7d42c346a0['data'][] = array("<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['device_id'] . '</a>', $C740da31596f24ef['username'], "<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['mac'] . '</a>', "<a onClick=\"whois('" . $C740da31596f24ef['public_ip'] . "');\" href='javascript: void(0);'>" . $C740da31596f24ef['public_ip'] . '</a>', $Dbb9e190755fc819, $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['device_id'], $C740da31596f24ef['username'], $C740da31596f24ef['mac'], $C740da31596f24ef['public_ip'], $C740da31596f24ef['owner_name'], $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						}
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'streams') {
	if (AACd47d8157A1a09('adv', 'streams') || aaCD47d8157A1a09('adv', 'mass_edit_streams')) {
		$A5dcdeb6ecbbf6bd = cbe87E2A9A996111('live');
		$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_icon`', '`streams`.`stream_display_name`', '`streams_servers`.`current_source`', '`clients`', '`streams_servers`.`stream_started`', false, false, false, '`streams_servers`.`bitrate`');

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$Eabdab369bae73a8 = isset(XUI::$rRequest['created']);
		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

		if ($Eabdab369bae73a8) {
			$f86e19bdb1e7dae8[] = '`streams`.`type` = 3';
		} else {
			$f86e19bdb1e7dae8[] = '`streams`.`type` = 1';
		}

		if (isset(XUI::$rRequest['stream_id'])) {
			$f86e19bdb1e7dae8[] = '`streams`.`id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];
			$Ccfe11bd7a796290 = 'ORDER BY `streams_servers`.`server_stream_id` ASC';
		} else {
			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
			}

			if (0 < intval(XUI::$rRequest['category'])) {
				$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
				$Df2582e36fdd6160[] = XUI::$rRequest['category'];
			} else {
				if (intval(XUI::$rRequest['category']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
				}
			}

			if (!isset(XUI::$rRequest['refresh'])) {
			} else {
				$f86e19bdb1e7dae8 = array('`streams`.`id` IN (' . implode(',', array_map('intval', explode(',', XUI::$rRequest['refresh']))) . ')');
				$D031c48a1422c07e = 0;
				$E400a3101514583e = 1000;
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (!$Eabdab369bae73a8) {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '(`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`stream_status` = 0)';
					} else {
						if (XUI::$rRequest['filter'] == 2) {
							$f86e19bdb1e7dae8[] = '((`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 1))';
						} else {
							if (XUI::$rRequest['filter'] == 3) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND `streams_servers`.`on_demand` = 0)';
							} else {
								if (XUI::$rRequest['filter'] == 4) {
									$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 2)';
								} else {
									if (XUI::$rRequest['filter'] == 5) {
										$f86e19bdb1e7dae8[] = '`streams_servers`.`on_demand` = 1';
									} else {
										if (XUI::$rRequest['filter'] == 6) {
											$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
										} else {
											if (XUI::$rRequest['filter'] == 7) {
												$f86e19bdb1e7dae8[] = '`streams`.`tv_archive_server_id` > 0 AND `streams`.`tv_archive_duration` > 0';
											} else {
												if (XUI::$rRequest['filter'] == 8) {
													if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
														$f86e19bdb1e7dae8[] = "(SELECT COUNT(*) AS `count` FROM `streams_logs` WHERE `streams_logs`.`action` = 'STREAM_FAILED' AND `streams_logs`.`date` >= UNIX_TIMESTAMP()-86400 AND `streams_logs`.`stream_id` = `streams`.`id`) > 144";
													} else {
														$f86e19bdb1e7dae8[] = "(SELECT COUNT(*) AS `count` FROM `streams_logs` WHERE `streams_logs`.`action` = 'STREAM_FAILED' AND `streams_logs`.`date` >= UNIX_TIMESTAMP()-86400 AND `streams_logs`.`stream_id` = `streams`.`id` AND `streams_logs`.`server_id` = `streams_servers`.`server_id`) > 144";
													}
												} else {
													if (XUI::$rRequest['filter'] == 9) {
														$f86e19bdb1e7dae8[] = 'LENGTH(`streams`.`channel_id`) > 0';
													} else {
														if (XUI::$rRequest['filter'] == 10) {
															$f86e19bdb1e7dae8[] = '(`streams`.`channel_id` IS NULL OR LENGTH(`streams`.`channel_id`) = 0)';
														} else {
															if (XUI::$rRequest['filter'] == 11) {
																$f86e19bdb1e7dae8[] = '`streams`.`adaptive_link` IS NOT NULL';
															} else {
																if (XUI::$rRequest['filter'] == 12) {
																	$f86e19bdb1e7dae8[] = '`streams`.`title_sync` IS NOT NULL';
																} else {
																	if (XUI::$rRequest['filter'] != 13) {
																	} else {
																		$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				} else {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '(`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0)';
					} else {
						if (XUI::$rRequest['filter'] == 2) {
							$f86e19bdb1e7dae8[] = "(`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND (REPLACE(`streams_servers`.`cchannel_rsources`, '\\\\/', '/') = REPLACE(`streams`.`stream_source`, '\\\\/', '/'))";
						} else {
							if (XUI::$rRequest['filter'] == 3) {
								$f86e19bdb1e7dae8[] = "(REPLACE(`streams_servers`.`cchannel_rsources`, '\\\\/', '/') <> REPLACE(`streams`.`stream_source`, '\\\\/', '/'))";
							} else {
								if (XUI::$rRequest['filter'] != 4) {
								} else {
									$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
								}
							}
						}
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['audio'])) {
			} else {
				if (XUI::$rRequest['audio'] == -1) {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`audio_codec` IS NULL';
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`audio_codec` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['audio'];
				}
			}

			if (0 >= strlen(XUI::$rRequest['video'])) {
			} else {
				if (XUI::$rRequest['video'] == -1) {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`video_codec` IS NULL';
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`video_codec` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['video'];
				}
			}

			if (0 >= strlen(XUI::$rRequest['resolution'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`resolution` = ?';
				$Df2582e36fdd6160[] = (intval(XUI::$rRequest['resolution']) ?: null);
			}

			if (0 < intval(XUI::$rRequest['server'])) {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
				$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			} else {
				if (intval(XUI::$rRequest['server']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
				}
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		if (!isset(XUI::$rRequest['single'])) {
		} else {
			$F2d4d8f7981ac574['streams_grouped'] = 0;
		}

		if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM (SELECT `id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id`) t1;';
		} else {
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
		}

		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams_servers`.`stream_id`, `streams`.`type`, `streams`.`stream_icon`, `streams`.`adaptive_link`, `streams`.`title_sync`, `streams_servers`.`cchannel_rsources`, `streams`.`stream_source`, `streams`.`stream_display_name`, `streams`.`tv_archive_duration`, `streams`.`tv_archive_server_id`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`cc_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams`.`epg_id`, `streams`.`channel_id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ', -`stream_started` DESC LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`type`, `streams`.`stream_icon`, `streams`.`adaptive_link`, `streams`.`title_sync`, `streams_servers`.`cchannel_rsources`, `streams`.`stream_source`, `streams`.`stream_display_name`, `streams`.`tv_archive_duration`, `streams`.`tv_archive_server_id`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`cc_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams`.`epg_id`, `streams`.`channel_id`, `streams_servers`.`parent_id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			}

			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$bd905fdd26def8ef = $d5e40c7f6fdf5643 = $a067d91fd5373c7e = $caa77b80211665a0 = $Cdb85875fd50f459 = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					$Cdb85875fd50f459[] = $C740da31596f24ef['id'];

					if (!$C740da31596f24ef['channel_id'] || in_array("'" . $C740da31596f24ef['epg_id'] . '_' . $C740da31596f24ef['channel_id'] . "'", $bd905fdd26def8ef)) {
					} else {
						$bd905fdd26def8ef[] = "'" . $C740da31596f24ef['epg_id'] . '_' . str_replace("'", "\\'", $C740da31596f24ef['channel_id']) . "'";
					}
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
					}

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						if ($F2d4d8f7981ac574['streams_grouped']) {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, true, true);
						} else {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, false, false);
						}
					}
				}

				if ($Eabdab369bae73a8) {
				} else {
					$C4af185e24cf9086 = time();

					if (0 >= count($Cdb85875fd50f459)) {
					} else {
						$A6d7047f2fda966c = "SELECT `stream_id`, `server_id`, COUNT(*) AS `fails`, MAX(`date`) AS `last` FROM `streams_logs` WHERE `action` IN ('STREAM_FAILED', 'STREAM_START_FAIL') AND `date` >= (UNIX_TIMESTAMP()-" . intval(($F2d4d8f7981ac574['fails_per_time'] ?: 86400)) . ') AND `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`, `server_id`;';
						$Fee0d5a474c96306->query($A6d7047f2fda966c);

						if (0 >= $Fee0d5a474c96306->num_rows()) {
						} else {
							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$a067d91fd5373c7e[$C740da31596f24ef['stream_id']][intval($C740da31596f24ef['server_id'])] = array($C740da31596f24ef['fails'], $C4af185e24cf9086 - $C740da31596f24ef['last']);
								$d5e40c7f6fdf5643[$C740da31596f24ef['stream_id']][0] += $C740da31596f24ef['fails'];

								if ($d5e40c7f6fdf5643[$C740da31596f24ef['stream_id']]['last'] >= $C4af185e24cf9086 - $C740da31596f24ef['last']) {
								} else {
									$d5e40c7f6fdf5643[$C740da31596f24ef['stream_id']][1] = $C4af185e24cf9086 - $C740da31596f24ef['last'];
								}
							}
						}
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!XUI::$rSettings['redis_handler']) {
					} else {
						if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
							$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
						} else {
							$C740da31596f24ef['clients'] = (count($bde5957fb5fa9547[$C740da31596f24ef['id']][$C740da31596f24ef['server_id']]) ?: 0);
						}
					}

					if (!$B3f0f4a134021073) {
						$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

						if (0 < strlen(XUI::$rRequest['category'])) {
							$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
						} else {
							$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
						}

						if (1 >= count($A38b42a281e3c3cf)) {
						} else {
							$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
						}

						if (!(0 < $C740da31596f24ef['tv_archive_duration'] && 0 < $C740da31596f24ef['tv_archive_server_id'])) {
						} else {
							$C740da31596f24ef['stream_display_name'] .= " &nbsp;<a href='archive?id=" . $C740da31596f24ef['id'] . "'><i class='text-danger mdi mdi-record'></i></a>";
						}

						if (0 >= count(json_decode($C740da31596f24ef['adaptive_link'], true))) {
						} else {
							$C740da31596f24ef['stream_display_name'] .= " &nbsp;<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'><i class='text-info mdi mdi-wifi-strength-3'></i></a>";
						}

						if (!$C740da31596f24ef['title_sync']) {
						} else {
							$C740da31596f24ef['stream_display_name'] .= " &nbsp;<i class='text-info mdi mdi-sync tooltip' title='Title Sync'></i>";
						}

						$Ef28eaee0050d7a5 = "<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'><strong>" . $C740da31596f24ef['stream_display_name'] . "</strong><br><span style='font-size:11px;'>" . $A1925ae53e9307eb . '</span></a>';

						if ($C740da31596f24ef['server_name']) {
							if (aACd47d8157a1A09('adv', 'servers')) {
								$B00ef71aa2cd7a26 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
							} else {
								$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];
							}

							if (!($F2d4d8f7981ac574['streams_grouped'] && 1 < $caa77b80211665a0[$C740da31596f24ef['id']])) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"View All Servers\" onClick=\"viewSources('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', " . intval($C740da31596f24ef['id']) . ");\" type='button' class='tooltip-left btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
							}

							if ($a8bb73cba48fb7f6[$C740da31596f24ef['server_id']]['last_status'] == 1) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"Server Offline!<br/>Uptime cannot be confirmed.\" type='button' class='tooltip btn btn-danger btn-xs waves-effect waves-light'><i class='mdi mdi-alert'></i></button>";
							}
						} else {
							$B00ef71aa2cd7a26 = 'No Server Selected';
						}

						if (0 < intval($C740da31596f24ef['parent_id'])) {
							$ecc9029bfbc77eed = "<br/><span style='font-size:11px;'>loop: " . strtolower(XUI::$rServers[$C740da31596f24ef['parent_id']]['server_name']) . '</span>';
						} else {
							$ecc9029bfbc77eed = "<br/><span style='font-size:11px;'>" . strtolower(parse_url($C740da31596f24ef['current_source'])['host']) . '</span>';
						}

						$B00ef71aa2cd7a26 .= $ecc9029bfbc77eed;

						if (0 >= intval($C740da31596f24ef['stream_started'])) {
						} else {
							$eff3c5536b319f0b = $fad73125a2cca3ed = time() - intval($C740da31596f24ef['stream_started']);
						}

						$b45800af0138159b = 0;

						if ($C740da31596f24ef['server_id']) {
							if (!$Eabdab369bae73a8) {
								if (intval($C740da31596f24ef['direct_source']) == 1) {
									if (intval($C740da31596f24ef['direct_proxy']) == 1) {
										if ($C740da31596f24ef['pid'] && 0 < $C740da31596f24ef['pid']) {
											$b45800af0138159b = 1;
										} else {
											$b45800af0138159b = 7;
										}
									} else {
										$b45800af0138159b = 5;
									}
								} else {
									if ($C740da31596f24ef['monitor_pid']) {
										if ($C740da31596f24ef['pid'] && 0 < $C740da31596f24ef['pid']) {
											if (intval($C740da31596f24ef['stream_status']) == 2) {
												$b45800af0138159b = 2;
											} else {
												$b45800af0138159b = 1;
											}
										} else {
											if ($C740da31596f24ef['stream_status'] == 0) {
												$b45800af0138159b = 2;
											} else {
												$b45800af0138159b = 3;
											}
										}
									} else {
										if (intval($C740da31596f24ef['on_demand']) == 1) {
											$b45800af0138159b = 4;
										} else {
											$b45800af0138159b = 0;
										}
									}
								}
							} else {
								if ($C740da31596f24ef['monitor_pid']) {
									if ($C740da31596f24ef['pid'] && 0 < $C740da31596f24ef['pid']) {
										if (intval($C740da31596f24ef['stream_status']) == 2) {
											$b45800af0138159b = 2;
										} else {
											$b45800af0138159b = 1;
										}
									} else {
										if ($C740da31596f24ef['stream_status'] == 0) {
											$b45800af0138159b = 2;
										} else {
											$b45800af0138159b = 3;
										}
									}
								} else {
									$b45800af0138159b = 0;
								}

								if (count(json_decode($C740da31596f24ef['cchannel_rsources'], true)) == count(json_decode($C740da31596f24ef['stream_source'], true)) || $C740da31596f24ef['parent_id']) {
								} else {
									$b45800af0138159b = 6;
								}
							}
						} else {
							if (intval($C740da31596f24ef['direct_source']) == 1) {
								$b45800af0138159b = 5;
							} else {
								$b45800af0138159b = -1;
							}
						}

						if ($C740da31596f24ef['server_id']) {
						} else {
							$C740da31596f24ef['server_id'] = 0;
						}

						if ($F2d4d8f7981ac574['streams_grouped'] != 1) {
						} else {
							$C740da31596f24ef['server_id'] = -1;
						}

						if (AaCD47d8157A1a09('adv', 'live_connections')) {
							if (0 < $C740da31596f24ef['clients']) {
								$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ', ' . intval($C740da31596f24ef['server_id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button></a>';
							} else {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}
						} else {
							if (0 < $C740da31596f24ef['clients']) {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button>';
							} else {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}
						}

						if (XUI::$rSettings['hide_failures'] && !$Eabdab369bae73a8) {
							$a5a140d9115dd28b = 'btn-fixed-xl';
						} else {
							$a5a140d9115dd28b = 'btn-fixed';
						}

						if ($b45800af0138159b == 1) {
							if (86400 <= $fad73125a2cca3ed) {
								$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
							} else {
								$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
							}

							$fad73125a2cca3ed = "<button type='button' class='btn btn-success btn-xs waves-effect waves-light " . $a5a140d9115dd28b . "'>" . $fad73125a2cca3ed . '</button>';
						} else {
							if ($b45800af0138159b == 3) {
								$fad73125a2cca3ed = "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light " . $a5a140d9115dd28b . "'>DOWN</button>";
							} else {
								if ($b45800af0138159b == 6) {
									$bbfc9bd8432031f5 = json_decode($C740da31596f24ef['stream_source'], true);
									$Fb362f76a7dd37ee = count(array_diff($bbfc9bd8432031f5, json_decode($C740da31596f24ef['cchannel_rsources'], true)));
									$a4c39aca5bca0ec1 = intval((count($bbfc9bd8432031f5) - $Fb362f76a7dd37ee) / count($bbfc9bd8432031f5) * 100);
									$fad73125a2cca3ed = "<button type='button' class='btn btn-primary btn-xs waves-effect waves-light btn-fixed-xl'>" . $a4c39aca5bca0ec1 . '% DONE</button>';
								} else {
									$fad73125a2cca3ed = $F8b5842eeedab682[$b45800af0138159b];
								}
							}
						}

						if (!in_array($b45800af0138159b, array(1, 2, 3))) {
						} else {
							if ($Eabdab369bae73a8) {
								$a0e727eef95293df = json_decode($C740da31596f24ef['cc_info'], true);
								$b267a0199ec5374f = ($C740da31596f24ef['parent_id'] ? 'Channel is looping from another server, real position cannot be determined.' : 'No information available.');

								if ($b45800af0138159b == 1 && 0 < count($a0e727eef95293df) && !$C740da31596f24ef['parent_id']) {
									$bbfc9bd8432031f5 = json_decode($C740da31596f24ef['stream_source'], true);

									foreach ($a0e727eef95293df as $Caaa4497150f8738) {
										if (!($Caaa4497150f8738['start'] <= $eff3c5536b319f0b && $eff3c5536b319f0b < $Caaa4497150f8738['finish'])) {
										} else {
											$b267a0199ec5374f = pathinfo($bbfc9bd8432031f5[$Caaa4497150f8738['position']])['filename'] . '<br/><br/>Track # ' . ($Caaa4497150f8738['position'] + 1) . ' of ' . count($bbfc9bd8432031f5) . '<br/>';

											if ($Caaa4497150f8738['position'] < count($bbfc9bd8432031f5) - 1) {
												$b267a0199ec5374f .= 'Next track in ' . number_format(($Caaa4497150f8738['finish'] - $eff3c5536b319f0b) / 60, 0) . ' minutes.';
											} else {
												$b267a0199ec5374f .= 'Looping in ' . number_format(($Caaa4497150f8738['finish'] - $eff3c5536b319f0b) / 60, 0) . ' minutes.';
											}
										}
									}
									$fad73125a2cca3ed = "<button type='button' title='" . htmlspecialchars($b267a0199ec5374f) . "' class='btn tooltip btn-success btn-xs waves-effect waves-light btn-fixed-xs'><i class='text-light fas fa-check-circle'></i></button>" . $fad73125a2cca3ed;
								} else {
									$fad73125a2cca3ed = "<button type='button' title='" . htmlspecialchars($b267a0199ec5374f) . "' class='btn tooltip btn-secondary btn-xs waves-effect waves-light btn-fixed-xs'><i class='text-light fas fa-minus-circle'></i></button>" . $fad73125a2cca3ed;
								}
							} else {
								if (!(XUI::$rSettings['hide_failures'] && stripos($fad73125a2cca3ed, 'btn-fixed-xl') === false)) {
								} else {
									$fad73125a2cca3ed = str_replace('btn-fixed', 'btn-fixed-xl', $fad73125a2cca3ed);
								}

								if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
									$a5b0685942352de0 = $d5e40c7f6fdf5643[$C740da31596f24ef['id']];
								} else {
									$a5b0685942352de0 = $a067d91fd5373c7e[$C740da31596f24ef['id']][$C740da31596f24ef['server_id']];
								}

								if ($a5b0685942352de0) {
								} else {
									$a5b0685942352de0 = array(0, 0);
								}

								if (XUI::$rSettings['hide_failures']) {
								} else {
									if (!isset($a5b0685942352de0) || $a5b0685942352de0[0] <= 2) {
										$fad73125a2cca3ed = "<button onClick='showFailures(" . intval($C740da31596f24ef['id']) . ', ' . ((!$F2d4d8f7981ac574['streams_grouped'] ? intval($C740da31596f24ef['server_id']) : '0')) . ")' type='button' title='" . $a5b0685942352de0[0] . " restarts' class='btn tooltip-left btn-success btn-xs waves-effect waves-light btn-fixed-xs'><i class='text-light fas fa-check-circle'></i></button>" . $fad73125a2cca3ed;
									} else {
										if ($a5b0685942352de0[0] <= 4 || 21600 < $a5b0685942352de0[1]) {
											$fad73125a2cca3ed = "<button onClick='showFailures(" . intval($C740da31596f24ef['id']) . ', ' . ((!$F2d4d8f7981ac574['streams_grouped'] ? intval($C740da31596f24ef['server_id']) : '0')) . ")' type='button' title='" . $a5b0685942352de0[0] . " restarts' class='btn tooltip-left btn-info btn-xs waves-effect waves-light btn-fixed-xs'><i class='text-light fas fa-minus-circle'></i></button>" . $fad73125a2cca3ed;
										} else {
											if ($a5b0685942352de0[0] <= 144 || 600 < $a5b0685942352de0[1]) {
												$fad73125a2cca3ed = "<button onClick='showFailures(" . intval($C740da31596f24ef['id']) . ', ' . ((!$F2d4d8f7981ac574['streams_grouped'] ? intval($C740da31596f24ef['server_id']) : '0')) . ")' type='button' title='" . $a5b0685942352de0[0] . " restarts' class='btn tooltip-left btn-warning btn-xs waves-effect waves-light btn-fixed-xs'><i class='text-light fas fa-exclamation-circle'></i></button>" . $fad73125a2cca3ed;
											} else {
												$fad73125a2cca3ed = "<button onClick='showFailures(" . intval($C740da31596f24ef['id']) . ', ' . ((!$F2d4d8f7981ac574['streams_grouped'] ? intval($C740da31596f24ef['server_id']) : '0')) . ")' type='button' title='" . $a5b0685942352de0[0] . " restarts' class='btn tooltip-left btn-danger btn-xs waves-effect waves-light btn-fixed-xs'><i class='text-light fas fa-times-circle'></i></button>" . $fad73125a2cca3ed;
											}
										}
									}
								}
							}
						}

						if (XUI::$rSettings['group_buttons']) {
							$ebab77ef4bee81e0 = '';

							if (0 >= strlen($C740da31596f24ef['notes'])) {
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

							if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && aacD47d8157a1A09('adv', 'edit_stream')) {
								if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop</a>" . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\">Restart</a>" . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\">Kill Connections</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Start</a>";
								}

								if (!isset(XUI::$rRequest['single'])) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
								}
							} else {
								if (!Aacd47D8157a1a09('adv', 'edit_stream')) {
								} else {
									if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop</a>" . "\r\n\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\">Restart</a>" . "\r\n\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\">Kill Connections</a>";
									} else {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Start</a>";
									}
								}

								if (!(AAcD47d8157a1a09('adv', 'fingerprint') && !$Eabdab369bae73a8 && 0 < $C740da31596f24ef['clients'])) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="modalFingerprint(' . $C740da31596f24ef['id'] . ", 'stream');\">Fingerprint</a>";
								}

								if (!aaCd47D8157a1a09('adv', 'edit_stream')) {
								} else {
									if ($C740da31596f24ef['type'] == 3) {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="created_channel?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'created_channel', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>';
									} else {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="stream?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'stream', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>';
									}

									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
								}
							}

							$ebab77ef4bee81e0 .= '</div></div>';
						} else {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && Aacd47d8157A1A09('adv', 'edit_stream')) {
								if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
									$ebab77ef4bee81e0 .= '<button title="Stop" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
									$Ba23222f3ed2dc08 = '';
								} else {
									$ebab77ef4bee81e0 .= '<button title="Start" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
									$Ba23222f3ed2dc08 = ' disabled';
								}

								$ebab77ef4bee81e0 .= '<button title="Restart" type="button" class="btn btn-light waves-effect waves-light btn-xs api-restart tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-refresh"></i></button>' . "\r\n\t\t\t\t\t\t" . '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs api-restart tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-hammer"></i></button>';

								if (!isset(XUI::$rRequest['single'])) {
								} else {
									$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}
							} else {
								if (0 < strlen($C740da31596f24ef['notes'])) {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
								}

								if (!AaCD47D8157a1a09('adv', 'edit_stream')) {
								} else {
									if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
										$ebab77ef4bee81e0 .= '<button title="Stop" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
										$Ba23222f3ed2dc08 = '';
									} else {
										$ebab77ef4bee81e0 .= '<button title="Start" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
										$Ba23222f3ed2dc08 = ' disabled';
									}

									$ebab77ef4bee81e0 .= '<button title="Restart" type="button" class="btn btn-light waves-effect waves-light btn-xs api-restart tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-refresh"></i></button>' . "\r\n\t\t\t\t\t\t\t" . '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-hammer"></i></button>';
								}

								if (!AACd47d8157A1a09('adv', 'fingerprint') || $Eabdab369bae73a8) {
								} else {
									if (0 < $C740da31596f24ef['clients']) {
										$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="modalFingerprint(' . $C740da31596f24ef['id'] . ", 'stream');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
									} else {
										$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-fingerprint"></i></button>';
									}
								}

								if (!aAcd47D8157A1A09('adv', 'edit_stream')) {
								} else {
									if ($C740da31596f24ef['type'] == 3) {
										$ebab77ef4bee81e0 .= '<a href="created_channel?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'created_channel', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>';
									} else {
										$ebab77ef4bee81e0 .= '<a href="stream?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'stream', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>';
									}

									$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}
							}

							$ebab77ef4bee81e0 .= '</div>';
						}

						$b5e8b95fdf13ba62 = "<table style='font-size: 10px;' class='table-data nowrap' align='center'><tbody><tr><td colspan='5'>No information available</td></tr></tbody></table>";
						$bb0071da5a239b0c = json_decode($C740da31596f24ef['stream_info'], true);
						$E7b0c34a84ef92b9 = json_decode($C740da31596f24ef['progress_info'], true);

						if ($b45800af0138159b != 1) {
						} else {
							if (isset($bb0071da5a239b0c['codecs']['video'])) {
							} else {
								$bb0071da5a239b0c['codecs']['video'] = array('width' => '?', 'height' => '?', 'codec_name' => 'N/A', 'r_frame_rate' => '--');
							}

							if (isset($bb0071da5a239b0c['codecs']['audio'])) {
							} else {
								$bb0071da5a239b0c['codecs']['audio'] = array('codec_name' => 'N/A');
							}

							if ($C740da31596f24ef['bitrate'] != 0) {
							} else {
								$C740da31596f24ef['bitrate'] = '?';
							}

							if (isset($E7b0c34a84ef92b9['speed'])) {
								$a31f32f586013061 = floor($E7b0c34a84ef92b9['speed'] * 100) / 100 . 'x';
							} else {
								$a31f32f586013061 = '1x';
							}

							$Fc6b82af9a3c82e5 = null;

							if (isset($E7b0c34a84ef92b9['fps'])) {
								$Fc6b82af9a3c82e5 = intval($E7b0c34a84ef92b9['fps']);
							} else {
								if (!isset($bb0071da5a239b0c['codecs']['video']['r_frame_rate'])) {
								} else {
									$Fc6b82af9a3c82e5 = intval($bb0071da5a239b0c['codecs']['video']['r_frame_rate']);
								}
							}

							if ($Fc6b82af9a3c82e5) {
								if (1000 > $Fc6b82af9a3c82e5) {
								} else {
									$Fc6b82af9a3c82e5 = intval($Fc6b82af9a3c82e5 / 1000);
								}

								$Fc6b82af9a3c82e5 = $Fc6b82af9a3c82e5 . ' FPS';
							} else {
								$Fc6b82af9a3c82e5 = '--';
							}

							$b5e8b95fdf13ba62 = "<table class='table-data nowrap' align='center'><tbody><tr><td class='double'>" . number_format($C740da31596f24ef['bitrate'], 0) . " Kbps</td><td class='text-success'><i class='mdi mdi-video' data-name='mdi-video'></i></td><td class='text-success'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>";

							if ($Eabdab369bae73a8) {
							} else {
								$b5e8b95fdf13ba62 .= "<td class='text-success'><i class='mdi mdi-play-speed' data-name='mdi-play-speed'></i></td>";
							}

							$b5e8b95fdf13ba62 .= "<td class='text-success'><i class='mdi mdi-layers' data-name='mdi-layers'></i></td></tr><tr><td class='double'>" . $bb0071da5a239b0c['codecs']['video']['width'] . ' x ' . $bb0071da5a239b0c['codecs']['video']['height'] . '</td><td>' . $bb0071da5a239b0c['codecs']['video']['codec_name'] . '</td><td>' . $bb0071da5a239b0c['codecs']['audio']['codec_name'] . '</td>';

							if ($Eabdab369bae73a8) {
							} else {
								$b5e8b95fdf13ba62 .= '<td>' . $a31f32f586013061 . '</td>';
							}

							$b5e8b95fdf13ba62 .= '<td>' . $Fc6b82af9a3c82e5 . '</td></tr></tbody></table>';
						}

						if (aAcD47D8157A1a09('adv', 'player')) {
							if ((intval($b45800af0138159b) == 1 || $b45800af0138159b == 4) && !$C740da31596f24ef['direct_proxy']) {
								if (empty($bb0071da5a239b0c['codecs']['video']['codec_name']) || strtoupper($bb0071da5a239b0c['codecs']['video']['codec_name']) == 'H264' || strtoupper($bb0071da5a239b0c['codecs']['video']['codec_name']) == 'N/A') {
									$cafddc0a05fb9f1f = '<button title="Play" type="button" class="btn btn-info waves-effect waves-light btn-xs tooltip" onClick="player(' . $C740da31596f24ef['id'] . ');"><i class="mdi mdi-play"></i></button>';
								} else {
									$cafddc0a05fb9f1f = '<button type="button" class="btn btn-dark waves-effect waves-light btn-xs tooltip" title="Incompatible Video Codec"><i class="mdi mdi-play"></i></button>';
								}
							} else {
								$cafddc0a05fb9f1f = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button>';
							}
						} else {
							$cafddc0a05fb9f1f = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button>';
						}

						if (file_exists(EPG_PATH . 'stream_' . $C740da31596f24ef['id'])) {
							$d8a1409105424710 = '<button onClick="viewEPG(' . intval($C740da31596f24ef['id']) . ");\" type='button' title='View EPG' class='tooltip btn btn-success btn-xs waves-effect waves-light'><i class='text-white fas fa-square'></i></button>";
						} else {
							if ($C740da31596f24ef['channel_id']) {
								$d8a1409105424710 = "<button type='button' class='btn btn-warning btn-xs waves-effect waves-light'><i class='text-white fas fa-square'></i></button>";
							} else {
								$d8a1409105424710 = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'><i class='text-white fas fa-square'></i></button>";
							}
						}

						if (0 < strlen($C740da31596f24ef['stream_icon']) && XUI::$rSettings['show_images']) {
							$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . urlencode($C740da31596f24ef['stream_icon']) . "'><img loading='lazy' src='resize?maxw=96&maxh=32&url=" . urlencode($C740da31596f24ef['stream_icon']) . "' /></a>";
						} else {
							$E9c8d08bfb6ef33c = '';
						}

						$C3c8913edb801c35 = $C740da31596f24ef['id'];

						if ($F2d4d8f7981ac574['streams_grouped'] || 1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
						} else {
							$C3c8913edb801c35 .= '-' . $C740da31596f24ef['server_id'];
						}

						if ($Eabdab369bae73a8) {
							$a85e1b7d42c346a0['data'][] = array("<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'>" . $C3c8913edb801c35 . '</a>', $E9c8d08bfb6ef33c, $Ef28eaee0050d7a5, $B00ef71aa2cd7a26, $ec5b28bb1cbf9f2d, $fad73125a2cca3ed, $ebab77ef4bee81e0, $cafddc0a05fb9f1f, $b5e8b95fdf13ba62);
						} else {
							$a85e1b7d42c346a0['data'][] = array("<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'>" . $C3c8913edb801c35 . '</a>', $E9c8d08bfb6ef33c, $Ef28eaee0050d7a5, $B00ef71aa2cd7a26, $ec5b28bb1cbf9f2d, $fad73125a2cca3ed, $ebab77ef4bee81e0, $cafddc0a05fb9f1f, $d8a1409105424710, $b5e8b95fdf13ba62);
						}
					} else {
						unset($C740da31596f24ef['stream_source']);
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'radios') {
	if (aacd47d8157a1A09('adv', 'radio') || AaCd47d8157a1A09('adv', 'mass_edit_radio')) {
		$A5dcdeb6ecbbf6bd = CBE87e2a9a996111('radio');
		$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_icon`', '`streams`.`stream_display_name`', '`server_name`', '`clients`', '`streams_servers`.`stream_started`', false, '`streams_servers`.`bitrate`');

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
		$f86e19bdb1e7dae8[] = '`streams`.`type` = 4';

		if (isset(XUI::$rRequest['stream_id'])) {
			$f86e19bdb1e7dae8[] = '`streams`.`id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];
			$Ccfe11bd7a796290 = 'ORDER BY `streams_servers`.`server_stream_id` ASC';
		} else {
			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
			}

			if (0 < intval(XUI::$rRequest['category'])) {
				$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
				$Df2582e36fdd6160[] = XUI::$rRequest['category'];
			} else {
				if (intval(XUI::$rRequest['category']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
				}
			}

			if (!isset(XUI::$rRequest['refresh'])) {
			} else {
				$f86e19bdb1e7dae8 = array('`streams`.`id` IN (' . implode(',', array_map('intval', explode(',', XUI::$rRequest['refresh']))) . ')');
				$D031c48a1422c07e = 0;
				$E400a3101514583e = 1000;
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`stream_status` = 0)';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '((`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 1))';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND `streams_servers`.`on_demand` = 0)';
						} else {
							if (XUI::$rRequest['filter'] == 4) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 2)';
							} else {
								if (XUI::$rRequest['filter'] == 5) {
									$f86e19bdb1e7dae8[] = '`streams_servers`.`on_demand` = 1';
								} else {
									if (XUI::$rRequest['filter'] != 6) {
									} else {
										$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
									}
								}
							}
						}
					}
				}
			}

			if (0 < intval(XUI::$rRequest['server'])) {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
				$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			} else {
				if (intval(XUI::$rRequest['server']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
				}
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		if (!isset(XUI::$rRequest['single'])) {
		} else {
			$F2d4d8f7981ac574['streams_grouped'] = 0;
		}

		if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(DISTINCT(`streams`.`id`)) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
		} else {
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
		}

		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_icon`, `streams`.`movie_properties`, `streams_servers`.`to_analyze`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_icon`, `streams`.`type`, `streams_servers`.`cchannel_rsources`, `streams`.`stream_source`, `streams`.`stream_display_name`, `streams`.`tv_archive_duration`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams_servers`.`parent_id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			}

			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$caa77b80211665a0 = $Cdb85875fd50f459 = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
					}

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						if ($F2d4d8f7981ac574['streams_grouped']) {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, true, true);
						} else {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, false, false);
						}
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!XUI::$rSettings['redis_handler']) {
					} else {
						if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
							$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
						} else {
							$C740da31596f24ef['clients'] = (count($bde5957fb5fa9547[$C740da31596f24ef['id']][$C740da31596f24ef['server_id']]) ?: 0);
						}
					}

					if (!$B3f0f4a134021073) {
						$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

						if (0 < strlen(XUI::$rRequest['category'])) {
							$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
						} else {
							$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
						}

						if (1 >= count($A38b42a281e3c3cf)) {
						} else {
							$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
						}

						$Ef28eaee0050d7a5 = "<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'><strong>" . $C740da31596f24ef['stream_display_name'] . "</strong><br><span style='font-size:11px;'>" . $A1925ae53e9307eb . '</span></a>';

						if ($C740da31596f24ef['server_name']) {
							if (aaCD47d8157A1a09('adv', 'servers')) {
								$B00ef71aa2cd7a26 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
							} else {
								$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];
							}

							if (!($F2d4d8f7981ac574['streams_grouped'] && 1 < $caa77b80211665a0[$C740da31596f24ef['id']])) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"View All Servers\" onClick=\"viewSources('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', " . intval($C740da31596f24ef['id']) . ");\" type='button' class='tooltip-left btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
							}

							if ($a8bb73cba48fb7f6[$C740da31596f24ef['server_id']]['last_status'] == 1) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"Server Offline!<br/>Uptime cannot be confirmed.\" type='button' class='tooltip btn btn-danger btn-xs waves-effect waves-light'><i class='mdi mdi-alert'></i></button>";
							}
						} else {
							$B00ef71aa2cd7a26 = 'No Server Selected';
						}

						if ($F2d4d8f7981ac574['streams_grouped']) {
						} else {
							if (0 < intval($C740da31596f24ef['parent_id'])) {
								$ecc9029bfbc77eed = "<br/><span style='font-size:11px;'>loop: " . strtolower(XUI::$rServers[$C740da31596f24ef['parent_id']]['server_name']) . '</span>';
							} else {
								$ecc9029bfbc77eed = "<br/><span style='font-size:11px;'>" . strtolower(parse_url($C740da31596f24ef['current_source'])['host']) . '</span>';
							}

							$B00ef71aa2cd7a26 .= $ecc9029bfbc77eed;
						}

						$fad73125a2cca3ed = 0;
						$b45800af0138159b = 0;

						if (0 >= intval($C740da31596f24ef['stream_started'])) {
						} else {
							$fad73125a2cca3ed = time() - intval($C740da31596f24ef['stream_started']);
						}

						if ($C740da31596f24ef['server_id']) {
							if (intval($C740da31596f24ef['direct_source']) == 1) {
								$b45800af0138159b = 5;
							} else {
								if ($C740da31596f24ef['monitor_pid']) {
									if ($C740da31596f24ef['pid'] && 0 < $C740da31596f24ef['pid']) {
										if (intval($C740da31596f24ef['stream_status']) == 2) {
											$b45800af0138159b = 2;
										} else {
											$b45800af0138159b = 1;
										}
									} else {
										if ($C740da31596f24ef['stream_status'] == 0) {
											$b45800af0138159b = 2;
										} else {
											$b45800af0138159b = 3;
										}
									}
								} else {
									if (intval($C740da31596f24ef['on_demand']) == 1) {
										$b45800af0138159b = 4;
									} else {
										$b45800af0138159b = 0;
									}
								}
							}
						} else {
							$b45800af0138159b = -1;
						}

						if ($C740da31596f24ef['server_id']) {
						} else {
							$C740da31596f24ef['server_id'] = 0;
						}

						if ($F2d4d8f7981ac574['streams_grouped'] != 1) {
						} else {
							$C740da31596f24ef['server_id'] = -1;
						}

						if (AAcd47D8157A1a09('adv', 'live_connections')) {
							if (0 < $C740da31596f24ef['clients']) {
								$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ', ' . intval($C740da31596f24ef['server_id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button></a>';
							} else {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}
						} else {
							if (0 < $C740da31596f24ef['clients']) {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button>';
							} else {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}
						}

						if ($b45800af0138159b == 1) {
							if (86400 <= $fad73125a2cca3ed) {
								$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
							} else {
								$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
							}

							$fad73125a2cca3ed = "<button type='button' class='btn btn-success btn-xs waves-effect waves-light btn-fixed-xl'>" . $fad73125a2cca3ed . '</button>';
						} else {
							if ($b45800af0138159b == 3) {
								$fad73125a2cca3ed = "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light btn-fixed-xl'>DOWN</button>";
							} else {
								$fad73125a2cca3ed = $F8b5842eeedab682[$b45800af0138159b];
							}
						}

						$fad73125a2cca3ed = str_replace("btn-fixed'", "btn-fixed-xl'", $fad73125a2cca3ed);

						if (XUI::$rSettings['group_buttons']) {
							$ebab77ef4bee81e0 = '';

							if (0 >= strlen($C740da31596f24ef['notes'])) {
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

							if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && aacd47D8157A1A09('adv', 'edit_radio')) {
								if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop</a>" . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\">Restart</a>" . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\">Kill Connections</a>";
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Start</a>";
								}

								if (!isset(XUI::$rRequest['single'])) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
								}
							} else {
								if (!aACD47d8157A1A09('adv', 'edit_radio')) {
								} else {
									if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop</a>" . "\r\n\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\">Restart</a>" . "\r\n\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\">Kill Connections</a>";
									} else {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Start</a>";
									}

									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="radio?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'radio', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>' . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
								}
							}

							$ebab77ef4bee81e0 .= '</div></div>';
						} else {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && aACD47d8157A1a09('adv', 'edit_radio')) {
								if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
									$ebab77ef4bee81e0 .= '<button title="Stop" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
									$Ba23222f3ed2dc08 = '';
								} else {
									$ebab77ef4bee81e0 .= '<button title="Start" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
									$Ba23222f3ed2dc08 = ' disabled';
								}

								$ebab77ef4bee81e0 .= '<button title="Restart" type="button" class="btn btn-light waves-effect waves-light btn-xs api-restart tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-refresh"></i></button>';

								if (!isset(XUI::$rRequest['single'])) {
								} else {
									$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}
							} else {
								if (0 < strlen($C740da31596f24ef['notes'])) {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
								}

								if (!aAcd47d8157a1a09('adv', 'edit_radio')) {
								} else {
									if (intval($b45800af0138159b) == 1 || intval($b45800af0138159b) == 2 || intval($b45800af0138159b) == 3 || $C740da31596f24ef['on_demand'] == 1 || $b45800af0138159b == 5) {
										$ebab77ef4bee81e0 .= '<button title="Stop" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
										$Ba23222f3ed2dc08 = '';
									} else {
										$ebab77ef4bee81e0 .= '<button title="Start" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
										$Ba23222f3ed2dc08 = ' disabled';
									}

									$ebab77ef4bee81e0 .= '<button title="Restart" type="button" class="btn btn-light waves-effect waves-light btn-xs api-restart tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'restart');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-refresh"></i></button>' . "\r\n\t\t\t\t\t\t\t" . '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'purge');\"" . $Ba23222f3ed2dc08 . '><i class="mdi mdi-hammer"></i></button>' . "\r\n\t\t\t\t\t\t\t" . '<a href="radio?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'radio', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>' . "\r\n\t\t\t\t\t\t\t" . '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}
							}

							$ebab77ef4bee81e0 .= '</div>';
						}

						$b5e8b95fdf13ba62 = "<table style='font-size: 10px;' class='table-data nowrap' align='center'><tbody><tr><td colspan='5'>No information available</td></tr></tbody></table>";
						$bb0071da5a239b0c = json_decode($C740da31596f24ef['stream_info'], true);
						$E7b0c34a84ef92b9 = json_decode($C740da31596f24ef['progress_info'], true);

						if ($b45800af0138159b != 1) {
						} else {
							if (isset($bb0071da5a239b0c['codecs']['video'])) {
							} else {
								$bb0071da5a239b0c['codecs']['video'] = array('width' => '?', 'height' => '?', 'codec_name' => 'N/A', 'r_frame_rate' => '--');
							}

							if (isset($bb0071da5a239b0c['codecs']['audio'])) {
							} else {
								$bb0071da5a239b0c['codecs']['audio'] = array('codec_name' => 'N/A');
							}

							if ($C740da31596f24ef['bitrate'] != 0) {
							} else {
								$C740da31596f24ef['bitrate'] = '?';
							}

							if (isset($E7b0c34a84ef92b9['speed'])) {
								$a31f32f586013061 = floor($E7b0c34a84ef92b9['speed'] * 100) / 100 . 'x';
							} else {
								$a31f32f586013061 = '1x';
							}

							$b5e8b95fdf13ba62 = "<table class='table-data nowrap table-data-90' align='center'>" . "\r\n" . '                        <tbody>' . "\r\n" . '                            <tr>' . "\r\n" . "                                <td class='text-success'><i class='mdi mdi-video' data-name='mdi-video'></i></td>" . "\r\n" . "                                <td class='text-success'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>" . "\r\n" . "                                <td class='text-success'><i class='mdi mdi-play-speed' data-name='mdi-play-speed'></i></td>" . "\r\n" . '                            </tr>' . "\r\n" . '                            <tr>' . "\r\n" . '                                <td>' . $C740da31596f24ef['bitrate'] . ' Kbps</td>' . "\r\n" . '                                <td>' . $bb0071da5a239b0c['codecs']['audio']['codec_name'] . '</td>' . "\r\n" . '                                <td>' . $a31f32f586013061 . '</td>' . "\r\n" . '                            </tr>' . "\r\n" . '                        </tbody>' . "\r\n" . '                    </table>';
						}

						if (0 < strlen($C740da31596f24ef['stream_icon']) && XUI::$rSettings['show_images']) {
							$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['stream_icon'] . "'><img loading='lazy' src='resize?maxw=96&maxh=32&url=" . $C740da31596f24ef['stream_icon'] . "' /></a>";
						} else {
							$E9c8d08bfb6ef33c = '';
						}

						$C3c8913edb801c35 = $C740da31596f24ef['id'];

						if ($F2d4d8f7981ac574['streams_grouped'] || 1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
						} else {
							$C3c8913edb801c35 .= '-' . $C740da31596f24ef['server_id'];
						}

						$a85e1b7d42c346a0['data'][] = array("<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'>" . $C3c8913edb801c35 . '</a>', $E9c8d08bfb6ef33c, $Ef28eaee0050d7a5, $B00ef71aa2cd7a26, $ec5b28bb1cbf9f2d, $fad73125a2cca3ed, $ebab77ef4bee81e0, $b5e8b95fdf13ba62);
					} else {
						unset($C740da31596f24ef['stream_source']);
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'movies') {
	if (aAcd47D8157A1a09('adv', 'movies') || aACd47d8157A1A09('adv', 'mass_sedits_vod')) {
		$A5dcdeb6ecbbf6bd = cBE87e2a9A996111('movie');
		$c6c389b9adf3a40c = array('`streams`.`id`', false, '`streams`.`stream_display_name`', '`server_name`', '`clients`', '`streams_servers`.`stream_started`', false, false, false, '`streams_servers`.`bitrate`');

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
		$f86e19bdb1e7dae8[] = '`streams`.`type` = 2';
		$f69f03301cf5dc4e = false;

		if (isset(XUI::$rRequest['stream_id'])) {
			$f86e19bdb1e7dae8[] = '`streams`.`id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];
			$Ccfe11bd7a796290 = 'ORDER BY `streams_servers`.`server_stream_id` ASC';
		} else {
			if (isset(XUI::$rRequest['source_id'])) {
				$f86e19bdb1e7dae8[] = 'MD5(`streams`.`stream_source`) = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['source_id'];
				$Ccfe11bd7a796290 = 'ORDER BY `streams_servers`.`server_stream_id` ASC';
			} else {
				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 4) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
				}

				if (0 < intval(XUI::$rRequest['category'])) {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category'];
				} else {
					if (intval(XUI::$rRequest['category']) != -1) {
					} else {
						$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
					}
				}

				if (!isset(XUI::$rRequest['refresh'])) {
				} else {
					$f86e19bdb1e7dae8 = array('`streams`.`id` IN (' . implode(',', array_map('intval', explode(',', XUI::$rRequest['refresh']))) . ')');
					$D031c48a1422c07e = 0;
					$E400a3101514583e = 1000;
				}

				if (0 >= strlen(XUI::$rRequest['filter'])) {
				} else {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` <> 1)';
					} else {
						if (XUI::$rRequest['filter'] == 2) {
							$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 1 AND `streams_servers`.`stream_status` <> 1)';
						} else {
							if (XUI::$rRequest['filter'] == 3) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` = 1)';
							} else {
								if (XUI::$rRequest['filter'] == 4) {
									$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 1)';
								} else {
									if (XUI::$rRequest['filter'] == 5) {
										$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
									} else {
										if (XUI::$rRequest['filter'] == 6) {
											$f86e19bdb1e7dae8[] = "(`streams`.`movie_properties` IS NULL OR `streams`.`movie_properties` = '' OR `streams`.`movie_properties` = '[]' OR `streams`.`movie_properties` = '{}' OR `streams`.`movie_properties` LIKE '%tmdb_id\":\"\"%')";
										} else {
											if (XUI::$rRequest['filter'] == 7) {
												$f86e19bdb1e7dae8[] = '`streams`.`id` IN (SELECT MIN(`id`) FROM `streams` WHERE `type` = 2 GROUP BY `stream_source` HAVING COUNT(`stream_source`) > 1)';
												$f69f03301cf5dc4e = true;
											} else {
												if (XUI::$rRequest['filter'] != 8) {
												} else {
													$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
												}
											}
										}
									}
								}
							}
						}
					}
				}

				if (0 >= strlen(XUI::$rRequest['audio'])) {
				} else {
					if (XUI::$rRequest['audio'] == -1) {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`audio_codec` IS NULL';
					} else {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`audio_codec` = ?';
						$Df2582e36fdd6160[] = XUI::$rRequest['audio'];
					}
				}

				if (0 >= strlen(XUI::$rRequest['video'])) {
				} else {
					if (XUI::$rRequest['video'] == -1) {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`video_codec` IS NULL';
					} else {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`video_codec` = ?';
						$Df2582e36fdd6160[] = XUI::$rRequest['video'];
					}
				}

				if (0 >= strlen(XUI::$rRequest['resolution'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`resolution` = ?';
					$Df2582e36fdd6160[] = (intval(XUI::$rRequest['resolution']) ?: null);
				}

				if (0 < intval(XUI::$rRequest['server'])) {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
					$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
				} else {
					if (intval(XUI::$rRequest['server']) != -1) {
					} else {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
					}
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}
			}
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		if (isset(XUI::$rRequest['single'])) {
			$F2d4d8f7981ac574['streams_grouped'] = 0;
		} else {
			if (!isset(XUI::$rRequest['grouped'])) {
			} else {
				$F2d4d8f7981ac574['streams_grouped'] = 1;
			}
		}

		if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(DISTINCT(`streams`.`id`)) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
		} else {
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
		}

		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, MD5(`streams`.`stream_source`) AS `source`, `streams`.`movie_properties`, `streams`.`year`, `streams_servers`.`to_analyze`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, MD5(`streams`.`stream_source`) AS `source`, `streams`.`movie_properties`, `streams`.`year`, `streams_servers`.`to_analyze`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			}

			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$caa77b80211665a0 = $Cdb85875fd50f459 = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
					}

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						if ($F2d4d8f7981ac574['streams_grouped']) {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, true, true);
						} else {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, false, false);
						}
					}

					if (!$f69f03301cf5dc4e) {
					} else {
						$d94e5f0792c69064 = array();
						$Fee0d5a474c96306->query('SELECT MD5(`stream_source`) AS `source`, COUNT(`stream_source`) AS `count` FROM `streams` WHERE `stream_source` IN (SELECT `stream_source` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ')) GROUP BY `stream_source` HAVING COUNT(`stream_source`) > 1;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$d94e5f0792c69064[$C740da31596f24ef['source']] = $C740da31596f24ef['count'];
						}
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!XUI::$rSettings['redis_handler']) {
					} else {
						if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
							$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
						} else {
							$C740da31596f24ef['clients'] = (count($bde5957fb5fa9547[$C740da31596f24ef['id']][$C740da31596f24ef['server_id']]) ?: 0);
						}
					}

					if (!$B3f0f4a134021073) {
						$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);
						$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);
						$e962a80487b84e46 = '';

						if (!$D92b16dc36690ab9['rating']) {
						} else {
							$B0ac3a61df74ba36 = round($D92b16dc36690ab9['rating']) / 2;
							$d25560ad0b146132 = floor($B0ac3a61df74ba36);
							$b39c3caa0856cfa2 = 0 < $B0ac3a61df74ba36 - $d25560ad0b146132;
							$D46dfa8113384246 = 5 - ($d25560ad0b146132 + (($b39c3caa0856cfa2 ? 1 : 0)));

							if (0 >= $d25560ad0b146132) {
							} else {
								foreach (range(1, $d25560ad0b146132) as $Ea22c4a9ab5b2176) {
									$e962a80487b84e46 .= "<i class='mdi mdi-star'></i>";
								}
							}

							if (!$b39c3caa0856cfa2) {
							} else {
								$e962a80487b84e46 .= "<i class='mdi mdi-star-half'></i>";
							}

							if (0 >= $D46dfa8113384246) {
							} else {
								foreach (range(1, $D46dfa8113384246) as $Ea22c4a9ab5b2176) {
									$e962a80487b84e46 .= "<i class='mdi mdi-star-outline'></i>";
								}
							}
						}

						if (0 < strlen(XUI::$rRequest['category'])) {
							$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
						} else {
							$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
						}

						if (1 >= count($A38b42a281e3c3cf)) {
						} else {
							$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
						}

						$A02729c83b6cd395 = ($C740da31596f24ef['year'] ? '<strong>' . $C740da31596f24ef['year'] . '</strong> &nbsp;' : '');
						$Ef28eaee0050d7a5 = "<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'><strong>" . $C740da31596f24ef['stream_display_name'] . "</strong><br><span style='font-size:11px;'>" . $A02729c83b6cd395 . $e962a80487b84e46 . '<br/>' . $A1925ae53e9307eb . '</span></a>';

						if ($C740da31596f24ef['server_name']) {
							if (AaCD47D8157A1a09('adv', 'servers')) {
								$B00ef71aa2cd7a26 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
							} else {
								$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];
							}

							if (!($F2d4d8f7981ac574['streams_grouped'] && 1 < $caa77b80211665a0[$C740da31596f24ef['id']])) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"View All Servers\" onClick=\"viewSources('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', " . intval($C740da31596f24ef['id']) . ");\" type='button' class='tooltip-left btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
							}

							if ($a8bb73cba48fb7f6[$C740da31596f24ef['server_id']]['last_status'] == 1) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"Server Offline!<br/>Uptime cannot be confirmed.\" type='button' class='tooltip btn btn-danger btn-xs waves-effect waves-light'><i class='mdi mdi-alert'></i></button>";
							}
						} else {
							$B00ef71aa2cd7a26 = 'No Server Selected';
						}

						$fad73125a2cca3ed = 0;

						if ($C740da31596f24ef['server_id']) {
							$b45800af0138159b = 0;

							if (intval($C740da31596f24ef['direct_source']) == 1) {
								if (intval($C740da31596f24ef['direct_proxy']) == 1) {
									$b45800af0138159b = 5;
								} else {
									$b45800af0138159b = 3;
								}
							} else {
								if (!is_null($C740da31596f24ef['pid']) && 0 < $C740da31596f24ef['pid']) {
									if ($C740da31596f24ef['to_analyze'] == 1) {
										$b45800af0138159b = 2;
									} else {
										if ($C740da31596f24ef['stream_status'] == 1) {
											$b45800af0138159b = 4;
										} else {
											$b45800af0138159b = 1;
										}
									}
								} else {
									$b45800af0138159b = 0;
								}
							}
						} else {
							$b45800af0138159b = -1;
						}

						if ($C740da31596f24ef['server_id']) {
						} else {
							$C740da31596f24ef['server_id'] = 0;
						}

						if ($F2d4d8f7981ac574['streams_grouped'] != 1) {
						} else {
							$C740da31596f24ef['server_id'] = -1;
						}

						if (AACD47D8157a1A09('adv', 'live_connections')) {
							if (0 < $C740da31596f24ef['clients']) {
								$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ', ' . intval($C740da31596f24ef['server_id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button></a>';
							} else {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}
						} else {
							if (0 < $C740da31596f24ef['clients']) {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button>';
							} else {
								$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}
						}

						if (XUI::$rSettings['group_buttons']) {
							$ebab77ef4bee81e0 = '';

							if (0 >= strlen($C740da31596f24ef['notes'])) {
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

							if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && AaCD47D8157a1A09('adv', 'edit_movie')) {
								if (intval($b45800af0138159b) == 1) {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Encode</a>";
								} else {
									if (intval($b45800af0138159b) == 3) {
									} else {
										if (intval($b45800af0138159b) == 2) {
											$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop Encoding</a>";
										} else {
											$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Start Encoding</a>";
										}
									}
								}

								if (!isset(XUI::$rRequest['single'])) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
								}
							} else {
								if (!aACD47D8157a1a09('adv', 'edit_movie')) {
								} else {
									if (intval($b45800af0138159b) == 1) {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Encode</a>";
									} else {
										if (intval($b45800af0138159b) == 3) {
										} else {
											if (intval($b45800af0138159b) == 2) {
												$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop Encoding</a>";
											} else {
												$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Start Encoding</a>";
											}
										}
									}

									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="movie?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'movie', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>' . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
								}
							}

							$ebab77ef4bee81e0 .= '</div></div>';
						} else {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && aACd47d8157a1A09('adv', 'edit_movie')) {
								if (intval($b45800af0138159b) == 1) {
									$ebab77ef4bee81e0 .= '<button title="Encode" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-refresh\"></i></button>";
								} else {
									if (intval($b45800af0138159b) == 3 || intval($b45800af0138159b) == 5) {
										$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop"><i class="mdi mdi-stop"></i></button>';
									} else {
										if (intval($b45800af0138159b) == 2) {
											$ebab77ef4bee81e0 .= '<button title="Stop Encoding" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
										} else {
											$ebab77ef4bee81e0 .= '<button title="Start Encoding" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
										}
									}
								}

								if (!isset(XUI::$rRequest['single'])) {
								} else {
									$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}
							} else {
								if (0 < strlen($C740da31596f24ef['notes'])) {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
								}

								if (!aACD47D8157a1a09('adv', 'edit_movie')) {
								} else {
									if (intval($b45800af0138159b) == 1) {
										$ebab77ef4bee81e0 .= '<button title="Encode" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-refresh\"></i></button>";
									} else {
										if (intval($b45800af0138159b) == 3 || intval($b45800af0138159b) == 5) {
											$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop"><i class="mdi mdi-stop"></i></button>';
										} else {
											if (intval($b45800af0138159b) == 2) {
												$ebab77ef4bee81e0 .= '<button title="Stop Encoding" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
											} else {
												$ebab77ef4bee81e0 .= '<button title="Start Encoding" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
											}
										}
									}

									$ebab77ef4bee81e0 .= '<a href="movie?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'movie', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>' . "\r\n\t\t\t\t\t\t\t" . '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}
							}

							$ebab77ef4bee81e0 .= '</div>';
						}

						if ($f69f03301cf5dc4e) {
							$Baeca850f087a7a2 = ($d94e5f0792c69064[$C740da31596f24ef['source']] - 1 ?: 0);
							$b5e8b95fdf13ba62 = "<a href='javascript: void(0);' onClick=\"viewDuplicates('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', '" . $C740da31596f24ef['source'] . "');\">Duplicate of <strong>" . $Baeca850f087a7a2 . '</strong> other movie' . (($Baeca850f087a7a2 == 1 ? '' : 's')) . '</a>';
						} else {
							$b5e8b95fdf13ba62 = "<table style='font-size: 10px;' class='table-data nowrap' align='center'><tbody><tr><td colspan='3'>No information available</td></tr></tbody></table>";
							$bb0071da5a239b0c = json_decode($C740da31596f24ef['stream_info'], true);

							if ($b45800af0138159b != 1) {
							} else {
								if (isset($bb0071da5a239b0c['codecs']['video'])) {
								} else {
									$bb0071da5a239b0c['codecs']['video'] = array('width' => '?', 'height' => '?', 'codec_name' => 'N/A', 'r_frame_rate' => '--');
								}

								if (isset($bb0071da5a239b0c['codecs']['audio'])) {
								} else {
									$bb0071da5a239b0c['codecs']['audio'] = array('codec_name' => 'N/A');
								}

								if ($C740da31596f24ef['bitrate'] != 0) {
								} else {
									$C740da31596f24ef['bitrate'] = '?';
								}

								$C5034884ed44603a = (empty($bb0071da5a239b0c['duration']) ? '--' : substr($bb0071da5a239b0c['duration'], 0, 5));
								$b5e8b95fdf13ba62 = "<table class='table-data nowrap table-data-120 text-center' align='center'>" . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='double'>" . number_format($C740da31596f24ef['bitrate'], 0) . ' Kbps</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='text-success'><i class='mdi mdi-video' data-name='mdi-video'></i></td>" . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='text-success'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>" . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='text-success'><i class='mdi mdi-clock' data-name='mdi-clock'></i></td>" . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='double'>" . $bb0071da5a239b0c['codecs']['video']['width'] . ' x ' . $bb0071da5a239b0c['codecs']['video']['height'] . '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . $bb0071da5a239b0c['codecs']['video']['codec_name'] . '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . $bb0071da5a239b0c['codecs']['audio']['codec_name'] . '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . $C5034884ed44603a . '</td>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t" . '</table>';
							}
						}

						if (AAcD47d8157a1a09('adv', 'player')) {
							if (intval($b45800af0138159b) == 1 || $b45800af0138159b == 3) {
								if (empty($bb0071da5a239b0c['codecs']['video']['codec_name']) || strtoupper($bb0071da5a239b0c['codecs']['video']['codec_name']) == 'H264' || strtoupper($bb0071da5a239b0c['codecs']['video']['codec_name']) == 'N/A') {
									$cafddc0a05fb9f1f = '<button title="Play" type="button" class="btn btn-info waves-effect waves-light btn-xs tooltip" onClick="player(' . $C740da31596f24ef['id'] . ", '" . $C740da31596f24ef['target_container'] . "');\"><i class=\"mdi mdi-play\"></i></button>";
								} else {
									$cafddc0a05fb9f1f = '<button type="button" class="btn btn-dark waves-effect waves-light btn-xs tooltip" title="Incompatible Video Codec"><i class="mdi mdi-play"></i></button>';
								}
							} else {
								$cafddc0a05fb9f1f = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button>';
							}
						} else {
							$cafddc0a05fb9f1f = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button>';
						}

						if (0 < strlen($D92b16dc36690ab9['movie_image']) && XUI::$rSettings['show_images']) {
							$A639a7baefc720ee = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $D92b16dc36690ab9['movie_image'] . "'><img loading='lazy' src='resize?maxh=58&maxw=32&url=" . $D92b16dc36690ab9['movie_image'] . "' /></a>";
						} else {
							$A639a7baefc720ee = '';
						}

						if (isset($D92b16dc36690ab9['kinopoisk_url']) && 0 < strlen($D92b16dc36690ab9['kinopoisk_url'])) {
							$a69d576081840514 = '<button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-check-circle"></i></button>';
						} else {
							$a69d576081840514 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-minus-circle"></i></button>';
						}

						$C3c8913edb801c35 = $C740da31596f24ef['id'];

						if ($F2d4d8f7981ac574['streams_grouped'] || 1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
						} else {
							$C3c8913edb801c35 .= '-' . $C740da31596f24ef['server_id'];
						}

						$a85e1b7d42c346a0['data'][] = array("<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'>" . $C3c8913edb801c35 . '</a>', $A639a7baefc720ee, $Ef28eaee0050d7a5, $B00ef71aa2cd7a26, $ec5b28bb1cbf9f2d, $f45f1268c76ac2a3[$b45800af0138159b], $a69d576081840514, $ebab77ef4bee81e0, $cafddc0a05fb9f1f, $b5e8b95fdf13ba62);
					} else {
						unset($a85e1b7d42c346a0['source']);
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'episode_list') {
	if (AaCd47d8157a1A09('adv', 'import_episodes') || AACd47D8157a1a09('adv', 'mass_delete')) {
		$c6c389b9adf3a40c = array('`streams`.`id`', false, '`streams`.`stream_display_name`', '`streams_servers`.`server_id`', '`streams_servers`.`stream_status`');

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
		$f86e19bdb1e7dae8[] = '`streams`.`type` = 5';

		if (0 < intval(XUI::$rRequest['server'])) {
			$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
			$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
		} else {
			if (intval(XUI::$rRequest['server']) != -1) {
			} else {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
			}
		}

		if (0 >= strlen(XUI::$rRequest['series'])) {
		} else {
			$f86e19bdb1e7dae8[] = '`streams_episodes`.`series_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['series'];
		}

		if (0 >= strlen(XUI::$rRequest['search']['value'])) {
		} else {
			foreach (range(1, 5) as $b6f0b24a56fe41b6) {
				$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
			}
			$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams_series`.`title` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
		}

		if (0 >= strlen(XUI::$rRequest['filter'])) {
		} else {
			if (XUI::$rRequest['filter'] == 1) {
				$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` <> 1)';
			} else {
				if (XUI::$rRequest['filter'] == 2) {
					$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 1 AND `streams_servers`.`stream_status` <> 1)';
				} else {
					if (XUI::$rRequest['filter'] == 3) {
						$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`stream_status` = 1)';
					} else {
						if (XUI::$rRequest['filter'] == 4) {
							$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 1)';
						} else {
							if (XUI::$rRequest['filter'] == 5) {
								$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
							} else {
								if (XUI::$rRequest['filter'] != 7) {
								} else {
									$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
								}
							}
						}
					}
				}
			}
		}

		if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
		} else {
			$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
			$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		$Fc3bbe383da3a3f3 = 'SELECT COUNT(DISTINCT(`streams`.`id`)) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ';';
		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if (0 < $Fee0d5a474c96306->num_rows()) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			$A6d7047f2fda966c = 'SELECT `streams`.`id`, MD5(`streams`.`stream_source`) AS `source`, `streams_servers`.`to_analyze`, `streams`.`movie_properties`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams_series`.`title`, `streams_series`.`seasons`, `streams_series`.`id` AS `sid`, `streams_episodes`.`season_num` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$caa77b80211665a0 = $Cdb85875fd50f459 = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!$B3f0f4a134021073) {
						$b45800af0138159b = 0;

						if (intval($C740da31596f24ef['direct_source']) == 1) {
							if (intval($C740da31596f24ef['direct_proxy']) == 1) {
								$b45800af0138159b = 5;
							} else {
								$b45800af0138159b = 3;
							}
						} else {
							if (!is_null($C740da31596f24ef['pid']) && 0 < $C740da31596f24ef['pid']) {
								if ($C740da31596f24ef['to_analyze'] == 1) {
									$b45800af0138159b = 2;
								} else {
									if ($C740da31596f24ef['stream_status'] == 1) {
										$b45800af0138159b = 4;
									} else {
										$b45800af0138159b = 1;
									}
								}
							} else {
								$b45800af0138159b = 0;
							}
						}

						$dc850cbc5eb6f918 = $C740da31596f24ef['title'] . ' - Season ' . $C740da31596f24ef['season_num'];
						$Ef28eaee0050d7a5 = '<strong>' . $C740da31596f24ef['stream_display_name'] . "</strong><br><span style='font-size:11px;'>" . $dc850cbc5eb6f918 . '</span>';

						if ($C740da31596f24ef['server_name']) {
							$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];

							if (1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
							} else {
								$B00ef71aa2cd7a26 .= " &nbsp; <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
							}
						} else {
							$B00ef71aa2cd7a26 = 'No Server Selected';
						}

						$A639a7baefc720ee = '';
						$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);

						if (!(0 < strlen($D92b16dc36690ab9['movie_image']) && XUI::$rSettings['show_images'])) {
						} else {
							$A639a7baefc720ee = "<a href='javascript: void(0);' data-src='resize?maxw=512&maxh=512&url=" . $D92b16dc36690ab9['movie_image'] . "'><img loading='lazy' src='resize?maxh=32&maxw=64&url=" . $D92b16dc36690ab9['movie_image'] . "' /></a>";
						}

						$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $A639a7baefc720ee, $Ef28eaee0050d7a5, $B00ef71aa2cd7a26, $f45f1268c76ac2a3[$b45800af0138159b]);
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'line_activity') {
	if (aaCd47d8157a1A09('adv', 'connection_logs')) {
		$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
		$c6c389b9adf3a40c = array('`username` ' . $cb10faf5ade31619 . ', `lines_activity`.`hmac_identifier`', '`streams`.`stream_display_name`', '`server_name`', '`lines_activity`.`user_agent`', '`lines_activity`.`isp`', '`lines_activity`.`user_ip`', '`lines_activity`.`date_start`', '`lines_activity`.`activity_id`', '`lines_activity`.`date_end` - `lines_activity`.`date_start`', '`lines_activity`.`container`', '`lines`.`is_restreamer`');

		if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
			$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
		} else {
			$C1633246b8426116 = 0;
		}

		$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

		if (0 >= strlen(XUI::$rRequest['search']['value'])) {
		} else {
			foreach (range(1, 7) as $b6f0b24a56fe41b6) {
				$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
			}
			$f86e19bdb1e7dae8[] = '(`lines_activity`.`hmac_identifier` LIKE ? OR `lines_activity`.`user_agent` LIKE ? OR `lines_activity`.`user_ip` LIKE ? OR `lines_activity`.`container` LIKE ? OR FROM_UNIXTIME(`lines_activity`.`date_start`) LIKE ? OR FROM_UNIXTIME(`lines_activity`.`date_end`) LIKE ? OR `lines_activity`.`geoip_country_code` LIKE ?)';
		}

		if (0 >= strlen(XUI::$rRequest['range'])) {
		} else {
			$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
			$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

			if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
			} else {
				$a859a0996bb0f1ff = null;
			}

			if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
			} else {
				$B37c1f185be84c33 = null;
			}

			if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
			} else {
				$f86e19bdb1e7dae8[] = '(`lines_activity`.`date_start` >= ? AND `lines_activity`.`date_end` <= ?)';
				$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
				$Df2582e36fdd6160[] = $B37c1f185be84c33;
			}
		}

		if (0 >= strlen(XUI::$rRequest['stream'])) {
		} else {
			$f86e19bdb1e7dae8[] = '`lines_activity`.`stream_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['stream'];
		}

		if (0 >= strlen(XUI::$rRequest['user'])) {
		} else {
			$f86e19bdb1e7dae8[] = '`lines_activity`.`user_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['user'];
		}

		if (0 >= intval(XUI::$rRequest['server'])) {
		} else {
			$f86e19bdb1e7dae8[] = '(`lines_activity`.`server_id` = ? OR `lines_activity`.`proxy_id` = ?)';
			$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
		}

		if (0 < count($f86e19bdb1e7dae8)) {
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
		} else {
			$ff9d21c7a9d310b1 = '';
		}

		if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
		} else {
			$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
		}

		$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines_activity` ' . $ff9d21c7a9d310b1 . ';';
		$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

		if ($Fee0d5a474c96306->num_rows() == 1) {
			$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
		} else {
			$a85e1b7d42c346a0['recordsTotal'] = 0;
		}

		$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

		if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
		} else {
			$A6d7047f2fda966c = 'SELECT `lines`.`username`, `lines`.`is_e2`, `lines`.`is_mag`, `lines_activity`.`activity_id`, `lines_activity`.`hmac_identifier`, `lines_activity`.`hmac_id`, `lines_activity`.`proxy_id`, `lines_activity`.`container`, `lines_activity`.`isp`, `lines_activity`.`user_id`, `lines_activity`.`stream_id`, `streams`.`series_no`, `lines_activity`.`server_id`, `lines_activity`.`user_agent`, `lines_activity`.`user_ip`, `lines_activity`.`container`, `lines_activity`.`date_start`, `lines_activity`.`date_end`, `lines_activity`.`geoip_country_code`, `streams`.`stream_display_name`, `streams`.`type`, (SELECT `server_name` FROM `servers` WHERE `id` = `lines_activity`.`server_id`) AS `server_name`, `lines`.`is_restreamer` FROM `lines_activity` LEFT JOIN `lines` ON `lines_activity`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_activity`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
			$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				$Fdc8e0fc5edb3ca8 = $A85539af09e9d8ee = $B4ca62ca86c3d576 = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!$C740da31596f24ef['is_mag']) {
					} else {
						$A85539af09e9d8ee[] = intval($C740da31596f24ef['user_id']);
					}

					if (!$C740da31596f24ef['is_e2']) {
					} else {
						$B4ca62ca86c3d576[] = intval($C740da31596f24ef['user_id']);
					}

					if (!($C740da31596f24ef['is_mag'] || $C740da31596f24ef['is_e2'])) {
					} else {
						$Fdc8e0fc5edb3ca8[intval($C740da31596f24ef['user_id'])] = array('device_id' => null, 'device_name' => null);
					}
				}

				if (0 >= count($A85539af09e9d8ee)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `user_id`, `mag_id`, `mac` FROM `mag_devices` WHERE `user_id` IN (' . implode(',', $A85539af09e9d8ee) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$Fdc8e0fc5edb3ca8[intval($C740da31596f24ef['user_id'])]['device_id'] = $C740da31596f24ef['mag_id'];
						$Fdc8e0fc5edb3ca8[intval($C740da31596f24ef['user_id'])]['device_name'] = $C740da31596f24ef['mac'];
					}
				}

				if (0 >= count($B4ca62ca86c3d576)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `user_id`, `device_id`, `mac` FROM `enigma2_devices` WHERE `user_id` IN (' . implode(',', $B4ca62ca86c3d576) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$Fdc8e0fc5edb3ca8[intval($C740da31596f24ef['user_id'])]['device_id'] = $C740da31596f24ef['device_id'];
						$Fdc8e0fc5edb3ca8[intval($C740da31596f24ef['user_id'])]['device_name'] = $C740da31596f24ef['mac'];
					}
				}

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!isset($Fdc8e0fc5edb3ca8[$C740da31596f24ef['user_id']])) {
					} else {
						$C740da31596f24ef = array_merge($C740da31596f24ef, $Fdc8e0fc5edb3ca8[$C740da31596f24ef['user_id']]);
					}

					if (!$B3f0f4a134021073) {
						if ($C740da31596f24ef['hmac_id']) {
							if (AacD47d8157A1A09('adv', 'add_hmac')) {
								$a71afc14d6cd090d = "<a href='hmac?id=" . $C740da31596f24ef['hmac_id'] . "'>HMAC - " . $C740da31596f24ef['hmac_identifier'] . '</a>';
							} else {
								$a71afc14d6cd090d = 'HMAC - ' . $C740da31596f24ef['hmac_identifier'];
							}
						} else {
							if ($C740da31596f24ef['is_mag']) {
								if (AaCD47D8157A1a09('adv', 'edit_mag')) {
									$a71afc14d6cd090d = "<a href='mag?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['username'] . "<br/><strong>MAC: </strong> <span class='text-secondary'>" . $C740da31596f24ef['device_name'] . '</span></a>';
								} else {
									$a71afc14d6cd090d = $C740da31596f24ef['username'];
								}
							} else {
								if ($C740da31596f24ef['is_e2']) {
									if (aAcd47D8157A1a09('adv', 'edit_e2')) {
										$a71afc14d6cd090d = "<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['username'] . '<br/>' . $C740da31596f24ef['device_name'] . '</a>';
									} else {
										$a71afc14d6cd090d = $C740da31596f24ef['username'];
									}
								} else {
									if (Aacd47D8157a1a09('adv', 'users')) {
										$a71afc14d6cd090d = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
									} else {
										$a71afc14d6cd090d = $C740da31596f24ef['username'];
									}
								}
							}
						}

						$d48363bb091686d2 = array(1 => 'streams', 2 => 'movies', 3 => 'streams', 4 => 'radio', 5 => 'series');
						$ce2460e0c52a99da = array(1 => 'stream_view', 2 => 'stream_view', 3 => 'stream_view', 4 => 'stream_view');

						if (aacD47d8157a1a09('adv', $d48363bb091686d2[$C740da31596f24ef['type']])) {
							if ($C740da31596f24ef['type'] == 5) {
								$Fe753328765ad26c = "<a href='serie?id=" . $C740da31596f24ef['series_no'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
							} else {
								$Fe753328765ad26c = "<a href='" . $ce2460e0c52a99da[$C740da31596f24ef['type']] . '?id=' . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
							}
						} else {
							$Fe753328765ad26c = $C740da31596f24ef['stream_display_name'];
						}

						if (AaCd47d8157a1A09('adv', 'servers')) {
							$e81220b4451f37c9 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
						} else {
							$e81220b4451f37c9 = $C740da31596f24ef['server_name'];
						}

						if (!(0 < $C740da31596f24ef['proxy_id'] && isset($Fd8279be5302940a[$C740da31596f24ef['proxy_id']]))) {
						} else {
							$e81220b4451f37c9 .= '<br/><small>(via ' . $Fd8279be5302940a[$C740da31596f24ef['proxy_id']]['server_name'] . ')</small>';
						}

						if (0 < strlen($C740da31596f24ef['geoip_country_code'])) {
							$D0281cc88d5d14fd = "<img loading='lazy' src='assets/images/countries/" . strtolower($C740da31596f24ef['geoip_country_code']) . ".png'></img> &nbsp;";
						} else {
							$D0281cc88d5d14fd = '';
						}

						if ($C740da31596f24ef['user_ip']) {
							$fd6627d61b4b058f = explode(':', $C740da31596f24ef['user_ip']);
							$c59ec257c284c894 = $D0281cc88d5d14fd . "<a onClick=\"whois('" . $C740da31596f24ef['user_ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['user_ip'])) . '</a>';
						} else {
							$c59ec257c284c894 = '';
						}

						if ($C740da31596f24ef['date_start']) {
							$D031c48a1422c07e = date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date_start']);
						} else {
							$D031c48a1422c07e = '';
						}

						if ($C740da31596f24ef['date_end']) {
							$D00cf8fa3b1195d0 = date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date_end']);
						} else {
							$D00cf8fa3b1195d0 = '';
						}

						$cafddc0a05fb9f1f = trim(explode('(', $C740da31596f24ef['user_agent'])[0]);
						$C5034884ed44603a = $C740da31596f24ef['date_end'] - $C740da31596f24ef['date_start'];
						$Ac54397e06e8e862 = 'success';

						if (86400 <= $C5034884ed44603a) {
							$C5034884ed44603a = sprintf('%02dd %02dh', $C5034884ed44603a / 86400, ($C5034884ed44603a / 3600) % 24);
							$Ac54397e06e8e862 = 'danger';
						} else {
							if (3600 <= $C5034884ed44603a) {
								if (14400 < $C5034884ed44603a) {
									$Ac54397e06e8e862 = 'warning';
								} else {
									if (43200 >= $C5034884ed44603a) {
									} else {
										$Ac54397e06e8e862 = 'danger';
									}
								}

								$C5034884ed44603a = sprintf('%02dh %02dm', $C5034884ed44603a / 3600, ($C5034884ed44603a / 60) % 60);
							} else {
								$C5034884ed44603a = sprintf('%02dm %02ds', ($C5034884ed44603a / 60) % 60, $C5034884ed44603a % 60);
							}
						}

						if (!$C740da31596f24ef['is_restreamer']) {
						} else {
							$Ac54397e06e8e862 = 'success';
						}

						$C5034884ed44603a = "<button type='button' class='btn btn-" . $Ac54397e06e8e862 . " btn-xs waves-effect waves-light btn-fixed'>" . $C5034884ed44603a . '</button>';

						if ($C740da31596f24ef['is_restreamer'] == 1) {
							$Ca6b8df5f3f02b26 = '<i class="text-info fas fa-square"></i>';
						} else {
							$Ca6b8df5f3f02b26 = '<i class="text-secondary fas fa-square"></i>';
						}

						$a85e1b7d42c346a0['data'][] = array($a71afc14d6cd090d, $Fe753328765ad26c, $e81220b4451f37c9, $cafddc0a05fb9f1f, $C740da31596f24ef['isp'], $c59ec257c284c894, $D031c48a1422c07e, $D00cf8fa3b1195d0, $C5034884ed44603a, strtoupper($C740da31596f24ef['container']), $Ca6b8df5f3f02b26);
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	}

	exit();
}

if ($E379394c7b1a273f == 'live_connections') {
	if (aacd47d8157a1A09('adv', 'live_connections')) {
		$b3439582205053ea = array();

		if (XUI::$rSettings['redis_handler']) {
			$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? false : true);
			$f10b443055599d8b = true;

			if (isset(XUI::$rRequest['refresh'])) {
				$D031c48a1422c07e = 0;
				$E400a3101514583e = 1000;
				$f16991461acd03bf = explode(',', XUI::$rRequest['refresh']);
			} else {
				$d58b4f8653a391d8 = (0 < intval(XUI::$rRequest['server_id']) ? intval(XUI::$rRequest['server_id']) : null);
				$F26087d31c2bbe4d = (0 < intval(XUI::$rRequest['stream_id']) ? intval(XUI::$rRequest['stream_id']) : null);
				$D78ff1d0edade5eb = (0 < intval(XUI::$rRequest['user_id']) ? intval(XUI::$rRequest['user_id']) : null);

				if ($D78ff1d0edade5eb) {
					if ($d58b4f8653a391d8 || $F26087d31c2bbe4d) {
						$f16991461acd03bf = XUI::$redis->zRevRangeByScore('LINE#' . $D78ff1d0edade5eb, '+inf', '-inf');
						$f10b443055599d8b = false;
					} else {
						if ($cb10faf5ade31619) {
							$f16991461acd03bf = XUI::$redis->zRangeByScore('LINE#' . $D78ff1d0edade5eb, '-inf', '+inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
						} else {
							$f16991461acd03bf = XUI::$redis->zRevRangeByScore('LINE#' . $D78ff1d0edade5eb, '+inf', '-inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
						}

						$Ec475faf4d560253 = XUI::$redis->zCard('LINE#' . $D78ff1d0edade5eb);
					}
				} else {
					if ($F26087d31c2bbe4d) {
						if ($D78ff1d0edade5eb || $d58b4f8653a391d8) {
							$f16991461acd03bf = XUI::$redis->zRevRangeByScore('STREAM#' . $F26087d31c2bbe4d, '+inf', '-inf');
							$f10b443055599d8b = false;
						} else {
							if ($cb10faf5ade31619) {
								$f16991461acd03bf = XUI::$redis->zRangeByScore('STREAM#' . $F26087d31c2bbe4d, '-inf', '+inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
							} else {
								$f16991461acd03bf = XUI::$redis->zRevRangeByScore('STREAM#' . $F26087d31c2bbe4d, '+inf', '-inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
							}

							$Ec475faf4d560253 = XUI::$redis->zCard('STREAM#' . $F26087d31c2bbe4d);
						}
					} else {
						if ($d58b4f8653a391d8) {
							if ($D78ff1d0edade5eb || $F26087d31c2bbe4d) {
								$f16991461acd03bf = XUI::$redis->zRevRangeByScore('SERVER#' . $d58b4f8653a391d8, '+inf', '-inf');
								$f10b443055599d8b = false;
							} else {
								if ($cb10faf5ade31619) {
									$f16991461acd03bf = XUI::$redis->zRangeByScore('SERVER#' . $d58b4f8653a391d8, '-inf', '+inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
								} else {
									$f16991461acd03bf = XUI::$redis->zRevRangeByScore('SERVER#' . $d58b4f8653a391d8, '+inf', '-inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
								}

								$Ec475faf4d560253 = XUI::$redis->zCard('SERVER#' . $d58b4f8653a391d8);
							}
						} else {
							if ($cb10faf5ade31619) {
								$f16991461acd03bf = XUI::$redis->zRangeByScore('LIVE', '-inf', '+inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
							} else {
								$f16991461acd03bf = XUI::$redis->zRevRangeByScore('LIVE', '+inf', '-inf', array('limit' => array($D031c48a1422c07e, $E400a3101514583e)));
							}

							$Ec475faf4d560253 = XUI::$redis->zCard('LIVE');
						}
					}
				}
			}

			if (!$cb10faf5ade31619 || $f10b443055599d8b) {
			} else {
				$f16991461acd03bf = array_reverse($f16991461acd03bf);
			}

			if ($f10b443055599d8b) {
			} else {
				$Ec475faf4d560253 = count($f16991461acd03bf);
			}

			foreach (XUI::$redis->mGet($f16991461acd03bf) as $C740da31596f24ef) {
				$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);

				if (is_array($C740da31596f24ef)) {
					if ($f10b443055599d8b) {
					} else {
						if (!($d58b4f8653a391d8 && $d58b4f8653a391d8 != $C740da31596f24ef['server_id'])) {
							if (!($F26087d31c2bbe4d && $F26087d31c2bbe4d != $C740da31596f24ef['stream_id'])) {
								if (!($D78ff1d0edade5eb && $D78ff1d0edade5eb != $C740da31596f24ef['user_id'])) {
								} else {
									$Ec475faf4d560253--;
								}
							} else {
								$Ec475faf4d560253--;
							}
						} else {
							$Ec475faf4d560253--;
						}
					}

					$C740da31596f24ef['activity_id'] = $C740da31596f24ef['uuid'];
					$C740da31596f24ef['identifier'] = ($C740da31596f24ef['user_id'] ?: $C740da31596f24ef['hmac_id'] . '_' . $C740da31596f24ef['hmac_identifier']);
					$C740da31596f24ef['active_time'] = time() - $C740da31596f24ef['date_start'];
					$C740da31596f24ef['server_name'] = (XUI::$rServers[$C740da31596f24ef['server_id']]['server_name'] ?: '');
					$b3439582205053ea[] = $C740da31596f24ef;
				} else {
					$Ec475faf4d560253--;
				}
			}

			if ($f10b443055599d8b) {
			} else {
				$b3439582205053ea = array_slice($b3439582205053ea, $D031c48a1422c07e, $E400a3101514583e);
			}

			$F805649379c06d30 = $Cdb85875fd50f459 = $b174976b99c4ec48 = array();

			foreach ($b3439582205053ea as $C740da31596f24ef) {
				if (!$C740da31596f24ef['stream_id']) {
				} else {
					$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
				}

				if (!$C740da31596f24ef['user_id']) {
				} else {
					$b174976b99c4ec48[] = intval($C740da31596f24ef['user_id']);
				}

				if (!$C740da31596f24ef['uuid']) {
				} else {
					$F805649379c06d30[] = $C740da31596f24ef['uuid'];
				}
			}
			$c92aec5c90838930 = $A356f6810cb9be68 = $f9c1bb233c3eb615 = $dec4b1df9997c4d4 = array();

			if (0 >= count($b174976b99c4ec48)) {
			} else {
				$Fee0d5a474c96306->query('SELECT `lines`.`id`, `lines`.`is_mag`, `lines`.`is_e2`, `lines`.`is_restreamer`, `lines`.`username`, `mag_devices`.`mag_id`, `enigma2_devices`.`device_id` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` WHERE `lines`.`id` IN (' . implode(',', $b174976b99c4ec48) . ');');

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$D78ff1d0edade5eb = $C740da31596f24ef['id'];
					unset($C740da31596f24ef['id']);
					$dec4b1df9997c4d4[$D78ff1d0edade5eb] = $C740da31596f24ef;
				}
			}

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				$Fee0d5a474c96306->query('SELECT `stream_id`, `series_id` FROM `streams_episodes` WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$f9c1bb233c3eb615[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['series_id'];
				}
				$Fee0d5a474c96306->query('SELECT `id`, `type`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$c92aec5c90838930[$C740da31596f24ef['id']] = array($C740da31596f24ef['stream_display_name'], $C740da31596f24ef['type']);
				}
			}

			if (0 >= count($F805649379c06d30)) {
			} else {
				$Fee0d5a474c96306->query("SELECT `uuid`, `divergence` FROM `lines_divergence` WHERE `uuid` IN ('" . implode("','", $F805649379c06d30) . "');");

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$A356f6810cb9be68[$C740da31596f24ef['uuid']] = $C740da31596f24ef['divergence'];
				}
			}

			$Ea22c4a9ab5b2176 = 0;

			while ($Ea22c4a9ab5b2176 < count($b3439582205053ea)) {
				$b3439582205053ea[$Ea22c4a9ab5b2176]['divergence'] = ($A356f6810cb9be68[$b3439582205053ea[$Ea22c4a9ab5b2176]['uuid']] ?: 0);
				$b3439582205053ea[$Ea22c4a9ab5b2176]['series_no'] = ($f9c1bb233c3eb615[$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_id']] ?: null);
				$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_display_name'] = ($c92aec5c90838930[$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_id']][0] ?: '');
				$b3439582205053ea[$Ea22c4a9ab5b2176]['type'] = ($c92aec5c90838930[$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_id']][1] ?: 1);
				$b3439582205053ea[$Ea22c4a9ab5b2176] = array_merge($b3439582205053ea[$Ea22c4a9ab5b2176], ($dec4b1df9997c4d4[$b3439582205053ea[$Ea22c4a9ab5b2176]['user_id']] ?: array()));
				$Ea22c4a9ab5b2176++;
			}
			$a85e1b7d42c346a0['recordsTotal'] = $Ec475faf4d560253;
			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);
		} else {
			$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
			$c6c389b9adf3a40c = array('`lines_live`.`activity_id`', '`lines_live`.`divergence`', '`username` ' . $cb10faf5ade31619 . ', `lines_live`.`hmac_identifier`', '`streams`.`stream_display_name`', '`server_name`', '`lines_live`.`user_agent`', '`lines_live`.`isp`', '`lines_live`.`user_ip`', 'UNIX_TIMESTAMP() - `lines_live`.`date_start`', '`lines_live`.`container`', '`lines`.`is_restreamer`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`hls_end` = 0';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 10) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`lines_live`.`hmac_identifier` LIKE ? OR `lines_live`.`user_agent` LIKE ? OR `lines_live`.`user_ip` LIKE ? OR `lines_live`.`container` LIKE ? OR FROM_UNIXTIME(`lines_live`.`date_start`) LIKE ? OR `lines_live`.`geoip_country_code` LIKE ? OR `lines`.`username` LIKE ? OR `mag_devices`.`mac` LIKE ? OR `enigma2_devices`.`mac` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
			}

			if (0 >= intval(XUI::$rRequest['server_id'])) {
			} else {
				$f86e19bdb1e7dae8[] = '(`lines_live`.`server_id` = ? OR `lines_live`.`proxy_id` = ?)';
				$Df2582e36fdd6160[] = XUI::$rRequest['server_id'];
				$Df2582e36fdd6160[] = XUI::$rRequest['server_id'];
			}

			if (0 >= intval(XUI::$rRequest['stream_id'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines_live`.`stream_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];
			}

			if (0 >= intval(XUI::$rRequest['user_id'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines_live`.`user_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['user_id'];
			}

			if (!isset(XUI::$rRequest['refresh'])) {
			} else {
				$f86e19bdb1e7dae8 = array('`lines_live`.`activity_id` IN (' . implode(',', array_map('intval', explode(',', XUI::$rRequest['refresh']))) . ') AND `hls_end` = 0');
				$D031c48a1422c07e = 0;
				$E400a3101514583e = 1000;
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`lines`.`is_mag` = 0 AND `lines`.`is_e2` = 0 AND `lines`.`is_restreamer` = 0 AND `lines`.`is_stalker` = 0)';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '`lines`.`is_mag` = 1';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '`lines`.`is_e2` = 1';
						} else {
							if (XUI::$rRequest['filter'] == 4) {
								$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
							} else {
								if (XUI::$rRequest['filter'] == 5) {
									$f86e19bdb1e7dae8[] = '`lines`.`is_restreamer` = 1';
								} else {
									if (XUI::$rRequest['filter'] != 6) {
									} else {
										$f86e19bdb1e7dae8[] = '`lines`.`is_stalker` = 1';
									}
								}
							}
						}
					}
				}
			}

			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines_live` LEFT JOIN `lines` ON `lines_live`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_live`.`stream_id` = `streams`.`id` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines_live`.`user_id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines_live`.`user_id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `mag_devices`.`mag_id`, `enigma2_devices`.`device_id`, `lines`.`is_e2`, `lines`.`is_mag`, `lines_live`.`activity_id`, `lines_live`.`hmac_id`, `lines_live`.`hmac_identifier`, `lines_live`.`proxy_id`, `lines_live`.`divergence`, `lines_live`.`user_id`, `lines_live`.`stream_id`, `streams`.`series_no`, `lines`.`is_restreamer`, `lines_live`.`isp`, `lines_live`.`server_id`, `lines_live`.`user_agent`, `lines_live`.`user_ip`, `lines_live`.`container`, `lines_live`.`pid`, `lines_live`.`uuid`, `lines_live`.`date_start`, `lines_live`.`geoip_country_code`, IF(`lines`.`is_mag`, `mag_devices`.`mac`, IF(`lines`.`is_e2`, `enigma2_devices`.`mac`, `lines`.`username`)) AS `username`, `streams`.`stream_display_name`, `streams`.`type`, (SELECT `server_name` FROM `servers` WHERE `id` = `lines_live`.`server_id`) AS `server_name` FROM `lines_live` LEFT JOIN `lines` ON `lines_live`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_live`.`stream_id` = `streams`.`id` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines_live`.`user_id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines_live`.`user_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
				}
			}
		}

		if (0 >= count($b3439582205053ea)) {
		} else {
			foreach ($b3439582205053ea as $C740da31596f24ef) {
				if (!$B3f0f4a134021073) {
					if ($C740da31596f24ef['divergence'] <= 50) {
						$b25be5f9af7a0a91 = '<i class="text-success fas fa-square tooltip" title="' . intval(100 - $C740da31596f24ef['divergence']) . '%"></i>';
					} else {
						if ($C740da31596f24ef['divergence'] <= 80) {
							$b25be5f9af7a0a91 = '<i class="text-warning fas fa-square tooltip" title="' . intval(100 - $C740da31596f24ef['divergence']) . '%"></i>';
						} else {
							$b25be5f9af7a0a91 = '<i class="text-danger fas fa-square tooltip" title="' . intval(100 - $C740da31596f24ef['divergence']) . '%"></i>';
						}
					}

					if ($C740da31596f24ef['hmac_id']) {
						if (aACD47D8157A1a09('adv', 'add_hmac')) {
							$a71afc14d6cd090d = "<a href='hmac?id=" . $C740da31596f24ef['hmac_id'] . "'>HMAC - " . $C740da31596f24ef['hmac_identifier'] . '</a>';
						} else {
							$a71afc14d6cd090d = 'HMAC - ' . $C740da31596f24ef['hmac_identifier'];
						}
					} else {
						if ($C740da31596f24ef['is_mag']) {
							if (aaCD47D8157A1A09('adv', 'edit_mag')) {
								$a71afc14d6cd090d = "<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
							} else {
								$a71afc14d6cd090d = $C740da31596f24ef['username'];
							}
						} else {
							if ($C740da31596f24ef['is_e2']) {
								if (AACD47D8157A1a09('adv', 'edit_e2')) {
									$a71afc14d6cd090d = "<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
								} else {
									$a71afc14d6cd090d = $C740da31596f24ef['username'];
								}
							} else {
								if (AACD47D8157A1A09('adv', 'users')) {
									$a71afc14d6cd090d = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
								} else {
									$a71afc14d6cd090d = $C740da31596f24ef['username'];
								}
							}
						}
					}

					$d48363bb091686d2 = array(1 => 'streams', 2 => 'movies', 3 => 'streams', 4 => 'radio', 5 => 'series');
					$ce2460e0c52a99da = array(1 => 'stream_view', 2 => 'stream_view', 3 => 'stream_view', 4 => 'stream_view');

					if (aacd47D8157A1A09('adv', $d48363bb091686d2[$C740da31596f24ef['type']])) {
						if ($C740da31596f24ef['type'] == 5) {
							$Fe753328765ad26c = "<a href='serie?id=" . $C740da31596f24ef['series_no'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
						} else {
							$Fe753328765ad26c = "<a href='" . $ce2460e0c52a99da[$C740da31596f24ef['type']] . '?id=' . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
						}
					} else {
						$Fe753328765ad26c = $C740da31596f24ef['stream_display_name'];
					}

					if (AaCD47d8157A1a09('adv', 'servers')) {
						$e81220b4451f37c9 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
					} else {
						$e81220b4451f37c9 = $C740da31596f24ef['server_name'];
					}

					if (!(0 < $C740da31596f24ef['proxy_id'] && isset($Fd8279be5302940a[$C740da31596f24ef['proxy_id']]))) {
					} else {
						$e81220b4451f37c9 .= '<br/><small>(via ' . $Fd8279be5302940a[$C740da31596f24ef['proxy_id']]['server_name'] . ')</small>';
					}

					if (0 < strlen($C740da31596f24ef['geoip_country_code'])) {
						$D0281cc88d5d14fd = "<img loading='lazy' src='assets/images/countries/" . strtolower($C740da31596f24ef['geoip_country_code']) . ".png'></img> &nbsp;";
					} else {
						$D0281cc88d5d14fd = '';
					}

					if ($C740da31596f24ef['user_ip']) {
						$fd6627d61b4b058f = explode(':', $C740da31596f24ef['user_ip']);
						$c59ec257c284c894 = $D0281cc88d5d14fd . "<a onClick=\"whois('" . $C740da31596f24ef['user_ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['user_ip'])) . '</a>';
					} else {
						$c59ec257c284c894 = '';
					}

					$cafddc0a05fb9f1f = trim(explode('(', $C740da31596f24ef['user_agent'])[0]);
					$C5034884ed44603a = intval(time()) - intval($C740da31596f24ef['date_start']);
					$Ac54397e06e8e862 = 'success';

					if ($C740da31596f24ef['hls_end']) {
						$C5034884ed44603a = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light btn-fixed'>CLOSED</button>";
					} else {
						if (86400 <= $C5034884ed44603a) {
							$C5034884ed44603a = sprintf('%02dd %02dh', $C5034884ed44603a / 86400, ($C5034884ed44603a / 3600) % 24);
							$Ac54397e06e8e862 = 'danger';
						} else {
							if (3600 <= $C5034884ed44603a) {
								if (14400 < $C5034884ed44603a) {
									$Ac54397e06e8e862 = 'warning';
								} else {
									if (43200 >= $C5034884ed44603a) {
									} else {
										$Ac54397e06e8e862 = 'danger';
									}
								}

								$C5034884ed44603a = sprintf('%02dh %02dm', $C5034884ed44603a / 3600, ($C5034884ed44603a / 60) % 60);
							} else {
								$C5034884ed44603a = sprintf('%02dm %02ds', ($C5034884ed44603a / 60) % 60, $C5034884ed44603a % 60);
							}
						}

						if (!$C740da31596f24ef['is_restreamer']) {
						} else {
							$Ac54397e06e8e862 = 'success';
						}

						$C5034884ed44603a = "<button type='button' class='btn btn-" . $Ac54397e06e8e862 . " btn-xs waves-effect waves-light btn-fixed'>" . $C5034884ed44603a . '</button>';
					}

					if ($C740da31596f24ef['is_restreamer'] == 1) {
						$Ca6b8df5f3f02b26 = '<i class="text-info fas fa-square"></i>';
					} else {
						$Ca6b8df5f3f02b26 = '<i class="text-secondary fas fa-square"></i>';
					}

					$ebab77ef4bee81e0 = '<div class="btn-group">';

					if (isset(XUI::$rRequest['fingerprint'])) {
						$ebab77ef4bee81e0 .= "<button title=\"Kill Connection\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['uuid'] . "', 'kill', '" . $C740da31596f24ef['activity_id'] . "');\"><i class=\"fas fa-hammer\"></i></button>";
					} else {
						$ebab77ef4bee81e0 .= "<button title=\"Kill Connection\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['uuid'] . "', 'kill');\"><i class=\"fas fa-hammer\"></i></button>";

						if (!(AaCd47d8157A1a09('adv', 'fingerprint') && 0 < intval($C740da31596f24ef['user_id']) && $C740da31596f24ef['type'] == 1)) {
						} else {
							$ebab77ef4bee81e0 .= '<button title="Fingerprint" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="modalFingerprint(' . $C740da31596f24ef['user_id'] . ", 'user');\"><i class=\"mdi mdi-fingerprint\"></i></button>";
						}
					}

					$ebab77ef4bee81e0 .= '</div>';
					$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['activity_id'], $b25be5f9af7a0a91, $a71afc14d6cd090d, $Fe753328765ad26c, $e81220b4451f37c9, $cafddc0a05fb9f1f, $C740da31596f24ef['isp'], $c59ec257c284c894, $C5034884ed44603a, strtoupper($C740da31596f24ef['container']), $Ca6b8df5f3f02b26, $ebab77ef4bee81e0);
				} else {
					$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
				}
			}
		}

		echo json_encode($a85e1b7d42c346a0);

		exit();
	} else {
		exit();
	}
} else {
	if ($E379394c7b1a273f == 'stream_list') {
		if (AAcD47D8157a1a09('adv', 'import_streams') || AAcd47D8157A1A09('adv', 'mass_delete')) {
			$A5dcdeb6ecbbf6bd = cbe87E2A9A996111('live');
			$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_icon`', '`streams`.`stream_display_name`', '`streams`.`category_id`', '`streams_servers`.`server_id`', '`streams_servers`.`stream_status`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (isset(XUI::$rRequest['include_channels'])) {
				$f86e19bdb1e7dae8[] = '`streams`.`type` IN (1,3)';
			} else {
				if (isset(XUI::$rRequest['only_channels'])) {
					$f86e19bdb1e7dae8[] = '`streams`.`type` = 3';
				} else {
					$f86e19bdb1e7dae8[] = '`streams`.`type` = 1';
				}
			}

			if (0 < intval(XUI::$rRequest['category'])) {
				$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
				$Df2582e36fdd6160[] = XUI::$rRequest['category'];
			} else {
				if (intval(XUI::$rRequest['category']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
				}
			}

			if (0 < intval(XUI::$rRequest['server'])) {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
				$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			} else {
				if (intval(XUI::$rRequest['server']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
				}
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (!isset(XUI::$rRequest['only_channels'])) {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '(`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`stream_status` = 0)';
					} else {
						if (XUI::$rRequest['filter'] == 2) {
							$f86e19bdb1e7dae8[] = '((`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 1))';
						} else {
							if (XUI::$rRequest['filter'] == 3) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND `streams_servers`.`on_demand` = 0)';
							} else {
								if (XUI::$rRequest['filter'] == 4) {
									$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 2)';
								} else {
									if (XUI::$rRequest['filter'] == 5) {
										$f86e19bdb1e7dae8[] = '`streams_servers`.`on_demand` = 1';
									} else {
										if (XUI::$rRequest['filter'] == 6) {
											$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
										} else {
											if (XUI::$rRequest['filter'] == 7) {
												$f86e19bdb1e7dae8[] = '`streams`.`tv_archive_server_id` > 0 AND `streams`.`tv_archive_duration` > 0';
											} else {
												if (XUI::$rRequest['filter'] == 8) {
													if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
														$f86e19bdb1e7dae8[] = "(SELECT COUNT(*) AS `count` FROM `streams_logs` WHERE `streams_logs`.`action` = 'STREAM_FAILED' AND `streams_logs`.`date` >= UNIX_TIMESTAMP()-86400 AND `streams_logs`.`stream_id` = `streams`.`id`) > 144";
													} else {
														$f86e19bdb1e7dae8[] = "(SELECT COUNT(*) AS `count` FROM `streams_logs` WHERE `streams_logs`.`action` = 'STREAM_FAILED' AND `streams_logs`.`date` >= UNIX_TIMESTAMP()-86400 AND `streams_logs`.`stream_id` = `streams`.`id` AND `streams_logs`.`server_id` = `streams_servers`.`server_id`) > 144";
													}
												} else {
													if (XUI::$rRequest['filter'] == 9) {
														$f86e19bdb1e7dae8[] = 'LENGTH(`streams`.`channel_id`) > 0';
													} else {
														if (XUI::$rRequest['filter'] == 10) {
															$f86e19bdb1e7dae8[] = '(`streams`.`channel_id` IS NULL OR LENGTH(`streams`.`channel_id`) = 0)';
														} else {
															if (XUI::$rRequest['filter'] == 11) {
																$f86e19bdb1e7dae8[] = '`streams`.`adaptive_link` IS NOT NULL';
															} else {
																if (XUI::$rRequest['filter'] == 12) {
																	$f86e19bdb1e7dae8[] = '`streams`.`title_sync` IS NOT NULL';
																} else {
																	if (XUI::$rRequest['filter'] != 13) {
																	} else {
																		$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				} else {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '(`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0)';
					} else {
						if (XUI::$rRequest['filter'] == 2) {
							$f86e19bdb1e7dae8[] = "(`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND (REPLACE(`streams_servers`.`cchannel_rsources`, '\\\\/', '/') = REPLACE(`streams`.`stream_source`, '\\\\/', '/'))";
						} else {
							if (XUI::$rRequest['filter'] != 3) {
							} else {
								$f86e19bdb1e7dae8[] = "(REPLACE(`streams_servers`.`cchannel_rsources`, '\\\\/', '/') <> REPLACE(`streams`.`stream_source`, '\\\\/', '/'))";
							}
						}
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM (SELECT `id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id`) t1;';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams_servers`.`stream_id`, `streams`.`type`, `streams`.`stream_icon`, `streams`.`adaptive_link`, `streams`.`title_sync`, `streams_servers`.`cchannel_rsources`, `streams`.`stream_source`, `streams`.`stream_display_name`, `streams`.`tv_archive_duration`, `streams`.`tv_archive_server_id`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`cc_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams`.`epg_id`, `streams`.`channel_id` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ', -`stream_started` DESC LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$caa77b80211665a0 = $Cdb85875fd50f459 = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
					}

					if (0 >= count($Cdb85875fd50f459)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

							if (0 < strlen(XUI::$rRequest['category'])) {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
							} else {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
							}

							if (1 >= count($A38b42a281e3c3cf)) {
							} else {
								$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
							}

							$Ef28eaee0050d7a5 = $C740da31596f24ef['stream_display_name'];

							if ($C740da31596f24ef['server_name']) {
								$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];

								if (1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
								} else {
									$B00ef71aa2cd7a26 .= " &nbsp; <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
								}
							} else {
								$B00ef71aa2cd7a26 = 'No Server Selected';
							}

							$fad73125a2cca3ed = 0;
							$b45800af0138159b = 0;

							if (0 >= intval($C740da31596f24ef['stream_started'])) {
							} else {
								$fad73125a2cca3ed = time() - intval($C740da31596f24ef['stream_started']);
							}

							if ($C740da31596f24ef['server_id']) {
								if (intval($C740da31596f24ef['direct_source']) == 1) {
									if (intval($C740da31596f24ef['direct_proxy']) == 1) {
										$b45800af0138159b = 7;
									} else {
										$b45800af0138159b = 5;
									}
								} else {
									if ($C740da31596f24ef['monitor_pid']) {
										if ($C740da31596f24ef['pid'] && 0 < $C740da31596f24ef['pid']) {
											if (intval($C740da31596f24ef['stream_status']) == 2) {
												$b45800af0138159b = 2;
											} else {
												$b45800af0138159b = 1;
											}
										} else {
											$b45800af0138159b = 3;
										}
									} else {
										if (intval($C740da31596f24ef['on_demand']) == 1) {
											$b45800af0138159b = 4;
										} else {
											$b45800af0138159b = 0;
										}
									}
								}
							} else {
								$b45800af0138159b = -1;
							}

							if (0 < strlen($C740da31596f24ef['stream_icon'])) {
								$E9c8d08bfb6ef33c = "<img loading='lazy' src='resize?maxw=96&maxh=32&url=" . urlencode($C740da31596f24ef['stream_icon']) . "' />";
							} else {
								$E9c8d08bfb6ef33c = '';
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $E9c8d08bfb6ef33c, $Ef28eaee0050d7a5, $A1925ae53e9307eb, $B00ef71aa2cd7a26, $F8b5842eeedab682[$b45800af0138159b]);
						} else {
							unset($C740da31596f24ef['stream_source']);
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'movie_list') {
		if (aaCD47D8157A1A09('adv', 'import_movies') || aAcd47d8157A1A09('adv', 'mass_delete')) {
			$A5dcdeb6ecbbf6bd = cBE87e2a9a996111('movie');
			$c6c389b9adf3a40c = array('`streams`.`id`', false, '`streams`.`stream_display_name`', '`streams`.`category_id`', '`streams_servers`.`server_id`', '`streams_servers`.`stream_status`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`streams`.`type` = 2';

			if (0 < intval(XUI::$rRequest['category'])) {
				$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
				$Df2582e36fdd6160[] = XUI::$rRequest['category'];
			} else {
				if (intval(XUI::$rRequest['category']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
				}
			}

			if (0 < intval(XUI::$rRequest['server'])) {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
				$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			} else {
				if (intval(XUI::$rRequest['server']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
				}
			}

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` <> 1)';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 1 AND `streams_servers`.`stream_status` <> 1)';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` = 1)';
						} else {
							if (XUI::$rRequest['filter'] == 4) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 1)';
							} else {
								if (XUI::$rRequest['filter'] == 5) {
									$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
								} else {
									if (XUI::$rRequest['filter'] == 6) {
										$f86e19bdb1e7dae8[] = "(`streams`.`movie_properties` IS NULL OR `streams`.`movie_properties` = '' OR `streams`.`movie_properties` = '[]' OR `streams`.`movie_properties` = '{}' OR `streams`.`movie_properties` LIKE '%tmdb_id\":\"\"%')";
									} else {
										if (XUI::$rRequest['filter'] == 7) {
											$f86e19bdb1e7dae8[] = '`streams`.`id` IN (SELECT MIN(`id`) FROM `streams` WHERE `type` = 2 GROUP BY `stream_source` HAVING COUNT(`stream_source`) > 1)';
											$f69f03301cf5dc4e = true;
										} else {
											if (XUI::$rRequest['filter'] != 8) {
											} else {
												$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
											}
										}
									}
								}
							}
						}
					}
				}
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(DISTINCT(`streams`.`id`)) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, MD5(`streams`.`stream_source`) AS `source`, `streams`.`movie_properties`, `streams`.`year`, `streams_servers`.`to_analyze`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$caa77b80211665a0 = $Cdb85875fd50f459 = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
					}

					if (0 >= count($Cdb85875fd50f459)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$b45800af0138159b = 0;

							if (intval($C740da31596f24ef['direct_source']) == 1) {
								if (intval($C740da31596f24ef['direct_proxy']) == 1) {
									$b45800af0138159b = 5;
								} else {
									$b45800af0138159b = 3;
								}
							} else {
								if (!is_null($C740da31596f24ef['pid']) && 0 < $C740da31596f24ef['pid']) {
									if ($C740da31596f24ef['to_analyze'] == 1) {
										$b45800af0138159b = 2;
									} else {
										if ($C740da31596f24ef['stream_status'] == 1) {
											$b45800af0138159b = 4;
										} else {
											$b45800af0138159b = 1;
										}
									}
								} else {
									$b45800af0138159b = 0;
								}
							}

							if ($C740da31596f24ef['server_name']) {
								$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];

								if (1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
								} else {
									$B00ef71aa2cd7a26 .= " &nbsp; <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
								}
							} else {
								$B00ef71aa2cd7a26 = 'No Server Selected';
							}

							$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

							if (0 < strlen(XUI::$rRequest['category'])) {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
							} else {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
							}

							if (1 >= count($A38b42a281e3c3cf)) {
							} else {
								$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
							}

							$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);
							$e962a80487b84e46 = '';

							if (!$D92b16dc36690ab9['rating']) {
							} else {
								$B0ac3a61df74ba36 = round($D92b16dc36690ab9['rating']) / 2;
								$d25560ad0b146132 = floor($B0ac3a61df74ba36);
								$b39c3caa0856cfa2 = 0 < $B0ac3a61df74ba36 - $d25560ad0b146132;
								$D46dfa8113384246 = 5 - ($d25560ad0b146132 + (($b39c3caa0856cfa2 ? 1 : 0)));

								if (0 >= $d25560ad0b146132) {
								} else {
									foreach (range(1, $d25560ad0b146132) as $Ea22c4a9ab5b2176) {
										$e962a80487b84e46 .= "<i class='mdi mdi-star'></i>";
									}
								}

								if (!$b39c3caa0856cfa2) {
								} else {
									$e962a80487b84e46 .= "<i class='mdi mdi-star-half'></i>";
								}

								if (0 >= $D46dfa8113384246) {
								} else {
									foreach (range(1, $D46dfa8113384246) as $Ea22c4a9ab5b2176) {
										$e962a80487b84e46 .= "<i class='mdi mdi-star-outline'></i>";
									}
								}
							}

							$A02729c83b6cd395 = ($C740da31596f24ef['year'] ? '<strong>' . $C740da31596f24ef['year'] . '</strong> &nbsp;' : '');
							$Ef28eaee0050d7a5 = $C740da31596f24ef['stream_display_name'] . "<br><span style='font-size:11px;'>" . $A02729c83b6cd395 . $e962a80487b84e46 . '</span>';

							if (0 < strlen($D92b16dc36690ab9['movie_image']) && XUI::$rSettings['show_images']) {
								$A639a7baefc720ee = "<a href='javascript: void(0);' data-src='resize?maxw=512&maxh=512&url=" . $D92b16dc36690ab9['movie_image'] . "'><img loading='lazy' src='resize?maxh=58&maxw=32&url=" . $D92b16dc36690ab9['movie_image'] . "' /></a>";
							} else {
								$A639a7baefc720ee = '';
							}

							if (isset($D92b16dc36690ab9['kinopoisk_url']) && 0 < strlen($D92b16dc36690ab9['kinopoisk_url'])) {
								$a69d576081840514 = '<button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-check-circle"></i></button>';
							} else {
								$a69d576081840514 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-minus-circle"></i></button>';
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $A639a7baefc720ee, $Ef28eaee0050d7a5, $A1925ae53e9307eb, $B00ef71aa2cd7a26, $f45f1268c76ac2a3[$b45800af0138159b], $a69d576081840514);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'radio_list') {
		if (aaCD47D8157a1a09('adv', 'mass_delete')) {
			$A5dcdeb6ecbbf6bd = cBe87E2a9a996111('radio');
			$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_icon`', '`streams`.`stream_display_name`', '`streams`.`category_id`', '`streams_servers`.`server_id`', '`streams_servers`.`stream_status`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`streams`.`type` = 4';

			if (0 < intval(XUI::$rRequest['category'])) {
				$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
				$Df2582e36fdd6160[] = XUI::$rRequest['category'];
			} else {
				if (intval(XUI::$rRequest['category']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
				}
			}

			if (0 < intval(XUI::$rRequest['server'])) {
				$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
				$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			} else {
				if (intval(XUI::$rRequest['server']) != -1) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
				}
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`stream_status` = 0)';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '((`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 1))';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NULL OR `streams_servers`.`monitor_pid` <= 0) AND `streams_servers`.`on_demand` = 0)';
						} else {
							if (XUI::$rRequest['filter'] == 4) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` = 2)';
							} else {
								if (XUI::$rRequest['filter'] == 5) {
									$f86e19bdb1e7dae8[] = '`streams_servers`.`on_demand` = 1';
								} else {
									if (XUI::$rRequest['filter'] != 6) {
									} else {
										$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
									}
								}
							}
						}
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(DISTINCT(`streams`.`id`)) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_icon`, `streams`.`movie_properties`, `streams_servers`.`to_analyze`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$caa77b80211665a0 = $Cdb85875fd50f459 = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
					}

					if (0 >= count($Cdb85875fd50f459)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

							if (0 < strlen(XUI::$rRequest['category'])) {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
							} else {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
							}

							if (1 >= count($A38b42a281e3c3cf)) {
							} else {
								$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
							}

							$fad73125a2cca3ed = 0;
							$b45800af0138159b = 0;

							if (0 >= intval($C740da31596f24ef['stream_started'])) {
							} else {
								$fad73125a2cca3ed = time() - intval($C740da31596f24ef['stream_started']);
							}

							if ($C740da31596f24ef['server_id']) {
								if (intval($C740da31596f24ef['direct_source']) == 1) {
									$b45800af0138159b = 5;
								} else {
									if ($C740da31596f24ef['monitor_pid']) {
										if ($C740da31596f24ef['pid'] && 0 < $C740da31596f24ef['pid']) {
											if (intval($C740da31596f24ef['stream_status']) == 2) {
												$b45800af0138159b = 2;
											} else {
												$b45800af0138159b = 1;
											}
										} else {
											$b45800af0138159b = 3;
										}
									} else {
										if (intval($C740da31596f24ef['on_demand']) == 1) {
											$b45800af0138159b = 4;
										} else {
											$b45800af0138159b = 0;
										}
									}
								}
							} else {
								$b45800af0138159b = -1;
							}

							if ($C740da31596f24ef['server_name']) {
								$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];

								if (1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
								} else {
									$B00ef71aa2cd7a26 .= " &nbsp; <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
								}
							} else {
								$B00ef71aa2cd7a26 = 'No Server Selected';
							}

							if (0 < strlen($C740da31596f24ef['stream_icon']) && XUI::$rSettings['show_images']) {
								$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['stream_icon'] . "'><img loading='lazy' src='resize?maxw=96&maxh=32&url=" . $C740da31596f24ef['stream_icon'] . "' /></a>";
							} else {
								$E9c8d08bfb6ef33c = '';
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $E9c8d08bfb6ef33c, $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $B00ef71aa2cd7a26, $F8b5842eeedab682[$b45800af0138159b]);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'series_list') {
		if (AAcd47D8157A1a09('adv', 'mass_delete')) {
			$A5dcdeb6ecbbf6bd = cBE87E2a9A996111('series');
			$c6c389b9adf3a40c = array('`streams_series`.`id`', '`streams_series`.`cover`', '`streams_series`.`title`', '`streams_series`.`category_id`', '`latest_season`', '`episode_count`', false, '`streams_series`.`release_date`', '`streams_series`.`last_modified`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['category'])) {
			} else {
				if (XUI::$rRequest['category'] == -1) {
					$f86e19bdb1e7dae8[] = '(`streams_series`.`tmdb_id` = 0 OR `streams_series`.`tmdb_id` IS NULL)';
				} else {
					if (XUI::$rRequest['category'] == -2) {
						$f86e19bdb1e7dae8[] = "(`streams`.`category_id` = '[]' OR `streams`.`category_id` IS NULL)";
					} else {
						$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams_series`.`category_id`, ?, '\$')";
						$Df2582e36fdd6160[] = XUI::$rRequest['category'];
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 3) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams_series`.`id` LIKE ? OR `streams_series`.`title` LIKE ? OR `streams_series`.`release_date` LIKE ?)';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams_series`.`id`, `streams_series`.`year`, `streams_series`.`rating`, `streams_series`.`cover`, `streams_series`.`title`, `streams_series`.`category_id`, `streams_series`.`tmdb_id`, `streams_series`.`release_date`, `streams_series`.`last_modified`, (SELECT MAX(`season_num`) FROM `streams_episodes` WHERE `series_id` = `streams_series`.`id`) AS `latest_season`, (SELECT COUNT(*) FROM `streams_episodes` WHERE `series_id` = `streams_series`.`id`) AS `episode_count` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

							if (0 < strlen(XUI::$rRequest['category'])) {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
							} else {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
							}

							if (1 >= count($A38b42a281e3c3cf)) {
							} else {
								$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
							}

							if (0 < $C740da31596f24ef['latest_season']) {
								$C740da31596f24ef['latest_season'] = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['latest_season'] . '</button>';
							} else {
								$C740da31596f24ef['latest_season'] = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}

							if (0 < $C740da31596f24ef['episode_count']) {
								$C740da31596f24ef['episode_count'] = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['episode_count'] . '</button>';
							} else {
								$C740da31596f24ef['episode_count'] = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}

							if ($C740da31596f24ef['last_modified'] == 0) {
								$C740da31596f24ef['last_modified'] = 'Never';
							} else {
								$C740da31596f24ef['last_modified'] = date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['last_modified']);
							}

							if (!$C740da31596f24ef['release_date']) {
							} else {
								$C740da31596f24ef['release_date'] = date($F2d4d8f7981ac574['date_format'], strtotime($C740da31596f24ef['release_date']));
							}

							if (0 < $C740da31596f24ef['tmdb_id']) {
								$a69d576081840514 = '<button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-check-circle"></i></button>';
							} else {
								$a69d576081840514 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-minus-circle"></i></button>';
							}

							if (0 < strlen($C740da31596f24ef['cover'])) {
								$A639a7baefc720ee = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['cover'] . "'><img loading='lazy' src='resize?maxh=58&maxw=32&url=" . $C740da31596f24ef['cover'] . "' /></a>";
							} else {
								$A639a7baefc720ee = '';
							}

							$e962a80487b84e46 = '';

							if (!$C740da31596f24ef['rating']) {
							} else {
								$B0ac3a61df74ba36 = round($C740da31596f24ef['rating']) / 2;
								$d25560ad0b146132 = floor($B0ac3a61df74ba36);
								$b39c3caa0856cfa2 = 0 < $B0ac3a61df74ba36 - $d25560ad0b146132;
								$D46dfa8113384246 = 5 - ($d25560ad0b146132 + (($b39c3caa0856cfa2 ? 1 : 0)));

								if (0 >= $d25560ad0b146132) {
								} else {
									foreach (range(1, $d25560ad0b146132) as $Ea22c4a9ab5b2176) {
										$e962a80487b84e46 .= "<i class='mdi mdi-star'></i>";
									}
								}

								if (!$b39c3caa0856cfa2) {
								} else {
									$e962a80487b84e46 .= "<i class='mdi mdi-star-half'></i>";
								}

								if (0 >= $D46dfa8113384246) {
								} else {
									foreach (range(1, $D46dfa8113384246) as $Ea22c4a9ab5b2176) {
										$e962a80487b84e46 .= "<i class='mdi mdi-star-outline'></i>";
									}
								}
							}

							$A02729c83b6cd395 = ($C740da31596f24ef['year'] ? '<strong>' . $C740da31596f24ef['year'] . '</strong> &nbsp;' : '');
							$c608db3e24256b76 = '<strong>' . $C740da31596f24ef['title'] . "</strong><br><span style='font-size:11px;'>" . $A02729c83b6cd395 . $e962a80487b84e46 . '</span></a>';
							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $A639a7baefc720ee, $c608db3e24256b76, $A1925ae53e9307eb, $C740da31596f24ef['latest_season'], $C740da31596f24ef['episode_count'], $a69d576081840514, $C740da31596f24ef['release_date'], $C740da31596f24ef['last_modified']);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'credits_log') {
		if (aACd47D8157a1A09('adv', 'credits_log')) {
			$c6c389b9adf3a40c = array('`users_credits_logs`.`id`', '`owner_username`', '`target_username`', '`users_credits_logs`.`amount`', '`users_credits_logs`.`reason`', '`date`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 5) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`target`.`username` LIKE ? OR `owner`.`username` LIKE ? OR FROM_UNIXTIME(`date`) LIKE ? OR `users_credits_logs`.`amount` LIKE ? OR `users_credits_logs`.`reason` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['range'])) {
			} else {
				$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
				$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

				if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
				} else {
					$a859a0996bb0f1ff = null;
				}

				if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
				} else {
					$B37c1f185be84c33 = null;
				}

				if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
				} else {
					$f86e19bdb1e7dae8[] = '(`users_credits_logs`.`date` >= ? AND `users_credits_logs`.`date` <= ?)';
					$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
					$Df2582e36fdd6160[] = $B37c1f185be84c33;
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '(`users_credits_logs`.`target_id` = ? OR `users_credits_logs`.`admin_id` = ?)';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `users_credits_logs` LEFT JOIN `users` AS `target` ON `target`.`id` = `users_credits_logs`.`target_id` LEFT JOIN `users` AS `owner` ON `owner`.`id` = `users_credits_logs`.`admin_id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `users_credits_logs`.`id`, `users_credits_logs`.`target_id`, `users_credits_logs`.`admin_id`, `target`.`username` AS `target_username`, `owner`.`username` AS `owner_username`, `amount`, FROM_UNIXTIME(`date`) AS `date`, `users_credits_logs`.`reason` FROM `users_credits_logs` LEFT JOIN `users` AS `target` ON `target`.`id` = `users_credits_logs`.`target_id` LEFT JOIN `users` AS `owner` ON `owner`.`id` = `users_credits_logs`.`admin_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							if (aaCD47d8157A1A09('adv', 'edit_reguser')) {
								$Dbb9e190755fc819 = "<a href='user?id=" . $C740da31596f24ef['admin_id'] . "'>" . $C740da31596f24ef['owner_username'] . '</a>';
								$D858966a53584fdb = "<a href='user?id=" . $C740da31596f24ef['target_id'] . "'>" . $C740da31596f24ef['target_username'] . '</a>';
							} else {
								$Dbb9e190755fc819 = $C740da31596f24ef['owner_username'];
								$D858966a53584fdb = $C740da31596f24ef['target_username'];
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $Dbb9e190755fc819, $D858966a53584fdb, number_format($C740da31596f24ef['amount'], 0), $C740da31596f24ef['reason'], $C740da31596f24ef['date']);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'client_logs') {
		if (AAcd47D8157a1A09('adv', 'client_request_log')) {
			$c6c389b9adf3a40c = array('`lines_logs`.`id`', '`lines`.`username`', '`streams`.`stream_display_name`', '`lines_logs`.`client_status`', '`lines_logs`.`user_agent`', '`lines_logs`.`ip`', '`lines_logs`.`date`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 7) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`lines_logs`.`client_status` LIKE ? OR `lines_logs`.`query_string` LIKE ? OR FROM_UNIXTIME(`date`) LIKE ? OR `lines_logs`.`user_agent` LIKE ? OR `lines_logs`.`ip` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `lines`.`username` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['range'])) {
			} else {
				$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
				$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

				if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
				} else {
					$a859a0996bb0f1ff = null;
				}

				if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
				} else {
					$B37c1f185be84c33 = null;
				}

				if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
				} else {
					$f86e19bdb1e7dae8[] = '(`lines_logs`.`date` >= ? AND `lines_logs`.`date` <= ?)';
					$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
					$Df2582e36fdd6160[] = $B37c1f185be84c33;
				}
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines_logs`.`client_status` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['filter'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines_logs` LEFT JOIN `streams` ON `streams`.`id` = `lines_logs`.`stream_id` LEFT JOIN `lines` ON `lines`.`id` = `lines_logs`.`user_id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `lines_logs`.`id`, `lines_logs`.`user_id`, `lines_logs`.`stream_id`, `streams`.`stream_display_name`, `streams`.`type`, `lines`.`username`, `lines_logs`.`client_status`, `lines_logs`.`query_string`, `lines_logs`.`user_agent`, `lines_logs`.`ip`, FROM_UNIXTIME(`lines_logs`.`date`) AS `date` FROM `lines_logs` LEFT JOIN `streams` ON `streams`.`id` = `lines_logs`.`stream_id` LEFT JOIN `lines` ON `lines`.`id` = `lines_logs`.`user_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							if (aacD47d8157a1a09('adv', 'edit_user')) {
								$a71afc14d6cd090d = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
							} else {
								$a71afc14d6cd090d = $C740da31596f24ef['username'];
							}

							$d48363bb091686d2 = array(1 => 'streams', 2 => 'movies', 3 => 'streams', 4 => 'radio', 5 => 'series');
							$ce2460e0c52a99da = array(1 => 'stream_view', 2 => 'stream_view', 3 => 'stream_view', 4 => 'stream_view');

							if (AACD47d8157A1a09('adv', $d48363bb091686d2[$C740da31596f24ef['type']])) {
								if ($C740da31596f24ef['type'] == 5) {
									$Fe753328765ad26c = "<a href='serie?id=" . $C740da31596f24ef['series_no'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
								} else {
									$Fe753328765ad26c = "<a href='" . $ce2460e0c52a99da[$C740da31596f24ef['type']] . '?id=' . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
								}
							} else {
								$Fe753328765ad26c = $C740da31596f24ef['stream_display_name'];
							}

							$fd6627d61b4b058f = explode(':', $C740da31596f24ef['ip']);
							$c59ec257c284c894 = "<a onClick=\"whois('" . $C740da31596f24ef['ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['ip'])) . '</a>';
							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $a71afc14d6cd090d, $Fe753328765ad26c, $b9d8a76ab5848022[$C740da31596f24ef['client_status']], $C740da31596f24ef['user_agent'], $c59ec257c284c894, $C740da31596f24ef['date']);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'reg_user_logs') {
		if (Aacd47d8157A1a09('adv', 'reg_userlog')) {
			$c6c389b9adf3a40c = array('`users_logs`.`id`', '`users`.`username`', '`users_logs`.`log_id`', '`users_logs`.`type`, `users_logs`.`action`', '`users_logs`.`cost`', '`users_logs`.`credits_after`', '`users_logs`.`date`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 3) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`users`.`username` LIKE ? OR `users_logs`.`deleted_info` LIKE ? OR `users_logs`.`action` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['range'])) {
			} else {
				$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
				$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

				if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
				} else {
					$a859a0996bb0f1ff = null;
				}

				if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
				} else {
					$B37c1f185be84c33 = null;
				}

				if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
				} else {
					$f86e19bdb1e7dae8[] = '(`users_logs`.`date` >= ? AND `users_logs`.`date` <= ?)';
					$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
					$Df2582e36fdd6160[] = $B37c1f185be84c33;
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`users_logs`.`owner` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`users_logs`.`action` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['filter'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `users_logs` LEFT JOIN `users` ON `users`.`id` = `users_logs`.`owner` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$D57b432dc56eb885 = D19b453Ac8E32C50();
				$A6d7047f2fda966c = 'SELECT `users`.`username`, `users_logs`.`id`, `users_logs`.`owner`, `users_logs`.`type`, `users_logs`.`action`, `users_logs`.`log_id`, `users_logs`.`package_id`, `users_logs`.`cost`, `users_logs`.`credits_after`, `users_logs`.`date`, `users_logs`.`deleted_info` FROM `users_logs` LEFT JOIN `users` ON `users`.`id` = `users_logs`.`owner` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							if (aACd47D8157a1a09('adv', 'edit_reguser')) {
								$Dbb9e190755fc819 = "<a href='user?id=" . $C740da31596f24ef['owner'] . "'>" . $C740da31596f24ef['username'] . '</a>';
							} else {
								$Dbb9e190755fc819 = $C740da31596f24ef['username'];
							}

							$cdc93dae5ba3d206 = array('line' => 'User Line', 'mag' => 'MAG Device', 'enigma' => 'Enigma2 Device', 'user' => 'Reseller')[$C740da31596f24ef['type']];
							$Fa016cbf0b72bfdd = '';

							switch ($C740da31596f24ef['action']) {
								case 'new':
									if ($C740da31596f24ef['package_id']) {
										$Fa016cbf0b72bfdd = 'Created New ' . $cdc93dae5ba3d206 . ' with Package: ' . $D57b432dc56eb885[$C740da31596f24ef['package_id']]['package_name'];
									} else {
										$Fa016cbf0b72bfdd = 'Created New ' . $cdc93dae5ba3d206;
									}

									break;

								case 'extend':
									if ($C740da31596f24ef['package_id']) {
										$Fa016cbf0b72bfdd = 'Extended ' . $cdc93dae5ba3d206 . ' with Package: ' . $D57b432dc56eb885[$C740da31596f24ef['package_id']]['package_name'];
									} else {
										$Fa016cbf0b72bfdd = 'Extended ' . $cdc93dae5ba3d206;
									}

									break;

								case 'convert':
									$Fa016cbf0b72bfdd = 'Converted Device to User Line';

									break;

								case 'edit':
									$Fa016cbf0b72bfdd = 'Edited ' . $cdc93dae5ba3d206;

									break;

								case 'enable':
									$Fa016cbf0b72bfdd = 'Enabled ' . $cdc93dae5ba3d206;

									break;

								case 'disable':
									$Fa016cbf0b72bfdd = 'Disabled ' . $cdc93dae5ba3d206;

									break;

								case 'delete':
									$Fa016cbf0b72bfdd = 'Deleted ' . $cdc93dae5ba3d206;

									break;

								case 'send_event':
									$Fa016cbf0b72bfdd = 'Sent Event to ' . $cdc93dae5ba3d206;

									break;

								case 'adjust_credits':
									$Fa016cbf0b72bfdd = 'Adjusted Credits by ' . $C740da31596f24ef['cost'];

									break;
							}
							$a4dd92d2bc66e08d = null;

							switch ($C740da31596f24ef['type']) {
								case 'line':
									$Ff014d0ebd314fcd = b4036EF9A1dB8473($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='line?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['username'] . '</a>';
									}

									break;

								case 'user':
									$Ff014d0ebd314fcd = FE76C4bcAF81BaA4($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='user?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['username'] . '</a>';
									}

									break;

								case 'mag':
									$Ff014d0ebd314fcd = bFE9937c6D242a3D($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='mag?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['mac'] . '</a>';
									}

									break;

								case 'enigma':
									$Ff014d0ebd314fcd = ba960Cab7fE0cD93($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='enigma?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['mac'] . '</a>';
									}

									break;
							}

							if ($a4dd92d2bc66e08d) {
							} else {
								$eef2045a92fba631 = json_decode($C740da31596f24ef['deleted_info'], true);

								if (is_array($eef2045a92fba631)) {
									if (isset($eef2045a92fba631['mac'])) {
										$a4dd92d2bc66e08d = "<span class='text-secondary'>" . $eef2045a92fba631['mac'] . '</span>';
									} else {
										$a4dd92d2bc66e08d = "<span class='text-secondary'>" . $eef2045a92fba631['username'] . '</span>';
									}
								} else {
									$a4dd92d2bc66e08d = "<span class='text-secondary'>DELETED</span>";
								}
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $Dbb9e190755fc819, $a4dd92d2bc66e08d, $Fa016cbf0b72bfdd, number_format($C740da31596f24ef['cost'], 0), number_format($C740da31596f24ef['credits_after'], 0), date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date']));
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'stream_errors') {
		if (AAcD47D8157A1A09('adv', 'stream_errors')) {
			$c6c389b9adf3a40c = array('`streams_errors`.`id`', '`streams`.`stream_display_name`', '`servers`.`server_name`', '`streams_errors`.`error`', '`streams_errors`.`date`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`stream_display_name` LIKE ? OR `servers`.`server_name` LIKE ? OR FROM_UNIXTIME(`date`) LIKE ? OR `streams_errors`.`error` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['range'])) {
			} else {
				$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
				$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

				if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
				} else {
					$a859a0996bb0f1ff = null;
				}

				if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
				} else {
					$B37c1f185be84c33 = null;
				}

				if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
				} else {
					$f86e19bdb1e7dae8[] = '(`streams_errors`.`date` >= ? AND `streams_errors`.`date` <= ?)';
					$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
					$Df2582e36fdd6160[] = $B37c1f185be84c33;
				}
			}

			if (0 >= intval(XUI::$rRequest['server'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`streams_errors`.`server_id` = ?';
				$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_errors` LEFT JOIN `streams` ON `streams`.`id` = `streams_errors`.`stream_id` LEFT JOIN `servers` ON `servers`.`id` = `streams_errors`.`server_id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams_errors`.`id`, `streams_errors`.`stream_id`, `streams`.`type`, `streams_errors`.`server_id`, `streams`.`stream_display_name`, `servers`.`server_name`, `streams_errors`.`error`, FROM_UNIXTIME(`streams_errors`.`date`) AS `date` FROM `streams_errors` LEFT JOIN `streams` ON `streams`.`id` = `streams_errors`.`stream_id` LEFT JOIN `servers` ON `servers`.`id` = `streams_errors`.`server_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$d48363bb091686d2 = array(1 => 'streams', 2 => 'movies', 3 => 'streams', 4 => 'radio', 5 => 'series');
							$ce2460e0c52a99da = array(1 => 'stream_view', 2 => 'stream_view', 3 => 'stream_view', 4 => 'stream_view');

							if (AAcD47d8157A1a09('adv', $d48363bb091686d2[$C740da31596f24ef['type']])) {
								if ($C740da31596f24ef['type'] == 5) {
									$Fe753328765ad26c = "<a href='serie?id=" . $C740da31596f24ef['series_no'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
								} else {
									$Fe753328765ad26c = "<a href='" . $ce2460e0c52a99da[$C740da31596f24ef['type']] . '?id=' . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
								}
							} else {
								$Fe753328765ad26c = $C740da31596f24ef['stream_display_name'];
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $Fe753328765ad26c, $C740da31596f24ef['server_name'], $C740da31596f24ef['error'], $C740da31596f24ef['date']);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'stream_unique') {
		if (AacD47d8157A1a09('adv', 'fingerprint')) {
			$A5dcdeb6ecbbf6bd = cBE87E2a9a996111('live');
			$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false, '`active_count`', null);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`streams`.`type` = 1';

			if (XUI::$rSettings['redis_handler']) {
			} else {
				$f86e19bdb1e7dae8[] = '(SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `lines_live`.`hls_end` = 0) > 0';
			}

			if (0 >= strlen(XUI::$rRequest['category'])) {
			} else {
				$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
				$Df2582e36fdd6160[] = XUI::$rRequest['category'];
			}

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 2) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`category_id`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `lines_live`.`hls_end` = 0) AS `active_count` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						$Cdb85875fd50f459 = array();

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
						}

						if (0 >= count($Cdb85875fd50f459)) {
						} else {
							$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, true, true);
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$C740da31596f24ef['active_count'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
						}

						if ($C740da31596f24ef['active_count'] != 0) {
							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $C740da31596f24ef['active_count'], "<button type='button' class='btn btn-info waves-effect waves-light btn-xs' href='javascript:void(0);' onClick='selectFingerprint(" . $C740da31596f24ef['id'] . ")'><i class='mdi mdi-fingerprint'></i></button>");
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						} else {
							$a85e1b7d42c346a0['recordsTotal']--;
						}
					}
				}
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);
			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'reg_users') {
		if (AACD47D8157A1a09('adv', 'mng_regusers')) {
			$c6c389b9adf3a40c = array('`users`.`id`', '`users`.`username`', '`users`.`owner_id`', '`users`.`ip`', '`users`.`status`', '`users`.`member_group_id`', '`users`.`credits`', false, false, false, false, '`users`.`last_login`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 7) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`users`.`id` LIKE ? OR `users`.`username` LIKE ? OR `users`.`notes` LIKE ? OR FROM_UNIXTIME(`users`.`date_registered`) LIKE ? OR FROM_UNIXTIME(`users`.`last_login`) LIKE ? OR `users`.`email` LIKE ? OR `users`.`ip` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == -1) {
					$f86e19bdb1e7dae8[] = '`users`.`status` = 1';
				} else {
					if (XUI::$rRequest['filter'] == -2) {
						$f86e19bdb1e7dae8[] = '`users`.`status` = 0';
					} else {
						$f86e19bdb1e7dae8[] = '`users`.`member_group_id` = ?';
						$Df2582e36fdd6160[] = XUI::$rRequest['filter'];
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`users`.`owner_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `users` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `users`.`member_group_id`, `users`.`id`, `users`.`status`, `users`.`notes`, `users`.`owner_id`, `users`.`credits`, `users`.`username`, `users`.`email`, `users`.`ip`, FROM_UNIXTIME(`users`.`date_registered`) AS `date_registered`, FROM_UNIXTIME(`users`.`last_login`) AS `last_login`, `users`.`status` FROM `users` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$D4253f9520627819 = $fcb256b788dd5243 = $b174976b99c4ec48 = $Ed94fed7e6680a78 = array();
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$b174976b99c4ec48[] = $C740da31596f24ef['id'];

						if (!$C740da31596f24ef['owner_id']) {
						} else {
							$Ed94fed7e6680a78[] = $C740da31596f24ef['owner_id'];
						}

						$D4253f9520627819[$C740da31596f24ef['id']] = array('is_reseller' => 0, 'user_lines' => 0, 'mag_lines' => 0, 'e2_lines' => 0, 'user_count' => 0, 'group_name' => null);
					}

					if (0 >= count($b174976b99c4ec48)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `users`.`id`, `users_groups`.`is_reseller`, `users_groups`.`group_name` FROM `users_groups` LEFT JOIN `users` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `users`.`id` IN (' . implode(',', $b174976b99c4ec48) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$D4253f9520627819[$C740da31596f24ef['id']]['is_reseller'] = $C740da31596f24ef['is_reseller'];
							$D4253f9520627819[$C740da31596f24ef['id']]['group_name'] = $C740da31596f24ef['group_name'];
						}
						$Fee0d5a474c96306->query('SELECT `member_id`, COUNT(`id`) AS `user_lines` FROM `lines` WHERE `member_id` IN (' . implode(',', $b174976b99c4ec48) . ') AND `lines`.`is_mag` = 0 AND `lines`.`is_e2` = 0 GROUP BY `member_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$D4253f9520627819[$C740da31596f24ef['member_id']]['user_lines'] = $C740da31596f24ef['user_lines'];
						}
						$Fee0d5a474c96306->query('SELECT `member_id`, COUNT(`id`) AS `mag_lines` FROM `lines` WHERE `member_id` IN (' . implode(',', $b174976b99c4ec48) . ') AND `lines`.`is_mag` = 1 AND `lines`.`is_e2` = 0 GROUP BY `member_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$D4253f9520627819[$C740da31596f24ef['member_id']]['mag_lines'] = $C740da31596f24ef['mag_lines'];
						}
						$Fee0d5a474c96306->query('SELECT `member_id`, COUNT(`id`) AS `e2_lines` FROM `lines` WHERE `member_id` IN (' . implode(',', $b174976b99c4ec48) . ') AND `lines`.`is_mag` = 0 AND `lines`.`is_e2` = 1 GROUP BY `member_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$D4253f9520627819[$C740da31596f24ef['member_id']]['e2_lines'] = $C740da31596f24ef['e2_lines'];
						}
					}

					if (0 >= count($Ed94fed7e6680a78)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `users` WHERE `id` IN (' . implode(',', $Ed94fed7e6680a78) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$fcb256b788dd5243[$C740da31596f24ef['id']] = $C740da31596f24ef['username'];
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (isset($fcb256b788dd5243[$C740da31596f24ef['owner_id']])) {
							$C740da31596f24ef['owner_username'] = $fcb256b788dd5243[$C740da31596f24ef['owner_id']];
						} else {
							$C740da31596f24ef['owner_username'] = '';
						}

						$C740da31596f24ef = array_merge($C740da31596f24ef, $D4253f9520627819[$C740da31596f24ef['id']]);

						if (!$B3f0f4a134021073) {
							if ($C740da31596f24ef['status'] == 1) {
								$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square tooltip" title="Active"></i>';
							} else {
								$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
							}

							if ($C740da31596f24ef['last_login']) {
							} else {
								$C740da31596f24ef['last_login'] = 'NEVER';
							}

							if (XUI::$rSettings['group_buttons']) {
								$ebab77ef4bee81e0 = '';

								if (0 >= strlen($C740da31596f24ef['notes'])) {
								} else {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								}

								$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

								if (!aacD47D8157a1a09('adv', 'edit_reguser')) {
								} else {
									if (!$C740da31596f24ef['is_reseller']) {
									} else {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="addCredits(' . $C740da31596f24ef['id'] . ');">Adjust Credits</a>';
									}

									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="user?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'user', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['username'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>';

									if ($C740da31596f24ef['status'] == 1) {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'disable');\">Disable</a>";
									} else {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'enable');\">Enable</a>";
									}

									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\">Delete</a>";
								}

								$ebab77ef4bee81e0 .= '</div></div>';
							} else {
								$ebab77ef4bee81e0 = '<div class="btn-group">';

								if (0 < strlen($C740da31596f24ef['notes'])) {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
								}

								if (!AACD47d8157a1A09('adv', 'edit_reguser')) {
								} else {
									if ($C740da31596f24ef['is_reseller']) {
										$ebab77ef4bee81e0 .= '<button title="Adjust Credits" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="addCredits(' . $C740da31596f24ef['id'] . ');"><i class="mdi mdi-coin"></i></button>';
									} else {
										$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-coin"></i></button>';
									}

									$ebab77ef4bee81e0 .= '<a href="user?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'user', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['username'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>';

									if ($C740da31596f24ef['status'] == 1) {
										$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
									} else {
										$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
									}

									$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}

								$ebab77ef4bee81e0 .= '</div>';
							}

							if (0 < strlen($C740da31596f24ef['ip'])) {
								$fd6627d61b4b058f = explode(':', $C740da31596f24ef['ip']);
								$c59ec257c284c894 = "<a onClick=\"whois('" . $C740da31596f24ef['ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['ip'])) . '</a>';
							} else {
								$c59ec257c284c894 = '';
							}

							if ($C740da31596f24ef['is_reseller']) {
								$F17f20a56056dab3 = '<button type="button" class="btn btn-purple btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['credits'], 0) . '</button>';
							} else {
								$F17f20a56056dab3 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">-</button>';
							}

							if (0 < $C740da31596f24ef['user_count']) {
								$c926828403592095 = '<a href="users?owner=' . intval($C740da31596f24ef['id']) . '"><button type="button" class="btn btn-pink btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['user_count'], 0) . '</button></a>';
							} else {
								$c926828403592095 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">0</button>';
							}

							if (0 < $C740da31596f24ef['user_lines']) {
								$Ee60e729075f9d1b = '<a href="lines?owner=' . intval($C740da31596f24ef['id']) . '"><button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['user_lines'], 0) . '</button></a>';
							} else {
								$Ee60e729075f9d1b = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">0</button>';
							}

							if (0 < $C740da31596f24ef['mag_lines']) {
								$bd1a02521af8196f = '<a href="mags?owner=' . intval($C740da31596f24ef['id']) . '"><button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['mag_lines'], 0) . '</button></a>';
							} else {
								$bd1a02521af8196f = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">0</button>';
							}

							if (0 < $C740da31596f24ef['e2_lines']) {
								$Dd60b10c6ae4634b = '<a href="enigmas?owner=' . intval($C740da31596f24ef['id']) . '"><button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['e2_lines'], 0) . '</button></a>';
							} else {
								$Dd60b10c6ae4634b = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">0</button>';
							}

							if (!isset(XUI::$rRequest['no_url'])) {
								$a85e1b7d42c346a0['data'][] = array("<a href='user?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['id'] . '</a>', "<a href='user?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['username'] . '</a>', "<a href='user?id=" . intval($C740da31596f24ef['owner_id']) . "'>" . $C740da31596f24ef['owner_username'] . '</a>', $c59ec257c284c894, $Ba23222f3ed2dc08, '<a href="users?filter=' . intval($C740da31596f24ef['member_group_id']) . '"><button type="button" class="btn btn-dark btn-fixed btn-xs waves-effect waves-light">' . $C740da31596f24ef['group_name'] . '</button></a>', $F17f20a56056dab3, $c926828403592095, $Ee60e729075f9d1b, $bd1a02521af8196f, $Dd60b10c6ae4634b, $C740da31596f24ef['last_login'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['username'], $C740da31596f24ef['owner_username'], $c59ec257c284c894, $Ba23222f3ed2dc08, '<button type="button" class="btn btn-dark btn-fixed btn-xs waves-effect waves-light">' . $C740da31596f24ef['group_name'] . '</button>', $F17f20a56056dab3, $c926828403592095, $Ee60e729075f9d1b, $bd1a02521af8196f, $Dd60b10c6ae4634b, $C740da31596f24ef['last_login'], $ebab77ef4bee81e0);
							}
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'asns') {
		if (Aacd47d8157a1A09('adv', 'block_isps')) {
			$c6c389b9adf3a40c = array('`blocked_asns`.`asn`', '`blocked_asns`.`isp`', '`blocked_asns`.`domain`', '`blocked_asns`.`country`', '`blocked_asns`.`num_ips`', '`blocked_asns`.`type`', '`blocked_asns`.`blocked`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 5) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`blocked_asns`.`asn` LIKE ? OR `blocked_asns`.`isp` LIKE ? OR `blocked_asns`.`domain` LIKE ? OR `blocked_asns`.`country` LIKE ? OR `blocked_asns`.`type` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`blocked_asns`.`blocked` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['filter'];
			}

			if (0 >= strlen(XUI::$rRequest['type'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`blocked_asns`.`type` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['type'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `blocked_asns` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `blocked_asns`.`id`, `blocked_asns`.`asn`, `blocked_asns`.`isp`, `blocked_asns`.`domain`, `blocked_asns`.`country`, `blocked_asns`.`num_ips`, `blocked_asns`.`type`, `blocked_asns`.`blocked` FROM `blocked_asns` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$ebab77ef4bee81e0 = '<div class="btn-group">';

							if ($C740da31596f24ef['blocked']) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-success waves-effect waves-light btn-xs" onClick="api(' . $C740da31596f24ef['id'] . ", 'allow');\"><i class=\"mdi mdi-check\"></i></button>";
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-danger waves-effect waves-light btn-xs" onClick="api(' . $C740da31596f24ef['id'] . ", 'block');\"><i class=\"mdi mdi-cancel\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '</div>';

							if ($C740da31596f24ef['blocked']) {
								$Ba23222f3ed2dc08 = '<button type="button" class="btn btn-danger btn-xs waves-effect waves-light btn-fixed">BLOCKED</button>';
							} else {
								$Ba23222f3ed2dc08 = '<button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed">ALLOWED</button>';
							}

							$E379394c7b1a273f = strtoupper($C740da31596f24ef['type']);
							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['asn'], $C740da31596f24ef['isp'], $C740da31596f24ef['domain'], '<img loading="lazy" src="assets/images/countries/' . strtolower($C740da31596f24ef['country']) . '.png">', number_format($C740da31596f24ef['num_ips'], 0), $E379394c7b1a273f, $Ba23222f3ed2dc08, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'series') {
		if (aaCD47D8157a1A09('adv', 'series') || aACd47D8157a1A09('adv', 'mass_sedits')) {
			$A5dcdeb6ecbbf6bd = cBe87E2a9A996111('series');
			$c6c389b9adf3a40c = array('`streams_series`.`id`', '`streams_series`.`cover`', '`streams_series`.`title`', '`streams_series`.`category_id`', '`latest_season`', '`episode_count`', false, '`streams_series`.`release_date`', '`streams_series`.`last_modified`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 3) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`streams_series`.`id` LIKE ? OR `streams_series`.`title` LIKE ? OR `streams_series`.`release_date` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['category'])) {
			} else {
				if (XUI::$rRequest['category'] == -1) {
					$f86e19bdb1e7dae8[] = '(`streams_series`.`tmdb_id` = 0 OR `streams_series`.`tmdb_id` IS NULL)';
				} else {
					if (XUI::$rRequest['category'] == -2) {
						$f86e19bdb1e7dae8[] = "(`streams_series`.`category_id` = '[]' OR `streams_series`.`category_id` IS NULL)";
					} else {
						$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams_series`.`category_id`, ?, '\$')";
						$Df2582e36fdd6160[] = XUI::$rRequest['category'];
					}
				}
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619 . ', `streams_series`.`id` ASC';
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `streams_series`.`id`, `streams_series`.`year`, `streams_series`.`rating`, `streams_series`.`cover`, `streams_series`.`title`, `streams_series`.`category_id`, `streams_series`.`tmdb_id`, `streams_series`.`release_date`, `streams_series`.`last_modified`, (SELECT MAX(`season_num`) FROM `streams_episodes` WHERE `series_id` = `streams_series`.`id`) AS `latest_season`, (SELECT COUNT(*) FROM `streams_episodes` WHERE `series_id` = `streams_series`.`id`) AS `episode_count` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

							if (0 < strlen(XUI::$rRequest['category'])) {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
							} else {
								$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
							}

							if (1 >= count($A38b42a281e3c3cf)) {
							} else {
								$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
							}

							if (XUI::$rSettings['group_buttons']) {
								$ebab77ef4bee81e0 = '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

								if (!aaCd47D8157A1a09('adv', 'add_episode')) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="episode?sid=' . $C740da31596f24ef['id'] . '">Add Episode(s)</a>';
								}

								if (!aacd47d8157A1A09('adv', 'episodes')) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="episodes?series=' . $C740da31596f24ef['id'] . '">View Episodes</a>';
								}

								if (!aacD47D8157A1a09('adv', 'edit_series')) {
								} else {
									$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="serie?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'serie', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['title'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>' . "\r\n\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\">Delete</a>";
								}

								$ebab77ef4bee81e0 .= '</div></div>';
							} else {
								$ebab77ef4bee81e0 = '<div class="btn-group">';

								if (!AaCd47D8157a1A09('adv', 'add_episode')) {
								} else {
									$ebab77ef4bee81e0 .= '<a href="episode?sid=' . $C740da31596f24ef['id'] . '"><button title="Add Episode(s)" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-plus-circle-outline"></i></button></a>';
								}

								if (!aAcd47D8157a1A09('adv', 'episodes')) {
								} else {
									$ebab77ef4bee81e0 .= '<a href="episodes?series=' . $C740da31596f24ef['id'] . '"><button title="View Episodes" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-eye"></i></button></a>';
								}

								if (!aacd47D8157a1a09('adv', 'edit_series')) {
								} else {
									$ebab77ef4bee81e0 .= '<a href="serie?id=' . $C740da31596f24ef['id'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'serie', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['title'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>' . "\r\n\t\t\t\t\t\t" . '<button type="button" title="Delete" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}

								$ebab77ef4bee81e0 .= '</div>';
							}

							if (0 < $C740da31596f24ef['latest_season']) {
								$C740da31596f24ef['latest_season'] = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['latest_season'] . '</button>';
							} else {
								$C740da31596f24ef['latest_season'] = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}

							if (0 < $C740da31596f24ef['episode_count']) {
								if (AAcD47d8157a1A09('adv', 'episodes')) {
									$C740da31596f24ef['episode_count'] = "<a href='episodes?series=" . $C740da31596f24ef['id'] . "'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['episode_count'] . '</button></a>';
								} else {
									$C740da31596f24ef['episode_count'] = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['episode_count'] . '</button>';
								}
							} else {
								$C740da31596f24ef['episode_count'] = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}

							if ($C740da31596f24ef['last_modified'] == 0) {
								$C740da31596f24ef['last_modified'] = 'Never';
							} else {
								$C740da31596f24ef['last_modified'] = date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['last_modified']);
							}

							if (!$C740da31596f24ef['release_date']) {
							} else {
								$C740da31596f24ef['release_date'] = date($F2d4d8f7981ac574['date_format'], strtotime($C740da31596f24ef['release_date']));
							}

							if (0 < $C740da31596f24ef['tmdb_id']) {
								$a69d576081840514 = '<button type="button" class="btn btn-success btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-check-circle"></i></button>';
							} else {
								$a69d576081840514 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xs"><i class="text-light fas fa-minus-circle"></i></button>';
							}

							if (0 < strlen($C740da31596f24ef['cover']) && XUI::$rSettings['show_images']) {
								$A639a7baefc720ee = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['cover'] . "'><img loading='lazy' src='resize?maxh=58&maxw=32&url=" . $C740da31596f24ef['cover'] . "' /></a>";
							} else {
								$A639a7baefc720ee = '';
							}

							if (AAcD47D8157a1a09('adv', 'episodes')) {
								$C3c8913edb801c35 = "<a href='serie?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['id'] . '</a>';
								$c608db3e24256b76 = "<a href='serie?id=" . intval($C740da31596f24ef['id']) . "'><strong>" . $C740da31596f24ef['title'] . '</strong></a>';
							} else {
								$C3c8913edb801c35 = $C740da31596f24ef['id'];
								$c608db3e24256b76 = '<strong>' . $C740da31596f24ef['title'] . '</strong>';
							}

							$e962a80487b84e46 = '';

							if (!$C740da31596f24ef['rating']) {
							} else {
								$B0ac3a61df74ba36 = round($C740da31596f24ef['rating']) / 2;
								$d25560ad0b146132 = floor($B0ac3a61df74ba36);
								$b39c3caa0856cfa2 = 0 < $B0ac3a61df74ba36 - $d25560ad0b146132;
								$D46dfa8113384246 = 5 - ($d25560ad0b146132 + (($b39c3caa0856cfa2 ? 1 : 0)));

								if (0 >= $d25560ad0b146132) {
								} else {
									foreach (range(1, $d25560ad0b146132) as $Ea22c4a9ab5b2176) {
										$e962a80487b84e46 .= "<i class='mdi mdi-star'></i>";
									}
								}

								if (!$b39c3caa0856cfa2) {
								} else {
									$e962a80487b84e46 .= "<i class='mdi mdi-star-half'></i>";
								}

								if (0 >= $D46dfa8113384246) {
								} else {
									foreach (range(1, $D46dfa8113384246) as $Ea22c4a9ab5b2176) {
										$e962a80487b84e46 .= "<i class='mdi mdi-star-outline'></i>";
									}
								}
							}

							$A02729c83b6cd395 = ($C740da31596f24ef['year'] ? '<strong>' . $C740da31596f24ef['year'] . '</strong> &nbsp;' : '');
							$c608db3e24256b76 .= "<br><span style='font-size:11px;'>" . $A02729c83b6cd395 . $e962a80487b84e46 . '</span></a>';
							$a85e1b7d42c346a0['data'][] = array($C3c8913edb801c35, $A639a7baefc720ee, $c608db3e24256b76, $A1925ae53e9307eb, $C740da31596f24ef['latest_season'], $C740da31596f24ef['episode_count'], $a69d576081840514, $C740da31596f24ef['release_date'], $C740da31596f24ef['last_modified'], $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'episodes') {
		if (AaCD47d8157A1A09('adv', 'episodes') || aACd47D8157A1A09('adv', 'mass_sedits')) {
			$c6c389b9adf3a40c = array('`streams`.`id`', false, '`streams`.`stream_display_name`', '`server_name`', '`clients`', '`streams_servers`.`stream_started`', false, false, '`streams_servers`.`bitrate`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`streams`.`type` = 5';
			$f69f03301cf5dc4e = false;

			if (isset(XUI::$rRequest['stream_id'])) {
				$f86e19bdb1e7dae8[] = '`streams`.`id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];
				$Ccfe11bd7a796290 = 'ORDER BY `streams_servers`.`server_stream_id` ASC';
			} else {
				if (isset(XUI::$rRequest['source_id'])) {
					$f86e19bdb1e7dae8[] = 'MD5(`streams`.`stream_source`) = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['source_id'];
					$Ccfe11bd7a796290 = 'ORDER BY `streams_servers`.`server_stream_id` ASC';
				} else {
					if (0 >= strlen(XUI::$rRequest['search']['value'])) {
					} else {
						foreach (range(1, 5) as $b6f0b24a56fe41b6) {
							$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
						}
						$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams_series`.`title` LIKE ? OR `streams`.`notes` LIKE ? OR `streams_servers`.`current_source` LIKE ?)';
					}

					if (0 >= strlen(XUI::$rRequest['series'])) {
					} else {
						$f86e19bdb1e7dae8[] = '`streams_series`.`id` = ?';
						$Df2582e36fdd6160[] = XUI::$rRequest['series'];
					}

					if (!isset(XUI::$rRequest['refresh'])) {
					} else {
						$f86e19bdb1e7dae8 = array('`streams`.`id` IN (' . implode(',', array_map('intval', explode(',', XUI::$rRequest['refresh']))) . ')');
						$D031c48a1422c07e = 0;
						$E400a3101514583e = 1000;
					}

					if (0 >= strlen(XUI::$rRequest['filter'])) {
					} else {
						if (XUI::$rRequest['filter'] == 1) {
							$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` <> 1)';
						} else {
							if (XUI::$rRequest['filter'] == 2) {
								$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 1 AND `streams_servers`.`stream_status` <> 1)';
							} else {
								if (XUI::$rRequest['filter'] == 3) {
									$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND `streams_servers`.`stream_status` = 1)';
								} else {
									if (XUI::$rRequest['filter'] == 4) {
										$f86e19bdb1e7dae8[] = '(`streams`.`direct_source` = 0 AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 1)';
									} else {
										if (XUI::$rRequest['filter'] == 5) {
											$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 1';
										} else {
											if (XUI::$rRequest['filter'] == 6) {
												$f86e19bdb1e7dae8[] = '`streams`.`id` IN (SELECT MIN(`id`) FROM `streams` WHERE `type` = 5 GROUP BY `stream_source` HAVING COUNT(`stream_source`) > 1)';
												$f69f03301cf5dc4e = true;
											} else {
												if (XUI::$rRequest['filter'] != 7) {
												} else {
													$f86e19bdb1e7dae8[] = '`streams`.`transcode_profile_id` > 0';
												}
											}
										}
									}
								}
							}
						}
					}

					if (0 >= strlen(XUI::$rRequest['audio'])) {
					} else {
						if (XUI::$rRequest['audio'] == -1) {
							$f86e19bdb1e7dae8[] = '`streams_servers`.`audio_codec` IS NULL';
						} else {
							$f86e19bdb1e7dae8[] = '`streams_servers`.`audio_codec` = ?';
							$Df2582e36fdd6160[] = XUI::$rRequest['audio'];
						}
					}

					if (0 >= strlen(XUI::$rRequest['video'])) {
					} else {
						if (XUI::$rRequest['video'] == -1) {
							$f86e19bdb1e7dae8[] = '`streams_servers`.`video_codec` IS NULL';
						} else {
							$f86e19bdb1e7dae8[] = '`streams_servers`.`video_codec` = ?';
							$Df2582e36fdd6160[] = XUI::$rRequest['video'];
						}
					}

					if (0 >= strlen(XUI::$rRequest['resolution'])) {
					} else {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`resolution` = ?';
						$Df2582e36fdd6160[] = (intval(XUI::$rRequest['resolution']) ?: null);
					}

					if (0 < intval(XUI::$rRequest['server'])) {
						$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
						$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
					} else {
						if (intval(XUI::$rRequest['server']) != -1) {
						} else {
							$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` IS NULL';
						}
					}

					if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
					} else {
						$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
						$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
					}
				}
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (isset(XUI::$rRequest['single'])) {
				$F2d4d8f7981ac574['streams_grouped'] = 0;
			} else {
				if (!isset(XUI::$rRequest['grouped'])) {
				} else {
					$F2d4d8f7981ac574['streams_grouped'] = 1;
				}
			}

			$a85e1b7d42c346a0['recordsTotal'] = 0;

			if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
				$Fc3bbe383da3a3f3 = 'SELECT COUNT(DISTINCT(`streams`.`id`)) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ';';
			} else {
				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ';';
			}

			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, MD5(`streams`.`stream_source`) AS `source`, `streams_servers`.`to_analyze`, `streams`.`movie_properties`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams_series`.`title`, `streams_series`.`seasons`, `streams_series`.`id` AS `sid`, `streams_episodes`.`season_num` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ' GROUP BY `streams`.`id` ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, MD5(`streams`.`stream_source`) AS `source`, `streams_servers`.`to_analyze`, `streams`.`movie_properties`, `streams`.`target_container`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`notes`, `streams`.`direct_source`, `streams`.`direct_proxy`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`stream_status`, `streams_servers`.`stream_started`, `streams_servers`.`stream_info`, `streams_servers`.`current_source`, `streams_servers`.`bitrate`, `streams_servers`.`progress_info`, `streams_servers`.`on_demand`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name`, (SELECT COUNT(*) FROM `lines_live` WHERE `lines_live`.`server_id` = `streams_servers`.`server_id` AND `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0) AS `clients`, `streams_series`.`title`, `streams_series`.`seasons`, `streams_series`.`id` AS `sid`, `streams_episodes`.`season_num` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				}

				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$caa77b80211665a0 = $Cdb85875fd50f459 = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
					}

					if (0 >= count($Cdb85875fd50f459)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `stream_id`, COUNT(`server_stream_id`) AS `count` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') GROUP BY `stream_id`;');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$caa77b80211665a0[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
						}

						if (!XUI::$rSettings['redis_handler']) {
						} else {
							if ($F2d4d8f7981ac574['streams_grouped']) {
								$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, true, true);
							} else {
								$bde5957fb5fa9547 = XUI::getStreamConnections($Cdb85875fd50f459, false, false);
							}
						}

						if (!$f69f03301cf5dc4e) {
						} else {
							$d94e5f0792c69064 = array();
							$Fee0d5a474c96306->query('SELECT MD5(`stream_source`) AS `source`, COUNT(`stream_source`) AS `count` FROM `streams` WHERE `stream_source` IN (SELECT `stream_source` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ')) GROUP BY `stream_source` HAVING COUNT(`stream_source`) > 1;');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$d94e5f0792c69064[$C740da31596f24ef['source']] = $C740da31596f24ef['count'];
							}
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!XUI::$rSettings['redis_handler']) {
						} else {
							if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
								$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
							} else {
								$C740da31596f24ef['clients'] = (count($bde5957fb5fa9547[$C740da31596f24ef['id']][$C740da31596f24ef['server_id']]) ?: 0);
							}
						}

						if (!$B3f0f4a134021073) {
							$dc850cbc5eb6f918 = $C740da31596f24ef['title'] . ' - Season ' . $C740da31596f24ef['season_num'];
							$Ef28eaee0050d7a5 = '<strong>' . $C740da31596f24ef['stream_display_name'] . "</strong><br><span style='font-size:11px;'>" . $dc850cbc5eb6f918 . '</span>';

							if ($C740da31596f24ef['server_name']) {
								if (Aacd47d8157A1A09('adv', 'servers')) {
									$B00ef71aa2cd7a26 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
								} else {
									$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];
								}

								if (!($F2d4d8f7981ac574['streams_grouped'] && 1 < $caa77b80211665a0[$C740da31596f24ef['id']])) {
								} else {
									$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"View All Servers\" onClick=\"viewSources('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', " . intval($C740da31596f24ef['id']) . ");\" type='button' class='tooltip-left btn btn-info btn-xs waves-effect waves-light'>+ " . ($caa77b80211665a0[$C740da31596f24ef['id']] - 1) . '</button>';
								}

								if ($a8bb73cba48fb7f6[$C740da31596f24ef['server_id']]['last_status'] == 1) {
								} else {
									$B00ef71aa2cd7a26 .= " &nbsp; <button title=\"Server Offline!<br/>Uptime cannot be confirmed.\" type='button' class='tooltip btn btn-danger btn-xs waves-effect waves-light'><i class='mdi mdi-alert'></i></button>";
								}
							} else {
								$B00ef71aa2cd7a26 = 'No Server Selected';
							}

							if ($F2d4d8f7981ac574['streams_grouped']) {
							} else {
								$ecc9029bfbc77eed = "<br/><span style='font-size:11px;'>" . parse_url($C740da31596f24ef['current_source'])['host'] . '</span>';
								$B00ef71aa2cd7a26 .= $ecc9029bfbc77eed;
							}

							$fad73125a2cca3ed = 0;
							$b45800af0138159b = 0;

							if (intval($C740da31596f24ef['direct_source']) == 1) {
								if (intval($C740da31596f24ef['direct_proxy']) == 1) {
									$b45800af0138159b = 5;
								} else {
									$b45800af0138159b = 3;
								}
							} else {
								if (!is_null($C740da31596f24ef['pid']) && 0 < $C740da31596f24ef['pid']) {
									if ($C740da31596f24ef['to_analyze'] == 1) {
										$b45800af0138159b = 2;
									} else {
										if ($C740da31596f24ef['stream_status'] == 1) {
											$b45800af0138159b = 4;
										} else {
											$b45800af0138159b = 1;
										}
									}
								} else {
									$b45800af0138159b = 0;
								}
							}

							if ($C740da31596f24ef['server_id']) {
							} else {
								$C740da31596f24ef['server_id'] = 0;
							}

							if ($F2d4d8f7981ac574['streams_grouped'] != 1) {
							} else {
								$C740da31596f24ef['server_id'] = -1;
							}

							if (AACd47D8157a1a09('adv', 'live_connections')) {
								if (0 < $C740da31596f24ef['clients']) {
									$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ', ' . intval($C740da31596f24ef['server_id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button></a>';
								} else {
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
								}
							} else {
								if (0 < $C740da31596f24ef['clients']) {
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['clients'], 0) . '</button>';
								} else {
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
								}
							}

							if (XUI::$rSettings['group_buttons']) {
								$ebab77ef4bee81e0 = '';

								if (0 >= strlen($C740da31596f24ef['notes'])) {
								} else {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								}

								$ebab77ef4bee81e0 .= '<div class="btn-group dropdown"><a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a><div class="dropdown-menu dropdown-menu-right">';

								if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && AAcd47D8157a1A09('adv', 'edit_episode')) {
									if (intval($b45800af0138159b) == 1) {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Encode</a>";
									} else {
										if (intval($b45800af0138159b) == 3) {
										} else {
											if (intval($b45800af0138159b) == 2) {
												$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop Encoding</a>";
											} else {
												$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Encode</a>";
											}
										}
									}

									if (!isset(XUI::$rRequest['single'])) {
									} else {
										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
									}
								} else {
									if (!AacD47D8157A1a09('adv', 'edit_episode')) {
									} else {
										if (intval($b45800af0138159b) == 1) {
											$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Encode</a>";
										} else {
											if (intval($b45800af0138159b) == 3) {
											} else {
												if (intval($b45800af0138159b) == 2) {
													$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\">Stop Encoding</a>";
												} else {
													$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\">Encode</a>";
												}
											}
										}

										$ebab77ef4bee81e0 .= '<a class="dropdown-item" href="episode?id=' . $C740da31596f24ef['id'] . '&sid=' . $C740da31596f24ef['sid'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'episode', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '>Edit</a>' . "\r\n\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\">Delete</a>";
									}
								}

								$ebab77ef4bee81e0 .= '</div></div>';
							} else {
								$ebab77ef4bee81e0 = '<div class="btn-group">';

								if ((isset(XUI::$rRequest['single']) || isset(XUI::$rRequest['simple'])) && AaCd47D8157A1a09('adv', 'edit_episode')) {
									if (intval($b45800af0138159b) == 1) {
										$ebab77ef4bee81e0 .= '<button title="Encode" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-refresh\"></i></button>";
									} else {
										if (intval($b45800af0138159b) == 3) {
											$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop"><i class="mdi mdi-stop"></i></button>';
										} else {
											if (intval($b45800af0138159b) == 2) {
												$ebab77ef4bee81e0 .= '<button title="Stop Encoding" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
											} else {
												$ebab77ef4bee81e0 .= '<button title="Encode" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
											}
										}
									}

									if (!isset(XUI::$rRequest['single'])) {
									} else {
										$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
									}
								} else {
									if (0 < strlen($C740da31596f24ef['notes'])) {
										$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
									} else {
										$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
									}

									if (!aAcD47d8157a1a09('adv', 'edit_episode')) {
									} else {
										if (intval($b45800af0138159b) == 1) {
											$ebab77ef4bee81e0 .= '<button title="Encode" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-refresh\"></i></button>";
										} else {
											if (intval($b45800af0138159b) == 3) {
												$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop"><i class="mdi mdi-stop"></i></button>';
											} else {
												if (intval($b45800af0138159b) == 2) {
													$ebab77ef4bee81e0 .= '<button title="Stop Encoding" type="button" class="btn btn-light waves-effect waves-light btn-xs api-stop tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
												} else {
													$ebab77ef4bee81e0 .= '<button title="Encode" type="button" class="btn btn-light waves-effect waves-light btn-xs api-start tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'start');\"><i class=\"mdi mdi-play\"></i></button>";
												}
											}
										}

										$ebab77ef4bee81e0 .= '<a href="episode?id=' . $C740da31596f24ef['id'] . '&sid=' . $C740da31596f24ef['sid'] . '" ' . ((XUI::$rSettings['modal_edit'] ? "onClick=\"editModal(event, 'episode', " . intval($C740da31596f24ef['id']) . ", '" . str_replace('"', '&quot;', str_replace("'", "\\'", $C740da31596f24ef['stream_display_name'])) . "')\" data-modal=\"true\"" : '')) . '><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil"></i></button></a>' . "\r\n\t\t\t\t\t\t\t" . '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ', ' . $C740da31596f24ef['server_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
									}
								}

								$ebab77ef4bee81e0 .= '</div>';
							}

							if ($f69f03301cf5dc4e) {
								$Baeca850f087a7a2 = ($d94e5f0792c69064[$C740da31596f24ef['source']] - 1 ?: 0);
								$b5e8b95fdf13ba62 = "<a href='javascript: void(0);' onClick=\"viewDuplicates('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', '" . $C740da31596f24ef['source'] . "');\">Duplicate of <strong>" . $Baeca850f087a7a2 . '</strong> other episode' . (($Baeca850f087a7a2 == 1 ? '' : 's')) . '</a>';
							} else {
								$b5e8b95fdf13ba62 = "<table style='font-size: 10px;' class='table-data nowrap' align='center'><tbody><tr><td colspan='3'>No information available</td></tr></tbody></table>";
								$bb0071da5a239b0c = json_decode($C740da31596f24ef['stream_info'], true);

								if ($b45800af0138159b != 1) {
								} else {
									if (isset($bb0071da5a239b0c['codecs']['video'])) {
									} else {
										$bb0071da5a239b0c['codecs']['video'] = array('width' => '?', 'height' => '?', 'codec_name' => 'N/A', 'r_frame_rate' => '--');
									}

									if (isset($bb0071da5a239b0c['codecs']['audio'])) {
									} else {
										$bb0071da5a239b0c['codecs']['audio'] = array('codec_name' => 'N/A');
									}

									if ($C740da31596f24ef['bitrate'] != 0) {
									} else {
										$C740da31596f24ef['bitrate'] = '?';
									}

									$b5e8b95fdf13ba62 = "<table class='table-data nowrap table-data-120' align='center'>" . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='double'>" . number_format($C740da31596f24ef['bitrate'], 0) . ' Kbps</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='text-success'><i class='mdi mdi-video' data-name='mdi-video'></i></td>" . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='text-success'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>" . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . "<td class='double'>" . $bb0071da5a239b0c['codecs']['video']['width'] . ' x ' . $bb0071da5a239b0c['codecs']['video']['height'] . '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . $bb0071da5a239b0c['codecs']['video']['codec_name'] . '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . $bb0071da5a239b0c['codecs']['audio']['codec_name'] . '</td>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t" . '</table>';
								}
							}

							if (aAcd47D8157a1A09('adv', 'player')) {
								if (intval($b45800af0138159b) == 1 || $b45800af0138159b == 3) {
									if (empty($bb0071da5a239b0c['codecs']['video']['codec_name']) || strtoupper($bb0071da5a239b0c['codecs']['video']['codec_name']) == 'H264' || strtoupper($bb0071da5a239b0c['codecs']['video']['codec_name']) == 'N/A') {
										$cafddc0a05fb9f1f = '<button title="Play" type="button" class="btn btn-info waves-effect waves-light btn-xs tooltip" onClick="player(' . $C740da31596f24ef['id'] . ", '" . $C740da31596f24ef['target_container'] . "');\"><i class=\"mdi mdi-play\"></i></button>";
									} else {
										$cafddc0a05fb9f1f = '<button type="button" class="btn btn-dark waves-effect waves-light btn-xs tooltip" title="Incompatible Video Codec"><i class="mdi mdi-play"></i></button>';
									}
								} else {
									$cafddc0a05fb9f1f = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button>';
								}
							} else {
								$cafddc0a05fb9f1f = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button>';
							}

							$A639a7baefc720ee = '';
							$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);

							if (!(0 < strlen($D92b16dc36690ab9['movie_image']) && XUI::$rSettings['show_images'])) {
							} else {
								$A639a7baefc720ee = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $D92b16dc36690ab9['movie_image'] . "'><img loading='lazy' src='resize?maxh=32&maxw=64&url=" . $D92b16dc36690ab9['movie_image'] . "' /></a>";
							}

							$C3c8913edb801c35 = $C740da31596f24ef['id'];

							if ($F2d4d8f7981ac574['streams_grouped'] || 1 >= $caa77b80211665a0[$C740da31596f24ef['id']]) {
							} else {
								$C3c8913edb801c35 .= '-' . $C740da31596f24ef['server_id'];
							}

							$a85e1b7d42c346a0['data'][] = array("<a href='stream_view?id=" . intval($C740da31596f24ef['id']) . "'>" . $C3c8913edb801c35 . '</a>', $A639a7baefc720ee, "<a href='stream_view?id=" . intval($C740da31596f24ef['id']) . "'>" . $Ef28eaee0050d7a5 . '</a>', $B00ef71aa2cd7a26, $ec5b28bb1cbf9f2d, $f45f1268c76ac2a3[$b45800af0138159b], $ebab77ef4bee81e0, $cafddc0a05fb9f1f, $b5e8b95fdf13ba62);
						} else {
							unset($a85e1b7d42c346a0['source']);
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'backups') {
		if (AacD47D8157A1A09('adv', 'database')) {
			$f592b55eda404013 = array_reverse(F4e14f6fe7A86d2C());
			$b196fdd40559c58e = array();

			if (0 >= strlen($F2d4d8f7981ac574['dropbox_token'])) {
			} else {
				foreach (array_reverse(c643339b29c504E4()) as $db13ebf912ff273c) {
					$b196fdd40559c58e[$db13ebf912ff273c['name']] = $db13ebf912ff273c;
				}
			}

			$a85e1b7d42c346a0 = array('draw' => intval(XUI::$rRequest['draw']), 'recordsTotal' => count($f592b55eda404013), 'recordsFiltered' => count($f592b55eda404013), 'data' => array());
			$F78d877efc07adfd = array();

			foreach ($f592b55eda404013 as $db13ebf912ff273c) {
				$ebab77ef4bee81e0 = "<div class=\"btn-group\"><button type=\"button\" title=\"Restore Backup\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $db13ebf912ff273c['filename'] . "', 'restore');\"><i class=\"mdi mdi-folder-upload\"></i></button>" . "\r\n" . "        <button type=\"button\" title=\"Delete Backup\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $db13ebf912ff273c['filename'] . "', 'delete');\"><i class=\"mdi mdi-close\"></i></button></div>";
				$Eaff27895a33cc74 = "<i class='text-success fas fa-square'></i>";

				if (isset($b196fdd40559c58e[$db13ebf912ff273c['filename']])) {
					$Df5829527466e3d6 = "<i class='text-success fas fa-square'></i>";
					unset($b196fdd40559c58e[$db13ebf912ff273c['filename']]);
				} else {
					if (file_exists(XUI_HOME . 'backups/' . $db13ebf912ff273c['filename'] . '.error')) {
						$Df5829527466e3d6 = "<i title='" . htmlspecialchars(file_get_contents(XUI_HOME . 'backups/' . $db13ebf912ff273c['filename'] . '.error')) . "' class='text-danger fas fa-square tooltip'></i>";
					} else {
						if (file_exists(XUI_HOME . 'backups/' . $db13ebf912ff273c['filename'] . '.uploading') && time() - filemtime(XUI_HOME . 'backups/' . $db13ebf912ff273c['filename'] . '.uploading') < 600) {
							$Df5829527466e3d6 = "<i title='Uploading...' class='text-warning fas fa-square tooltip'></i>";
						} else {
							$Df5829527466e3d6 = "<i class='text-secondary fas fa-square'></i>";
						}
					}
				}

				$F78d877efc07adfd[] = $db13ebf912ff273c['filename'];
				$a85e1b7d42c346a0['data'][] = array(date($F2d4d8f7981ac574['datetime_format'], strtotime($db13ebf912ff273c['date'])), $db13ebf912ff273c['filename'], ceil($db13ebf912ff273c['filesize'] / 1024 / 1024) . ' MB', $Eaff27895a33cc74, $Df5829527466e3d6, $ebab77ef4bee81e0);
			}

			foreach ($b196fdd40559c58e as $db13ebf912ff273c) {
				$ebab77ef4bee81e0 = "<div class=\"btn-group\"><button type=\"button\" title=\"Restore Backup\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $db13ebf912ff273c['name'] . "', 'restore');\"><i class=\"mdi mdi-folder-upload\"></i></button>" . "\r\n" . "        <button type=\"button\" title=\"Delete Backup\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $db13ebf912ff273c['name'] . "', 'delete');\"><i class=\"mdi mdi-close\"></i></button></div>";

				if (in_array($db13ebf912ff273c['name'], $F78d877efc07adfd)) {
					$Eaff27895a33cc74 = "<i class='text-success fas fa-square'></i>";
				} else {
					$Eaff27895a33cc74 = "<i class='text-secondary fas fa-square'></i>";
				}

				$Df5829527466e3d6 = "<i class='text-success fas fa-square'></i>";
				$a85e1b7d42c346a0['data'][] = array(date($F2d4d8f7981ac574['datetime_format'], $db13ebf912ff273c['time']), $db13ebf912ff273c['name'], ceil($db13ebf912ff273c['size'] / 1024 / 1024) . ' MB', $Eaff27895a33cc74, $Df5829527466e3d6, $ebab77ef4bee81e0);
			}
			echo json_encode($a85e1b7d42c346a0);

			exit();
		} else {
			exit();
		}
	} else {
		if ($E379394c7b1a273f == 'watch_output') {
			if (aACd47d8157A1a09('adv', 'folder_watch_output')) {
				$c6c389b9adf3a40c = array('`watch_logs`.`id`', '`watch_logs`.`type`', '`watch_logs`.`server_id`', '`watch_logs`.`filename`', '`watch_logs`.`status`', '`watch_logs`.`dateadded`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`watch_logs`.`id` LIKE ? OR `watch_logs`.`filename` LIKE ? OR `watch_logs`.`dateadded` LIKE ?)';
				}

				if (0 >= intval(XUI::$rRequest['server'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`watch_logs`.`server_id` = ?';
					$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
				}

				if (0 >= strlen(XUI::$rRequest['type'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`watch_logs`.`type` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['type'];
				}

				if (0 >= strlen(XUI::$rRequest['status'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`watch_logs`.`status` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['status'];
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `watch_logs` LEFT JOIN `servers` ON `servers`.`id` = `watch_logs`.`server_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `watch_logs`.`id`, `watch_logs`.`type`, `watch_logs`.`server_id`, `servers`.`server_name`, `watch_logs`.`filename`, `watch_logs`.`status`, `watch_logs`.`stream_id`, `watch_logs`.`dateadded` FROM `watch_logs` LEFT JOIN `servers` ON `servers`.`id` = `watch_logs`.`server_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<div class="btn-group">';

								if (0 >= $C740da31596f24ef['stream_id']) {
								} else {
									if ($C740da31596f24ef['type'] == 1) {
										if (!AaCD47D8157A1A09('adv', 'edit_movie')) {
										} else {
											$ebab77ef4bee81e0 = '<a href="stream_view?id=' . $C740da31596f24ef['stream_id'] . '"><button title="View Movie" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-eye"></i></button></a>';
										}
									} else {
										if (!aacD47d8157a1A09('adv', 'edit_episode')) {
										} else {
											$ebab77ef4bee81e0 = '<a href="stream_view?id=' . $C740da31596f24ef['stream_id'] . '"><button title="View Episode" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-eye"></i></button></a>';
										}
									}
								}

								if (!(1 < $C740da31596f24ef['status'] && $C740da31596f24ef['type'] == 1)) {
								} else {
									$ebab77ef4bee81e0 .= '<a href="movie.php?path=' . urlencode('s:' . $C740da31596f24ef['server_id'] . ':' . $C740da31596f24ef['filename']) . '"><button type="button" title="Manual Match" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-plus"></i></button></a>';
								}

								$ebab77ef4bee81e0 .= '<button type="button" title="Delete" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								$ebab77ef4bee81e0 .= '</div>';

								if (aaCd47D8157A1A09('adv', 'servers')) {
									$e81220b4451f37c9 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
								} else {
									$e81220b4451f37c9 = $C740da31596f24ef['server_name'];
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], array(1 => 'Movies', 2 => 'Series')[$C740da31596f24ef['type']], $e81220b4451f37c9, $C740da31596f24ef['filename'], $b24ad57311c6310c[$C740da31596f24ef['status']], $C740da31596f24ef['dateadded'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'mysql_syslog') {
			if ($B2ff75c438fb3031['is_admin'] && aAcd47D8157a1a09('adv', 'panel_logs')) {
				$c6c389b9adf3a40c = array('`mysql_syslog`.`date`', '`servers`.`server_name`', '`mysql_syslog`.`type`', '`mysql_syslog`.`error`', '`mysql_syslog`.`ip`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`mysql_syslog`.`ip` LIKE ? OR `mysql_syslog`.`type` LIKE ? OR `mysql_syslog`.`error` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `mysql_syslog` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$cda44bf16c8f250e = array();
					$Fee0d5a474c96306->query('SELECT `ip` FROM `blocked_ips`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$cda44bf16c8f250e[] = $C740da31596f24ef['ip'];
					}
					$A6d7047f2fda966c = 'SELECT `mysql_syslog`.`id`, `mysql_syslog`.`server_id`, `servers`.`server_name`, `mysql_syslog`.`type`, `mysql_syslog`.`error`, `mysql_syslog`.`ip`, `mysql_syslog`.`date` FROM `mysql_syslog` LEFT JOIN `servers` ON `servers`.`id` = `mysql_syslog`.`server_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								if ($C740da31596f24ef['ip'] != '127.0.0.1') {
								} else {
									$C740da31596f24ef['ip'] = 'localhost';
								}

								if (0 < strlen($C740da31596f24ef['ip']) && $C740da31596f24ef['ip'] != 'localhost') {
									if (!in_array($C740da31596f24ef['ip'], $cda44bf16c8f250e)) {
										$ebab77ef4bee81e0 = "<button title=\"Block IP\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['ip'] . "', 'block');\"><i class=\"fas fa-hammer\"></i></button>";
									} else {
										$ebab77ef4bee81e0 = '<button title="IP Already Blocked" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="fas fa-hammer"></i></button>';
									}

									$fd6627d61b4b058f = explode(':', $C740da31596f24ef['ip']);
									$c59ec257c284c894 = "<a onClick=\"whois('" . $C740da31596f24ef['ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['ip'])) . '</a>';
								} else {
									$ebab77ef4bee81e0 = '<button type="button" class="btn btn-light waves-effect waves-light btn-xs" disabled><i class="fas fa-hammer"></i></button>';
									$c59ec257c284c894 = 'localhost';
								}

								$a85e1b7d42c346a0['data'][] = array(date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date']), "<a href='server_view?id=" . intval($C740da31596f24ef['server_id']) . "'>" . $C740da31596f24ef['server_name'] . '</a>', $C740da31596f24ef['type'], $C740da31596f24ef['error'], $c59ec257c284c894, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'panel_logs') {
			if ($B2ff75c438fb3031['is_admin'] && AACD47d8157A1A09('adv', 'panel_logs')) {
				$c6c389b9adf3a40c = array('`panel_logs`.`date`', '`servers`.`server_name`', '`panel_logs`.`type`', '`panel_logs`.`log_message`');

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`panel_logs`.`log_message` LIKE ? OR `panel_logs`.`log_extra` LIKE ? OR `panel_logs`.`type` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `panel_logs` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `panel_logs`.`id`, `panel_logs`.`date`, `panel_logs`.`server_id`, `servers`.`server_name`, `panel_logs`.`type`, `panel_logs`.`log_message`, `panel_logs`.`log_extra` FROM `panel_logs` LEFT JOIN `servers` ON `servers`.`id` = `panel_logs`.`server_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$a85e1b7d42c346a0['data'][] = array(date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date']), "<a href='server_view?id=" . intval($C740da31596f24ef['server_id']) . "'>" . $C740da31596f24ef['server_name'] . '</a>', strtoupper($C740da31596f24ef['type']), $C740da31596f24ef['log_message'] . (($C740da31596f24ef['log_extra'] ? '<br/>' . $C740da31596f24ef['log_extra'] : '')));
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'login_logs') {
			if ($B2ff75c438fb3031['is_admin'] && Aacd47D8157a1a09('adv', 'login_logs')) {
				$c6c389b9adf3a40c = array('`login_logs`.`date`', '`login_logs`.`type`', '`login_logs`.`status`', '`users`.`username`', '`access_codes`.`code`', '`login_logs`.`login_ip`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 4) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`login_logs`.`login_ip` LIKE ? OR `login_logs`.`status` LIKE ? OR `users`.`username` LIKE ? OR `access_codes`.`code` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `login_logs` LEFT JOIN `users` ON `users`.`id` = `login_logs`.`user_id` LEFT JOIN `access_codes` ON `access_codes`.`id` = `login_logs`.`access_code` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$cda44bf16c8f250e = array();
					$Fee0d5a474c96306->query('SELECT `ip` FROM `blocked_ips`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$cda44bf16c8f250e[] = $C740da31596f24ef['ip'];
					}
					$A6d7047f2fda966c = 'SELECT `login_logs`.`id`, `login_logs`.`type`, `login_logs`.`access_code`, `access_codes`.`code`, `login_logs`.`user_id`, `users`.`username`, `login_logs`.`status`, `login_logs`.`login_ip`, `login_logs`.`date` FROM `login_logs` LEFT JOIN `users` ON `users`.`id` = `login_logs`.`user_id` LEFT JOIN `access_codes` ON `access_codes`.`id` = `login_logs`.`access_code` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								if (0 < strlen($C740da31596f24ef['login_ip'])) {
									if (!in_array($C740da31596f24ef['login_ip'], $cda44bf16c8f250e)) {
										$ebab77ef4bee81e0 = "<button title=\"Block IP\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['login_ip'] . "', 'block');\"><i class=\"fas fa-hammer\"></i></button>";
									} else {
										$ebab77ef4bee81e0 = '<button title="IP Already Blocked" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="fas fa-hammer"></i></button>';
									}

									$fd6627d61b4b058f = explode(':', $C740da31596f24ef['ip']);
									$c59ec257c284c894 = "<a onClick=\"whois('" . $C740da31596f24ef['ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['ip'])) . '</a>';
								} else {
									$ebab77ef4bee81e0 = '<button type="button" class="btn btn-light waves-effect waves-light btn-xs" disabled><i class="fas fa-hammer"></i></button>';
									$c59ec257c284c894 = '';
								}

								$a85e1b7d42c346a0['data'][] = array(date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date']), $C740da31596f24ef['type'], $C740da31596f24ef['status'], '<a href="user?id=' . $C740da31596f24ef['user_id'] . '">' . $C740da31596f24ef['username'] . '</a>', $C740da31596f24ef['code'], $c59ec257c284c894, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'queue') {
			if ($B2ff75c438fb3031['is_admin'] && (AACd47D8157A1A09('adv', 'movies') || AACD47d8157a1a09('adv', 'episodes') || AaCD47D8157a1A09('adv', 'series'))) {
				$c6c389b9adf3a40c = array('`queue`.`id`', '`streams`.`stream_display_name`', '`servers`.`server_name`', '`queue`.`pid`', '`queue`.`added`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`stream_display_name` LIKE ? OR `servers`.`server_name` LIKE ? OR `streams`.`id` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `queue` LEFT JOIN `servers` ON `servers`.`id` = `queue`.`server_id` LEFT JOIN `streams` ON `streams`.`id` = `queue`.`stream_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `queue`.*, `servers`.`server_name`, `streams`.`type`, `streams`.`stream_display_name` FROM `queue` LEFT JOIN `servers` ON `servers`.`id` = `queue`.`server_id` LEFT JOIN `streams` ON `streams`.`id` = `queue`.`stream_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$Dfa7f7fd6a9f18a8 = $D031c48a1422c07e + 1;

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								if (aaCd47d8157a1a09('adv', 'servers')) {
									$B00ef71aa2cd7a26 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
								} else {
									$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];
								}

								$d48363bb091686d2 = array(2 => 'movies', 5 => 'series');

								if (AaCd47D8157A1a09('adv', $d48363bb091686d2[$C740da31596f24ef['type']])) {
									$f523e362fb81d6c8 = "<a href='stream_view?id=" . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
								} else {
									$f523e362fb81d6c8 = $C740da31596f24ef['stream_display_name'];
								}

								if (0 < $C740da31596f24ef['pid']) {
									$Ba23222f3ed2dc08 = '<i class="text-info fas fa-square tooltip" title="In Progress"></i>';
									$ebab77ef4bee81e0 = "<button title=\"Stop\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['id'] . "', 'stop');\"><i class=\"mdi mdi-stop\"></i></button>";
								} else {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Queued..."></i>';
									$ebab77ef4bee81e0 = "<button title=\"Delete\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['id'] . "', 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}

								$a85e1b7d42c346a0['data'][] = array($Dfa7f7fd6a9f18a8, $f523e362fb81d6c8, $B00ef71aa2cd7a26, $Ba23222f3ed2dc08, date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['added']), $ebab77ef4bee81e0);
								$Dfa7f7fd6a9f18a8++;
							} else {
								$C740da31596f24ef['position'] = $Dfa7f7fd6a9f18a8;
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'restream_logs') {
			if ($B2ff75c438fb3031['is_admin'] && Aacd47d8157a1a09('adv', 'restream_logs')) {
				$c6c389b9adf3a40c = array('`detect_restream_logs`.`id`', '`lines`.`username`', '`streams`.`stream_display_name`', '`detect_restream_logs`.`ip`', '`detect_restream_logs`.`time`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`detect_restream_logs`.`ip` LIKE ? OR `lines`.`username` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `detect_restream_logs` LEFT JOIN `lines` ON `lines`.`id` = `detect_restream_logs`.`user_id` LEFT JOIN `streams` ON `streams`.`id` = `detect_restream_logs`.`stream_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$cda44bf16c8f250e = array();
					$Fee0d5a474c96306->query('SELECT `ip` FROM `blocked_ips`;');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$cda44bf16c8f250e[] = $C740da31596f24ef['ip'];
					}
					$A6d7047f2fda966c = 'SELECT `detect_restream_logs`.`id`, `detect_restream_logs`.`user_id`, `detect_restream_logs`.`stream_id`, `detect_restream_logs`.`ip`, `detect_restream_logs`.`time`, `lines`.`username`, `streams`.`stream_display_name`, `streams`.`type` FROM `detect_restream_logs` LEFT JOIN `lines` ON `lines`.`id` = `detect_restream_logs`.`user_id` LEFT JOIN `streams` ON `streams`.`id` = `detect_restream_logs`.`stream_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								if (0 < strlen($C740da31596f24ef['ip'])) {
									if (!in_array($C740da31596f24ef['ip'], $cda44bf16c8f250e)) {
										$ebab77ef4bee81e0 = "<button title=\"Block IP\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['ip'] . "', 'block');\"><i class=\"fas fa-hammer\"></i></button>";
									} else {
										$ebab77ef4bee81e0 = '<button title="IP Already Blocked" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="fas fa-hammer"></i></button>';
									}

									$fd6627d61b4b058f = explode(':', $C740da31596f24ef['ip']);
									$c59ec257c284c894 = "<a onClick=\"whois('" . $C740da31596f24ef['ip'] . "');\" href='javascript: void(0);'>" . ((1 < count($fd6627d61b4b058f) ? implode(':', array_slice($fd6627d61b4b058f, 0, 4)) . ':<br/>' . implode(':', array_slice($fd6627d61b4b058f, 4, 8)) : $C740da31596f24ef['ip'])) . '</a>';
								} else {
									$ebab77ef4bee81e0 = '<button type="button" class="btn btn-light waves-effect waves-light btn-xs" disabled><i class="fas fa-hammer"></i></button>';
									$c59ec257c284c894 = '';
								}

								$d48363bb091686d2 = array(1 => 'streams', 2 => 'movies', 3 => 'streams', 4 => 'radio', 5 => 'series');
								$ce2460e0c52a99da = array(1 => 'stream_view', 2 => 'stream_view', 3 => 'stream_view', 4 => 'stream_view');

								if (AaCd47D8157A1a09('adv', $d48363bb091686d2[$C740da31596f24ef['type']])) {
									if ($C740da31596f24ef['type'] == 5) {
										$f523e362fb81d6c8 = "<a href='serie?id=" . $C740da31596f24ef['series_no'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
									} else {
										$f523e362fb81d6c8 = "<a href='" . $ce2460e0c52a99da[$C740da31596f24ef['type']] . '?id=' . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . '</a>';
									}
								} else {
									$f523e362fb81d6c8 = $C740da31596f24ef['stream_display_name'];
								}

								if (aaCD47D8157a1a09('adv', 'edit_user')) {
									$Ff014d0ebd314fcd = '<a href="line?id=' . $C740da31596f24ef['user_id'] . '">' . $C740da31596f24ef['username'] . '</a>';
								} else {
									$Ff014d0ebd314fcd = $C740da31596f24ef['username'];
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $Ff014d0ebd314fcd, $f523e362fb81d6c8, $c59ec257c284c894, date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date']), $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'mag_events') {
			if ($B2ff75c438fb3031['is_admin'] && aAcd47D8157A1A09('adv', 'manage_events')) {
				$c6c389b9adf3a40c = array('`mag_events`.`send_time`', '`mag_devices`.`mac`', '`mag_events`.`event`', '`mag_events`.`msg`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`mag_devices`.`mac` LIKE ? OR `mag_events`.`event` LIKE ? OR `mag_events`.`msg` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `mag_events` LEFT JOIN `mag_devices` ON `mag_devices`.`mag_id` = `mag_events`.`mag_device_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `mag_events`.`id`, `mag_events`.`send_time`, `mag_devices`.`mac`, `mag_events`.`event`, `mag_events`.`msg`, `mag_events`.`mag_device_id` FROM `mag_events` LEFT JOIN `mag_devices` ON `mag_devices`.`mag_id` = `mag_events`.`mag_device_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								$a85e1b7d42c346a0['data'][] = array(date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['send_time']), $C740da31596f24ef['mac'], $C740da31596f24ef['event'], $C740da31596f24ef['msg'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'bouquets_streams') {
			if ($B2ff75c438fb3031['is_admin'] && AAcD47D8157A1a09('adv', 'bouquets')) {
				$A5dcdeb6ecbbf6bd = CBE87e2A9a996111('live');
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false, false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '(`type` = 1 OR `type` = 3)';

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`category_id` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category_id'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category_id'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								$ebab77ef4bee81e0 = '<div class="btn-group"><button data-id="' . $C740da31596f24ef['id'] . '" data-type="stream" type="button" style="display: none;" class="btn-remove btn btn-warning waves-effect waves-warning btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'stream');\"><i class=\"mdi mdi-minus\"></i></button>" . "\r\n" . '                <button data-id="' . $C740da31596f24ef['id'] . '" data-type="stream" type="button" style="display: none;" class="btn-add btn btn-success waves-effect waves-success btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'stream');\"><i class=\"mdi mdi-plus\"></i></button></div>";
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'bouquets_vod') {
			if ($B2ff75c438fb3031['is_admin'] && AacD47d8157a1A09('adv', 'bouquets')) {
				$A5dcdeb6ecbbf6bd = CBE87e2A9A996111('movie');
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false, false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`type` = 2';

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`category_id` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category_id'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category_id'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								$ebab77ef4bee81e0 = '<div class="btn-group"><button data-id="' . $C740da31596f24ef['id'] . '" data-type="movies" type="button" style="display: none;" class="btn-remove btn btn-warning waves-effect waves-warning btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'movies');\"><i class=\"mdi mdi-minus\"></i></button>" . "\r\n" . '                <button data-id="' . $C740da31596f24ef['id'] . '" data-type="movies" type="button" style="display: none;" class="btn-add btn btn-success waves-effect waves-success btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'movies');\"><i class=\"mdi mdi-plus\"></i></button></div>";
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'bouquets_series') {
			if ($B2ff75c438fb3031['is_admin'] && aACD47D8157a1a09('adv', 'bouquets')) {
				$A5dcdeb6ecbbf6bd = cBe87E2a9a996111('series');
				$c6c389b9adf3a40c = array('`streams_series`.`id`', '`streams_series`.`title`', false, false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams_series`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams_series`.`id` LIKE ? OR `streams_series`.`title` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams_series`.`id`, `streams_series`.`title`, `streams_series`.`category_id` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category_id'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category_id'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								$ebab77ef4bee81e0 = '<div class="btn-group"><button data-id="' . $C740da31596f24ef['id'] . '" data-type="series" type="button" style="display: none;" class="btn-remove btn btn-warning waves-effect waves-warning btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'series');\"><i class=\"mdi mdi-minus\"></i></button>" . "\r\n" . '                <button data-id="' . $C740da31596f24ef['id'] . '" data-type="series" type="button" style="display: none;" class="btn-add btn btn-success waves-effect waves-success btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'series');\"><i class=\"mdi mdi-plus\"></i></button></div>";
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['title'], $A1925ae53e9307eb, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'bouquets_radios') {
			if ($B2ff75c438fb3031['is_admin'] && AaCD47d8157A1a09('adv', 'bouquets')) {
				$A5dcdeb6ecbbf6bd = cbE87E2A9A996111('radio');
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false, false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`type` = 4';

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`category_id` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category_id'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category_id'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								$ebab77ef4bee81e0 = '<div class="btn-group"><button data-id="' . $C740da31596f24ef['id'] . '" data-type="radios" type="button" style="display: none;" class="btn-remove btn btn-warning waves-effect waves-warning btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'radios');\"><i class=\"mdi mdi-minus\"></i></button>" . "\r\n" . '                <button data-id="' . $C740da31596f24ef['id'] . '" data-type="radios" type="button" style="display: none;" class="btn-add btn btn-success waves-effect waves-success btn-xs" onClick="toggleBouquet(' . $C740da31596f24ef['id'] . ", 'radios');\"><i class=\"mdi mdi-plus\"></i></button></div>";
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'streams_short') {
			if ($B2ff75c438fb3031['is_admin'] && AACd47D8157A1a09('adv', 'categories')) {
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '(`type` = 1 OR `type` = 3)';

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<a href="stream_view?id=' . $C740da31596f24ef['id'] . '"><button type="button" title="View Stream" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-play"></i></button></a>';
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'movies_short') {
			if ($B2ff75c438fb3031['is_admin'] && AAcd47d8157A1A09('adv', 'categories')) {
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`type` = 2';

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<a href="stream_view?id=' . $C740da31596f24ef['id'] . '"><button type="button" title="View Movie" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-play"></i></button></a>';
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'radios_short') {
			if ($B2ff75c438fb3031['is_admin'] && AAcD47D8157A1A09('adv', 'categories')) {
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`type` = 4';

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<a href="stream_view?id=' . $C740da31596f24ef['id'] . '"><button type="button" title="View Station" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-play"></i></button></a>';
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'series_short') {
			if ($B2ff75c438fb3031['is_admin'] && AAcD47d8157a1a09('adv', 'categories')) {
				$c6c389b9adf3a40c = array('`streams_series`.`id`', '`streams_series`.`title`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

				if (!(isset(XUI::$rRequest['category_id']) && 0 < intval(XUI::$rRequest['category_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams_series`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category_id'];
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams_series`.`id` LIKE ? OR `streams_series`.`title` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams_series`.`id`, `streams_series`.`title` FROM `streams_series` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<a href="series?id=' . $C740da31596f24ef['id'] . '"><button type="button" title="Edit Series" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-play"></i></button></a>';
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['title'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'vod_selection') {
			if ($B2ff75c438fb3031['is_admin'] && aACd47d8157A1A09('adv', 'create_channel')) {
				$A5dcdeb6ecbbf6bd = cBe87e2a9a996111('movie');
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_display_name`', '`streams_series`.`title`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`stream_source` LIKE ?';
				$Df2582e36fdd6160[] = '%s:' . intval(XUI::$rRequest['server_id']) . ':%';

				if (isset(XUI::$rRequest['category_id']) && 0 < strlen(XUI::$rRequest['category_id'])) {
					$B211d7401e6242f3 = explode(':', XUI::$rRequest['category_id']);

					if (intval($B211d7401e6242f3[0]) == 0) {
						$f86e19bdb1e7dae8[] = "(`streams`.`type` = 2 AND JSON_CONTAINS(`streams`.`category_id`, ?, '\$'))";
						$Df2582e36fdd6160[] = $B211d7401e6242f3[1];
					} else {
						$f86e19bdb1e7dae8[] = '(`streams`.`type` = 5 AND `streams`.`series_no` = ?)';
						$Df2582e36fdd6160[] = $B211d7401e6242f3[1];
					}
				} else {
					$f86e19bdb1e7dae8[] = '(`streams`.`type` = 2 OR `streams`.`type` = 5)';
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `streams_series`.`title` LIKE ?)';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams`.`series_no` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`category_id`, `streams_series`.`title` FROM `streams` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams`.`series_no` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ebab77ef4bee81e0 = '<div class="btn-group"><button data-id="' . $C740da31596f24ef['id'] . '" data-type="vod" type="button" style="display: none;" class="btn-remove btn btn-light waves-effect waves-light btn-xs" onClick="toggleSelection(' . $C740da31596f24ef['id'] . ');"><i class="mdi mdi-minus"></i></button>' . "\r\n" . '                <button data-id="' . $C740da31596f24ef['id'] . '" data-type="vod" type="button" style="display: none;" class="btn-add btn btn-light waves-effect waves-light btn-xs" onClick="toggleSelection(' . $C740da31596f24ef['id'] . ');"><i class="mdi mdi-plus"></i></button></div>';

								if (0 < strlen($C740da31596f24ef['title'])) {
									$A1925ae53e9307eb = $C740da31596f24ef['title'];
								} else {
									$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

									if (0 < strlen($B211d7401e6242f3[1])) {
										$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval($B211d7401e6242f3[1])]['category_name'] ?: 'No Category');
									} else {
										$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
									}

									if (1 >= count($A38b42a281e3c3cf)) {
									} else {
										$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
									}
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'epg_api') {
			$c6c389b9adf3a40c = array('`epg_api`.`callSign`', '`epg_api`.`name`', '`epg_api`.`bcastLangs`', '`epg_api`.`videoType`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = "`epg_api`.`callSign` <> ''";

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 5) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`epg_api`.`callSign` LIKE ? OR `epg_api`.`name` LIKE ? OR `epg_api`.`bcastLangs` LIKE ? OR `epg_api`.`videoType` LIKE ? OR `epg_api`.`affiliateCallSign` LIKE ?)';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `epg_api` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `epg_api`.`stationId`, `epg_api`.`callSign`, `epg_api`.`name`, `epg_api`.`bcastLangs`, `epg_api`.`videoType`, `epg_api`.`picon` FROM `epg_api` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$ebab77ef4bee81e0 = "<a href=\"javascript: void(0);\" onClick=\"selectEPGAPI('" . $C740da31596f24ef['callSign'] . "', '" . $C740da31596f24ef['stationId'] . "', '" . str_replace("'", "\\'", $C740da31596f24ef['name']) . "', '" . $C740da31596f24ef['picon'] . "')\"><button type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs\"><i class=\"mdi mdi-check\"></i></button></a>";

							if (0 < strlen($C740da31596f24ef['picon'])) {
								$E9c8d08bfb6ef33c = "<img loading='lazy' src='" . $C740da31596f24ef['picon'] . "' height='32px' />";
							} else {
								$E9c8d08bfb6ef33c = '';
							}

							$a85e1b7d42c346a0['data'][] = array($E9c8d08bfb6ef33c, $C740da31596f24ef['callSign'], $C740da31596f24ef['name'], json_decode($C740da31596f24ef['bcastLangs'], true)[0], $C740da31596f24ef['videoType'], $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		if ($E379394c7b1a273f == 'provider_streams') {
			$c6c389b9adf3a40c = array('`providers`.`name`', '`providers_streams`.`stream_icon`', '`providers_streams`.`stream_display_name`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`providers`.`enabled` = 1 AND `providers`.`status` = 1';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 4) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`providers`.`name` LIKE ? OR `providers`.`ip` LIKE ? OR `providers_streams`.`stream_display_name` LIKE ? OR `providers_streams`.`stream_id` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['type'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`providers_streams`.`type` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['type'];
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `providers_streams` LEFT JOIN `providers` ON `providers`.`id` = `providers_streams`.`provider_id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `providers`.`id`,`providers_streams`.`type`,`providers`.`username`, `providers`.`password`, `providers`.`ssl`, `providers`.`legacy`, `providers`.`hls`, `providers`.`ip`, `providers`.`port`, `providers`.`name`, `providers`.`data`, `providers_streams`.`stream_id`, `providers_streams`.`category_array`, `providers_streams`.`stream_display_name`, `providers_streams`.`stream_icon`,`providers_streams`.`channel_id` FROM `providers_streams` LEFT JOIN `providers` ON `providers`.`id` = `providers_streams`.`provider_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							if ($C740da31596f24ef['type'] == 'live') {
								$Eb6eccfbed89f039 = (($C740da31596f24ef['ssl'] ? 'https' : 'http')) . '://' . $C740da31596f24ef['ip'] . ':' . $C740da31596f24ef['port'] . '/live/' . $C740da31596f24ef['username'] . '/' . $C740da31596f24ef['password'] . '/' . $C740da31596f24ef['stream_id'] . (($C740da31596f24ef['hls'] ? '.m3u8' : ($C740da31596f24ef['legacy'] ? '.ts' : '')));
								$ebab77ef4bee81e0 = "<a href=\"javascript: void(0);\" onClick=\"addStream('" . str_replace("'", "\\'", $Eb6eccfbed89f039) . "');\"><button type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs\"><i class=\"mdi mdi-check\"></i></button></a>";
							} else {
								$Eb6eccfbed89f039 = (($C740da31596f24ef['ssl'] ? 'https' : 'http')) . '://' . $C740da31596f24ef['ip'] . ':' . $C740da31596f24ef['port'] . '/movie/' . $C740da31596f24ef['username'] . '/' . $C740da31596f24ef['password'] . '/' . $C740da31596f24ef['stream_id'] . '.' . $C740da31596f24ef['channel_id'];
								$ebab77ef4bee81e0 = "<a href=\"javascript: void(0);\" onClick=\"addStream('" . str_replace("'", "\\'", $C740da31596f24ef['stream_display_name']) . "', '" . str_replace("'", "\\'", $Eb6eccfbed89f039) . "');\"><button type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs\"><i class=\"mdi mdi-check\"></i></button></a>";
							}

							if (0 < strlen($C740da31596f24ef['stream_icon']) && $C740da31596f24ef['type'] == 'live') {
								$E9c8d08bfb6ef33c = "<img loading='lazy' src='" . $C740da31596f24ef['stream_icon'] . "' height='32px' />";
							} else {
								$E9c8d08bfb6ef33c = '';
							}

							$Ceea7bc85048bdce = json_decode($C740da31596f24ef['data'], true);
							$bae85948a6f4b7de = ($Ceea7bc85048bdce['exp_date'] ?: 'Never');
							$B68ac2238b156add = ($Ceea7bc85048bdce['max_connections'] ?: '&infin;');
							$Ad973fd3103e20dc = "<span class='tooltip' title='Expires: " . $bae85948a6f4b7de . '<br/>Connections: ' . $Ceea7bc85048bdce['active_connections'] . ' / ' . $B68ac2238b156add . "'>" . $C740da31596f24ef['name'] . '</span>';

							if ($C740da31596f24ef['type'] == 'live') {
								$a85e1b7d42c346a0['data'][] = array($E9c8d08bfb6ef33c, $C740da31596f24ef['stream_display_name'], $Ad973fd3103e20dc, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['stream_display_name'], $Ad973fd3103e20dc, $ebab77ef4bee81e0);
							}
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		if ($E379394c7b1a273f == 'parent_servers') {
			if (aACd47d8157a1a09('adv', 'servers')) {
				if (isset(XUI::$rServers[XUI::$rRequest['proxy_id']]) && count(XUI::$rServers[XUI::$rRequest['proxy_id']]['parent_id']) != 0) {
					$c6c389b9adf3a40c = array('`id`', '`server_name`', '`server_ip`');

					if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
						$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
					} else {
						$C1633246b8426116 = 0;
					}

					$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
					$f86e19bdb1e7dae8[] = '`server_type` = 0';
					$f86e19bdb1e7dae8[] = '`id` IN (' . implode(',', array_map('intval', XUI::$rServers[XUI::$rRequest['proxy_id']]['parent_id'])) . ')';

					if (0 >= strlen(XUI::$rRequest['search']['value'])) {
					} else {
						foreach (range(1, 2) as $b6f0b24a56fe41b6) {
							$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
						}
						$f86e19bdb1e7dae8[] = '(`server_name` LIKE ? OR `server_ip` LIKE ?)';
					}

					if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
					} else {
						$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
						$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
					}

					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
					$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `servers` ' . $ff9d21c7a9d310b1 . ';';
					$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

					if ($Fee0d5a474c96306->num_rows() == 1) {
						$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
					} else {
						$a85e1b7d42c346a0['recordsTotal'] = 0;
					}

					$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

					if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
					} else {
						$A6d7047f2fda966c = 'SELECT `id`, `server_name`, `server_ip` FROM `servers` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
						$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

						if (0 >= $Fee0d5a474c96306->num_rows()) {
						} else {
							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								if (!$B3f0f4a134021073) {
									$a85e1b7d42c346a0['data'][] = array("<a href='server_view?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['id'] . '</a>', "<a href='server_view?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['server_name'] . '</a>', $C740da31596f24ef['server_ip']);
								} else {
									$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
								}
							}
						}
					}

					echo json_encode($a85e1b7d42c346a0);

					exit();
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'failures_modal') {
			if (aAcD47D8157A1A09('adv', 'streams')) {
				$E400a3101514583e = 10;
				$Ccfe11bd7a796290 = 'ORDER BY `date` DESC';
				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`stream_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];

				if (!(isset(XUI::$rRequest['server_id']) && 0 < intval(XUI::$rRequest['server_id']))) {
				} else {
					$f86e19bdb1e7dae8[] = '`server_id` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['server_id'];
				}

				$f86e19bdb1e7dae8[] = '`date` >= UNIX_TIMESTAMP()-' . intval(($F2d4d8f7981ac574['fails_per_time'] ?: 86400));
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_logs` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `server_id`, `action`, `source`, `date` FROM `streams_logs` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$ecc9029bfbc77eed = '';

								if (empty($C740da31596f24ef['source'])) {
								} else {
									$ecc9029bfbc77eed = strtolower(parse_url($C740da31596f24ef['source'])['host']);
								}

								$a85e1b7d42c346a0['data'][] = array("<a href='server_view?id=" . intval($C740da31596f24ef['server_id']) . "'>" . XUI::$rServers[$C740da31596f24ef['server_id']]['server_name'] . '</a>', $ecc9029bfbc77eed, $e5ca16bbec7e5c54[$C740da31596f24ef['action']], date(XUI::$rSettings['datetime_format'], $C740da31596f24ef['date']));
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}

		if ($E379394c7b1a273f == 'epg_modal') {
			$E400a3101514583e = 10;
			$d8a1409105424710 = XUI::getEPG(XUI::$rRequest['stream_id'], time(), time() + 604800);

			if (!($d8a1409105424710 && $E400a3101514583e < count($d8a1409105424710))) {
			} else {
				$d8a1409105424710 = array_slice($d8a1409105424710, 0, $E400a3101514583e);
			}

			$a85e1b7d42c346a0['recordsTotal'] = (count($d8a1409105424710) ?: 0);
			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				foreach ($d8a1409105424710 as $C740da31596f24ef) {
					if (!$B3f0f4a134021073) {
						$a85e1b7d42c346a0['data'][] = array(date('H:i:s', $C740da31596f24ef['start']), $C740da31596f24ef['title'], $C740da31596f24ef['description']);
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		if ($E379394c7b1a273f == 'stream_logs') {
			$c6c389b9adf3a40c = array('`date`', '`action`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`stream_id` = ?';
			$Df2582e36fdd6160[] = XUI::$rRequest['stream_id'];
			$f86e19bdb1e7dae8[] = '`date` >= (UNIX_TIMESTAMP()-86400)';
			$Ccfe11bd7a796290 = 'ORDER BY `date` DESC';
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams_logs` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `date`, `action` FROM `streams_logs` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							$a85e1b7d42c346a0['data'][] = array(date('H:i:s', $C740da31596f24ef['date']), $C14aaca15fa57b1f[$C740da31596f24ef['action']]);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		if ($E379394c7b1a273f != 'ondemand') {
		} else {
			if (aAcD47D8157A1A09('adv', 'streams')) {
				$A5dcdeb6ecbbf6bd = cBe87e2A9a996111('live');
				$c6c389b9adf3a40c = array('`streams`.`id`', '`streams`.`stream_icon`', '`streams`.`stream_display_name`', '`streams_servers`.`server_id`', '`ondemand_check`.`status`', '`ondemand_check`.`response`', '`ondemand_check`.`resolution`', '`ondemand_check`.`date`');

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`streams`.`type` = 1';
				$f86e19bdb1e7dae8[] = '`streams`.`direct_source` = 0';
				$f86e19bdb1e7dae8[] = '`streams_servers`.`on_demand` = 1';

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 6) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `streams`.`stream_display_name` LIKE ? OR `ondemand_check`.`fps` LIKE ? OR `ondemand_check`.`resolution` LIKE ? OR `ondemand_check`.`video_codec` LIKE ? OR `ondemand_check`.`audio_codec` LIKE ?)';
				}

				if (0 >= strlen(XUI::$rRequest['category'])) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category'];
				}

				if (0 >= strlen(XUI::$rRequest['filter'])) {
				} else {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '`ondemand_check`.`status` = 1';
					} else {
						if (XUI::$rRequest['filter'] == 2) {
							$f86e19bdb1e7dae8[] = '`ondemand_check`.`status` = 0';
						} else {
							if (XUI::$rRequest['filter'] != 3) {
							} else {
								$f86e19bdb1e7dae8[] = '`ondemand_check`.`status` IS NULL';
							}
						}
					}
				}

				if (0 >= intval(XUI::$rRequest['server'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_servers`.`server_id` = ?';
					$Df2582e36fdd6160[] = intval(XUI::$rRequest['server']);
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` LEFT JOIN `ondemand_check` ON `ondemand_check`.`id` = `streams_servers`.`ondemand_check` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `ondemand_check`.`status` AS `ondemand_status`, `ondemand_check`.`date` AS `ondemand_date`, `ondemand_check`.`errors`, `ondemand_check`.`response`, `ondemand_check`.`resolution`, `ondemand_check`.`fps`, `ondemand_check`.`video_codec`, `ondemand_check`.`audio_codec`, `streams`.`id`, `streams`.`type`, `streams`.`stream_icon`, `streams`.`stream_source`, `streams`.`stream_display_name`, `streams_servers`.`server_id`, `streams`.`llod`, `streams`.`category_id`, (SELECT `server_name` FROM `servers` WHERE `id` = `streams_servers`.`server_id`) AS `server_name` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` LEFT JOIN `ondemand_check` ON `ondemand_check`.`id` = `streams_servers`.`ondemand_check` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();
						$A037a7dd685f14f2 = $F971b6c9816edc09 = $Cdb85875fd50f459 = array();

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							$Cdb85875fd50f459[] = intval($C740da31596f24ef['id']);
						}

						if (0 >= count($Cdb85875fd50f459)) {
						} else {
							$Fee0d5a474c96306->query('SELECT `stream_id`, `server_id`, COUNT(*) AS `count` FROM `ondemand_check` WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ") AND `status` = 1 GROUP BY CONCAT(`stream_id`, '_', `server_id`);");

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$A037a7dd685f14f2[intval($C740da31596f24ef['server_id'])][$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
							}
							$Fee0d5a474c96306->query('SELECT `stream_id`, `server_id`, COUNT(*) AS `count` FROM `ondemand_check` WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ") AND `status` = 0 GROUP BY CONCAT(`stream_id`, '_', `server_id`);");

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F971b6c9816edc09[intval($C740da31596f24ef['server_id'])][$C740da31596f24ef['stream_id']] = $C740da31596f24ef['count'];
							}
						}

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								$d58b4f8653a391d8 = intval($C740da31596f24ef['server_id']);
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								$Ef28eaee0050d7a5 = "<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'><strong>" . $C740da31596f24ef['stream_display_name'] . "</strong><br><span style='font-size:11px;'>" . $A1925ae53e9307eb . '</span></a>';

								if ($C740da31596f24ef['server_name']) {
									if (aacd47d8157a1A09('adv', 'servers')) {
										$B00ef71aa2cd7a26 = "<a href='server_view?id=" . $C740da31596f24ef['server_id'] . "'>" . $C740da31596f24ef['server_name'] . '</a>';
									} else {
										$B00ef71aa2cd7a26 = $C740da31596f24ef['server_name'];
									}
								} else {
									$B00ef71aa2cd7a26 = 'No Server Selected';
								}

								if (!empty($C740da31596f24ef['stream_icon'])) {
									$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['stream_icon'] . "'><img loading='lazy' src='resize?maxw=96&maxh=32&url=" . $C740da31596f24ef['stream_icon'] . "' /></a>";
								} else {
									$E9c8d08bfb6ef33c = '';
								}

								if (is_null($C740da31596f24ef['ondemand_status'])) {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Not Scanned"></i>';
								} else {
									if ($C740da31596f24ef['ondemand_status'] == 1) {
										$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square tooltip" title="Ready"></i>';
									} else {
										$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="' . ((!empty($C740da31596f24ef['errors']) ? '<strong>Latest Error:</strong><br/>' . str_replace('"', '\\"', $C740da31596f24ef['errors']) : 'Down')) . '"></i>';
									}
								}

								$Aae09861fbc788ec = '<button type="button" class="btn btn-dark bg-animate btn-xs waves-effect waves-light no-border">' . (($A037a7dd685f14f2[$d58b4f8653a391d8][$C740da31596f24ef['id']] ?: 0)) . ' <i class="mdi mdi-arrow-up-thick"></i> &nbsp; ' . (($F971b6c9816edc09[$d58b4f8653a391d8][$C740da31596f24ef['id']] ?: 0)) . ' <i class="mdi mdi-arrow-down-thick"></i></button>';
								$Af547236269d8f66 = 'Never';
								$Ac4925333fce02b2 = "<button type='button' class='btn btn-light btn-xs waves-effect waves-light'>--</button>";
								$b5e8b95fdf13ba62 = "<table style='font-size: 10px;' class='table-data nowrap' align='center'><tbody><tr><td colspan='3'>No information available</td></tr></tbody></table>";

								if (is_null($C740da31596f24ef['ondemand_status'])) {
								} else {
									if (0 >= $C740da31596f24ef['ondemand_date']) {
									} else {
										$Af547236269d8f66 = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['ondemand_date']) . '<br/>' . date('H:i:s', $C740da31596f24ef['ondemand_date']);
									}

									if (0 >= $C740da31596f24ef['response']) {
									} else {
										$Ac4925333fce02b2 = "<button type='button' class='btn btn-light btn-xs waves-effect waves-light'>" . number_format($C740da31596f24ef['response'], 0) . ' ms</button>';
									}

									if (!($C740da31596f24ef['fps'] || $C740da31596f24ef['video_codec'] || $C740da31596f24ef['audio_codec'] || $C740da31596f24ef['resolution'])) {
									} else {
										$b5e8b95fdf13ba62 = "<table class='table-data nowrap table-data-120 text-center' align='center'>" . "\r\n" . '                            <tbody>' . "\r\n" . '                                <tr>' . "\r\n" . "                                    <td class='text-success'><i class='mdi mdi-image-size-select-large' data-name='mdi-image-size-select-large'></i></td>" . "\r\n" . "                                    <td class='text-success'><i class='mdi mdi-video' data-name='mdi-video'></i></td>" . "\r\n" . "                                    <td class='text-success'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>" . "\r\n" . "                                    <td class='text-success'><i class='mdi mdi-clock' data-name='mdi-clock'></i></td>" . "\r\n" . '                                </tr>' . "\r\n" . '                                <tr>' . "\r\n" . '                                    <td>' . (($C740da31596f24ef['resolution'] ? $C740da31596f24ef['resolution'] . 'p' : 'N/A')) . '</td>' . "\r\n" . '                                    <td>' . ((str_replace('mpeg2video', 'mpeg2', $C740da31596f24ef['video_codec']) ?: 'N/A')) . '</td>' . "\r\n" . '                                    <td>' . (($C740da31596f24ef['audio_codec'] ?: 'N/A')) . '</td>' . "\r\n" . '                                    <td>' . (($C740da31596f24ef['fps'] . ' FPS' ?: 'N/A')) . '</td>' . "\r\n" . '                                </tr>' . "\r\n" . '                            </tbody>' . "\r\n" . '                        </table>';
									}
								}

								$a85e1b7d42c346a0['data'][] = array("<a href='stream_view?id=" . $C740da31596f24ef['id'] . "'>" . $C740da31596f24ef['id'] . '</a>', $E9c8d08bfb6ef33c, $Ef28eaee0050d7a5, $B00ef71aa2cd7a26, $Ba23222f3ed2dc08 . ' &nbsp; ' . $Aae09861fbc788ec, $Ac4925333fce02b2, $b5e8b95fdf13ba62, $Af547236269d8f66);
							} else {
								unset($C740da31596f24ef['stream_source']);
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}
	}
}

function filterRow($C740da31596f24ef, $C9e42207e95f03ed, $Be763c6c88600252)
{
	if ($C9e42207e95f03ed || $Be763c6c88600252) {
		$a85e1b7d42c346a0 = array();

		foreach (array_keys($C740da31596f24ef) as $D3fa098be3f297cd) {
			if ($C9e42207e95f03ed) {
				if (!in_array($D3fa098be3f297cd, $C9e42207e95f03ed)) {
				} else {
					$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
				}
			} else {
				if (!$Be763c6c88600252) {
				} else {
					if (in_array($D3fa098be3f297cd, $Be763c6c88600252)) {
					} else {
						$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
					}
				}
			}
		}

		return $a85e1b7d42c346a0;
	} else {
		return $C740da31596f24ef;
	}
}
