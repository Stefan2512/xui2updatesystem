<?php

include 'session.php';
include 'functions.php';

if (B1882DF698b44754()) {
} else {
	b46F5dD76f3c7421();
}

$bcf587bb39f95fd5 = 'Users';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Users</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo '                <div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    User has been added / modified.' . "\n" . '                </div>' . "\n" . '                ';
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\n" . '                            <div class="col-md-3">' . "\n" . '                                <input type="text" class="form-control" id="reg_search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="Search Users...">' . "\n" . '                            </div>' . "\n" . '                            <label class="col-md-2 col-form-label text-center" for="reg_reseller">Filter Results &nbsp; <button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="clearOwner();"><i class="mdi mdi-close"></i></button></label>' . "\n" . '                            <div class="col-md-3">' . "\n" . '                                <select id="reg_reseller" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

if (!(isset(XUI::$rRequest['owner']) && ($Dbb9e190755fc819 = Fe76c4Bcaf81BAa4(intval(XUI::$rRequest['owner']))))) {
} else {
	echo '                                    <option value="';
	echo intval($Dbb9e190755fc819['id']);
	echo '" selected="selected">';
	echo $Dbb9e190755fc819['username'];
	echo '</option>' . "\n" . '                                    ';
}

echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="reg_filter" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['filter'])) {
} else {
	echo ' selected';
}

echo '>No Filter</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == -1)) {
} else {
	echo ' selected';
}

echo '>Active</option>' . "\n" . '                                    <option value="-2"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == -2)) {
} else {
	echo ' selected';
}

echo '>Disabled</option>' . "\n" . '                                    ';

foreach (ba348B5700ee9ff3() as $D307572f7986a746) {
	echo '                                    <option value="';
	echo intval($D307572f7986a746['group_id']);
	echo '"';

	if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == intval($D307572f7986a746['group_id']))) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $D307572f7986a746['group_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <label class="col-md-1 col-form-label text-center" for="reg_show_entries">Show</label>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="reg_show_entries" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo '                                    <option';

	if (isset(XUI::$rRequest['entries'])) {
		if (XUI::$rRequest['entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	} else {
		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n\t\t\t\t\t\t" . '<table id="datatable-users" class="table table-striped table-borderless dt-responsive nowrap font-normal">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Username</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Owner</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">IP</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Status</th>' . "\n" . '                                    <th class="text-center">Type</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Credits</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Users</th>' . "\n" . '                                    <th class="text-center">Lines</th>' . "\n" . '                                    <th class="text-center">MAGs</th>' . "\n" . '                                    <th class="text-center">Enigmas</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Last Login</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
