<?php

include 'session.php';
include 'functions.php';

if (B1882Df698B44754()) {
} else {
	b46f5dD76F3C7421();
}

if (!$F61f585ee1fe12b7) {
} else {
	header('Location: dashboard');
}

$ed197f76ec286bcb = (0 < intval(XUI::$rRequest['page']) ? intval(XUI::$rRequest['page']) : 1);
$E400a3101514583e = (0 < intval(XUI::$rRequest['entries']) ? intval(XUI::$rRequest['entries']) : XUI::$rSettings['default_entries']);
$D031c48a1422c07e = ($ed197f76ec286bcb - 1) * $E400a3101514583e;
$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
$f86e19bdb1e7dae8[] = '`type` = 1 AND `epg_id` IS NOT NULL AND `channel_id` IS NOT NULL';

if (!(isset(XUI::$rRequest['category']) && 0 < intval(XUI::$rRequest['category']))) {
} else {
	$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`category_id`, ?, '\$')";
	$Df2582e36fdd6160[] = XUI::$rRequest['category'];
}

if (empty(XUI::$rRequest['search'])) {
} else {
	$f86e19bdb1e7dae8[] = '(`stream_display_name` LIKE ? OR `id` LIKE ?';
	$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search'] . '%';
	$Df2582e36fdd6160[] = XUI::$rRequest['search'];
}

if (0 < count($f86e19bdb1e7dae8)) {
	$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
} else {
	$ff9d21c7a9d310b1 = '';
}

$c6c389b9adf3a40c = array('name' => '`stream_display_name` ASC', 'added' => '`added` DESC');

if (!empty(XUI::$rRequest['sort']) && isset($c6c389b9adf3a40c[XUI::$rRequest['sort']])) {
	$Ccfe11bd7a796290 = $c6c389b9adf3a40c[XUI::$rRequest['sort']];
} else {
	$B363519e815eea93 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'channel_order'));

	if (XUI::$rSettings['channel_number_type'] != 'manual' && 0 < count($B363519e815eea93)) {
		$Ccfe11bd7a796290 = 'FIELD(`streams`.`id`,' . implode(',', $B363519e815eea93) . ')';
	} else {
		$Ccfe11bd7a796290 = '`order` ASC';
	}
}

$Cdb85875fd50f459 = array();
$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';', ...$Df2582e36fdd6160);
$Aa8d8af3d37ca869 = $Fee0d5a474c96306->get_row()['count'];
$Fee0d5a474c96306->query('SELECT `id` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ORDER BY ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';', ...$Df2582e36fdd6160);

foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
	$Cdb85875fd50f459[] = $C740da31596f24ef['id'];
}
$a560fbca8e1e7fd4 = ceil($Aa8d8af3d37ca869 / $E400a3101514583e);
$Bab0a7a99696cfe2 = array();

foreach (range($ed197f76ec286bcb - 2, $ed197f76ec286bcb + 2) as $Ea22c4a9ab5b2176) {
	if (!(1 <= $Ea22c4a9ab5b2176 && $Ea22c4a9ab5b2176 <= $a560fbca8e1e7fd4)) {
	} else {
		$Bab0a7a99696cfe2[] = $Ea22c4a9ab5b2176;
	}
}
$bcf587bb39f95fd5 = 'TV Guide';
include 'header.php';
echo '<div class="wrapper "';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">TV Guide</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '<form method="GET" action="epg_view">' . "\n\t\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t\t" . '<div id="collapse_filters" class="form-group row" style="margin-bottom: 0;">' . "\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="search" name="search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="Search Streams...">' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t" . '<select id="category" name="category" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<option value=""';

if (isset(XUI::$rRequest['category'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['all_categories'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t";

foreach (cbe87E2A9A996111('live') as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo intval($A1925ae53e9307eb['id']);
	echo '"';

	if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $A1925ae53e9307eb['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\n\t\t\t\t\t\t\t\t\t" . '<select id="sort" name="sort" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Default Sort', 'name' => 'Alphabetical', 'added' => 'Date Added') as $C506f7e1a1b97909 => $Fa016cbf0b72bfdd) {
	echo "\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $C506f7e1a1b97909;
	echo '"';

	if (!(isset(XUI::$rRequest['sort']) && XUI::$rRequest['sort'] == $C506f7e1a1b97909)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $Fa016cbf0b72bfdd;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<label class="col-md-1 col-form-label text-center" for="user_show_entries">Show</label>' . "\n\t\t\t\t\t\t\t\t" . '<div class="col-md-1">' . "\n\t\t\t\t\t\t\t\t\t" . '<select id="entries" name="entries" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($E400a3101514583e != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="btn-group col-md-2">' . "\n\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-info">Search</button>' . "\n\t\t\t\t\t\t\t\t\t" . '<button type="button" onClick="clearForm()" class="btn btn-warning"><i class="mdi mdi-filter-remove"></i></button>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</form>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t";

if (0 < count($Cdb85875fd50f459)) {
	echo "\t\t\t\t" . '<div class="listings-grid-container">' . "\n\t\t\t\t\t" . '<a href="#" class="listings-direction-link left day-nav-arrow js-day-nav-arrow" data-direction="prev"><span class="isvg isvg-left-dir"></span></a>' . "\n\t\t\t\t\t" . '<a href="#" class="listings-direction-link right day-nav-arrow js-day-nav-arrow" data-direction="next"><span class="isvg isvg-right-dir"></span></a>' . "\n\t\t\t\t\t" . '<div class="listings-day-slider-wrapper">' . "\n\t\t\t\t\t\t" . '<div class="listings-day-slider js-listings-day-slider">' . "\n\t\t\t\t\t\t\t" . '<div class="js-listings-day-nav-inner"></div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<div class="js-billboard-fix-point"></div>' . "\n\t\t\t\t\t" . '<div class="listings-grid-inner">' . "\n\t\t\t\t\t\t" . '<div class="time-nav-bar cf js-time-nav-bar">' . "\n\t\t\t\t\t\t\t" . '<div class="listings-mobile-nav">' . "\n\t\t\t\t\t\t\t\t" . '<a class="listings-now-btn js-now-btn" href="#">NOW</a>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="listings-times-wrapper">' . "\n\t\t\t\t\t\t\t\t" . '<a href="#" class="listings-direction-link left js-time-nav-arrow" data-direction="prev"><span class="isvg isvg-left-dir text-white"></span></a>' . "\n\t\t\t\t\t\t\t\t" . '<a href="#" class="listings-direction-link right js-time-nav-arrow" data-direction="next"><span class="isvg isvg-right-dir text-white"></span></a>' . "\n\t\t\t\t\t\t\t\t" . '<div class="times-slider js-times-slider"></div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '<div class="listings-loader js-listings-loader"><span class="isvg isvg-loader animate-spin"></span></div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '<div class="listings-wrapper cf js-listings-wrapper">' . "\n\t\t\t\t\t\t\t" . '<div class="listings-timeline js-listings-timeline"></div>' . "\n\t\t\t\t\t\t\t" . '<div class="js-listings-container"></div>' . "\n\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t";

	if (1 >= $a560fbca8e1e7fd4) {
	} else {
		echo "\t\t\t\t\t" . '<ul class="paginator">' . "\n\t\t\t\t\t\t";

		if (1 >= $ed197f76ec286bcb) {
		} else {
			echo '<li class="paginator__item paginator__item--prev">' . "\n\t\t\t\t\t\t\t\t" . '<a href="epg_view?search=' . ((urlencode(XUI::$rRequest['search']) ?: '')) . '&category=' . ((XUI::$rRequest['category'] ? intval(XUI::$rRequest['category']) : '')) . '&sort=' . ((XUI::$rRequest['sort'] ? urlencode(XUI::$rRequest['sort']) : '')) . '&entries=' . ((XUI::$rRequest['entries'] ? intval(XUI::$rRequest['entries']) : '')) . '&page=' . ($ed197f76ec286bcb - 1) . '"><i class="mdi mdi-chevron-left"></i></a>' . "\n\t\t\t\t\t\t\t" . '</li>';
		}

		if (1 >= $Bab0a7a99696cfe2[0]) {
		} else {
			echo '<li class="paginator__item' . (($ed197f76ec286bcb == 1 ? ' paginator__item--active' : '')) . '"><a href="epg_view?search=' . ((urlencode(XUI::$rRequest['search']) ?: '')) . '&category=' . ((XUI::$rRequest['category'] ? intval(XUI::$rRequest['category']) : '')) . '&sort=' . ((XUI::$rRequest['sort'] ? urlencode(XUI::$rRequest['sort']) : '')) . '&entries=' . ((XUI::$rRequest['entries'] ? intval(XUI::$rRequest['entries']) : '')) . '&page=1">1</a></li>';

			if (1 >= count($Bab0a7a99696cfe2)) {
			} else {
				echo "<li class='paginator__item'><a href='javascript: void(0);'>...</a></li>";
			}
		}

		foreach ($Bab0a7a99696cfe2 as $Ea22c4a9ab5b2176) {
			echo '<li class="paginator__item' . (($ed197f76ec286bcb == $Ea22c4a9ab5b2176 ? ' paginator__item--active' : '')) . '"><a href="epg_view?search=' . ((urlencode(XUI::$rRequest['search']) ?: '')) . '&category=' . ((XUI::$rRequest['category'] ? intval(XUI::$rRequest['category']) : '')) . '&sort=' . ((XUI::$rRequest['sort'] ? urlencode(XUI::$rRequest['sort']) : '')) . '&entries=' . ((XUI::$rRequest['entries'] ? intval(XUI::$rRequest['entries']) : '')) . '&page=' . $Ea22c4a9ab5b2176 . '">' . $Ea22c4a9ab5b2176 . '</a></li>';
		}

		if ($Bab0a7a99696cfe2[count($Bab0a7a99696cfe2) - 1] >= $a560fbca8e1e7fd4) {
		} else {
			if (1 >= count($Bab0a7a99696cfe2)) {
			} else {
				echo "<li class='paginator__item'><a href='javascript: void(0);'>...</a></li>";
			}

			echo '<li class="paginator__item' . (($ed197f76ec286bcb == $a560fbca8e1e7fd4 ? ' paginator__item--active' : '')) . '"><a href="epg_view?search=' . ((urlencode(XUI::$rRequest['search']) ?: '')) . '&category=' . ((XUI::$rRequest['category'] ? intval(XUI::$rRequest['category']) : '')) . '&sort=' . ((XUI::$rRequest['sort'] ? urlencode(XUI::$rRequest['sort']) : '')) . '&entries=' . ((XUI::$rRequest['entries'] ? intval(XUI::$rRequest['entries']) : '')) . '&page=' . $a560fbca8e1e7fd4 . '">' . $a560fbca8e1e7fd4 . '</a></li>';
		}

		if ($ed197f76ec286bcb >= $a560fbca8e1e7fd4) {
		} else {
			echo '<li class="paginator__item paginator__item--next">' . "\n\t\t\t\t\t\t\t\t" . '<a href="epg_view?search=' . ((urlencode(XUI::$rRequest['search']) ?: '')) . '&category=' . ((XUI::$rRequest['category'] ? intval(XUI::$rRequest['category']) : '')) . '&sort=' . ((XUI::$rRequest['sort'] ? urlencode(XUI::$rRequest['sort']) : '')) . '&entries=' . ((XUI::$rRequest['entries'] ? intval(XUI::$rRequest['entries']) : '')) . '&page=' . ($ed197f76ec286bcb + 1) . '"><i class="mdi mdi-chevron-right"></i></a>' . "\n\t\t\t\t\t\t\t" . '</li>';
		}

		echo "\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t";
	}

	echo "\t\t\t\t" . '</div>' . "\n\t\t\t\t";
} else {
	echo "\t\t\t\t" . '<div class="alert alert-warning alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">×</span>' . "\n" . '                    </button>' . "\n" . '                    No Live Streams or Programmes have been found matching your search terms.' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t\t";
}

echo "\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n" . '    </div>' . "\n" . '</div>' . "\n";
include 'footer.php';
