<?php

include 'session.php';
include 'functions.php';

if (B1882DF698B44754()) {
} else {
	b46F5DD76F3c7421();
}

if (!isset(XUI::$rRequest['id']) || ($baefafb46a261dbf = cBC22956B573E5Cc(XUI::$rRequest['id']))) {
} else {
	b46F5dd76F3c7421();
}

if (!isset($baefafb46a261dbf)) {
} else {
	$Acdfe35de0f15bdd = json_decode($baefafb46a261dbf['profile_options'], true);

	if ($Acdfe35de0f15bdd['software_decoding']) {
		if (!isset($Acdfe35de0f15bdd[9])) {
		} else {
			$Acdfe35de0f15bdd['gpu']['resize'] = str_replace(':', 'x', $Acdfe35de0f15bdd[9]['val']);
		}

		$Acdfe35de0f15bdd['gpu']['deint'] = intval(isset($Acdfe35de0f15bdd[17]));
	} else {
		if (!isset($Acdfe35de0f15bdd['gpu']['resize'])) {
		} else {
			$Acdfe35de0f15bdd[9]['val'] = str_replace('x', ':', $Acdfe35de0f15bdd['gpu']['resize']);
		}

		$Acdfe35de0f15bdd[17]['val'] = 0 < intval($Acdfe35de0f15bdd['gpu']['deint']);
	}
}

$Bb1e97d0ea20bca0 = array('Off');

foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
	$e81220b4451f37c9['gpu_info'] = json_decode($e81220b4451f37c9['gpu_info'], true);

	if (!isset($e81220b4451f37c9['gpu_info']['gpus'])) {
	} else {
		foreach ($e81220b4451f37c9['gpu_info']['gpus'] as $cd0f3566b68f221f => $d5aa7e5e1de00526) {
			$Bb1e97d0ea20bca0[$e81220b4451f37c9['id'] . '_' . $cd0f3566b68f221f] = $e81220b4451f37c9['server_name'] . ' - ' . $d5aa7e5e1de00526['name'];
		}
	}
}
$bcf587bb39f95fd5 = 'Transcoding Profile';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';

if (isset($baefafb46a261dbf)) {
	echo $_['edit_profile'];
} else {
	echo $_['add_profile'];
}

echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-xl-12">' . "\n\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_FAILURE)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-danger alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t";
	echo $_['generic_fail'];
	echo "\t\t\t\t" . '</div>' . "\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t" . '<form action="#" method="POST" data-parsley-validate="">' . "\n\t\t\t\t\t\t\t";

if (!isset($baefafb46a261dbf)) {
} else {
	echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="edit" value="';
	echo $baefafb46a261dbf['profile_id'];
	echo '" />' . "\n\t\t\t\t\t\t\t";
}

echo "\t\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<a href="#profile-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-account-card-details-outline mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">';
echo $_['details'];
echo '</span>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="profile-details">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="profile_name">';
echo $_['profile_name'];
echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="profile_name" name="profile_name" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($baefafb46a261dbf['profile_name']);
}

echo '" required data-parsley-trigger="change">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="gpu_device">GPU Accelerated Transcoding</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="gpu_device" name="gpu_device" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($Bb1e97d0ea20bca0 as $Bcb41d44b619234f => $c0d2b32874d8048f) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['gpu']['val'] == $Bcb41d44b619234f)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Bcb41d44b619234f;
	echo '">';
	echo $c0d2b32874d8048f;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="video_codec">';
echo $_['video_codec'];
echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9" id="video_codec_cpu_container">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="video_codec_cpu" name="video_codec_cpu" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('copy' => 'Copy Video Codec', 'libx264' => 'H.264 / MPEG-4 AVC', 'libx265' => 'H.265 / HEVC', 'mpegvideo' => 'H.262 / MPEG-2') as $A387578f69b4c724 => $bdea1c04569050b7) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-vcodec'] == $A387578f69b4c724)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $A387578f69b4c724;
	echo '">';
	echo $A387578f69b4c724 . ' - ' . $bdea1c04569050b7;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n" . '                                                    </div>' . "\n" . '                                                    <div class="col-md-6" id="video_codec_gpu_container" style="display: none;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="video_codec_gpu" name="video_codec_gpu" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('h264_nvenc' => 'CUVID NVENC H264', 'hevc_nvenc' => 'CUVID NVENC HEVC') as $A387578f69b4c724 => $bdea1c04569050b7) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-vcodec'] == $A387578f69b4c724)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $A387578f69b4c724;
	echo '">';
	echo $A387578f69b4c724 . ' - ' . $bdea1c04569050b7;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3" id="video_decoding_container" style="display: none;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="software_decoding" name="software_decoding" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('Hardware Decoding', 'Software Decoding') as $b6842cb20051e925 => $E379394c7b1a273f) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['software_decoding'] == $b6842cb20051e925)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $b6842cb20051e925;
	echo '">';
	echo $E379394c7b1a273f;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                </div>' . "\n" . '                                                <div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="audio_codec">';
echo $_['audio_codec'];
echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-9">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="audio_codec" name="audio_codec" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('copy' => 'Copy Audio Codec', 'aac' => 'AAC Advanced Audio Coding', 'ac3' => 'AC3 Dolby Digital', 'eac3' => 'E-AC3 Dolby Digital Plus', 'mp2' => 'MP2 MPEG Audio Layer 2', 'libmp3lame' => 'MP3 MPEG Audio Layer 2') as $A387578f69b4c724 => $bdea1c04569050b7) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-acodec'] == $A387578f69b4c724)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $A387578f69b4c724;
	echo '">';
	echo $A387578f69b4c724 . ' - ' . $bdea1c04569050b7;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div id="gpu_h264" style="display:none;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="preset_h264">';
echo $_['preset'];
echo ' <i title="';
echo $_['profile_tooltip_1'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="preset_h264" name="preset_h264" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Default', 'losslesshp' => 'Lossless - High Performance', 'lossless' => 'Lossless', 'llhp' => 'Low Latency - High Performance', 'llhq' => 'Low Latency - High Quality', 'll' => 'Low Latency', 'bd' => 'Blu-Ray Disk', 'hq' => 'High Quality', 'hp' => 'High Performance', 'fast' => 'Fast', 'medium' => 'Medium', 'slow' => 'Slow') as $Eb7e04058b4488aa => $ff5eb5f58c8f6e42) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-preset'] == $Eb7e04058b4488aa)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Eb7e04058b4488aa;
	echo '">';
	echo $ff5eb5f58c8f6e42;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="video_profile_h264">';
echo $_['video_profile'];
echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="video_profile_h264" name="video_profile_h264" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Automatic', 'baseline -level 3.0' => 'Baseline - Level 3.0', 'baseline -level 3.1' => 'Baseline - Level 3.1', 'main -level 3.1' => 'Main - Level 3.1', 'main -level 4.0' => 'Main - Level 4.0', 'high -level 4.0' => 'High - Level 4.0', 'high -level 4.1' => 'High - Level 4.1', 'high -level 4.2' => 'High - Level 4.2', 'high -level 5.0' => 'High - Level 5.0', 'high -level 5.1' => 'High - Level 5.1', 'high444p -level 4.0' => 'High 444p - Level 4.0', 'high444p -level 4.1' => 'High 444p - Level 4.1', 'high444p -level 4.2' => 'High 444p - Level 4.2', 'high444p -level 5.0' => 'High 444p - Level 5.0', 'high444p -level 5.1' => 'High 444p - Level 5.1') as $Eb7e04058b4488aa => $ff5eb5f58c8f6e42) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-profile:v'] == $Eb7e04058b4488aa)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Eb7e04058b4488aa;
	echo '">';
	echo $ff5eb5f58c8f6e42;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div id="gpu_hevc" style="display:none;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="preset_hevc">';
echo $_['preset'];
echo ' <i title="';
echo $_['profile_tooltip_1'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="preset_hevc" name="preset_hevc" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Default', 'losslesshp' => 'Lossless - High Performance', 'lossless' => 'Lossless', 'llhp' => 'Low Latency - High Performance', 'llhq' => 'Low Latency - High Quality', 'll' => 'Low Latency', 'bd' => 'Blu-Ray Disk', 'hq' => 'High Quality', 'hp' => 'High Performance', 'fast' => 'Fast', 'medium' => 'Medium', 'slow' => 'Slow') as $Eb7e04058b4488aa => $ff5eb5f58c8f6e42) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-preset'] == $Eb7e04058b4488aa)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Eb7e04058b4488aa;
	echo '">';
	echo $ff5eb5f58c8f6e42;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="video_profile_hevc">';
echo $_['video_profile'];
echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="video_profile_hevc" name="video_profile_hevc" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Automatic', 'main -level 4.0' => 'Main - Level 4.0', 'main -level 4.1' => 'Main - Level 4.1', 'main -level 4.2' => 'Main - Level 4.2', 'main -level 5.0' => 'Main - Level 5.0', 'main -level 5.1' => 'Main - Level 5.1', 'main -level 5.2' => 'Main - Level 5.2', 'main -level 6.0' => 'Main - Level 6.0', 'main -level 6.1' => 'Main - Level 6.1', 'main -level 6.2' => 'Main - Level 6.2', 'main10 -level 4.0' => 'Main 10bit - Level 4.0', 'main10 -level 4.1' => 'Main 10bit - Level 4.1', 'main10 -level 4.2' => 'Main 10bit - Level 4.2', 'main10 -level 5.0' => 'Main 10bit - Level 5.0', 'main10 -level 5.1' => 'Main 10bit - Level 5.1', 'main10 -level 5.2' => 'Main 10bit - Level 5.2', 'main10 -level 6.0' => 'Main 10bit - Level 6.0', 'main10 -level 6.1' => 'Main 10bit - Level 6.1', 'main10 -level 6.2' => 'Main 10bit - Level 6.2', 'rext -level 4.0' => 'REXT - Level 4.0', 'rext -level 4.1' => 'REXT - Level 4.1', 'rext -level 4.2' => 'REXT - Level 4.2', 'rext -level 5.0' => 'REXT - Level 5.0', 'rext -level 5.1' => 'REXT - Level 5.1', 'rext -level 5.2' => 'REXT - Level 5.2', 'rext -level 6.0' => 'REXT - Level 6.0', 'rext -level 6.1' => 'REXT - Level 6.1', 'rext -level 6.2' => 'REXT - Level 6.2') as $Eb7e04058b4488aa => $ff5eb5f58c8f6e42) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-profile:v'] == $Eb7e04058b4488aa)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Eb7e04058b4488aa;
	echo '">';
	echo $ff5eb5f58c8f6e42;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div id="gpu_options" style="display:none;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="resize">Resize <i title="Resize command for GPU acceleration. Example: 1920x1080" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="resize" name="resize" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd['gpu']['resize']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="deint">Deinterlace <i title="Set deinterlacing mode." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select name="deint" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('Weave (default)', 'Bob', 'Adaptive') as $b6f0b24a56fe41b6 => $b6842cb20051e925) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['gpu']['deint'] == $b6f0b24a56fe41b6)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $b6f0b24a56fe41b6;
	echo '">';
	echo $b6842cb20051e925;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div id="cpu_options">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="preset_cpu">';
echo $_['preset'];
echo ' <i title="';
echo $_['profile_tooltip_1'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="preset_cpu" name="preset_cpu" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Default', 'ultrafast' => 'Ultra Fast', 'superfast' => 'Super Fast', 'veryfast' => 'Very Fast', 'faster' => 'Faster', 'fast' => 'Fast', 'medium' => 'Medium', 'slow' => 'Slow', 'slower' => 'Slower', 'veryslow' => 'Very Slow', 'placebo' => 'Placebo') as $Eb7e04058b4488aa => $ff5eb5f58c8f6e42) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-preset'] == $Eb7e04058b4488aa)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Eb7e04058b4488aa;
	echo '">';
	echo $ff5eb5f58c8f6e42;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="video_profile_cpu">';
echo $_['video_profile'];
echo '</label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<select id="video_profile_cpu" name="video_profile_cpu" class="form-control" data-toggle="select2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach (array('' => 'Automatic', 'baseline -level 3.0' => 'Baseline - Level 3.0', 'baseline -level 3.1' => 'Baseline - Level 3.1', 'main -level 3.1' => 'Main - Level 3.1', 'main -level 4.0' => 'Main - Level 4.0', 'high -level 4.0' => 'High - Level 4.0', 'high -level 4.1' => 'High - Level 4.1', 'high -level 4.2' => 'High - Level 4.2', 'high -level 5.0' => 'High - Level 5.0', 'high -level 5.1' => 'High - Level 5.1') as $Eb7e04058b4488aa => $ff5eb5f58c8f6e42) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<option ';

	if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd['-profile:v'] == $Eb7e04058b4488aa)) {
	} else {
		echo 'selected ';
	}

	echo 'value="';
	echo $Eb7e04058b4488aa;
	echo '">';
	echo $ff5eb5f58c8f6e42;
	echo '</option>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</select>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="scaling">';
echo $_['scaling'];
echo ' <i title="';
echo $_['profile_tooltip_9'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="scaling" name="scaling" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[9]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="yadif_filter">Enable Deinterlace Filter <i title="De-interlace video using yadif filter. May be incompatible with other options that occupy the video filter. For GPU transcoding you should use the NVENC deinterlacing options." class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="yadif_filter" id="yadif_filter" type="checkbox"';

if (!(isset($baefafb46a261dbf) && $Acdfe35de0f15bdd[17]['val'] == 1)) {
} else {
	echo ' checked ';
}

echo 'data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="video_bitrate">';
echo $_['average_video_bitrate'];
echo ' <i title="';
echo $_['profile_tooltip_3'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="video_bitrate" name="video_bitrate" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[3]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="audio_bitrate">';
echo $_['average_audio_bitrate'];
echo ' <i title="';
echo $_['profile_tooltip_4'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="audio_bitrate" name="audio_bitrate" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[4]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="min_tolerance">';
echo $_['minimum_bitrate_tolerance'];
echo ' <i title="';
echo $_['profile_tooltip_5'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="min_tolerance" name="min_tolerance" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[5]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="max_tolerance">';
echo $_['maximum_bitrate_tolerance'];
echo ' <i title="';
echo $_['profile_tooltip_6'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="max_tolerance" name="max_tolerance" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[6]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="buffer_size">';
echo $_['buffer_size'];
echo ' <i title="';
echo $_['profile_tooltip_7'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="buffer_size" name="buffer_size" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[7]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="crf_value">';
echo $_['crf_value'];
echo ' <i title="';
echo $_['profile_tooltip_8'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="crf_value" name="crf_value" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[8]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="framerate">';
echo $_['target_framerate'];
echo ' <i title="';
echo $_['profile_tooltip_11'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="framerate" name="framerate" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[11]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="samplerate">';
echo $_['audio_sample_rate'];
echo ' <i title="';
echo $_['profile_tooltip_12'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="samplerate" name="samplerate" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[12]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="audio_channels">';
echo $_['audio_channels'];
echo ' <i title="';
echo $_['profile_tooltip_13'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="audio_channels" name="audio_channels" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[13]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="threads">';
echo $_['threads'];
echo ' <i title="';
echo $_['profile_tooltip_14'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="threads" name="threads" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[15]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="aspect_ratio">';
echo $_['aspect_ratio'];
echo ' <i title="';
echo $_['profile_tooltip_10'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="aspect_ratio" name="aspect_ratio" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[10]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<label class="col-md-3 col-form-label" for="logo_path">';
echo $_['logo_path_url'];
echo ' <i title="';
echo $_['profile_tooltip_16'];
echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-md-6">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="logo_path" name="logo_path" value="';

if (!isset($baefafb46a261dbf)) {
} else {
	echo htmlspecialchars($Acdfe35de0f15bdd[16]['val']);
}

echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n" . '                                                    <div class="col-md-3">' . "\n" . '                                                        <input type="text" class="form-control text-center" id="logo_pos" name="logo_pos" value="';

if (isset($baefafb46a261dbf)) {
	echo htmlspecialchars(($Acdfe35de0f15bdd[16]['pos'] ?: '10:10'));
} else {
	echo '10:10';
}

echo '" placeholder="pos x:x">' . "\n" . '                                                    </div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<input name="submit_profile" type="submit" class="btn btn-primary" value="';

if (isset($baefafb46a261dbf)) {
	echo $_['edit'];
} else {
	echo $_['add'];
}

echo '" />' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div> ' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
