<?php

if (count(get_included_files()) != 1) {
	$dc7105542a3b0c95 = isset(XUI::$rRequest['modal']);
	$D480255818428bfd = (json_decode(XUI::$rSettings['update_data'], true) ?: array());
	echo '<!DOCTYPE html>' . "\r\n" . '<html lang="en">' . "\r\n" . '    <head>' . "\r\n" . '        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . "\r\n" . '        <title>';
	echo($F2d4d8f7981ac574['server_name'] ?: 'XUI');
	echo ' ';

	if (!isset($bcf587bb39f95fd5)) {
	} else {
		echo ' | ' . $bcf587bb39f95fd5;
	}

	echo '</title>' . "\r\n" . '        <meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\r\n" . '        <meta http-equiv="X-UA-Compatible" content="IE=edge" />' . "\r\n" . '        <meta name="robots" content="noindex,nofollow">' . "\r\n" . '        <link rel="shortcut icon" href="assets/images/favicon.ico">' . "\r\n" . '        <link href="assets/libs/jquery-nice-select/nice-select.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/switchery/switchery.min.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/select2/select2.min.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/datatables/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/datatables/responsive.bootstrap4.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/datatables/buttons.bootstrap4.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/datatables/select.bootstrap4.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/jquery-toast/jquery.toast.min.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/treeview/style.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/nestable2/jquery.nestable.min.css" rel="stylesheet" />' . "\r\n" . '        <link href="assets/libs/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/quill/quill.min.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/jbox/jBox.all.min.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t" . '<link href="assets/css/icons.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/jquery-vectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t";

	if (isset($A4d9bff1e2402340) || !$Dde20813a43b39a3[$D4253f9520627819['theme']]['dark']) {
		echo '        <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/css/app.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/css/listings.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t" . '<link href="assets/css/custom.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t";
	} else {
		echo "\t\t" . '<link href="assets/css/bootstrap.dark.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/css/app.dark.css" rel="stylesheet" type="text/css" />' . "\r\n" . '        <link href="assets/css/listings.dark.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t" . '<link href="assets/css/custom.dark.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t";
	}

	echo '        <link href="assets/css/extra.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t";

	if (!$dc7105542a3b0c95) {
	} else {
		echo "\t\t" . '<link href="assets/css/modal.css" rel="stylesheet" type="text/css" />' . "\r\n\t\t";
	}

	echo '        ';

	if (!isset($A4d9bff1e2402340) && $Dde20813a43b39a3[$D4253f9520627819['theme']]['image']) {
		echo '        <style>' . "\r\n" . '        body {' . "\r\n" . "            background: url('./assets/images/theme";
		echo basename($Dde20813a43b39a3[$D4253f9520627819['theme']]['image']);
		echo "');" . "\r\n" . '        }' . "\r\n" . '        </style>' . "\r\n\t\t";
	} else {
		echo '        <style>' . "\r\n" . '        html, body {' . "\r\n" . '          overflow-x: hidden;' . "\r\n" . '        }' . "\r\n" . '        ';

		if (!$F61f585ee1fe12b7) {
		} else {
			echo '        .dataTables_wrapper {' . "\r\n" . '            overflow-x: auto !important;' . "\r\n" . '        }' . "\r\n" . '        ';
		}

		echo '        </style>' . "\r\n" . '        ';
	}

	if (!isset($f797597e1012696d)) {
	} else {
		echo $f797597e1012696d;
	}

	echo '    </head>' . "\r\n" . '    <body>' . "\r\n\t\t";

	if ($dc7105542a3b0c95) {
	} else {
		echo '        <header id="topnav">' . "\r\n" . '            <div class="navbar-overlay bg-animate';

		if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
		} else {
			echo '-' . $D4253f9520627819['hue'];
		}

		echo '"></div>' . "\r\n" . '            <div class="navbar-custom">' . "\r\n" . '                <div class="container-fluid">' . "\r\n" . '                    <div class="logo-box">' . "\r\n" . '                        <a href="index" class="logo text-center">' . "\r\n" . '                            <span class="logo-lg';

		if (0 >= strlen($D4253f9520627819['hue'])) {
		} else {
			echo ' whiteout';
		}

		echo '">' . "\r\n" . '                                <img src="assets/images/logo-dragon-shield.png" alt="" height="50">' . "\r\n" . '            </span>' . "\r\n" . '                            <span class="logo-sm';

		if (0 >= strlen($D4253f9520627819['hue'])) {
		} else {
			echo ' whiteout';
		}

		echo '">' . "\r\n" . '                                <img src="assets/images/favicon.png" alt="" height="28">' . "\r\n" . '             </span>' . "\r\n" . '                        </a>' . "\r\n" . '                    </div>' . "\r\n" . '                    ';

		if (isset($A4d9bff1e2402340)) {
		} else {
			if ($F61f585ee1fe12b7 || !$F2d4d8f7981ac574['header_stats']) {
			} else {
				echo '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0" style="opacity: 80%" id="header_stats">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect pd-left pd-right" data-toggle="dropdown" href="./live_connections" role="button" aria-haspopup="false" aria-expanded="false">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . '                                    <i class="fe-zap text-white"></i> &nbsp; <button type="button" class="btn btn-dark bg-animate';

				if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
				} else {
					echo '-' . $D4253f9520627819['hue'];
				}

				echo ' btn-xs waves-effect waves-light no-border"><span id="header_connections">0</span></button>' . "\r\n" . '                                </span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect pd-left pd-right" data-toggle="dropdown" href="./live_connections" role="button" aria-haspopup="false" aria-expanded="false">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . '                                    <i class="fe-users text-white"></i> &nbsp; <button type="button" class="btn btn-dark bg-animate';

				if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
				} else {
					echo '-' . $D4253f9520627819['hue'];
				}

				echo ' btn-xs waves-effect waves-light no-border"><span id="header_users">0</span></button>' . "\r\n" . '                                </span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect pd-left pd-right" data-toggle="dropdown" href="./streams" role="button" aria-haspopup="false" aria-expanded="false">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . '                                    <i class="fe-play text-white"></i> &nbsp; <button type="button" class="btn btn-dark bg-animate';

				if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
				} else {
					echo '-' . $D4253f9520627819['hue'];
				}

				echo ' btn-xs waves-effect waves-light no-border"><span id="header_streams_up">0</span> <i class="mdi mdi-arrow-up-thick"></i> &nbsp; <span id="header_streams_down">0</span> <i class="mdi mdi-arrow-down-thick"></i></button>' . "\r\n" . '                                </span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect pd-left pd-right" data-toggle="dropdown" href="./dashboard" role="button" aria-haspopup="false" aria-expanded="false">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . '                                    <i class="fe-trending-up text-white"></i> &nbsp; <button type="button" class="btn btn-dark bg-animate';

				if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
				} else {
					echo '-' . $D4253f9520627819['hue'];
				}

				echo ' btn-xs waves-effect waves-light no-border"><span id="header_network_up">0</span> <small>Mbps</small> <i class="mdi mdi-arrow-up-thick"></i> &nbsp; <span id="header_network_down">0</span> <small>Mbps</small> <i class="mdi mdi-arrow-down-thick"></i></button>' . "\r\n" . '                                </span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    ';
			}

			echo '                    <!-- Streams, Channels, Movies, Episodes & Radio Stations -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_streams" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_streams_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('start');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-play\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('stop');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-stop\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('restart');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-refresh\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('purge');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-hammer\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- TV Series -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_series" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_series_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- Servers -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_servers" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_servers_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('tools');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-creation\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('restart');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-refresh\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('start');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-play\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('stop');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-stop\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('purge');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-hammer\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-shield-check-outline text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable_proxy');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable_proxy');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-access-point-network text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- Proxies -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_proxies" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_proxies_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('tools');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-creation\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('purge');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-hammer\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-trash-can-outline\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-shield-check-outline text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- Lines -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_lines" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_lines_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('purge');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-hammer\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-lock text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('ban');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">ban</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('unban');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">unban</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-power text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- Enigma Devices -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_enigmas" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_enigmas_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('convert');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"fas fa-retweet\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('purge');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-hammer\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-lock text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('ban');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">ban</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('unban');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">unban</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-power text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- MAG Devices -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_mags" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_mags_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('event');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-message-alert\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('convert');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"fas fa-retweet\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('purge');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-hammer\"></i></button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-lock text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('ban');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">ban</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('unban');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">unban</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-power text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <!-- Users -->' . "\r\n" . '                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0 multiselect" id="multiselect_users" style="display: none;opacity: 80%;">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <span class="nav-link nav-user mr-0 waves-effect pd-left pd-right">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . "                                    <button type=\"button\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><span id=\"multi_users_selected\">0</span></button> &nbsp; <i onClick=\"multiAPI('clear');\" class=\"mdi mdi-selection-off text-white\"></i> &nbsp; " . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('delete');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                    &nbsp; <i class="mdi mdi-lock text-white"></i> &nbsp; ' . "\r\n" . '                                    <div class="btn-group">' . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('disable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">disable</button>" . "\r\n" . "                                        <button type=\"button\" onClick=\"multiAPI('enable');\" class=\"btn btn-primary btn-xs waves-effect waves-light no-border\">enable</button>" . "\r\n" . '                                    </div>' . "\r\n" . '                                </span>' . "\r\n" . '                            </span>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                    <ul class="list-unstyled topnav-menu float-right mb-0 topnav-custom">' . "\r\n" . '                        <li class="dropdown notification-list">' . "\r\n" . '                            <a class="navbar-toggle nav-link">' . "\r\n" . '                                <div class="lines text-white">' . "\r\n" . '                                    <span></span>' . "\r\n" . '                                    <span></span>' . "\r\n" . '                                    <span></span>' . "\r\n" . '                                </div>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n\t\t\t\t\t\t";

			if (!XUI::$rSettings['enable_search']) {
			} else {
				echo "\t\t\t\t\t\t" . '<li class="dropdown notification-list" id="search-mobile">' . "\r\n" . '                            <a href="javascript:void(0);" class="search-toggle pad-15 nav-link right-bar-toggle waves-effect text-white">' . "\r\n" . '                                <i class="mdi mdi-magnify noti-icon"></i>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n\t\t\t\t\t\t" . '<li class="d-none d-sm-block" id="topnav-search">' . "\r\n" . '                            <div class="app-search" data-theme="bg-animate';

				if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
				} else {
					echo '-' . $D4253f9520627819['hue'];
				}

				echo '">' . "\r\n" . '                                <div class="app-search-box">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<select placeholder="Search..." class="quick_search form-control bg-animate';

				if (!(0 < strlen($D4253f9520627819['hue']) && in_array($D4253f9520627819['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
				} else {
					echo '-' . $D4253f9520627819['hue'];
				}

				echo '" data-toggle="select2"></select>' . "\r\n" . '                                </div>' . "\r\n" . '                            </div>' . "\r\n" . '                        </li>' . "\r\n\t\t\t\t\t\t";
			}

			echo '                        <li class="dropdown notification-list">' . "\r\n" . '                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">' . "\r\n" . '                                <span class="pro-user-name text-white ml-1">' . "\r\n" . '                                    ';
			echo $D4253f9520627819['username'];
			echo ' <i class="mdi mdi-chevron-down"></i> ' . "\r\n" . '                                </span>' . "\r\n" . '                                <span class="pro-user-name-mob nav-link text-white waves-effect">' . "\r\n" . '                                    <i class="fe-user noti-icon"></i> ' . "\r\n" . '                                </span>' . "\r\n" . '                            </a>' . "\r\n" . '                            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">' . "\r\n" . '                                <a href="edit_profile" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>User Profile</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                ';

			if (!AAcD47D8157A1a09('adv', 'settings')) {
			} else {
				echo '                                <a href="settings" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Setarile Generale</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                ';
			}

			if (!AaCD47D8157a1A09('adv', 'database')) {
			} else {
				echo '                                <a href="backups" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Setarile de Backup</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                <a href="cache" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Cache & Redis</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                ';
			}

			if (!AAcD47d8157a1a09('adv', 'folder_watch_settings')) {
			} else {
				echo '                                <div class="dropdown-divider"></div>' . "\r\n" . '                                <a href="settings_plex" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Plex Settings</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                <a href="settings_watch" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Setare Folder Filme</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                ';
			}

			echo '                                <div class="dropdown-divider"></div>' . "\r\n" . '                                ';

			if (!aAcD47d8157a1a09('adv', 'license') || $D8d681f377d877d4) {
			} else {
				echo '                                <a href="licenta-xui" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Inormatii Licenta</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                ';
			}

			echo '                                <a href="https://xui.one/billing/index.php?rp=/knowledgebase" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>XUI Knowledgebase</span>' . "\r\n" . '                                </a>' . "\r\n" . '                                <div class="dropdown-divider"></div>' . "\r\n" . '                                <a href="logout" class="dropdown-item notify-item">' . "\r\n" . '                                    <span>Logout</span>' . "\r\n" . '                                </a>' . "\r\n" . '                            </div>' . "\r\n" . '                        </li>' . "\r\n\t\t\t\t\t\t";

			if ($f0a85bb7cb144853 && aacD47D8157A1A09('adv', 'servers')) {
				echo '                        <li class="notification-list">' . "\r\n" . '                            <a href="servers" class="nav-link right-bar-toggle waves-effect ';

				if ($D4253f9520627819['theme'] == 1) {
					echo 'text-white';
				} else {
					echo 'text-warning';
				}

				echo '">' . "\r\n" . '                                <i class="mdi mdi-wifi-strength-off noti-icon"></i>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        ';
			} else {
				if (!($D8a272f675608cb9 && aaCD47D8157A1a09('adv', 'servers'))) {
				} else {
					echo '                        <li class="notification-list">' . "\r\n" . '                            <a href="proxies" class="nav-link right-bar-toggle waves-effect ';

					if ($D4253f9520627819['theme'] == 1) {
						echo 'text-white';
					} else {
						echo 'text-warning';
					}

					echo '">' . "\r\n" . '                                <i class="mdi mdi-wifi-strength-off noti-icon"></i>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        ';
				}
			}

			if (!(!$F61f585ee1fe12b7 && is_array($D480255818428bfd) && $D480255818428bfd['version'] && (0 < version_compare($D480255818428bfd['version'], XUI_VERSION) || version_compare($D480255818428bfd['version'], XUI_VERSION) == 0 && intval(XUI_REVISION) < intval($D480255818428bfd['revision'])))) {
			} else {
				echo "\t\t\t\t\t\t" . '<li class="notification-list">' . "\r\n" . '                            <a href="settings" class="nav-link right-bar-toggle waves-effect ';

				if ($D4253f9520627819['theme'] == 1) {
					echo 'text-white';
				} else {
					echo 'text-warning';
				}

				echo ' tooltip-left" title="';
				echo(XUI_BETA ? 'Beta Release ' : 'Official Release ');
				echo ' v';
				echo $D480255818428bfd['version'] . (($D480255818428bfd['revision'] ? ' R' . intval($D480255818428bfd['revision']) : ''));
				echo ' is available to download.">' . "\r\n" . '                                <i class="mdi mdi-update noti-icon"></i>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n\t\t\t\t\t\t";
			}

			if (!$F2d4d8f7981ac574['show_tickets']) {
			} else {
				$ccc5e6bbdc6b5c6c = array();
				$Aa8c918a2a91966f = array();
				$Fee0d5a474c96306->query('SELECT `id` FROM `users` WHERE `owner_id` = ?;', $D4253f9520627819['id']);

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$Aa8c918a2a91966f[] = $C740da31596f24ef['id'];
				}

				if (0 >= count($Aa8c918a2a91966f)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `tickets`.`id`, `tickets`.`title`, MAX(`tickets_replies`.`date`) AS `date`, `users`.`username` FROM `tickets` LEFT JOIN `tickets_replies` ON `tickets_replies`.`ticket_id` = `tickets`.`id` LEFT JOIN `users` ON `users`.`id` = `tickets`.`member_id` WHERE `tickets`.`status` <> 0 AND `admin_read` = 0 AND `user_read` = 1 AND `member_id` <> ? AND `member_id` IN (SELECT `id` FROM `users` WHERE `owner_id` = ?) GROUP BY `tickets_replies`.`ticket_id` ORDER BY `tickets_replies`.`date` DESC LIMIT 50;', $D4253f9520627819['id'], $D4253f9520627819['id']);
					$Bbf7921d6229d871 = $Fee0d5a474c96306->num_rows();

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$ccc5e6bbdc6b5c6c[] = $C740da31596f24ef;
					}
				}

				echo '                        <li class="dropdown notification-list">' . "\r\n" . '                            ';

				if (0 < $Bbf7921d6229d871) {
					echo '                            <a class="nav-link dropdown-toggle waves-effect text-white" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">' . "\r\n" . '                            ';
				} else {
					echo '                            <a class="nav-link waves-effect text-white" href="tickets" role="button">' . "\r\n" . '                            ';
				}

				echo '                                <i class="fe-mail noti-icon"></i>' . "\r\n" . '                                ';

				if (0 >= $Bbf7921d6229d871) {
				} else {
					echo '                                <span class="badge badge-info rounded-circle noti-icon-badge" style="min-width:20px;">';
					echo($Bbf7921d6229d871 < 100 ? $Bbf7921d6229d871 : '99+');
					echo '</span>' . "\r\n" . '                                ';
				}

				echo '                            </a>' . "\r\n" . '                            <div class="dropdown-menu dropdown-menu-right dropdown-lg">' . "\r\n" . '                                <div class="dropdown-item noti-title">' . "\r\n" . '                                    <h5 class="m-0">' . "\r\n" . '                                        Tickete Support' . "\r\n" . '                                    </h5>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="slimscroll noti-scroll">' . "\r\n" . '                                    ';

				foreach ($ccc5e6bbdc6b5c6c as $Fc045a436f741403) {
					$f8b690b644399c54 = time() - intval($Fc045a436f741403['date']);

					if ($f8b690b644399c54 < 60) {
						$f8b690b644399c54 = $f8b690b644399c54 . ' seconds ago';
					} else {
						if ($f8b690b644399c54 < 3600) {
							$f8b690b644399c54 = ceil($f8b690b644399c54 / 60) . ' minutes ago';
						} else {
							if ($f8b690b644399c54 < 86400) {
								$f8b690b644399c54 = ceil($f8b690b644399c54 / 3600) . ' hours ago';
							} else {
								$f8b690b644399c54 = ceil($f8b690b644399c54 / 86400) . ' days ago';
							}
						}
					}

					echo '                                    <a href="ticket_view?id=';
					echo $Fc045a436f741403['id'];
					echo '" class="dropdown-item notify-item">' . "\r\n" . '                                        <div class="notify-icon bg-info">' . "\r\n" . '                                            <i class="mdi mdi-comment"></i>' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <p class="notify-details">';
					echo htmlspecialchars($Fc045a436f741403['title']);
					echo '                                            <small class="text-muted">';
					echo $f8b690b644399c54;
					echo '</small>' . "\r\n" . '                                        </p>' . "\r\n" . '                                    </a>' . "\r\n" . '                                    ';
				}
				echo '                                </div>' . "\r\n" . '                                <a href="tickets" class="dropdown-item text-center text-primary notify-item notify-all">' . "\r\n" . '                                    View Tickets' . "\r\n" . '                                    <i class="fi-arrow-right"></i>' . "\r\n" . '                                </a>' . "\r\n" . '                            </div>' . "\r\n" . '                        </li>' . "\r\n" . '                        ';
			}

			echo '                    </ul>' . "\r\n" . '                    ';
		}

		echo '                    <div class="clearfix"></div>' . "\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n" . '            ';

		if (isset($A4d9bff1e2402340)) {
		} else {
			echo '            <div class="topbar-menu">' . "\r\n" . '                <div class="container-fluid">' . "\r\n" . '                    <div id="navigation">' . "\r\n" . '                        <ul class="navigation-menu">' . "\r\n" . '                            <li class="has-submenu">' . "\r\n" . '                                <a href="index"><i class="fe-activity"></i>';
			echo $_['dashboard'];

			if (!$F61f585ee1fe12b7) {
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n" . '                                    ';

				if (!aAcD47d8157A1a09('adv', 'live_connections')) {
				} else {
					echo '                                    <li><a href="live_connections">';
					echo $_['live_connections'];
					echo '</a></li>' . "\r\n" . '                                    ';
				}

				echo '                                </ul>' . "\r\n" . '                                ';
			} else {
				echo '                                </a>' . "\r\n" . '                                ';
			}

			echo '                            </li>' . "\r\n\t\t\t\t\t\t\t";

			if (!(aaCD47d8157a1a09('adv', 'servers') || aaCD47D8157a1a09('adv', 'process_monitor'))) {
			} else {
				echo '                            <li class="has-submenu">' . "\r\n" . '                                <a href="#"><i class="fas fa-server"></i>';
				echo $_['servers'];
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n\t\t\t\t\t\t\t\t\t";

				if (!aAcD47d8157a1a09('adv', 'servers')) {
				} else {
					echo '                                    <li><a href="servers">';
					echo $_['manage_servers'];
					echo '</a></li>' . "\r\n" . '                                    <li><a href="proxies">';
					echo $_['manage_proxies'];
					echo '</a></li>' . "\r\n" . '                                    <li><a href="server_order">Ordinea Serverelor</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t";
				}

				if (!AaCD47d8157A1a09('adv', 'process_monitor')) {
				} else {
					echo '                                    <li><a href="process_monitor">';
					echo $_['process_monitor'];
					echo '</a></li>' . "\r\n" . '                                    ';
				}

				echo '                                </ul>' . "\r\n" . '                            </li>' . "\r\n" . '                            ';
			}

			if (!(aAcD47d8157A1a09('adv', 'add_reguser') || aACd47d8157A1A09('adv', 'mng_regusers'))) {
			} else {
				echo '                            <li class="has-submenu">' . "\r\n" . '                                <a href="#"> <i class="fas fa-users"></i>';
				echo $_['users'];
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n" . '                                    ';

				if (!AACD47d8157A1A09('adv', 'add_reguser')) {
				} else {
					echo '                                    <li><a href="user">';
					echo $_['add_user'];
					echo '</a></li>' . "\r\n" . '                                    ';
				}

				if (!aACd47D8157a1a09('adv', 'mng_regusers')) {
				} else {
					echo '                                    <li><a href="users">';
					echo $_['manage_users'];
					echo '</a></li>' . "\r\n" . '                                    ';
				}

				echo '                                </ul>' . "\r\n" . '                            </li>' . "\r\n" . '                            ';
			}

			if (!(aAcD47D8157A1a09('adv', 'add_user') || aAcD47d8157a1A09('adv', 'users') || aacd47D8157a1a09('adv', 'add_mag') || aAcD47d8157A1a09('adv', 'manage_mag') || AAcd47d8157a1a09('adv', 'add_e2') || AAcd47d8157A1a09('adv', 'manage_e2'))) {
			} else {
				echo "\t\t\t\t\t\t\t" . '<li class="has-submenu">' . "\r\n" . '                                <a href="#"> <i class="fas fa-desktop"></i>';
				echo $_['lines'];
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n" . '                                    ';

				if (!(aAcd47d8157A1a09('adv', 'add_user') || AaCD47d8157A1A09('adv', 'users'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['user_lines'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!AACd47d8157a1a09('adv', 'add_user')) {
					} else {
						echo '                                            <li><a href="line">';
						echo $_['add_line'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aaCD47d8157A1a09('adv', 'users')) {
					} else {
						echo '                                            <li><a href="lines">';
						echo $_['manage_lines'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n\t\t\t\t\t\t\t\t\t";
				}

				if (!(AacD47d8157a1A09('adv', 'add_mag') || AAcD47d8157A1a09('adv', 'manage_mag'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['mag_devices'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!aaCd47D8157a1A09('adv', 'add_mag')) {
					} else {
						echo '                                            <li><a href="mag">';
						echo $_['add_mag'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aacD47d8157a1a09('adv', 'manage_mag')) {
					} else {
						echo '                                            <li><a href="mags">';
						echo $_['manage_mag_devices'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n\t\t\t\t\t\t\t\t\t";
				}

				if (!(aACD47d8157a1A09('adv', 'add_e2') || Aacd47D8157A1A09('adv', 'manage_e2'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['enigma_devices'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!aaCd47d8157a1a09('adv', 'add_e2')) {
					} else {
						echo '                                            <li><a href="enigma">';
						echo $_['add_enigma'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!AACD47d8157A1a09('adv', 'manage_e2')) {
					} else {
						echo '                                            <li><a href="enigmas">';
						echo $_['manage_enigma_devices'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				echo '                                </ul>' . "\r\n" . '                            </li>' . "\r\n\t\t\t\t\t\t\t";
			}

			if (!(aaCd47d8157a1a09('adv', 'add_stream') || AAcD47D8157a1a09('adv', 'create_channel') || aAcd47D8157a1a09('adv', 'import_streams') || AAcd47D8157A1A09('adv', 'streams') || AAcd47d8157A1a09('adv', 'add_movie') || aAcD47D8157a1A09('adv', 'import_movies') || AAcD47d8157a1A09('adv', 'movies') || aACD47D8157a1a09('adv', 'series') || AaCd47d8157a1a09('adv', 'episodes') || aacD47D8157A1a09('adv', 'add_series') || AaCd47d8157A1a09('adv', 'radio') || AACD47d8157A1A09('adv', 'add_radio'))) {
			} else {
				echo '                            <li class="has-submenu">' . "\r\n" . '                                <a href="#"> <i class="fas fa-play"></i>';
				echo $_['content'];
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n" . '                                    ';

				if (!(AAcD47d8157A1a09('adv', 'add_stream') || Aacd47d8157A1a09('adv', 'import_streams') || aacd47d8157a1a09('adv', 'streams'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['streams'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!aaCd47D8157a1A09('adv', 'add_stream')) {
					} else {
						echo '                                            <li><a href="stream">';
						echo $_['add_stream'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aacd47d8157a1a09('adv', 'import_streams') || $F61f585ee1fe12b7) {
					} else {
						echo '                                            <li><a href="stream?import=1">Import Multiple</a></li>' . "\r\n" . '                                            <li><a href="review?type=1">Import & Review</a></li>' . "\r\n" . '                                            ';
					}

					if (!Aacd47d8157A1a09('adv', 'streams')) {
					} else {
						echo '                                            <li><a href="streams">';
						echo $_['manage_streams'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(AAcD47d8157A1A09('adv', 'create_channel') || aAcd47D8157a1A09('adv', 'streams'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['created_channels'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!AaCd47d8157A1a09('adv', 'create_channel')) {
					} else {
						echo '                                            <li><a href="created_channel">';
						echo $_['create_channel'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!Aacd47d8157A1a09('adv', 'streams')) {
					} else {
						echo '                                            <li><a href="created_channels">';
						echo $_['manage_created_channels'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(AacD47d8157a1A09('adv', 'add_movie') || aacD47D8157a1A09('adv', 'import_movies') || AacD47d8157A1A09('adv', 'movies'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['movies'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!aacD47d8157a1A09('adv', 'add_movie')) {
					} else {
						echo '                                            <li><a href="movie">';
						echo $_['add_movie'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					if (!aAcD47D8157a1A09('adv', 'import_movies') || $F61f585ee1fe12b7) {
					} else {
						echo '                                            <li><a href="movie?import=1">Import Multiple</a></li>' . "\r\n" . '                                            <li><a href="review?type=2">Import & Review</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					if (!aacD47d8157A1A09('adv', 'movies')) {
					} else {
						echo '                                            <li><a href="movies">';
						echo $_['manage_movies'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(AAcd47D8157a1A09('adv', 'add_series') || aACd47d8157a1a09('adv', 'series') || aAcd47d8157a1A09('adv', 'episodes'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['series'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!aacd47D8157A1a09('adv', 'add_series')) {
					} else {
						echo '                                            <li><a href="serie">';
						echo $_['add_series'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					if (!AACD47d8157A1a09('adv', 'series')) {
					} else {
						echo '                                            <li><a href="series">';
						echo $_['manage_series'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					if (!aACD47d8157A1a09('adv', 'episodes')) {
					} else {
						echo '                                            <li><a href="episodes">';
						echo $_['manage_episodes'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(aacD47d8157A1A09('adv', 'add_radio') || AaCd47D8157A1A09('adv', 'radio'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['stations'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!AaCD47d8157A1A09('adv', 'add_radio')) {
					} else {
						echo '                                            <li><a href="radio">';
						echo $_['add_station'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					if (!AACD47D8157A1A09('adv', 'radio')) {
					} else {
						echo '                                            <li><a href="radios">';
						echo $_['manage_stations'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!aACd47d8157a1a09('adv', 'movies')) {
				} else {
					echo '                                    <li><a href="archive">Recordings</a></li>' . "\r\n" . '                                    ';
				}

				if ($F61f585ee1fe12b7 || !AaCD47D8157a1a09('adv', 'streams')) {
				} else {
					echo '                                    <li><a href="epg_view">TV Guide</a></li>' . "\r\n" . '                                    ';
				}

				echo '                                </ul>' . "\r\n" . '                            </li>' . "\r\n\t\t\t\t\t\t\t";
			}

			if (!(AACd47d8157a1A09('adv', 'add_bouquet') || AacD47D8157a1a09('adv', 'bouquets') || AAcd47d8157a1A09('adv', 'edit_bouquet'))) {
			} else {
				echo '                            <li class="has-submenu">' . "\r\n" . '                                <a href="#"> <i class="fas fa-spa"></i>';
				echo $_['bouquets'];
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n\t\t\t\t\t\t\t\t\t";

				if (!AaCd47d8157a1A09('adv', 'add_bouquet')) {
				} else {
					echo '                                    <li><a href="bouquet">';
					echo $_['add_bouquet'];
					echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t";
				}

				if (!aAcD47d8157a1A09('adv', 'bouquets')) {
				} else {
					echo '                                    <li><a href="bouquets">';
					echo $_['manage_bouquets'];
					echo '</a></li>' . "\r\n" . '                                    ';
				}

				if (!aAcd47D8157a1a09('adv', 'edit_bouquet') || $F61f585ee1fe12b7) {
				} else {
					echo '                                    <li><a href="bouquet_order">';
					echo $_['order_bouquets'];
					echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t";
				}

				echo '                                </ul>' . "\r\n" . '                            </li>' . "\r\n" . '                            ';
                
			}
				
			if (!(aacD47D8157a1a09('adv', 'streams') || aAcD47D8157A1a09('adv', 'episodes') || aaCd47d8157a1a09('adv', 'series') || AacD47D8157A1a09('adv', 'categories') || AaCd47D8157A1a09('adv', 'epg') || aAcD47D8157a1A09('adv', 'mng_groups') || AAcd47d8157a1a09('adv', 'mng_packages') || AAcD47d8157A1A09('adv', 'tprofiles') || aacd47D8157A1A09('adv', 'folder_watch') || aacd47d8157A1a09('adv', 'add_code') || AACd47d8157A1A09('adv', 'block_asns') || Aacd47D8157a1A09('adv', 'block_ips') || aacD47D8157A1a09('adv', 'block_isps') || aAcd47d8157a1a09('adv', 'block_uas') || aacd47D8157A1a09('adv', 'rtmp') || AaCd47d8157A1A09('adv', 'channel_order') || Aacd47D8157A1A09('adv', 'fingerprint') || AAcD47D8157a1A09('adv', 'mass_delete') || Aacd47d8157A1a09('adv', 'stream_tools') || Aacd47D8157a1a09('adv', 'mass_edit_enigmas') || AACd47D8157a1a09('adv', 'mass_edit_lines') || aaCd47D8157a1A09('adv', 'mass_edit_mags') || AaCd47d8157a1a09('adv', 'mass_sedits_vod') || aacD47d8157a1A09('adv', 'mass_sedits') || aACD47D8157a1a09('adv', 'mass_edit_radio') || AaCd47D8157a1a09('adv', 'mass_edit_streams') || AAcd47d8157a1A09('adv', 'mass_edit_users') || AAcd47D8157A1a09('adv', 'connection_logs') || aACd47D8157A1A09('adv', 'client_request_log') || AaCD47d8157A1A09('adv', 'login_logs') || AACD47d8157A1A09('adv', 'panel_logs') || AACd47d8157A1a09('adv', 'credits_log') || AACd47d8157A1A09('adv', 'live_connections') || aaCD47d8157A1A09('adv', 'manage_events') || AaCD47D8157a1a09('adv', 'reg_userlog') || aacd47d8157A1a09('adv', 'stream_errors') || aacd47D8157a1a09('adv', 'folder_watch') || AACd47D8157a1a09('adv', 'add_hmac') || aAcD47d8157a1a09('adv', 'quick_tools') || aaCd47D8157A1a09('adv', 'manage_tickets'))) {
			} else {
				echo '                            <li class="has-submenu">' . "\r\n" . '                                <a href="#"> <i class="fas fa-wrench"></i>';
				echo $_['management'];
				echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                <ul class="submenu">' . "\r\n" . '                                    ';

				if (!(aaCd47d8157A1a09('adv', 'categories') || aacd47D8157A1a09('adv', 'epg') || aaCD47D8157A1a09('adv', 'mng_groups') || AACd47d8157a1a09('adv', 'mng_packages') || AAcd47d8157a1A09('adv', 'tprofiles') || aacd47D8157A1A09('adv', 'folder_watch'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">Seteaza serviciile <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!aACd47d8157A1a09('adv', 'categories')) {
					} else {
						echo '                                            <li><a href="stream_categories">';
						echo $_['categories'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aAcD47d8157A1a09('adv', 'epg')) {
					} else {
						echo '                                            <li><a href="epgs">';
						echo $_['epgs'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aacd47d8157A1A09('adv', 'mng_groups')) {
					} else {
						echo '                                            <li><a href="groups">';
						echo $_['groups'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aACd47d8157A1A09('adv', 'mng_packages')) {
					} else {
						echo '                                            <li><a href="packages">';
						echo $_['packages'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aACd47D8157A1a09('adv', 'streams')) {
					} else {
						echo '                                            <li><a href="providers">Stream Providers</a></li>' . "\r\n" . '                                            ';
					}

					if (!aaCD47d8157A1A09('adv', 'tprofiles')) {
					} else {
						echo '                                            <li><a href="profiles">';
						echo $_['transcode_profiles'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aacd47D8157A1a09('adv', 'folder_watch')) {
					} else {
						echo '                                            <li><a href="plex">Plex Sync</a></li>' . "\r\n" . '                                            <li><a href="watch">';
						echo $_['folder_watch'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(aAcD47D8157A1A09('adv', 'add_code') || aaCD47d8157a1A09('adv', 'block_asns') || AAcD47D8157a1a09('adv', 'block_ips') || aacd47d8157A1A09('adv', 'block_isps') || aaCd47d8157A1A09('adv', 'block_uas') || AACd47D8157a1a09('adv', 'rtmp') || Aacd47d8157A1a09('adv', 'add_hmac'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">Access Control <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!AAcD47D8157A1a09('adv', 'add_code')) {
					} else {
						echo '                                            <li><a href="codes">Codurile de Access</a></li>' . "\r\n" . '                                            ';
					}

					if (!AacD47D8157A1A09('adv', 'block_asns')) {
					} else {
						echo "                                            <li><a href=\"asns\">Blockeaza ASN's</a></li>" . "\r\n" . '                                            ';
					}

					if (!AaCd47D8157A1a09('adv', 'block_ips')) {
					} else {
						echo '                                            <li><a href="ips">';
						echo $_['blocked_ips'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aAcD47D8157A1A09('adv', 'block_isps')) {
					} else {
						echo '                                            <li><a href="isps">';
						echo $_['blocked_isps'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!aaCD47D8157a1a09('adv', 'block_uas')) {
					} else {
						echo '                                            <li><a href="useragents">';
						echo $_['blocked_uas'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!AACD47D8157a1a09('adv', 'add_hmac')) {
					} else {
						echo '                                            <li><a href="hmacs">HMAC Keys</a></li>' . "\r\n" . '                                            ';
					}

					if (!aaCD47d8157a1a09('adv', 'rtmp')) {
					} else {
						echo '                                            <li><a href="rtmp_ips">';
						echo $_['rtmp_ips'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(AAcD47D8157A1a09('adv', 'channel_order') || AaCD47D8157a1A09('adv', 'rtmp') || aaCD47D8157a1A09('adv', 'fingerprint') || AacD47d8157a1A09('adv', 'mass_delete') || AACd47D8157A1a09('adv', 'stream_tools') || AAcd47d8157A1a09('adv', 'quick_tools'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['tools'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!Aacd47D8157a1a09('adv', 'channel_order') || $F61f585ee1fe12b7) {
					} else {
						echo '                                            <li><a href="channel_order">';
						echo $_['channel_order'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!AAcd47D8157a1A09('adv', 'fingerprint')) {
					} else {
						echo '                                            <li><a href="fingerprint">';
						echo $_['fingerprint'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!AaCD47D8157A1A09('adv', 'mass_delete')) {
					} else {
						echo '                                            <li><a href="mass_delete">';
						echo $_['mass_delete'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!AaCD47d8157A1a09('adv', 'quick_tools')) {
					} else {
						echo '                                            <li><a href="quick_tools">';
						echo $_['quick_tools'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					if (!AaCd47D8157a1A09('adv', 'rtmp')) {
					} else {
						echo '                                            <li><a href="rtmp_monitor">RTMP Monitor</a></li>' . "\r\n" . '                                            ';
					}

					if (!Aacd47d8157A1A09('adv', 'stream_tools')) {
					} else {
						echo '                                            <li><a href="stream_tools">';
						echo $_['stream_tools'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(aacd47D8157a1a09('adv', 'mass_edit_enigmas') || aACD47d8157a1a09('adv', 'mass_sedits') || AACd47d8157a1A09('adv', 'mass_edit_lines') || aAcd47d8157A1A09('adv', 'mass_edit_mags') || AAcD47d8157a1a09('adv', 'mass_sedits_vod') || Aacd47D8157A1a09('adv', 'mass_sedits') || AacD47D8157a1a09('adv', 'mass_edit_radio') || aACd47D8157a1a09('adv', 'mass_edit_streams') || aAcd47D8157A1a09('adv', 'mass_edit_users'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['mass_edit'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu">' . "\r\n" . '                                            ';

					if (!AacD47D8157A1a09('adv', 'mass_edit_streams')) {
					} else {
						echo '                                            <li><a href="created_channel_mass">Canale Create</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!aAcd47D8157A1A09('adv', 'mass_edit_enigmas')) {
					} else {
						echo '                                            <li><a href="enigma_mass">';
						echo $_['enigma_devices'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!aAcd47D8157A1A09('adv', 'mass_sedits')) {
					} else {
						echo '                                            <li><a href="episodes_mass">';
						echo $_['episodes'];
						echo '</a></li>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					}

					echo '                                            ';

					if (!aacd47d8157A1a09('adv', 'mass_edit_lines')) {
					} else {
						echo '                                            <li><a href="line_mass">';
						echo $_['lines'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!aAcD47D8157a1a09('adv', 'mass_edit_mags')) {
					} else {
						echo '                                            <li><a href="mag_mass">';
						echo $_['mag_devices'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!aACD47d8157a1A09('adv', 'mass_sedits_vod')) {
					} else {
						echo '                                            <li><a href="movie_mass">';
						echo $_['movies'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!AaCD47d8157a1a09('adv', 'mass_sedits')) {
					} else {
						echo '                                            <li><a href="series_mass">';
						echo $_['series'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!AAcD47d8157a1A09('adv', 'mass_edit_radio')) {
					} else {
						echo '                                            <li><a href="radio_mass">';
						echo $_['stations'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!aAcd47D8157a1A09('adv', 'mass_edit_streams')) {
					} else {
						echo '                                            <li><a href="stream_mass">';
						echo $_['streams'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if ($F61f585ee1fe12b7 || !aACD47d8157A1A09('adv', 'mass_edit_streams')) {
					} else {
						echo '                                            <li><a href="stream_review">Stream Review</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                            ';

					if (!AacD47D8157a1A09('adv', 'mass_edit_users')) {
					} else {
						echo '                                            <li><a href="user_mass">';
						echo $_['users'];
						echo '</a></li>' . "\r\n" . '                                            ';
					}

					echo '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if (!(AacD47D8157A1A09('adv', 'movies') || AAcD47D8157A1A09('adv', 'streams') || aAcd47d8157a1a09('adv', 'connection_logs') || aAcd47d8157A1A09('adv', 'client_request_log') || AACD47D8157a1A09('adv', 'login_logs') || Aacd47D8157a1a09('adv', 'panel_logs') || aACD47d8157A1A09('adv', 'credits_log') || AACD47D8157A1a09('adv', 'live_connections') || aAcD47D8157A1a09('adv', 'manage_events') || aACd47D8157A1a09('adv', 'reg_userlog') || AAcd47D8157a1a09('adv', 'streams') || aAcd47D8157A1A09('adv', 'episodes') || aAcD47d8157A1A09('adv', 'series') || Aacd47D8157A1A09('adv', 'stream_errors') || aacd47d8157A1A09('adv', 'folder_watch'))) {
				} else {
					echo '                                    <li class="has-submenu">' . "\r\n" . '                                        <a href="#">';
					echo $_['logs'];
					echo ' <div class="arrow-down"></div></a>' . "\r\n" . '                                        <ul class="submenu megamenu">' . "\r\n" . '                                            <li>' . "\r\n" . '                                                <ul>' . "\r\n" . '                                                    ';
					$a003898be4f98e56 = array(array('url' => 'line_activity', 'title' => $_['activity_logs'], 'permissions' => array('connection_logs')), array('url' => 'client_logs', 'title' => $_['client_logs'], 'permissions' => array('client_request_log')), array('url' => 'credit_logs', 'title' => $_['credit_logs'], 'permissions' => array('credits_log')), array('url' => 'queue', 'title' => 'Encoding Queue', 'permissions' => array('streams', 'episodes', 'series')), array('url' => 'line_ips', 'title' => $_['ips_per_line'], 'permissions' => array('connection_logs')), array('url' => 'live_connections', 'title' => $_['live_connections'], 'permissions' => array('live_connections')), array('url' => 'login_logs', 'title' => 'Login Logs', 'permissions' => array('login_logs')), array('url' => 'mag_events', 'title' => $_['mag_event_logs'], 'permissions' => array('manage_events')), array('url' => 'ondemand', 'title' => 'On-Demand Scanner', 'permissions' => array('streams')), array('url' => 'panel_logs', 'title' => 'Panel Errors', 'permissions' => array('panel_logs')), array('url' => 'user_logs', 'title' => $_['reseller_logs'], 'permissions' => array('reg_userlog')), array('url' => 'restream_logs', 'title' => 'Restream Detection', 'permissions' => array('restream_logs')), array('url' => 'stream_errors', 'title' => $_['stream_errors'], 'permissions' => array('stream_errors')), array('url' => 'stream_rank', 'title' => 'Stream Rank', 'permissions' => array('streams')), array('url' => 'mysql_syslog', 'title' => 'System Logs', 'permissions' => array('panel_logs')), array('url' => 'theft_detection', 'title' => 'VOD Theft Detection', 'permissions' => array('movies')), array('url' => 'watch_output', 'title' => $_['watch_folder_logs'], 'permissions' => array('folder_watch')));
					$d25a52eae3ddc116 = array();

					foreach ($a003898be4f98e56 as $fa2807b514bf8d02) {
						$De2d6b0d9f3595fc = true;

						foreach ($fa2807b514bf8d02['permissions'] as $d48363bb091686d2) {
							if (AacD47d8157A1A09('adv', $d48363bb091686d2)) {
							} else {
								$De2d6b0d9f3595fc = false;
							}
						}

						if (!$De2d6b0d9f3595fc) {
						} else {
							$d25a52eae3ddc116[] = $fa2807b514bf8d02;
						}
					}
					$B211d7401e6242f3 = null;

					if (8 >= count($d25a52eae3ddc116)) {
					} else {
						$B211d7401e6242f3 = ceil(count($d25a52eae3ddc116) / 2);
					}

					$Ea22c4a9ab5b2176 = 0;

					foreach ($d25a52eae3ddc116 as $fa2807b514bf8d02) {
						if (!($B211d7401e6242f3 && $Ea22c4a9ab5b2176 == $B211d7401e6242f3)) {
						} else {
							echo '</ul></li><li><ul>';
						}

						echo '<li><a href="' . $fa2807b514bf8d02['url'] . '">' . $fa2807b514bf8d02['title'] . '</a></li>';
						$Ea22c4a9ab5b2176++;
					}
					echo '                                                </ul>' . "\r\n" . '                                            </li>' . "\r\n" . '                                        </ul>' . "\r\n" . '                                    </li>' . "\r\n" . '                                    ';
				}

				if ($F2d4d8f7981ac574['show_tickets'] || !aACd47D8157a1A09('adv', 'manage_tickets')) {
				} else {
					echo '                                    <li><a href="tickets">';
					echo $_['tickets'];
					echo '</a></li>' . "\r\n" . '                                    ';
				}

				echo '                                </ul>' . "\r\n" . '                            </li>' . "\r\n" . '                            ';
			}
      
      if (!aACd47D8157A1a09('adv', 'streams')) {
					} else {
						echo '<li><a href="providers"><i class="fas fa-users"></i>Stream Providers</a></li>' . "\r\n" . '    ';
					}
      
      
      
      

			echo '                        </ul>' . "\r\n" . '                        <div class="clearfix"></div>' . "\r\n" . '                    </div>' . "\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n" . '            ';
		}

		echo '        </header>' . "\r\n\t\t";
	}

	if (!$F2d4d8f7981ac574['js_navigate']) {
	} else {
		echo '        <div id="status">' . "\r\n" . '            <div class="spinner"></div>' . "\r\n" . '        </div>' . "\r\n" . '        ';
	}
} else {
	exit();
}
