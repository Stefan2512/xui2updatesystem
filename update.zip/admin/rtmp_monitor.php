<?php

include 'session.php';
include 'functions.php';

if (B1882DF698b44754()) {
} else {
	b46f5Dd76F3c7421();
}

if (isset(XUI::$rRequest['server']) && isset($a8bb73cba48fb7f6[XUI::$rRequest['server']])) {
} else {
	XUI::$rRequest['server'] = SERVER_ID;
}

$F1c7f989b40d41bb = F628024A69e60B02(XUI::$rRequest['server']);
$bcf587bb39f95fd5 = 'RTMP Monitor';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n\t\t\t\t\t\t" . '<ol class="breadcrumb m-0">' . "\r\n\t\t\t\t\t\t\t" . '<li>' . "\r\n\t\t\t\t\t\t\t\t" . "<a href=\"javascript:void(0);\" onClick=\"navigate('rtmp_monitor');\" style=\"margin-right:10px;\">" . "\r\n\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-dark waves-effect waves-light btn-sm">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-refresh"></i> ';
echo $_['refresh'];
echo "\t\t\t\t\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t" . '</ol>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">RTMP Monitor</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<table class="table table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t" . '<thead class="thead-light">' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">RTMP PID</th>' . "\r\n" . '                                    <th class="text-center">NGINX Version</th>' . "\r\n" . '                                    <th class="text-center">FLV Version</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Uptime</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Input Mbps</th>' . "\r\n" . '                                    <th class="text-center">Output Mbps</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
echo $F1c7f989b40d41bb['pid'];
echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
echo $F1c7f989b40d41bb['nginx_version'];
echo '</td>' . "\r\n" . '                                    <td class="text-center">';
echo $F1c7f989b40d41bb['nginx_http_flv_version'];
echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\r\n" . '                                        ';
$fad73125a2cca3ed = $F1c7f989b40d41bb['uptime'];

if (86400 <= $fad73125a2cca3ed) {
	$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
} else {
	$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
}

echo "<button type='button' class='btn btn-success btn-xs waves-effect waves-light btn-fixed'>" . $fad73125a2cca3ed . '</button>';
echo '                                    </td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
echo number_format($F1c7f989b40d41bb['bw_in'] / 1000 / 1000, 2);
echo ' Mbps</td>' . "\r\n" . '                                    <td class="text-center">';
echo number_format($F1c7f989b40d41bb['bw_out'] / 1000 / 1000, 2);
echo ' Mbps</td>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<form id="line_activity_search">' . "\r\n\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-4">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="live_search" value="" placeholder="Search Streams...">' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<label class="col-md-1 col-form-label text-center" for="live_filter">';
echo $_['server'];
echo '</label>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-4">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<select id="live_filter" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t\t";

foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
	echo "\t\t\t\t\t\t\t\t\t\t" . '<option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (XUI::$rRequest['server'] != $e81220b4451f37c9['id']) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<label class="col-md-1 col-form-label text-center" for="live_show_entries">';
echo $_['show'];
echo '</label>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<select id="live_show_entries" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</form>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\r\n" . '                                    <th>RTMP URL</th>' . "\r\n" . '                                    <th class="text-center">Publisher IP</th>' . "\r\n" . '                                    <th class="text-center">Uptime</th>' . "\r\n" . '                                    <th class="text-center">Clients</th>' . "\r\n" . '                                    <th class="text-center">Stream Info</th>' . "\r\n" . '                                    <th class="text-center">Actions</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n" . '                                ';
$A2b85ede89f9df0c = $F1c7f989b40d41bb['server']['application']['live']['stream'];

if (!isset($A2b85ede89f9df0c['name'])) {
} else {
	$A2b85ede89f9df0c = array($A2b85ede89f9df0c);
}

foreach ($A2b85ede89f9df0c as $f523e362fb81d6c8) {
	if (!isset($f523e362fb81d6c8['client']['id'])) {
	} else {
		$f523e362fb81d6c8['client'] = array($f523e362fb81d6c8['client']);
	}

	$ec740e752dd1e1c8 = count($f523e362fb81d6c8['client']);
	$f0b0e6c4a40508b3 = '';

	foreach ($f523e362fb81d6c8['client'] as $C426358e96a98000) {
		if ($f523e362fb81d6c8['time'] > $C426358e96a98000['time']) {
		} else {
			$f0b0e6c4a40508b3 = "<a onClick=\"whois('" . $C426358e96a98000['address'] . "');\" href='javascript: void(0);'>" . $C426358e96a98000['address'] . '</a>';
			$ec740e752dd1e1c8--;

			break;
		}
	}

	if (0 < $ec740e752dd1e1c8 && is_numeric($f523e362fb81d6c8['name'])) {
		$ec5b28bb1cbf9f2d = "<a href='live_connections?search=RTMP&stream_id=" . intval($f523e362fb81d6c8['name']) . '&server=' . intval(XUI::$rRequest['server']) . "'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $ec740e752dd1e1c8 . '</button></a>';
	} else {
		if (0 < $ec740e752dd1e1c8) {
			$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $ec740e752dd1e1c8 . '</button>';
		} else {
			$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
		}
	}

	echo "\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo $f523e362fb81d6c8['name'];
	echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo htmlspecialchars(XUI::$rServers[intval(XUI::$rRequest['server'])]['rtmp_server']) . $f523e362fb81d6c8['name'];
	echo '</td>' . "\r\n" . '                                    <td class="text-center">';
	echo $f0b0e6c4a40508b3;
	echo '</td>' . "\r\n" . '                                    <td class="text-center">' . "\r\n" . '                                        ';
	$fad73125a2cca3ed = $f523e362fb81d6c8['time'] / 1000;

	if (86400 <= $fad73125a2cca3ed) {
		$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
	} else {
		$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
	}

	echo "<button type='button' class='btn btn-success btn-xs waves-effect waves-light btn-fixed'>" . $fad73125a2cca3ed . '</button>';
	echo '                                    </td>' . "\r\n" . '                                    <td class="text-center">';
	echo $ec5b28bb1cbf9f2d;
	echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\r\n" . "                                        <table class='table-data' style=\"width: 300px !important; white-space: nowrap;\" align='center'><tbody><tr><td class='double'>";
	echo number_format($f523e362fb81d6c8['bw_in'] / 1000, 0);
	echo " Kbps</td><td style='color: #20a009;'><i class='mdi mdi-video' data-name='mdi-video'></i></td><td style='color: #20a009;'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td><td style='color: #20a009;'><i class='mdi mdi-layers' data-name='mdi-layers'></i></td></tr><tr><td class='double'>";
	echo $f523e362fb81d6c8['meta']['video']['width'];
	echo ' x ';
	echo $f523e362fb81d6c8['meta']['video']['height'];
	echo '</td><td>';
	echo $f523e362fb81d6c8['meta']['video']['codec'];
	echo '</td><td>';
	echo $f523e362fb81d6c8['meta']['audio']['codec'];
	echo '</td><td>';
	echo round($f523e362fb81d6c8['meta']['video']['frame_rate'], 0);
	echo ' FPS</td></tr></tbody></table>' . "\r\n" . '                                    </td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<button data-toggle="tooltip" title="Kill Stream" type="button" class="btn tooltip btn-light waves-effect waves-light btn-xs" onClick="kill(';
	echo intval(XUI::$rRequest['server']);
	echo ", '";
	echo $f523e362fb81d6c8['name'];
	echo "');\"><i class=\"mdi mdi-close\"></i></button>" . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</td>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
