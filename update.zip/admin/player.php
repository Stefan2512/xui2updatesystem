<?php

include 'session.php';
include 'functions.php';

if (isset(XUI::$rRequest['id'])) {
	if (b1882dF698B44754()) {
	} else {
		B46F5Dd76f3c7421();
	}

	$bae85948a6f4b7de = time() + 14400;
	$F64d974c429d80be = array('session_id' => session_id(), 'expires' => $bae85948a6f4b7de, 'stream_id' => intval(XUI::$rRequest['id']), 'ip' => XUI::a9Bc416Fa6Fa55C3());
	$D8394423706a1469 = false;

	if (!isset(XUI::$rRequest['container'])) {
	} else {
		$F64d974c429d80be['container'] = XUI::$rRequest['container'];

		if ($F64d974c429d80be['container'] == 'mp4') {
		} else {
			$D8394423706a1469 = true;
		}
	}

	if (!isset(XUI::$rRequest['start'])) {
	} else {
		$F64d974c429d80be['start'] = XUI::$rRequest['start'];
	}

	if (!isset(XUI::$rRequest['duration'])) {
	} else {
		$F64d974c429d80be['duration'] = XUI::$rRequest['duration'];
	}

	if (in_array(XUI::$rRequest['type'], array('live', 'timeshift'))) {
		$Fee0d5a474c96306->query('SELECT `server_id`, `on_demand` FROM `streams_servers` WHERE ((`streams_servers`.`monitor_pid` > 0 AND `streams_servers`.`pid` > 0) OR (`streams_servers`.`on_demand` = 1)) AND `stream_id` = ?;', XUI::$rRequest['id']);
	} else {
		$Fee0d5a474c96306->query('SELECT `server_id`, `on_demand` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE (`streams`.`direct_source` = 0 AND `streams_servers`.`pid` > 0 AND `streams_servers`.`to_analyze` = 0 AND `streams_servers`.`stream_status` <> 1) AND `stream_id` = ?;', XUI::$rRequest['id']);
	}

	$Beb96c2a189d2e62 = false;
	$d58b4f8653a391d8 = null;

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($C740da31596f24ef['server_id'] == SERVER_ID) {
			$d58b4f8653a391d8 = $C740da31596f24ef['server_id'];
		} else {
			if ($d58b4f8653a391d8) {
			} else {
				$d58b4f8653a391d8 = $C740da31596f24ef['server_id'];
			}
		}

		$Beb96c2a189d2e62 = $C740da31596f24ef['on_demand'];
	}

	if ($d58b4f8653a391d8) {
		$f6cb1b77556fb98a = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

		if (!$Beb96c2a189d2e62) {
		} else {
			$Cf8ac6bbb9af24a9 = 'http://' . $a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_ip'] . ':' . $a8bb73cba48fb7f6[$d58b4f8653a391d8]['http_broadcast_port'] . '/admin/live?password=' . XUI::$rSettings['live_streaming_pass'] . '&stream=' . intval(XUI::$rRequest['id']) . '&extension=.m3u8&odstart=1';

			if (intval(file_get_contents($Cf8ac6bbb9af24a9, false, stream_context_create(array('http' => array('timeout' => 20))))) != 0) {
			} else {
				exit();
			}
		}

		$C700a2b357e5ed65 = $C6033ec178efa2ae . '://' . (($a8bb73cba48fb7f6[$d58b4f8653a391d8]['domain_name'] ? explode(',', $a8bb73cba48fb7f6[$d58b4f8653a391d8]['domain_name'])[0] : $a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_ip'])) . ':' . ((b1d9852FcEb75e78() ? $a8bb73cba48fb7f6[$d58b4f8653a391d8]['https_broadcast_port'] : $a8bb73cba48fb7f6[$d58b4f8653a391d8]['http_broadcast_port'])) . '/admin/' . ((XUI::$rRequest['type'] == 'live' ? 'live' : (XUI::$rRequest['type'] == 'timeshift' ? 'timeshift' : 'vod'))) . '?uitoken=' . $f6cb1b77556fb98a . ((XUI::$rRequest['type'] == 'live' ? '&extension=.m3u8' : ''));
		echo '<html>' . "\n" . '    <script src="assets/js/vendor.min.js"></script>' . "\n" . '    ';

		if ($D8394423706a1469) {
		} else {
			echo '    <script src="assets/libs/jwplayer/jwplayer.js"></script>' . "\n" . '    <script src="assets/libs/jwplayer/jwplayer.core.controls.js"></script>' . "\n" . '    ';
		}

		echo '    <style>html { overflow: hidden; }</style>' . "\n" . '    <body>' . "\n" . '        ';

		if ($D8394423706a1469) {
			echo '        <video id="video" width="100%" height="100%" src="';
			echo $C700a2b357e5ed65;
			echo '" controls></video>' . "\n" . '        ';
		} else {
			echo '        <div id="now__playing__player"></div>' . "\n" . '        ';
		}

		echo '    </body>' . "\n" . '    <script>' . "\n" . '    $(document).ready(function() {' . "\n" . '        ';

		if (!$D8394423706a1469) {
			echo '        var rPlayer = jwplayer("now__playing__player");' . "\n" . '        rPlayer.setup({' . "\n" . '            "file": "';
			echo $C700a2b357e5ed65;
			echo '",' . "\n" . '            "type": "';
			echo(in_array(XUI::$rRequest['type'], array('live', 'timeshift')) ? 'hls' : preg_replace('/[^A-Za-z0-9 ]/', '', $F64d974c429d80be['container']));
			echo '",' . "\n" . '            "autostart": true,' . "\n" . '            "width": "100%",' . "\n" . '            "height": "100%"' . "\n" . '        });' . "\n" . '        rPlayer.play();' . "\n" . '        ';
		} else {
			echo '        $("video").trigger("play");' . "\n" . '        ';
		}

		echo '    });' . "\n" . '    </script>' . "\n" . '</html>';
	} else {
		exit();
	}
} else {
	exit();
}
