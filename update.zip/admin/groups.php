<?php

include 'session.php';
include 'functions.php';

if (b1882dF698B44754()) {
} else {
	B46F5Dd76f3C7421();
}

$bcf587bb39f95fd5 = 'Groups';
include 'header.php';
echo '<div class="wrapper boxed-layout"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['groups'];
echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t";
	echo $_['group_success'];
	echo "\t\t\t\t" . '</div>' . "\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['group_name'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['is_admin'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['is_reseller'];
echo '</th>' . "\n" . '                                    <th class="text-center">Subresellers</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach (BA348B5700ee9FF3() as $D307572f7986a746) {
	echo "\t\t\t\t\t\t\t\t" . '<tr id="group-';
	echo $D307572f7986a746['group_id'];
	echo '">' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo $D307572f7986a746['group_id'];
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo $D307572f7986a746['group_name'];
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n" . '                                        ';

	if ($D307572f7986a746['is_admin']) {
		echo "                                        <i class='text-success mdi mdi-circle'></i>" . "\n" . '                                        ';
	} else {
		echo "                                        <i class='text-secondary mdi mdi-circle'></i>" . "\n" . '                                        ';
	}

	echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

	if ($D307572f7986a746['is_reseller']) {
		echo "                                        <i class='text-success mdi mdi-circle'></i>" . "\n" . '                                        ';
	} else {
		echo "                                        <i class='text-secondary mdi mdi-circle'></i>" . "\n" . '                                        ';
	}

	echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

	if ($D307572f7986a746['create_sub_resellers']) {
		echo "                                        <i class='text-success mdi mdi-circle'></i>" . "\n" . '                                        ';
	} else {
		echo "                                        <i class='text-secondary mdi mdi-circle'></i>" . "\n" . '                                        ';
	}

	echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t";

	if (!AAcd47D8157A1A09('adv', 'edit_group')) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./group?id=';
		echo $D307572f7986a746['group_id'];
		echo '"><button type="button" data-toggle="tooltip" data-placement="top" title="" data-original-title="';
		echo $_['edit_group'];
		echo '" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-pencil-outline"></i></button></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t";

		if (!$D307572f7986a746['can_delete']) {
		} else {
			echo "\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" data-toggle="tooltip" data-placement="top" title="" data-original-title="';
			echo $_['delete_group'];
			echo '" class="btn btn-light waves-effect waves-light btn-xs" onClick="api(';
			echo $D307572f7986a746['group_id'];
			echo ", 'delete');\"\"><i class=\"mdi mdi-close\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t";
		}
	}

	echo "\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
