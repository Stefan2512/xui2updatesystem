<?php

include 'session.php';
include 'functions.php';

if (b1882dF698B44754()) {
} else {
	B46f5DD76f3c7421();
}

$cb498e4dcaac05cc = D7a15E0c2d9BECE1();
$bcf587bb39f95fd5 = 'Bouquets';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n\t\t\t\t\t\t";
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $_['bouquets'];
echo '</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo '                <div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    Bouquet has been added / modified.' . "\n" . '                </div>' . "\n" . '                ';
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['bouquet_name'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['streams'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['movies'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['series'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['stations'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
	echo "\t\t\t\t\t\t\t\t" . '<tr id="bouquet-';
	echo intval($ddf0508b312dbfb8['id']);
	echo '">' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo intval($ddf0508b312dbfb8['id']);
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo htmlspecialchars($ddf0508b312dbfb8['bouquet_name']);
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light">';
	echo number_format(count(json_decode($ddf0508b312dbfb8['bouquet_channels'], true)), 0);
	echo '</button></td>' . "\n" . '                                    <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light">';
	echo number_format(count(json_decode($ddf0508b312dbfb8['bouquet_movies'], true)), 0);
	echo '</button></td>' . "\n" . '                                    <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light">';
	echo number_format(count(json_decode($ddf0508b312dbfb8['bouquet_series'], true)), 0);
	echo '</button></td>' . "\n" . '                                    <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light">';
	echo number_format(count(json_decode($ddf0508b312dbfb8['bouquet_radios'], true)), 0);
	echo '</button></td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t\t";

	if (AaCd47D8157a1A09('adv', 'edit_bouquet')) {
		echo "\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./bouquet_sort?id=';
		echo intval($ddf0508b312dbfb8['id']);
		echo '"><button type="button" title="';
		echo $_['reorder_bouquet'];
		echo '" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-format-line-spacing"></i></button></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./bouquet?id=';
		echo intval($ddf0508b312dbfb8['id']);
		echo '"><button type="button" title="';
		echo $_['edit_bouquet'];
		echo '" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./bouquet?duplicate=';
		echo intval($ddf0508b312dbfb8['id']);
		echo '"><button type="button" title="Duuplicate Bouquet" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-content-copy"></i></button></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="';
		echo $_['delete_bouquet'];
		echo '" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
		echo intval($ddf0508b312dbfb8['id']);
		echo ", 'delete');\"\"><i class=\"mdi mdi-close\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t";
	} else {
		echo '--';
	}

	echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
