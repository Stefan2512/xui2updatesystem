<?php

include 'session.php';
include 'functions.php';

if (b1882df698b44754()) {
} else {
	B46f5dd76f3C7421();
}

XUI::$rServers = XUI::F99d78e199D641d5(true);
$bcf587bb39f95fd5 = 'Proxy Servers';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n\t\t\t\t\t\t";
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Proxy Servers</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Status</th>' . "\n" . '                                    <th>Proxy Name</th>' . "\n" . '                                    <th>Proxied Server</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Proxy IP</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Network</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Connections</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">CPU %</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">MEM %</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Ping</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach (XUI::$rServers as $e81220b4451f37c9) {
	if ($e81220b4451f37c9['server_type'] == 1) {
		$C39e5afe2a23deaa = json_decode($e81220b4451f37c9['watchdog_data'], true);

		if (is_array($C39e5afe2a23deaa)) {
		} else {
			$C39e5afe2a23deaa = array('total_mem_used_percent' => 0, 'cpu' => 0);
		}

		if (XUI::$rServers[$e81220b4451f37c9['id']]['server_online']) {
		} else {
			$C39e5afe2a23deaa['cpu'] = 0;
			$C39e5afe2a23deaa['total_mem_used_percent'] = 0;
		}

		echo "\t\t\t\t\t\t\t\t" . '<tr id="server-';
		echo $e81220b4451f37c9['id'];
		echo '">' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
		echo $e81220b4451f37c9['id'];
		echo '</td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

		if (!$e81220b4451f37c9['enabled']) {
			echo '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
		} else {
			if ($e81220b4451f37c9['server_online']) {
				echo '<i class="text-success fas fa-square tooltip" title="Online"></i>';
			} else {
				if (0 < $e81220b4451f37c9['last_check_ago']) {
					$Af547236269d8f66 = date($F2d4d8f7981ac574['datetime_format'], $e81220b4451f37c9['last_check_ago']);
				} else {
					$Af547236269d8f66 = 'Never';
				}

				if ($e81220b4451f37c9['status'] == 3) {
					echo '<i class="text-info fas fa-square tooltip" title="Installing..."></i>';
				} else {
					if ($e81220b4451f37c9['status'] == 4) {
						echo '<i class="text-warning fas fa-square tooltip" title="Installation Failed!"></i>';
					} else {
						if ($e81220b4451f37c9['status'] == 5) {
							echo '<i class="text-info fas fa-square tooltip" title="Updating..."></i>';
						} else {
							echo '<i class="text-danger fas fa-square tooltip" title="Last Ping: ' . $Af547236269d8f66 . '"></i>';
						}
					}
				}
			}
		}

		echo '                                    </td>' . "\n" . '                                    <td><a href="server_view?id=';
		echo $e81220b4451f37c9['id'];
		echo '">';
		echo $e81220b4451f37c9['server_name'];
		echo(!empty($e81220b4451f37c9['domain_name']) ? '<br/><small>' . explode(',', $e81220b4451f37c9['domain_name'])[0] . '</small>' : '');
		echo '</a></td>' . "\n" . '                                    <td><a href="server_view?id=';
		echo $e81220b4451f37c9['parent_id'][0];
		echo '">';
		echo $a8bb73cba48fb7f6[$e81220b4451f37c9['parent_id'][0]]['server_name'];
		echo '</a>';

		if (1 >= count($e81220b4451f37c9['parent_id'])) {
		} else {
			echo '&nbsp; <button title="View All Servers" onClick="viewServers(';
			echo intval($e81220b4451f37c9['id']);
			echo ");\" type='button' class='tooltip-left btn btn-info btn-xs waves-effect waves-light'>+ ";
			echo count($e81220b4451f37c9['parent_id']) - 1;
			echo '</button>';
		}

		echo '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . "<td class=\"text-center\"><a onClick=\"whois('";
		echo $e81220b4451f37c9['server_ip'];
		echo "');\" href=\"javascript: void(0);\">";
		echo $e81220b4451f37c9['server_ip'];
		echo '</a></td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t";
		$ec5b28bb1cbf9f2d = beEB53575450629a($e81220b4451f37c9['id'], true);

		if (AacD47D8157A1A09('adv', 'live_connections')) {
			$ec5b28bb1cbf9f2d = '<a href="./live_connections?server=' . $e81220b4451f37c9['id'] . "\"><button type='button' class='btn btn-dark bg-animate btn-xs waves-effect waves-light no-border'>" . number_format($ec5b28bb1cbf9f2d, 0) . '</button></a>';
		} else {
			$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-dark bg-animate btn-xs waves-effect waves-light no-border'>" . number_format($ec5b28bb1cbf9f2d, 0) . '</button>';
		}

		echo $ec5b28bb1cbf9f2d;
		echo "\t\t\t\t\t\t\t\t\t" . '<br/><small>of ';
		echo number_format($e81220b4451f37c9['total_clients'], 0);
		echo '</small>' . "\n" . '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n" . '                                        <button type="button" class="btn btn-dark bg-animate btn-xs waves-effect waves-light no-border"><span id="header_streams_up">';
		echo number_format($C39e5afe2a23deaa['bytes_sent'] / 125000, 0);
		echo '</span> <i class="mdi mdi-arrow-up-thick"></i> &nbsp; <span id="header_streams_down">';
		echo number_format($C39e5afe2a23deaa['bytes_received'] / 125000, 0);
		echo '</span> <i class="mdi mdi-arrow-down-thick"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<br/><small>';
		echo number_format($e81220b4451f37c9['network_guaranteed_speed'], 0);
		echo ' Mbps</small>' . "\n" . '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n" . '                                        ';

		if (intval($C39e5afe2a23deaa['cpu']) <= 34) {
			$Ac54397e06e8e862 = '#23b397';
		} else {
			if (intval($C39e5afe2a23deaa['cpu']) <= 67) {
				$Ac54397e06e8e862 = '#f8cc6b';
			} else {
				$Ac54397e06e8e862 = '#f0643b';
			}
		}

		echo '                                        <input data-plugin="knob" data-width="48" data-height="48" data-bgColor="';

		if ($D4253f9520627819['theme'] == 1) {
			echo '#7e8e9d';
		} else {
			echo '#ebeff2';
		}

		echo '" data-fgColor="';
		echo $Ac54397e06e8e862;
		echo '" data-readOnly=true value="';
		echo intval($C39e5afe2a23deaa['cpu']);
		echo '"/>' . "\n" . '                                    </td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

		if (intval($C39e5afe2a23deaa['total_mem_used_percent']) <= 34) {
			$Ac54397e06e8e862 = '#23b397';
		} else {
			if (intval($C39e5afe2a23deaa['total_mem_used_percent']) <= 67) {
				$Ac54397e06e8e862 = '#f8cc6b';
			} else {
				$Ac54397e06e8e862 = '#f0643b';
			}
		}

		echo '                                        <input data-plugin="knob" data-width="48" data-height="48" data-bgColor="';

		if ($D4253f9520627819['theme'] == 1) {
			echo '#7e8e9d';
		} else {
			echo '#ebeff2';
		}

		echo '" data-fgColor="';
		echo $Ac54397e06e8e862;
		echo '" data-readOnly=true value="';
		echo intval($C39e5afe2a23deaa['total_mem_used_percent']);
		echo '"/>' . "\n" . '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . "<td class=\"text-center\"><button type='button' class='btn btn-light btn-xs waves-effect waves-light'>";
		echo number_format(($e81220b4451f37c9['server_online'] ? $e81220b4451f37c9['ping'] : 0), 0);
		echo ' ms</button></td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t\t";

		if (aacd47d8157A1A09('adv', 'edit_server')) {
			if (XUI::$rSettings['group_buttons']) {
				echo "\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group dropdown">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-menu"></i></a>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dropdown-menu dropdown-menu-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item btn-reboot-server" href="javascript:void(0);" data-id="';
				echo $e81220b4451f37c9['id'];
				echo '">Proxy Tools</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'kill');\">Kill Connections</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="./proxy?id=';
				echo $e81220b4451f37c9['id'];
				echo '">Edit Proxy</a>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t";

				if ($e81220b4451f37c9['enabled']) {
					echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'disable');\">Disable Proxy</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
				} else {
					echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'enable');\">Enable Proxy</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t\t\t\t\t\t" . '<a class="dropdown-item" href="javascript:void(0);" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'delete');\">Delete Proxy</a>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t";
			} else {
				echo "\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="Proxy Tools" class="btn btn-light waves-effect waves-light btn-xs btn-reboot-server tooltip" data-id="';
				echo $e81220b4451f37c9['id'];
				echo '"><i class="mdi mdi-creation"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" title="Kill All Connections" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'kill');\"><i class=\"fas fa-hammer\"></i></button>" . "\n" . '                                            <a href="./proxy?id=';
				echo $e81220b4451f37c9['id'];
				echo '"><button type="button" title="Edit Proxy" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>' . "\n" . '                                            ';

				if ($e81220b4451f37c9['enabled']) {
					echo '                                            <button type="button" title="Disable Proxy" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'disable');\"><i class=\"mdi mdi-close-network-outline\"></i></button>" . "\n" . '                                            ';
				} else {
					echo '                                            <button type="button" title="Enable Proxy" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
					echo $e81220b4451f37c9['id'];
					echo ", 'enable');\"><i class=\"mdi mdi-access-point-network\"></i></button>" . "\n" . '                                            ';
				}

				echo '                                            <button type="button" title="Delete Proxy" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(';
				echo $e81220b4451f37c9['id'];
				echo ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t";
			}
		} else {
			echo '--';
		}

		echo "\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t";
	}
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
