<?php

include 'session.php';
include 'functions.php';

if (b1882dF698B44754()) {
} else {
	B46f5dd76F3c7421();
}

$bcf587bb39f95fd5 = 'Plex Sync';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Plex Sync</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo '                <div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    The server is now being synced. It will be scanned during the next Plex Sync run.' . "\n" . '                </div>' . "\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                    <th class="text-center">Status</th>' . "\n" . '                                    <th class="text-center">Plex IP</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Server Name</th>' . "\n" . '                                    <th>Library</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Last Run</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach (getPlexServers() as $e81220b4451f37c9) {
	if (0 < $e81220b4451f37c9['last_run']) {
		$c94b497359f8aed9 = date('Y-m-d H:i:s', $e81220b4451f37c9['last_run']);
	} else {
		$c94b497359f8aed9 = 'Never';
	}

	$E21ec5d638d1a2ca = 'Unknown';

	foreach (json_decode($e81220b4451f37c9['plex_libraries'], true) as $f4039bf182dd75cc) {
		if (intval($f4039bf182dd75cc['key']) != intval($e81220b4451f37c9['directory'])) {
		} else {
			$E21ec5d638d1a2ca = $f4039bf182dd75cc['title'];

			break;
		}
	}
	$F83240b668152664 = (is_null($e81220b4451f37c9['server_add']) ? 0 : count(json_decode($e81220b4451f37c9['server_add'], true)));
	echo "\t\t\t\t\t\t\t\t" . '<tr id="folder-';
	echo intval($e81220b4451f37c9['id']);
	echo '">' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo intval($e81220b4451f37c9['id']);
	echo '</td>' . "\n" . '                                    <td class="text-center">' . "\n" . '                                        ';

	if ($e81220b4451f37c9['active']) {
		echo '                                        <i class="text-success fas fa-square"></i>' . "\n" . '                                        ';
	} else {
		echo '                                        <i class="text-secondary fas fa-square"></i>' . "\n" . '                                        ';
	}

	echo '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo $e81220b4451f37c9['plex_ip'];
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo $a8bb73cba48fb7f6[$e81220b4451f37c9['server_id']]['server_name'] . ((0 < $F83240b668152664 ? "&nbsp; <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>+ " . $F83240b668152664 . '</button>' : ''));
	echo '                                    </td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td>';
	echo $E21ec5d638d1a2ca;
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
	echo $c94b497359f8aed9;
	echo '</td>' . "\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./plex_add?id=';
	echo intval($e81220b4451f37c9['id']);
	echo '"><button type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-pencil-outline"></i></button></a>' . "\n" . '                                            <button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="api(';
	echo intval($e81220b4451f37c9['id']);
	echo ", 'force');\"><i class=\"mdi mdi-refresh\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="api(';
	echo intval($e81220b4451f37c9['id']);
	echo ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t" . '</td>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
