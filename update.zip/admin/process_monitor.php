<?php

include 'session.php';
include 'functions.php';

if (B1882dF698b44754()) {
} else {
	B46F5Dd76f3c7421();
}

if (isset(XUI::$rRequest['server']) && isset($a8bb73cba48fb7f6[XUI::$rRequest['server']])) {
} else {
	XUI::$rRequest['server'] = SERVER_ID;
}

if (!isset(XUI::$rRequest['clear'])) {
	if (!isset(XUI::$rRequest['clear_s'])) {
		$A2b85ede89f9df0c = a569fe109782304D(XUI::$rRequest['server']);
		$Ed937f6c4a4c540b = B4167cfCa7Fe90F8(XUI::$rRequest['server']);
		$D238fb37ea40fafb = a384500BaD4447a8(XUI::$rRequest['server']);
		$Ba23222f3ed2dc08 = array('D' => 'Uninterruptible Sleep', 'I' => 'Idle', 'R' => 'Running', 'S' => 'Interruptible Sleep', 'T' => 'Stopped', 'W' => 'Paging', 'X' => 'Dead', 'Z' => 'Zombie');
		$bcf587bb39f95fd5 = 'Process Monitor';
		include 'header.php';
		echo '<div class="wrapper"';

		if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
		} else {
			echo ' style="display: none;"';
		}

		echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n\t\t\t\t\t\t" . '<ol class="breadcrumb m-0">' . "\r\n\t\t\t\t\t\t\t" . '<li>' . "\r\n\t\t\t\t\t\t\t\t" . '<a href="process_monitor?server=';
		echo intval(XUI::$rRequest['server']);
		echo '" style="margin-right:10px;">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-dark waves-effect waves-light btn-sm">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-refresh"></i> ';
		echo $_['refresh'];
		echo "\t\t\t\t\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t" . '</ol>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">';
		echo $_['process_monitor'];
		echo '</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n" . '                ';

		if ($F61f585ee1fe12b7) {
		} else {
			if (0 >= count($Ed937f6c4a4c540b)) {
			} else {
				echo "\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<table class="table table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t" . '<thead class="thead-light">' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
				echo $_['mount_point'];
				echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
				echo $_['size'];
				echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
				echo $_['used'];
				echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
				echo $_['available'];
				echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
				echo $_['used'];
				echo ' %</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
				echo $_['actions'];
				echo '</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t";

				foreach ($Ed937f6c4a4c540b as $E4f80a40a4682e20) {
					if (80 > $E4f80a40a4682e20['percentage']) {
					} else {
						$B4a5f8dc1f8d260c = STATUS_SPACE_ISSUE;
					}

					echo "\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>';
					echo $E4f80a40a4682e20['mount'];
					echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
					echo $E4f80a40a4682e20['size'];
					echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
					echo $E4f80a40a4682e20['used'];
					echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';
					echo $E4f80a40a4682e20['avail'];
					echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">';

					if (80 <= intval(rtrim($E4f80a40a4682e20['percentage'], '%'))) {
						echo "<span class='text-danger'>" . $E4f80a40a4682e20['percentage'] . '</span>';
					} else {
						echo $E4f80a40a4682e20['percentage'];
					}

					echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";

					if (substr($E4f80a40a4682e20['mount'], strlen($E4f80a40a4682e20['mount']) - 3, 3) == 'tmp') {
						echo "\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./process_monitor?server=';
						echo intval(XUI::$rRequest['server']);
						echo '&clear"><button data-toggle="tooltip" data-placement="top" title="" data-original-title="';
						echo $_['clear_temp'];
						echo '" type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-close"></i></button></a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
					} else {
						if (substr($E4f80a40a4682e20['mount'], strlen($E4f80a40a4682e20['mount']) - 7, 7) != 'streams') {
						} else {
							echo "\t\t\t\t\t\t\t\t\t\t\t" . '<a href="./process_monitor?server=';
							echo intval(XUI::$rRequest['server']);
							echo '&clear_s"><button data-toggle="tooltip" data-placement="top" title="" data-original-title="';
							echo $_['clear_streams'];
							echo '" type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-close"></i></button></a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
						}
					}

					echo "\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</td>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t";
				}
				echo "\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
			}

			if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SPACE_ISSUE)) {
			} else {
				echo '                <div class="alert alert-danger text-center" role="alert">' . "\r\n" . '                    <strong>You are running out of space on one or more of your mount points. You should resolve this before issues occur.</strong>' . "\r\n" . '                </div>' . "\r\n" . '                ';
			}

			$fe3612454622141f = getStreamsRamdisk(XUI::$rRequest['server']);
			$Fee0d5a474c96306->query('SELECT `stream_id`, `stream_display_name`, `bitrate` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `pid` > 0;', XUI::$rRequest['server']);
			$c92aec5c90838930 = $Fee0d5a474c96306->get_rows(true, 'stream_id');
			$b84a7819a4a0cc12 = array();

			foreach ($fe3612454622141f as $F26087d31c2bbe4d => $a77daf9df0093a16) {
				if (!isset($c92aec5c90838930[$F26087d31c2bbe4d])) {
				} else {
					$b84a7819a4a0cc12[$F26087d31c2bbe4d] = $a77daf9df0093a16;
				}
			}
			asort($b84a7819a4a0cc12);
			$b84a7819a4a0cc12 = array_reverse($b84a7819a4a0cc12, true);
			$a127c9f4d540a6fd = ceil(count($b84a7819a4a0cc12) / 2);

			if (10 >= $a127c9f4d540a6fd) {
			} else {
				$a127c9f4d540a6fd = 10;
			}

			$Aed08c2fd5911dba = array_slice($b84a7819a4a0cc12, 0, $a127c9f4d540a6fd, true);
			$f5ca10af8609bb6f = array_slice($b84a7819a4a0cc12, $a127c9f4d540a6fd, $a127c9f4d540a6fd, true);

			if (0 >= $a127c9f4d540a6fd) {
			} else {
				echo '                    <div class="row" style="overflow-x:auto;">' . "\r\n" . '                        <div class="col-md-6">' . "\r\n" . '                            <div class="card-box">' . "\r\n" . '                                <table class="table table-borderless mb-0">' . "\r\n" . '                                    <thead class="thead-light">' . "\r\n" . '                                        <tr>' . "\r\n" . '                                            <th class="text-center">Stream ID</th>' . "\r\n" . '                                            <th>Stream Name</th>' . "\r\n" . '                                            <th class="text-center">Bitrate</th>' . "\r\n" . '                                            <th class="text-center">Mount Usage</th>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                    </thead>' . "\r\n" . '                                    <tbody>' . "\r\n" . '                                        ';

				foreach ($Aed08c2fd5911dba as $F26087d31c2bbe4d => $a77daf9df0093a16) {
					echo '                                        <tr>' . "\r\n" . '                                            <td class="text-center"><a class="text-dark" href="stream_view?id=';
					echo $F26087d31c2bbe4d;
					echo '">';
					echo $F26087d31c2bbe4d;
					echo '</a></td>' . "\r\n" . '                                            <td><a class="text-dark" href="stream_view?id=';
					echo $F26087d31c2bbe4d;
					echo '">';
					echo $c92aec5c90838930[$F26087d31c2bbe4d]['stream_display_name'];
					echo '</a></td>' . "\r\n" . '                                            <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">';
					echo number_format($c92aec5c90838930[$F26087d31c2bbe4d]['bitrate'], 0);
					echo ' Kbps</button></td>' . "\r\n" . '                                            <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">';
					echo number_format($a77daf9df0093a16 / 1024 / 1024, 0);
					echo ' MB</button></td>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                        ';
				}
				echo '                                    </tbody>' . "\r\n" . '                                </table>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        <div class="col-md-6">' . "\r\n" . '                            <div class="card-box">' . "\r\n" . '                                <table class="table table-borderless mb-0">' . "\r\n" . '                                    <thead class="thead-light">' . "\r\n" . '                                        <tr>' . "\r\n" . '                                            <th class="text-center">Stream ID</th>' . "\r\n" . '                                            <th>Stream Name</th>' . "\r\n" . '                                            <th class="text-center">Bitrate</th>' . "\r\n" . '                                            <th class="text-center">Mount Usage</th>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                    </thead>' . "\r\n" . '                                    <tbody>' . "\r\n" . '                                        ';

				foreach ($f5ca10af8609bb6f as $F26087d31c2bbe4d => $a77daf9df0093a16) {
					echo '                                        <tr>' . "\r\n" . '                                            <td class="text-center"><a class="text-dark" href="stream_view?id=';
					echo $F26087d31c2bbe4d;
					echo '">';
					echo $F26087d31c2bbe4d;
					echo '</a></td>' . "\r\n" . '                                            <td><a class="text-dark" href="stream_view?id=';
					echo $F26087d31c2bbe4d;
					echo '">';
					echo $c92aec5c90838930[$F26087d31c2bbe4d]['stream_display_name'];
					echo '</a></td>' . "\r\n" . '                                            <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">';
					echo number_format($c92aec5c90838930[$F26087d31c2bbe4d]['bitrate'], 0);
					echo ' Kbps</button></td>' . "\r\n" . '                                            <td class="text-center"><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">';
					echo number_format($a77daf9df0093a16 / 1024 / 1024, 0);
					echo ' MB</button></td>' . "\r\n" . '                                        </tr>' . "\r\n" . '                                        ';
				}
				echo '                                    </tbody>' . "\r\n" . '                                </table>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                    </div>' . "\r\n" . '                ';
			}
		}

		echo "\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<form id="line_activity_search">' . "\r\n\t\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-6">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="live_search" value="" placeholder="';
		echo $_['search_processes'];
		echo '...">' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<label class="col-md-1 col-form-label text-center" for="live_filter">';
		echo $_['server'];
		echo '</label>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<select id="live_filter" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t\t";

		foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
			echo "\t\t\t\t\t\t\t\t\t\t" . '<option value="';
			echo $e81220b4451f37c9['id'];
			echo '"';

			if (XUI::$rRequest['server'] != $e81220b4451f37c9['id']) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo $e81220b4451f37c9['server_name'];
			echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<label class="col-md-1 col-form-label text-center" for="live_show_entries">';
		echo $_['show'];
		echo '</label>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-1">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<select id="live_show_entries" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t\t";

		foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
			echo "\t\t\t\t\t\t\t\t\t\t" . '<option';

			if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
			} else {
				echo ' selected';
			}

			echo ' value="';
			echo $C9e42207e95f03ed;
			echo '">';
			echo $C9e42207e95f03ed;
			echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</form>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
		echo $_['pid'];
		echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
		echo $_['type'];
		echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
		echo $_['process'];
		echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
		echo $_['cpu_%'];
		echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
		echo $_['mem_mb'];
		echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Runtime</th>' . "\r\n" . '                                    <th>CPU Time</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>';
		echo $_['actions'];
		echo '</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t";

		foreach ($D238fb37ea40fafb as $Df1e7eea7d843145) {
			$A134afcd6d59abf6 = array('proxy' => 'Live Proxy', 'llod' => 'LLOD', 'loopback' => 'Loopback', 'queue' => 'VOD Queue', 'ondemand' => 'On-Demand Instant Off', 'plex_item' => 'Plex Item Scan', 'watch_item' => 'Watch Item Scan', 'cache_handler' => 'Cache Handler', 'certbot' => 'Certbot SSL Automation', 'closed_cons' => 'Closed Connection Handler', 'signals' => 'Signal Handler', 'watchdog' => 'Server Watchdog');
			$d1ed31fd52b1ed35 = array('plex' => 'Plex Sync', 'cache_engine' => 'Cache Generator', 'activity' => 'Activity Cron', 'backups' => 'Backup Cron', 'cache' => 'Cache Cron', 'epg' => 'EPG Cron', 'lines_logs' => 'Line Logging Cron', 'root_signals' => 'Root Signal Cron', 'series' => 'Series Cron', 'servers' => 'Servers Cron', 'stats' => 'Stats Cron', 'streams' => 'Streams Cron', 'streams_logs' => 'Stream Logging Cron', 'tmdb' => 'TMDb Refresh Cron', 'tmp' => 'Temp Cron', 'users' => 'Users Cron', 'vod' => 'VOD Cron', 'watch' => 'Watch Folder Cron');

			if (isset($A134afcd6d59abf6[basename(explode(' ', trim(explode('#', $Df1e7eea7d843145['command'])[0]))[0], '.php')])) {
				$Df1e7eea7d843145['command'] = $A134afcd6d59abf6[basename(explode(' ', trim(explode('#', $Df1e7eea7d843145['command'])[0]))[0], '.php')];
				$E379394c7b1a273f = 'XUI CLI';
			} else {
				if (isset($A134afcd6d59abf6[basename(trim(explode('#', $Df1e7eea7d843145['command'])[0]), '.php')])) {
					$Df1e7eea7d843145['command'] = $A134afcd6d59abf6[basename(trim(explode('#', $Df1e7eea7d843145['command'])[0]), '.php')];
					$E379394c7b1a273f = 'XUI CLI';
				} else {
					if (isset($d1ed31fd52b1ed35[basename(explode(' ', trim(explode('#', $Df1e7eea7d843145['command'])[0]))[0], '.php')])) {
						$Df1e7eea7d843145['command'] = $d1ed31fd52b1ed35[basename(explode(' ', trim(explode('#', $Df1e7eea7d843145['command'])[0]))[0], '.php')];
						$E379394c7b1a273f = 'XUI Cron';
					} else {
						if (stripos($Df1e7eea7d843145['command'], 'nginx: master process') !== false) {
							$Df1e7eea7d843145['command'] = 'NGINX Master Process';
							$E379394c7b1a273f = 'NGINX Master';
						} else {
							if (stripos($Df1e7eea7d843145['command'], 'nginx: worker process') !== false) {
								$Df1e7eea7d843145['command'] = 'NGINX Worker Process';
								$E379394c7b1a273f = 'NGINX Pool';
							} else {
								if (stripos($Df1e7eea7d843145['command'], 'php-fpm: master process') !== false) {
									$Df1e7eea7d843145['command'] = 'PHP Master Process';
									$E379394c7b1a273f = 'PHP Master';
								} else {
									if (stripos($Df1e7eea7d843145['command'], 'redis-server') !== false) {
										$Df1e7eea7d843145['command'] = 'Redis Server';
										$E379394c7b1a273f = 'Redis';
									} else {
										$Df1e7eea7d843145['command'] = 'Command: ' . $Df1e7eea7d843145['command'];
										$E379394c7b1a273f = array('pid' => $_['main'] . ' - ', 'vframes' => $_['thumbnail'] . ' - ', 'monitor_pid' => $_['monitor'] . ' - ', 'delay_pid' => $_['delayed'] . ' - ', 'activity' => $_['line_activity'] . ' - ', 'timeshift' => $_['timeshift'] . ' - ', null => '')[$A2b85ede89f9df0c[$Df1e7eea7d843145['pid']]['pid_type']] . array(1 => $_['stream'], 2 => $_['movie'], 3 => $_['created_channel'], 4 => $_['radio'], 5 => $_['episode'], null => $_['system'])[$A2b85ede89f9df0c[$Df1e7eea7d843145['pid']]['type']];
									}
								}
							}
						}
					}
				}
			}

			$fad73125a2cca3ed = $Df1e7eea7d843145['etime'];

			if (86400 <= $fad73125a2cca3ed) {
				$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
			} else {
				$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
			}

			$c9b956e155323420 = $Df1e7eea7d843145['time'];

			if (86400 <= $c9b956e155323420) {
				$c9b956e155323420 = sprintf('%02dd %02dh %02dm', $c9b956e155323420 / 86400, ($c9b956e155323420 / 3600) % 24, ($c9b956e155323420 / 60) % 60);
			} else {
				$c9b956e155323420 = sprintf('%02dh %02dm %02ds', $c9b956e155323420 / 3600, ($c9b956e155323420 / 60) % 60, $c9b956e155323420 % 60);
			}

			echo "\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>';
			echo $Df1e7eea7d843145['pid'];
			echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>';
			echo $E379394c7b1a273f;
			echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . "\r\n" . '                                        ';

			if (isset($A2b85ede89f9df0c[$Df1e7eea7d843145['pid']])) {
				echo $A2b85ede89f9df0c[$Df1e7eea7d843145['pid']]['title'];
			} else {
				echo $Df1e7eea7d843145['command'];
			}

			echo '                                    </td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td><button type="button" class="btn btn-light btn-xs waves-effect waves-light">';
			echo number_format($Df1e7eea7d843145['cpu'], 2);
			echo '%</button><br/><small>avg: ';
			echo number_format($Df1e7eea7d843145['load_average'], 2);
			echo '</small>%</td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td><button type="button" class="btn btn-light btn-xs waves-effect waves-light">';
			echo number_format($Df1e7eea7d843145['rss'] / 1024, 0);
			echo '</button></td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed">';
			echo $fad73125a2cca3ed;
			echo '</button></td>' . "\r\n" . '                                    <td><button type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed">';
			echo $c9b956e155323420;
			echo '</button></td>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";

			if (isset($A2b85ede89f9df0c[$Df1e7eea7d843145['pid']])) {
				echo "\t\t\t\t\t\t\t\t\t\t\t" . '<a href="';
				echo array(1 => 'stream_view', 2 => 'stream_view', 3 => 'stream_view', 4 => 'stream_view', 5 => 'stream_view')[$A2b85ede89f9df0c[$Df1e7eea7d843145['pid']]['type']] . '?id=' . $A2b85ede89f9df0c[$Df1e7eea7d843145['pid']]['id'];
				echo '"><button data-toggle="tooltip" data-placement="top" title="" data-original-title="';
				echo $_['view'];
				echo '" type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-eye"></i></button></a>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
			} else {
				echo "\t\t\t\t\t\t\t\t\t\t\t" . '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-eye"></i></button>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t";
			}

			echo "\t\t\t\t\t\t\t\t\t\t\t" . '<button data-toggle="tooltip" data-placement="top" title="" data-original-title="';
			echo $_['kill_process_info'];
			echo '" type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="kill(';
			echo intval(XUI::$rRequest['server']);
			echo ', ';
			echo $Df1e7eea7d843145['pid'];
			echo ');"><i class="mdi mdi-close"></i></button>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</td>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
		include 'footer.php';
	} else {
		c00aB7dA6173ebB1(XUI::$rRequest['server']);
		header('Location: ./process_monitor?server=' . XUI::$rRequest['server']);

		exit();
	}
} else {
	b8E493b5dbDB3D7A(XUI::$rRequest['server']);
	header('Location: ./process_monitor?server=' . XUI::$rRequest['server']);

	exit();
}
