<?php

include 'session.php';
include 'functions.php';

if (B1882df698B44754()) {
} else {
	B46F5dD76F3C7421();
}

$A5dcdeb6ecbbf6bd = Cbe87E2a9a996111('series');
$bcf587bb39f95fd5 = 'TV Series';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">TV Series</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS) {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Series has been added / modified.' . "\n\t\t\t\t" . '</div>' . "\n" . '                ';
} else {
	if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS_MULTI)) {
	} else {
		echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . "Series are being imported in the background, series that can't be matched will not be added. Check Watch Folder logs for information." . "\n\t\t\t\t" . '</div>' . "\n" . '                ';
	}
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\n" . '                            <div class="col-md-6">' . "\n" . '                                <input type="text" class="form-control" id="series_search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="Search Series...">' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-3">' . "\n" . '                                <select id="series_category_id" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value="">All Categories</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == -1)) {
} else {
	echo ' selected';
}

echo '>No TMDb Match</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == -2)) {
} else {
	echo ' selected';
}

echo '>No Categories</option>' . "\n" . '                                    ';

foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
	echo '                                    <option value="';
	echo $A1925ae53e9307eb['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['category']) && XUI::$rRequest['category'] == $A1925ae53e9307eb['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A1925ae53e9307eb['category_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <label class="col-md-1 col-form-label text-center" for="series_show_entries">Show</label>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="series_show_entries" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo '                                    <option';

	if (isset(XUI::$rRequest['entries'])) {
		if (XUI::$rRequest['entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	} else {
		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n\t\t\t\t\t\t" . '<table id="datatable-streampage" class="table table-striped table-borderless dt-responsive nowrap font-normal">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\n" . '                                    <th class="text-center">Image</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Name</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Category</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Seasons</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Episodes</th>' . "\n" . '                                    <th class="text-center">TMDb</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">First Aired</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Last Updated</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
