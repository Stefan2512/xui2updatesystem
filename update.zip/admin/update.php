<?php
// update_check.php - noul server de update (plasat pe server propriu sau GitHub Pages cu proxy PHP)

header('Content-Type: application/json');

// Config de bază
$latestVersion = '2.0.1';
$githubRepo = 'https://github.com/USERNAME/REPO/releases/latest/download/update.zip';

// Răspuns pentru clientul XUI
$response = [
    'status' => 'success',
    'version' => $latestVersion,
    'message' => 'New version available: ' . $latestVersion,
    'download_url' => $githubRepo
];

echo json_encode($response);
