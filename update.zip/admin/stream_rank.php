<?php

include 'session.php';
include 'functions.php';

if (B1882DF698B44754()) {
} else {
	b46f5dD76F3C7421();
}

$e177e626dc505af6 = array(1 => 'Live Stream', 2 => 'Movie', 3 => 'Created Channel', 4 => 'Radio Station', 5 => 'Episode');
$b2dbef523fae7e66 = (XUI::$rRequest['period'] ?: 'all');
$Fee0d5a474c96306->query('SELECT `streams_stats`.*, `streams`.`stream_display_name` FROM `streams_stats` INNER JOIN `streams` ON `streams`.`id` = `streams_stats`.`stream_id` WHERE `streams_stats`.`type` = ? AND `streams`.`type` IN (1,3) GROUP BY `stream_id` ORDER BY `streams_stats`.`rank` ASC LIMIT 500;', $b2dbef523fae7e66);
$b3439582205053ea = $Fee0d5a474c96306->get_rows();
$bcf587bb39f95fd5 = 'Stream Rank';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n" . '                    <div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">Stream Rank</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-7">' . "\r\n\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="log_search" value="" placeholder="Search Logs...">' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t" . '<select id="period" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value="today"';

if ($b2dbef523fae7e66 != 'today') {
} else {
	echo ' selected';
}

echo '>Today</option>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<option value="week"';

if ($b2dbef523fae7e66 != 'week') {
} else {
	echo ' selected';
}

echo '>This Week</option>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<option value="month"';

if ($b2dbef523fae7e66 != 'month') {
} else {
	echo ' selected';
}

echo '>This Month</option>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<option value="all"';

if ($b2dbef523fae7e66 != 'all') {
} else {
	echo ' selected';
}

echo '>All Time</option>' . "\r\n\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t" . '<select id="show_entries" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Rank #</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Stream Name</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Time Watched</th>' . "\r\n" . '                                    <th class="text-center">Total Connections</th>' . "\r\n" . '                                    <th class="text-center">Total Users</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n" . '                                ';
$Ea22c4a9ab5b2176 = 0;

foreach ($b3439582205053ea as $C740da31596f24ef) {
	$Ea22c4a9ab5b2176++;
	$C4af185e24cf9086 = $C740da31596f24ef['time'];

	if (86400 <= $C4af185e24cf9086) {
		$C4af185e24cf9086 = sprintf('%02dd %02dh %02dm', $C4af185e24cf9086 / 86400, ($C4af185e24cf9086 / 3600) % 24, ($C4af185e24cf9086 / 60) % 60);
	} else {
		$C4af185e24cf9086 = sprintf('%02dh %02dm %02ds', $C4af185e24cf9086 / 3600, ($C4af185e24cf9086 / 60) % 60, $C4af185e24cf9086 % 60);
	}

	echo '                                    <tr>' . "\r\n" . '                                        <td class="text-center">';
	echo $Ea22c4a9ab5b2176;
	echo '</td>' . "\r\n" . '                                        <td><a href="stream_view?id=';
	echo intval($C740da31596f24ef['id']);
	echo '">';
	echo $C740da31596f24ef['stream_display_name'];
	echo '</a></td>' . "\r\n" . "                                        <td class=\"text-center\"><button type='button' class='btn btn-light btn-xs waves-effect waves-light btn-fixed'>";
	echo $C4af185e24cf9086;
	echo '</button></td>' . "\r\n" . "                                        <td class=\"text-center\"><button type='button' class='btn btn-light btn-xs waves-effect waves-light btn-fixed'>";
	echo number_format($C740da31596f24ef['connections'], 0);
	echo '</button></td>' . "\r\n" . "                                        <td class=\"text-center\"><button type='button' class='btn btn-light btn-xs waves-effect waves-light btn-fixed'>";
	echo number_format($C740da31596f24ef['users'], 0);
	echo '</button></td>' . "\r\n" . '                                    </tr>' . "\r\n" . '                                ';
}
echo '                            </tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
