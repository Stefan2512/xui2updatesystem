<?php

include 'session.php';
include 'functions.php';

if (B1882Df698b44754()) {
} else {
	B46f5DD76f3c7421();
}

if (isset(XUI::$rRequest['type'])) {
	$E379394c7b1a273f = intval(XUI::$rRequest['type']);
} else {
	if (isset(XUI::$rRequest['type'])) {
		$E379394c7b1a273f = intval(XUI::$rRequest['type']);
	} else {
		$E379394c7b1a273f = 1;
	}
}

if (isset(XUI::$rRequest['post_data'])) {
	$C4033c5a05611ed1 = json_decode(base64_decode(XUI::$rRequest['post_data']), true);
	$C4033c5a05611ed1['review'] = array();
	$C4033c5a05611ed1['notes'] = '';
	$C4033c5a05611ed1['custom_sid'] = $C4033c5a05611ed1['notes'];
	$A38b42a281e3c3cf = array();

	foreach (CbE87E2a9A996111(array(1 => 'live', 2 => 'movie')[intval($E379394c7b1a273f)]) as $A1925ae53e9307eb) {
		$A38b42a281e3c3cf[] = $A1925ae53e9307eb['id'];
	}
	$C8413f429e2be20f = array();

	foreach (XUI::$rRequest['category_selection'] as $A1925ae53e9307eb) {
		if (in_array($A1925ae53e9307eb, $A38b42a281e3c3cf) || is_numeric($A1925ae53e9307eb)) {
		} else {
			$a85e1b7d42c346a0 = API::dc7b22871aC995e5(array('category_type' => array(1 => 'live', 2 => 'movie')[intval($E379394c7b1a273f)], 'category_name' => $A1925ae53e9307eb));
			$C8413f429e2be20f[$A1925ae53e9307eb] = $a85e1b7d42c346a0['data']['insert_id'];
		}
	}

	foreach (XUI::$rRequest as $D3fa098be3f297cd => $b6842cb20051e925) {
		if (substr($D3fa098be3f297cd, 0, 7) != 'import_') {
		} else {
			$C3c8913edb801c35 = intval(explode('import_', $D3fa098be3f297cd)[1]);

			if (!XUI::$rRequest['import_' . $C3c8913edb801c35]) {
			} else {
				$A5dcdeb6ecbbf6bd = array();

				foreach (json_decode(XUI::$rRequest['category_id_' . $C3c8913edb801c35], true) as $A1925ae53e9307eb) {
					if (!is_numeric($A1925ae53e9307eb) && isset($C8413f429e2be20f[$A1925ae53e9307eb])) {
						$A5dcdeb6ecbbf6bd[] = intval($C8413f429e2be20f[$A1925ae53e9307eb]);
					} else {
						if (!is_numeric($A1925ae53e9307eb)) {
						} else {
							$A5dcdeb6ecbbf6bd[] = intval($A1925ae53e9307eb);
						}
					}
				}

				if ($E379394c7b1a273f == 1) {
					$C4033c5a05611ed1['review'][] = array('stream_source' => array(XUI::$rRequest['url_' . $C3c8913edb801c35]), 'stream_icon' => XUI::$rRequest['icon_' . $C3c8913edb801c35], 'stream_display_name' => XUI::$rRequest['name_' . $C3c8913edb801c35], 'epg_lang' => null, 'channel_id' => (!empty(XUI::$rRequest['channel_id_' . $C3c8913edb801c35]) ? XUI::$rRequest['channel_id_' . $C3c8913edb801c35] : null), 'epg_api' => (!empty(XUI::$rRequest['epg_type_' . $C3c8913edb801c35]) ? XUI::$rRequest['epg_type_' . $C3c8913edb801c35] : 0), 'epg_id' => (!empty(XUI::$rRequest['epg_id_' . $C3c8913edb801c35]) ? XUI::$rRequest['epg_id_' . $C3c8913edb801c35] : 0), 'bouquets' => json_decode(XUI::$rRequest['bouquets_' . $C3c8913edb801c35], true), 'category_id' => $A5dcdeb6ecbbf6bd);
				} else {
					$C4033c5a05611ed1['review'][] = array('stream_source' => array(XUI::$rRequest['url_' . $C3c8913edb801c35]), 'stream_display_name' => XUI::$rRequest['name_' . $C3c8913edb801c35], 'tmdb_id' => (!empty(XUI::$rRequest['tmdb_id_' . $C3c8913edb801c35]) ? XUI::$rRequest['tmdb_id_' . $C3c8913edb801c35] : null), 'bouquets' => json_decode(XUI::$rRequest['bouquets_' . $C3c8913edb801c35], true), 'category_id' => $A5dcdeb6ecbbf6bd);
				}
			}
		}
	}

	if ($E379394c7b1a273f == 1) {
		$a85e1b7d42c346a0 = API::e0407C2C64B2C037($C4033c5a05611ed1);
		$B4a5f8dc1f8d260c = $a85e1b7d42c346a0['status'];

		if ($B4a5f8dc1f8d260c != STATUS_SUCCESS) {
		} else {
			header('Location: ./streams?status=' . STATUS_SUCCESS);

			exit();
		}
	} else {
		$a85e1b7d42c346a0 = API::D4E96aC013E38c70($C4033c5a05611ed1);
		$B4a5f8dc1f8d260c = $a85e1b7d42c346a0['status'];

		if ($B4a5f8dc1f8d260c != STATUS_SUCCESS) {
		} else {
			header('Location: ./movies?status=' . STATUS_SUCCESS);

			exit();
		}
	}
} else {
	if (!isset($_FILES['m3u_file'])) {
	} else {
		unset(XUI::$rRequest['submit_stream']);
		$C4033c5a05611ed1 = base64_encode(json_encode(XUI::$rRequest));
		$A5dcdeb6ecbbf6bd = cBE87E2A9a996111(array(1 => 'live', 2 => 'movie')[intval($E379394c7b1a273f)]);
		$cb498e4dcaac05cc = d7a15E0C2d9beCE1();
		$bbfc9bd8432031f5 = array();
		$f69f03301cf5dc4e = array();
		$Fee0d5a474c96306->query('SELECT `stream_source` FROM `streams` WHERE `type` = ?;', $E379394c7b1a273f);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			foreach (json_decode($C740da31596f24ef['stream_source'], true) as $C700a2b357e5ed65) {
				if (in_array($C700a2b357e5ed65, $bbfc9bd8432031f5)) {
				} else {
					$bbfc9bd8432031f5[] = str_replace('https://', 'http://', $C700a2b357e5ed65);
				}
			}
		}
		$D2165010a62b36e4 = array();

		if (empty($_FILES['m3u_file']['tmp_name']) || !in_array(strtolower(pathinfo($_FILES['m3u_file']['name'], PATHINFO_EXTENSION)), array('m3u', 'm3u8'))) {
			$B4a5f8dc1f8d260c = STATUS_INVALID_FILE;
		} else {
			$D19861e3f008e509 = array();
			$c15d5b523e931f51 = bEA20353771F9Ba3($_FILES['m3u_file']['tmp_name']);

			foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
				list($b82f49489b692793) = $B59c127fecf35c15->getExtTags();

				if (!$b82f49489b692793) {
				} else {
					$C700a2b357e5ed65 = $B59c127fecf35c15->getPath();

					if ($E379394c7b1a273f == 1) {
						$a0019977d8dc5d09 = array('ts', 'm3u8', 'm3u', 'mpd', 'ism', '');
					} else {
						$a0019977d8dc5d09 = array('mp4', 'mkv', 'mov', 'avi', 'mpg', 'mpeg', 'flv', 'wmv', 'm4v');
					}

					if (!in_array(strtolower(pathinfo(explode('?', $C700a2b357e5ed65)[0])['extension']), $a0019977d8dc5d09)) {
					} else {
						$E10ef6b1aed21af8 = in_array(str_replace('https://', 'http://', $C700a2b357e5ed65), $bbfc9bd8432031f5);

						if ($E10ef6b1aed21af8 && !XUI::$rRequest['duplicates']) {
						} else {
							if (count($D19861e3f008e509) < 500) {
								if ($E379394c7b1a273f == 1) {
									$D19861e3f008e509[] = array('url' => $C700a2b357e5ed65, 'logo' => ($b82f49489b692793->getAttribute('tvg-logo') ?: ''), 'tvg_id' => ($b82f49489b692793->getAttribute('tvg-id') ?: ''), 'title' => ($b82f49489b692793->getTitle() ?: ''), 'category' => ($b82f49489b692793->getAttribute('group-title') ?: ''), 'exists' => $E10ef6b1aed21af8);
								} else {
									$D19861e3f008e509[] = array('url' => $C700a2b357e5ed65, 'title' => ($b82f49489b692793->getTitle() ?: ''), 'category' => ($b82f49489b692793->getAttribute('group-title') ?: ''), 'exists' => $E10ef6b1aed21af8);
								}
							} else {
								$B4a5f8dc1f8d260c = STATUS_TOO_MANY_RESULTS;

								break;
							}
						}
					}
				}
			}

			if (count($D19861e3f008e509) != 0) {
			} else {
				$B4a5f8dc1f8d260c = STATUS_NO_SOURCES;
				$D19861e3f008e509 = null;
			}
		}
	}
}

if (isset($D19861e3f008e509) && $D19861e3f008e509) {
} else {
	$e80d13748eba016a = array(array('id' => 'source', 'parent' => '#', 'text' => "<strong class='btn btn-success waves-effect waves-light btn-xs'>Live Stream</strong>", 'icon' => 'mdi mdi-play', 'state' => array('opened' => true)), array('id' => 'offline', 'parent' => '#', 'text' => "<strong class='btn btn-secondary waves-effect waves-light btn-xs'>Offline</strong>", 'icon' => 'mdi mdi-stop', 'state' => array('opened' => true)));

	foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
		$e80d13748eba016a[] = array('id' => $e81220b4451f37c9['id'], 'parent' => 'offline', 'text' => $e81220b4451f37c9['server_name'], 'icon' => 'mdi mdi-server-network', 'state' => array('opened' => true));
	}
	$f86c7f12032c787a = CCe66F113D4F4390();
	$fec9c81ecb7b04b5 = eFe0Ce577FB769BC();
}

$dfb26bd41092c868 = $a6642b161cc3f82b = array();
$bcf587bb39f95fd5 = 'Review';
include 'header.php';
echo '<div class="wrapper';

if (isset($D19861e3f008e509)) {
} else {
	echo ' boxed-layout-ext';
}

echo '"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n" . '        <form';

if (isset($D19861e3f008e509)) {
} else {
	echo ' enctype="multipart/form-data"';
}

echo ' action="./review?type=';
echo intval($E379394c7b1a273f);
echo '" method="POST" id="stream_form" data-parsley-validate="">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n" . '                    ';

if (!isset($D19861e3f008e509)) {
} else {
	echo '                    <div class="page-title-right">' . "\n\t\t\t\t\t\t" . '<ol class="breadcrumb m-0">' . "\n\t\t\t\t\t\t\t" . '<li>' . "\n\t\t\t\t\t\t\t\t" . '<input name="submit_stream" type="submit" class="btn btn-primary" value="Import Selected" />' . "\n\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t" . '</ol>' . "\n\t\t\t\t\t" . '</div>' . "\n" . '                    ';
}

echo "\t\t\t\t\t" . '<h4 class="page-title">';
echo array(1 => 'Stream', 2 => 'Movie')[$E379394c7b1a273f];
echo ' Review</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n" . '        ';

if (!isset($D19861e3f008e509)) {
} else {
	echo '        <div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n" . '                        <div class="form-group row mb-4">' . "\n" . '                            <div class="col-md-12">' . "\n" . '                                <h4 class="header-title">Category Creation</h4>' . "\n" . '                                <p class="sub-header">' . "\n" . '                                    You can create categories by typing them in the below box, this will allow you to quickly add categories to the imported results.' . "\n" . '                                </p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-12">' . "\n" . '                                <select name="category_selection[]" id="category_selection" class="form-control col-md-12 select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n" . '                                    ';

	foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
		echo '                                    <option selected value="';
		echo $A1925ae53e9307eb['id'];
		echo '">';
		echo $A1925ae53e9307eb['category_name'];
		echo '</option>' . "\n" . '                                    ';
	}
	echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                        ';

	if ($E379394c7b1a273f == 1) {
		echo '                        <div class="form-group row">' . "\n" . '                            <div class="col-md-12">' . "\n" . '                                <h4 class="header-title">Stream Import</h4>' . "\n" . '                                <p class="sub-header" style="margin-bottom: 0;">' . "\n" . '                                    To import a stream, ensure the checkbox next to it is selected. You will need to go to each page for that page of streams to be included in the import.' . "\n" . '                                </p>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                        ';
	} else {
		echo '                        <div class="form-group row">' . "\n" . '                            <div class="col-md-12">' . "\n" . '                                <h4 class="header-title">Movie Import</h4>' . "\n" . '                                <p class="sub-header" style="margin-bottom: 0;">' . "\n" . '                                    To import a movie, ensure the checkbox next to it is selected. You will need to go to each page for that page of movies to be included in the import.' . "\n" . '                                </p>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                        ';
	}

	echo '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '        </div>' . "\n" . '        ';
}

echo "\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_INVALID_FILE) {
	echo '                <div class="alert alert-danger alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    Invalid playlist selected, please ensure the playlist is in M3U format.' . "\n" . '                </div>' . "\n" . '                ';
} else {
	if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_TOO_MANY_RESULTS) {
		echo '                <div class="alert alert-danger alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    The playlist you selected has more than 500 results, the review page will not show all results.' . "\n" . '                </div>' . "\n" . '                ';
	} else {
		if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_NO_SOURCES) {
			echo '                <div class="alert alert-danger alert-dismissible fade show" role="alert">' . "\n" . '                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n" . '                        <span aria-hidden="true">&times;</span>' . "\n" . '                    </button>' . "\n" . '                    No results were found in the playlist.' . "\n" . '                </div>' . "\n" . '                ';
		} else {
			if ($D19861e3f008e509) {
			} else {
				echo '                <div class="alert alert-info" role="alert">' . "\n" . '                    The Review page is for playlists of less than 500 items, you should use the normal M3U Import function for larger playlists or reduce the playlist. The review page will cut off at 500 results and not process any more if you upload a larger playlist anyway.' . "\n" . '                    ';

				if ($E379394c7b1a273f != 0) {
				} else {
					echo '                    <br/><br/>If you have an XMLTV EPG file for this playlist, you should add it first and rescan your EPG so channels are automatically matched up against the EPG. You can however do this later through the EPG review tool.' . "\n" . '                    ';
				}

				echo '                </div>' . "\n" . '                ';
			}
		}
	}
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n" . '                        ';

if (isset($D19861e3f008e509)) {
	echo "                        <input type=\"hidden\" name=\"post_data\" value='";
	echo $C4033c5a05611ed1;
	echo "' />" . "\n" . "                        <input type=\"hidden\" name=\"type\" value='";
	echo $E379394c7b1a273f;
	echo "' />" . "\n" . '                        ';
	$Ea22c4a9ab5b2176 = 0;

	foreach ($D19861e3f008e509 as $f523e362fb81d6c8) {
		$Ea22c4a9ab5b2176++;
		echo '<input type="hidden" name="name_' . $Ea22c4a9ab5b2176 . '" id="name_i_' . $Ea22c4a9ab5b2176 . '" value="" />';
		echo '<input type="hidden" name="category_id_' . $Ea22c4a9ab5b2176 . '" id="category_id_i_' . $Ea22c4a9ab5b2176 . '" value="" />';
		echo '<input type="hidden" name="bouquets_' . $Ea22c4a9ab5b2176 . '" id="bouquets_i_' . $Ea22c4a9ab5b2176 . '" value="" />';
		echo '<input type="hidden" name="icon_' . $Ea22c4a9ab5b2176 . '" id="icon_' . $Ea22c4a9ab5b2176 . '" value="' . htmlspecialchars($f523e362fb81d6c8['logo']) . '" />';
		echo '<input type="hidden" name="url_' . $Ea22c4a9ab5b2176 . '" value="' . htmlspecialchars($f523e362fb81d6c8['url']) . '" />';
		echo '<input type="hidden" name="import_' . $Ea22c4a9ab5b2176 . '" id="import_' . $Ea22c4a9ab5b2176 . '" value="0" />';

		if ($E379394c7b1a273f == 1) {
			echo '<input type="hidden" id="tvg_id_' . $Ea22c4a9ab5b2176 . '" value="' . htmlspecialchars($f523e362fb81d6c8['tvg_id']) . '" />';
			echo '<input type="hidden" name="epg_type_' . $Ea22c4a9ab5b2176 . '" id="epg_type_' . $Ea22c4a9ab5b2176 . '" value="0" />';
			echo '<input type="hidden" name="epg_id_' . $Ea22c4a9ab5b2176 . '" id="epg_id_' . $Ea22c4a9ab5b2176 . '" value="0" />';
			echo '<input type="hidden" name="channel_id_' . $Ea22c4a9ab5b2176 . '" id="channel_id_' . $Ea22c4a9ab5b2176 . '" value="0" />';
		} else {
			echo '<input type="hidden" name="tmdb_id_' . $Ea22c4a9ab5b2176 . '" id="tmdb_id_' . $Ea22c4a9ab5b2176 . '" value="" />';
		}
	}
	echo '                        <div class="row">' . "\n" . '                            <div class="col-12">' . "\n" . '                                <table id="datatable" class="table table-striped table-borderless dt-responsive nowrap" data-count="';
	echo count($D19861e3f008e509);
	echo '">' . "\n" . '                                    <thead>' . "\n" . '                                        <tr>' . "\n" . '                                            <th class="text-center">Add</th>' . "\n" . '                                            ';

	if ($E379394c7b1a273f == 1) {
		echo '                                            <th class="text-center">Icon</th>' . "\n" . '                                            <th>Stream Name</th>' . "\n" . '                                            ';
	} else {
		echo '                                            <th class="text-center">Image</th>' . "\n" . '                                            <th>Movie Name</th>' . "\n" . '                                            ';
	}

	echo '                                            <th>Category</th>' . "\n" . '                                            <th>Bouquets</th>' . "\n" . '                                            ';

	if ($E379394c7b1a273f == 1) {
		echo '                                            <th>EPG Search</th>' . "\n" . '                                            <th class="text-center">Language</th>' . "\n" . '                                            ';
	} else {
		echo '                                            <th>TMDb Results</th>' . "\n" . '                                            ';
	}

	echo '                                            <th></th>' . "\n" . '                                        </tr>' . "\n" . '                                    </thead>' . "\n" . '                                    <tbody>' . "\n" . '                                        ';
	$Ea22c4a9ab5b2176 = 0;

	foreach ($D19861e3f008e509 as $f523e362fb81d6c8) {
		$Ea22c4a9ab5b2176++;
		$D307572f7986a746 = null;
		$b792983f62587674 = 0;

		foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
			similar_text($A1925ae53e9307eb['category_name'], $f523e362fb81d6c8['category'], $Ee06f57eb50b4b36);

			if (!($b792983f62587674 < $Ee06f57eb50b4b36 && 70 <= $Ee06f57eb50b4b36)) {
			} else {
				$D307572f7986a746 = $A1925ae53e9307eb;
				$b792983f62587674 = $Ee06f57eb50b4b36;
			}
		}

		if (!$D307572f7986a746) {
		} else {
			$a6642b161cc3f82b[] = $Ea22c4a9ab5b2176;
		}

		if (0 < strlen($f523e362fb81d6c8['logo'])) {
			$dfb26bd41092c868[] = $Ea22c4a9ab5b2176;
			$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='./resize?maxw=512&maxh=512&url=" . $f523e362fb81d6c8['logo'] . "'><img class='lazyload' src='./resize?maxw=96&maxh=32&url=" . $f523e362fb81d6c8['logo'] . "' /></a>";
		} else {
			$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src=''><img class='lazyload' src='' /></a>";
		}

		echo '                                        <tr id="stream_';
		echo $Ea22c4a9ab5b2176;
		echo '" data-id="';
		echo $Ea22c4a9ab5b2176;
		echo '">' . "\n" . '                                            <td class="text-center">' . "\n" . '                                                <div class="checkbox checkbox-single checkbox-offset ';

		if ($f523e362fb81d6c8['exists']) {
			echo 'checkbox-warning';
		} else {
			echo 'checkbox-primary';
		}

		echo '">' . "\n" . '                                                    <input id="check_';
		echo $Ea22c4a9ab5b2176;
		echo '" data-id="';
		echo $Ea22c4a9ab5b2176;
		echo '" type="checkbox" class="activate ';

		if ($f523e362fb81d6c8['exists']) {
		} else {
			echo ' checked';
		}

		echo '">' . "\n" . '                                                    <label></label>' . "\n" . '                                                </div>' . "\n" . '                                            </td>' . "\n" . '                                            <td class="text-center" id="picon_';
		echo $Ea22c4a9ab5b2176;
		echo '">';
		echo $E9c8d08bfb6ef33c;
		echo '</td>' . "\n" . '                                            <td>' . "\n" . '                                                <div class="input-group">' . "\n" . '                                                    <input type="text" class="form-control" id="name_';
		echo $Ea22c4a9ab5b2176;
		echo '" value="';
		echo htmlspecialchars($f523e362fb81d6c8['title']);
		echo '">' . "\n" . '                                                    <div class="input-group-append">' . "\n" . '                                                        <a href="javascript: void(0);" onClick="';

		if ($E379394c7b1a273f == 1) {
			echo 'scanEPG(' . $Ea22c4a9ab5b2176 . ');';
		} else {
			echo 'scanTMDb(' . $Ea22c4a9ab5b2176 . ');';
		}

		echo '" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-magnify text-white"></i></a>' . "\n" . '                                                    </div>' . "\n" . '                                                </div>' . "\n" . '                                            </td>' . "\n" . '                                            <td>' . "\n" . '                                                <select id="category_id_';
		echo $Ea22c4a9ab5b2176;
		echo '" class="form-control select2-multiple category_id" data-id="';
		echo $Ea22c4a9ab5b2176;
		echo '" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n" . '                                                    ';

		foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
			echo '                                                    <option ';

			if (!isset($D307572f7986a746)) {
			} else {
				if (!intval($D307572f7986a746['id'] == $A1925ae53e9307eb['id'])) {
				} else {
					echo 'selected ';
				}
			}

			echo 'value="';
			echo $A1925ae53e9307eb['id'];
			echo '">';
			echo $A1925ae53e9307eb['category_name'];
			echo '</option>' . "\n" . '                                                    ';
		}
		echo '                                                </select>' . "\n" . '                                            </td>' . "\n" . '                                            <td>' . "\n" . '                                                <select id="bouquets_';
		echo $Ea22c4a9ab5b2176;
		echo '" data-id="';
		echo $Ea22c4a9ab5b2176;
		echo '" class="form-control select2-multiple bouquet" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n" . '                                                    ';

		foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
			echo '                                                    <option value="';
			echo $ddf0508b312dbfb8['id'];
			echo '">';
			echo $ddf0508b312dbfb8['bouquet_name'];
			echo '</option>' . "\n" . '                                                    ';
		}
		echo '                                                </select>' . "\n" . '                                            </td>' . "\n" . '                                            ';

		if ($E379394c7b1a273f == 1) {
			echo '                                            <td>' . "\n" . '                                                <select id="epg_api_';
			echo $Ea22c4a9ab5b2176;
			echo '" data-id="';
			echo $Ea22c4a9ab5b2176;
			echo '" class="form-control epg_api" data-toggle="select2"></select>' . "\n" . '                                            </td>' . "\n" . '                                            <td style="width: 80px;">' . "\n" . '                                                <input type="text" class="form-control text-center" id="epg_lang_';
			echo $Ea22c4a9ab5b2176;
			echo '" readonly value=""></input>' . "\n" . '                                            </td>' . "\n" . '                                            <td class="text-center">' . "\n" . '                                                <button onClick="clearEPG(this);" id="clear_epg_';
			echo $Ea22c4a9ab5b2176;
			echo '" data-id="';
			echo $Ea22c4a9ab5b2176;
			echo '" type="button" title="Clear EPG" class="tooltip btn btn-secondary btn-xs waves-effect waves-light"><i class="text-white fas fa-times"></i></button>' . "\n" . '                                                <button onClick="viewEPG(this);" id="view_epg_';
			echo $Ea22c4a9ab5b2176;
			echo '" data-id="';
			echo $Ea22c4a9ab5b2176;
			echo '" type="button" title="View EPG API" class="tooltip btn btn-secondary btn-xs waves-effect waves-light"><i class="text-white far fa-circle"></i></button>' . "\n" . '                                                <a href="javascript: void(0);" title="';
			echo htmlspecialchars($f523e362fb81d6c8['url']);
			echo '" class="tooltip-left btn btn-primary btn-xs waves-effect waves-light"><i class="text-white mdi mdi-link"></i></a>' . "\n" . '                                            </td>' . "\n" . '                                            ';
		} else {
			echo '                                            <td>' . "\n" . '                                                <select id="tmdb_search_';
			echo $Ea22c4a9ab5b2176;
			echo '" data-id="';
			echo $Ea22c4a9ab5b2176;
			echo '" class="form-control tmdb_search" data-toggle="select2"></select>' . "\n" . '                                            </td>' . "\n" . '                                            <td class="text-center">' . "\n" . '                                                <a href="javascript: void(0);" title="';
			echo htmlspecialchars($f523e362fb81d6c8['title']);
			echo '<br/>';
			echo htmlspecialchars($f523e362fb81d6c8['url']);
			echo '" class="tooltip-left btn btn-primary btn-xs waves-effect waves-light"><i class="text-white mdi mdi-information-variant"></i></a>' . "\n" . '                                            </td>' . "\n" . '                                            ';
		}

		echo '                                        </tr>' . "\n" . '                                        ';
	}
	echo '                                    </tbody>' . "\n" . '                                </table>' . "\n" . '                            </div>' . "\n" . '                        </div> ' . "\n" . '                        ';
} else {
	echo '                        <input type="hidden" name="server_tree_data" id="server_tree_data" value="" />' . "\n" . '                        <input type="hidden" name="od_tree_data" id="od_tree_data" value="" />' . "\n" . "                        <input type=\"hidden\" name=\"type\" value='";
	echo $E379394c7b1a273f;
	echo "' />" . "\n" . '                        <div id="basicwizard">' . "\n" . '                            <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n" . '                                <li class="nav-item">' . "\n" . '                                    <a href="#advanced-options" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n" . '                                        <i class="mdi mdi-folder-alert-outline mr-1"></i>' . "\n" . '                                        <span class="d-none d-sm-inline">Options</span>' . "\n" . '                                    </a>' . "\n" . '                                </li>' . "\n" . '                                <li class="nav-item">' . "\n" . '                                    <a href="#load-balancing" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">' . "\n" . '                                        <i class="mdi mdi-server-network mr-1"></i>' . "\n" . '                                        <span class="d-none d-sm-inline">Servers</span>' . "\n" . '                                    </a>' . "\n" . '                                </li>' . "\n" . '                            </ul>' . "\n" . '                            <div class="tab-content b-0 mb-0 pt-0">' . "\n" . '                                <div class="tab-pane" id="advanced-options">' . "\n" . '                                    <div class="row">' . "\n" . '                                        <div class="col-12">' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="duplicates">Show Potential Duplicates <i title="This option will remove all potential duplicate results from the review page, if you do not select this, duplicates will be unchecked by default so you are able to check them to include them anyway." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="duplicates" id="duplicates" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                                <div class="col-md-6">' . "\n" . '                                                    <input type="file" id="m3u_file" name="m3u_file" style="padding-top: 5px;" accept=".m3u, .m3u8">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            ';

	if ($E379394c7b1a273f == 1) {
		echo '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="gen_timestamps">Generate PTS <i title="Allow FFmpeg to generate presentation timestamps for you to achieve better synchronization with the stream codecs. In some streams this can cause de-sync." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="gen_timestamps" id="gen_timestamps" type="checkbox" checked data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-4 col-form-label" for="read_native">Native Frames <i title="You should always read live streams as non-native frames. However if you are streaming static video files, set this to true otherwise the encoding process will fail." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-2">' . "\n" . '                                                    <input name="read_native" id="read_native" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="stream_all">Stream All Codecs <i title="This option will stream all codecs from your stream. Some streams have more than one audio/video/subtitles channels." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="stream_all" id="stream_all" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-4 col-form-label" for="allow_record">Allow Recording</label>' . "\n" . '                                                <div class="col-md-2">' . "\n" . '                                                    <input name="allow_record" id="allow_record" type="checkbox" checked data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="direct_source">Direct Source <i title="Redirect clients to the source directly. Do not use if you want to keep your source secure." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="direct_source" id="direct_source" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-4 col-form-label" for="direct_proxy">Direct Stream <i title="When using direct source, hide the original URL by proxying the live stream through your servers via UDP. MPEG-TS and HLS is supported as an input format, however only MPEG-TS is supported as an output format to clients.<br/><br/>Experimental! This may not work for all streams." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-2">' . "\n" . '                                                    <input name="direct_proxy" id="direct_proxy" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="rtmp_output">Output RTMP <i title="Enable RTMP output for this channel." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="rtmp_output" id="rtmp_output" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-4 col-form-label" for="probesize_ondemand">On Demand Probesize <i title="Adjustable probesize for ondemand streams. Adjust this setting if you experience issues with no audio." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-2">' . "\n" . '                                                    <input type="text" class="form-control" id="probesize_ondemand" name="probesize_ondemand" value="128000">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="transcode_profile_id">Transcoding Profile <i title="Sometimes, in order to make a stream compatible with most devices, it must be transcoded. Please note that the transcode will only be applied to the server(s) that take the stream directly from the source, all other servers attached to the transcoding server will not transcode the stream." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <select name="transcode_profile_id" id="transcode_profile_id" class="form-control" data-toggle="select2">' . "\n" . '                                                        <option selected value="0">Transcoding Disabled</option>' . "\n" . '                                                        ';

		foreach ($fec9c81ecb7b04b5 as $b8a339227222357b) {
			echo '                                                        <option value="';
			echo $b8a339227222357b['profile_id'];
			echo '">';
			echo $b8a339227222357b['profile_name'];
			echo '</option>' . "\n" . '                                                        ';
		}
		echo '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-4 col-form-label" for="delay_minutes">Minute Delay <i title="Delay stream by X minutes. Will not work with on demand streams." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-2">' . "\n" . '                                                    <input type="text" class="form-control" id="delay_minutes" name="delay_minutes" value="">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="user_agent">User Agent</label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <input type="text" class="form-control" id="user_agent" name="user_agent" value="';
		echo htmlspecialchars($f86c7f12032c787a['user_agent']['argument_default_value']);
		echo '">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="http_proxy">HTTP Proxy <i title="Format: ip:port" class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <input type="text" class="form-control" id="http_proxy" name="http_proxy" value="';
		echo htmlspecialchars($f86c7f12032c787a['proxy']['argument_default_value']);
		echo '">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="cookie">Cookie <i title="Format: key=value;" class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <input type="text" class="form-control" id="cookie" name="cookie" value="';
		echo htmlspecialchars($f86c7f12032c787a['cookie']['argument_default_value']);
		echo '">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="headers">Headers <i title="FFmpeg -headers command." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <input type="text" class="form-control" id="headers" name="headers" value="';
		echo htmlspecialchars($f86c7f12032c787a['headers']['argument_default_value']);
		echo '">' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            ';
	} else {
		echo '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="direct_source">';
		echo $_['direct_source'];
		echo ' <i title="';
		echo $_['episode_tooltip_1'];
		echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="direct_source" id="direct_source" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . "                                                <label class=\"col-md-3 col-form-label\" for=\"direct_proxy\">Direct Stream <i title=\"When using direct source, hide the original URL by proxying the movie through your servers. This will consume bandwidth but won't require the movie to be saved to your servers permanently.\" class=\"tooltip text-secondary far fa-circle\"></i></label>" . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="direct_proxy" id="direct_proxy" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="read_native">';
		echo $_['native_frames'];
		echo '</label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="read_native" id="read_native" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-3 col-form-label" for="remove_subtitles">';
		echo $_['remove_existing_subtitles'];
		echo ' <i title="';
		echo $_['episode_tooltip_3'];
		echo '" class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="remove_subtitles" id="remove_subtitles" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="transcode_profile_id">Transcoding Profile <i title="Sometimes, in order to make a stream compatible with most devices, it must be transcoded. Please note that the transcode will only be applied to the server(s) that take the stream directly from the source, all other servers attached to the transcoding server will not transcode the stream." class="tooltip text-secondary far fa-circle"></i></label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <select name="transcode_profile_id" id="transcode_profile_id" class="form-control" data-toggle="select2">' . "\n" . '                                                        <option selected value="0">Transcoding Disabled</option>' . "\n" . '                                                        ';

		foreach ($fec9c81ecb7b04b5 as $b8a339227222357b) {
			echo '                                                        <option value="';
			echo $b8a339227222357b['profile_id'];
			echo '">';
			echo $b8a339227222357b['profile_name'];
			echo '</option>' . "\n" . '                                                        ';
		}
		echo '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="tmdb_language">TMDb Language</label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <select name="tmdb_language" id="tmdb_language" class="form-control" data-toggle="select2">' . "\n" . '                                                        ';

		foreach ($b2894c436f8a0966 as $D3fa098be3f297cd => $rLanguage) {
			echo '                                                        <option';

			if ($D3fa098be3f297cd != $F2d4d8f7981ac574['tmdb_language']) {
			} else {
				echo ' selected';
			}

			echo ' value="';
			echo $D3fa098be3f297cd;
			echo '">';
			echo $rLanguage;
			echo '</option>' . "\n" . '                                                        ';
		}
		echo '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            ';
	}

	echo '                                        </div> ' . "\n" . '                                    </div> ' . "\n" . '                                    <ul class="list-inline wizard mb-0">' . "\n" . '                                        <li class="prevb list-inline-item">' . "\n" . '                                            <a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n" . '                                        </li>' . "\n" . '                                        <li class="nextb list-inline-item float-right">' . "\n" . '                                            <a href="javascript: void(0);" class="btn btn-secondary">Next</a>' . "\n" . '                                        </li>' . "\n" . '                                    </ul>' . "\n" . '                                </div>' . "\n" . '                                <div class="tab-pane" id="load-balancing">' . "\n" . '                                    <div class="row">' . "\n" . '                                        <div class="col-12">' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="servers">Server Tree</label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <div id="server_tree"></div>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            ';

	if ($E379394c7b1a273f != 1) {
	} else {
		echo '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="on_demand">On-Demand Servers</label>' . "\n" . '                                                <div class="col-md-9">' . "\n" . '                                                    <select name="on_demand[]" id="on_demand" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Choose...">' . "\n" . '                                                        ';

		foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
			echo '                                                        <option value="';
			echo $e81220b4451f37c9['id'];
			echo '">';
			echo $e81220b4451f37c9['server_name'];
			echo '</option>' . "\n" . '                                                        ';
		}
		echo '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="tv_archive_server_id">Timeshift Server</label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <select name="tv_archive_server_id" id="tv_archive_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                                        <option value="0">Disabled</option>' . "\n" . '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-3 col-form-label" for="tv_archive_duration">Timeshift Days</label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input type="text" class="form-control" id="tv_archive_duration" name="tv_archive_duration" value="0">' . "\n" . '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="vframes_server_id">Thumbnails</label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <select name="vframes_server_id" id="vframes_server_id" class="form-control" data-toggle="select2">' . "\n" . '                                                        <option value="0">Disabled</option>' . "\n" . '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                                <label class="col-md-3 col-form-label" for="llod">Low Latency On-Demand</label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <select name="llod" id="llod" class="form-control" data-toggle="select2">' . "\n" . '                                                        ';

		foreach (array('Disabled', 'LLOD v2 - FFMPEG', 'LLOD v3 - PHP') as $b6842cb20051e925 => $Fa016cbf0b72bfdd) {
			echo '                                                        <option value="';
			echo $b6842cb20051e925;
			echo '">';
			echo $Fa016cbf0b72bfdd;
			echo '</option>' . "\n" . '                                                        ';
		}
		echo '                                                    </select>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                            ';
	}

	echo '                                            <div class="form-group row mb-4">' . "\n" . '                                                <label class="col-md-3 col-form-label" for="restart_on_edit">';

	if ($E379394c7b1a273f == 1) {
		echo 'Auto-Start Streams';
	} else {
		echo 'Auto-Encode Movies';
	}

	echo '</label>' . "\n" . '                                                <div class="col-md-3">' . "\n" . '                                                    <input name="restart_on_edit" id="restart_on_edit" type="checkbox" data-plugin="switchery" class="js-switch" data-color="#039cfd"/>' . "\n" . '                                                </div>' . "\n" . '                                            </div>' . "\n" . '                                        </div> ' . "\n" . '                                    </div> ' . "\n" . '                                    <ul class="list-inline wizard mb-0">' . "\n" . '                                        <li class="prevb list-inline-item">' . "\n" . '                                            <a href="javascript: void(0);" class="btn btn-secondary">Previous</a>' . "\n" . '                                        </li>' . "\n" . '                                        <li class="nextb list-inline-item float-right">' . "\n" . '                                            <input name="submit_stream" type="submit" class="btn btn-primary" value="Review" />' . "\n" . '                                        </li>' . "\n" . '                                    </ul>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                        ';
}

echo '                    </div> ' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '        </div>' . "\n" . '        </form>' . "\n" . '    </div>' . "\n" . '</div>' . "\n";
include 'footer.php';
