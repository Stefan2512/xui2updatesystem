<?php

include 'session.php';
include 'functions.php';

if (B1882dF698b44754()) {
} else {
	B46F5Dd76f3C7421();
}

$bcf587bb39f95fd5 = 'Restream Detection Logs';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<h4 class="page-title">Restream Detection Logs</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                <div class="alert alert-info" role="alert">' . "\n" . '                    ';

if (XUI::$rSettings['detect_restream_block_user'] && XUI::$rSettings['detect_restream_block_ip']) {
	echo '                    Your service is set up to automatically block the lines and IP addresses of those detected restreaming without permission.' . "\n" . '                    ';
} else {
	if (!XUI::$rSettings['detect_restream_block_user'] && XUI::$rSettings['detect_restream_block_ip']) {
		echo '                    Your service is set up to automatically block the IP addresses of those detected restreaming without permission. Lines will remain active.' . "\n" . '                    ';
	} else {
		if (XUI::$rSettings['detect_restream_block_user'] && !XUI::$rSettings['detect_restream_block_ip']) {
			echo "                    Your service is set up to automatically block the lines of those detected restreaming without permission. IP's will not be automatically blocked." . "\n" . '                    ';
		} else {
			echo "                    Your service is set up to detect restreaming without permission, however it won't automatically block IP addresses or lines." . "\n" . '                    ';
		}
	}
}

echo '                </div>' . "\n\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['id'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>';
echo $_['username'];
echo '</th>' . "\n" . '                                    <th>';
echo $_['stream'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['ip'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['date'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
