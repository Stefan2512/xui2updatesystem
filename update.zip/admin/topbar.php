<?php

if (count(get_included_files()) != 1) {
	$ddf21fc658e95052 = d451DBaDaa63Fd18();
	$C3c8913edb801c35 = (isset(XUI::$rRequest['id']) ? intval(XUI::$rRequest['id']) : null);
	$e154835c9fa166f7 = (isset(XUI::$rRequest['sid']) ? intval(XUI::$rRequest['sid']) : null);
	$a6dd5c688a424355 = array('ondemand' => array('Manage Streams' => array('streams', 'streams'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('stream_mass', 'mass_edit_streams'), 'Stream Tools' => array('stream_tools', 'stream_tools'), 'Stream Error Logs' => array('stream_errors', 'stream_errors'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'streams' => array('Add Stream' => array('stream', 'add_stream'), 'Import & Review' => ($F61f585ee1fe12b7 ? array() : array('review?type=1', 'import_streams')), 'Categories' => array('stream_categories', 'categories'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), "EPG's" => array('epgs', 'epg'), 'Fingerprint' => array('fingerprint', 'fingerprint'), 'On-Demand Scanner' => array('ondemand', 'streams'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('stream_mass', 'mass_edit_streams'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Stream Tools' => array('stream_tools', 'stream_tools'), 'Stream Error Logs' => array('stream_errors', 'stream_errors'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'created_channels' => array('Create Channel' => array('created_channel', 'create_channel'), 'Categories' => array('stream_categories', 'categories'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('created_channel_mass', null), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'stream_review' => array((isset($D19861e3f008e509) ? 'Save Changes' : 'Review Streams') => array(null, null, 'id="btn-submit"')), 'panel_logs' => array('Send to XUI.one' => array(null, null, 'id="btn-send-xui"')), 'movies' => array('Add Movie' => array('movie', 'add_movie'), 'Import & Review' => ($F61f585ee1fe12b7 ? array() : array('review?type=2', 'import_movies')), 'Categories' => array('stream_categories', 'categories'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('movie_mass', 'mass_sedits_vod'), 'Watch Folder' => array('watch', 'folder_watch'), 'Watch Output Logs' => array('watch_output', 'folder_watch_output'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'series' => array('Add Series' => array('serie', 'add_series'), 'Episodes' => array('episodes', 'episodes'), 'Categories' => array('stream_categories', 'categories'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('series_mass', 'mass_sedits'), 'Watch Folder' => array('watch', 'folder_watch'), 'Watch Output Logs' => array('watch_output', 'folder_watch_output'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'episodes' => array('Add Episode' => array(null, 'add_episode'), 'TV Series' => array('series', 'series'), 'Categories' => array('stream_categories', 'categories'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('episodes_mass', 'mass_sedits'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'radios' => array('Add Station' => array('radio', 'add_radio'), 'Categories' => array('stream_categories', 'categories'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('radio_mass', 'mass_edit_radio'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'lines' => array('Add Line' => array('line', 'add_user'), "Blocked ASN's" => array('asns', 'block_isps'), "Blocked IP's" => array('ips', 'block_ips'), "Blocked ISP's" => array('isps', 'block_isps'), 'Blocked User-Agents' => array('useragents', 'block_uas'), 'Live Connections' => array('live_connections', 'live_connections'), 'Activity Logs' => array('line_activity', 'connection_logs'), "IP's per Line" => array('line_ips', 'connection_logs'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('line_mass', 'mass_edit_users'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'live_connections' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Activity Logs' => array('line_activity', 'connection_logs'), "IP's per Line" => array('line_ips', 'connection_logs')), 'mags' => array('Add Device' => array('mag', 'add_mag'), "Blocked IP's" => array('ips', 'block_ips'), "Blocked ISP's" => array('isps', 'block_isps'), 'Live Connections' => array('live_connections', 'connection_logs'), 'Activity Logs' => array('line_activity', 'connection_logs'), 'MAG Event Logs' => array('mag_events', 'manage_events'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('mag_mass', 'mass_edit_mags'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'enigmas' => array('Add Device' => array('enigma', 'add_e2'), "Blocked IP's" => array('ips', 'block_ips'), "Blocked ISP's" => array('isps', 'block_isps'), 'Live Connections' => array('live_connections', 'connection_logs'), 'Activity Logs' => array('line_activity', 'connection_logs'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('enigma_mass', 'mass_edit_enigmas'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'users' => array('Add User' => array('user', 'add_reguser'), 'Groups' => array('groups', 'mng_groups'), 'Packages' => array('packages', 'mng_packages'), 'Subresellers' => array('subresellers', 'subreseller'), 'Client Logs' => array('client_logs', 'client_request_log'), 'Credit Logs' => array('credit_logs', 'credits_log'), 'Reseller Logs' => array('user_logs', 'reg_userlog'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Mass Edit' => array('user_mass', 'mass_edit_reguser'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'bouquet' => array('Manage Bouquets' => array('bouquets', 'bouquets'), 'Sort Bouquet' => array('bouquet_sort?id=' . $C3c8913edb801c35, 'edit_bouquet')), 'bouquet_sort' => array('Manage Bouquets' => array('bouquets', 'bouquets'), 'Edit Bouquet' => array('bouquet?id=' . $C3c8913edb801c35, 'edit_bouquet')), 'bouquet_order' => array('Manage Bouquets' => array('bouquets', 'bouquets'), 'Add Bouquet' => array('bouquet', 'add_bouquet')), 'archive' => array('View Stream' => array('stream_view?id=' . $C3c8913edb801c35, 'streams'), 'Edit Stream' => array('stream?id=' . $C3c8913edb801c35, 'edit_stream'), 'Create Recording' => array('record', 'add_movie'), 'Manage Streams' => array('streams', 'streams')), 'asns' => array('Quick Tools' => array('quick_tools', 'quick_tools')), 'backups' => array('General Settings' => array('settings', 'settings'), 'Watch Settings' => array('settings_watch', 'folder_watch_settings'), 'Plex Settings' => array('settings_plex', 'folder_watch_settings'), 'Cache Settings' => array('cache', 'backups')), 'cache' => array('General Settings' => array('settings', 'settings'), 'Watch Settings' => array('settings_watch', 'folder_watch_settings'), 'Plex Settings' => array('settings_plex', 'folder_watch_settings'), 'Backup Settings' => array('backups', 'database')), 'settings' => array('Backup Settings' => array('backups', 'database'), 'Watch Settings' => array('settings_watch', 'folder_watch_settings'), 'Plex Settings' => array('settings_plex', 'folder_watch_settings'), 'Cache Settings' => array('cache', 'backups')), 'settings_watch' => array('Folders' => array('watch', 'folder_watch'), 'General Settings' => array('settings', 'settings'), 'Backup Settings' => array('backups', 'database'), 'Plex Settings' => array('settings_plex', 'folder_watch_settings'), 'Watch Folder Logs' => array('watch_output', 'folder_watch_output')), 'settings_plex' => array('Libraries' => array('plex', 'folder_watch'), 'General Settings' => array('settings', 'settings'), 'Backup Settings' => array('backups', 'database'), 'Watch Settings' => array('settings_watch', 'folder_watch_settings'), 'Watch Folder Logs' => array('watch_output', 'folder_watch_output')), 'channel_order' => array('Categories' => array('stream_categories', 'categories'), 'Bouquets' => array('bouquets', 'bouquets')), 'bouquets' => array('Add Bouquet' => array('bouquet', 'add_bouquet'), 'Order Bouquets' => ($F61f585ee1fe12b7 ? array() : array('bouquet_order', 'edit_bouquet')), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Categories' => array('stream_categories', 'categories')), 'stream_categories' => array('Add Category' => array('stream_category', 'add_cat'), 'Channel Order' => ($F61f585ee1fe12b7 ? array() : array('channel_order', 'channel_order')), 'Bouquets' => array('bouquets', 'bouquets')), 'client_logs' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Clear Logs' => array(null, null, 'id="btn-clear-logs"')), 'credit_logs' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Clear Logs' => array(null, null, 'id="btn-clear-logs"')), 'user_logs' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Clear Logs' => array(null, null, 'id="btn-clear-logs"')), 'stream_errors' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Clear Logs' => array(null, null, 'id="btn-clear-logs"')), 'line_activity' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Clear Logs' => array(null, null, 'id="btn-clear-logs"')), 'watch_output' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'Clear Logs' => array(null, null, 'id="btn-clear-logs"'), 'Watch Folder' => array('watch', 'folder_watch')), 'code' => array('Access Codes' => array('codes', 'add_code')), 'codes' => array('Add Code' => array('code', 'add_code')), 'hmacs' => array('Add HMAC' => array('hmac', 'add_hmac')), 'hmac' => array('HMAC Keys' => array('hmacs', 'add_hmac')), 'stream' => array('View Stream' => array('stream_view?id=' . $C3c8913edb801c35, 'streams'), 'Import' => array('stream?import', 'import_streams'), 'Add Single' => array('stream', 'add_stream'), 'Manage Streams' => array('streams', 'streams'), 'Import & Review' => ($F61f585ee1fe12b7 ? array() : array('review?type=1', 'import_streams'))), 'movie' => array('View Movie' => array('stream_view?id=' . $C3c8913edb801c35, 'movies'), 'Import' => array('movie?import', 'import_movies'), 'Add Single' => array('movie', 'add_movie'), 'Manage Movies' => array('movies', 'movies'), 'Import & Review' => ($F61f585ee1fe12b7 ? array() : array('review?type=2', 'import_movies'))), 'episode' => array('Add Multiple' => array('episode?sid=' . $e154835c9fa166f7 . '&multi', 'add_episode'), 'Add Single' => array('episode?sid=' . $e154835c9fa166f7, 'add_episode'), 'View Episodes' => array('episodes?series=' . $e154835c9fa166f7, 'episodes'), 'Manage Series' => array('series', 'series')), 'serie' => array('Import' => array('serie?import', 'import_streams'), 'Add Single' => array('serie', 'add_series'), 'Manage Series' => array('series', 'series'), 'View Episodes' => array('episodes?series=' . $C3c8913edb801c35, 'episodes')), 'created_channel' => array('View Channel' => array('stream_view?id=' . $C3c8913edb801c35, 'streams'), 'Manage Channels' => array('created_channels', 'streams')), 'epg' => array("Manage EPG's" => array('epgs', 'epg')), 'epgs' => array('Add EPG' => array('epg', 'add_epg'), 'Force Reload' => array(null, 'add_epg', 'onClick="forceUpdate();" id="force_update"')), 'fingerprint' => array('Manage Streams' => array('streams', 'streams')), 'group' => array('Manage Groups' => array('groups', 'mng_groups')), 'groups' => array('Add Group' => array('group', 'add_group')), 'package' => array('Manage Packages' => array('packages', 'mng_packages')), 'packages' => array('Add Package' => array('package', 'add_packages')), 'provider' => array('Providers' => array('providers', 'streams')), 'providers' => array('Add Provider' => array('provider', 'streams')), 'ip' => array('Blocked IPs' => array('ips', 'block_ips')), 'ips' => array('Block IP' => array('ip', 'block_ips'), 'Flush Blocks' => array('ips?flush=1', 'block_ips')), 'isp' => array('Blocked ISPs' => array('isps', 'block_isps')), 'isps' => array('Block ISP' => array('isp', 'block_isps')), 'line' => array('Manage Lines' => array('lines', 'users')), 'user' => array('Manage Users' => array('users', 'mng_regusers')), 'mag' => array('MAG Devices' => array('mags', 'manage_mag')), 'enigma' => array('Enigma Devices' => array('enigmas', 'manage_e2')), 'line_ips' => array('Manage Lines' => array('lines', 'users')), 'line_mass' => array('Manage Lines' => array('lines', 'users'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools')), 'user_mass' => array('Manage Users' => array('users', 'mng_regusers'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools')), 'mag_mass' => array('Manage Devices' => array('mags', 'manage_mag'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools')), 'enigma_mass' => array('Manage Devices' => array('enigmas', 'manage_e2'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools')), 'stream_mass' => array('Manage Streams' => array('streams', 'streams'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Stream Tools' => array('stream_tools', 'stream_tools')), 'created_channel_mass' => array('Manage Channels' => array('created_channels', 'streams'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Stream Tools' => array('stream_tools', 'stream_tools')), 'movie_mass' => array('Manage Movies' => array('movies', 'movies'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Stream Tools' => array('stream_tools', 'stream_tools')), 'radio_mass' => array('Manage Stations' => array('radios', 'radio'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Stream Tools' => array('stream_tools', 'stream_tools')), 'series_mass' => array('Manage Series' => array('series', 'series'), 'Manage Episodes' => array('episodes', 'episodes'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools')), 'episodes_mass' => array('Manage Episodes' => array('episodes', 'episodes'), 'Manage Series' => array('series', 'series'), 'Mass Delete' => array('mass_delete', 'mass_delete'), 'Quick Tools' => array('quick_tools', 'quick_tools'), 'Stream Tools' => array('stream_tools', 'stream_tools')), 'mag_events' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"'), 'MAG Devices' => array('mags', 'manage_mag')), 'login_logs' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'mysql_syslog' => array('Export as CSV' => array(null, null, 'id="btn-export-csv"')), 'mass_delete' => array('Manage Streams' => array('streams', 'streams'), 'Manage Channels' => array('created_channels', 'streams'), 'Manage Series' => array('series', 'series'), 'Manage Episodes' => array('episodes', 'episodes'), 'Manage Stations' => array('radios', 'radio'), 'Manage Lines' => array('lines', 'users'), 'Manage Users' => array('users', 'mng_regusers'), 'Manage MAGs' => array('mags', 'manage_mag'), 'Manage Enigmas' => array('enigmas', 'manage_e2')), 'quick_tools' => array('Stream Tools' => array('stream_tools', 'stream_tools')), 'stream_tools' => array('Quick Tools' => array('quick_tools', 'quick_tools')), 'profile' => array('Manage Profiles' => array('profiles', 'tprofiles')), 'profiles' => array('Create Profile' => array('profile', 'tprofile')), 'rtmp_ips' => array('Add IP' => array('rtmp_ip', 'add_rtmp')), 'rtmp_ip' => array('RTMP IPs' => array('rtmp_ips', 'rtmp')), 'server' => array('View Server' => array('server_view?id=' . $C3c8913edb801c35, 'servers'), 'Manage Servers' => array('servers', 'servers')), 'proxy' => array('View Proxy' => array('server_view?id=' . $C3c8913edb801c35, 'servers'), 'Manage Proxies' => array('proxies', 'servers')), 'server_install' => array('Manage Servers' => array('servers', 'servers'), 'Manage Proxies' => array('proxies', 'servers')), 'servers' => array('Install Server' => array('server_install', 'add_server'), 'Server Order' => array('server_order', 'servers'), 'Proxies' => array('proxies', 'servers'), 'Process Monitor' => array('process_monitor', 'process_monitor'), 'Update All Servers' => array(null, 'servers', 'onClick="updateAll();"'), 'Update All Binaries' => array(null, 'servers', 'onClick="updateBinaries();"'), 'Restart All Services' => array(null, 'servers', 'onClick="restartServices();"')), 'server_order' => array('Servers' => array('servers', 'servers'), 'Proxies' => array('proxies', 'servers'), 'Process Monitor' => array('process_monitor', 'process_monitor')), 'proxies' => array('Install Proxy' => array('server_install?proxy=1', 'add_server'), 'Servers' => array('servers', 'servers'), 'Process Monitor' => array('process_monitor', 'process_monitor')), 'stream_category' => array('Manage Categories' => array('stream_categories', 'categories')), 'ticket' => array('View Ticket' => array('ticket_view?id=' . $C3c8913edb801c35, 'ticket'), 'View Tickets' => array('tickets', 'manage_tickets')), 'ticket_view' => array('Add Response' => array('ticket?id=' . $C3c8913edb801c35, 'ticket'), 'View Tickets' => array('tickets', 'manage_tickets')), 'useragent' => array('Blocked User-Agents' => array('useragents', 'block_uas')), 'useragents' => array('Block User-Agent' => array('useragent', 'block_uas')), 'watch' => array('Add Folder' => array('watch_add', 'folder_watch_add'), 'Settings' => array('settings_watch', 'folder_watch_settings'), 'Watch Output Logs' => array('watch_output', 'folder_watch_output'), 'Kill Running' => array(null, 'folder_watch_settings', 'onClick="killWatchFolder();"'), 'Enable All' => array(null, 'folder_watch_settings', 'onClick="enableAll();"'), 'Disable All' => array(null, 'folder_watch_settings', 'onClick="disableAll();"')), 'watch_add' => array('Manage Folders' => array('watch', 'folder_watch')), 'plex' => array('Add Library' => array('plex_add', 'folder_watch_add'), 'Settings' => array('settings_plex', 'folder_watch_settings'), 'Watch Folder Logs' => array('watch_output', 'folder_watch_output'), 'Kill Running' => array(null, 'folder_watch_settings', 'onClick="killPlexSync();"'), 'Enable All' => array(null, 'folder_watch_settings', 'onClick="enableAll();"'), 'Disable All' => array(null, 'folder_watch_settings', 'onClick="disableAll();"')), 'plex_add' => array('Manage Libraries' => array('plex', 'folder_watch')));

	if (!($D8d681f377d877d4 || $Ab5b854e25293d6b)) {
	} else {
		$a6dd5c688a424355['servers'] = array('Proxies' => array('proxies', 'servers'), 'Process Monitor' => array('process_monitor', 'process_monitor'));
	}

	if ($ddf21fc658e95052 != 'stream_view') {
	} else {
		if ($f523e362fb81d6c8['type'] == 1) {
			$a6dd5c688a424355['stream_view'] = array('Edit Stream' => array('stream?id=' . $C3c8913edb801c35, 'edit_stream'), 'Manage Streams' => array('streams', 'streams'));
		} else {
			if ($f523e362fb81d6c8['type'] == 2) {
				$a6dd5c688a424355['stream_view'] = array('Edit Movie' => array('movie?id=' . $C3c8913edb801c35, 'edit_movie'), 'Manage Movies' => array('movies', 'movies'));
			} else {
				if ($f523e362fb81d6c8['type'] == 3) {
					$a6dd5c688a424355['stream_view'] = array('Edit Channel' => array('created_channel?id=' . $C3c8913edb801c35, 'edit_cchannel'), 'Manage Channels' => array('created_channels', 'streams'));
				} else {
					if ($f523e362fb81d6c8['type'] == 4) {
						$a6dd5c688a424355['stream_view'] = array('Edit Station' => array('radio?id=' . $C3c8913edb801c35, 'edit_radio'), 'Manage Stations' => array('radios', 'radio'));
					} else {
						if ($f523e362fb81d6c8['type'] != 5) {
						} else {
							$a6dd5c688a424355['stream_view'] = array('Edit Episode' => array('episode?id=' . $C3c8913edb801c35 . '&sid=' . intval($A2d65843292b5c59), 'edit_episode'), 'View Episodes' => array('episodes?series=' . intval($A2d65843292b5c59), 'episodes'), 'Manage Series' => array('series', 'series'));
						}
					}
				}
			}
		}
	}

	if ($ddf21fc658e95052 != 'server_view') {
	} else {
		if ($e81220b4451f37c9['server_type'] == 0) {
			$a6dd5c688a424355['server_view'] = array('Process Monitor' => array('process_monitor?server=' . $C3c8913edb801c35, 'process_monitor'), 'Edit Server' => array('server?id=' . $C3c8913edb801c35, 'edit_server'), 'Reinstall Server' => array('server_install?id=' . $C3c8913edb801c35, 'add_server'), 'View FPM Status' => array(null, 'servers', 'onClick="getFPMStatus(' . $C3c8913edb801c35 . ');"'), 'Manage Servers' => array('servers', 'servers'));
		} else {
			$a6dd5c688a424355['server_view'] = array('Edit Proxy' => array('proxy?id=' . $C3c8913edb801c35, 'edit_server'), 'Reinstall Proxy' => array('server_install?proxy=1&id=' . $C3c8913edb801c35, 'add_server'), 'Manage Proxies' => array('proxies', 'servers'));
		}
	}

	switch ($ddf21fc658e95052) {
		case 'archive':
			if (!is_null($adab610984c5d7df)) {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]], $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[2]]);
			}

			break;

		case 'movie':
		case 'stream':
			if (!isset($f523e362fb81d6c8) && !isset($a417725f28d75ef7)) {
				if (!isset(XUI::$rRequest['import'])) {
					unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[2]]);
				} else {
					unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]]);
				}

				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[4]], $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[2]], $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]]);
			}

			break;

		case 'episode':
			if (!isset($Bd43537fab08ca31)) {
				if (isset($caa6c2a1dcc4ac73)) {
					unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
				} else {
					unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]]);
				}
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]], $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			}

			break;

		case 'serie':
			if (isset($ef62ade7a459ab90)) {
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[3]]);
			}

			if (!isset(XUI::$rRequest['import'])) {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]]);
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			}

			break;

		case 'mag':
		case 'enigma':
		case 'line':
			break;

		case 'server':
		case 'proxy':
			if (isset($e81220b4451f37c9)) {
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			}

			break;

		case 'server_install':
			if ($E379394c7b1a273f == 1) {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]]);
			}

			break;

		case 'ticket':
			if (isset($Fc045a436f741403)) {
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			}

			break;

		case 'ticket_view':
			if (!(isset($e67c6f9cfcf32879) && $e67c6f9cfcf32879['status'] == 0)) {
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			}

			break;

		case 'bouquet':
			if (isset($f8be76c63ffd3cae)) {
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[1]]);
			}

			break;

		case 'created_channel':
			if (isset($Fe753328765ad26c)) {
			} else {
				unset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]]);
			}

			break;

		default:
			break;
	}
} else {
	exit();
}

$b29c51a47b07e86e = array();

if (isset($a6dd5c688a424355[$ddf21fc658e95052])) {
	foreach ($a6dd5c688a424355[$ddf21fc658e95052] as $d9ee1cc8e0f43f6e => $a27e64cc6ce01033) {
		if ($d9ee1cc8e0f43f6e != 'Export as CSV' || Aacd47d8157A1A09('adv', 'backups')) {
			if (!($d9ee1cc8e0f43f6e && (!$a27e64cc6ce01033[1] || aacD47D8157A1A09('adv', $a27e64cc6ce01033[1])))) {
			} else {
				if (count($a27e64cc6ce01033) == 3) {
					$b29c51a47b07e86e[$d9ee1cc8e0f43f6e] = 'code:' . $a27e64cc6ce01033[2];
				} else {
					if (0 >= count($a27e64cc6ce01033)) {
					} else {
						$b29c51a47b07e86e[$d9ee1cc8e0f43f6e] = $a27e64cc6ce01033[0];
					}
				}
			}
		}
	}
}

switch ($ddf21fc658e95052) {
	case 'streams':
	case 'created_channels':
	case 'movies':
	case 'series':
	case 'users':
	case 'mags':
	case 'client_logs':
	case 'line_activity':
	case 'live_connections':
	case 'lines':
	case 'radios':
	case 'enigmas':
	case 'ondemand':
	case 'episodes':
		echo '<div class="btn-group">';

		if (!(!$F61f585ee1fe12b7 && aaCD47D8157A1A09('adv', $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][1]) && 0 < strlen(array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]))) {
		} else {
			if ($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][0]) {
				echo "<button type=\"button\" onClick=\"navigate('" . $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][0] . "');\" class=\"btn btn-sm btn-info waves-effect waves-light\">" . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
			} else {
				if (isset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][2])) {
					echo '<button type="button" ' . $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][2] . ' class="btn btn-sm btn-info waves-effect waves-light">' . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
				} else {
					echo '<button type="button" onClick="showModal();" class="btn btn-sm btn-info waves-effect waves-light">' . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
				}
			}

			echo '<span class="gap"></span>';
		}

		if (!$F61f585ee1fe12b7) {
		} else {
			echo '<a class="btn btn-success waves-effect waves-light btn-sm btn-fixed-sm" data-toggle="collapse" href="#collapse_filters" role="button" aria-expanded="false">' . "\r\n" . '                    <i class="mdi mdi-filter"></i>' . "\r\n" . '                </a>';
		}

		echo '<button onClick="clearFilters();" type="button" class="btn btn-warning waves-effect waves-light btn-sm btn-fixed-sm" id="clearFilters">' . "\r\n" . '                <i class="mdi mdi-filter-remove"></i>' . "\r\n" . '            </button>' . "\r\n" . '            <button onClick="refreshTable();" type="button" class="btn btn-pink waves-effect waves-light btn-sm btn-fixed-sm">' . "\r\n" . '                <i class="mdi mdi-refresh"></i>' . "\r\n" . '            </button>';

		if (0 >= count(array_slice($b29c51a47b07e86e, ($F61f585ee1fe12b7 ? 0 : 1), count($b29c51a47b07e86e)))) {
		} else {
			echo '<button type="button" class="btn btn-sm btn-dark waves-effect waves-light dropdown-toggle btn-fixed-sm" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-caret-down"></i></button>' . "\r\n" . '                <div class="dropdown-menu">';

			foreach (array_slice($b29c51a47b07e86e, ($F61f585ee1fe12b7 ? 0 : 1), count($b29c51a47b07e86e)) as $d9ee1cc8e0f43f6e => $C700a2b357e5ed65) {
				if (!$d9ee1cc8e0f43f6e) {
				} else {
					if ($C700a2b357e5ed65) {
						if (substr($C700a2b357e5ed65, 0, 5) == 'code:') {
							echo '<a class="dropdown-item" href="javascript: void(0);" ' . substr($C700a2b357e5ed65, 5, strlen($C700a2b357e5ed65) - 5) . '>' . $d9ee1cc8e0f43f6e . '</a>';
						} else {
							echo "<a class=\"dropdown-item\" href=\"javascript: void(0);\" onClick=\"navigate('" . $C700a2b357e5ed65 . "');\">" . $d9ee1cc8e0f43f6e . '</a>';
						}
					} else {
						echo '<a class="dropdown-item" href="javascript: void(0);" onClick="showModal();">' . $d9ee1cc8e0f43f6e . '</a>';
					}
				}
			}
			echo '</div>';
		}

		echo '</div>';

		break;

	case 'stream_view':
		echo '<div class="btn-group">';

		if ($f523e362fb81d6c8['type'] == 1 || $f523e362fb81d6c8['type'] == 3) {
			echo '<a href="javascript:void(0);" onClick="player(' . intval($f523e362fb81d6c8['id']) . ');">' . "\r\n" . '                    <button type="button" title="Play" class="tooltip btn btn-info waves-effect waves-light btn-sm">' . "\r\n" . '                        <i class="mdi mdi-play"></i>' . "\r\n" . '                    </button>' . "\r\n" . '                </a>';
		} else {
			if (!($f523e362fb81d6c8['type'] == 2 || $f523e362fb81d6c8['type'] == 5)) {
			} else {
				echo '<a href="javascript:void(0);" onClick="player(' . intval($f523e362fb81d6c8['id']) . ", '" . htmlspecialchars($f523e362fb81d6c8['target_container']) . "');\">" . "\r\n" . '                    <button type="button" title="Play" class="tooltip btn btn-info waves-effect waves-light btn-sm">' . "\r\n" . '                        <i class="mdi mdi-play"></i>' . "\r\n" . '                    </button>' . "\r\n" . '                </a>';
			}
		}

		if (!(!$F61f585ee1fe12b7 && aaCd47D8157a1A09('adv', $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][1]) && 0 < strlen(array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]))) {
		} else {
			echo "<button type=\"button\" onClick=\"navigate('" . $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][0] . "');\" class=\"btn btn-sm btn-info waves-effect waves-light\">" . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
		}

		if (0 >= count(array_slice($b29c51a47b07e86e, ($F61f585ee1fe12b7 ? 0 : 1), count($b29c51a47b07e86e)))) {
		} else {
			echo '<span class="gap"></span><button type="button" class="btn btn-sm btn-dark waves-effect waves-light dropdown-toggle btn-fixed' . (($F61f585ee1fe12b7 ? '-xl' : '-sm')) . '" data-toggle="dropdown" aria-expanded="false">' . (($F61f585ee1fe12b7 ? 'Options &nbsp; ' : '')) . '<i class="fas fa-caret-down"></i></button>' . "\r\n" . '                <div class="dropdown-menu">';

			foreach (array_slice($b29c51a47b07e86e, ($F61f585ee1fe12b7 ? 0 : 1), count($b29c51a47b07e86e)) as $d9ee1cc8e0f43f6e => $C700a2b357e5ed65) {
				if (!$d9ee1cc8e0f43f6e) {
				} else {
					if (substr($C700a2b357e5ed65, 0, 5) == 'code:') {
						echo '<a class="dropdown-item" href="javascript: void(0);" ' . substr($C700a2b357e5ed65, 5, strlen($C700a2b357e5ed65) - 5) . '>' . $d9ee1cc8e0f43f6e . '</a>';
					} else {
						echo "<a class=\"dropdown-item\" href=\"javascript: void(0);\" onClick=\"navigate('" . $C700a2b357e5ed65 . "');\">" . $d9ee1cc8e0f43f6e . '</a>';
					}
				}
			}
			echo '</div>';
		}

		echo '</div>';

		break;

		default:
echo '<div class="btn-group">';

if (!(!$F61f585ee1fe12b7 && aACD47D8157A1A09('adv', $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][1]) && 0 < strlen(array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]))) {
} else {
	if ($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][0]) {
		echo "<button type=\"button\" onClick=\"navigate('" . $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][0] . "');\" class=\"btn btn-sm btn-info waves-effect waves-light\">" . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
	} else {
		if (isset($a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][2])) {
			echo '<button type="button" ' . $a6dd5c688a424355[$ddf21fc658e95052][array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0]][2] . ' class="btn btn-sm btn-info waves-effect waves-light">' . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
		} else {
			echo '<button type="button" onClick="showModal();" class="btn btn-sm btn-info waves-effect waves-light">' . array_keys($a6dd5c688a424355[$ddf21fc658e95052])[0] . '</button>';
		}
	}
}

if (0 >= count(array_slice($b29c51a47b07e86e, ($F61f585ee1fe12b7 ? 0 : 1), count($b29c51a47b07e86e)))) {
} else {
	echo '<span class="gap"></span><button type="button" class="btn btn-sm btn-dark waves-effect waves-light dropdown-toggle btn-fixed' . (($F61f585ee1fe12b7 ? '-xl' : '-sm')) . '" data-toggle="dropdown" aria-expanded="false">' . (($F61f585ee1fe12b7 ? 'Options &nbsp; ' : '')) . '<i class="fas fa-caret-down"></i></button>' . "\r\n" . '                <div class="dropdown-menu">';

	foreach (array_slice($b29c51a47b07e86e, ($F61f585ee1fe12b7 ? 0 : 1), count($b29c51a47b07e86e)) as $d9ee1cc8e0f43f6e => $C700a2b357e5ed65) {
		if (!$d9ee1cc8e0f43f6e) {
		} else {
			if (substr($C700a2b357e5ed65, 0, 5) == 'code:') {
				echo '<a class="dropdown-item" href="javascript: void(0);" ' . substr($C700a2b357e5ed65, 5, strlen($C700a2b357e5ed65) - 5) . '>' . $d9ee1cc8e0f43f6e . '</a>';
			} else {
				echo "<a class=\"dropdown-item\" href=\"javascript: void(0);\" onClick=\"navigate('" . $C700a2b357e5ed65 . "');\">" . $d9ee1cc8e0f43f6e . '</a>';
			}
		}
	}
	echo '</div>';
}

echo '</div>';
}
