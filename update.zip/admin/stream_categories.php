<?php

include 'session.php';
include 'functions.php';

if (b1882Df698B44754()) {
} else {
	b46F5dD76F3C7421();
}

$A5dcdeb6ecbbf6bd = array(1 => cBE87E2A9A996111(), 2 => CBe87e2a9a996111('movie'), 3 => cBe87E2A9a996111('series'), 4 => cbE87E2a9A996111('radio'));
$d1413047bdc98aad = array(1 => array(), 2 => array(), 3 => array());

foreach (array(1, 2, 3, 4) as $C3c8913edb801c35) {
	foreach ($A5dcdeb6ecbbf6bd[$C3c8913edb801c35] as $Be965cdd996d4520 => $Aa0bb127e6545912) {
		$d1413047bdc98aad[$C3c8913edb801c35][] = $Aa0bb127e6545912;
	}
}
$bcf587bb39f95fd5 = 'Stream Categories';
include 'header.php';
echo '<div class="wrapper boxed-layout"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo '                    </div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Categories</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-xl-12">' . "\n" . '                ';

if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS) {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Your new Category has been added. You can move it up the list to re-order it.' . "\n\t\t\t\t" . '</div>' . "\n" . '                ';
} else {
	if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS_MULTI)) {
	} else {
		echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Categories have been re-ordered.' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t\t";
	}
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body">' . "\n\t\t\t\t\t\t" . '<div id="basicwizard">' . "\n\t\t\t\t\t\t\t" . '<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#category-order-1" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-play mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Streams</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#category-order-2" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-movie mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Movies</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#category-order-3" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-youtube-tv mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Series</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t" . '<li class="nav-item">' . "\n\t\t\t\t\t\t\t\t\t" . '<a href="#category-order-4" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<i class="mdi mdi-radio mr-1"></i>' . "\n\t\t\t\t\t\t\t\t\t\t" . '<span class="d-none d-sm-inline">Radio</span>' . "\n\t\t\t\t\t\t\t\t\t" . '</a>' . "\n\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t" . '<div class="tab-content b-0 mb-0 pt-0">' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="category-order-1">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="stream_categories_form-1">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" id="categories_input-1" name="categories" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="sub-header">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'To re-order a category, drag it up or down the list using the <i class="mdi mdi-view-sequential"></i> icon. Click Save Changes at the bottom once finished.' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</p>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="custom-dd dd" id="category_order-1">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<ol class="dd-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($d1413047bdc98aad[1] as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dd-item dd3-item category-';
	echo $A1925ae53e9307eb['id'];
	echo '" data-id="';
	echo $A1925ae53e9307eb['id'];
	echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd-handle dd3-handle"></div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd3-content">';
	echo $A1925ae53e9307eb['category_name'];
	echo ' ';

	if (!$A1925ae53e9307eb['is_adult']) {
	} else {
		echo "<i class='text-pink mdi mdi-record'></i>";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span style="float:right;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	if (!aAcD47d8157a1A09('adv', 'edit_cat')) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<button type=\"button\" onClick=\"navigate('stream_category?id=";
		echo $A1925ae53e9307eb['id'];
		echo "');\" class=\"btn btn-light waves-effect waves-light sml-button\"><i class=\"mdi mdi-pencil-outline\"></i></button></a>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-light waves-effect waves-light sml-button" onClick="deleteCategory(';
		echo $A1925ae53e9307eb['id'];
		echo ')"><i class="mdi mdi-close"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</ol>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">Save Changes</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="category-order-2">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="stream_categories_form-2">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" id="categories_input-2" name="categories" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="sub-header">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'To re-order a category, drag it up or down the list using the <i class="mdi mdi-view-sequential"></i> icon. Click Save Changes at the bottom once finished.' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</p>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="custom-dd dd" id="category_order-2">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<ol class="dd-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($d1413047bdc98aad[2] as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dd-item dd3-item category-';
	echo $A1925ae53e9307eb['id'];
	echo '" data-id="';
	echo $A1925ae53e9307eb['id'];
	echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd-handle dd3-handle"></div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd3-content">';
	echo $A1925ae53e9307eb['category_name'];
	echo ' ';

	if (!$A1925ae53e9307eb['is_adult']) {
	} else {
		echo "<i class='text-pink mdi mdi-record'></i>";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span style="float:right;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	if (!AAcd47d8157a1A09('adv', 'edit_cat')) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<button type=\"button\" onClick=\"navigate('stream_category?id=";
		echo $A1925ae53e9307eb['id'];
		echo "');\" class=\"btn btn-light waves-effect waves-light sml-button\"><i class=\"mdi mdi-pencil-outline\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-light waves-effect waves-light sml-button" onClick="deleteCategory(';
		echo $A1925ae53e9307eb['id'];
		echo ')"><i class="mdi mdi-close"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</ol>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">Save Changes</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="category-order-3">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="stream_categories_form-3">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" id="categories_input-3" name="categories" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="sub-header">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'To re-order a category, drag it up or down the list using the <i class="mdi mdi-view-sequential"></i> icon. Click Save Changes at the bottom once finished.' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</p>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="custom-dd dd" id="category_order-3">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<ol class="dd-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($d1413047bdc98aad[3] as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dd-item dd3-item category-';
	echo $A1925ae53e9307eb['id'];
	echo '" data-id="';
	echo $A1925ae53e9307eb['id'];
	echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd-handle dd3-handle"></div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd3-content">';
	echo $A1925ae53e9307eb['category_name'];
	echo ' ';

	if (!$A1925ae53e9307eb['is_adult']) {
	} else {
		echo "<i class='text-pink mdi mdi-record'></i>";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span style="float:right;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	if (!AaCD47d8157A1A09('adv', 'edit_cat')) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<button type=\"button\" onClick=\"navigate('stream_category?id=";
		echo $A1925ae53e9307eb['id'];
		echo "');\" class=\"btn btn-light waves-effect waves-light sml-button\"><i class=\"mdi mdi-pencil-outline\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-light waves-effect waves-light sml-button" onClick="deleteCategory(';
		echo $A1925ae53e9307eb['id'];
		echo ')"><i class="mdi mdi-close"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</ol>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">Save Changes</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t" . '<div class="tab-pane" id="category-order-4">' . "\n\t\t\t\t\t\t\t\t\t" . '<form action="#" method="POST" id="stream_categories_form-4">' . "\n\t\t\t\t\t\t\t\t\t\t" . '<input type="hidden" id="categories_input-4" name="categories" value="" />' . "\n\t\t\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<p class="sub-header">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . 'To re-order a category, drag it up or down the list using the <i class="mdi mdi-view-sequential"></i> icon. Click Save Changes at the bottom once finished.' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</p>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="custom-dd dd" id="category_order-4">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<ol class="dd-list">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

foreach ($d1413047bdc98aad[4] as $A1925ae53e9307eb) {
	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<li class="dd-item dd3-item category-';
	echo $A1925ae53e9307eb['id'];
	echo '" data-id="';
	echo $A1925ae53e9307eb['id'];
	echo '">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd-handle dd3-handle"></div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="dd3-content">';
	echo $A1925ae53e9307eb['category_name'];
	echo ' ';

	if (!$A1925ae53e9307eb['is_adult']) {
	} else {
		echo "<i class='text-pink mdi mdi-record'></i>";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span style="float:right;">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";

	if (!aAcd47d8157a1A09('adv', 'edit_cat')) {
	} else {
		echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="btn-group">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . "<button type=\"button\" onClick=\"navigate('stream_category?id=";
		echo $A1925ae53e9307eb['id'];
		echo "');\" class=\"btn btn-light waves-effect waves-light sml-button\"><i class=\"mdi mdi-pencil-outline\"></i></button>" . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="button" class="btn btn-light waves-effect waves-light sml-button" onClick="deleteCategory(';
		echo $A1925ae53e9307eb['id'];
		echo ')"><i class="mdi mdi-close"></i></button>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</span>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '</ol>' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t\t\t\t\t\t" . '<ul class="list-inline wizard mb-0 add-margin-top-20">' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '<li class="list-inline-item float-right">' . "\n\t\t\t\t\t\t\t\t\t\t\t\t" . '<button type="submit" class="btn btn-primary waves-effect waves-light">Save Changes</button>' . "\n\t\t\t\t\t\t\t\t\t\t\t" . '</li>' . "\n\t\t\t\t\t\t\t\t\t\t" . '</ul>' . "\n\t\t\t\t\t\t\t\t\t" . '</form>' . "\n\t\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div> ' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
