<?php

$Bdb9aa165959a993 = 60;

if (defined('TMP_PATH')) {
} else {
	define('TMP_PATH', '/home/xui/tmp/');
}

if (session_status() != PHP_SESSION_NONE) {
} else {
	session_start();
}

if (!(isset($_SESSION['hash']) && isset($_SESSION['last_activity']) && $Bdb9aa165959a993 * 60 < time() - $_SESSION['last_activity'])) {
} else {
	foreach (array('hash', 'ip', 'code', 'verify', 'last_activity') as $D3fa098be3f297cd) {
		if (!isset($_SESSION[$D3fa098be3f297cd])) {
		} else {
			unset($_SESSION[$D3fa098be3f297cd]);
		}
	}

	if (session_status() !== PHP_SESSION_NONE) {
	} else {
		session_start();
	}
}

if (!isset($_SESSION['hash'])) {
	if (basename(__FILE__) == basename($_SERVER['SCRIPT_FILENAME'])) {
		echo json_encode(array('result' => false));

		exit();
	}

	header('Location: ./login?referrer=' . urlencode(basename($_SERVER['REQUEST_URI'], '.php')));

	exit();
}

if (basename(__FILE__) == basename($_SERVER['SCRIPT_FILENAME'])) {
	echo json_encode(array('result' => true));

	exit();
}

$_SESSION['last_activity'] = time();
session_write_close();
