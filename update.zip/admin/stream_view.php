<?php

include 'session.php';
include 'functions.php';

if (B1882dF698b44754()) {
} else {
	b46F5dd76f3C7421();
}

if (isset(XUI::$rRequest['id']) && ($f523e362fb81d6c8 = e5ECeb32F67D5E70(XUI::$rRequest['id']))) {
} else {
	b46f5DD76f3C7421();
}

$c3e4b78793d61beb = array(1 => 'Stream', 2 => 'Movie', 3 => 'Channel', 4 => 'Station', 5 => 'Episode')[$f523e362fb81d6c8['type']];
$E05d5c8afb9dc282 = null;
$A639a7baefc720ee = null;

if ($f523e362fb81d6c8['type'] == 1) {
	$E05d5c8afb9dc282 = cFaec500A6b51C40($f523e362fb81d6c8['id']);

	if (0 >= $f523e362fb81d6c8['vframes_server_id']) {
	} else {
		$bae85948a6f4b7de = time() + 3600;
		$F64d974c429d80be = array('session_id' => session_id(), 'expires' => $bae85948a6f4b7de, 'stream_id' => intval(XUI::$rRequest['id']), 'ip' => XUI::a9BC416fa6fa55C3());
		$f6cb1b77556fb98a = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

		if (B1d9852fceb75E78()) {
			$A639a7baefc720ee = 'https://' . ((XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['domain_name'] ? XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['domain_name'] : XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['server_ip'])) . ':' . intval(XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['https_broadcast_port']) . '/admin/thumb?uitoken=' . $f6cb1b77556fb98a;
		} else {
			$A639a7baefc720ee = 'http://' . ((XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['domain_name'] ? XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['domain_name'] : XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['server_ip'])) . ':' . intval(XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['http_broadcast_port']) . '/admin/thumb?uitoken=' . $f6cb1b77556fb98a;
		}
	}

	$Ab17a088c3341b0d = (json_decode($f523e362fb81d6c8['adaptive_link'], true) ?: array());
} else {
	if ($f523e362fb81d6c8['type'] == 2 || $f523e362fb81d6c8['type'] == 5) {
		$D92b16dc36690ab9 = json_decode($f523e362fb81d6c8['movie_properties'], true);
		$A639a7baefc720ee = (!empty($D92b16dc36690ab9['backdrop_path'][0]) ? XUI::B8F3def724810918($D92b16dc36690ab9['backdrop_path'][0], (b1d9852fCeB75E78() ? 'https' : 'http')) : XUI::B8f3deF724810918($D92b16dc36690ab9['movie_image'], (B1d9852FCEB75e78() ? 'https' : 'http')));

		if (empty($A639a7baefc720ee)) {
		} else {
			if (@getimagesize($A639a7baefc720ee)) {
			} else {
				$A639a7baefc720ee = null;
			}
		}
	} else {
		if ($f523e362fb81d6c8['type'] != 3) {
		} else {
			$a0e727eef95293df = null;
			$Fee0d5a474c96306->query('SELECT `streams_servers`.`stream_started`, `streams_servers`.`cc_info` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` AND `streams_servers`.`parent_id` IS NULL WHERE `streams`.`id` = ? GROUP BY `streams`.`id`;', $f523e362fb81d6c8['id']);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				$ac870d4ba693b96f = $Fee0d5a474c96306->get_row();
				$a0e727eef95293df = json_decode($ac870d4ba693b96f['cc_info'], true);
				$eff3c5536b319f0b = time() - intval($ac870d4ba693b96f['stream_started']);
			}
		}
	}
}

if ($f523e362fb81d6c8['type'] != 5) {
} else {
	$bbc84f53c534450d = null;
	$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` = (SELECT `series_id` FROM `streams_episodes` WHERE `stream_id` = ?);', $f523e362fb81d6c8['id']);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		$bbc84f53c534450d = $Fee0d5a474c96306->get_row();
	}

	$A2d65843292b5c59 = $bbc84f53c534450d['id'];
}

$dfeb264f9dc80c74 = D48690EE48e36D75($f523e362fb81d6c8['id']);
$bcf587bb39f95fd5 = 'View ' . $c3e4b78793d61beb;
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n" . '                    <h4 class="page-title">';
echo $f523e362fb81d6c8['stream_display_name'];
echo '</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-xl-12">' . "\r\n" . '                ';

if (!$A639a7baefc720ee) {
} else {
	echo '                <img class="card-img-top img-fluid" src="';
	echo $A639a7baefc720ee;
	echo "\" onerror=\"this.style.display='none'\"/>" . "\r\n" . '                ';
}

if ($f523e362fb81d6c8['type'] != 1) {
} else {
	echo "\t\t\t\t" . '<div class="card-box">' . "\r\n\t\t\t\t\t" . '<ul class="nav nav-tabs nav-bordered nav-justified">' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#today" data-toggle="tab" aria-expanded="true" class="nav-link active">' . "\r\n\t\t\t\t\t\t\t\t" . 'Today' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#week" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'This Week' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#month" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'This Month' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#all" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'All Time' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t" . '<div class="tab-content">' . "\r\n\t\t\t\t\t\t";

	foreach (array('today', 'week', 'month', 'all') as $E379394c7b1a273f) {
		echo "\t\t\t\t\t\t" . '<div class="tab-pane';

		if ($E379394c7b1a273f != 'today') {
		} else {
			echo ' active';
		}

		echo '" id="';
		echo $E379394c7b1a273f;
		echo '">' . "\r\n\t\t\t\t\t\t\t" . '<div class="row text-center" style="padding-top: 20px;">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<h4 class="header-title">Stream Rank</h4>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="sub-header" id="s_conns">';

		if (0 < $dfeb264f9dc80c74[$E379394c7b1a273f]['rank']) {
			echo '#' . $dfeb264f9dc80c74[$E379394c7b1a273f]['rank'];
		} else {
			echo 'N/A';
		}

		echo '</p>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<h4 class="header-title">Time Played</h4>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="sub-header" id="s_users">';
		echo b8E27ec7C94B1Bc0($dfeb264f9dc80c74[$E379394c7b1a273f]['time']);
		echo '</p>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<h4 class="header-title">Total Streams</h4>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="sub-header" id="s_online">';
		echo number_format($dfeb264f9dc80c74[$E379394c7b1a273f]['connections'], 0);
		echo '</p>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<h4 class="header-title">Total Users</h4>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="sub-header" id="s_online">';
		echo number_format($dfeb264f9dc80c74[$E379394c7b1a273f]['users'], 0);
		echo '</p>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t";
	}
	echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n" . '                ';
}

echo "\t\t\t\t" . '<div class="card-box">' . "\r\n\t\t\t\t\t" . '<ul class="nav nav-tabs nav-bordered nav-justified">' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#servers" data-toggle="tab" aria-expanded="true" class="nav-link active">' . "\r\n\t\t\t\t\t\t\t\t" . 'Active Servers' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';

if ($f523e362fb81d6c8['type'] == 1) {
	echo "\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#sources" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Stream Sources' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';

	if (0 >= count($Ab17a088c3341b0d)) {
	} else {
		echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#adaptive" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Adaptive Link' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
	}

	if (0 >= count($E05d5c8afb9dc282)) {
	} else {
		echo "\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#guide" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Programme Guide' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
	}

	if (!(0 < $f523e362fb81d6c8['tv_archive_server_id'] && 0 < $f523e362fb81d6c8['tv_archive_duration'])) {
	} else {
		echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#archive" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'TV Archive' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
	}

	echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#errors" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Recent Errors' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
} else {
	if ($f523e362fb81d6c8['type'] == 2) {
		echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#information" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Movie Information' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
	} else {
		if ($f523e362fb81d6c8['type'] == 3) {
			echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#sources" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Channel Guide' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
		} else {
			if ($f523e362fb81d6c8['type'] != 5) {
			} else {
				if (!$bbc84f53c534450d) {
				} else {
					echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#s-information" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Series Information' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
				}

				echo '                        <li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#information" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Episode Information' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
			}
		}
	}
}

echo "\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t" . '<div class="tab-content">' . "\r\n\t\t\t\t\t\t" . '<div class="tab-pane active" id="servers">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Source</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Clients</th>' . "\r\n" . '                                            ';

if ($f523e362fb81d6c8['type'] == 2) {
	echo "\t\t\t\t\t\t\t\t\t\t\t" . '<th>Status</th>' . "\r\n" . '                                            ';
} else {
	echo '                                            <th>Uptime</th>' . "\r\n" . '                                            ';
}

echo "\t\t\t\t\t\t\t\t\t\t\t" . '<th>Actions</th>' . "\r\n" . '                                            ';

if ($f523e362fb81d6c8['type'] == 2) {
	echo '                                            <th>Actions</th>' . "\r\n" . '                                            ';
} else {
	echo '                                            <th>';
	echo $c3e4b78793d61beb;
	echo ' Info</th>' . "\r\n" . '                                            ';
}

echo '                                            <th>';
echo $c3e4b78793d61beb;
echo ' Info</th>' . "\r\n" . '                                            <th>';
echo $c3e4b78793d61beb;
echo ' Info</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td colspan="8" class="text-center">Loading information...</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';

if ($f523e362fb81d6c8['type'] == 1) {
	echo "\t\t\t\t\t\t" . '<div class="tab-pane" id="sources">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable-sources" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Order</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Source</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center" style="width:300px;">Stream Info &nbsp;<button onClick="scanSources();" type="button" class="btn btn-xs btn-outline-secondary waves-effect waves-light"><i class="mdi mdi-refresh"></i></button></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
	$Ea22c4a9ab5b2176 = 0;

	foreach (json_decode($f523e362fb81d6c8['stream_source'], true) as $c8d91fcd2309e48a) {
		$Ea22c4a9ab5b2176++;
		$baba170ab02ca0bd = parse_url($c8d91fcd2309e48a)['host'];
		$B47aa6fc6628604a = intval(explode('?', explode('.', explode('/', $c8d91fcd2309e48a)[count(explode('/', $c8d91fcd2309e48a)) - 1])[0])[0]);

		if (0 < $B47aa6fc6628604a) {
			$baba170ab02ca0bd .= ' [ID: ' . $B47aa6fc6628604a . ']';
		} else {
			if (!in_array(strtolower(pathinfo($c8d91fcd2309e48a)['extension']), array('ts', 'm3u8', 'mp4', 'mkv'))) {
			} else {
				$baba170ab02ca0bd .= ' [' . explode('?', explode('/', $c8d91fcd2309e48a)[count(explode('/', $c8d91fcd2309e48a)) - 1])[0] . ']';
			}
		}

		echo "\t\t\t\t\t\t\t\t\t\t" . '<tr class="stream_info" data-id="';
		echo $Ea22c4a9ab5b2176 - 1;
		echo '">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\r\n" . '                                                <button onClick="overrideSource(';
		echo intval(XUI::$rRequest['id']);
		echo ', ';
		echo $Ea22c4a9ab5b2176 - 1;
		echo ');" type="button" title="Override Source" class="tooltip btn btn-info btn-xs waves-effect waves-light btn-fixed-xs">';
		echo $Ea22c4a9ab5b2176;
		echo '</button>' . "\r\n" . '                                            </td>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td><span>';
		echo $baba170ab02ca0bd;
		echo '</span></td>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td class="text-center" id="stream_info_';
		echo $Ea22c4a9ab5b2176 - 1;
		echo '" style="width:300px;">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t\t" . "<table tstyle='width: 300px;' class='table-data' align='center'><tbody><tr><td colspan='4'>Not scanned</td></tr></tbody></table>" . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
	}
	echo "\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';

	if (0 >= count($Ab17a088c3341b0d)) {
	} else {
		$Ab17a088c3341b0d = array_merge(array($f523e362fb81d6c8['id']), $Ab17a088c3341b0d);
		$C437018de91c0402 = $c92aec5c90838930 = array();
		$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Ab17a088c3341b0d)) . ');');

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$c92aec5c90838930[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
		}
		$Fee0d5a474c96306->query('SELECT `stream_id`, `stream_info`, `progress_info` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Ab17a088c3341b0d)) . ') AND `stream_info` IS NOT NULL AND `pid` IS NOT NULL AND `pid` > 0 GROUP BY `stream_id`;');

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$C437018de91c0402[$C740da31596f24ef['stream_id']] = array(json_decode($C740da31596f24ef['stream_info'], true), json_decode($C740da31596f24ef['progress_info'], true));
		}
		echo '                        <div class="tab-pane" id="adaptive">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable-adaptive" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Stream Name</th>' . "\r\n" . '                                            <th class="text-center">Bandwidth</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center" style="width:300px;">Stream Info</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t\t\t";

		foreach ($Ab17a088c3341b0d as $ba78a3ba07e942ec) {
			list($bb0071da5a239b0c, $E7b0c34a84ef92b9) = ($C437018de91c0402[$ba78a3ba07e942ec] ?: array());

			if (isset($bb0071da5a239b0c['codecs']['video'])) {
			} else {
				$bb0071da5a239b0c['codecs']['video'] = array('width' => '?', 'height' => '?', 'codec_name' => 'N/A', 'r_frame_rate' => '--');
			}

			if (isset($bb0071da5a239b0c['codecs']['audio'])) {
			} else {
				$bb0071da5a239b0c['codecs']['audio'] = array('codec_name' => 'N/A');
			}

			if ($bb0071da5a239b0c['bitrate'] != 0) {
			} else {
				$bb0071da5a239b0c['bitrate'] = '?';
			}

			if (isset($E7b0c34a84ef92b9['speed'])) {
				$a31f32f586013061 = floor($E7b0c34a84ef92b9['speed'] * 100) / 100 . 'x';
			} else {
				$a31f32f586013061 = '1x';
			}

			$Fc6b82af9a3c82e5 = null;

			if (isset($E7b0c34a84ef92b9['fps'])) {
				$Fc6b82af9a3c82e5 = intval($E7b0c34a84ef92b9['fps']);
			} else {
				if (!isset($bb0071da5a239b0c['codecs']['video']['r_frame_rate'])) {
				} else {
					$Fc6b82af9a3c82e5 = intval($bb0071da5a239b0c['codecs']['video']['r_frame_rate']);
				}
			}

			if ($Fc6b82af9a3c82e5) {
				if (1000 > $Fc6b82af9a3c82e5) {
				} else {
					$Fc6b82af9a3c82e5 = intval($Fc6b82af9a3c82e5 / 1000);
				}

				$Fc6b82af9a3c82e5 = $Fc6b82af9a3c82e5 . ' FPS';
			} else {
				$Fc6b82af9a3c82e5 = '--';
			}

			$b5e8b95fdf13ba62 = "<table class='table-data nowrap' style='width: 400px;' align='center'><tbody><tr><td class='double'>" . number_format($bb0071da5a239b0c['bitrate'] / 1024, 0) . " Kbps</td><td style='color: #20a009;'><i class='mdi mdi-video' data-name='mdi-video'></i></td><td style='color: #20a009;'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>";

			if ($Eabdab369bae73a8) {
			} else {
				$b5e8b95fdf13ba62 .= "<td style='color: #20a009;'><i class='mdi mdi-play-speed' data-name='mdi-play-speed'></i></td>";
			}

			$b5e8b95fdf13ba62 .= "<td style='color: #20a009;'><i class='mdi mdi-layers' data-name='mdi-layers'></i></td></tr><tr><td class='double'>" . $bb0071da5a239b0c['codecs']['video']['width'] . ' x ' . $bb0071da5a239b0c['codecs']['video']['height'] . '</td><td>' . $bb0071da5a239b0c['codecs']['video']['codec_name'] . '</td><td>' . $bb0071da5a239b0c['codecs']['audio']['codec_name'] . '</td>';

			if ($Eabdab369bae73a8) {
			} else {
				$b5e8b95fdf13ba62 .= '<td>' . $a31f32f586013061 . '</td>';
			}

			$b5e8b95fdf13ba62 .= '<td>' . $Fc6b82af9a3c82e5 . '</td></tr></tbody></table>';
			echo "\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td class="text-center">' . "\r\n" . '                                                <a href="stream_view?id=';
			echo $ba78a3ba07e942ec;
			echo '"><button type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-lg">';
			echo $ba78a3ba07e942ec;
			echo '</button></a>' . "\r\n" . '                                            </td>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td>';
			echo($c92aec5c90838930[$ba78a3ba07e942ec] ?: 'Not Available');
			echo '</td>' . "\r\n" . '                                            <td class="text-center">';
			echo number_format(floatval($bb0071da5a239b0c['bitrate']), 0);
			echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td class="text-center" style="width:400px;">';
			echo $b5e8b95fdf13ba62;
			echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
	}

	if (0 >= count($E05d5c8afb9dc282)) {
	} else {
		$A4d7b7db36f83f3e = false;
		$Fee0d5a474c96306->query('SELECT `server_id`, `direct_source`, `monitor_pid`, `pid`, `stream_status`, `on_demand` FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` WHERE `streams`.`id` = ? AND `server_id` IS NOT NULL;', $f523e362fb81d6c8['id']);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			foreach ($Fee0d5a474c96306->get_rows() as $C2c9bb154c711e06) {
				if (!$C2c9bb154c711e06['server_id'] || $C2c9bb154c711e06['direct_source']) {
				} else {
					$A4d7b7db36f83f3e = true;

					break;
				}
			}
		}

		echo "\t\t\t\t\t\t" . '<div class="tab-pane" id="guide">' . "\r\n\t\t\t\t\t\t\t" . '<div class="inbox-widget slimscroll" style="min-height: 400px;">' . "\r\n\t\t\t\t\t\t\t\t";
		$A0b1211192aba994 = date('Y-m-d');

		foreach ($E05d5c8afb9dc282 as $cfe5858b37d01860) {
			if (date('Y-m-d', $cfe5858b37d01860['start']) == $A0b1211192aba994) {
			} else {
				$A0b1211192aba994 = date('Y-m-d', $cfe5858b37d01860['start']);
				echo '<h4 class="header-title mb-3" style="padding-top: 20px;">' . date('l jS', $cfe5858b37d01860['start']) . '</h4>';
			}

			echo "\t\t\t\t\t\t\t\t" . '<div class="inbox-item">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="inbox-item-author">';
			echo $cfe5858b37d01860['title'];
			echo '</p>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="inbox-item-text" style="margin-top:10px;">';
			echo $cfe5858b37d01860['description'];
			echo '</p>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<p class="inbox-item-date btn-group">' . "\r\n" . '                                        <button class="btn btn-info btn-xs waves-effect waves-light btn-fixed">';
			echo date('H:i', $cfe5858b37d01860['start']);
			echo ' - ';
			echo date('H:i', $cfe5858b37d01860['end']);
			echo '</button>' . "\r\n" . '                                        ';

			if (!$A4d7b7db36f83f3e) {
			} else {
				echo '                                        <a href="record?id=';
				echo intval($f523e362fb81d6c8['id']);
				echo '&programme=';
				echo intval($cfe5858b37d01860['id']);
				echo '"><button class="btn btn-danger btn-xs waves-effect waves-light tooltip" title="Record"><i class="mdi mdi-record"></i></button></a>' . "\r\n" . '                                        ';
			}

			echo "\t\t\t\t\t\t\t\t\t" . '</p><br/>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t";
		}
		echo "\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
	}

	if (!(0 < $f523e362fb81d6c8['tv_archive_server_id'] && 0 < $f523e362fb81d6c8['tv_archive_duration'])) {
	} else {
		$f665b8e041442d05 = E695e82dd6b72236($f523e362fb81d6c8['id']);
		echo '                        <div class="tab-pane" id="archive">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable-archive" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Date</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Title</th>' . "\r\n" . '                                            <th class="text-center">Status</th>' . "\r\n" . '                                            <th class="text-center">Player</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n" . '                                        ';

		foreach ($f665b8e041442d05 as $bb2621204e39e62d) {
			$C5034884ed44603a = $bb2621204e39e62d['end'] - $bb2621204e39e62d['start'];
			$bb2621204e39e62d['stream_id'] = XUI::$rRequest['id'];
			echo "\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n" . '                                            <td class="text-center">';
			echo date($F2d4d8f7981ac574['date_format'], $bb2621204e39e62d['start']);
			echo '<br/>';
			echo date('H:i:s', $bb2621204e39e62d['start']);
			echo ' - ';
			echo date('H:i:s', $bb2621204e39e62d['end']);
			echo '</td>' . "\r\n" . '                                            <td>';
			echo $bb2621204e39e62d['title'];
			echo '</td>' . "\r\n" . '                                            <td class="text-center">' . "\r\n" . '                                                ';

			if ($bb2621204e39e62d['in_progress']) {
				echo "                                                <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>IN PROGRESS</button>" . "\r\n" . '                                                ';
			} else {
				if ($bb2621204e39e62d['complete']) {
					echo "                                                <button type='button' class='btn btn-success btn-xs waves-effect waves-light'>COMPLETE</button>" . "\r\n" . '                                                ';
				} else {
					echo "                                                <button type='button' class='btn btn-warning btn-xs waves-effect waves-light'>INCOMPLETE</button>" . "\r\n" . '                                                ';
				}
			}

			echo '                                                <a href="record?archive=';
			echo urlencode(base64_encode(json_encode($bb2621204e39e62d)));
			echo '"><button class="btn btn-danger btn-xs waves-effect waves-light tooltip" title="Save to VOD"><i class="mdi mdi-record"></i></button></a>' . "\r\n" . '                                            </td>' . "\r\n" . '                                            <td class="text-center"><button type="button" class="btn btn-info waves-effect waves-light btn-xs" onclick="player(';
			echo intval($f523e362fb81d6c8['id']);
			echo ', ';
			echo intval($bb2621204e39e62d['start']);
			echo ', ';
			echo intval($C5034884ed44603a / 60);
			echo ');"><i class="mdi mdi-play"></i></button></td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n" . '                                        ';
		}
		echo "\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
	}

	echo '                        <div class="tab-pane" id="errors">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable-errors" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Date</th>' . "\r\n" . '                                            <th>Message</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n" . '                                        ';

	foreach (Cc5Fab790EAf9d0D($f523e362fb81d6c8['id']) as $bb2621204e39e62d) {
		echo "\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n" . '                                            <td style="width: 80px;" class="text-center">';
		echo date($F2d4d8f7981ac574['datetime_format'], $bb2621204e39e62d['date']);
		echo '</td>' . "\r\n" . "                                            <td onClick='showError(this);' style='cursor: pointer;'>";
		echo $bb2621204e39e62d['error'];
		echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n" . '                                        ';
	}
	echo "\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
} else {
	if ($f523e362fb81d6c8['type'] == 2) {
		echo '                        <div class="tab-pane" id="information">' . "\r\n" . '                            <div class="col-12 input-view">' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="plot">';
		echo $_['plot'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-10">' . "\r\n" . '                                        <textarea readonly rows="6" class="form-control" id="plot" name="plot">';
		echo htmlspecialchars($D92b16dc36690ab9['plot']);
		echo '</textarea>' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="cast">';
		echo $_['cast'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-10">' . "\r\n" . '                                        <input readonly type="text" class="form-control" id="cast" name="cast" value="';
		echo htmlspecialchars($D92b16dc36690ab9['cast']);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="director">';
		echo $_['director'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-4">' . "\r\n" . '                                        <input readonly type="text" class="form-control" id="director" name="director" value="';
		echo htmlspecialchars($D92b16dc36690ab9['director']);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="genre">';
		echo $_['genres'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-4">' . "\r\n" . '                                        <input readonly type="text" class="form-control" id="genre" name="genre" value="';
		echo htmlspecialchars($D92b16dc36690ab9['genre']);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="release_date">';
		echo $_['release_date'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-4">' . "\r\n" . '                                        <input readonly type="text" class="form-control text-center" id="release_date" name="release_date" value="';
		echo htmlspecialchars($D92b16dc36690ab9['release_date']);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="episode_run_time">';
		echo $_['runtime'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-4">' . "\r\n" . '                                        <input readonly type="text" class="form-control text-center" id="episode_run_time" name="episode_run_time" value="';
		echo XUI::f01C2e2CFc16141E(intval($D92b16dc36690ab9['episode_run_time']) * 60, false);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="youtube_trailer">';
		echo $_['youtube_trailer'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-4 input-group">' . "\r\n" . '                                        <input readonly type="text" class="form-control text-center" id="youtube_trailer" name="youtube_trailer" value="';
		echo htmlspecialchars($D92b16dc36690ab9['youtube_trailer']);
		echo '">' . "\r\n" . '                                        <div class="input-group-append">' . "\r\n" . '                                            <a href="javascript:void(0)" onClick="openYouTube(this)" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-eye"></i></a>' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="rating">';
		echo $_['rating'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-4">' . "\r\n" . '                                        <input readonly type="text" class="form-control text-center" id="rating" name="rating" value="';
		echo htmlspecialchars($D92b16dc36690ab9['rating']);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                                <div class="form-group row mb-4">' . "\r\n" . '                                    <label class="col-md-2 col-form-label" for="country">';
		echo $_['country'];
		echo '</label>' . "\r\n" . '                                    <div class="col-md-10">' . "\r\n" . '                                        <input readonly type="text" class="form-control" id="country" name="country" value="';
		echo htmlspecialchars($D92b16dc36690ab9['country']);
		echo '">' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div>' . "\r\n" . '                            </div> ' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
	} else {
		if ($f523e362fb81d6c8['type'] == 5) {
			if (!$bbc84f53c534450d) {
			} else {
				echo '                        <div class="tab-pane" id="s-information">' . "\r\n" . '                            <div class="row">' . "\r\n" . '                                <div class="col-12 input-view">' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="plot">Plot</label>' . "\r\n" . '                                        <div class="col-md-10">' . "\r\n" . '                                            <textarea readonly rows="6" class="form-control" id="plot" name="plot">';
				echo htmlspecialchars($bbc84f53c534450d['plot']);
				echo '</textarea>' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="cast">Cast</label>' . "\r\n" . '                                        <div class="col-md-10">' . "\r\n" . '                                            <input readonly type="text" class="form-control" id="cast" name="cast" value="';
				echo htmlspecialchars($bbc84f53c534450d['cast']);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="director">Director</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="director" name="director" value="';
				echo htmlspecialchars($bbc84f53c534450d['director']);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="genre">Genres</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center " id="genre" name="genre" value="';
				echo htmlspecialchars($bbc84f53c534450d['genre']);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="release_date">Release Date</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="release_date" name="release_date" value="';
				echo htmlspecialchars($bbc84f53c534450d['release_date']);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="episode_run_time">Runtime</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="episode_run_time" name="episode_run_time" value="';
				echo XUI::F01c2E2CfC16141e(intval($D92b16dc36690ab9['episode_run_time']) * 60, false);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="youtube_trailer">Youtube Trailer</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="youtube_trailer" name="youtube_trailer" value="';
				echo htmlspecialchars($bbc84f53c534450d['youtube_trailer']);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="rating">Rating</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="rating" name="rating" value="';
				echo htmlspecialchars($bbc84f53c534450d['rating']);
				echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div> ' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
			}

			echo '                        <div class="tab-pane" id="information">' . "\r\n" . '                            <div class="row">' . "\r\n" . '                                <div class="col-12 input-view">' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="plot">';
			echo $_['plot'];
			echo '</label>' . "\r\n" . '                                        <div class="col-md-10">' . "\r\n" . '                                            <textarea readonly rows="6" class="form-control" id="plot" name="plot">';
			echo htmlspecialchars($D92b16dc36690ab9['plot']);
			echo '</textarea>' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="release_date">';
			echo $_['release_date'];
			echo '</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="release_date" name="release_date" value="';
			echo htmlspecialchars($D92b16dc36690ab9['release_date']);
			echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="episode_run_time">';
			echo $_['runtime'];
			echo '</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="episode_run_time" name="episode_run_time" value="';
			echo XUI::f01C2E2cfC16141e(intval($D92b16dc36690ab9['duration_secs']), false);
			echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                    <div class="form-group row mb-4">' . "\r\n" . '                                        <label class="col-md-2 col-form-label" for="rating">';
			echo $_['rating'];
			echo '</label>' . "\r\n" . '                                        <div class="col-md-4">' . "\r\n" . '                                            <input readonly type="text" class="form-control text-center" id="rating" name="rating" value="';
			echo htmlspecialchars($D92b16dc36690ab9['rating']);
			echo '">' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n" . '                                </div> ' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
		} else {
			if ($f523e362fb81d6c8['type'] != 3) {
			} else {
				if (!$a0e727eef95293df) {
				} else {
					echo '                        <div class="tab-pane" id="sources">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable-sources" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Position</th>' . "\r\n" . '                                            <th>Filename</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Start</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Finish</th>' . "\r\n" . '                                            <th class="text-center">Duration</th>' . "\r\n" . '                                            <th class="text-center">Stream Info</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n" . '                                        ';

					foreach ($a0e727eef95293df as $Caaa4497150f8738) {
						$bc2874292e0d9ece = pathinfo(json_decode($f523e362fb81d6c8['stream_source'], true)[$Caaa4497150f8738['position']])['filename'];
						$Caaa4497150f8738['seconds'] = intval(explode('.', $Caaa4497150f8738['seconds'])[0]);
						$db752e19806388c2 = $Caaa4497150f8738['start'] - $eff3c5536b319f0b;
						$D196f287741e71ee = time() + $db752e19806388c2;
						$ec788d3ffa19091e = $D196f287741e71ee + $Caaa4497150f8738['seconds'];

						if (86400 <= $Caaa4497150f8738['seconds']) {
							$C5034884ed44603a = sprintf('%02dd %02dh %02dm', $Caaa4497150f8738['seconds'] / 86400, ($Caaa4497150f8738['seconds'] / 3600) % 24, ($Caaa4497150f8738['seconds'] / 60) % 60);
						} else {
							$C5034884ed44603a = sprintf('%02dh %02dm %02ds', $Caaa4497150f8738['seconds'] / 3600, ($Caaa4497150f8738['seconds'] / 60) % 60, $Caaa4497150f8738['seconds'] % 60);
						}

						$C5034884ed44603a = "<button type='button' class='btn btn-success btn-xs waves-effect waves-light btn-fixed'>" . $C5034884ed44603a . '</button>';

						if (isset($Caaa4497150f8738['stream_info']['codecs']['video'])) {
						} else {
							$Caaa4497150f8738['stream_info']['codecs']['video'] = array('width' => '?', 'height' => '?', 'codec_name' => 'N/A', 'r_frame_rate' => '--');
						}

						if (isset($Caaa4497150f8738['stream_info']['codecs']['audio'])) {
						} else {
							$Caaa4497150f8738['stream_info']['codecs']['audio'] = array('codec_name' => 'N/A');
						}

						if ($Caaa4497150f8738['stream_info']['bitrate'] != 0) {
						} else {
							$Caaa4497150f8738['stream_info']['bitrate'] = '?';
						}

						$Fc6b82af9a3c82e5 = null;

						if (!isset($Caaa4497150f8738['stream_info']['codecs']['video']['r_frame_rate'])) {
						} else {
							$Fc6b82af9a3c82e5 = intval($Caaa4497150f8738['stream_info']['codecs']['video']['r_frame_rate']);
						}

						if ($Fc6b82af9a3c82e5) {
							if (1000 > $Fc6b82af9a3c82e5) {
							} else {
								$Fc6b82af9a3c82e5 = intval($Fc6b82af9a3c82e5 / 1000);
							}

							$Fc6b82af9a3c82e5 = $Fc6b82af9a3c82e5 . ' FPS';
						} else {
							$Fc6b82af9a3c82e5 = '--';
						}

						$b5e8b95fdf13ba62 = "<table class='table-data nowrap' align='center'><tbody><tr><td class='double'>" . number_format($Caaa4497150f8738['stream_info']['bitrate'] / 1024, 0) . " Kbps</td><td style='color: #20a009;'><i class='mdi mdi-video' data-name='mdi-video'></i></td><td style='color: #20a009;'><i class='mdi mdi-volume-high' data-name='mdi-volume-high'></i></td>";
						$b5e8b95fdf13ba62 .= "<td style='color: #20a009;'><i class='mdi mdi-layers' data-name='mdi-layers'></i></td></tr><tr><td class='double'>" . $Caaa4497150f8738['stream_info']['codecs']['video']['width'] . ' x ' . $Caaa4497150f8738['stream_info']['codecs']['video']['height'] . '</td><td>' . $Caaa4497150f8738['stream_info']['codecs']['video']['codec_name'] . '</td><td>' . $Caaa4497150f8738['stream_info']['codecs']['audio']['codec_name'] . '</td>';
						$b5e8b95fdf13ba62 .= '<td>' . $Fc6b82af9a3c82e5 . '</td></tr></tbody></table>';

						if ($Caaa4497150f8738['start'] <= $eff3c5536b319f0b && $eff3c5536b319f0b < $Caaa4497150f8738['finish']) {
							$Dfa7f7fd6a9f18a8 = '<button type="button" title="Playing Now" class="tooltip btn btn-info btn-xs waves-effect waves-light btn-fixed-xs">' . ($Caaa4497150f8738['position'] + 1) . '</button>';
						} else {
							$Dfa7f7fd6a9f18a8 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xs">' . ($Caaa4497150f8738['position'] + 1) . '</button>';
						}

						echo "\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n" . '                                            <td class="text-center">';
						echo $Dfa7f7fd6a9f18a8;
						echo '</td>' . "\r\n" . '                                            <td>';
						echo $bc2874292e0d9ece;
						echo '</td>' . "\r\n" . '                                            <td class="text-center">';
						echo date('H:i:s', $D196f287741e71ee);
						echo '</td>' . "\r\n" . '                                            <td class="text-center">';
						echo date('H:i:s', $ec788d3ffa19091e);
						echo '</td>' . "\r\n" . '                                            <td class="text-center">';
						echo $C5034884ed44603a;
						echo '</td>' . "\r\n" . '                                            <td class="text-center">';
						echo $b5e8b95fdf13ba62;
						echo '</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n" . '                                        ';
					}
					echo "\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
				}
			}
		}
	}
}

echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div> ' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
