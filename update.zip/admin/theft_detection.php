<?php

include 'session.php';
include 'functions.php';

if (b1882df698b44754()) {
} else {
	B46F5dd76f3C7421();
}

$c049b11cb92e6052 = (intval(XUI::$rRequest['range']) ?: 0);
$d32b403f54c66050 = (igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'theft_detection')) ?: array());
$bcf587bb39f95fd5 = 'VOD Theft Detection';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n" . '                    <div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">VOD Theft Detection</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n\t\t\t\t\t\t" . '<div class="form-group row mb-4">' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-7">' . "\r\n\t\t\t\t\t\t\t\t" . '<input type="text" class="form-control" id="log_search" value="" placeholder="Search Logs...">' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t\t\t" . '<select id="range" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value="0"';

if ($c049b11cb92e6052 != 0) {
} else {
	echo ' selected';
}

echo '>All Time</option>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<option value="604800"';

if ($c049b11cb92e6052 != 604800) {
} else {
	echo ' selected';
}

echo '>Last 7 Days</option>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<option value="86400"';

if ($c049b11cb92e6052 != 86400) {
} else {
	echo ' selected';
}

echo '>Last 24 Hours</option>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<option value="3600"';

if ($c049b11cb92e6052 != 3600) {
} else {
	echo ' selected';
}

echo '>Last Hour</option>' . "\r\n\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-md-2">' . "\r\n\t\t\t\t\t\t\t\t" . '<select id="show_entries" class="form-control" data-toggle="select2">' . "\r\n\t\t\t\t\t\t\t\t\t";

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo "\t\t\t\t\t\t\t\t\t" . '<option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\r\n\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t" . '</select>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">User ID</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Username</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">View Count</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Actions</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody>' . "\r\n" . '                                ';

foreach ($d32b403f54c66050[$c049b11cb92e6052] as $C740da31596f24ef) {
	if ($c049b11cb92e6052 == 0) {
		$ebab77ef4bee81e0 = '<a href="line_activity?search=' . $C740da31596f24ef['username'] . '"><button type="button" class="btn btn-light waves-effect waves-light btn-xs">View Logs</button></a>';
	} else {
		$A4bd0a6b74593fdb = date($F2d4d8f7981ac574['date_format'], time() - intval($c049b11cb92e6052)) . ' - ' . date($F2d4d8f7981ac574['date_format'], time());
		$ebab77ef4bee81e0 = '<a href="line_activity?search=' . $C740da31596f24ef['username'] . '&dates=' . $A4bd0a6b74593fdb . '"><button type="button" class="btn btn-light waves-effect waves-light btn-xs">View Logs</button></a>';
	}

	if (aACD47d8157A1a09('adv', 'edit_user')) {
		$C3c8913edb801c35 = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['user_id'] . '</a>';
		$a71afc14d6cd090d = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
	} else {
		$C3c8913edb801c35 = $C740da31596f24ef['user_id'];
		$a71afc14d6cd090d = $C740da31596f24ef['username'];
	}

	echo '                                    <tr>' . "\r\n" . '                                        <td class="text-center">';
	echo $C3c8913edb801c35;
	echo '</td>' . "\r\n" . '                                        <td>';
	echo $a71afc14d6cd090d;
	echo '</td>' . "\r\n" . '                                        <td class="text-center">';
	echo $C740da31596f24ef['vod_count'];
	echo '</td>' . "\r\n" . '                                        <td class="text-center">';
	echo $ebab77ef4bee81e0;
	echo '</td>' . "\r\n" . '                                    </tr>' . "\r\n" . '                                ';
}
echo '                            </tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
