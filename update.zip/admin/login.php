<?php

include 'functions.php';

// Dragon Shield Media PRO Login Page
// Required assets:
// - Logo: assets/images/logo-dragon-shield.png (physical path: /home/xui/admin/assets/images/logo-dragon-shield.png)
// - Video: assets/video/bg.mp4 (physical path: /home/xui/admin/assets/video/bg.mp4)

if (!file_exists(TMP_PATH . '.migration.first')) {
} else {
	header('Location: setup');
}

if (!isset($_SESSION['hash'])) {
	session_start();

	if (!($b175c78ed63c25a1 = in_array(E787D2298dBDa85D(), array('setup', 'rescue')))) {
	} else {
		$F2d4d8f7981ac574['recaptcha_enable'] = false;
	}

	$c59ec257c284c894 = C7afd69EDc2A2940();

	if (0 >= intval($F2d4d8f7981ac574['login_flood'])) {
	} else {
		$Fee0d5a474c96306->query("SELECT COUNT(`id`) AS `count` FROM `login_logs` WHERE `status` = 'INVALID_LOGIN' AND `login_ip` = ? AND TIME_TO_SEC(TIMEDIFF(NOW(), `date`)) <= 86400;", $c59ec257c284c894);

		if ($Fee0d5a474c96306->num_rows() != 1) {
		} else {
			if (intval($F2d4d8f7981ac574['login_flood']) > intval($Fee0d5a474c96306->get_row()['count'])) {
			} else {
				API::c638aD4F75FF57A6(array('ip' => $c59ec257c284c894, 'notes' => 'LOGIN FLOOD ATTACK'));
				exit();
			}
		}
	}

	if (!isset(XUI::$rRequest['login'])) {
	} else {
		$a85e1b7d42c346a0 = API::f2E77D2f6CE1E2eE(XUI::$rRequest, $b175c78ed63c25a1);
		$B4a5f8dc1f8d260c = $a85e1b7d42c346a0['status'];

		if ($B4a5f8dc1f8d260c != STATUS_SUCCESS) {
		} else {
			if (E787d2298dbDa85d() == 'setup') {
				header('Location: codes');
				exit();
			}

			if (0 < strlen(XUI::$rRequest['referrer'])) {
				$a3486ca94f1ff0e2 = basename(XUI::$rRequest['referrer']);

				if (substr($a3486ca94f1ff0e2, 0, 6) != 'logout') {
				} else {
					$a3486ca94f1ff0e2 = 'dashboard';
				}

				header('Location: ' . $a3486ca94f1ff0e2);
				exit();
			}

			header('Location: dashboard');
			exit();
		}
	}

	echo '<!DOCTYPE html>' . "\n" . '<html lang="en">' . "\n" . '    <head>' . "\n" . '        <meta charset="utf-8" />' . "\n" . '        <title data-id="login">XUI | ';
	echo $_['login'];
	echo '</title>' . "\n" . '        <meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\n" . '        <meta http-equiv="X-UA-Compatible" content="IE=edge" />' . "\n" . '        <link rel="shortcut icon" href="assets/images/favicon.ico">' . "\n\t\t" . '<link href="assets/css/icons.css" rel="stylesheet" type="text/css" />' . "\n" . '        ';

	if (isset($_COOKIE['theme']) && $_COOKIE['theme'] == 1) {
		echo "\t\t" . '<link href="assets/css/bootstrap.dark.css" rel="stylesheet" type="text/css" />' . "\n" . '        <link href="assets/css/app.dark.css" rel="stylesheet" type="text/css" />' . "\n" . '        ';
	} else {
		echo '        <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" />' . "\n" . '        <link href="assets/css/app.css" rel="stylesheet" type="text/css" />' . "\n" . '        ';
	}

	echo '        <link href="assets/css/extra.css" rel="stylesheet" type="text/css" />' . "\n\t\t";
	echo '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">' . "\n\t\t";
	echo '<style>' . "\n";
	echo '        .g-recaptcha {' . "\n" . '            display: inline-block;' . "\n" . '        }' . "\n";
	echo '        .vertical-center {' . "\n" . '            margin: 0;' . "\n" . '            position: absolute;' . "\n" . '            top: 50%;' . "\n" . '            -ms-transform: translateY(-50%);' . "\n" . '            transform: translateY(-50%);' . "\n" . '            width: 100%;' . "\n" . '        }' . "\n";
	
	// Dragon Shield Custom Styles
	echo '        /* Dragon Shield Split Layout */' . "\n";
	echo '        body {' . "\n";
	echo '            font-family: "Inter", sans-serif !important;' . "\n";
	echo '            background: #0a0a0a !important;' . "\n";
	echo '            margin: 0;' . "\n";
	echo '            padding: 0;' . "\n";
	echo '            overflow: hidden;' . "\n";
	echo '            height: 100vh;' . "\n";
	echo '        }' . "\n";
	
	echo '        .body-full {' . "\n";
	echo '            background: transparent !important;' . "\n";
	echo '            position: relative;' . "\n";
	echo '            z-index: 10;' . "\n";
	echo '            width: 26%;' . "\n";
	echo '            height: 100vh;' . "\n";
	echo '            float: left;' . "\n";
	echo '            background: linear-gradient(135deg, rgba(3, 5, 11, 0.95) 0%, rgba(4, 8, 16, 0.9) 50%, rgba(8, 15, 35, 0.85) 100%) !important;' . "\n";
	echo '            backdrop-filter: blur(20px);' . "\n";
	echo '        }' . "\n";
	
	echo '        .body-full::before {' . "\n";
	echo '            content: "";' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            top: 0;' . "\n";
	echo '            left: 0;' . "\n";
	echo '            right: 0;' . "\n";
	echo '            bottom: 0;' . "\n";
	echo '            background: linear-gradient(45deg, rgba(0, 32, 96, 0.1) 0%, rgba(0, 48, 144, 0.05) 100%);' . "\n";
	echo '            pointer-events: none;' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-right-panel {' . "\n";
	echo '            position: fixed;' . "\n";
	echo '            top: 0;' . "\n";
	echo '            right: 0;' . "\n";
	echo '            width: 74%;' . "\n";
	echo '            height: 100vh;' . "\n";
	echo '            background: linear-gradient(45deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);' . "\n";
	echo '            z-index: 1;' . "\n";
	echo '            overflow: hidden;' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-video {' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            top: 0;' . "\n";
	echo '            left: 0;' . "\n";
	echo '            width: 100%;' . "\n";
	echo '            height: 100%;' . "\n";
	echo '            object-fit: cover;' . "\n";
	echo '            filter: brightness(0.7) contrast(1.2);' . "\n";
	echo '            z-index: 1;' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-video-overlay {' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            top: 0;' . "\n";
	echo '            left: 0;' . "\n";
	echo '            right: 0;' . "\n";
	echo '            bottom: 0;' . "\n";
	echo '            background: linear-gradient(135deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.3) 50%, rgba(0, 0, 0, 0.2) 100%);' . "\n";
	echo '            z-index: 2;' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-particles {' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            top: 0;' . "\n";
	echo '            left: 0;' . "\n";
	echo '            width: 100%;' . "\n";
	echo '            height: 100%;' . "\n";
	echo '            pointer-events: none;' . "\n";
	echo '            z-index: 5;' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-particle {' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            background: radial-gradient(circle, rgba(220, 20, 60, 0.8) 0%, transparent 70%);' . "\n";
	echo '            border-radius: 50%;' . "\n";
	echo '            animation: dragonParticleFloat 6s infinite linear;' . "\n";
	echo '        }' . "\n";
	
	echo '        @keyframes dragonParticleFloat {' . "\n";
	echo '            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }' . "\n";
	echo '            10% { opacity: 1; }' . "\n";
	echo '            90% { opacity: 1; }' . "\n";
	echo '            100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }' . "\n";
	echo '        }' . "\n";
	
	echo '        .account-pages {' . "\n";
	echo '            backdrop-filter: blur(20px);' . "\n";
	echo '            height: 100vh;' . "\n";
	echo '            display: flex;' . "\n";
	echo '            align-items: center;' . "\n";
	echo '        }' . "\n";
	
	echo '        .container {' . "\n";
	echo '            width: calc(100% - 30px) !important;' . "\n";
	echo '            max-width: none !important;' . "\n";
	echo '            padding: 25px;' . "\n";
	echo '        }' . "\n";
	
	echo '        .col-md-8.col-lg-6.col-xl-5 {' . "\n";
	echo '            flex: 0 0 100%;' . "\n";
	echo '            max-width: 100%;' . "\n";
	echo '        }' . "\n";
	
	echo '        .vertical-center {' . "\n";
	echo '            position: static !important;' . "\n";
	echo '            transform: none !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        @media (max-width: 768px) {' . "\n";
	echo '            .body-full { width: 100%; }' . "\n";
	echo '            .dragon-right-panel { display: none; }' . "\n";
	echo '            .container { padding: 15px; }' . "\n";
	echo '            .dragon-title { font-size: 1.0rem; }' . "\n";
	echo '            .card-body { padding: 18px !important; }' . "\n";
	echo '        }' . "\n";
	
	echo '        @keyframes dragonFloat {' . "\n";
	echo '            0%, 100% { transform: translateY(0px); }' . "\n";
	echo '            50% { transform: translateY(-10px); }' . "\n";
	echo '        }' . "\n";
	
	echo '        .card {' . "\n";
	echo '            background: rgba(255, 255, 255, 0.05) !important;' . "\n";
	echo '            backdrop-filter: blur(20px) !important;' . "\n";
	echo '            border: 1px solid rgba(255, 255, 255, 0.1) !important;' . "\n";
	echo '            border-radius: 20px !important;' . "\n";
	echo '            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5) !important;' . "\n";
	echo '            position: relative;' . "\n";
	echo '            animation: dragonSlideIn 0.8s ease;' . "\n";
	echo '            z-index: 15;' . "\n";
	echo '            margin: 0;' . "\n";
	echo '            overflow: hidden;' . "\n";
	echo '        }' . "\n";
	
	echo '        .card-body {' . "\n";
	echo '            padding: 25px !important;' . "\n";
	echo '            position: relative;' . "\n";
	echo '        }' . "\n";
	
	echo '        @keyframes dragonSlideIn {' . "\n";
	echo '            from { opacity: 0; transform: translateY(30px); }' . "\n";
	echo '            to { opacity: 1; transform: translateY(0); }' . "\n";
	echo '        }' . "\n";
	
	echo '        .card::before {' . "\n";
	echo '            content: "";' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            top: -2px;' . "\n";
	echo '            left: -2px;' . "\n";
	echo '            right: -2px;' . "\n";
	echo '            bottom: -2px;' . "\n";
	echo '            background: linear-gradient(135deg, rgba(220, 20, 60, 0.4) 0%, rgba(255, 215, 0, 0.3) 50%, rgba(220, 20, 60, 0.4) 100%);' . "\n";
	echo '            border-radius: 20px;' . "\n";
	echo '            z-index: -1;' . "\n";
	echo '            opacity: 0;' . "\n";
	echo '            transition: opacity 0.3s ease;' . "\n";
	echo '            animation: dragonGlow 3s ease-in-out infinite;' . "\n";
	echo '        }' . "\n";
	
	echo '        @keyframes dragonGlow {' . "\n";
	echo '            0%, 100% { opacity: 0; }' . "\n";
	echo '            50% { opacity: 0.3; }' . "\n";
	echo '        }' . "\n";
	
	echo '        .card:hover::before {' . "\n";
	echo '            opacity: 0.6 !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        }' . "\n";
	
	echo '        .dragon-logo {' . "\n";
	echo '            max-height: 90px !important;' . "\n";
	echo '            height: auto !important;' . "\n";
	echo '            width: auto !important;' . "\n";
	echo '            max-width: calc(100% - 40px) !important;' . "\n";
	echo '            margin: 0 auto 15px auto !important;' . "\n";
	echo '            padding: 0 20px !important;' . "\n";
	echo '            display: block !important;' . "\n";
	echo '            filter: drop-shadow(0 5px 15px rgba(220, 20, 60, 0.3)) !important;' . "\n";
	echo '            animation: dragonFloat 3s ease-in-out infinite !important;' . "\n";
	echo '            box-sizing: border-box !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        .form-control {' . "\n";
	echo '            background: rgba(255, 255, 255, 0.05) !important;' . "\n";
	echo '            border: 1px solid rgba(255, 255, 255, 0.1) !important;' . "\n";
	echo '            border-radius: 12px !important;' . "\n";
	echo '            color: #fff !important;' . "\n";
	echo '            backdrop-filter: blur(10px);' . "\n";
	echo '            transition: all 0.3s ease;' . "\n";
	echo '            padding: 15px 20px;' . "\n";
	echo '        }' . "\n";
	
	echo '        .form-control:focus {' . "\n";
	echo '            border-color: rgba(220, 20, 60, 0.5) !important;' . "\n";
	echo '            box-shadow: 0 0 20px rgba(220, 20, 60, 0.2) !important;' . "\n";
	echo '            background: rgba(255, 255, 255, 0.08) !important;' . "\n";
	echo '            transform: scale(1.02);' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-focused label {' . "\n";
	echo '            color: #dc143c !important;' . "\n";
	echo '            text-shadow: 0 0 10px rgba(220, 20, 60, 0.3);' . "\n";
	echo '        }' . "\n";
	
	echo '        .form-control::placeholder {' . "\n";
	echo '            color: rgba(255, 255, 255, 0.5) !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        label {' . "\n";
	echo '            color: rgba(255, 255, 255, 0.9) !important;' . "\n";
	echo '            font-weight: 500;' . "\n";
	echo '            letter-spacing: 0.3px;' . "\n";
	echo '            margin-bottom: 8px !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        .btn {' . "\n";
	echo '            background: linear-gradient(135deg, #dc143c 0%, #ff4757 100%) !important;' . "\n";
	echo '            border: none !important;' . "\n";
	echo '            border-radius: 12px !important;' . "\n";
	echo '            color: #fff !important;' . "\n";
	echo '            font-weight: 600;' . "\n";
	echo '            text-transform: uppercase;' . "\n";
	echo '            letter-spacing: 1px;' . "\n";
	echo '            position: relative;' . "\n";
	echo '            overflow: hidden;' . "\n";
	echo '            transition: all 0.3s ease;' . "\n";
	echo '            padding: 18px 30px;' . "\n";
	echo '            font-size: 1rem;' . "\n";
	echo '            margin-top: 20px;' . "\n";
	echo '        }' . "\n";
	
	echo '        .btn::before {' . "\n";
	echo '            content: "";' . "\n";
	echo '            position: absolute;' . "\n";
	echo '            top: 0;' . "\n";
	echo '            left: -100%;' . "\n";
	echo '            width: 100%;' . "\n";
	echo '            height: 100%;' . "\n";
	echo '            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);' . "\n";
	echo '            transition: left 0.5s;' . "\n";
	echo '        }' . "\n";
	
	echo '        .btn:hover:not(:disabled) {' . "\n";
	echo '            transform: translateY(-2px) !important;' . "\n";
	echo '            box-shadow: 0 15px 30px rgba(220, 20, 60, 0.4) !important;' . "\n";
	echo '            background: linear-gradient(135deg, #dc143c 0%, #ff4757 100%) !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        .btn:hover:not(:disabled)::before {' . "\n";
	echo '            left: 100%;' . "\n";
	echo '        }' . "\n";
	
	echo '        .btn:disabled {' . "\n";
	echo '            background: rgba(255, 255, 255, 0.1) !important;' . "\n";
	echo '            cursor: not-allowed;' . "\n";
	echo '            transform: none !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        .form-group {' . "\n";
	echo '            margin-bottom: 20px;' . "\n";
	echo '        }' . "\n";
	
	echo '        .alert {' . "\n";
	echo '            backdrop-filter: blur(10px);' . "\n";
	echo '            border-radius: 12px !important;' . "\n";
	echo '            border-left: 4px solid !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        .alert-danger {' . "\n";
	echo '            background: rgba(220, 20, 60, 0.1) !important;' . "\n";
	echo '            border-color: #dc143c !important;' . "\n";
	echo '            color: #ff6b7a !important;' . "\n";
	echo '        }' . "\n";
	
	// Dragon Shield Branding
	echo '        .dragon-title {' . "\n";
	echo '            font-size: 1.2rem;' . "\n";
	echo '            font-weight: 700;' . "\n";
	echo '            background: linear-gradient(135deg, #dc143c 0%, #ffd700 50%, #dc143c 100%);' . "\n";
	echo '            background-size: 200% 200%;' . "\n";
	echo '            -webkit-background-clip: text;' . "\n";
	echo '            -webkit-text-fill-color: transparent;' . "\n";
	echo '            background-clip: text;' . "\n";
	echo '            margin: 8px 0 5px 0;' . "\n";
	echo '            letter-spacing: -0.3px;' . "\n";
	echo '            text-align: center;' . "\n";
	echo '            animation: dragonGradientShift 3s ease-in-out infinite;' . "\n";
	echo '            line-height: 1.2;' . "\n";
	echo '            display: block !important;' . "\n";
	echo '            visibility: visible !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        @keyframes dragonGradientShift {' . "\n";
	echo '            0%, 100% { background-position: 0% 50%; }' . "\n";
	echo '            50% { background-position: 100% 50%; }' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-subtitle {' . "\n";
	echo '            color: rgba(255, 255, 255, 0.7);' . "\n";
	echo '            font-size: 0.75rem;' . "\n";
	echo '            font-weight: 400;' . "\n";
	echo '            text-align: center;' . "\n";
	echo '            margin-bottom: 0;' . "\n";
	echo '            animation: dragonFadeIn 1s ease 0.5s both;' . "\n";
	echo '            line-height: 1.3;' . "\n";
	echo '            display: block !important;' . "\n";
	echo '            visibility: visible !important;' . "\n";
	echo '        }' . "\n";
	
	echo '        @keyframes dragonFadeIn {' . "\n";
	echo '            from { opacity: 0; transform: translateY(10px); }' . "\n";
	echo '            to { opacity: 1; transform: translateY(0); }' . "\n";
	echo '        }' . "\n";
	
	echo '        .dragon-copyright {' . "\n";
	echo '            text-align: center;' . "\n";
	echo '            margin-top: 20px;' . "\n";
	echo '            color: rgba(255, 255, 255, 0.6);' . "\n";
	echo '            font-size: 0.7rem;' . "\n";
	echo '            font-weight: 400;' . "\n";
	echo '            letter-spacing: 0.5px;' . "\n";
	echo '            animation: dragonFadeIn 1s ease 1s both;' . "\n";
	echo '        }' . "\n";
	
	echo "\t\t" . '</style>' . "\n" . '    </head>' . "\n" . '    <body class="bg-animate';

	if (!(isset($_COOKIE['hue']) && 0 < strlen($_COOKIE['hue']) && in_array($_COOKIE['hue'], array_keys($a0bf9d3bd74d9b1f)))) {
	} else {
		echo '-' . $_COOKIE['hue'];
	}

	echo '">' . "\n" . '        <div class="body-full navbar-custom">' . "\n" . '            <div class="account-pages vertical-center">' . "\n" . '                <div class="container">' . "\n" . '                    <div class="row justify-content-center">' . "\n" . '                        <div class="col-md-8 col-lg-6 col-xl-5">' . "\n";
	
	echo '                            ';

	if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_FAILURE) {
		echo '                            <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">' . "\n" . '                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . "\n" . '                                ';
		echo $_['login_message_1'];
		echo '                            </div>' . "\n" . '                            ';
	} else {
		if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_INVALID_CODE) {
			echo '                            <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">' . "\n" . '                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . "\n" . '                                ';
			echo $_['login_message_2'];
			echo '                            </div>' . "\n" . '                            ';
		} else {
			if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_NOT_ADMIN) {
				echo '                            <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">' . "\n" . '                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . "\n" . '                                ';
				echo $_['login_message_3'];
				echo '                            </div>' . "\n" . '                            ';
			} else {
				if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_DISABLED) {
					echo '                            <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">' . "\n" . '                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . "\n" . '                                ';
					echo $_['login_message_4'];
					echo '                            </div>' . "\n" . '                            ';
				} else {
					if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_INVALID_CAPTCHA)) {
					} else {
						echo '                            <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">' . "\n" . '                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . "\n" . '                                ';
						echo $_['login_message_5'];
						echo '                            </div>' . "\n" . '                            ';
					}
				}
			}
		}
	}

	echo '                            <form action="./login" method="POST" data-parsley-validate="">' . "\n" . '                                <div class="card">' . "\n" . '                                    <div class="card-body p-4">' . "\n";
	echo '                                        <div class="text-center mb-4">' . "\n";
	echo '                                            <img src="assets/images/logo-dragon-shield.png" alt="Dragon Shield Logo" class="dragon-logo">' . "\n";
	echo '                                            <h2 class="dragon-title">Dragon Shield Media PRO</h2>' . "\n";
	echo '                                            <p class="dragon-subtitle">Advanced Media Management Platform</p>' . "\n";
	echo '                                        </div>' . "\n";
	echo '                                        <input type="hidden" name="referrer" value="';
	echo htmlspecialchars(XUI::$rRequest['referrer']);
	echo '" />' . "\n" . '                                        <div class="form-group mb-3" id="username_group">' . "\n" . '                                            <label for="username">';
	echo $_['username'];
	echo '</label>' . "\n" . '                                            <input class="form-control" autocomplete="off" type="text" id="username" name="username" required data-parsley-trigger="change" placeholder="">' . "\n" . '                                        </div>' . "\n" . '                                        <div class="form-group mb-3">' . "\n" . '                                            <label for="password">';
	echo $_['password'];
	echo '</label>' . "\n" . '                                            <input class="form-control" autocomplete="off" type="password" required data-parsley-trigger="change" id="password" name="password" placeholder="">' . "\n" . '                                        </div>' . "\n" . '                                        ';

	if (!$F2d4d8f7981ac574['recaptcha_enable']) {
	} else {
		echo '                                        <h5 class="auth-title text-center" style="margin-bottom:0;">' . "\n" . '                                            <div class="g-recaptcha" data-callback="recaptchaCallback" id="verification" data-sitekey="';
		echo $F2d4d8f7981ac574['recaptcha_v2_site_key'];
		echo '"></div>' . "\n" . '                                        </h5>' . "\n" . '                                        ';
	}

	echo '                                        <div class="form-group mb-0 text-center">' . "\n" . '                                            <button style="border:0" class="btn btn-info ';

	if (isset($_COOKIE['hue']) && 0 < strlen($_COOKIE['hue']) && in_array($_COOKIE['hue'], array_keys($a0bf9d3bd74d9b1f))) {
		echo 'bg-animate-' . $_COOKIE['hue'];
	} else {
		echo 'bg-animate-info';
	}

	echo ' btn-block" type="submit" id="login_button" name="login"';

	if (!$F2d4d8f7981ac574['recaptcha_enable']) {
	} else {
		echo ' disabled';
	}

	echo '>';
	echo $_['login'];
	echo '</button>' . "\n" . '                                        </div>' . "\n";
	echo '                                        <div class="dragon-copyright">Dragon Shield © 2025 All Rights Reserved</div>' . "\n";
	echo '                                    </div>' . "\n" . '                                </div>' . "\n" . '                            </form>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '        </div>' . "\n";
	
	// Dragon Shield Right Panel with Video
	echo '        <div class="dragon-right-panel">' . "\n";
	echo '            <video class="dragon-video" autoplay muted loop>' . "\n";
	echo '                <source src="assets/video/bg.mp4" type="video/mp4">' . "\n";
	echo '                Your browser does not support HTML5 video.' . "\n";
	echo '            </video>' . "\n";
	echo '            <div class="dragon-video-overlay"></div>' . "\n";
	echo '        </div>' . "\n";
	
	// Dragon Shield Particles for Left Panel
	echo '        <div class="dragon-particles" id="dragonParticles" style="position: fixed; top: 0; left: 0; width: 26%; height: 100vh; pointer-events: none; z-index: 5;"></div>' . "\n";
	
	echo '        <script src="assets/js/vendor.min.js"></script>' . "\n" . '        <script src="assets/libs/parsleyjs/parsley.min.js"></script>' . "\n" . '        <script src="assets/js/app.min.js"></script>' . "\n\t\t";

	if (!$F2d4d8f7981ac574['recaptcha_enable']) {
	} else {
		echo "\t\t" . '<script src="https://www.google.com/recaptcha/api.js" async defer></script>' . "\n\t\t";
	}

	echo '        <script>' . "\n";
	echo '        function recaptchaCallback() {' . "\n" . "            \$('#login_button').removeAttr('disabled');" . "\n" . '        };' . "\n";
	
	// Dragon Shield Particles Animation
	echo '        function createDragonParticle() {' . "\n";
	echo '            const particle = document.createElement("div");' . "\n";
	echo '            particle.className = "dragon-particle";' . "\n";
	echo '            const size = Math.random() * 4 + 2;' . "\n";
	echo '            const startPosition = Math.random() * 100;' . "\n";
	echo '            const animationDuration = Math.random() * 3 + 4;' . "\n";
	echo '            particle.style.width = size + "px";' . "\n";
	echo '            particle.style.height = size + "px";' . "\n";
	echo '            particle.style.left = startPosition + "%";' . "\n";
	echo '            particle.style.animationDuration = animationDuration + "s";' . "\n";
	echo '            const particlesContainer = document.getElementById("dragonParticles");' . "\n";
	echo '            if (particlesContainer) {' . "\n";
	echo '                particlesContainer.appendChild(particle);' . "\n";
	echo '                setTimeout(() => {' . "\n";
	echo '                    if (particle.parentNode) particle.remove();' . "\n";
	echo '                }, animationDuration * 1000);' . "\n";
	echo '            }' . "\n";
	echo '        }' . "\n";
	
	echo '        // Initialize Dragon Shield effects' . "\n";
	echo '        document.addEventListener("DOMContentLoaded", function() {' . "\n";
	echo '            setInterval(createDragonParticle, 300);' . "\n";
	
	// Form enhancements
	echo '            document.querySelectorAll(".form-control").forEach(input => {' . "\n";
	echo '                input.addEventListener("focus", function() {' . "\n";
	echo '                    this.parentElement.classList.add("dragon-focused");' . "\n";
	echo '                });' . "\n";
	echo '                input.addEventListener("blur", function() {' . "\n";
	echo '                    this.parentElement.classList.remove("dragon-focused");' . "\n";
	echo '                });' . "\n";
	echo '            });' . "\n";
	
	// Button loading effect - FIXED
	echo '            const form = document.querySelector("form[data-parsley-validate]");' . "\n";
	echo '            if (form) {' . "\n";
	echo '                form.addEventListener("submit", function(e) {' . "\n";
	echo '                    const button = document.getElementById("login_button");' . "\n";
	echo '                    if (button && !button.disabled) {' . "\n";
	echo '                        const originalText = button.innerHTML;' . "\n";
	echo '                        button.innerHTML = "<span style=\"opacity: 0.7;\">Logging in...</span>";' . "\n";
	echo '                        button.style.pointerEvents = "none";' . "\n";
	echo '                        // Do not prevent default - let form submit normally' . "\n";
	echo '                    }' . "\n";
	echo '                });' . "\n";
	echo '            }' . "\n";
	echo '        });' . "\n";
	
	echo '        </script>' . "\n" . '    </body>' . "\n" . '</html>';
} else {
	header('Location: dashboard');
	exit();
}
?>