<?php

include 'session.php';
include 'functions.php';

if ($Dde20813a43b39a3[$D4253f9520627819['theme']]['dark']) {
	$A97781a69ffc0557 = array(1 => array('secondary', '#7e8e9d', '#ffffff'), 2 => array('secondary', '#7e8e9d', '#ffffff'), 3 => array('secondary', '#7e8e9d', '#ffffff'), 4 => array('secondary', '#7e8e9d', '#ffffff'));
	$A3f4b30945caee8c = array(array('#7e8e9d', 'bg-map-dark-1'), array('#6c7b8a', 'bg-map-dark-2'), array('#5a6977', 'bg-map-dark-3'), array('#485765', 'bg-map-dark-4'), array('#374654', 'bg-map-dark-5'), array('#273643', 'bg-map-dark-6'));
} else {
	$A97781a69ffc0557 = array(1 => array('purple', '#675db7', '#675db7'), 2 => array('success', '#23b397', '#23b397'), 3 => array('pink', '#e36498', '#e36498'), 4 => array('info', '#56C3D6', '#56C3D6'));
	$A3f4b30945caee8c = array(array('#23b397', 'bg-success'), array('#56c2d6', 'bg-info'), array('#5089de', 'bg-primary'), array('#675db7', 'bg-purple'), array('#e36498', 'bg-pink'), array('#98a6ad', 'bg-secondary'));
}

if (!isset(XUI::$rRequest['server_id']) || isset($a8bb73cba48fb7f6[XUI::$rRequest['server_id']])) {
} else {
	B46F5dd76F3C7421();
}

$C7dc44e2b269673a = array();
$bde5957fb5fa9547 = 0;

if (isset(XUI::$rRequest['server_id'])) {
	$Fee0d5a474c96306->query('SELECT `geoip_country_code`, COUNT(`geoip_country_code`) AS `count` FROM `lines_activity` WHERE (`server_id` = ? OR `proxy_id` = ?) GROUP BY `geoip_country_code` ORDER BY `count` DESC;', intval(XUI::$rRequest['server_id']), intval(XUI::$rRequest['server_id']));
} else {
	$Fee0d5a474c96306->query('SELECT `geoip_country_code`, COUNT(`geoip_country_code`) AS `count` FROM `lines_activity` GROUP BY `geoip_country_code` ORDER BY `count` DESC;');
}

if (0 >= $Fee0d5a474c96306->num_rows()) {
} else {
	$Ea22c4a9ab5b2176 = 0;

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($Ea22c4a9ab5b2176 < count($A3f4b30945caee8c)) {
			$C740da31596f24ef['colour'] = $A3f4b30945caee8c[$Ea22c4a9ab5b2176];
		} else {
			$C740da31596f24ef['colour'] = $A3f4b30945caee8c[count($A3f4b30945caee8c) - 1];
		}

		if (isset($Deba92a26931982d[$C740da31596f24ef['geoip_country_code']])) {
			$C740da31596f24ef['name'] = $Deba92a26931982d[$C740da31596f24ef['geoip_country_code']];
		} else {
			$C740da31596f24ef['name'] = 'Unknown Country';
		}

		$bde5957fb5fa9547 += $C740da31596f24ef['count'];
		$C7dc44e2b269673a[] = $C740da31596f24ef;
		$Ea22c4a9ab5b2176++;
	}
}

if (isset(XUI::$rRequest['server_id'])) {
} else {
	$E400a3101514583e = 3600;
	$C4af185e24cf9086 = time();
	$B34176766a53ef44 = $C4af185e24cf9086 - $E400a3101514583e;
	$b7a45be2d6027d36 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `servers_stats` WHERE `time` >= ? ORDER BY `time` ASC;', $B34176766a53ef44);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$b7a45be2d6027d36[intval($C740da31596f24ef['server_id'])][] = $C740da31596f24ef['cpu'];
		}
	}
}

$Dbc0b343dc249303 = $a8bb73cba48fb7f6;
array_multisort(array_column($Dbc0b343dc249303, 'order'), SORT_ASC, $Dbc0b343dc249303);

if ($D8d681f377d877d4) {
	$d4977dad729c72de = 'Trial';
} else {
	if ($Ab5b854e25293d6b) {
		$d4977dad729c72de = 'Beta License';
	} else {
		$d4977dad729c72de = 'License';
	}
}

/*=================================================================*/
/* Incepe aici partea cu pagina ce insereaza Header si Dashboardul.*/
/*=================================================================*/

$bcf587bb39f95fd5 = 'Dashboard';
include 'header.php';
echo '<div class="wrapper">' . "\n" . '    <div class="container-fluid">' . "\n\t\t";

if (aAcd47d8157a1A09('adv', 'index')) {
	echo '        <div class="row">' . "\n" . '            <div class="col-12">' . "\n" . '                <div class="page-title-box">' . "\n" . '                    <div class="page-title-right"';

	if (!$F61f585ee1fe12b7) {
	} else {
		echo ' style="width: 100%"';
	}

	echo '>' . "\n" . '                        <ol class="breadcrumb m-0" style="width: ';

	if ($F61f585ee1fe12b7) {
		echo '100%';
	} else {
		echo '250px';
	}

	echo ';">' . "\n" . '                            <select id="server_id" class="form-control">' . "\n" . '                                <option ';

	if (isset(XUI::$rRequest['server_id'])) {
	} else {
		echo 'selected ';
	}

	echo 'value="">All Servers</option>' . "\n" . '                                ';

	foreach ($a8bb73cba48fb7f6 as $b72c70c2ef4f8e06) {
		if (!$b72c70c2ef4f8e06['enabled']) {
		} else {
			echo '                                    <option value="';
			echo $b72c70c2ef4f8e06['id'];
			echo '"';

			if (!(isset(XUI::$rRequest['server_id']) && XUI::$rRequest['server_id'] == $b72c70c2ef4f8e06['id'])) {
			} else {
				echo ' selected';
			}

			echo '>';
			echo $b72c70c2ef4f8e06['server_name'];
			echo '</option>' . "\n" . '                                ';
		}
	}
	echo '                            </select>' . "\n" . '                        </ol>' . "\n" . '                    </div>' . "\n" . '                    ';

	if ($F61f585ee1fe12b7) {
	} else {
		echo '                    <h4 class="page-title">' . "\n" . '                    ';

		if (isset(XUI::$rRequest['server_id'])) {
			echo XUI::$rServers[intval(XUI::$rRequest['server_id'])]['server_name'] . "&nbsp; <a href='server_view?id=" . intval(XUI::$rRequest['server_id']) . "' class='btn btn-light waves-effect waves-light btn-xs tooltip-right' title='View Server'><i class='mdi mdi-chart-line'></i></a><a href='process_monitor?server=" . intval(XUI::$rRequest['server_id']) . "' class='btn btn-light waves-effect waves-light btn-xs tooltip-right' title='Process Monitor'><i class='mdi mdi-chart-bar'></i></a>";
		} else {
			echo 'Dashboard';
		}

		echo '</h4>' . "\n" . '                    ';
	}

	echo '                </div>' . "\n" . '            </div>' . "\n" . '        </div>' . "\n" . '        <div class="row mb-4">' . "\n" . '            <div class="col-md-4">' . "\n" . '                ';

	if (!aAcd47D8157a1a09('adv', 'live_connections')) {
	} else {
		echo '<a href="./live_connections">';
	}

	echo '                <div class="card cta-box ';
/*==================================================================================================================*/
//asta este cardul pentru dashboard Online Connections si se pune intreabarea daca este tema 0 light sau tema 1 dark*/
/*==================================================================================================================*/

	if ($D4253f9520627819['theme'] != 0) {
	} else {
		echo 'bg-purple';
	}

	echo ' text-white">' . "\n" . '                    <div class="card-body active-connections dashboard-card-1">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="col-3">' . "\n" . '                                <div class="avatar-sm bg-light">' . "\n" . '                                    <i class="fe-zap avatar-title font-22 ';

	if ($D4253f9520627819['theme'] == 1) {
		echo 'text-white';
	} else {
		echo 'text-purple';
	}

	echo '"></i>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-9">' . "\n" . '                                <div class="text-right">' . "\n" . '                                    <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>' . "\n" . '                                    <p class="text-white mb-1 text-truncate">Online Connections</p>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                ';

	if (!AacD47D8157A1a09('adv', 'live_connections')) {
	} else {
		echo '</a>';
	}
 
	echo '            </div>' . "\n" . '            <div class="col-md-4">' . "\n" . '                ';

	if (!AacD47D8157a1a09('adv', 'live_connections')) {
	} else {
		echo '<a href="./live_connections">';
	}

	echo '                <div class="card cta-box ';




/*======================================================================================================*/
/* asta este cardul pentru Active Lines si se pune intreabarea daca este tema 0 light sau tema 1 dark   */
/*======================================================================================================*/

	if ($D4253f9520627819['theme'] != 0) {
	} else {
		echo 'bg-success';
	}

	echo ' text-white">' . "\n" . '                    <div class="card-body online-users dashboard-card-2">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="col-3">' . "\n" . '                                <div class="avatar-sm bg-light">' . "\n" . '                                    <i class="fe-users avatar-title font-22 ';

	if ($D4253f9520627819['theme'] == 1) {
		echo 'text-white';
	} else {
		echo 'text-success';
	}

	echo '"></i>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-9">' . "\n" . '                                <div class="text-right">' . "\n" . '                                    <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>' . "\n" . '                                    <p class="text-white mb-1 text-truncate">Active Lines</p>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                ';

	if (!aaCd47d8157a1a09('adv', 'live_connections')) {
	} else {
		echo '</a>';
	}

	echo '            </div>' . "\n" . '            <div class="col-md-4">' . "\n" . '                ';

	if (!aACd47D8157A1A09('adv', 'streams')) {
	} else {
		echo '<a href="./streams?filter=1">';
	}

	echo '                <div class="card cta-box ';

	if ($D4253f9520627819['theme'] != 0) {
	} else {
		echo 'bg-info';
	}

/*======================================================================================================*/
/* Asta este cardul pentru Live Streams si se pune intreabarea daca este tema 0 light sau tema 1 dark   */
/*======================================================================================================*/

	echo ' text-white">' . "\n" . '                    <div class="card-body active-streams dashboard-card-3">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="col-3">' . "\n" . '                                <div class="avatar-sm bg-light">' . "\n" . '                                    <i class="fe-play avatar-title font-22 ';

	if ($D4253f9520627819['theme'] == 1) {
		echo 'text-white';
	} else {
		echo 'text-info';
	}

	echo '"></i>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-9">' . "\n" . '                                <div class="text-right">' . "\n" . '                                    <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>' . "\n" . '                                    <p class="text-white mb-1 text-truncate">Live Streams</p>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                ';

	if (!AACd47D8157a1a09('adv', 'streams')) {
	} else {
		echo '</a>';
	}

	echo '            </div>' . "\n" . '            <div class="col-md-4">' . "\n" . '                ';

	if (!AACD47d8157A1A09('adv', 'streams')) {
	} else {
		echo '<a href="./streams?filter=2">';
	}

	echo '                <div class="card cta-box ';

	if ($D4253f9520627819['theme'] != 0) {
	} else {
		echo 'bg-pink';
	}

/*======================================================================================================*/
/* Acesta este cardul pentru Down Streams si se pune intrebarea daca este tema 0 light sau tema 1 dark  */
/*======================================================================================================*/

	echo ' text-white">' . "\n" . '                    <div class="card-body offline-streams dashboard-card-4">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="col-3">' . "\n" . '                                <div class="avatar-sm bg-light">' . "\n" . '                                    <i class="fe-alert-triangle avatar-title font-22 ';

	if ($D4253f9520627819['theme'] == 1) {
		echo 'text-white';
	} else {
		echo 'text-pink';
	}

	echo '"></i>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-9">' . "\n" . '                                <div class="text-right">' . "\n" . '                                    <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>' . "\n" . '                                    <p class="text-white mb-1 text-truncate">Down Streams</p>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                ';

	if (!aAcd47d8157A1a09('adv', 'streams')) {
	} else {
		echo '</a>';
	}

	echo '            </div>' . "\n" . '            <div class="col-md-4">' . "\n" . '                <div class="card cta-box ';

/*========================================================================================================*/
/* Acesta este cardul pentru Network Output si se pune intrebarea daca este tema 0 light sau tema 1 dark  */
/*========================================================================================================*/

	if ($D4253f9520627819['theme'] != 0) {
	} else {
		echo 'bg-primary';
	}

	echo ' text-white">' . "\n" . '                    <div class="card-body output-flow dashboard-card-5">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="col-3">' . "\n" . '                                <div class="avatar-sm bg-light">' . "\n" . '                                    <i class="fe-trending-up avatar-title font-22 ';

	if ($D4253f9520627819['theme'] == 1) {
		echo 'text-white';
	} else {
		echo 'text-primary';
	}

	echo '"></i>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-9">' . "\n" . '                                <div class="text-right">' . "\n" . '                                    <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span> <small>Mbps</small></h3>' . "\n" . '                                    <p class="text-white mb-1 text-truncate">Network Output</p>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            <div class="col-md-4">' . "\n" . '                <div class="card cta-box ';

/*========================================================================================================*/
/* Acesta este cardul pentru Network Intput si se pune intrebarea daca este tema 0 light sau tema 1 dark  */
/*========================================================================================================*/

	if ($D4253f9520627819['theme'] != 0) {
	} else {
		echo 'bg-danger';
	}

	echo ' text-white">' . "\n" . '                    <div class="card-body input-flow dashboard-card-6">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="col-3">' . "\n" . '                                <div class="avatar-sm bg-light">' . "\n" . '                                    <i class="fe-trending-down avatar-title font-22 ';

	if ($D4253f9520627819['theme'] == 1) {
		echo 'text-white';
	} else {
		echo 'text-danger';
	}

	echo '"></i>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-9">' . "\n" . '                                <div class="text-right">' . "\n" . '                                    <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span> <small>Mbps</small></h3>' . "\n" . '                                    <p class="text-white mb-1 text-truncate">Network Input</p>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            <div class="col-12">' . "\n" . '            ';

	if (time() < $d205bd8d1407bcb1[3] && $d205bd8d1407bcb1[3] - time() < 604800 || $D8d681f377d877d4 || $Ab5b854e25293d6b) {
		echo '                <div class="card cta-box bg-info text-white">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="media-body">' . "\n" . '                                ';

		if ($d4977dad729c72de == 'Beta License') {
			echo '                                <h3 class="m-0 font-weight-normal text-white sp-line-1 cta-box-title"><strong>XUI Beta Programme</strong></h3>' . "\n" . '                                ';
		} else {
			echo '                                <h3 class="m-0 font-weight-normal text-white sp-line-1 cta-box-title"><strong>';
			echo $d4977dad729c72de;
			echo ' Expires Soon!</strong></h3>' . "\n" . '                                ';
		}

		echo '                                <p class="text-light mt-2 ">';
		echo $d4977dad729c72de;
		echo ' will expire in <strong>';
		echo XUI::f01c2E2Cfc16141E($d205bd8d1407bcb1[3] - time());
		echo '</strong>.<br/><br/>' . "\n" . '                                ';

		if ($d4977dad729c72de == 'Trial') {
			echo '                                If you want to continue using XUI, you will need to order a normal license via the billing panel.<br/>This installation is non-transferable however you can backup your database and restore it on the non-trial version of XUI.</p>' . "\n" . '                                ';
		} else {
			if ($d4977dad729c72de == 'Beta License') {
				echo '                                Your Beta license is linked to your Main license, to renew this license you should renew your Main license instead via the billing panel.</p>' . "\n" . '                                ';
			} else {
				echo '                                A new invoice should have been generated for you in the billing panel, please ensure you pay with enough time left for it to verify and update your expiration date on the server.<br/>You can manually update your license by clicking License Info in the Settings dropdown menu.</p>' . "\n" . '                                ';
			}
		}

		echo '                                <a href="https://xui.one/billing/" class="text-white font-weight-semibold text-uppercase">Go to Billing Panel <i class="mdi mdi-arrow-right"></i></a>' . "\n" . '                            </div>' . "\n" . '                            ';

		if ($F61f585ee1fe12b7) {
		} else {
			echo '                            <img class="ml-3 whiteout" src="./assets/images/logo-topbar.png" width="80" style="margin-right: 20px;">' . "\n" . '                            ';
		}

		echo '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                ';
	} else {
		if (!($d205bd8d1407bcb1[3] < time() && time() <= $d205bd8d1407bcb1[4])) {
		} else {
			echo '                <div class="card cta-box bg-danger text-white">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <div class="media align-items-center">' . "\n" . '                            <div class="media-body">' . "\n" . '                                <h3 class="m-0 font-weight-normal text-white sp-line-1 cta-box-title"><strong>';
			echo $d4977dad729c72de;
			echo ' Expired!</strong></h3>' . "\n" . '                                <p class="text-light mt-2 ">XUI will shut down in <strong>';
			echo XUI::F01C2E2CfC16141e($d205bd8d1407bcb1[4] - time());
			echo "</strong>.<br/>The panel will continue operating until the timer runs out, however if you plan on continuing using XUI you'll need to pay your invoice with enough time left for it to verify and update your expiration date on the server.<br/>You can manually update your license by clicking License Info in the Settings dropdown menu.</p>" . "\n" . '                                <a href="https://xui.one/billing/" class="text-white font-weight-semibold text-uppercase">Go to Billing Panel <i class="mdi mdi-arrow-right"></i></a>' . "\n" . '                            </div>' . "\n" . '                            <img class="ml-3 whiteout" src="./assets/images/logo-topbar.png" width="80" style="margin-right: 20px;">' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                ';
		}
	}

	echo '            </div>' . "\n" . '            ';

	if ($F61f585ee1fe12b7) {
	} else {
		if (!$F2d4d8f7981ac574['dashboard_status']) {
		} else {
			echo '            <div class="col-xl-6">' . "\n" . '                <div class="card" style="height: 390px; overflow:hidden;">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <h4 class="header-title mb-4">Service Status</h4>' . "\n" . '                        <div style="max-height: 288px; overflow-y: scroll;">' . "\n" . '                            <div class="timeline-alt">' . "\n" . '                                ';
			$c3bbe23e072bcb1b = false;

			try {
				$B59c127fecf35c15 = $Fee0d5a474c96306->dbh->query("SELECT JSON_CONTAINS('0', 0, '\$') AS `json_test`;");
			} catch (Exception $c34ae71903f0d920) {
				$c3bbe23e072bcb1b = true;
				echo '<div class="timeline-item">' . "\n" . '                                        <i class="timeline-icon bg-danger"></i>' . "\n" . '                                        <div class="timeline-item-info">' . "\n" . '                                            <a href="javascript:void(0);" class="text-body font-weight-semibold mb-1 d-block bg"><strong>MariaDB Outdated!</strong></a>' . "\n" . "                                            <small>You're using an old version of MariaDB. Please update to at least v10.5 in order for XUI to work correctly.</small><br/>" . "\n" . '                                            <p><br/></p>' . "\n" . '                                        </div>' . "\n" . '                                    </div>';
			}

			if (!(empty(XUI::$rSettings['status_uuid']) || XUI::$rSettings['status_uuid'] != md5(XUI_VERSION . ((XUI_REVISION ? 'R' . XUI_REVISION : ''))))) {
			} else {
				$c3bbe23e072bcb1b = true;
				echo '<div class="timeline-item">' . "\n" . '                                        <i class="timeline-icon bg-warning"></i>' . "\n" . '                                        <div class="timeline-item-info">' . "\n" . '                                            <a href="javascript:void(0);" class="text-body font-weight-semibold mb-1 d-block bg"><strong>Database Incomplete</strong></a>' . "\n" . '                                            <small>Your database is outdated, please run <strong>/home/xui/status</strong> as root user to update your tables.</small><br/>' . "\n" . '                                            <p><br/></p>' . "\n" . '                                        </div>' . "\n" . '                                    </div>';
			}

			if (file_exists(CONFIG_PATH . 'signals.last') && 600 >= time() - filemtime(CONFIG_PATH . 'signals.last')) {
			} else {
				$c3bbe23e072bcb1b = true;
				echo '<div class="timeline-item">' . "\n" . '                                        <i class="timeline-icon bg-dark"></i>' . "\n" . '                                        <div class="timeline-item-info">' . "\n" . '                                            <a href="javascript:void(0);" class="text-body font-weight-semibold mb-1 d-block bg"><strong>Root Crons Missing</strong></a>' . "\n" . "                                            <small>Root cronjob hasn't run recently, please check root crontab or run <strong>/home/xui/status</strong></small><br/>" . "\n" . '                                            <p><br/></p>' . "\n" . '                                        </div>' . "\n" . '                                    </div>';
			}

			if (!XUI::$rSettings['use_buffer']) {
			} else {
				$c3bbe23e072bcb1b = true;
				echo '<div class="timeline-item">' . "\n" . '                                        <i class="timeline-icon bg-dark"></i>' . "\n" . '                                        <div class="timeline-item-info">' . "\n" . '                                            <a href="settings" class="text-body font-weight-semibold mb-1 d-block bg"><strong>NGINX Buffer</strong></a>' . "\n" . "                                            <small>You have enabled <strong>NGINX Buffer</strong> in settings. <span class=\"text-secondary\">While this isn't an issue, if you don't know what this does you should disable this.</span></small><br/>" . "\n" . '                                            <p><br/></p>' . "\n" . '                                        </div>' . "\n" . '                                    </div>';
			}

			if (!isset(XUI::$rRequest['server_id'])) {
				$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_activity`;');
				$b18dadad2f0cfd29 = ($Fee0d5a474c96306->get_row()['count'] ?: 0);

				if (1000000 > $b18dadad2f0cfd29) {
				} else {
					$c3bbe23e072bcb1b = true;
					echo '<div class="timeline-item">' . "\n" . '                                            <i class="timeline-icon bg-dark"></i>' . "\n" . '                                            <div class="timeline-item-info">' . "\n" . '                                                <a href="line_activity" class="text-body font-weight-semibold mb-1 d-block bg"><strong>Activity Logs</strong></a>' . "\n" . '                                                <small>You have <strong>' . number_format($b18dadad2f0cfd29, 0) . ' logs</strong> stored. <span class="text-secondary">This can significantly slow down the user interface. You should consider clearing these.</span></small><br/>' . "\n" . '                                                <p><br/></p>' . "\n" . '                                            </div>' . "\n" . '                                        </div>';
				}

				$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_errors`;');
				$F1692b8ca313856e = ($Fee0d5a474c96306->get_row()['count'] ?: 0);

				if (1000000 > $F1692b8ca313856e) {
				} else {
					$c3bbe23e072bcb1b = true;
					echo '<div class="timeline-item">' . "\n" . '                                            <i class="timeline-icon bg-dark"></i>' . "\n" . '                                            <div class="timeline-item-info">' . "\n" . '                                                <a href="stream_errors" class="text-body font-weight-semibold mb-1 d-block bg"><strong>Stream Error Logs</strong></a>' . "\n" . '                                                <small>You have <strong>' . number_format($F1692b8ca313856e, 0) . ' logs</strong> stored. <span class="text-secondary">This may indiciate some serious stream issues. You should investigate and clear old logs.</span></small><br/>' . "\n" . '                                                <p><br/></p>' . "\n" . '                                            </div>' . "\n" . '                                        </div>';
				}
			} else {
				$F1692b8ca313856e = $b18dadad2f0cfd29 = 0;
			}

			if (isset(XUI::$rRequest['server_id'])) {
				$a6d36201b819be07 = array(XUI::$rServers[XUI::$rRequest['server_id']]);
			} else {
				$Af547236269d8f66 = array_column(XUI::$rServers, 'last_check_ago');
				array_multisort($Af547236269d8f66, SORT_DESC, XUI::$rServers);
				$a6d36201b819be07 = XUI::$rServers;
			}

			foreach ($a6d36201b819be07 as $e81220b4451f37c9) {
				if (XUI::$rSettings['redis_handler']) {
					$E9046c9b35948a4e = $e81220b4451f37c9['connections'];
				} else {
					$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE (`server_id` = ? OR `proxy_id` = ?) AND `hls_end` = 0;', $e81220b4451f37c9['id'], $e81220b4451f37c9['id']);
					$E9046c9b35948a4e = $Fee0d5a474c96306->get_row()['count'];
				}

				$ffd0802c4358f6d2 = json_decode($e81220b4451f37c9['watchdog_data'], true);
				$D370fc32f973c6ca = array('offline' => false, 'cpu' => false, 'memory' => false, 'disk' => false, 'clients' => false, 'output' => false, 'input' => false, 'offset' => false);

				if (!$e81220b4451f37c9['server_online'] && $e81220b4451f37c9['enabled'] && $e81220b4451f37c9['status'] == 1) {
					$D370fc32f973c6ca['offline'] = true;
				} else {
					if (!$e81220b4451f37c9['server_online']) {
					} else {
						if (intval(XUI::$rSettings['threshold_cpu']) > $ffd0802c4358f6d2['cpu']) {
						} else {
							$D370fc32f973c6ca['cpu'] = true;
						}

						if (intval(XUI::$rSettings['threshold_mem']) >= $ffd0802c4358f6d2['total_mem_used_percent']) {
						} else {
							$D370fc32f973c6ca['memory'] = true;
						}

						if (!($e81220b4451f37c9['server_type'] == 0 && 0 < $ffd0802c4358f6d2['total_disk_space'] && intval(XUI::$rSettings['threshold_disk']) <= intval(($ffd0802c4358f6d2['total_disk_space'] - $ffd0802c4358f6d2['free_disk_space']) / $ffd0802c4358f6d2['total_disk_space'] * 100))) {
						} else {
							$D370fc32f973c6ca['disk'] = true;
						}

						if (!(0 < $e81220b4451f37c9['network_guaranteed_speed'] && $e81220b4451f37c9['network_guaranteed_speed'] * intval(XUI::$rSettings['threshold_network']) / 100 <= $ffd0802c4358f6d2['bytes_sent'] / 125000)) {
						} else {
							$D370fc32f973c6ca['output'] = true;
						}

						if (!(0 < $e81220b4451f37c9['network_guaranteed_speed'] && $e81220b4451f37c9['network_guaranteed_speed'] * intval(XUI::$rSettings['threshold_network']) / 100 <= $ffd0802c4358f6d2['bytes_received'] / 125000)) {
						} else {
							$D370fc32f973c6ca['input'] = true;
						}

						if (!(0 < $e81220b4451f37c9['total_clients'] && $e81220b4451f37c9['total_clients'] * intval(XUI::$rSettings['threshold_clients']) / 100 <= $E9046c9b35948a4e)) {
						} else {
							$D370fc32f973c6ca['clients'] = true;
						}

						if (!(5 < $e81220b4451f37c9['time_offset'] || $e81220b4451f37c9['time_offset'] < -5)) {
						} else {
							$D370fc32f973c6ca['offset'] = true;
						}
					}
				}

				if (!($D370fc32f973c6ca['offline'] || $D370fc32f973c6ca['cpu'] || $D370fc32f973c6ca['memory'] || $D370fc32f973c6ca['disk'] || $D370fc32f973c6ca['clients'] || $D370fc32f973c6ca['output'] || $D370fc32f973c6ca['input'] || $D370fc32f973c6ca['offset'])) {
				} else {
					$c3bbe23e072bcb1b = true;
					echo '                                    <div class="timeline-item">' . "\n" . '                                        <i class="timeline-icon bg-dark"></i>' . "\n" . '                                        <div class="timeline-item-info">' . "\n" . '                                            <a href="server_view?id=';
					echo $e81220b4451f37c9['id'];
					echo '" class="text-body font-weight-semibold mb-1 d-block bg"><strong>';
					echo $e81220b4451f37c9['server_name'];
					echo '</strong></a>' . "\n" . '                                            ';

					if (!$D370fc32f973c6ca['offline']) {
					} else {
						if (!$e81220b4451f37c9['remote_status']) {
							echo '<small>Server cannot be accessed remotely on its IP and Port. Please check that they are correct and ensure nothing is already running on port ' . $e81220b4451f37c9['http_broadcast_port'] . '.</small><br/>';
						} else {
							if ($e81220b4451f37c9['last_check_ago']) {
								echo '<small>Server has been unreachable for <strong>' . XUI::f01c2E2cFc16141E(time() - $e81220b4451f37c9['last_check_ago']) . '</strong></small><br/>';
							} else {
								echo '<small>Server has never sent a callback to XUI. Please check the server for install issues.</small><br/>';
							}
						}
					}

					if (!$D370fc32f973c6ca['cpu']) {
					} else {
						echo '<small>CPU usage is currently <strong>' . ceil(($ffd0802c4358f6d2['cpu'] <= 100 ? $ffd0802c4358f6d2['cpu'] : 100)) . '%</strong>. <span class="text-secondary">To ensure stability please lower CPU usage or investigate any issues.</span></small><br/>';
					}

					if (!$D370fc32f973c6ca['memory']) {
					} else {
						echo '<small>Memory usage is currently <strong>' . ceil(($ffd0802c4358f6d2['total_mem_used_percent'] <= 100 ? $ffd0802c4358f6d2['total_mem_used_percent'] : 100)) . '%</strong>. <span class="text-secondary">Check stream usage in Process Monitor for anomolies if this seems high.</span></small><br/>';
					}

					if (!$D370fc32f973c6ca['disk']) {
					} else {
						echo '<small>Disk usage is currently <strong>' . intval(($ffd0802c4358f6d2['total_disk_space'] - $ffd0802c4358f6d2['free_disk_space']) / $ffd0802c4358f6d2['total_disk_space'] * 100) . '%</strong>. <span class="text-secondary">If usage hits 100% the server will become unusable.</span></small><br/>';
					}

					if (!$D370fc32f973c6ca['clients']) {
					} else {
						echo '<small>Current connections is <strong>' . number_format($E9046c9b35948a4e, 0) . ' / ' . number_format($e81220b4451f37c9['total_clients'], 0) . '</strong>. <span class="text-secondary">Clients will be unable to connect if the limit is reached.</span></small><br/>';
					}

					if (!$D370fc32f973c6ca['input']) {
					} else {
						echo '<small>Network input is currently <strong>' . number_format($ffd0802c4358f6d2['bytes_received'] / 125000, 0) . ' Mbps / ' . number_format($e81220b4451f37c9['network_guaranteed_speed'], 0) . ' Mbps</strong>. <span class="text-secondary">Streams will suffer restarts if the limit is reached.</span></small><br/>';
					}

					if (!$D370fc32f973c6ca['output']) {
					} else {
						echo '<small>Network output is currently <strong>' . number_format($ffd0802c4358f6d2['bytes_sent'] / 125000, 0) . ' Mbps / ' . number_format($e81220b4451f37c9['network_guaranteed_speed'], 0) . ' Mbps</strong>. <span class="text-secondary">Clients will be unable to connect if the limit is reached.</span></small><br/>';
					}

					if (!$D370fc32f973c6ca['offset']) {
					} else {
						echo '<small>Server time is offset to main server time by <strong>' . number_format(abs($e81220b4451f37c9['time_offset']), 0) . '</strong> seconds. <span class="text-secondary">This will affect timeshift, EPG, connections and all sorts of queries.</span></small><br/>';
					}

					echo '                                            <p><br/></p>' . "\n" . '                                        </div>' . "\n" . '                                    </div>' . "\n" . '                                    ';
				}
			}

			if ($c3bbe23e072bcb1b) {
			} else {
				echo '                                <div class="timeline-item">' . "\n" . '                                    <i class="timeline-icon bg-dark"></i>' . "\n" . '                                    <div class="timeline-item-info">' . "\n" . '                                        <a href="#" class="text-body font-weight-semibold mb-1 d-block bg"><strong>No potential issues have been detected!</strong></a>' . "\n" . '                                        <p><br/></p>' . "\n" . '                                    </div>' . "\n" . '                                </div>' . "\n" . '                                ';
			}

			echo '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n\t\t\t";
		}

		if (!$F2d4d8f7981ac574['dashboard_stats']) {
		} else {
			echo '            <div class="col-xl-6">' . "\n" . '                <div class="card">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <h4 class="header-title mb-0">CPU & Memory</h4>' . "\n" . '                        <div id="cpu_chart-col" class="pt-3 show" dir="ltr">' . "\n" . '                            <div id="cpu_chart" class="apex-charts"></div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            <div class="col-xl-6">' . "\n" . '                <div class="card">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <h4 class="header-title mb-0">Network Traffic</h4>' . "\n" . '                        <div id="network_chart-col" class="pt-3 show" dir="ltr">' . "\n" . '                            <div id="network_chart" class="apex-charts"></div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            ';

			if (!$F2d4d8f7981ac574['save_closed_connection']) {
			} else {
				echo '            <div class="col-xl-6">' . "\n" . '                <div class="card">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <h4 class="header-title mb-0">Connections</h4>' . "\n" . '                        <div id="connections_chart-col" class="pt-3 show" dir="ltr">' . "\n" . '                            <div id="connections_chart" class="apex-charts"></div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            ';
			}

			if (!($F2d4d8f7981ac574['save_closed_connection'] && $F2d4d8f7981ac574['dashboard_map'])) {
			} else {
				echo '            <div class="col-xl-12">' . "\n" . '                <div class="card">' . "\n" . '                    <div class="card-body">' . "\n" . '                        <h4 class="header-title mb-0">Connections by Location</h4>' . "\n" . '                        <div id="location-col" class="collapse pt-3 show">' . "\n" . '                            <div class="row">' . "\n" . '                                <div class="col-md-8 align-self-center">' . "\n" . '                                    <div id="map"  style="height: 450px" class="dash-map"></div>' . "\n" . '                                </div>' . "\n" . '                                <div class="col-md-4 align-self-center">' . "\n" . '                                    ';

				foreach (array_slice($C7dc44e2b269673a, 0, 5) as $De0e117a481409e2) {
					echo '                                    <h5 class="mb-1 mt-0">';
					echo number_format($De0e117a481409e2['count'], 0);
					echo ' <small class="text-muted ml-2">';
					echo $De0e117a481409e2['name'];
					echo '</small></h5>' . "\n" . '                                    <div class="progress-w-percent">' . "\n" . '                                        <span class="progress-value font-weight-bold">';
					echo round($De0e117a481409e2['count'] / $bde5957fb5fa9547 * 100, 0);
					echo '% </span>' . "\n" . '                                        <div class="progress progress-sm">' . "\n" . '                                            <div class="progress-bar ';
					echo $De0e117a481409e2['colour'][1];
					echo '" role="progressbar" style="width: ';
					echo round($De0e117a481409e2['count'] / $bde5957fb5fa9547 * 100, 0);
					echo '%;" aria-valuenow="';
					echo round($De0e117a481409e2['count'] / $bde5957fb5fa9547 * 100, 0);
					echo '" aria-valuemin="0" aria-valuemax="100"></div>' . "\n" . '                                        </div>' . "\n" . '                                    </div>' . "\n" . '                                    ';
				}
				echo '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            ';
			}
		}
	}

	if (isset(XUI::$rRequest['server_id'])) {
	} else {
		$Ea22c4a9ab5b2176 = 0;

		foreach ($Dbc0b343dc249303 as $e81220b4451f37c9) {
			if (!($e81220b4451f37c9['enabled'] && $e81220b4451f37c9['server_online'])) {
			} else {
				$Ea22c4a9ab5b2176++;

				if ($Ea22c4a9ab5b2176 != 5) {
				} else {
					$Ea22c4a9ab5b2176 = 1;
				}

				if ($e81220b4451f37c9['server_type'] == 0) {
					if ($e81220b4451f37c9['is_main']) {
						$df5dd6287d36edcb = 'Main Server';
					} else {
						if ($e81220b4451f37c9['enabled']) {
							$df5dd6287d36edcb = 'Load Balancer';
						} else {
							$df5dd6287d36edcb = 'Server Disabled';
						}
					}

					if (!($e81220b4451f37c9['enable_proxy'] && $e81220b4451f37c9['enabled'])) {
					} else {
						$df5dd6287d36edcb .= ' (proxied)';
					}
				} else {
					if ($e81220b4451f37c9['enabled']) {
						$df5dd6287d36edcb = 'Proxy Server';
					} else {
						$df5dd6287d36edcb = 'Proxy Disabled';
					}
				}

				if ($F2d4d8f7981ac574['dashboard_display_alt'] && !$F61f585ee1fe12b7) {
					echo '            <div class="col-xl-6 col-md-12">' . "\n" . '                <a href="./server_view?id=';
					echo $e81220b4451f37c9['id'];
					echo '">' . "\n" . '                    <div class="card-header bg-';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][0];
					echo ' py-3 text-white">' . "\n" . '                        <div class="float-right">' . "\n" . '                            <i class="mdi mdi-chart-line"></i>' . "\n" . '                        </div>' . "\n" . '                        <h5 class="card-title mb-0 text-white">';
					echo $e81220b4451f37c9['server_name'];
					echo '<br/><small>';
					echo $df5dd6287d36edcb;
					echo '</small></h5>' . "\n" . '                    </div>' . "\n" . '                </a>' . "\n" . '                <div class="card-header no-margin-bottom py-3 text-white';

					if ($D4253f9520627819['theme'] != 0) {
					} else {
						echo ' bg-white';
					}

					echo '">' . "\n" . '                    <div class="row">' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">';
					echo $_['connections'];
					echo '</h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <a href="live_connections?server=';
					echo $e81220b4451f37c9['id'];
					echo '"><button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_conns" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button></a>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">';
					echo $_['users'];
					echo '</h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <a href="live_connections?server=';
					echo $e81220b4451f37c9['id'];
					echo '"><button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_users" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button></a>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-4 col-4">' . "\n" . '                            <div class="progress-w-left">' . "\n" . '                                <h4 class="progress-value header-title">CPU</h4>' . "\n" . '                                <div class="progress progress-xl">' . "\n" . '                                    <div class="progress-bar" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_cpu" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="row">' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">Streams&nbsp;Live</h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <a href="streams?server=';
					echo $e81220b4451f37c9['id'];
					echo '&filter=1"><button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_online" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button></a>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">Down</h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <a href="streams?server=';
					echo $e81220b4451f37c9['id'];
					echo '&filter=2"><button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_offline" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button></a>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-4 col-4">' . "\n" . '                            <div class="progress-w-left">' . "\n" . '                                <h4 class="progress-value header-title">MEM</h4>' . "\n" . '                                <div class="progress progress-xl">' . "\n" . '                                    <div class="progress-bar" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_mem" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="row">' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">Requests<small>&nbsp;/sec</small></small></h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_requests" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">';
					echo $_['uptime'];
					echo '</h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_uptime" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0d 0h</button>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-4 col-4">' . "\n" . '                            <div class="progress-w-left">' . "\n" . '                                <h4 class="progress-value header-title">IO</h4>' . "\n" . '                                <div class="progress progress-xl">' . "\n" . '                                    <div class="progress-bar" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_io" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="row">' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">';
					echo $_['input'];
					echo '<small>&nbsp;(Mbps)</small></h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_input" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2">' . "\n" . '                            <h4 class="header-title">';
					echo $_['output'];
					echo '<small>&nbsp;(Mbps)</small></h4>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-2 col-2 text-center">' . "\n" . '                            <button id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_output" type="button" class="btn btn-light btn-xs waves-effect waves-light btn-fixed-min">0</button>' . "\n" . '                        </div>' . "\n" . '                        <div class="col-md-4 col-4">' . "\n" . '                            <div class="progress-w-left">' . "\n" . '                                <h4 class="progress-value header-title">DISK</h4>' . "\n" . '                                <div class="progress progress-xl">' . "\n" . '                                    <div class="progress-bar" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_fs" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\n" . '                                </div>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                <div class="card-footer">' . "\n" . '                    <span data-plugin="peity-line" data-fill="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][2];
					echo '" data-stroke="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][2];
					echo '" data-width="100%" data-height="50" data-min="0" data-max="100">';
					echo implode(',', ($b7a45be2d6027d36[$e81220b4451f37c9['id']] ?: array()));
					echo '</span>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            ';
				} else {
					echo '            <div class="col-xl-3 col-md-6">' . "\n" . '                <a href="./server_view?id=';
					echo $e81220b4451f37c9['id'];
					echo '">' . "\n" . '                    <div class="card-header bg-';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][0];
					echo ' py-3 text-white text-center">' . "\n" . '                        <h5 class="card-title mb-0 text-white">';
					echo $e81220b4451f37c9['server_name'];
					echo '<br/><small>';
					echo $df5dd6287d36edcb;
					echo '</small></h5>' . "\n" . '                    </div>' . "\n" . '                    <div class="card-header py-3 text-white';

					if ($D4253f9520627819['theme'] != 0) {
					} else {
						echo ' bg-white';
					}

					echo '">' . "\n" . '                        <div class="row" style="margin-bottom:-20px;">' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['conns'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_conns">0</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['users'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_users">0</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['online'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_online">0</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['input'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_input">0 Mbps</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['output'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_output">0 Mbps</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['uptime'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_uptime">0d 0h</p>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="card-box no-margin-bottom light-grey">' . "\n" . '                        <div class="row">' . "\n" . '                            <div class="col-md-4 col-4" align="center">' . "\n" . '                                <h4 class="header-title">CPU %</h4>' . "\n" . '                                <input class="knob" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_cpu" data-plugin="knob" data-width="64" data-height="64" data-fgColor="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][1];
					echo '" data-bgColor="#e8e7f4" value="0" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15"/>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-4" align="center">' . "\n" . '                                <h4 class="header-title">MEM %</h4>' . "\n" . '                                <input class="knob" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_mem" data-plugin="knob" data-width="64" data-height="64" data-fgColor="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][1];
					echo '" data-bgColor="#e8e7f4" value="0" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15"/>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-4" align="center">' . "\n" . '                                <h4 class="header-title">DISK %</h4>' . "\n" . '                                <input class="knob" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_fs" data-plugin="knob" data-width="64" data-height="64" data-fgColor="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][1];
					echo '" data-bgColor="#e8e7f4" value="0" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15"/>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="card-footer">' . "\n" . '                        <span data-plugin="peity-line" data-fill="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][2];
					echo '" data-stroke="';
					echo $A97781a69ffc0557[$Ea22c4a9ab5b2176][2];
					echo '" data-width="100%" data-height="50" data-min="0" data-max="100">';
					echo(is_array($b7a45be2d6027d36[$e81220b4451f37c9['id']]) ? implode(',', $b7a45be2d6027d36[$e81220b4451f37c9['id']]) : '');
					echo '</span>' . "\n" . '                    </div>' . "\n" . '                </a>' . "\n" . '            </div>' . "\n" . '            ';
				}
			}
		}
		$Ea22c4a9ab5b2176 = 0;

		foreach ($Dbc0b343dc249303 as $e81220b4451f37c9) {
			if (!$e81220b4451f37c9['enabled'] || $e81220b4451f37c9['server_online']) {
			} else {
				$Ea22c4a9ab5b2176++;

				if ($Ea22c4a9ab5b2176 != 5) {
				} else {
					$Ea22c4a9ab5b2176 = 1;
				}

				if ($e81220b4451f37c9['server_type'] == 0) {
					if ($e81220b4451f37c9['is_main']) {
						$df5dd6287d36edcb = 'Main Server';
					} else {
						if ($e81220b4451f37c9['enabled']) {
							$df5dd6287d36edcb = 'Load Balancer';
						} else {
							$df5dd6287d36edcb = 'Server Disabled';
						}
					}

					if (!($e81220b4451f37c9['enable_proxy'] && $e81220b4451f37c9['enabled'])) {
					} else {
						$df5dd6287d36edcb .= ' (proxied)';
					}
				} else {
					if ($e81220b4451f37c9['enabled']) {
						$df5dd6287d36edcb = 'Proxy Server';
					} else {
						$df5dd6287d36edcb = 'Proxy Disabled';
					}
				}

				if ($F2d4d8f7981ac574['dashboard_display_alt'] && !$F61f585ee1fe12b7) {
					echo '            <div class="col-xl-6 col-md-12">' . "\n" . '                <a href="./server_view?id=';
					echo $e81220b4451f37c9['id'];
					echo '">' . "\n" . '                    <div class="card-header ';

					if ($D4253f9520627819['theme'] == 1) {
						echo 'bg-light';
					} else {
						echo 'bg-dark';
					}

					echo ' py-3 text-white">' . "\n" . '                        <div class="float-right">' . "\n" . '                            <i class="mdi mdi-chart-line"></i>' . "\n" . '                        </div>' . "\n" . '                        <h5 class="card-title mb-0 text-white">';
					echo $e81220b4451f37c9['server_name'];
					echo '<br/><small>';
					echo $df5dd6287d36edcb;
					echo '</small></h5>' . "\n" . '                    </div>' . "\n" . '                </a>' . "\n" . '                <div class="card-header no-margin-bottom py-3 text-white';

					if ($D4253f9520627819['theme'] != 0) {
					} else {
						echo ' bg-white';
					}

					echo '">' . "\n" . '                    <div class="col-12 text-center" style="padding-top: 70px;">' . "\n" . '                        <a href="./server_view?id=';
					echo $e81220b4451f37c9['id'];
					echo '">' . "\n" . '                            <i class="fe-alert-triangle avatar-title font-22 ';

					if ($D4253f9520627819['theme'] == 1) {
						echo 'text-white';
					} else {
						echo 'text-danger';
					}

					echo '"></i>' . "\n" . '                            <h4 class="header-title ';

					if ($D4253f9520627819['theme'] == 1) {
						echo 'text-white';
					} else {
						echo 'text-danger';
					}

					echo '">Server Offline</h4>' . "\n" . '                        </a>' . "\n" . '                    </div>' . "\n" . '                </div>' . "\n" . '                <div class="card-footer">' . "\n" . '                    <span data-plugin="peity-line" data-fill="';
					echo($D4253f9520627819['theme'] == 1 ? '#434b56' : '#7e8e9d');
					echo '" data-stroke="';
					echo($D4253f9520627819['theme'] == 1 ? '#434b56' : '#7e8e9d');
					echo '" data-width="100%" data-height="50" data-min="0" data-max="100">';
					echo implode(',', ($b7a45be2d6027d36[$e81220b4451f37c9['id']] ?: array()));
					echo '</span>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '            ';
				} else {
					echo '            <div class="col-xl-3 col-md-6">' . "\n" . '                <a href="./server_view?id=';
					echo $e81220b4451f37c9['id'];
					echo '">' . "\n" . '                    <div class="card-header ';

					if ($D4253f9520627819['theme'] == 1) {
						echo 'bg-light';
					} else {
						echo 'bg-dark';
					}

					echo ' py-3 text-white text-center">' . "\n" . '                        <h5 class="card-title mb-0 text-white">';
					echo $e81220b4451f37c9['server_name'];
					echo '<br/><small>';
					echo $df5dd6287d36edcb;
					echo '</small></h5>' . "\n" . '                    </div>' . "\n" . '                    <div class="card-header py-3 text-white';

					if ($D4253f9520627819['theme'] != 0) {
					} else {
						echo ' bg-white';
					}

					echo '">' . "\n" . '                        <div class="row" style="margin-bottom:-20px;">' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['conns'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_conns">0</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['users'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_users">0</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['online'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_online">0</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['input'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_input">0 Mbps</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['output'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_output">0 Mbps</p>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-4 col-6" align="center">' . "\n" . '                                <h4 class="header-title">';
					echo $_['uptime'];
					echo '</h4>' . "\n" . '                                <p class="sub-header" id="s_';
					echo $e81220b4451f37c9['id'];
					echo '_uptime">0d 0h</p>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="card-box no-margin-bottom light-grey">' . "\n" . '                        <div class="row">' . "\n" . '                            ';

					if ($e81220b4451f37c9['status'] == 3) {
						echo '                            <div class="col-12 text-center" style="padding-top: 15px;">' . "\n" . '                                <i class="mdi mdi-creation avatar-title font-22 ';

						if ($D4253f9520627819['theme'] == 1) {
							echo 'text-white';
						} else {
							echo 'text-info';
						}

						echo '"></i>' . "\n" . '                                <h4 class="header-title ';

						if ($D4253f9520627819['theme'] == 1) {
							echo 'text-white';
						} else {
							echo 'text-info';
						}

						echo '">Installing...</h4>' . "\n" . '                            </div>' . "\n" . '                            ';
					} else {
						if ($e81220b4451f37c9['status'] == 4) {
							echo '                            <div class="col-12 text-center" style="padding-top: 15px;">' . "\n" . '                                <i class="fe-alert-triangle avatar-title font-22 ';

							if ($D4253f9520627819['theme'] == 1) {
								echo 'text-white';
							} else {
								echo 'text-warning';
							}

							echo '"></i>' . "\n" . '                                <h4 class="header-title ';

							if ($D4253f9520627819['theme'] == 1) {
								echo 'text-white';
							} else {
								echo 'text-warning';
							}

							echo '">Install Failed!</h4>' . "\n" . '                            </div>' . "\n" . '                            ';
						} else {
							echo '                            <div class="col-12 text-center" style="padding-top: 15px;">' . "\n" . '                                <i class="fe-alert-triangle avatar-title font-22 ';

							if ($D4253f9520627819['theme'] == 1) {
								echo 'text-white';
							} else {
								echo 'text-danger';
							}

							echo '"></i>' . "\n" . '                                <h4 class="header-title ';

							if ($D4253f9520627819['theme'] == 1) {
								echo 'text-white';
							} else {
								echo 'text-danger';
							}

							echo '">Server Offline</h4>' . "\n" . '                            </div>' . "\n" . '                            ';
						}
					}

					echo '                        </div>' . "\n" . '                    </div>' . "\n" . '                    <div class="card-footer">' . "\n" . '                        <span data-plugin="peity-line" data-fill="';
					echo($D4253f9520627819['theme'] == 1 ? '#434b56' : '#7e8e9d');
					echo '" data-stroke="';
					echo($D4253f9520627819['theme'] == 1 ? '#434b56' : '#7e8e9d');
					echo '" data-width="100%" data-height="50" data-min="0" data-max="100">';
					echo(is_array($b7a45be2d6027d36[$e81220b4451f37c9['id']]) ? implode(',', $b7a45be2d6027d36[$e81220b4451f37c9['id']]) : '');
					echo '</span>' . "\n" . '                    </div>' . "\n" . '                </a>' . "\n" . '            </div>' . "\n" . '            ';
				}
			}
		}
	}

	echo "\t\t" . '</div>' . "\n\t\t";
} else {
	echo "\t\t" . '<div class="alert alert-danger show text-center" role="alert" style="margin-top:20px;">' . "\n\t\t\t";
	echo $_['dashboard_no_permissions'];
	echo '<br/>';
	echo $_['dashboard_nav_top'];
	echo "\t\t" . '</div>' . "\n\t\t";
}

echo "\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
