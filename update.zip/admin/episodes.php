<?php

include 'session.php';
include 'functions.php';

if (B1882DF698b44754()) {
} else {
	B46f5Dd76f3C7421();
}

$E6652981ffae09cc = $E79a0db1471ddfdf = array();
$Fee0d5a474c96306->query('SELECT DISTINCT(`audio_codec`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `audio_codec` IS NOT NULL AND `type` = 5 ORDER BY `audio_codec` ASC;');

foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
	$E6652981ffae09cc[] = $C740da31596f24ef['audio_codec'];
}
$Fee0d5a474c96306->query('SELECT DISTINCT(`video_codec`) FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `video_codec` IS NOT NULL AND `type` = 5 ORDER BY `video_codec` ASC;');

foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
	$E79a0db1471ddfdf[] = $C740da31596f24ef['video_codec'];
}
$bcf587bb39f95fd5 = 'Episodes';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n" . '        <div class="row">' . "\n" . '            <div class="col-12">' . "\n" . '                <div class="page-title-box">' . "\n" . '                    <div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n" . '                    <h4 class="page-title">';
echo $_['episodes'];
echo '</h4>' . "\n" . '                </div>' . "\n" . '            </div>' . "\n" . '        </div>     ' . "\n" . '        <div class="row">' . "\n" . '            <div class="col-12">' . "\n" . '                <div class="card">' . "\n" . '                    <div class="card-body" style="overflow-x:auto;">' . "\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <input type="text" class="form-control" id="episodes_search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="';
echo $_['search_episodes'];
echo '...">' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="episodes_server" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['server'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['all_servers'];
echo '</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == -1)) {
} else {
	echo ' selected';
}

echo '>No Servers</option>' . "\n" . '                                    ';

foreach (F6dA964066F2f5E4() as $e81220b4451f37c9) {
	echo '                                    <option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <label class="col-md-1 col-form-label text-center" for="episodes_series">Series &nbsp; <button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="clearSeries();"><i class="mdi mdi-close"></i></button></label>' . "\n" . '                            <div class="col-md-2">' . "\n" . '                                <select id="episodes_series" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

if (!(isset(XUI::$rRequest['series']) && ($bbc84f53c534450d = fFD24E407abb46eB(intval(XUI::$rRequest['series']))))) {
} else {
	echo '                                    <option value="';
	echo intval($bbc84f53c534450d['id']);
	echo '" selected="selected">';
	echo $bbc84f53c534450d['title'];
	echo '</option>' . "\n" . '                                    ';
}

echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="episodes_filter" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['filter'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['no_filter'];
echo '</option>' . "\n" . '                                    <option value="1"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 1)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['encoded'];
echo '</option>' . "\n" . '                                    <option value="2"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 2)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['encoding'];
echo '</option>' . "\n" . '                                    <option value="3"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 3)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['down'];
echo '</option>' . "\n" . '                                    <option value="4"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 4)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['ready'];
echo '</option>' . "\n" . '                                    <option value="5"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 5)) {
} else {
	echo ' selected';
}

echo '>';
echo $_['direct'];
echo '</option>' . "\n\t\t\t\t\t\t\t\t\t" . '<option value="6"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 6)) {
} else {
	echo ' selected';
}

echo '>Duplicate</option>' . "\n\t\t\t\t\t\t\t\t\t" . '<option value="7"';

if (!(isset(XUI::$rRequest['filter']) && XUI::$rRequest['filter'] == 7)) {
} else {
	echo ' selected';
}

echo '>Transcoding</option>' . "\n" . '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="episodes_audio" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['audio'])) {
} else {
	echo ' selected';
}

echo '>Audio</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['audio']) && XUI::$rRequest['audio'] == '-1')) {
} else {
	echo ' selected';
}

echo '>None</option>' . "\n" . '                                    ';

foreach ($E6652981ffae09cc as $A387578f69b4c724) {
	echo '                                    <option value="';
	echo $A387578f69b4c724;
	echo '"';

	if (!(isset(XUI::$rRequest['audio']) && XUI::$rRequest['audio'] == $A387578f69b4c724)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A387578f69b4c724;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="episodes_video" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['video'])) {
} else {
	echo ' selected';
}

echo '>Video</option>' . "\n" . '                                    <option value="-1"';

if (!(isset(XUI::$rRequest['video']) && XUI::$rRequest['video'] == '-1')) {
} else {
	echo ' selected';
}

echo '>None</option>' . "\n" . '                                    ';

foreach ($E79a0db1471ddfdf as $A387578f69b4c724) {
	echo '                                    <option value="';
	echo $A387578f69b4c724;
	echo '"';

	if (!(isset(XUI::$rRequest['video']) && XUI::$rRequest['video'] == $A387578f69b4c724)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $A387578f69b4c724;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="episodes_resolution" class="form-control" data-toggle="select2">' . "\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['resolution'])) {
} else {
	echo ' selected';
}

echo '>Quality</option>' . "\n" . '                                    ';

foreach (array(240, 360, 480, 576, 720, 1080, 1440, 2160) as $fbf4f3f4868222b7) {
	echo '                                    <option value="';
	echo $fbf4f3f4868222b7;
	echo '"';

	if (!(isset(XUI::$rRequest['resolution']) && XUI::$rRequest['resolution'] == $fbf4f3f4868222b7)) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $fbf4f3f4868222b7;
	echo 'p</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                            <div class="col-md-1">' . "\n" . '                                <select id="episodes_show_entries" class="form-control" data-toggle="select2">' . "\n" . '                                    ';

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo '                                    <option';

	if (isset(XUI::$rRequest['entries'])) {
		if (XUI::$rRequest['entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	} else {
		if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
		} else {
			echo ' selected';
		}
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\n" . '                                    ';
}
echo '                                </select>' . "\n" . '                            </div>' . "\n" . '                        </div>' . "\n" . '                        <table id="datatable-streampage" class="table table-striped table-borderless dt-responsive nowrap font-normal">' . "\n" . '                            <thead>' . "\n" . '                                <tr>' . "\n" . '                                    <th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                    <th class="text-center">Image</th>' . "\n" . '                                    <th>';
echo $_['name'];
echo '</th>' . "\n" . '                                    ';

if ($F2d4d8f7981ac574['streams_grouped'] == 1) {
	echo "\t\t\t\t\t\t\t\t\t" . '<th>';
	echo $_['servers'];
	echo '</th>' . "\n" . '                                    ';
} else {
	echo '                                    <th>';
	echo $_['server'];
	echo '</th>' . "\n\t\t\t\t\t\t\t\t\t";
}

echo '                                    <th class="text-center">';
echo $_['clients'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['status'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['actions'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['player'];
echo '</th>' . "\n" . '                                    <th class="text-center">';
echo $_['stream_info'];
echo '</th>' . "\n" . '                                </tr>' . "\n" . '                            </thead>' . "\n" . '                            <tbody></tbody>' . "\n" . '                        </table>' . "\n" . '                    </div> ' . "\n" . '                </div> ' . "\n" . '            </div>' . "\n" . '        </div>' . "\n" . '    </div>' . "\n" . '</div>' . "\n";
include 'footer.php';
