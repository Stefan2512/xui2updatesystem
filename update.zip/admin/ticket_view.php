<?php

include 'session.php';
include 'functions.php';

if (B1882DF698B44754()) {
} else {
	b46f5dd76f3c7421();
}

if (isset(XUI::$rRequest['id']) && ($e67c6f9cfcf32879 = D42Edd31C6Ef0655(XUI::$rRequest['id']))) {
} else {
	B46f5DD76F3c7421();
}

if ($D4253f9520627819['id'] == $e67c6f9cfcf32879['member_id']) {
} else {
	$Fee0d5a474c96306->query('UPDATE `tickets` SET `admin_read` = 1 WHERE `id` = ?;', XUI::$rRequest['id']);
}

$bcf587bb39f95fd5 = 'View Ticket';
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">';
echo $e67c6f9cfcf32879['title'];
echo '</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="timeline" dir="ltr">' . "\r\n\t\t\t\t\t";

foreach ($e67c6f9cfcf32879['replies'] as $C9e90f3f7130c9af) {
	echo "\t\t\t\t\t" . '<article class="timeline-item';

	if ($C9e90f3f7130c9af['admin_reply']) {
	} else {
		echo ' timeline-item-left';
	}

	echo '">' . "\r\n\t\t\t\t\t\t" . '<div class="timeline-desk">' . "\r\n\t\t\t\t\t\t\t" . '<div class="timeline-box">' . "\r\n\t\t\t\t\t\t\t\t" . '<span class="arrow-alt"></span>' . "\r\n\t\t\t\t\t\t\t\t" . '<span class="timeline-icon"><i class="mdi mdi-adjust"></i></span>' . "\r\n\t\t\t\t\t\t\t\t" . '<h4 class="mt-0 font-16">';

	if (!$C9e90f3f7130c9af['admin_reply']) {
		echo $e67c6f9cfcf32879['user']['username'];
	} else {
		echo 'Admin';
	}

	echo '</h4>' . "\r\n\t\t\t\t\t\t\t\t" . '<p class="text-muted"><small>';
	echo date('Y-m-d H:i', $C9e90f3f7130c9af['date']);
	echo '</small></p>' . "\r\n\t\t\t\t\t\t\t\t" . '<p class="mb-0">';
	echo $C9e90f3f7130c9af['message'];
	echo '</p>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '</article>' . "\r\n\t\t\t\t\t";
}
echo "\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
