<?php

include 'session.php';
include 'functions.php';

if (B1882Df698b44754()) {
} else {
	B46F5DD76f3C7421();
}

$adab610984c5d7df = null;

if (isset(XUI::$rRequest['id'])) {
	$f523e362fb81d6c8 = e5ecEB32f67d5e70(XUI::$rRequest['id']);

	if (!(!$f523e362fb81d6c8 || $f523e362fb81d6c8['type'] != 1 || $f523e362fb81d6c8['tv_archive_duration'] == 0 || $f523e362fb81d6c8['tv_archive_server_id'] == 0)) {
	} else {
		B46F5dD76F3C7421();
	}

	$f665b8e041442d05 = e695e82Dd6b72236($f523e362fb81d6c8['id']);
} else {
	$adab610984c5d7df = getRecordings();
}

$bcf587bb39f95fd5 = (!is_null($adab610984c5d7df) ? 'Recodings' : 'TV Archive');
include 'header.php';
echo '<div class="wrapper boxed-layout-ext"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n" . '                    <div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n" . '                    ';

if (!is_null($adab610984c5d7df)) {
	echo "\t\t\t\t\t" . '<h4 class="page-title">Recordings</h4>' . "\n" . '                    ';
} else {
	echo '                    <h4 class="page-title">';
	echo $f523e362fb81d6c8['stream_display_name'];
	echo '<small> - TV Archive</small></h4>' . "\n" . '                    ';
}

echo "\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>     ' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n" . '                ';

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Recording has been scheduled.' . "\n\t\t\t\t" . '</div>' . "\n" . '                ';
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<div class="table">' . "\n" . '                            <table id="datatable" class="table table-striped table-borderless mb-0">' . "\n" . '                                <thead>' . "\n" . '                                    <tr>' . "\n" . '                                        <th class="text-center">ID</th>' . "\n" . '                                        <th class="text-center">Date</th>' . "\n" . '                                        <th class="text-center">Duration</th>' . "\n" . '                                        <th>Title</th>' . "\n" . '                                        <th class="text-center">Status</th>' . "\n" . '                                        <th class="text-center">Player</th>' . "\n" . '                                        <th class="text-center">Actions</th>' . "\n" . '                                    </tr>' . "\n" . '                                </thead>' . "\n" . '                                <tbody>' . "\n" . '                                    ';

if (!is_null($adab610984c5d7df)) {
	foreach ($adab610984c5d7df as $bb2621204e39e62d) {
		$C5034884ed44603a = $bb2621204e39e62d['end'] - $bb2621204e39e62d['start'];

		if (!($bb2621204e39e62d['status'] == 0 && !$bb2621204e39e62d['archive'] && $bb2621204e39e62d['end'] < time())) {
		} else {
			$bb2621204e39e62d['status'] = 3;
		}

		echo '                                    <tr>' . "\n" . '                                        <td>';
		echo $bb2621204e39e62d['id'];
		echo '</td>' . "\n" . '                                        <td class="text-center">';
		echo date($F2d4d8f7981ac574['date_format'] . ' H:i', $bb2621204e39e62d['start']);
		echo '</td>' . "\n" . '                                        <td class="text-center">';
		echo sprintf('%02dh %02dm', $C5034884ed44603a / 3600, ($C5034884ed44603a / 60) % 60);
		echo '</td>' . "\n" . '                                        <td>';
		echo $bb2621204e39e62d['title'];
		echo '</td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                            ';

		if ($bb2621204e39e62d['status'] == 0) {
			echo "                                            <button type='button' class='btn btn-light btn-xs waves-effect waves-light'>WAITING</button>" . "\n" . '                                            ';
		} else {
			if ($bb2621204e39e62d['status'] == 1) {
				echo "                                            <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>RECORDING</button>" . "\n" . '                                            ';
			} else {
				if ($bb2621204e39e62d['status'] == 2) {
					echo "                                            <button type='button' class='btn btn-success btn-xs waves-effect waves-light'>COMPLETE</button>" . "\n" . '                                            ';
				} else {
					echo "                                            <button type='button' class='btn btn-danger btn-xs waves-effect waves-light'>FAILED</button>" . "\n" . '                                            ';
				}
			}
		}

		echo '                                        </td>' . "\n" . '                                        ';

		if ($bb2621204e39e62d['created_id']) {
			echo '                                        <td class="text-center"><button type="button" class="btn btn-info waves-effect waves-light btn-xs" onclick="player(';
			echo intval($bb2621204e39e62d['created_id']);
			echo ');"><i class="mdi mdi-play"></i></button></td>' . "\n" . '                                        ';
		} else {
			echo '                                        <td class="text-center"><button disabled type="button" class="btn btn-info waves-effect waves-light btn-xs"><i class="mdi mdi-play"></i></button></td>' . "\n" . '                                        ';
		}

		echo '                                        <td class="text-center">' . "\n" . '                                            <div class="btn-group">' . "\n" . '                                                ';

		if ($bb2621204e39e62d['created_id']) {
			echo '                                                <a href="stream_view?id=';
			echo intval($bb2621204e39e62d['created_id']);
			echo '"><button title="View Movie" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-movie-outline"></i></button></a>' . "\n" . '                                                ';
		} else {
			echo '                                                <button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-movie-outline"></i></button>' . "\n" . '                                                ';
		}

		echo '                                                <button title="Delete Recording" onClick="deleteRecording(';
		echo intval($bb2621204e39e62d['id']);
		echo ')" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-close"></i></button>' . "\n" . '                                            </div>' . "\n" . '                                        </td>' . "\n" . '                                    </tr>' . "\n" . '                                    ';
	}
} else {
	foreach ($f665b8e041442d05 as $bb2621204e39e62d) {
		$C5034884ed44603a = $bb2621204e39e62d['end'] - $bb2621204e39e62d['start'];
		$bb2621204e39e62d['stream_id'] = XUI::$rRequest['id'];
		echo '                                    <tr>' . "\n" . '                                        <td>';
		echo $bb2621204e39e62d['id'];
		echo '</td>' . "\n" . '                                        <td class="text-center">';
		echo date($F2d4d8f7981ac574['date_format'] . ' H:i', $bb2621204e39e62d['start']);
		echo '</td>' . "\n" . '                                        <td class="text-center">';
		echo sprintf('%02dh %02dm', $C5034884ed44603a / 3600, ($C5034884ed44603a / 60) % 60);
		echo '</td>' . "\n" . '                                        <td>';
		echo $bb2621204e39e62d['title'];
		echo '</td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                            ';

		if ($bb2621204e39e62d['in_progress']) {
			echo "                                            <button type='button' class='btn btn-info btn-xs waves-effect waves-light'>IN PROGRESS</button>" . "\n" . '                                            ';
		} else {
			if ($bb2621204e39e62d['complete']) {
				echo "                                            <button type='button' class='btn btn-success btn-xs waves-effect waves-light'>COMPLETE</button>" . "\n" . '                                            ';
			} else {
				echo "                                            <button type='button' class='btn btn-warning btn-xs waves-effect waves-light'>INCOMPLETE</button>" . "\n" . '                                            ';
			}
		}

		echo '                                        </td>' . "\n" . '                                        <td class="text-center"><button type="button" class="btn btn-info waves-effect waves-light btn-xs" onclick="player(';
		echo intval($f523e362fb81d6c8['id']);
		echo ', ';
		echo intval($bb2621204e39e62d['start']);
		echo ', ';
		echo intval($C5034884ed44603a / 60);
		echo ');"><i class="mdi mdi-play"></i></button></td>' . "\n" . '                                        ';

		if (!$bb2621204e39e62d['in_progress']) {
			echo '                                        <td class="text-center"><a href="record?archive=';
			echo urlencode(base64_encode(json_encode($bb2621204e39e62d)));
			echo '"><button type="button" class="btn btn-danger waves-effect waves-light btn-xs"><i class="mdi mdi-record"></i></button></a></td>' . "\n" . '                                        ';
		} else {
			echo '                                        <td class="text-center"><button disabled type="button" class="btn btn-danger waves-effect waves-light btn-xs"><i class="mdi mdi-record"></i></button></td>' . "\n" . '                                        ';
		}

		echo '                                    </tr>' . "\n" . '                                    ';
	}
}

echo '                                </tbody>' . "\n" . '                            </table>' . "\n" . '                        </div>' . "\n\t\t\t\t\t" . '</div>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
