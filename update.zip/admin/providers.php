<?php

include 'session.php';
include 'functions.php';

if (B1882Df698b44754()) {
} else {
	B46F5dD76F3C7421();
}

$bcf587bb39f95fd5 = 'Stream Providers';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\n" . '    <div class="container-fluid">' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t" . '<div class="page-title-box">' . "\n\t\t\t\t\t" . '<div class="page-title-right">' . "\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\n\t\t\t\t\t" . '<h4 class="page-title">Stream Providers</h4>' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t\t" . '<div class="row">' . "\n\t\t\t" . '<div class="col-12">' . "\n\t\t\t\t";

if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_SUCCESS)) {
} else {
	echo "\t\t\t\t" . '<div class="alert alert-success alert-dismissible fade show" role="alert">' . "\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\n\t\t\t\t\t" . '</button>' . "\n\t\t\t\t\t" . 'Provider has been added to the database and will be periodically scanned.' . "\n\t\t\t\t" . '</div>' . "\n\t\t\t\t";
}

echo "\t\t\t\t" . '<div class="card">' . "\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\n\t\t\t\t\t\t" . '<table id="datatable" class="table table-striped table-borderless dt-responsive nowrap">' . "\n\t\t\t\t\t\t\t" . '<thead>' . "\n\t\t\t\t\t\t\t\t" . '<tr>' . "\n" . '                                    <th class="text-center">';
echo $_['id'];
echo '</th>' . "\n" . '                                    <th class="text-center">Status</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th>Provider</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Username</th>' . "\n" . '                                    <th class="text-center">Connections</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Streams</th>' . "\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Movies</th>' . "\n" . '                                    <th class="text-center">Series</th>' . "\n" . '                                    <th class="text-center">Expires</th>' . "\n" . '                                    <th class="text-center">Last Changed</th>' . "\n" . '                                    <th class="text-center">Actions</th>' . "\n\t\t\t\t\t\t\t\t" . '</tr>' . "\n\t\t\t\t\t\t\t" . '</thead>' . "\n\t\t\t\t\t\t\t" . '<tbody>' . "\n\t\t\t\t\t\t\t\t";

foreach (getStreamProviders() as $Ad973fd3103e20dc) {
	$a27e64cc6ce01033 = json_decode($Ad973fd3103e20dc['data'], true);

	if (!$Ad973fd3103e20dc['enabled']) {
		$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square"></i>';
	} else {
		if ($Ad973fd3103e20dc['enabled'] && $Ad973fd3103e20dc['status']) {
			$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square"></i>';
		} else {
			$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square"></i>';
		}
	}

	echo '                                    <tr id="provider-';
	echo $Ad973fd3103e20dc['id'];
	echo '">' . "\n" . '                                        <td class="text-center">';
	echo $Ad973fd3103e20dc['id'];
	echo '</td>' . "\n" . '                                        <td class="text-center">';
	echo $Ba23222f3ed2dc08;
	echo '</td>' . "\n" . '                                        <td>';
	echo $Ad973fd3103e20dc['name'];
	echo '<br/><small>';
	echo $Ad973fd3103e20dc['ip'];
	echo ':';
	echo $Ad973fd3103e20dc['port'];
	echo '</small></td>' . "\n" . '                                        <td class="text-center">';
	echo $Ad973fd3103e20dc['username'];
	echo '</td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                        ';

	if (0 < $a27e64cc6ce01033['max_connections']) {
		if ($a27e64cc6ce01033['max_connections'] * 0.75 < $a27e64cc6ce01033['active_connections']) {
			$Ac54397e06e8e862 = 'danger';
		} else {
			if ($a27e64cc6ce01033['max_connections'] * 0.5 < $a27e64cc6ce01033['active_connections']) {
				$Ac54397e06e8e862 = 'warning';
			} else {
				$Ac54397e06e8e862 = 'success';
			}
		}

		echo '<a href="streams?search=' . urlencode(strtolower($Ad973fd3103e20dc['ip'])) . '&filter=1"><button type="button" class="btn btn-' . $Ac54397e06e8e862 . ' btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['active_connections'], 0) . ' / ' . number_format($a27e64cc6ce01033['max_connections'], 0) . '</button></a>';
	} else {
		echo '<a href="streams?search=' . urlencode(strtolower($Ad973fd3103e20dc['ip'])) . '&filter=1"><button type="button" class="btn btn-success btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['active_connections'], 0) . ' / &infin;</button></a>';
	}

	echo '                                        </td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                        ';

	if (0 < $a27e64cc6ce01033['streams']) {
		echo '<button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['streams'], 0) . '</button>';
	} else {
		echo '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['streams'], 0) . '</button>';
	}

	echo '                                        </td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                        ';

	if (0 < $a27e64cc6ce01033['movies']) {
		echo '<button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['movies'], 0) . '</button>';
	} else {
		echo '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['movies'], 0) . '</button>';
	}

	echo '                                        </td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                        ';

	if (0 < $a27e64cc6ce01033['series']) {
		echo '<button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['series'], 0) . '</button>';
	} else {
		echo '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">' . number_format($a27e64cc6ce01033['series'], 0) . '</button>';
	}

	echo '                                        </td>' . "\n" . '                                        <td class="text-center">';
	echo($a27e64cc6ce01033['exp_date'] == -1 ? 'Unknown' : ($a27e64cc6ce01033['exp_date'] ? date('Y-m-d', $a27e64cc6ce01033['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $a27e64cc6ce01033['exp_date']) . '</small>' : 'Never'));
	echo '</td>' . "\n" . '                                        <td class="text-center">';
	echo($Ad973fd3103e20dc['last_changed'] ? date('Y-m-d', $Ad973fd3103e20dc['last_changed']) . "<br/><small class='text-secondary'>" . date('H:i:s', $Ad973fd3103e20dc['last_changed']) . '</small>' : 'Never');
	echo '</td>' . "\n" . '                                        <td class="text-center">' . "\n" . '                                            <div class="btn-group">' . "\n" . '                                                <a href="provider?id=';
	echo $Ad973fd3103e20dc['id'];
	echo '"><button type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-pencil"></i></button></a>' . "\n" . '                                                <button type="button" title="Force Reload" class="tooltip btn btn-light waves-effect waves-light btn-xs" onClick="api(';
	echo $Ad973fd3103e20dc['id'];
	echo ", 'reload');\"><i class=\"mdi mdi-refresh\"></i></button>" . "\n" . '                                                <button type="button" class="btn btn-light waves-effect waves-light btn-xs" onClick="api(';
	echo $Ad973fd3103e20dc['id'];
	echo ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>" . "\n" . '                                            </div>' . "\n" . '                                        </td>' . "\n" . '                                    </tr>' . "\n\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t" . '</tbody>' . "\n\t\t\t\t\t\t" . '</table>' . "\n\t\t\t\t\t" . '</div> ' . "\n\t\t\t\t" . '</div> ' . "\n\t\t\t" . '</div>' . "\n\t\t" . '</div>' . "\n\t" . '</div>' . "\n" . '</div>' . "\n";
include 'footer.php';
