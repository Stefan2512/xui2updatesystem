<?php

include 'session.php';
include 'functions.php';

if (b1882df698b44754()) {
} else {
	B46F5Dd76F3C7421();
}

if (!isset(XUI::$rRequest['user_id'])) {
} else {
	$cd6f747ef348d4bc = B4036EF9A1dB8473(XUI::$rRequest['user_id']);
}

if (!isset(XUI::$rRequest['stream_id'])) {
} else {
	$d550d3261242f0a6 = E5ECeB32f67D5e70(XUI::$rRequest['stream_id']);
}

$bcf587bb39f95fd5 = 'Activity Logs';
include 'header.php';
echo '<div class="wrapper"';

if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
} else {
	echo ' style="display: none;"';
}

echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n" . '                    <div class="page-title-right">' . "\r\n" . '                        ';
include 'topbar.php';
echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">Activity Logs</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>     ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t" . '<div class="card-body" style="overflow-x:auto;">' . "\r\n" . '                        <div id="collapse_filters" class="';

if (!$F61f585ee1fe12b7) {
} else {
	echo 'collapse';
}

echo ' form-group row mb-4">' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <input type="text" class="form-control" id="act_search" value="';

if (!isset(XUI::$rRequest['search'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['search']);
}

echo '" placeholder="';
echo $_['search_logs'];
echo '...">' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="act_server" class="form-control" data-toggle="select2">' . "\r\n" . '                                    <option value=""';

if (isset(XUI::$rRequest['server'])) {
} else {
	echo ' selected';
}

echo '>';
echo $_['all_servers'];
echo '</option>' . "\r\n" . '                                    ';

foreach (XUI::$rServers as $e81220b4451f37c9) {
	echo '                                    <option value="';
	echo $e81220b4451f37c9['id'];
	echo '"';

	if (!(isset(XUI::$rRequest['server']) && XUI::$rRequest['server'] == $e81220b4451f37c9['id'])) {
	} else {
		echo ' selected';
	}

	echo '>';
	echo $e81220b4451f37c9['server_name'];
	echo '</option>' . "\r\n" . '                                    ';
}
echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="act_stream" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

if (!isset($d550d3261242f0a6)) {
} else {
	echo '                                    <option value="';
	echo intval($d550d3261242f0a6['id']);
	echo '" selected="selected">';
	echo $d550d3261242f0a6['stream_display_name'];
	echo '</option>' . "\r\n" . '                                    ';
}

echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <select id="act_line" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

if (!isset($cd6f747ef348d4bc)) {
} else {
	echo '                                    <option value="';
	echo intval($cd6f747ef348d4bc['id']);
	echo '" selected="selected">';
	echo $cd6f747ef348d4bc['username'];
	echo '</option>' . "\r\n" . '                                    ';
}

echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                            <div class="col-md-2">' . "\r\n" . '                                <input type="text" class="form-control text-center date" id="act_range" name="range" value="';

if (!isset(XUI::$rRequest['range'])) {
} else {
	echo htmlspecialchars(XUI::$rRequest['range']);
}

echo '" data-toggle="date-picker" data-single-date-picker="true" placeholder="All Dates">' . "\r\n" . '                            </div>' . "\r\n" . '                            <label class="col-md-1 col-form-label text-center" for="act_show_entries">';
echo $_['show'];
echo '</label>' . "\r\n" . '                            <div class="col-md-1">' . "\r\n" . '                                <select id="act_show_entries" class="form-control" data-toggle="select2">' . "\r\n" . '                                    ';

foreach (array(10, 25, 50, 250, 500, 1000) as $C9e42207e95f03ed) {
	echo '                                    <option';

	if ($F2d4d8f7981ac574['default_entries'] != $C9e42207e95f03ed) {
	} else {
		echo ' selected';
	}

	echo ' value="';
	echo $C9e42207e95f03ed;
	echo '">';
	echo $C9e42207e95f03ed;
	echo '</option>' . "\r\n" . '                                    ';
}
echo '                                </select>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n\t\t\t\t\t\t" . '<table id="datatable-activity" class="table table-striped table-borderless dt-responsive nowrap">' . "\r\n\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Line</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Stream</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>Server</th>' . "\r\n" . '                                    <th>Player</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th>ISP</th>' . "\r\n" . '                                    <th class="text-center">IP</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Start</th>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<th class="text-center">Stop</th>' . "\r\n" . '                                    <th class="text-center">Duration</th>' . "\r\n" . '                                    <th class="text-center">Output</th>' . "\r\n" . '                                    <th class="text-center">Restreamer</th>' . "\r\n\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t" . '<tbody></tbody>' . "\r\n\t\t\t\t\t\t" . '</table>' . "\r\n\r\n\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t" . '</div> ' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div>' . "\r\n\t\t\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
include 'footer.php';
