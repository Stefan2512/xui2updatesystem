<?php

include 'session.php';
include 'functions.php';

if (b1882df698b44754()) {
} else {
	B46F5dd76f3c7421();
}

if (isset(XUI::$rRequest['id'])) {
	if (isset($a8bb73cba48fb7f6[XUI::$rRequest['id']])) {
		$e81220b4451f37c9 = $a8bb73cba48fb7f6[XUI::$rRequest['id']];
	} else {
		if (isset($Fd8279be5302940a[XUI::$rRequest['id']])) {
			$e81220b4451f37c9 = $Fd8279be5302940a[XUI::$rRequest['id']];
		} else {
			exit();
		}
	}

	$ffd0802c4358f6d2 = json_decode($e81220b4451f37c9['watchdog_data'], true);
	$e81220b4451f37c9['gpu_info'] = json_decode($e81220b4451f37c9['gpu_info'], true);
	$e19876d9ba369ed1 = array('cpu' => array(), 'memory' => array(), 'io' => array(), 'input' => array(), 'output' => array(), 'dates' => array(null, null));

	foreach (Bf7791BD46BeC674($e81220b4451f37c9['id']) as $a27e64cc6ce01033) {
		if ($e19876d9ba369ed1['dates'][0] && $a27e64cc6ce01033['time'] * 1000 > $e19876d9ba369ed1['dates'][0]) {
		} else {
			$e19876d9ba369ed1['dates'][0] = $a27e64cc6ce01033['time'] * 1000;
		}

		if ($e19876d9ba369ed1['dates'][1] && $e19876d9ba369ed1['dates'][1] > $a27e64cc6ce01033['time'] * 1000) {
		} else {
			$e19876d9ba369ed1['dates'][1] = $a27e64cc6ce01033['time'] * 1000;
		}

		$e19876d9ba369ed1['cpu'][] = array($a27e64cc6ce01033['time'] * 1000, floatval(rtrim($a27e64cc6ce01033['cpu'], '%')));
		$e19876d9ba369ed1['memory'][] = array($a27e64cc6ce01033['time'] * 1000, floatval(rtrim($a27e64cc6ce01033['total_mem_used_percent'], '%')));
		$e19876d9ba369ed1['io'][] = array($a27e64cc6ce01033['time'] * 1000, floatval(json_decode($a27e64cc6ce01033['iostat_info'], true)['avg-cpu']['iowait']));
		$e19876d9ba369ed1['input'][] = array($a27e64cc6ce01033['time'] * 1000, round($a27e64cc6ce01033['bytes_received'] / 125000, 0));
		$e19876d9ba369ed1['output'][] = array($a27e64cc6ce01033['time'] * 1000, round($a27e64cc6ce01033['bytes_sent'] / 125000, 0));
	}
	$dd6503a196807aba = json_decode($e81220b4451f37c9['certbot_ssl'], true);
	$bf0ae29929f5fd32 = false;

	if ($dd6503a196807aba['expiration']) {
		$cb545bbcbfee77ba = true;

		if (time() >= $dd6503a196807aba['expiration']) {
		} else {
			$bf0ae29929f5fd32 = true;
		}

		$D41fb416a088058d = date($F2d4d8f7981ac574['datetime_format'], $dd6503a196807aba['expiration']);
	} else {
		$cb545bbcbfee77ba = false;
		$D41fb416a088058d = 'No Certificate Installed';
	}

	if ($e81220b4451f37c9['server_type'] == 0) {
		$bcf587bb39f95fd5 = 'View Server';
	} else {
		$bcf587bb39f95fd5 = 'View Proxy';
	}

	include 'header.php';
	echo '<div class="wrapper boxed-layout-ext"';

	if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	} else {
		echo ' style="display: none;"';
	}

	echo '>' . "\r\n" . '    <div class="container-fluid">' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-12">' . "\r\n\t\t\t\t" . '<div class="page-title-box">' . "\r\n\t\t\t\t\t" . '<div class="page-title-right">' . "\r\n" . '                        ';
	include 'topbar.php';
	echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<h4 class="page-title">' . "\r\n\t\t\t\t\t\t";
	echo $e81220b4451f37c9['server_name'];
	echo "\t\t\t\t\t\t" . '<small style="margin-left: 5px;">';
	echo $e81220b4451f37c9['server_ip'];
	echo '</small>' . "\r\n\t\t\t\t\t" . '</h4>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div>' . "\r\n\t\t" . '</div> ' . "\r\n\t\t" . '<div class="row">' . "\r\n\t\t\t" . '<div class="col-xl-12">' . "\r\n" . '                ';

	if (isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_CERTBOT) {
		echo '                <div class="alert alert-success alert-dismissible fade show" role="alert">' . "\r\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\r\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\r\n\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t" . 'Certbot will run in the background and attempt to generate certificates for your server automatically, check back here shortly for a progress update. Once a certificate is installed, you can turn SSL on for this server.' . "\r\n\t\t\t\t" . '</div>' . "\r\n" . '                ';
	} else {
		if (!(isset($B4a5f8dc1f8d260c) && $B4a5f8dc1f8d260c == STATUS_CERTBOT_INVALID)) {
		} else {
			echo '                <div class="alert alert-danger alert-dismissible fade show" role="alert">' . "\r\n\t\t\t\t\t" . '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . "\r\n\t\t\t\t\t\t" . '<span aria-hidden="true">&times;</span>' . "\r\n\t\t\t\t\t" . '</button>' . "\r\n\t\t\t\t\t" . 'No valid domains were selected for Certbot automation. Please try again.' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
		}
	}

	echo "\t\t\t\t" . '<div class="row text-center">' . "\r\n" . '                    ';

	if ($e81220b4451f37c9['server_type'] == 0) {
		echo "\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n" . '                    ';
	} else {
		echo '                    <div class="col-md-6">' . "\r\n" . '                    ';
	}

	if (!aaCd47d8157a1a09('adv', 'live_connections')) {
	} else {
		echo '<a href="./live_connections?server_id=';
		echo $e81220b4451f37c9['id'];
		echo '">';
	}

	echo "\t\t\t\t\t\t" . '<div class="card cta-box ';

	if ($F2d4d8f7981ac574['dark_mode']) {
	} else {
		echo 'bg-purple';
	}

	echo ' text-white">' . "\r\n\t\t\t\t\t\t\t" . '<div class="card-body active-connections">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="avatar-sm bg-light">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-zap avatar-title font-22 ';

	if ($F2d4d8f7981ac574['dark_mode']) {
		echo 'text-white';
	} else {
		echo 'text-purple';
	}

	echo '"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="text-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1"><span data-plugin="counterup" class="entry" id="open_connections">0</span></h3>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate">Connections</p>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t";

	if (!aaCd47d8157A1A09('adv', 'live_connections')) {
	} else {
		echo '</a>';
	}

	echo "\t\t\t\t\t" . '</div>' . "\r\n" . '                    ';

	if ($e81220b4451f37c9['server_type'] == 0) {
		echo "\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n" . '                    ';
	} else {
		echo '                    <div class="col-md-6">' . "\r\n" . '                    ';
	}

	if (!aacd47D8157a1A09('adv', 'live_connections')) {
	} else {
		echo '<a href="./live_connections?server_id=';
		echo $e81220b4451f37c9['id'];
		echo '">';
	}

	echo "\t\t\t\t\t\t" . '<div class="card cta-box ';

	if ($F2d4d8f7981ac574['dark_mode']) {
	} else {
		echo 'bg-success';
	}

	echo ' text-white">' . "\r\n\t\t\t\t\t\t\t" . '<div class="card-body active-connections">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="avatar-sm bg-light">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-users avatar-title font-22 ';

	if ($F2d4d8f7981ac574['dark_mode']) {
		echo 'text-white';
	} else {
		echo 'text-success';
	}

	echo '"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="text-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1"><span data-plugin="counterup" class="entry" id="online_users">0</span></h3>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate">Users</p>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t";

	if (!AaCd47d8157A1A09('adv', 'live_connections')) {
	} else {
		echo '</a>';
	}

	echo "\t\t\t\t\t" . '</div>' . "\r\n" . '                    ';

	if ($e81220b4451f37c9['server_type'] != 0) {
	} else {
		echo "\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t";

		if (!aaCd47D8157a1a09('adv', 'streams')) {
		} else {
			echo '<a href="./streams?filter=1&server=';
			echo $e81220b4451f37c9['id'];
			echo '">';
		}

		echo "\t\t\t\t\t\t" . '<div class="card cta-box ';

		if ($F2d4d8f7981ac574['dark_mode']) {
		} else {
			echo 'bg-pink';
		}

		echo ' text-white">' . "\r\n\t\t\t\t\t\t\t" . '<div class="card-body active-connections">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="avatar-sm bg-light">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-play avatar-title font-22 ';

		if ($F2d4d8f7981ac574['dark_mode']) {
			echo 'text-white';
		} else {
			echo 'text-pink';
		}

		echo '"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="text-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1"><span data-plugin="counterup" class="entry" id="total_running_streams">0</span></h3>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate">Streams</p>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t";

		if (!aACD47D8157a1A09('adv', 'streams')) {
		} else {
			echo '</a>';
		}

		echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '<div class="col-md-3">' . "\r\n\t\t\t\t\t\t";

		if (!aaCd47d8157a1A09('adv', 'streams')) {
		} else {
			echo '<a href="./streams?filter=2&server=';
			echo $e81220b4451f37c9['id'];
			echo '">';
		}

		echo "\t\t\t\t\t\t" . '<div class="card cta-box ';

		if ($F2d4d8f7981ac574['dark_mode']) {
		} else {
			echo 'bg-info';
		}

		echo ' text-white">' . "\r\n\t\t\t\t\t\t\t" . '<div class="card-body active-connections">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="media align-items-center">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-3">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="avatar-sm bg-light">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<i class="fe-pause avatar-title font-22 ';

		if ($F2d4d8f7981ac574['dark_mode']) {
			echo 'text-white';
		} else {
			echo 'text-info';
		}

		echo '"></i>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="col-9">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div class="text-right">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<h3 class="text-white my-1"><span data-plugin="counterup" class="entry" id="offline_streams">0</span></h3>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<p class="text-white mb-1 text-truncate">Down</p>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t";

		if (!aAcd47D8157a1A09('adv', 'streams')) {
		} else {
			echo '</a>';
		}

		echo "\t\t\t\t\t" . '</div>' . "\r\n" . '                    ';
	}

	echo "\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '<div class="card-box">' . "\r\n\t\t\t\t\t" . '<div class="col-md-12 align-self-center">' . "\r\n" . '                        ';

	if (in_array($e81220b4451f37c9['status'], array(3, 4))) {
		echo '                        <div class="text-center" style="padding-top: 15px;">' . "\r\n" . '                            <i class="mdi mdi-creation avatar-title font-24 text-info"></i><br/>' . "\r\n" . '                            <h4 class="header-title text-info">Installing...</h4>' . "\r\n" . '                            <textarea readonly style="padding: 15px; margin-top: 20px; background: #56c2d6; color: #fff; border: 0; width: 100%; height: 150px; scroll-y: auto;" id="server_install"></textarea>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
	} else {
		if ($e81220b4451f37c9['server_online']) {
			echo "\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">CPU Usage<small class="text-muted ml-2">of ';
			echo $ffd0802c4358f6d2['cpu_cores'];
			echo ' Cores</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent" id="watchdog_cpu">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">0%</span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">Memory Usage<small class="text-muted ml-2">of ';
			echo round($ffd0802c4358f6d2['total_mem'] / 1024 / 1024, 0);
			echo ' GB</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent" id="watchdog_mem">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">0%</span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';

			if ($e81220b4451f37c9['server_type'] != 0) {
			} else {
				echo '                        <h5 class="mb-1 mt-0">Disk Usage<small class="text-muted ml-2"> of ';
				echo(1099511627776 < $ffd0802c4358f6d2['total_disk_space'] ? number_format($ffd0802c4358f6d2['total_disk_space'] / 1024 / 1024 / 1024 / 1024, 0) . ' TB' : number_format($ffd0802c4358f6d2['total_disk_space'] / 1024 / 1024 / 1024, 0) . ' GB');
				echo '</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent" id="watchdog_disk">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">0%</span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        <h5 class="mb-1 mt-0">IO Wait<small class="text-muted ml-2" id="watchdog_idle"> 0% Idle</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent" id="watchdog_io">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">0%</span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
			}

			echo "\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">Network Input<small class="text-muted ml-2">of ';
			echo number_format($e81220b4451f37c9['network_guaranteed_speed'], 0);
			echo ' Mbps</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent" id="watchdog_input">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">0 Mbps</span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">Network Output<small class="text-muted ml-2">of ';
			echo number_format($e81220b4451f37c9['network_guaranteed_speed'], 0);
			echo ' Mbps</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent" id="watchdog_output">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">0 Mbps</span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
		} else {
			echo '                        <div class="text-center" style="padding-top: 15px;">' . "\r\n" . '                            <i class="fe-alert-triangle avatar-title font-24 text-danger"></i><br/>' . "\r\n" . '                        <h4 class="header-title text-danger">Server Offline</h4>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
		}
	}

	echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";

	if (!is_array($e81220b4451f37c9['gpu_info'])) {
	} else {
		$cd0f3566b68f221f = 0;

		foreach ($e81220b4451f37c9['gpu_info']['gpus'] as $d5aa7e5e1de00526) {
			$D325c5780b273117 = number_format(intval(explode(' ', $d5aa7e5e1de00526['memory_usage']['used'])[0]) / intval(explode(' ', $d5aa7e5e1de00526['memory_usage']['total'])[0]) * 100, 0);
			echo "\t\t\t\t" . '<div class="card-box">' . "\r\n\t\t\t\t\t" . '<div class="col-md-12 align-self-center">' . "\r\n\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">GPU';
			echo $cd0f3566b68f221f;
			echo ' Usage<small class="text-muted ml-2"> ';
			echo $d5aa7e5e1de00526['name'];
			echo '</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['gpu_util'])[0]);
			echo '% </span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar ';
			echo D14a0C6CA02FcE17(intval(explode(' ', $d5aa7e5e1de00526['utilisation']['gpu_util'])[0]));
			echo '" role="progressbar" style="width: ';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['gpu_util'])[0]);
			echo '%;" aria-valuenow="';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['gpu_util'])[0]);
			echo '" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">GPU';
			echo $cd0f3566b68f221f;
			echo ' Memory Usage<small class="text-muted ml-2"> ';
			echo number_format(explode(' ', $d5aa7e5e1de00526['memory_usage']['used'])[0], 0);
			echo 'MB / ';
			echo number_format(explode(' ', $d5aa7e5e1de00526['memory_usage']['total'])[0], 0);
			echo 'MB</small></h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">';
			echo $D325c5780b273117;
			echo '% </span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar ';
			echo D14A0c6cA02FCe17($D325c5780b273117);
			echo '" role="progressbar" style="width: ';
			echo $D325c5780b273117;
			echo '%;" aria-valuenow="';
			echo $D325c5780b273117;
			echo '" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">GPU';
			echo $cd0f3566b68f221f;
			echo ' Encoder Usage</h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['encoder_util'])[0]);
			echo '% </span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar ';
			echo D14A0c6CA02fce17(intval(explode(' ', $d5aa7e5e1de00526['utilisation']['encoder_util'])[0]));
			echo '" role="progressbar" style="width: ';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['encoder_util'])[0]);
			echo '%;" aria-valuenow="';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['encoder_util'])[0]);
			echo '" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<h5 class="mb-1 mt-0">GPU';
			echo $cd0f3566b68f221f;
			echo ' Decoder Usage</h5>' . "\r\n\t\t\t\t\t\t" . '<div class="progress-w-percent">' . "\r\n\t\t\t\t\t\t\t" . '<span class="progress-value font-weight-bold">';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['decoder_util'])[0]);
			echo '% </span>' . "\r\n\t\t\t\t\t\t\t" . '<div class="progress progress-sm">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="progress-bar ';
			echo D14a0C6ca02fcE17(intval(explode(' ', $d5aa7e5e1de00526['utilisation']['decoder_util'])[0]));
			echo '" role="progressbar" style="width: ';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['decoder_util'])[0]);
			echo '%;" aria-valuenow="';
			echo intval(explode(' ', $d5aa7e5e1de00526['utilisation']['decoder_util'])[0]);
			echo '" aria-valuemin="0" aria-valuemax="100"></div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
			$cd0f3566b68f221f++;
		}

		if (!$cb545bbcbfee77ba) {
		} else {
			echo '                <div class="card-box">' . "\r\n\t\t\t\t\t" . '<div class="col-md-12 align-self-center">' . "\r\n" . '                        <div class="form-group row mb-4">' . "\r\n" . '                            <label class="col-md-4 col-form-label" for="expiration_date">Certificate Expiration Date</label>' . "\r\n" . '                            <div class="col-md-8">' . "\r\n" . '                                <input type="text" class="form-control" id="expiration_date" value="';
			echo $D41fb416a088058d;
			echo '" readonly>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';

			if (!$bf0ae29929f5fd32) {
			} else {
				echo '                        <div class="form-group row mb-4">' . "\r\n" . '                            <label class="col-md-4 col-form-label" for="cert_serial">Certificate Serial</label>' . "\r\n" . '                            <div class="col-md-8">' . "\r\n" . '                                <input type="text" class="form-control" id="cert_serial" value="';
				echo $dd6503a196807aba['serial'];
				echo '" readonly>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        <div class="form-group row">' . "\r\n" . '                            <label class="col-md-4 col-form-label" for="cert_subject">Certificate Subject</label>' . "\r\n" . '                            <div class="col-md-8">' . "\r\n" . '                                <input type="text" class="form-control" id="cert_subject" value="';
				echo $dd6503a196807aba['subject'];
				echo '" readonly>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                        ';
			}

			echo "\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t\t";
		}
	}

	echo "\t\t\t\t" . '<div class="card-box">' . "\r\n\t\t\t\t\t" . '<ul class="nav nav-tabs nav-bordered nav-justified">' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#cpu" data-toggle="tab" aria-expanded="true" class="nav-link active">' . "\r\n\t\t\t\t\t\t\t\t" . 'Resources' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#network" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Network Traffic' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';

	if ($e81220b4451f37c9['server_type'] != 0) {
	} else {
		echo "\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#streams" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Online Streams' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n" . '                        ';
	}

	echo "\t\t\t\t\t\t" . '<li class="nav-item">' . "\r\n\t\t\t\t\t\t\t" . '<a href="#connections" data-toggle="tab" aria-expanded="false" class="nav-link">' . "\r\n\t\t\t\t\t\t\t\t" . 'Active Connections' . "\r\n\t\t\t\t\t\t\t" . '</a>' . "\r\n\t\t\t\t\t\t" . '</li>' . "\r\n\t\t\t\t\t" . '</ul>' . "\r\n\t\t\t\t\t" . '<div class="tab-content">' . "\r\n\t\t\t\t\t\t" . '<div class="tab-pane active" id="cpu">' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-xl-12">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="card-body">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div id="cpu_chart-col" class="pt-3 show" dir="ltr">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<div id="cpu_chart" class="apex-charts"></div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '<div class="tab-pane" id="network">' . "\r\n\t\t\t\t\t\t\t" . '<div class="col-xl-12">' . "\r\n\t\t\t\t\t\t\t\t" . '<div class="card">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<div class="card-body">' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<div id="network_chart-col" class="pt-3 show" dir="ltr">' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<div id="network_chart" class="apex-charts"></div>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t\t" . '</div> ' . "\r\n\t\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';

	if ($e81220b4451f37c9['server_type'] != 0) {
	} else {
		echo "\t\t\t\t\t\t" . '<div class="tab-pane" id="streams">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable_streams" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>ID</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Name</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Clients</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Uptime</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th>Actions</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th></th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td colspan="10" class="text-center">Loading stream information...</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n" . '                        ';
	}

	echo "\t\t\t\t\t\t" . '<div class="tab-pane" id="connections">' . "\r\n\t\t\t\t\t\t\t" . '<div class="table">' . "\r\n\t\t\t\t\t\t\t\t" . '<table id="datatable_connections" class="table table-striped table-borderless mb-0">' . "\r\n\t\t\t\t\t\t\t\t\t" . '<thead>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<th class="text-center">ID</th>' . "\r\n" . '                                            <th class="text-center">Quality</th>' . "\r\n" . '                                            <th>Username</th>' . "\r\n" . '                                            <th>Stream</th>' . "\r\n" . '                                            <th>Server</th>' . "\r\n" . '                                            <th>Player</th>' . "\r\n" . '                                            <th>ISP</th>' . "\r\n" . '                                            <th class="text-center">IP</th>' . "\r\n" . '                                            <th class="text-center">Duration</th>' . "\r\n" . '                                            <th class="text-center">Output</th>' . "\r\n" . '                                            <th class="text-center">Restreamer</th>' . "\r\n" . '                                            <th class="text-center">';
	echo $_['actions'];
	echo '</th>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</thead>' . "\r\n\t\t\t\t\t\t\t\t\t" . '<tbody>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '<tr>' . "\r\n\t\t\t\t\t\t\t\t\t\t\t" . '<td colspan="9" class="text-center">Loading user information...</td>' . "\r\n\t\t\t\t\t\t\t\t\t\t" . '</tr>' . "\r\n\t\t\t\t\t\t\t\t\t" . '</tbody>' . "\r\n\t\t\t\t\t\t\t\t" . '</table>' . "\r\n\t\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t\t" . '</div>' . "\r\n\t\t\t\t" . '</div>' . "\r\n\t\t\t" . '</div> ' . "\r\n\t\t" . '</div>' . "\r\n\t" . '</div>' . "\r\n" . '</div>' . "\r\n";
	include 'footer.php';
} else {
	exit();
}
