define('XUI_VERSION', '2.0.8');
define('XUI_REVISION', 8);
