define('XUI_VERSION', '2.0.9');
define('XUI_REVISION', 9);
