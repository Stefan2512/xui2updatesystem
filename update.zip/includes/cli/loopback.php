<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc > 2) {
		error_reporting(0);
		ini_set('display_errors', 0);
		$F26087d31c2bbe4d = intval($argv[1]);
		$d58b4f8653a391d8 = intval($argv[2]);
		define('XUI_HOME', '/home/xui/');
		define('STREAMS_PATH', XUI_HOME . 'content/streams/');
		define('INCLUDES_PATH', XUI_HOME . 'includes/');
		define('FFMPEG', XUI_HOME . 'bin/ffmpeg_bin/4.0/ffmpeg');
		define('FFPROBE', XUI_HOME . 'bin/ffmpeg_bin/4.0/ffprobe');
		define('CACHE_TMP_PATH', XUI_HOME . 'tmp/cache/');
		define('CONFIG_PATH', XUI_HOME . 'config/');
		define('PAT_HEADER', "�\r");
		define('KEYFRAME_HEADER', "\x07P");
		define('PACKET_SIZE', 188);
		define('BUFFER_SIZE', 12032);
		define('PAT_PERIOD', 2);
		define('TIMEOUT', 20);
		define('TIMEOUT_READ', 1);

		if (file_exists(CONFIG_PATH . 'config.ini')) {
			if (file_exists(CACHE_TMP_PATH . 'settings')) {
				if (file_exists(CACHE_TMP_PATH . 'servers')) {
					$Df06db369f6b9832 = parse_ini_file(CONFIG_PATH . 'config.ini');
					define('SERVER_ID', intval($Df06db369f6b9832['server_id']));
					d60457acfd5df5c9($F26087d31c2bbe4d);
					register_shutdown_function('shutdown');
					set_time_limit(0);
					cli_set_process_title('Loopback[' . $F26087d31c2bbe4d . ']');
					require INCLUDES_PATH . 'ts.php';
					$e1644d67f855686d = $E8601dd191bcdbba = null;
					$Ce2588e350bd2724 = $e2a0e8d3bf81a35b = array();
					$F2d4d8f7981ac574 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'settings'));
					$a8bb73cba48fb7f6 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'servers'));
					$ab807f62de794231 = $F2d4d8f7981ac574['seg_list_size'];
					$Ad932ae5de6fc9e2 = $F2d4d8f7981ac574['seg_delete_threshold'];
					$c0b3ca0e630a00ce = $fef6ec871481e2a8 = null;
					startloopback($F26087d31c2bbe4d, $d58b4f8653a391d8, $ab807f62de794231, $Ad932ae5de6fc9e2);
				} else {
					echo 'Servers not cached!' . "\n";

					exit(0);
				}
			} else {
				echo 'Settings not cached!' . "\n";

				exit(0);
			}
		} else {
			echo 'Config file missing!' . "\n";

			exit(0);
		}
	} else {
		echo 'Loopback cannot be directly run!' . "\n";

		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function startLoopback($F26087d31c2bbe4d, $d58b4f8653a391d8, $ab807f62de794231, $Ad932ae5de6fc9e2)
{
	global $a8bb73cba48fb7f6;
	global $F2d4d8f7981ac574;
	global $e2a0e8d3bf81a35b;
	global $E8601dd191bcdbba;
	global $e1644d67f855686d;
	global $fef6ec871481e2a8;
	global $c0b3ca0e630a00ce;
	$e3019184fb1785ff = (!is_null($a8bb73cba48fb7f6[SERVER_ID]['private_url_ip']) && !is_null($a8bb73cba48fb7f6[$d58b4f8653a391d8]['private_url_ip']) ? $a8bb73cba48fb7f6[$d58b4f8653a391d8]['private_url_ip'] : $a8bb73cba48fb7f6[$d58b4f8653a391d8]['public_url_ip']);
	$e1644d67f855686d = @fopen($e3019184fb1785ff . 'admin/live?stream=' . @intval($F26087d31c2bbe4d) . '&password=' . @urlencode($F2d4d8f7981ac574['live_streaming_pass']) . '&extension=ts&prebuffer=1', 'rb');

	if (!$e1644d67f855686d) {
	} else {
		shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*.ts');
		stream_set_blocking($e1644d67f855686d, true);
		$ab0657150415d4c8 = $e1034511e63f0e9e = $b9f3f039ea3bf5ca = $fe4c6aae49a89941 = '';
		$dabbbb018c906611 = array();
		$Eb8625bccd4f95c5 = $dd96d5e5f09b92ad = false;
		$f64c65f8c5f65d9c = true;
		$D00713bbb5f0a356 = time();
		$D2176e3a77f12992 = round(microtime(true) * 1000);
		$d55bf693d0ece21c = 0;
		$E8601dd191bcdbba = fopen(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $d55bf693d0ece21c . '.ts', 'wb');
		$e2a0e8d3bf81a35b[$d55bf693d0ece21c] = true;
		echo 'PID: ' . getmypid() . "\n";

		while (!feof($e1644d67f855686d)) {
			stream_set_timeout($e1644d67f855686d, TIMEOUT_READ);
			$b9f3f039ea3bf5ca = $b9f3f039ea3bf5ca . $ab0657150415d4c8 . fread($e1644d67f855686d, BUFFER_SIZE - strlen($b9f3f039ea3bf5ca . $ab0657150415d4c8));
			$ab0657150415d4c8 = '';
			$B82cf6c4229ec535 = floor(strlen($b9f3f039ea3bf5ca) / PACKET_SIZE);

			if (0 >= $B82cf6c4229ec535) {
			} else {
				$D00713bbb5f0a356 = time();

				if (strlen($b9f3f039ea3bf5ca) == $B82cf6c4229ec535 * PACKET_SIZE) {
				} else {
					$ab0657150415d4c8 = substr($b9f3f039ea3bf5ca, $B82cf6c4229ec535 * PACKET_SIZE, strlen($b9f3f039ea3bf5ca) - $B82cf6c4229ec535 * PACKET_SIZE);
					$b9f3f039ea3bf5ca = substr($b9f3f039ea3bf5ca, 0, $B82cf6c4229ec535 * PACKET_SIZE);
				}

				$Cb71beb6ebd5bdd2 = 0;

				foreach (str_split($b9f3f039ea3bf5ca, PACKET_SIZE) as $fe4c6aae49a89941) {
					list(, $Eb5dde5d027876ce) = unpack('N', substr($fe4c6aae49a89941, 0, 4));
					$abc2466c5bfb1b17 = $Eb5dde5d027876ce >> 24 & 255;

					if ($abc2466c5bfb1b17 == 71) {
						if (substr($fe4c6aae49a89941, 6, 4) == PAT_HEADER) {
							$dd96d5e5f09b92ad = true;
							$dabbbb018c906611 = array();
						} else {
							$b49d848d5d4e13b6 = $Eb5dde5d027876ce >> 4 & 3;

							if (($b49d848d5d4e13b6 & 2) !== 2) {
							} else {
								if (!(0 < count($dabbbb018c906611) && unpack('C', $fe4c6aae49a89941[4])[1] == 7 && substr($fe4c6aae49a89941, 4, 2) == KEYFRAME_HEADER)) {
								} else {
									$e1034511e63f0e9e = implode('', $dabbbb018c906611);
									$Eb8625bccd4f95c5 = true;
									$dd96d5e5f09b92ad = false;
									$dabbbb018c906611 = array();
									$fd4e6cc52b9e7850 = new TS();
									$fd4e6cc52b9e7850->setPacket($fe4c6aae49a89941);
									$a7d6eeaedf862a0c = $fd4e6cc52b9e7850->parsePacket();

									if (!isset($a7d6eeaedf862a0c['pts'])) {
									} else {
										$c0b3ca0e630a00ce = $fef6ec871481e2a8;
										$fef6ec871481e2a8 = $a7d6eeaedf862a0c['pts'];
									}

									unset($fd4e6cc52b9e7850);
								}
							}
						}

						if (!($dd96d5e5f09b92ad && count($dabbbb018c906611) < 10)) {
						} else {
							$dabbbb018c906611[] = $fe4c6aae49a89941;
						}

						if (!$Eb8625bccd4f95c5) {
						} else {
							$e1034511e63f0e9e .= $fe4c6aae49a89941;
						}

						$Cb71beb6ebd5bdd2++;
					} else {
						writeError($F26087d31c2bbe4d, '[Loopback] No sync byte detected! Stream is out of sync.');
						$Ea22c4a9ab5b2176 = 0;

						while ($Ea22c4a9ab5b2176 < strlen($fe4c6aae49a89941)) {
							if (substr($fe4c6aae49a89941, $Ea22c4a9ab5b2176, 2) != 'G' . "\x01") {
							} else {
								if (strlen(fread($e1644d67f855686d, $Ea22c4a9ab5b2176)) != $Ea22c4a9ab5b2176) {
								} else {
									writeError($F26087d31c2bbe4d, '[Loopback] Resynchronised stream. Continuing...');
									$D00713bbb5f0a356 = time();

									break;
								}
							}

							$Ea22c4a9ab5b2176++;
						}
						writeError($F26087d31c2bbe4d, "[Loopback] Couldn't rectify out-of-sync data. Exiting.");

						exit();
					}
				}

				if ($Eb8625bccd4f95c5) {
					$D2176e3a77f12992 = round(microtime(true) * 1000);
					$Dfa7f7fd6a9f18a8 = strpos($b9f3f039ea3bf5ca, $e1034511e63f0e9e);

					if (0 >= $Dfa7f7fd6a9f18a8) {
					} else {
						$b071ee81419b5d88 = substr($b9f3f039ea3bf5ca, 0, $Dfa7f7fd6a9f18a8);

						if ($f64c65f8c5f65d9c) {
						} else {
							fwrite($E8601dd191bcdbba, $b071ee81419b5d88, strlen($b071ee81419b5d88));
						}
					}

					if ($f64c65f8c5f65d9c) {
					} else {
						fclose($E8601dd191bcdbba);
						$d55bf693d0ece21c++;
						$E8601dd191bcdbba = fopen(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $d55bf693d0ece21c . '.ts', 'wb');
						$e2a0e8d3bf81a35b[$d55bf693d0ece21c] = true;
						$D6f405849b747c07 = deleteOldSegments($F26087d31c2bbe4d, $ab807f62de794231, $Ad932ae5de6fc9e2);
						updateSegments($F26087d31c2bbe4d, $D6f405849b747c07);
					}

					$f64c65f8c5f65d9c = false;
					fwrite($E8601dd191bcdbba, $e1034511e63f0e9e, strlen($e1034511e63f0e9e));
					$e1034511e63f0e9e = '';
					$Eb8625bccd4f95c5 = false;
				} else {
					fwrite($E8601dd191bcdbba, $b9f3f039ea3bf5ca, strlen($b9f3f039ea3bf5ca));
				}

				$b9f3f039ea3bf5ca = '';
			}

			if (TIMEOUT > time() - $D00713bbb5f0a356) {
				break;
			}

			echo 'No data, timeout reached' . "\n";
			writeError($F26087d31c2bbe4d, '[Loopback] No data received for ' . TIMEOUT . ' seconds, closing source.');
		}

		if (time() - $D00713bbb5f0a356 >= TIMEOUT) {
		} else {
			writeError($F26087d31c2bbe4d, '[Loopback] Connection to source closed unexpectedly.');
		}

		fclose($E8601dd191bcdbba);
		fclose($e1644d67f855686d);
	}
}

function d60457aCFd5df5C9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'Loopback\\[" . intval($F26087d31c2bbe4d) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'Loopback[' . $F26087d31c2bbe4d . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}
}

function deleteOldSegments($F26087d31c2bbe4d, $e4e1253702993155, $e99411c7e3f16dd2)
{
	global $e2a0e8d3bf81a35b;
	$a85e1b7d42c346a0 = array();
	$E415df512cb68430 = max(array_keys($e2a0e8d3bf81a35b));

	foreach ($e2a0e8d3bf81a35b as $B1c1aa7e8b5b4849 => $Ba23222f3ed2dc08) {
		if (!$Ba23222f3ed2dc08) {
		} else {
			if ($B1c1aa7e8b5b4849 < $E415df512cb68430 - ($e4e1253702993155 + $e99411c7e3f16dd2) + 1) {
				$e2a0e8d3bf81a35b[$B1c1aa7e8b5b4849] = false;
				@unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $B1c1aa7e8b5b4849 . '.ts');
			} else {
				if ($B1c1aa7e8b5b4849 == $E415df512cb68430) {
				} else {
					$a85e1b7d42c346a0[] = $B1c1aa7e8b5b4849;
				}
			}
		}
	}

	if ($e4e1253702993155 >= count($a85e1b7d42c346a0)) {
	} else {
		$a85e1b7d42c346a0 = array_slice($a85e1b7d42c346a0, count($a85e1b7d42c346a0) - $e4e1253702993155, $e4e1253702993155);
	}

	return $a85e1b7d42c346a0;
}

function updateSegments($F26087d31c2bbe4d, $D6f405849b747c07)
{
	global $Ce2588e350bd2724;
	global $c0b3ca0e630a00ce;
	global $fef6ec871481e2a8;
	$a1ca7d888fba44a6 = '#EXTM3U' . "\n" . '#EXT-X-VERSION:3' . "\n" . '#EXT-X-TARGETDURATION:4' . "\n" . '#EXT-X-MEDIA-SEQUENCE:';
	$Af165d3b11356e16 = false;

	foreach ($D6f405849b747c07 as $d55bf693d0ece21c) {
		if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $d55bf693d0ece21c . '.ts')) {
		} else {
			if ($Af165d3b11356e16) {
			} else {
				$a1ca7d888fba44a6 .= $d55bf693d0ece21c . "\n";
				$Af165d3b11356e16 = true;
			}

			if (isset($Ce2588e350bd2724[$d55bf693d0ece21c]) || !$c0b3ca0e630a00ce) {
			} else {
				$Ce2588e350bd2724[$d55bf693d0ece21c] = ($fef6ec871481e2a8 - $c0b3ca0e630a00ce) / 90000;
			}

			$a1ca7d888fba44a6 .= '#EXTINF:' . round((isset($Ce2588e350bd2724[$d55bf693d0ece21c]) ? $Ce2588e350bd2724[$d55bf693d0ece21c] : 10), 0) . '.000000,' . "\n" . $F26087d31c2bbe4d . '_' . $d55bf693d0ece21c . '.ts' . "\n";
		}
	}
	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8', $a1ca7d888fba44a6);
}

function writeError($F26087d31c2bbe4d, $D370fc32f973c6ca)
{
	echo $D370fc32f973c6ca . "\n";
	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '.errors', $D370fc32f973c6ca . "\n", FILE_APPEND | LOCK_EX);
}

function keygen($Bf6b25c7c9707bb0, $Faf50feea3df4ce1)
{
	$D3fa098be3f297cd = 'AYZP6IulCXgssFBfJH68fN8SKxQPZlh5aSAfzxMzD1F473ivbunfgMNTI5ep5Vyy';

	for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < strlen($Faf50feea3df4ce1); $Ea22c4a9ab5b2176++) {
		$Faf50feea3df4ce1[$Ea22c4a9ab5b2176] = $Faf50feea3df4ce1[$Ea22c4a9ab5b2176] ^ $D3fa098be3f297cd[$Ea22c4a9ab5b2176 % strlen($D3fa098be3f297cd)];
	}

	return hash($Bf6b25c7c9707bb0, $Faf50feea3df4ce1);
}

function shutdown()
{
	global $e1644d67f855686d;
	global $E8601dd191bcdbba;
	global $F26087d31c2bbe4d;

	if (!is_resource($E8601dd191bcdbba)) {
	} else {
		@fclose($E8601dd191bcdbba);
	}

	if (!is_resource($e1644d67f855686d)) {
	} else {
		@fclose($e1644d67f855686d);
	}
}
