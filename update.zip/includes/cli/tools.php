<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		set_time_limit(0);
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		$ea6e26d49a4a78cf = (1 < count($argv) ? $argv[1] : null);
		fdc97512d22b990e();
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function fDC97512D22B990e()
{
	global $Fee0d5a474c96306;
	global $ea6e26d49a4a78cf;
	global $C3c8913edb801c35;

	switch ($ea6e26d49a4a78cf) {
		case 'images':
			$a4bc4d305e85a4eb = array();
			$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams`;');
			$Aa8d8af3d37ca869 = $Fee0d5a474c96306->get_row()['count'];

			if (0 >= $Aa8d8af3d37ca869) {
			} else {
				$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

				if ($Fffb76b482d3afe0) {
				} else {
					$Fffb76b482d3afe0 = array(0);
				}

				foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
					try {
						$Fee0d5a474c96306->query('SELECT `stream_icon`, `movie_properties` FROM `streams` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
						$c15d5b523e931f51 = $Fee0d5a474c96306->get_rows();

						foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
							$D92b16dc36690ab9 = json_decode($B59c127fecf35c15['movie_properties'], true);

							if (empty($B59c127fecf35c15['stream_icon']) || substr($B59c127fecf35c15['stream_icon'], 0, 2) != 's:') {
							} else {
								$a4bc4d305e85a4eb[] = $B59c127fecf35c15['stream_icon'];
							}

							if (empty($D92b16dc36690ab9['movie_image']) || substr($D92b16dc36690ab9['movie_image'], 0, 2) != 's:') {
							} else {
								$a4bc4d305e85a4eb[] = $D92b16dc36690ab9['movie_image'];
							}

							if (empty($D92b16dc36690ab9['cover_big']) || substr($D92b16dc36690ab9['cover_big'], 0, 2) != 's:') {
							} else {
								$a4bc4d305e85a4eb[] = $D92b16dc36690ab9['cover_big'];
							}

							if (empty($D92b16dc36690ab9['backdrop_path'][0]) || substr($D92b16dc36690ab9['backdrop_path'][0], 0, 2) != 's:') {
							} else {
								$a4bc4d305e85a4eb[] = $D92b16dc36690ab9['backdrop_path'][0];
							}
						}
					} catch (Exception $c34ae71903f0d920) {
						echo 'Error: ' . $c34ae71903f0d920 . "\n";
					}
				}
			}

			$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_series`;');
			$Aa8d8af3d37ca869 = $Fee0d5a474c96306->get_row()['count'];

			if (0 >= $Aa8d8af3d37ca869) {
			} else {
				$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

				if ($Fffb76b482d3afe0) {
				} else {
					$Fffb76b482d3afe0 = array(0);
				}

				foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
					try {
						$Fee0d5a474c96306->query('SELECT `cover`, `cover_big` FROM `streams_series` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
						$c15d5b523e931f51 = $Fee0d5a474c96306->get_rows();

						foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
							if (empty($B59c127fecf35c15['cover']) || substr($B59c127fecf35c15['cover'], 0, 2) != 's:') {
							} else {
								$a4bc4d305e85a4eb[] = $B59c127fecf35c15['cover'];
							}

							if (empty($B59c127fecf35c15['cover_big']) || substr($B59c127fecf35c15['cover_big'], 0, 2) != 's:') {
							} else {
								$a4bc4d305e85a4eb[] = $B59c127fecf35c15['cover_big'];
							}
						}
					} catch (Exception $c34ae71903f0d920) {
						echo 'Error: ' . $c34ae71903f0d920 . "\n";
					}
				}
			}

			$a4bc4d305e85a4eb = array_unique($a4bc4d305e85a4eb);

			foreach ($a4bc4d305e85a4eb as $A639a7baefc720ee) {
				$B211d7401e6242f3 = explode(':', $A639a7baefc720ee, 3);

				if (intval($B211d7401e6242f3[1]) != SERVER_ID) {
				} else {
					$ef056700aa36a5b4 = explode('/', $B211d7401e6242f3[2]);
					$d953b066e19239c1 = pathinfo($ef056700aa36a5b4[count($ef056700aa36a5b4) - 1]);
					$A639a7baefc720ee = $d953b066e19239c1['filename'];
					$F6264099bf1c569c = Xui\Functions::decrypt($A639a7baefc720ee, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

					if (empty($F6264099bf1c569c) || substr($F6264099bf1c569c, 0, 4) != 'http') {
					} else {
						if (file_exists(IMAGES_PATH . $d953b066e19239c1['basename'])) {
						} else {
							echo 'Downloading: ' . $F6264099bf1c569c . "\n";
							XUI::B2068cE8B339BF70($F6264099bf1c569c);
						}
					}
				}
			}

			break;

		case 'duplicates':
			$ca518e82bd328243 = $Cdb85875fd50f459 = array();
			$Fee0d5a474c96306->query('SELECT `a`.`id`, `a`.`stream_source` FROM `streams` `a` INNER JOIN (SELECT  `stream_source`, COUNT(*) `totalCount` FROM `streams` WHERE `type` IN (2,5) GROUP BY `stream_source`) `b` ON `a`.`stream_source` = `b`.`stream_source` WHERE `b`.`totalCount` > 1;');

			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$ca518e82bd328243[md5($C740da31596f24ef['stream_source'])][] = $C740da31596f24ef['id'];
			}

			foreach ($ca518e82bd328243 as $C3c8913edb801c35 => $B909d0e1f7004f1a) {
				array_shift($B909d0e1f7004f1a);

				foreach ($B909d0e1f7004f1a as $F26087d31c2bbe4d) {
					$Cdb85875fd50f459[] = intval($F26087d31c2bbe4d);
				}
			}

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				foreach (array_chunk($Cdb85875fd50f459, 100) as $f75c01ea43f2cd76) {
					deleteStreams($f75c01ea43f2cd76);
				}
			}

			break;

		case 'bouquets':
			$Cdb85875fd50f459 = array(array(), array());
			$Fee0d5a474c96306->query('SELECT `id` FROM `streams`;');

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$Cdb85875fd50f459[0][] = intval($C740da31596f24ef['id']);
				}
			}

			$Fee0d5a474c96306->query('SELECT `id` FROM `streams_series`;');

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$Cdb85875fd50f459[1][] = intval($C740da31596f24ef['id']);
				}
			}

			$Fee0d5a474c96306->query('SELECT * FROM `bouquets` ORDER BY `bouquet_order` ASC;');

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				foreach ($Fee0d5a474c96306->get_rows() as $ddf0508b312dbfb8) {
					$D480255818428bfd = array(array(), array(), array(), array());

					foreach (json_decode($ddf0508b312dbfb8['bouquet_channels'], true) as $C3c8913edb801c35) {
						if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[0]))) {
						} else {
							$D480255818428bfd[0][] = intval($C3c8913edb801c35);
						}
					}

					foreach (json_decode($ddf0508b312dbfb8['bouquet_movies'], true) as $C3c8913edb801c35) {
						if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[0]))) {
						} else {
							$D480255818428bfd[1][] = intval($C3c8913edb801c35);
						}
					}

					foreach (json_decode($ddf0508b312dbfb8['bouquet_radios'], true) as $C3c8913edb801c35) {
						if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[0]))) {
						} else {
							$D480255818428bfd[2][] = intval($C3c8913edb801c35);
						}
					}

					foreach (json_decode($ddf0508b312dbfb8['bouquet_series'], true) as $C3c8913edb801c35) {
						if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[1]))) {
						} else {
							$D480255818428bfd[3][] = intval($C3c8913edb801c35);
						}
					}
					$Fee0d5a474c96306->query("UPDATE `bouquets` SET `bouquet_channels` = '[" . implode(',', array_map('intval', $D480255818428bfd[0])) . "]', `bouquet_movies` = '[" . implode(',', array_map('intval', $D480255818428bfd[1])) . "]', `bouquet_radios` = '[" . implode(',', array_map('intval', $D480255818428bfd[2])) . "]', `bouquet_series` = '[" . implode(',', array_map('intval', $D480255818428bfd[3])) . "]' WHERE `id` = ?;", $ddf0508b312dbfb8['id']);
				}
			}

			break;
	}
}

function deleteStreams($Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('DELETE FROM `lines_logs` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `mag_claims` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams` WHERE `id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_episodes` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_errors` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_logs` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_options` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_stats` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `watch_refresh` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `lines_live` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `recordings` WHERE `created_id` IN (' . implode(',', $Aa8c918a2a91966f) . ') OR `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `stream_id` = 0 WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('SELECT `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `parent_id` IS NOT NULL AND `parent_id` > 0 AND `parent_id` NOT IN (SELECT `id` FROM `servers` WHERE `server_type` = 0);');
	$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', SERVER_ID, time(), json_encode(array('type' => 'update_streams', 'id' => $Aa8c918a2a91966f)));

	foreach (array_keys(XUI::$rServers) as $d58b4f8653a391d8) {
		$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`, `cache`) VALUES(?, ?, ?, 1);', $d58b4f8653a391d8, time(), json_encode(array('type' => 'delete_vods', 'id' => $Aa8c918a2a91966f)));
	}

	return true;
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
