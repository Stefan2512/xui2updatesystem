<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		set_time_limit(0);
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		shell_exec('kill -9 $(ps aux | grep scanner | grep -v grep | grep -v ' . getmypid() . " | awk '{print \$2}')");

		if (XUI::$rSettings['on_demand_checker']) {
			$Af547236269d8f66 = null;
			$F2319168a4d07d06 = 60;
			$Ba344b2758e3e955 = md5_file(__FILE__);

			while (true && $Fee0d5a474c96306->ping()) {
				if ($Af547236269d8f66 && $F2319168a4d07d06 > time() - $Af547236269d8f66) {
				} else {
					if (md5_file(__FILE__) == $Ba344b2758e3e955) {
						XUI::$rSettings = XUI::d761E78da5Eb70FB(true);
						$Af547236269d8f66 = time();
					} else {
						echo 'File changed! Break.' . "\n";
					}
				}

				if ($Fee0d5a474c96306->query('SELECT `streams`.* FROM `streams` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `streams`.`id` WHERE `streams_servers`.`pid` IS NULL AND `streams_servers`.`on_demand` = 1 AND `streams_servers`.`parent_id` IS NULL AND `streams`.`type` = 1 AND `streams`.`direct_source` = 0 AND `streams_servers`.`server_id` = ? AND (UNIX_TIMESTAMP() - (SELECT MAX(`date`) FROM `ondemand_check` WHERE `stream_id` = `streams`.`id` AND `server_id` = `streams_servers`.`server_id`) > ? OR (SELECT MAX(`date`) FROM `ondemand_check` WHERE `stream_id` = `streams`.`id` AND `server_id` = `streams_servers`.`server_id`) IS NULL);', SERVER_ID, (XUI::$rSettings['on_demand_scan_time'] ?: 3600))) {
					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							echo '[' . $C740da31596f24ef['id'] . '] - ' . $C740da31596f24ef['stream_display_name'] . "\n";
							$Fee0d5a474c96306->query('SELECT t1.*, t2.* FROM `streams_options` t1, `streams_arguments` t2 WHERE t1.stream_id = ? AND t1.argument_id = t2.id', $C740da31596f24ef['id']);
							$f86c7f12032c787a = $Fee0d5a474c96306->get_rows();
							$c16539fff4ffd50f = (intval($C740da31596f24ef['probesize_ondemand']) ?: 512000);
							$a8d6b4f70a067a08 = '10000000';
							$cd2a4260ef308305 = intval($a8d6b4f70a067a08 / 1000000) + XUI::$rSettings['probe_extra_wait'];

							if (!(XUI::$rSettings['on_demand_max_probe'] < $cd2a4260ef308305 && 0 < XUI::$rSettings['on_demand_max_probe'])) {
							} else {
								$cd2a4260ef308305 = intval(XUI::$rSettings['on_demand_max_probe']);
							}

							$f4efda65b81ca641 = 'timeout ' . $cd2a4260ef308305 . ' ' . XUI::$rFFPROBE . ' {FETCH_OPTIONS} -probesize ' . $c16539fff4ffd50f . ' -analyzeduration ' . $a8d6b4f70a067a08 . ' -i {STREAM_SOURCE} -loglevel error -print_format json -show_streams -show_format 2>' . STREAMS_TMP_PATH . $C740da31596f24ef['id'] . '._errors';
							$bbfc9bd8432031f5 = json_decode($C740da31596f24ef['stream_source'], true);
							$c857e57ce6074885 = 0;
							$Db09f9628b0daff0 = null;

							foreach ($bbfc9bd8432031f5 as $c8d91fcd2309e48a) {
								$Ce7e235cbd59b7c3 = false;
								$B7f18f2aa03cd644 = $c8d91fcd2309e48a;
								$ecc9029bfbc77eed = XUI::CE3ba3178Bc00D1c($c8d91fcd2309e48a);
								echo 'Checking source: ' . $c8d91fcd2309e48a . "\n";
								$e97435234acb895c = parse_url($ecc9029bfbc77eed);
								$e1aa7b5f34c25c15 = XUI::c7c23F3aAEa4F10e($ecc9029bfbc77eed);

								if (!($e1aa7b5f34c25c15 && XUI::$rSettings['send_xui_header'])) {
								} else {
									foreach (array_keys($f86c7f12032c787a) as $C3c8913edb801c35) {
										if ($f86c7f12032c787a[$C3c8913edb801c35]['argument_key'] != 'headers') {
										} else {
											$f86c7f12032c787a[$C3c8913edb801c35]['value'] .= "\r\n" . 'X-XUI-Detect:1';
											$Ce7e235cbd59b7c3 = true;
										}
									}

									if ($Ce7e235cbd59b7c3) {
									} else {
										$f86c7f12032c787a[] = array('value' => 'X-XUI-Detect:1', 'argument_key' => 'headers', 'argument_cat' => 'fetch', 'argument_wprotocol' => 'http', 'argument_type' => 'text', 'argument_cmd' => "-headers '%s" . "\r\n" . "'");
									}
								}

								if (!($e1aa7b5f34c25c15 && XUI::$rSettings['request_prebuffer'] == 1)) {
								} else {
									foreach (array_keys($f86c7f12032c787a) as $C3c8913edb801c35) {
										if ($f86c7f12032c787a[$C3c8913edb801c35]['argument_key'] != 'headers') {
										} else {
											$f86c7f12032c787a[$C3c8913edb801c35]['value'] .= "\r\n" . 'X-XUI-Prebuffer:1';
											$Ce7e235cbd59b7c3 = true;
										}
									}

									if ($Ce7e235cbd59b7c3) {
									} else {
										$f86c7f12032c787a[] = array('value' => 'X-XUI-Prebuffer:1', 'argument_key' => 'headers', 'argument_cat' => 'fetch', 'argument_wprotocol' => 'http', 'argument_type' => 'text', 'argument_cmd' => "-headers '%s" . "\r\n" . "'");
									}
								}

								$C6033ec178efa2ae = strtolower(substr($ecc9029bfbc77eed, 0, strpos($ecc9029bfbc77eed, '://')));
								$ffce8f666f9d039c = implode(' ', XUI::a4c93c52f5D2D72d($f86c7f12032c787a, $C6033ec178efa2ae, 'fetch'));

								if (!($e1aa7b5f34c25c15 && XUI::$rSettings['api_probe'])) {
								} else {
									$d88a567c47b3ff49 = $e97435234acb895c['scheme'] . '://' . $e97435234acb895c['host'] . ':' . $e97435234acb895c['port'] . '/probe/' . base64_encode($e97435234acb895c['path']);
									$C4af185e24cf9086 = round(microtime(true) * 1000);
									$e4cfabbf1b1ea27e = json_decode(XUI::A2aF9198cFD841A1($d88a567c47b3ff49), true);
									$Ac4925333fce02b2 = round(microtime(true) * 1000) - $C4af185e24cf9086;

									if (!($e4cfabbf1b1ea27e && isset($e4cfabbf1b1ea27e['streams']))) {
									} else {
										echo 'Got stream information via API' . "\n";

										break;
									}
								}

								$C4af185e24cf9086 = round(microtime(true) * 1000);
								$e4cfabbf1b1ea27e = json_decode(shell_exec(str_replace(array('{FETCH_OPTIONS}', '{STREAM_SOURCE}'), array($ffce8f666f9d039c, escapeshellarg($ecc9029bfbc77eed)), $f4efda65b81ca641)), true);
								$Ac4925333fce02b2 = round(microtime(true) * 1000) - $C4af185e24cf9086;

								if (!(file_exists(STREAMS_TMP_PATH . $C740da31596f24ef['id'] . '._errors') && 0 < filesize(STREAMS_TMP_PATH . $C740da31596f24ef['id'] . '._errors'))) {
								} else {
									if ($Db09f9628b0daff0 || $c857e57ce6074885 != 0) {
									} else {
										$Db09f9628b0daff0 = file_get_contents(STREAMS_TMP_PATH . $C740da31596f24ef['id'] . '._errors');
									}

									unlink(STREAMS_TMP_PATH . $C740da31596f24ef['id'] . '._errors');
								}

								if (!($e4cfabbf1b1ea27e && isset($e4cfabbf1b1ea27e['streams']))) {
									if (!$C740da31596f24ef['llod']) {
										$c857e57ce6074885++;
									} else {
										break;
									}
								} else {
									echo 'Got stream information via ffprobe' . "\n";

									break;
								}
							}

							if (!empty($e4cfabbf1b1ea27e)) {
								echo 'Source live!' . "\n";
								$e4cfabbf1b1ea27e = XUI::cEfC1CE0aDbb45d2($e4cfabbf1b1ea27e);
								$Dd7dd922fac30f26 = ($e4cfabbf1b1ea27e['codecs']['audio']['codec_name'] ?: null);
								$F2735dad02d30e84 = ($e4cfabbf1b1ea27e['codecs']['video']['codec_name'] ?: null);
								$fbf4f3f4868222b7 = ($e4cfabbf1b1ea27e['codecs']['video']['height'] ?: null);
								$Cdae3c14d1ac018f = ($e4cfabbf1b1ea27e['codecs']['video']['bit_rate'] ?: 0);
								$d30b75b3869ea34e = ($e4cfabbf1b1ea27e['codecs']['audio']['bit_rate'] ?: 0);
								$Fc6b82af9a3c82e5 = (intval(explode('/', $e4cfabbf1b1ea27e['codecs']['video']['r_frame_rate'])[0]) ?: 0);

								if ($Fc6b82af9a3c82e5 != 0) {
								} else {
									$Fc6b82af9a3c82e5 = (intval(explode('/', $e4cfabbf1b1ea27e['codecs']['video']['avg_frame_rate'])[0]) ?: 0);
								}

								if (1000 > $Fc6b82af9a3c82e5) {
								} else {
									$Fc6b82af9a3c82e5 = intval($Fc6b82af9a3c82e5 / 1000);
								}

								if (!$fbf4f3f4868222b7) {
								} else {
									$fbf4f3f4868222b7 = XUI::CcedFAEa1D970310(array(240, 360, 480, 576, 720, 1080, 1440, 2160), $fbf4f3f4868222b7);
								}

								$Ba23222f3ed2dc08 = 1;
							} else {
								echo 'Source down!' . "\n";
								$Fc6b82af9a3c82e5 = $Dd7dd922fac30f26 = $F2735dad02d30e84 = $fbf4f3f4868222b7 = $Ac4925333fce02b2 = null;
								$c857e57ce6074885 = $Ba23222f3ed2dc08 = 0;
							}

							$c8d91fcd2309e48a = $bbfc9bd8432031f5[$c857e57ce6074885];
							$Fee0d5a474c96306->query('INSERT INTO `ondemand_check`(`stream_id`, `server_id`, `status`, `source_id`, `source_url`, `fps`, `video_codec`, `audio_codec`, `resolution`, `response`, `errors`, `date`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);', $C740da31596f24ef['id'], SERVER_ID, $Ba23222f3ed2dc08, $c857e57ce6074885, $c8d91fcd2309e48a, $Fc6b82af9a3c82e5, $F2735dad02d30e84, $Dd7dd922fac30f26, $fbf4f3f4868222b7, $Ac4925333fce02b2, $Db09f9628b0daff0, time());
							$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `ondemand_check` = ? WHERE `stream_id` = ? AND `server_id` = ?;', $Fee0d5a474c96306->last_insert_id(), $C740da31596f24ef['id'], SERVER_ID);
							echo "\n";
						}
					}

					sleep(60);

					break;
				}
			}

			if (!is_object($Fee0d5a474c96306)) {
			} else {
				$Fee0d5a474c96306->close_mysql();
			}

			shell_exec('(sleep 1; ' . PHP_BIN . ' ' . __FILE__ . ' ) > /dev/null 2>/dev/null &');
		} else {
			echo 'On-Demand - Source Scanner is disabled.' . "\n";

			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}
