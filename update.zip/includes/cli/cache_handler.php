<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		set_time_limit(0);
		$f9b07d216a168dcc = getmypid();
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		shell_exec('kill -9 $(ps aux | grep cache_handler | grep -v grep | grep -v ' . $f9b07d216a168dcc . " | awk '{print \$2}')");
		$Af547236269d8f66 = null;
		$F2319168a4d07d06 = 60;
		$Ba344b2758e3e955 = md5_file(__FILE__);
		XUI::$rSettings = XUI::d761e78DA5EB70fb(true);

		if (XUI::$rSettings['enable_cache']) {
			while (true) {
				if (!$Fee0d5a474c96306->ping()) {
					break;
				}

				if ($Af547236269d8f66 && $F2319168a4d07d06 > time() - $Af547236269d8f66) {
				} else {
					XUI::$rSettings = XUI::D761e78DA5eB70fb(true);
					XUI::$rServers = XUI::f99D78e199d641D5(true);

					if (XUI::$rSettings['enable_cache']) {
						if (md5_file(__FILE__) == $Ba344b2758e3e955) {
							$Af547236269d8f66 = time();
						} else {
							echo 'File changed! Break.' . "\n";
						}
					} else {
						echo 'Cache disabled! Break.' . "\n";
					}
				}

				try {
					$c121727b49ad2f87 = array();

					foreach (glob(SIGNALS_TMP_PATH . 'cache_*') as $Daef1121feb5ecc6) {
						list($D3fa098be3f297cd, $a27e64cc6ce01033) = json_decode(file_get_contents($Daef1121feb5ecc6), true);
						list($Eb5dde5d027876ce) = explode('/', $D3fa098be3f297cd);

						switch ($Eb5dde5d027876ce) {
							case 'restream_block_user':
								list($bb49d7112ea639bd, $D78ff1d0edade5eb, $F26087d31c2bbe4d, $c59ec257c284c894) = explode('/', $D3fa098be3f297cd);
								$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $D78ff1d0edade5eb);
								$Fee0d5a474c96306->query('INSERT INTO `detect_restream_logs`(`user_id`, `stream_id`, `ip`, `time`) VALUES(?, ?, ?, ?);', $D78ff1d0edade5eb, $F26087d31c2bbe4d, $c59ec257c284c894, time());
								$c121727b49ad2f87[] = $D78ff1d0edade5eb;

								break;

							case 'forced_country':
								$D78ff1d0edade5eb = intval(explode('/', $D3fa098be3f297cd)[1]);
								$Fee0d5a474c96306->query('UPDATE `lines` SET `forced_country` = ? WHERE `id` = ?', $a27e64cc6ce01033, $D78ff1d0edade5eb);
								$c121727b49ad2f87[] = $D78ff1d0edade5eb;

								break;

							case 'isp':
								$D78ff1d0edade5eb = intval(explode('/', $D3fa098be3f297cd)[1]);
								$ad856642008b1a70 = json_decode($a27e64cc6ce01033, true);
								$Fee0d5a474c96306->query('UPDATE `lines` SET `isp_desc` = ?, `as_number` = ? WHERE `id` = ?', $ad856642008b1a70[0], $ad856642008b1a70[1], $D78ff1d0edade5eb);
								$c121727b49ad2f87[] = $D78ff1d0edade5eb;

								break;

							case 'expiring':
								$D78ff1d0edade5eb = intval(explode('/', $D3fa098be3f297cd)[1]);
								$Fee0d5a474c96306->query('UPDATE `lines` SET `last_expiration_video` = ? WHERE `id` = ?;', time(), $D78ff1d0edade5eb);
								$c121727b49ad2f87[] = $D78ff1d0edade5eb;

								break;

							case 'flood_attack':
								list($bb49d7112ea639bd, $c59ec257c284c894) = explode('/', $D3fa098be3f297cd);
								$Fee0d5a474c96306->query('INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES(?,?,?)', $c59ec257c284c894, 'FLOOD ATTACK', time());
								touch(FLOOD_TMP_PATH . 'block_' . $c59ec257c284c894);

								break;

							case 'bruteforce_attack':
								list($bb49d7112ea639bd, $c59ec257c284c894) = explode('/', $D3fa098be3f297cd);
								$Fee0d5a474c96306->query('INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES(?,?,?)', $c59ec257c284c894, 'BRUTEFORCE ATTACK', time());
								touch(FLOOD_TMP_PATH . 'block_' . $c59ec257c284c894);

								break;
						}
						unlink($Daef1121feb5ecc6);
					}
					$c121727b49ad2f87 = array_unique($c121727b49ad2f87);

					foreach ($c121727b49ad2f87 as $D78ff1d0edade5eb) {
						XUI::BC77eDC4169f1BAA($D78ff1d0edade5eb);
					}
					sleep(1);
				} catch (Exception $c34ae71903f0d920) {
					echo 'Error!' . "\n";
				}
			}

			if (is_object($Fee0d5a474c96306)) {
				$Fee0d5a474c96306->close_mysql();
			}

			shell_exec('(sleep 1; ' . PHP_BIN . ' ' . __FILE__ . ' ) > /dev/null 2>/dev/null &');
		} else {
			echo 'Cache disabled.' . "\n";

			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}
