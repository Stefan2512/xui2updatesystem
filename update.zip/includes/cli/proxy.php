<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc > 1) {
		$F26087d31c2bbe4d = intval($argv[1]);
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		d60457acfd5df5c9($F26087d31c2bbe4d);
		register_shutdown_function('shutdown');
		set_time_limit(0);
		cli_set_process_title('XUIProxy[' . $F26087d31c2bbe4d . ']');
		$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.server_id = ? WHERE t1.id = ?', SERVER_ID, $F26087d31c2bbe4d);

		if ($Fee0d5a474c96306->num_rows() > 0) {
			file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor', getmypid());
			@unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid');
			$bb0071da5a239b0c = $Fee0d5a474c96306->get_row();
			$Fee0d5a474c96306->query('SELECT t1.*, t2.* FROM `streams_options` t1, `streams_arguments` t2 WHERE t1.stream_id = ? AND t1.argument_id = t2.id', $F26087d31c2bbe4d);
			$f86c7f12032c787a = $Fee0d5a474c96306->get_rows(true, 'argument_key');
			define('PAT_HEADER', "�\r");
			define('PACKET_SIZE', 188);
			define('BUFFER_SIZE', 12032);
			define('PAT_PERIOD', 2);
			define('TIMEOUT', 20);
			define('CLOSE_EMPTY', 3000);
			define('STORE_PREBUFFER', 1128000);
			define('MAX_PREBUFFER', 10528000);
			$e1644d67f855686d = null;
			startproxy($F26087d31c2bbe4d, $bb0071da5a239b0c, $f86c7f12032c787a);
		} else {
			XUI::a52Ea4C1EaD81De2($F26087d31c2bbe4d);

			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function D60457aCfD5dF5c9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'XUIProxy\\[" . intval($F26087d31c2bbe4d) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'XUIProxy[' . $F26087d31c2bbe4d . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}
}

function startProxy($F26087d31c2bbe4d, $bb0071da5a239b0c, $f86c7f12032c787a)
{
	global $e1644d67f855686d;
	global $Fee0d5a474c96306;

	if (file_exists(CONS_TMP_PATH . $F26087d31c2bbe4d . '/')) {
	} else {
		mkdir(CONS_TMP_PATH . $F26087d31c2bbe4d);
	}

	$b3374866087774a1 = (isset($f86c7f12032c787a['user_agent']) ? ($f86c7f12032c787a['user_agent']['value'] ?: $f86c7f12032c787a['user_agent']['argument_default_value']) : 'Mozilla/5.0');
	$Be3590384c940166 = array('ssl' => array('verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true), 'http' => array('method' => 'GET', 'user_agent' => $b3374866087774a1, 'timeout' => TIMEOUT, 'header' => ''));

	if (!isset($f86c7f12032c787a['proxy'])) {
	} else {
		$Be3590384c940166['http']['proxy'] = 'tcp://' . $f86c7f12032c787a['proxy']['value'];
		$Be3590384c940166['http']['request_fulluri'] = true;
	}

	if (!isset($f86c7f12032c787a['cookie'])) {
	} else {
		$Be3590384c940166['http']['header'] .= 'Cookie: ' . $f86c7f12032c787a['cookie']['value'] . "\r\n";
	}

	if (!XUI::$rSettings['request_prebuffer']) {
	} else {
		$Be3590384c940166['http']['header'] .= 'X-XUI-Prebuffer: 1' . "\r\n";
	}

	$B2976aadbf91a696 = stream_context_create($Be3590384c940166);
	$ce2460e0c52a99da = json_decode($bb0071da5a239b0c['stream_source'], true);
	$e1644d67f855686d = getActiveStream($ce2460e0c52a99da, $B2976aadbf91a696);

	if (is_resource($e1644d67f855686d)) {
	} else {
		$Ae2b613e51651b56 = (!empty($Be3590384c940166['http']['header']) ? '-headers ' . escapeshellarg($Be3590384c940166['http']['header']) : '');
		$Fa288895c003c519 = (!empty($f86c7f12032c787a['proxy']) ? '-http_proxy ' . escapeshellarg($f86c7f12032c787a['proxy']) : '');
		$cf1c389bda3e30fd = XUI::$rFFMPEG_CPU . ' -copyts -vsync 0 -nostats -nostdin -hide_banner -loglevel quiet -y -user_agent ' . escapeshellarg($b3374866087774a1) . ' ' . $Ae2b613e51651b56 . ' ' . $Fa288895c003c519 . ' -i ' . escapeshellarg($e1644d67f855686d) . ' -map 0 -c copy -mpegts_flags +initial_discontinuity -pat_period ' . PAT_PERIOD . ' -f mpegts -';
		$e1644d67f855686d = popen($cf1c389bda3e30fd, 'rb');
	}

	if ($e1644d67f855686d) {
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `monitor_pid` = ?, `pid` = ?, `stream_started` = ?, `stream_status` = 0, `to_analyze` = 0 WHERE `server_stream_id` = ?', getmypid(), getmypid(), time(), $bb0071da5a239b0c['server_stream_id']);

		if (!XUI::$rSettings['enable_cache']) {
		} else {
			XUI::afa0F3fFB001b9Be($F26087d31c2bbe4d);
		}

		shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*.ts');
		file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid', getmypid());
		$Fee0d5a474c96306->close_mysql();
		$Ccba8a7b57e3ee80 = null;
		stream_set_blocking($e1644d67f855686d, false);
		$ab0657150415d4c8 = $Ebb0c33fda7f8abe = $e1034511e63f0e9e = $b9f3f039ea3bf5ca = $fe4c6aae49a89941 = '';
		$D495d176852bba7e = $dabbbb018c906611 = array();
		$F35a775002cfc083 = $dd96d5e5f09b92ad = false;
		$A14f8386b7241bd1 = false;

		while (!feof($e1644d67f855686d)) {
			stream_set_timeout($e1644d67f855686d, TIMEOUT);
			$b9f3f039ea3bf5ca = $b9f3f039ea3bf5ca . $ab0657150415d4c8 . fread($e1644d67f855686d, BUFFER_SIZE - strlen($b9f3f039ea3bf5ca . $ab0657150415d4c8));
			$ab0657150415d4c8 = '';
			$B82cf6c4229ec535 = floor(strlen($b9f3f039ea3bf5ca) / PACKET_SIZE);

			if (0 < $B82cf6c4229ec535) {
				if (strlen($b9f3f039ea3bf5ca) == $B82cf6c4229ec535 * PACKET_SIZE) {
				} else {
					$ab0657150415d4c8 = substr($b9f3f039ea3bf5ca, $B82cf6c4229ec535 * PACKET_SIZE, strlen($b9f3f039ea3bf5ca) - $B82cf6c4229ec535 * PACKET_SIZE);
					$b9f3f039ea3bf5ca = substr($b9f3f039ea3bf5ca, 0, $B82cf6c4229ec535 * PACKET_SIZE);
				}

				foreach (str_split($b9f3f039ea3bf5ca, PACKET_SIZE) as $fe4c6aae49a89941) {
					list(, $Eb5dde5d027876ce) = unpack('N', substr($fe4c6aae49a89941, 0, 4));
					$abc2466c5bfb1b17 = $Eb5dde5d027876ce >> 24 & 255;

					if ($abc2466c5bfb1b17 != 71) {
					} else {
						if (substr($fe4c6aae49a89941, 6, 4) == PAT_HEADER) {
							$dd96d5e5f09b92ad = true;
							$dabbbb018c906611 = array();
						} else {
							$b49d848d5d4e13b6 = $Eb5dde5d027876ce >> 4 & 3;

							if (($b49d848d5d4e13b6 & 2) !== 2) {
							} else {
								if (!(0 < count($dabbbb018c906611) && unpack('C', $fe4c6aae49a89941[4])[1] == 7 && substr($fe4c6aae49a89941, 4, 2) == "\x07" . 'P')) {
								} else {
									if ($e1034511e63f0e9e && STORE_PREBUFFER > strlen($e1034511e63f0e9e)) {
									} else {
										$e1034511e63f0e9e = implode('', $dabbbb018c906611) . $fe4c6aae49a89941;
									}

									$A14f8386b7241bd1 = true;
									$dd96d5e5f09b92ad = false;
									$dabbbb018c906611 = array();
								}
							}
						}
					}

					if (!($dd96d5e5f09b92ad && count($dabbbb018c906611) < 10)) {
					} else {
						$dabbbb018c906611[] = $fe4c6aae49a89941;
					}

					if (!(strlen($e1034511e63f0e9e) < MAX_PREBUFFER && $A14f8386b7241bd1)) {
					} else {
						$e1034511e63f0e9e .= $fe4c6aae49a89941;
					}

					if ($F35a775002cfc083) {
					} else {
						$Ebb0c33fda7f8abe .= $fe4c6aae49a89941;

						if (3000 * PACKET_SIZE > strlen($Ebb0c33fda7f8abe)) {
						} else {
							echo 'Write analysis buffer' . "\n";
							file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '.analyse', $Ebb0c33fda7f8abe);
							$Ebb0c33fda7f8abe = null;
							$F35a775002cfc083 = true;
						}
					}
				}
				$E685cf320639b639 = getSockets();

				if (0 < count($E685cf320639b639)) {
					$Ccba8a7b57e3ee80 = round(microtime(true) * 1000);

					foreach ($E685cf320639b639 as $df80e2612fca9902) {
						$Df7149ba3185b924 = CONS_TMP_PATH . $F26087d31c2bbe4d . '/' . $df80e2612fca9902;

						if (!(file_exists($Df7149ba3185b924) && (!isset($D495d176852bba7e[$df80e2612fca9902]) || !empty($b9f3f039ea3bf5ca)))) {
						} else {
							$Cae0f755f512a801 = socket_create(AF_UNIX, SOCK_DGRAM, 0);
							socket_set_nonblock($Cae0f755f512a801);

							if (!isset($D495d176852bba7e[$df80e2612fca9902])) {
								if (empty($e1034511e63f0e9e)) {
								} else {
									echo 'Send prebuffer: ' . strlen($e1034511e63f0e9e) . ' bytes' . "\n";
									$D495d176852bba7e[$df80e2612fca9902] = true;

									foreach (str_split($e1034511e63f0e9e, BUFFER_SIZE) as $f75c01ea43f2cd76) {
										socket_sendto($Cae0f755f512a801, $f75c01ea43f2cd76, BUFFER_SIZE, 0, $Df7149ba3185b924);
									}
								}
							} else {
								if (empty($b9f3f039ea3bf5ca)) {
								} else {
									socket_sendto($Cae0f755f512a801, $b9f3f039ea3bf5ca, BUFFER_SIZE, 0, $Df7149ba3185b924);
								}
							}

							socket_close($Cae0f755f512a801);
						}
					}
				} else {
					if ($Ccba8a7b57e3ee80) {
					} else {
						$Ccba8a7b57e3ee80 = round(microtime(true) * 1000);
					}

					if (CLOSE_EMPTY > round(microtime(true) * 1000) - $Ccba8a7b57e3ee80) {
					} else {
						echo 'No sockets waiting, close stream' . "\n";
					}
				}

				$b9f3f039ea3bf5ca = '';

				break;
			}

			if ($Ccba8a7b57e3ee80 && 100000 >= round(microtime(true) * 1000) - $Ccba8a7b57e3ee80) {
			} else {
				$E685cf320639b639 = getSockets();

				if (0 < count($E685cf320639b639)) {
					$Ccba8a7b57e3ee80 = round(microtime(true) * 1000);

					if (empty($e1034511e63f0e9e)) {
					} else {
						foreach ($E685cf320639b639 as $df80e2612fca9902) {
							if (isset($D495d176852bba7e[$df80e2612fca9902])) {
							} else {
								$Cae0f755f512a801 = socket_create(AF_UNIX, SOCK_DGRAM, 0);
								socket_set_nonblock($Cae0f755f512a801);
								echo 'Send prebuffer: ' . strlen($e1034511e63f0e9e) . ' bytes' . "\n";
								$D495d176852bba7e[$df80e2612fca9902] = true;

								foreach (str_split($e1034511e63f0e9e, BUFFER_SIZE) as $f75c01ea43f2cd76) {
									socket_sendto($Cae0f755f512a801, $f75c01ea43f2cd76, BUFFER_SIZE, 0, CONS_TMP_PATH . $F26087d31c2bbe4d . '/' . $df80e2612fca9902);
								}
								socket_close($Cae0f755f512a801);
							}
						}
					}
				} else {
					if ($Ccba8a7b57e3ee80) {
					} else {
						$Ccba8a7b57e3ee80 = round(microtime(true) * 1000);
					}

					if (CLOSE_EMPTY > round(microtime(true) * 1000) - $Ccba8a7b57e3ee80) {
					} else {
						echo 'No sockets waiting, close stream' . "\n";
					}
				}
			}
		}
		fclose($e1644d67f855686d);
		$Fee0d5a474c96306->db_connect();
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `monitor_pid` = null, `pid` = null, `stream_status` = 1 WHERE `server_stream_id` = ?;', $bb0071da5a239b0c['server_stream_id']);

		if (!XUI::$rSettings['enable_cache']) {
		} else {
			XUI::Afa0F3fFb001b9Be($F26087d31c2bbe4d);
		}

		exit();

		if ($B82cf6c4229ec535 != 0) {
		} else {
			usleep(10000);
		}
	} else {
		echo 'Failed!' . "\n";
		XUI::effEB9F2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'STREAM_START_FAIL');
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `monitor_pid` = null, `pid` = null, `stream_status` = 1 WHERE `server_stream_id` = ?;', $bb0071da5a239b0c['server_stream_id']);

		if (!XUI::$rSettings['enable_cache']) {
		} else {
			XUI::AfA0F3Ffb001b9Be($F26087d31c2bbe4d);
		}
	}
}

function getSockets()
{
	global $F26087d31c2bbe4d;
	$E685cf320639b639 = array();

	if (!($a8f3762d489787d6 = opendir(CONS_TMP_PATH . $F26087d31c2bbe4d . '/'))) {
	} else {
		while (false !== ($bc2874292e0d9ece = readdir($a8f3762d489787d6))) {
			if (!($bc2874292e0d9ece != '.' && $bc2874292e0d9ece != '..')) {
			} else {
				$E685cf320639b639[] = $bc2874292e0d9ece;
			}
		}
		closedir($a8f3762d489787d6);
	}

	return $E685cf320639b639;
}

function getActiveStream($ce2460e0c52a99da, $B2976aadbf91a696)
{
	foreach ($ce2460e0c52a99da as $C700a2b357e5ed65) {
		$C700a2b357e5ed65 = XUI::cE3BA3178bC00d1C($C700a2b357e5ed65);
		$e1644d67f855686d = @fopen($C700a2b357e5ed65, 'rb', false, $B2976aadbf91a696);

		if (!$e1644d67f855686d) {
		} else {
			$c42ee198cc4d5b8a = stream_get_meta_data($e1644d67f855686d);
			$Ae2b613e51651b56 = array();

			foreach ($c42ee198cc4d5b8a['wrapper_data'] as $Ff014d0ebd314fcd) {
				if (strpos($Ff014d0ebd314fcd, 'HTTP') !== 0) {
					list($D3fa098be3f297cd, $b6842cb20051e925) = explode(': ', $Ff014d0ebd314fcd);
					$Ae2b613e51651b56[$D3fa098be3f297cd] = $b6842cb20051e925;
				} else {
					$Ae2b613e51651b56[0] = $Ff014d0ebd314fcd;
				}
			}
			$c196718c8d49a297 = (is_array($Ae2b613e51651b56['Content-Type']) ? $Ae2b613e51651b56['Content-Type'][count($Ae2b613e51651b56['Content-Type']) - 1] : $Ae2b613e51651b56['Content-Type']);

			if (strtolower($c196718c8d49a297) == 'video/mp2t') {
				return $e1644d67f855686d;
			}

			fclose($e1644d67f855686d);

			if (!in_array(strtolower($c196718c8d49a297), array('application/x-mpegurl', 'application/vnd.apple.mpegurl', 'audio/x-mpegurl'))) {
			} else {
				return $C700a2b357e5ed65;
			}
		}
	}
}

function shutdown()
{
	global $F26087d31c2bbe4d;
	global $e1644d67f855686d;
	@unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor');
	@unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid');
	shell_exec('rm -rf ' . CONS_TMP_PATH . $F26087d31c2bbe4d . '/');

	if (!is_resource($e1644d67f855686d)) {
	} else {
		@fclose($e1644d67f855686d);
	}
}
