<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		set_time_limit(0);
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		shell_exec('kill -9 $(ps aux | grep queue | grep -v grep | grep -v ' . getmypid() . " | awk '{print \$2}')");
		$Af547236269d8f66 = null;
		$F2319168a4d07d06 = 60;
		$Ba344b2758e3e955 = md5_file(__FILE__);

		while (true && $Fee0d5a474c96306->ping()) {
			if ($Af547236269d8f66 && $F2319168a4d07d06 > time() - $Af547236269d8f66) {
			} else {
				if (md5_file(__FILE__) == $Ba344b2758e3e955) {
					XUI::$rSettings = XUI::D761E78Da5Eb70fB(true);
					$Af547236269d8f66 = time();
				} else {
					echo 'File changed! Break.' . "\n";
				}
			}

			if ($Fee0d5a474c96306->query("SELECT `id`, `pid` FROM `queue` WHERE `server_id` = ? AND `pid` IS NOT NULL AND `type` = 'movie' ORDER BY `added` ASC;", SERVER_ID)) {
				$da26920118f0ae06 = $a330db047a007f18 = array();

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if ($C740da31596f24ef['pid'] && (XUI::Dd714ee89c59fBf2($C740da31596f24ef['pid'], 'ffmpeg') || XUI::DD714ee89C59Fbf2($C740da31596f24ef['pid'], PHP_BIN))) {
							$a330db047a007f18[] = $C740da31596f24ef['pid'];
						} else {
							$da26920118f0ae06[] = $C740da31596f24ef['id'];
						}
					}
				}

				$e515557dd75f7fca = (0 < XUI::$rSettings['max_encode_movies'] ? intval(XUI::$rSettings['max_encode_movies']) - count($a330db047a007f18) : 50);

				if (0 >= $e515557dd75f7fca) {
				} else {
					if ($Fee0d5a474c96306->query("SELECT `id`, `stream_id` FROM `queue` WHERE `server_id` = ? AND `pid` IS NULL AND `type` = 'movie' ORDER BY `added` ASC LIMIT " . $e515557dd75f7fca . ';', SERVER_ID)) {
						if (0 >= $Fee0d5a474c96306->num_rows()) {
						} else {
							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$f9b07d216a168dcc = XUI::Ed56a02053a7DD1F($C740da31596f24ef['stream_id']);

								if ($f9b07d216a168dcc) {
									$Fee0d5a474c96306->query('UPDATE `queue` SET `pid` = ? WHERE `id` = ?;', $f9b07d216a168dcc, $C740da31596f24ef['id']);
								} else {
									$da26920118f0ae06[] = $C740da31596f24ef['id'];
								}
							}
						}
					}
				}

				if ($Fee0d5a474c96306->query("SELECT `id`, `pid` FROM `queue` WHERE `server_id` = ? AND `pid` IS NOT NULL AND `type` = 'channel' ORDER BY `added` ASC;", SERVER_ID)) {
					$a330db047a007f18 = array();

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if ($C740da31596f24ef['pid'] && XUI::dd714Ee89c59FbF2($C740da31596f24ef['pid'], PHP_BIN)) {
								$a330db047a007f18[] = $C740da31596f24ef['pid'];
							} else {
								$da26920118f0ae06[] = $C740da31596f24ef['id'];
							}
						}
					}

					$e515557dd75f7fca = (0 < XUI::$rSettings['max_encode_cc'] ? intval(XUI::$rSettings['max_encode_cc']) - count($a330db047a007f18) : 1);

					if (0 >= $e515557dd75f7fca) {
					} else {
						if ($Fee0d5a474c96306->query("SELECT `id`, `stream_id` FROM `queue` WHERE `server_id` = ? AND `pid` IS NULL AND `type` = 'channel' ORDER BY `added` ASC LIMIT " . $e515557dd75f7fca . ';', SERVER_ID)) {
							if (0 >= $Fee0d5a474c96306->num_rows()) {
							} else {
								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
									if (!file_exists(CREATED_PATH . $C740da31596f24ef['stream_id'] . '_.create')) {
									} else {
										unlink(CREATED_PATH . $C740da31596f24ef['stream_id'] . '_.create');
									}

									shell_exec(PHP_BIN . ' ' . CLI_PATH . 'created.php ' . intval($C740da31596f24ef['stream_id']) . ' >/dev/null 2>/dev/null &');
									$f9b07d216a168dcc = null;

									foreach (range(1, 3) as $Ea22c4a9ab5b2176) {
										if (!file_exists(CREATED_PATH . $C740da31596f24ef['stream_id'] . '_.create')) {
											usleep(100000);
										} else {
											$f9b07d216a168dcc = intval(file_get_contents(CREATED_PATH . $C740da31596f24ef['stream_id'] . '_.create'));

											break;
										}
									}

									if ($f9b07d216a168dcc) {
										$Fee0d5a474c96306->query('UPDATE `queue` SET `pid` = ? WHERE `id` = ?;', $f9b07d216a168dcc, $C740da31596f24ef['id']);
									} else {
										$da26920118f0ae06[] = $C740da31596f24ef['id'];
									}
								}
							}
						}
					}

					if (0 >= count($da26920118f0ae06)) {
					} else {
						$Fee0d5a474c96306->query('DELETE FROM `queue` WHERE `id` IN (' . implode(',', $da26920118f0ae06) . ');');
					}

					sleep((0 < XUI::$rSettings['queue_loop'] ? intval(XUI::$rSettings['queue_loop']) : 5));
				}

				break;
			}
		}

		if (!is_object($Fee0d5a474c96306)) {
		} else {
			$Fee0d5a474c96306->close_mysql();
		}

		shell_exec('(sleep 1; ' . PHP_BIN . ' ' . __FILE__ . ' ) > /dev/null 2>/dev/null &');
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}
