<?php

set_time_limit(0);

if ($argc && count($argv) == 2) {
	if (Xui\Functions::getLicense()[9] != 1) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		$cf1c389bda3e30fd = $argv[1];
		fdc97512d22b990e();
	} else {
		exit('Not supported in Trial Mode.' . "\n");
	}
} else {
	exit(0);
}

function fDC97512D22B990E()
{
	global $Fee0d5a474c96306;
	global $cf1c389bda3e30fd;

	switch ($cf1c389bda3e30fd) {
		case 'update':
			if (XUI::$rServers[SERVER_ID]['is_main']) {
				$D480255818428bfd = Xui\Functions::checkUpdate('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', XUI_VERSION);
			} else {
				$Db3333007923d513 = null;
				$C700a2b357e5ed65 = null;

				foreach (XUI::$rServers as $e81220b4451f37c9) {
					if (!$e81220b4451f37c9['is_main']) {
					} else {
						$C700a2b357e5ed65 = 'http://' . $e81220b4451f37c9['server_ip'] . ':' . $e81220b4451f37c9['http_broadcast_port'] . '/api?password=' . XUI::$rSettings['live_streaming_pass'] . '&action=request_update&type=' . intval(XUI::$rServers[SERVER_ID]['server_type']);
						$Db3333007923d513 = $e81220b4451f37c9['xui_version'];

						break;
					}
				}

				if ($C700a2b357e5ed65) {
					$D480255818428bfd = json_decode(file_get_contents($C700a2b357e5ed65), true);
				} else {
					exit(0);
				}
			}

			if ($D480255818428bfd && 0 < strlen($D480255818428bfd['url'])) {
				$a27e64cc6ce01033 = fopen($D480255818428bfd['url'], 'rb');
				$fad9bf1525c16db1 = TMP_PATH . '.update.tar.gz';
				$f433193a3297ffde = fopen($fad9bf1525c16db1, 'wb');
				stream_copy_to_stream($a27e64cc6ce01033, $f433193a3297ffde);
				fclose($a27e64cc6ce01033);
				fclose($f433193a3297ffde);

				if (md5_file($fad9bf1525c16db1) == $D480255818428bfd['md5']) {
					$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 5 WHERE `id` = ?;', SERVER_ID);
					$cf1c389bda3e30fd = 'sudo /usr/bin/python3 ' . XUI_HOME . 'update "' . $fad9bf1525c16db1 . '" "' . $D480255818428bfd['md5'] . '" > /dev/null 2>&1 &';
					shell_exec($cf1c389bda3e30fd);

					exit(1);
				}

				exit(-1);
			}

			exit(0);

		case 'post-update':
			if (!(XUI::$rServers[SERVER_ID]['is_main'] && XUI::$rSettings['auto_update_lbs'])) {
			} else {
				foreach (XUI::$rServers as $e81220b4451f37c9) {
					if (!($e81220b4451f37c9['enabled'] && $e81220b4451f37c9['status'] == 1 && time() - $e81220b4451f37c9['last_check_ago'] <= 180) || $e81220b4451f37c9['is_main']) {
					} else {
						$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $e81220b4451f37c9['id'], time(), json_encode(array('action' => 'update')));
					}
				}
			}

			$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 1, `xui_version` = ?, `xui_revision` = ? WHERE `id` = ?;', XUI_VERSION, XUI_REVISION, SERVER_ID);

			if (XUI::$rServers[SERVER_ID]['is_main']) {
			} else {
				if (!file_exists('/etc/init.d/xuione')) {
				} else {
					unlink('/etc/init.d/xuione');
				}

				if (!file_exists(XUI_HOME . 'www/stream/auth.php')) {
				} else {
					unlink(XUI_HOME . 'www/stream/auth.php');
				}

				if (!file_exists(XUI_HOME . 'includes/aes.php')) {
				} else {
					unlink(XUI_HOME . 'includes/aes.php');
				}

				if (!file_exists(XUI_HOME . 'crons/status.php')) {
				} else {
					unlink(XUI_HOME . 'crons/status.php');
				}

				if (!file_exists(XUI_HOME . 'includes/handler.php')) {
				} else {
					unlink(XUI_HOME . 'includes/handler.php');
				}

				if (!file_exists(XUI_HOME . 'includes/nhandler.php')) {
				} else {
					unlink(XUI_HOME . 'includes/nhandler.php');
				}

				if (!file_exists(XUI_HOME . 'includes/cli/closed_cons.php')) {
				} else {
					unlink(XUI_HOME . 'includes/cli/closed_cons.php');
				}

				if (!file_exists(XUI_HOME . 'bin/ffmpeg')) {
				} else {
					unlink(XUI_HOME . 'bin/ffmpeg');
				}

				if (!file_exists(XUI_HOME . 'bin/ffprobe')) {
				} else {
					unlink(XUI_HOME . 'bin/ffprobe');
				}
			}

			foreach (array('http', 'https') as $E379394c7b1a273f) {
				$f0aa0180b47dfb80 = file_get_contents(XUI_HOME . 'bin/nginx/ports/' . $E379394c7b1a273f . '.conf');

				if (stripos($f0aa0180b47dfb80, ' reuseport') === false) {
				} else {
					file_put_contents(XUI_HOME . 'bin/nginx/ports/' . $E379394c7b1a273f . '.conf', str_replace(' reuseport', '', $f0aa0180b47dfb80));
				}
			}

			if (!file_exists(XUI_HOME . 'bin/redis')) {
			} else {
				exec('rm -rf ' . XUI_HOME . 'bin/redis');
			}

			exec('sudo chown -R xui:xui ' . XUI_HOME);
			exec('sudo systemctl daemon-reload');
			exec("sudo echo 'net.ipv4.ip_unprivileged_port_start=0' > /etc/sysctl.d/50-allports-nonroot.conf && sudo sysctl --system");
			exec('sudo ' . XUI_HOME . 'status');

			break;
	}
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
