<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc > 1) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		$e1ef5c0a2f4c2596 = intval($argv[1]);
		d60457acfd5df5c9($e1ef5c0a2f4c2596);
		set_time_limit(0);
		cli_set_process_title('Record[' . $e1ef5c0a2f4c2596 . ']');
		fdc97512d22b990e();
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function db5724651e2b56A4($bc2874292e0d9ece, $A639a7baefc720ee)
{
	if (!(0 < strlen($A639a7baefc720ee) && substr(strtolower($A639a7baefc720ee), 0, 4) == 'http')) {
	} else {
		$C6a7103a3e51b098 = 'jpg';
		$b9d9701068b80f80 = IMAGES_PATH . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;

		if (file_exists($b9d9701068b80f80)) {
			return 's:' . SERVER_ID . ':/images/' . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;
		}

		$a0eb8eb80ccd233b = curl_init();
		curl_setopt($a0eb8eb80ccd233b, CURLOPT_URL, $A639a7baefc720ee);
		curl_setopt($a0eb8eb80ccd233b, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($a0eb8eb80ccd233b, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt($a0eb8eb80ccd233b, CURLOPT_TIMEOUT, 5);
		$a27e64cc6ce01033 = curl_exec($a0eb8eb80ccd233b);

		if (0 >= strlen($a27e64cc6ce01033)) {
		} else {
			$Bc16cc77a681d1ed = IMAGES_PATH . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;
			file_put_contents($Bc16cc77a681d1ed, $a27e64cc6ce01033);

			if (!file_exists($Bc16cc77a681d1ed)) {
			} else {
				return 's:' . SERVER_ID . ':/images/' . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;
			}
		}
	}
}

function dc95637c2dA3b543()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT MAX(`order`) AS `order` FROM `streams`;');

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return 0;
	}

	return intval($Fee0d5a474c96306->get_row()['order']) + 1;
}

function C8adb574f9477f84($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function D7E7f81f646193B2($C52c0b6b0f74407b, $C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$ddf0508b312dbfb8 = c8adb574f9477f84($C52c0b6b0f74407b);
	$ae63b8db36d4a79c = json_decode($ddf0508b312dbfb8['bouquet_movies'], true);

	if (in_array($C3c8913edb801c35, $ae63b8db36d4a79c)) {
	} else {
		$ae63b8db36d4a79c[] = intval($C3c8913edb801c35);
	}

	$ae63b8db36d4a79c = '[' . implode(',', array_map('intval', $ae63b8db36d4a79c)) . ']';
	$Fee0d5a474c96306->query('UPDATE `bouquets` SET `bouquet_movies` = ? WHERE `id` = ?;', $ae63b8db36d4a79c, $C52c0b6b0f74407b);
}

function fDC97512d22b990E()
{
	global $Fee0d5a474c96306;
	global $e1ef5c0a2f4c2596;
	$Fee0d5a474c96306->query('SELECT * FROM `recordings` WHERE `id` = ?;', $e1ef5c0a2f4c2596);

	if (0 < $Fee0d5a474c96306->num_rows()) {
		$d5e40c7f6fdf5643 = $Dc305bd276c03993 = 0;
		$E7cd9fe35ef2bc5e = false;
		$B5519598a5f22232 = $Fee0d5a474c96306->get_row();

		if ($B5519598a5f22232['start'] - 60 <= time() && time() <= $B5519598a5f22232['end'] || $B5519598a5f22232['archive']) {
			$f9b07d216a168dcc = (file_exists(STREAMS_PATH . $B5519598a5f22232['stream_id'] . '_.pid') ? intval(file_get_contents(STREAMS_PATH . $B5519598a5f22232['stream_id'] . '_.pid')) : 0);
			$bb62005ea7eb8380 = STREAMS_PATH . $B5519598a5f22232['stream_id'] . '_.m3u8';

			if (0 < $f9b07d216a168dcc && file_exists($bb62005ea7eb8380)) {
				$Fee0d5a474c96306->query('UPDATE `recordings` SET `status` = 1 WHERE `id` = ?;', $e1ef5c0a2f4c2596);
				$Fee0d5a474c96306->close_mysql();

				while (XUI::F74FA4748B081619($f9b07d216a168dcc, $B5519598a5f22232['stream_id']) && file_exists($bb62005ea7eb8380)) {
					if ($B5519598a5f22232['archive']) {
						$C5034884ed44603a = intval(($B5519598a5f22232['end'] - $B5519598a5f22232['start']) / 60);
						$e1644d67f855686d = @fopen('http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/admin/timeshift?password=' . XUI::$rSettings['live_streaming_pass'] . '&stream=' . $B5519598a5f22232['stream_id'] . '&start=' . $B5519598a5f22232['start'] . '&duration=' . $C5034884ed44603a . '&extension=ts', 'r');
					} else {
						$e1644d67f855686d = @fopen('http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/admin/live?password=' . XUI::$rSettings['live_streaming_pass'] . '&stream=' . $B5519598a5f22232['stream_id'] . '&extension=ts', 'r');
					}

					if (!$e1644d67f855686d) {
					} else {
						echo 'Recording...' . "\n";

						if ($B5519598a5f22232['archive']) {
							$ba898c080060869c = fopen(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts', 'w');
						} else {
							$ba898c080060869c = fopen(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts', 'a');
						}

						while (!feof($e1644d67f855686d)) {
							$a27e64cc6ce01033 = stream_get_line($e1644d67f855686d, 4096);

							if (empty($a27e64cc6ce01033)) {
							} else {
								$Dc305bd276c03993 += $a27e64cc6ce01033;
								fwrite($ba898c080060869c, $a27e64cc6ce01033);
								fflush($ba898c080060869c);
								$d5e40c7f6fdf5643 = 0;
							}

							if ($B5519598a5f22232['end'] > time() || $B5519598a5f22232['archive']) {
							} else {
								$E7cd9fe35ef2bc5e = true;
								fclose($ba898c080060869c);
							}
						}
						fclose($e1644d67f855686d);

						if (!$B5519598a5f22232['archive']) {
						} else {
							$E7cd9fe35ef2bc5e = true;
						}
					}

					$d5e40c7f6fdf5643++;

					if ($d5e40c7f6fdf5643 != 5) {
						echo 'Broken pipe! Restarting...' . "\n";
						sleep(1);

						break;
					}

					if (10485760 > $Dc305bd276c03993) {
					} else {
						$E7cd9fe35ef2bc5e = true;
					}

					echo 'Too many fails!' . "\n";
				}
			} else {
				echo 'Channel is not running.' . "\n";
			}
		} else {
			echo 'Programme is not currently airing.' . "\n";
		}

		if ($Fee0d5a474c96306->connected) {
		} else {
			$Fee0d5a474c96306->db_connect();
		}

		if (!$E7cd9fe35ef2bc5e) {
		} else {
			if (file_exists(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts') && 0 < filesize(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts')) {
				echo 'Recording complete! Converting to MP4...' . "\n";

				if (empty($B5519598a5f22232['stream_icon'])) {
				} else {
					$B5519598a5f22232['stream_icon'] = db5724651e2b56a4($B5519598a5f22232['stream_icon']);
				}

				$eff3c5536b319f0b = intval($B5519598a5f22232['end'] - $B5519598a5f22232['start']);
				$eaad9527ef2b563d = b9Da5d708FC1c079('streams');
				$eaad9527ef2b563d['type'] = 2;
				$eaad9527ef2b563d['stream_source'] = '[]';
				$eaad9527ef2b563d['target_container'] = 'mp4';
				$eaad9527ef2b563d['stream_display_name'] = $B5519598a5f22232['title'];
				$eaad9527ef2b563d['year'] = date('Y');
				$eaad9527ef2b563d['movie_properties'] = array('kinopoisk_url' => null, 'tmdb_id' => null, 'name' => $B5519598a5f22232['title'], 'o_name' => $B5519598a5f22232['title'], 'cover_big' => $B5519598a5f22232['stream_icon'], 'movie_image' => $B5519598a5f22232['stream_icon'], 'release_date' => date('Y-m-d', $B5519598a5f22232['start']), 'episode_run_time' => intval($eff3c5536b319f0b / 60), 'youtube_trailer' => null, 'director' => '', 'actors' => '', 'cast' => '', 'description' => trim($B5519598a5f22232['description']), 'plot' => trim($B5519598a5f22232['description']), 'age' => '', 'mpaa_rating' => '', 'rating_count_kinopoisk' => 0, 'country' => '', 'genre' => '', 'backdrop_path' => array(), 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => 0);
				$eaad9527ef2b563d['rating'] = 0;
				$eaad9527ef2b563d['read_native'] = 0;
				$eaad9527ef2b563d['movie_symlink'] = 0;
				$eaad9527ef2b563d['remove_subtitles'] = 0;
				$eaad9527ef2b563d['transcode_profile_id'] = 0;
				$eaad9527ef2b563d['order'] = dc95637c2da3b543();
				$eaad9527ef2b563d['added'] = time();
				$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', json_decode($B5519598a5f22232['category_id'], true))) . ']';
				$acd0eb2c8a975903 = f4817DC607d9981D($eaad9527ef2b563d);
				$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = $Fee0d5a474c96306->last_insert_id();
					$B95dc1bd2d8c3a31 = shell_exec(FFMPEG_BIN_40 . " -i '" . ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts' . "' -c:v copy -c:a copy '" . VOD_PATH . $Fc2dc5a0ce8d07ea . '.mp4' . "'");
					@unlink(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts');

					if (file_exists(VOD_PATH . $Fc2dc5a0ce8d07ea . '.mp4')) {
						foreach (json_decode($B5519598a5f22232['bouquets'], true) as $ddf0508b312dbfb8) {
							d7e7f81f646193b2($ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
						}
						$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_source` = ? WHERE `id` = ?;', json_encode(array(VOD_PATH . $Fc2dc5a0ce8d07ea . '.mp4')), $Fc2dc5a0ce8d07ea);
						$Fee0d5a474c96306->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `pid`, `to_analyze`) VALUES(?, ?, NULL, 1, 1);', $Fc2dc5a0ce8d07ea, SERVER_ID);
						$Fee0d5a474c96306->query('UPDATE `recordings` SET `status` = 2, `created_id` = ? WHERE `id` = ?;', $Fc2dc5a0ce8d07ea, $e1ef5c0a2f4c2596);
					} else {
						echo "Couldn't convert to MP4" . "\n";
						$E7cd9fe35ef2bc5e = false;
					}
				} else {
					echo 'Failed to insert into database!' . "\n";
					$E7cd9fe35ef2bc5e = false;
				}
			} else {
				echo 'Recording size is 0 bytes.' . "\n";
				$E7cd9fe35ef2bc5e = false;
			}
		}

		if ($E7cd9fe35ef2bc5e) {
		} else {
			echo 'Recording incomplete!' . "\n";
			$Fee0d5a474c96306->query('UPDATE `recordings` SET `status` = 3 WHERE `id` = ?;', $e1ef5c0a2f4c2596);
			@unlink(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '.ts');
		}
	} else {
		echo "Recording entry doesn't exist." . "\n";
	}
}

function D60457ACFd5DF5C9($e1ef5c0a2f4c2596)
{
	clearstatcache(true);

	if (!file_exists(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '_.record')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '_.record'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'Record\\[" . intval($e1ef5c0a2f4c2596) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'Record[' . $e1ef5c0a2f4c2596 . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}

	file_put_contents(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '_.record', getmypid());
}

function c4a6F6F0DEBd5F57($b6842cb20051e925)
{
	return strtolower(preg_replace('/[^a-z0-9_]+/i', '', $b6842cb20051e925));
}

function f4817dc607d9981d($d49041d5f05a9270)
{
	$D480255818428bfd = $F02c388243a378a7 = $C0ad72b730f8eea3 = $a27e64cc6ce01033 = array();

	foreach (array_keys($d49041d5f05a9270) as $D3fa098be3f297cd) {
		$F02c388243a378a7[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '`';
		$D480255818428bfd[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '` = ?';
	}

	foreach (array_values($d49041d5f05a9270) as $b6842cb20051e925) {
		if (!is_array($b6842cb20051e925)) {
		} else {
			$b6842cb20051e925 = json_encode($b6842cb20051e925, JSON_UNESCAPED_UNICODE);
		}

		$C0ad72b730f8eea3[] = '?';
		$a27e64cc6ce01033[] = $b6842cb20051e925;
	}

	return array('placeholder' => implode(',', $C0ad72b730f8eea3), 'columns' => implode(',', $F02c388243a378a7), 'data' => $a27e64cc6ce01033, 'update' => implode(',', $D480255818428bfd));
}

function B9DA5D708fC1c079($B1a1e80ba9ae29c7, $a27e64cc6ce01033 = array(), $fcc4f0f10efcef42 = false)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `column_name`, `column_default`, `is_nullable`, `data_type` FROM `information_schema`.`columns` WHERE `table_schema` = (SELECT DATABASE()) AND `table_name` = ? ORDER BY `ordinal_position`;', $B1a1e80ba9ae29c7);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($C740da31596f24ef['column_default'] != 'NULL') {
		} else {
			$C740da31596f24ef['column_default'] = null;
		}

		$f2373ceca1685f65 = false;

		if ($C740da31596f24ef['is_nullable'] != 'NO' || $C740da31596f24ef['column_default']) {
		} else {
			if (in_array($C740da31596f24ef['data_type'], array('int', 'float', 'tinyint', 'double', 'decimal', 'smallint', 'mediumint', 'bigint', 'bit'))) {
				$C740da31596f24ef['column_default'] = 0;
			} else {
				$C740da31596f24ef['column_default'] = '';
			}

			$f2373ceca1685f65 = true;
		}

		if (array_key_exists($C740da31596f24ef['column_name'], $a27e64cc6ce01033)) {
			if (empty($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && !is_numeric($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && is_null($C740da31596f24ef['column_default'])) {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = ($f2373ceca1685f65 ? $C740da31596f24ef['column_default'] : null);
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $a27e64cc6ce01033[$C740da31596f24ef['column_name']];
			}
		} else {
			if ($fcc4f0f10efcef42) {
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $C740da31596f24ef['column_default'];
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $e1ef5c0a2f4c2596;

	if (!file_exists(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '_.record')) {
	} else {
		unlink(ARCHIVE_PATH . $e1ef5c0a2f4c2596 . '_.record');
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
