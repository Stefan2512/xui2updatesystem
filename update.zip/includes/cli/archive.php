<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc > 1) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		$F26087d31c2bbe4d = intval($argv[1]);
		d60457acfd5df5c9($F26087d31c2bbe4d);
		set_time_limit(0);
		cli_set_process_title('TVArchive[' . $F26087d31c2bbe4d . ']');
		fdc97512d22b990e();
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function FDc97512D22B990e()
{
	global $Fee0d5a474c96306;
	global $F26087d31c2bbe4d;

	if (file_exists(ARCHIVE_PATH . $F26087d31c2bbe4d)) {
	} else {
		mkdir(ARCHIVE_PATH . $F26087d31c2bbe4d);
	}

	$f9b07d216a168dcc = (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid') ? intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) : 0);
	$bb62005ea7eb8380 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8';

	if (0 >= $f9b07d216a168dcc) {
	} else {
		$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t1.id = t2.stream_id AND t2.server_id = t1.tv_archive_server_id WHERE t1.`id` = ? AND t1.`tv_archive_server_id` = ? AND t1.`tv_archive_duration` > 0', $F26087d31c2bbe4d, SERVER_ID);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$C740da31596f24ef = $Fee0d5a474c96306->get_row();

			if (!XUI::Dd714Ee89C59FbF2($C740da31596f24ef['tv_archive_pid'], PHP_BIN)) {
			} else {
				if (!(is_numeric($C740da31596f24ef['tv_archive_pid']) && 0 < $C740da31596f24ef['tv_archive_pid'])) {
				} else {
					posix_kill($C740da31596f24ef['tv_archive_pid'], 9);
				}
			}

			if (!empty($C740da31596f24ef['pid'])) {
			} else {
				posix_kill(getmypid(), 9);
			}

			$Fee0d5a474c96306->query('UPDATE `streams` SET `tv_archive_pid` = ? WHERE `id` = ?', getmypid(), $F26087d31c2bbe4d);
			XUI::AFA0F3ffB001b9be($F26087d31c2bbe4d);
			$Fee0d5a474c96306->close_mysql();

			while (XUI::f74fA4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d) && file_exists($bb62005ea7eb8380)) {
				$Af547236269d8f66 = time();
				fad51cf3d53Db648($F26087d31c2bbe4d, $C740da31596f24ef['tv_archive_duration']);
				$f5093dce77139292 = gmdate('Y-m-d:H-i');
				$e1644d67f855686d = @fopen('http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/admin/live?password=' . XUI::$rSettings['live_streaming_pass'] . '&stream=' . $F26087d31c2bbe4d . '&extension=ts', 'r');

				if (!$e1644d67f855686d) {
				} else {
					$ba898c080060869c = fopen(ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . $f5093dce77139292 . '.ts', 'a');

					while (!feof($e1644d67f855686d)) {
						if (3600 > time() - $Af547236269d8f66) {
						} else {
							fad51Cf3d53Db648($F26087d31c2bbe4d, $C740da31596f24ef['tv_archive_duration']);
							$Af547236269d8f66 = time();
						}

						if (gmdate('Y-m-d:H-i') == $f5093dce77139292) {
						} else {
							fclose($ba898c080060869c);

							if (file_exists(ARCHIVE_PATH . $F26087d31c2bbe4d)) {
							} else {
								mkdir(ARCHIVE_PATH . $F26087d31c2bbe4d);
							}

							$db752e19806388c2 = (XUI::findKeyframe(ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . $f5093dce77139292 . '.ts') ?: 0);
							file_put_contents(ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . $f5093dce77139292 . '.ts.offset', $db752e19806388c2);
							$f5093dce77139292 = gmdate('Y-m-d:H-i');
							$ba898c080060869c = fopen(ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . $f5093dce77139292 . '.ts', 'a');
						}

						fwrite($ba898c080060869c, stream_get_line($e1644d67f855686d, 4096));
						fflush($ba898c080060869c);
					}
					fclose($e1644d67f855686d);
				}

				sleep(1);
			}
		}

		exit();
	}
}

function fAD51CF3d53Db648($F26087d31c2bbe4d, $C5034884ed44603a)
{
	$Ff003e50a37198e9 = intval(count(scandir(ARCHIVE_PATH . $F26087d31c2bbe4d . '/')) - 2);

	if ($C5034884ed44603a * 24 * 60 >= $Ff003e50a37198e9) {
	} else {
		$c573c2fcc4632585 = $Ff003e50a37198e9 - $C5034884ed44603a * 24 * 60;
		$b93e6a2691d72853 = array_values(array_filter(explode("\n", shell_exec('ls -tr ' . ARCHIVE_PATH . intval($F26087d31c2bbe4d) . " | sed -e 's/\\s\\+/\\n/g'"))));

		for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < $c573c2fcc4632585; $Ea22c4a9ab5b2176++) {
			unlink(ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . $b93e6a2691d72853[$Ea22c4a9ab5b2176]);
		}
	}
}

function d60457aCfd5DF5c9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.archive')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.archive'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'TVArchive\\[" . intval($F26087d31c2bbe4d) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'TVArchive[' . $F26087d31c2bbe4d . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}

	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.archive', getmypid());
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
