<?php

function d60457acFd5dF5C9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'XUI\\[" . intval($F26087d31c2bbe4d) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'XUI[' . $F26087d31c2bbe4d . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}
}

if ((posix_getpwuid(posix_geteuid())['name'] != 'xui')) {
	exit('Please run as XUI!' . "\n");
}

if ((!@$argc || ($argc <= 1))) {
	exit(0);
}

$F26087d31c2bbe4d = intval($argv[1]);
$d81f27c553f73ff4 = !empty($argv[2]);
require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
d60457acFD5df5c9($F26087d31c2bbe4d);
set_time_limit(0);
cli_set_process_title('XUI[' . $F26087d31c2bbe4d . ']');
$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.server_id = ? WHERE t1.id = ?', SERVER_ID, $F26087d31c2bbe4d);

if (($Fee0d5a474c96306->num_rows() <= 0)) {
	XUI::a52ea4c1EAd81De2($F26087d31c2bbe4d);

	exit();
}

$bb0071da5a239b0c = $Fee0d5a474c96306->get_row();
$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `monitor_pid` = ? WHERE `server_stream_id` = ?', getmypid(), $bb0071da5a239b0c['server_stream_id']);

if (XUI::$rSettings['enable_cache']) {
	XUI::AFa0f3ffb001B9Be($F26087d31c2bbe4d);
}

$f9b07d216a168dcc = (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid') ? intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) : $bb0071da5a239b0c['pid']);
$ad9e78094ea46852 = json_decode($bb0071da5a239b0c['auto_restart'], true);
$bb62005ea7eb8380 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8';
$f7fb30f97e1a1d47 = $bb0071da5a239b0c['delay_pid'];
$fcae8575b94f8564 = $bb0071da5a239b0c['parent_id'];
$fa741d851639c561 = false;
$bbfc9bd8432031f5 = array();
$Cc6901bef8bb7c30 = XUI::$rSegmentSettings['seg_time'];
$b50df7318b3a8be8 = false;
$b4444a323f90163f = 0;

if (($fcae8575b94f8564 == 0)) {
	$bbfc9bd8432031f5 = json_decode($bb0071da5a239b0c['stream_source'], true);
	//////////////////////////
}

if (0 >= $fcae8575b94f8564) {
	$Cc34ada8114813bd = $bb0071da5a239b0c['current_source'];
} else {
	$Cc34ada8114813bd = 'Loopback: #' . $fcae8575b94f8564;
}
$D2176e3a77f12992 = $D9b6e988c8c78276 = null;
$Fee0d5a474c96306->query('SELECT t1.*, t2.* FROM `streams_options` t1, `streams_arguments` t2 WHERE t1.stream_id = ? AND t1.argument_id = t2.id', $F26087d31c2bbe4d);
$f86c7f12032c787a = $Fee0d5a474c96306->get_rows();

if (!(0 < $bb0071da5a239b0c['delay_minutes']) && ($bb0071da5a239b0c['parent_id'] == 0)) {
	$e43dcce9a685f04c = false;
	$b53b03db133532c7 = STREAMS_PATH;
} else {
	$b53b03db133532c7 = DELAY_PATH;
	$bb62005ea7eb8380 = DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8';
	$e43dcce9a685f04c = true;
}
$c790d8a5c681996d = true;
$Af28573112ea2a1a = 0;

if (XUI::f74fa4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d)) {
	echo 'Stream is running.' . "\n";

	if ($d81f27c553f73ff4) {
		$Af28573112ea2a1a = MONITOR_CALLS;

		if ((is_numeric($f9b07d216a168dcc) && (0 < $f9b07d216a168dcc))) {
			shell_exec('kill -9 ' . intval($f9b07d216a168dcc));
		}
		shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*');
		file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor', getmypid());

		if (($e43dcce9a685f04c && XUI::a8CCFd5DB103a765($f7fb30f97e1a1d47, $F26087d31c2bbe4d) && is_numeric($f7fb30f97e1a1d47) && (0 < $f7fb30f97e1a1d47))) {
			shell_exec('kill -9 ' . intval($f7fb30f97e1a1d47));
		}
		usleep(50000);
		$f7fb30f97e1a1d47 = $f9b07d216a168dcc = 0;
	}
} else {
	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor', getmypid());
}

if (XUI::$rSettings['kill_rogue_ffmpeg']) {
	exec('ps aux | grep -v grep | grep \'/' . $F26087d31c2bbe4d . '_.m3u8\' | awk \'{print $2}\'', $D59cad1840440e04);

	foreach ($D59cad1840440e04 as $a6eef5949b6688d5) {
		if ((is_numeric($a6eef5949b6688d5) && (0 < intval($a6eef5949b6688d5)) && (intval($a6eef5949b6688d5) != intval($f9b07d216a168dcc)))) {
			shell_exec('kill -9 ' . $a6eef5949b6688d5 . ';');
		}
	}
}

goto label235;

label235:
if (true) {
	if (!(0 < $f9b07d216a168dcc)) {
		goto label471;
	}
	$Fee0d5a474c96306->close_mysql();
	$B4f81f12f4143111 = $C6490eba6e5b2915 = $Fe34e449b0cfdfac = $F8476b3d509c0b2a = $Ea1ac3fc3421259a = time();
	$Ba344b2758e3e955 = md5_file($bb62005ea7eb8380);
	$D97a4f098a8d1bf8 = XUI::f74FA4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d) && file_exists($bb62005ea7eb8380);
	$b4015d24aedaf0db = null;

	goto label592;

	label592: //while
		if ((XUI::F74fA4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d) && file_exists($bb62005ea7eb8380))) {
			if (!(!empty($ad9e78094ea46852['days']) && !empty($ad9e78094ea46852['at']))) {
				goto label195;
			}

			list($d08bd3f46de523f4, $D1b34eaa5eef40cc) = explode(':', $ad9e78094ea46852['at']);

			if (!(in_array(date('l'), $ad9e78094ea46852['days']) && (date('H') == $d08bd3f46de523f4))) {
				goto label195;
			}

			if (!($D1b34eaa5eef40cc == date('i'))) {
				goto label195;
			}

			echo 'Auto-restart' . "\n";
			XUI::EFFEb9f2c8015c8A($F26087d31c2bbe4d, SERVER_ID, 'AUTO_RESTART', $Cc34ada8114813bd);
			$D97a4f098a8d1bf8 = false;

			goto label1186;
		}

	goto label1186;

	label195:
			if (($fa741d851639c561 || (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur') && (300 < (time() - $C6490eba6e5b2915))))) {
				echo 'Probe Stream' . "\n";
				$d55bf693d0ece21c = XUI::d076f5A2cC104C49($bb62005ea7eb8380, 10)[0];

				if (!empty($d55bf693d0ece21c)) {
					if (((300 < (time() - $C6490eba6e5b2915)) && ($d55bf693d0ece21c == $D2176e3a77f12992))) {
						XUI::EFFeB9f2c8015c8A($F26087d31c2bbe4d, SERVER_ID, 'FFMPEG_ERROR', $Cc34ada8114813bd);

						goto label1186;
					}
					$D2176e3a77f12992 = $d55bf693d0ece21c;
					$E02429d2ee600884 = XUI::c8851B830A0692CD($b53b03db133532c7 . $d55bf693d0ece21c);

					if ((10 < intval($E02429d2ee600884['of_duration']))) {
						$E02429d2ee600884['of_duration'] = 10;
					}
					file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur', intval($E02429d2ee600884['of_duration']));

					if (($Cc6901bef8bb7c30 < intval($E02429d2ee600884['of_duration']))) {
						$Cc6901bef8bb7c30 = intval($E02429d2ee600884['of_duration']);
					}
					file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.stream_info', json_encode($E02429d2ee600884, JSON_UNESCAPED_UNICODE));
					$bb0071da5a239b0c['stream_info'] = json_encode($E02429d2ee600884, JSON_UNESCAPED_UNICODE);
				}
				$fa741d851639c561 = false;
				$C6490eba6e5b2915 = time();

				if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
					file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid', $f9b07d216a168dcc);
				}

				if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
					file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor', getmypid());
				}
			}

	if (!(($bb0071da5a239b0c['fps_restart'] == 1) && (XUI::$rSettings['fps_delay'] < (time() - $B4f81f12f4143111)) && file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.progress_check'))) {
		goto label298;
	}

	echo 'Checking FPS...' . "\n";
	$d75674a646265e7b = floatval(json_decode(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.progress_check'), true)['fps']) ?: 0;

	if (!(0 < $d75674a646265e7b)) {
		goto label1847;
	}

	if (!$b4015d24aedaf0db) {
		goto label1087;
	}

	if (!($b4015d24aedaf0db && (($d75674a646265e7b * ($bb0071da5a239b0c['fps_threshold'] ?: 100)) < $b4015d24aedaf0db))) {
		goto label1847;
	}
	echo 'FPS dropped below threshold! Break' . "\n";
	XUI::EFFEb9f2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'FPS_DROP_THRESHOLD', $Cc34ada8114813bd);

	goto label1186;

	label884:

$dc0404bcfb9cd8f1 = implode(' ', XUI::a4C93C52f5D2D72D($f86c7f12032c787a, $C6033ec178efa2ae, 'fetch'));

	if (($E02429d2ee600884 = XUI::C8851B830a0692cd($ecc9029bfbc77eed, $dc0404bcfb9cd8f1))) {
		echo 'Force new source' . "\n";
		XUI::EFFEB9f2c8015c8a($F26087d31c2bbe4d, SERVER_ID, 'FORCE_SOURCE', $bbfc9bd8432031f5[$Cc34cb9d37801a94]);
		$D9b6e988c8c78276 = $bbfc9bd8432031f5[$Cc34cb9d37801a94];
		unlink(SIGNALS_TMP_PATH . $F26087d31c2bbe4d . '.force');
		$D97a4f098a8d1bf8 = false;

		goto label1186;
	}

	goto label1631;
	label1631:
unlink(SIGNALS_TMP_PATH . $F26087d31c2bbe4d . '.force');

	label496:
if ((file_exists(SIGNALS_TMP_PATH . $F26087d31c2bbe4d . '.force') && ($fcae8575b94f8564 == 0))) {
	$Cc34cb9d37801a94 = intval(file_get_contents(SIGNALS_TMP_PATH . $F26087d31c2bbe4d . '.force'));
	$ecc9029bfbc77eed = XUI::Ce3bA3178Bc00d1C($bbfc9bd8432031f5[$Cc34cb9d37801a94]);

	if (($bbfc9bd8432031f5[$Cc34cb9d37801a94] != $Cc34ada8114813bd)) {
		$C6033ec178efa2ae = strtolower(substr($ecc9029bfbc77eed, 0, strpos($ecc9029bfbc77eed, '://')));

		goto label884;
	}

	goto label1631;
}

	if (($e43dcce9a685f04c && ($bb0071da5a239b0c['delay_available_at'] <= time()) && !XUI::a8ccfD5DB103a765($f7fb30f97e1a1d47, $F26087d31c2bbe4d))) {
		echo 'Start Delay' . "\n";
		XUI::eFFeb9f2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'DELAY_START');
		$f7fb30f97e1a1d47 = intval(shell_exec(PHP_BIN . ' ' . CLI_PATH . 'delay.php ' . intval($F26087d31c2bbe4d) . ' ' . intval($bb0071da5a239b0c['delay_minutes']) . ' >/dev/null 2>/dev/null & echo $!'));
	}
	sleep(1);

	goto label592;
}

goto label1880;

label1:

if (!$bb0071da5a239b0c['parent_id']) {
	goto label49;
}
$D9b6e988c8c78276 = (!is_null(XUI::$rServers[SERVER_ID]['private_url_ip']) && !is_null(XUI::$rServers[$bb0071da5a239b0c['parent_id']]['private_url_ip']) ? XUI::$rServers[$bb0071da5a239b0c['parent_id']]['private_url_ip'] : XUI::$rServers[$bb0071da5a239b0c['parent_id']]['public_url_ip']) . 'admin/live?stream=' . intval($F26087d31c2bbe4d) . '&password=' . urlencode(XUI::$rSettings['live_streaming_pass']) . '&extension=ts';

label49:

$a27e64cc6ce01033 = XUI::E5d50da8f3AB33b2($F26087d31c2bbe4d, $bb0071da5a239b0c, $bb0071da5a239b0c['parent_id'] ? array() : $f86c7f12032c787a, $D9b6e988c8c78276);

goto label644;

label1512:

if ($D9b6e988c8c78276) {
	$Ea84d0933a1ef2f0 = $D9b6e988c8c78276;
} else {
	$Ea84d0933a1ef2f0 = json_decode($bb0071da5a239b0c['stream_source'], true)[0];
}
$a27e64cc6ce01033 = XUI::eC4E6C6a6aaBe235($F26087d31c2bbe4d, false, $Ea84d0933a1ef2f0, true);

label644:
goto label1131;

label1127:

$a27e64cc6ce01033 = XUI::startLoopback($F26087d31c2bbe4d);

label1131:
if ((is_numeric($a27e64cc6ce01033) && ($a27e64cc6ce01033 == 0))) {
	$E9d347a502b13abd = true;
	$b4444a323f90163f++;

	if (((0 < XUI::$rSettings['stop_failures']) && ($b4444a323f90163f == XUI::$rSettings['stop_failures']))) {
		echo 'Failure limit reached, exiting.' . "\n";

		exit();

		goto label1880;
	}
}

if (!$a27e64cc6ce01033) {
	exit();

	goto label1880;
}

if ($E9d347a502b13abd) {
	goto label562;
}

$f9b07d216a168dcc = intval($a27e64cc6ce01033['main_pid']);

if ($f9b07d216a168dcc) {
	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid', $f9b07d216a168dcc);
}

$bb62005ea7eb8380 = $a27e64cc6ce01033['playlist'];
$e43dcce9a685f04c = $a27e64cc6ce01033['delay_enabled'];
$bb0071da5a239b0c['delay_available_at'] = $a27e64cc6ce01033['delay_start_at'];
$fcae8575b94f8564 = $a27e64cc6ce01033['parent_id'];

if (0 >= $fcae8575b94f8564) {
	$Cc34ada8114813bd = trim($a27e64cc6ce01033['stream_source'], '\'"');
} else {
	$Cc34ada8114813bd = 'Loopback: #' . $fcae8575b94f8564;
}
$db752e19806388c2 = $a27e64cc6ce01033['offset'];
$fa741d851639c561 = true;
echo 'Stream started' . "\n";
echo $Cc34ada8114813bd . "\n";

if ($b50df7318b3a8be8) {
	$D9b6e988c8c78276 = null;
	$b50df7318b3a8be8 = false;
}

if (!$e43dcce9a685f04c) {
	$b53b03db133532c7 = STREAMS_PATH;
} else {
	$b53b03db133532c7 = DELAY_PATH;
}
$e1bc98ce34937596 = $b53b03db133532c7 . $F26087d31c2bbe4d . '_0.ts';
$ea6de21e70c530a9 = false;
$Aae09861fbc788ec = 0;
$A63c815f93524582 = (($Cc6901bef8bb7c30 * 3) <= 30 ? $Cc6901bef8bb7c30 * 3 : 30);

if (!($A63c815f93524582 < 20)) {
	goto label998;
}

$A63c815f93524582 = 20;

goto label998;

label998:

if (true) {
	echo 'Checking for playlist ' . ($Aae09861fbc788ec + 1) . ('/' . $A63c815f93524582 . '...' . "\n");

	if (XUI::f74Fa4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d)) {
		if (file_exists($bb62005ea7eb8380)) {
			echo 'Playlist exists!' . "\n";

			goto label1064;
		}

		if ((file_exists($e1bc98ce34937596) && !$ea6de21e70c530a9 && $bb0071da5a239b0c['on_demand'])) {
			echo 'Segment exists!' . "\n";
			$ea6de21e70c530a9 = true;
			$Aae09861fbc788ec = 0;
			$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `stream_status` = 0, `stream_started` = ? WHERE `server_stream_id` = ?', time() - $db752e19806388c2, $bb0071da5a239b0c['server_stream_id']);
		}

		if (($Aae09861fbc788ec == $A63c815f93524582)) {
			echo 'Reached max failures' . "\n";
			$E9d347a502b13abd = true;

			goto label1064;
		}
		$Aae09861fbc788ec++;
		sleep(1);

		goto label998;
	}
	echo 'Ffmpeg stopped running' . "\n";
	$E9d347a502b13abd = true;

	goto label1064;
}

	goto label1064;
label1064:

goto label562;
label562:

XUI::$rSettings = XUI::D761e78DA5Eb70Fb();

if (XUI::f74fa4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d) && !$E9d347a502b13abd) {
	goto label1267;
}

echo 'Stream start failed...' . "\n";

if (($fcae8575b94f8564 == 0)) {
	XUI::eFFEB9F2c8015c8A($F26087d31c2bbe4d, SERVER_ID, 'STREAM_START_FAIL', $Cc34ada8114813bd);
}

if ((is_numeric($f9b07d216a168dcc) && (0 < $f9b07d216a168dcc) && XUI::f74Fa4748B081619($f9b07d216a168dcc, $F26087d31c2bbe4d))) {
	shell_exec('kill -9 ' . intval($f9b07d216a168dcc));
}
$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `pid` = null, `stream_status` = 1 WHERE `server_stream_id` = ?;', $bb0071da5a239b0c['server_stream_id']);

if (XUI::$rSettings['enable_cache']) {
	XUI::afA0f3fFb001B9BE($F26087d31c2bbe4d);
}
echo 'Sleep for ' . XUI::$rSettings['stream_fail_sleep'] . ' seconds...';
sleep(XUI::$rSettings['stream_fail_sleep']);

if (!(XUI::$rSettings['on_demand_failure_exit'] && $bb0071da5a239b0c['on_demand'])) {
	goto label554;
}
echo 'On-demand failed to run!' . "\n";

exit();

goto label1880;

label1186:
if ($D97a4f098a8d1bf8) {
	XUI::efFeb9F2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'STREAM_FAILED', $Cc34ada8114813bd);
	echo 'Stream failed!' . "\n";
}
$Fee0d5a474c96306->db_connect();

goto label471;

label471:

if (XUI::f74FA4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d)) {
	echo 'Killing stream...' . "\n";

	if ((is_numeric($f9b07d216a168dcc) && (0 < $f9b07d216a168dcc))) {
		shell_exec('kill -9 ' . intval($f9b07d216a168dcc));
	}
	usleep(50000);
}

if (XUI::A8Ccfd5Db103a765($f7fb30f97e1a1d47, $F26087d31c2bbe4d)) {
	echo 'Killing stream delay...' . "\n";

	////////////////////////
	if ((is_numeric($f7fb30f97e1a1d47) && (0 < $f7fb30f97e1a1d47))) {
		shell_exec('kill -9 ' . intval($f7fb30f97e1a1d47));
	}
	usleep(50000);
}

goto label76;
//////////////////////////
label554:

if ((MONITOR_CALLS <= $Af28573112ea2a1a)) {
	$Af28573112ea2a1a = 0;
}

goto label76;

label76:

if (!XUI::f74fa4748B081619($f9b07d216a168dcc, $F26087d31c2bbe4d)) {
	$E9d347a502b13abd = false;
	echo 'Restarting...' . "\n";
	shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*');
	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor', getmypid());
	$db752e19806388c2 = 0;
	$Af28573112ea2a1a++;

	if ((0 < $bb0071da5a239b0c['parent_id']) && XUI::$rSettings['php_loopback']) {
		goto label1127;
	}

	if ((0 < $bb0071da5a239b0c['llod']) && $bb0071da5a239b0c['on_demand'] && $c790d8a5c681996d) {
		goto label933;
	}

	if ($bb0071da5a239b0c['type'] == 3) {
		if (((0 < $f9b07d216a168dcc) && !$bb0071da5a239b0c['parent_id'] && (0 < $bb0071da5a239b0c['stream_started']))) {
			$a0e727eef95293df = json_decode($bb0071da5a239b0c['cc_info'], true);

			if (($a0e727eef95293df && ((time() - $bb0071da5a239b0c['stream_started']) < (intval($a0e727eef95293df[count($a0e727eef95293df) - 1]['finish']) * 0.95)))) {
				$db752e19806388c2 = time() - $bb0071da5a239b0c['stream_started'];
			}
		}
		$a27e64cc6ce01033 = XUI::EC4e6c6A6AAbe235($F26087d31c2bbe4d, false, $D9b6e988c8c78276, false, $db752e19806388c2);

		label933:

		if ($bb0071da5a239b0c['llod'] == 1) {
			goto label1512;
		}

		goto label1;
	}

	$a27e64cc6ce01033 = XUI::Ec4e6c6A6aaBe235($F26087d31c2bbe4d, $Af28573112ea2a1a < MONITOR_CALLS, $D9b6e988c8c78276);

	goto label644;
}

	goto label235;

label1087:

if (XUI::$rSettings['fps_check_type'] == 1) {
	goto label1094;
}

$b4015d24aedaf0db = $d75674a646265e7b;

goto label1847;
label1094:

$d55bf693d0ece21c = XUI::D076f5A2cc104C49($bb62005ea7eb8380, 10)[0];

if (empty($d55bf693d0ece21c)) {
	goto label1847;
}

$E02429d2ee600884 = XUI::c8851B830A0692Cd($b53b03db133532c7 . $d55bf693d0ece21c);

if (!(isset($E02429d2ee600884['codecs']['video']['avg_frame_rate']) || isset($E02429d2ee600884['codecs']['video']['r_frame_rate']))) {
	goto label1847;
}

$d75674a646265e7b = $E02429d2ee600884['codecs']['video']['avg_frame_rate'] ?: $E02429d2ee600884['codecs']['video']['r_frame_rate'];

goto label768;

label768:

if (stripos($d75674a646265e7b, '/') !== false) {
	goto label780;
}

$d75674a646265e7b = floatval($d75674a646265e7b);

goto label1052;

label780:

list($Be71401a913607c0, $Cd98e5a46a318d0a) = array_map('floatval', explode('/', $d75674a646265e7b));

goto label1047;

label1047:

$d75674a646265e7b = floatval($Be71401a913607c0 / $Cd98e5a46a318d0a);

label1052:

if (!(0 < $d75674a646265e7b)) {
	goto label1057;
}

$b4015d24aedaf0db = $d75674a646265e7b;

label1057:

goto label1847;

label1267:

echo 'Started! Probe Stream' . "\n";

if ($c790d8a5c681996d) {
	$c790d8a5c681996d = false;
	XUI::EFFEb9f2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'STREAM_START', $Cc34ada8114813bd);
} else {
	XUI::eFfeB9f2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'STREAM_RESTART', $Cc34ada8114813bd);
}
$d55bf693d0ece21c = $b53b03db133532c7 . XUI::D076F5a2Cc104C49($bb62005ea7eb8380, 10)[0];
$bb0071da5a239b0c['stream_info'] = null;

if (file_exists($d55bf693d0ece21c)) {
	$E02429d2ee600884 = XUI::C8851B830a0692CD($d55bf693d0ece21c);

	if ((10 < intval($E02429d2ee600884['of_duration']))) {
		$E02429d2ee600884['of_duration'] = 10;
	}
	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur', intval($E02429d2ee600884['of_duration']));

	if (($Cc6901bef8bb7c30 < intval($E02429d2ee600884['of_duration']))) {
		$Cc6901bef8bb7c30 = intval($E02429d2ee600884['of_duration']);
	}

	if ($E02429d2ee600884) {
		$bb0071da5a239b0c['stream_info'] = json_encode($E02429d2ee600884, JSON_UNESCAPED_UNICODE);
		$aa2e54fde620d6b3 = XUI::BB02B8E7d661C337('live', STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8');
		$fa741d851639c561 = false;
		$C6490eba6e5b2915 = time();
	}
}
$f03f005ea6f01679 = 0;
$Dd7dd922fac30f26 = $F2735dad02d30e84 = $fbf4f3f4868222b7 = null;

if (!$bb0071da5a239b0c['stream_info']) {
	goto label430;
}

$b0000fe47694dd59 = json_decode($bb0071da5a239b0c['stream_info'], true);
$f03f005ea6f01679 = intval(XUI::a267181c61BdFff9($b0000fe47694dd59));
$Dd7dd922fac30f26 = $b0000fe47694dd59['codecs']['audio']['codec_name'] ?: null;
$F2735dad02d30e84 = $b0000fe47694dd59['codecs']['video']['codec_name'] ?: null;
$fbf4f3f4868222b7 = $b0000fe47694dd59['codecs']['video']['height'] ?: null;

if (!$fbf4f3f4868222b7) {
	goto label430;
}

$fbf4f3f4868222b7 = XUI::CceDfAea1d970310(array(240, 360, 480, 576, 720, 1080, 1440, 2160), $fbf4f3f4868222b7);

label430:
if (!$ea6de21e70c530a9 && $bb0071da5a239b0c['stream_info'] && $bb0071da5a239b0c['on_demand']) {
	if ($bb0071da5a239b0c['stream_info']) {
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `stream_info` = ?, `compatible` = ?, `audio_codec` = ?, `video_codec` = ?, `resolution` = ?, `bitrate` = ?, `stream_status` = 0, `stream_started` = ? WHERE `server_stream_id` = ?', $bb0071da5a239b0c['stream_info'], $f03f005ea6f01679, $Dd7dd922fac30f26, $F2735dad02d30e84, $fbf4f3f4868222b7, intval($aa2e54fde620d6b3), time() - $db752e19806388c2, $bb0071da5a239b0c['server_stream_id']);
	} else {
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `stream_status` = 0, `stream_info` = NULL, `compatible` = 0, `audio_codec` = NULL, `video_codec` = NULL, `resolution` = NULL, `stream_started` = ? WHERE `server_stream_id` = ?', time() - $db752e19806388c2, $bb0071da5a239b0c['server_stream_id']);
	}
} else {
	$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `stream_info` = ?, `compatible` = ?, `audio_codec` = ?, `video_codec` = ?, `resolution` = ?, `bitrate` = ?, `stream_status` = 0 WHERE `server_stream_id` = ?', $bb0071da5a239b0c['stream_info'], $f03f005ea6f01679, $Dd7dd922fac30f26, $F2735dad02d30e84, $fbf4f3f4868222b7, intval($aa2e54fde620d6b3), $bb0071da5a239b0c['server_stream_id']);
}

if (XUI::$rSettings['enable_cache']) {
	XUI::AFA0f3ffb001B9be($F26087d31c2bbe4d);
}
echo 'End start process' . "\n";

goto label554;

label1847:
unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.progress_check');

label298:
if (!((XUI::$rSettings['audio_restart_loss'] == 1) && (300 < (time() - $Fe34e449b0cfdfac)))) {
	goto label617;
}

echo 'Checking audio...' . "\n";
$d55bf693d0ece21c = XUI::d076F5A2Cc104C49($bb62005ea7eb8380, 10)[0];

if (!empty($d55bf693d0ece21c)) {
	$E02429d2ee600884 = XUI::C8851B830a0692CD($b53b03db133532c7 . $d55bf693d0ece21c);

	if ((!isset($E02429d2ee600884['codecs']['audio']) || empty($E02429d2ee600884['codecs']['audio']))) {
		echo 'Lost audio! Break' . "\n";
		XUI::effeb9F2C8015c8a($F26087d31c2bbe4d, SERVER_ID, 'AUDIO_LOSS', $Cc34ada8114813bd);

		goto label1186;
	}
	$Fe34e449b0cfdfac = time();

	label617:
	if ((($Cc6901bef8bb7c30 * 6) <= time() - $F8476b3d509c0b2a)) {
		$Fcfb63b23cad3c6e = md5_file($bb62005ea7eb8380);

		if ($Ba344b2758e3e955 != $Fcfb63b23cad3c6e) {
			$Ba344b2758e3e955 = $Fcfb63b23cad3c6e;
			$F8476b3d509c0b2a = time();

			label1851:
			if (XUI::$rSettings['encrypt_hls']) {
				foreach (glob(STREAMS_PATH . $F26087d31c2bbe4d . '_*.ts.enc') as $e2f848a82a80c113) {
					if (!file_exists(rtrim($e2f848a82a80c113, '.enc'))) {
						unlink($e2f848a82a80c113);
					}
				}
			}

			if ((count(json_decode($bb0071da5a239b0c['stream_info'], true)) == 0)) {
				$fa741d851639c561 = true;
			}
			$F8476b3d509c0b2a = time();

			goto label1095;
		}

		goto label1186;
	}

	label1095:
	if (((XUI::$rSettings['priority_backup'] == 1) && (1 < count($bbfc9bd8432031f5)) && ($fcae8575b94f8564 == 0) && (300 < (time() - $Ea1ac3fc3421259a)))) {
		echo 'Checking backups...' . "\n";
		$Ea1ac3fc3421259a = time();
		$D3fa098be3f297cd = array_search($Cc34ada8114813bd, $bbfc9bd8432031f5);

		if ((!is_numeric($D3fa098be3f297cd) || (0 < $D3fa098be3f297cd))) {
			foreach ($bbfc9bd8432031f5 as $c8d91fcd2309e48a) {
				if (!(($c8d91fcd2309e48a == $Cc34ada8114813bd) || ($c8d91fcd2309e48a == $D9b6e988c8c78276))) {
					$ecc9029bfbc77eed = XUI::ce3ba3178bC00d1C($c8d91fcd2309e48a);
					$C6033ec178efa2ae = strtolower(substr($ecc9029bfbc77eed, 0, strpos($ecc9029bfbc77eed, '://')));
					$dc0404bcfb9cd8f1 = implode(' ', XUI::a4C93C52F5D2d72D($f86c7f12032c787a, $C6033ec178efa2ae, 'fetch'));

					if (($E02429d2ee600884 = XUI::c8851b830a0692cd($ecc9029bfbc77eed, $dc0404bcfb9cd8f1))) {
						echo 'Switch priority' . "\n";
						XUI::EffEb9F2c8015C8a($F26087d31c2bbe4d, SERVER_ID, 'PRIORITY_SWITCH', $c8d91fcd2309e48a);
						$D9b6e988c8c78276 = $c8d91fcd2309e48a;
						$b50df7318b3a8be8 = true;
						$D97a4f098a8d1bf8 = false;

						goto label1186;
					}
				}
			}
		}
	}

	goto label496;
}

goto label1186;

label1880:;
