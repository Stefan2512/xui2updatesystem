<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc >= 6) {
		$d58b4f8653a391d8 = intval($argv[2]);

		if ($d58b4f8653a391d8 != 0) {
			shell_exec("kill -9 `ps -ef | grep 'XUI Install\\[" . $d58b4f8653a391d8 . "\\]' | grep -v grep | awk '{print \$2}'`;");
			set_time_limit(0);
			cli_set_process_title('XUI Install[' . $d58b4f8653a391d8 . ']');
			register_shutdown_function('shutdown');
			require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
			unlink(CACHE_TMP_PATH . 'servers');
			XUI::$rServers = XUI::f99d78e199D641D5();
			$E379394c7b1a273f = intval($argv[1]);

			if (!($E379394c7b1a273f != 1 && Xui\Functions::getLicense()[9] == 1)) {
				$b87b2986f8f49da8 = intval($argv[3]);
				list(, , , , $a71afc14d6cd090d, $d5249dad8e8411b7) = $argv;
				$F91f810dbf66509a = (empty($argv[6]) ? 80 : intval($argv[6]));
				$a78833bcca43d4e5 = (empty($argv[7]) ? 443 : intval($argv[7]));
				$e22648017bfc9b61 = (empty($argv[8]) ? 0 : intval($argv[8]));
				$D4959f87d20e3759 = (empty($argv[9]) ? 0 : intval($argv[9]));
				$f96fcd481c5c5bb2 = (empty($argv[10]) ? array() : json_decode($argv[10], true));
				$B753706f1970d2b5 = '# XUI.one' . PHP_EOL . PHP_EOL . 'net.ipv4.tcp_congestion_control = bbr' . PHP_EOL . 'net.core.default_qdisc = fq' . PHP_EOL . 'net.ipv4.tcp_rmem = 8192 87380 134217728' . PHP_EOL . 'net.ipv4.udp_rmem_min = 16384' . PHP_EOL . 'net.core.rmem_default = 262144' . PHP_EOL . 'net.core.rmem_max = 268435456' . PHP_EOL . 'net.ipv4.tcp_wmem = 8192 65536 134217728' . PHP_EOL . 'net.ipv4.udp_wmem_min = 16384' . PHP_EOL . 'net.core.wmem_default = 262144' . PHP_EOL . 'net.core.wmem_max = 268435456' . PHP_EOL . 'net.core.somaxconn = 1000000' . PHP_EOL . 'net.core.netdev_max_backlog = 250000' . PHP_EOL . 'net.core.optmem_max = 65535' . PHP_EOL . 'net.ipv4.tcp_max_tw_buckets = 1440000' . PHP_EOL . 'net.ipv4.tcp_max_orphans = 16384' . PHP_EOL . 'net.ipv4.ip_local_port_range = 2000 65000' . PHP_EOL . 'net.ipv4.tcp_no_metrics_save = 1' . PHP_EOL . 'net.ipv4.tcp_slow_start_after_idle = 0' . PHP_EOL . 'net.ipv4.tcp_fin_timeout = 15' . PHP_EOL . 'net.ipv4.tcp_keepalive_time = 300' . PHP_EOL . 'net.ipv4.tcp_keepalive_probes = 5' . PHP_EOL . 'net.ipv4.tcp_keepalive_intvl = 15' . PHP_EOL . 'fs.file-max=20970800' . PHP_EOL . 'fs.nr_open=20970800' . PHP_EOL . 'fs.aio-max-nr=20970800' . PHP_EOL . 'net.ipv4.tcp_timestamps = 1' . PHP_EOL . 'net.ipv4.tcp_window_scaling = 1' . PHP_EOL . 'net.ipv4.tcp_mtu_probing = 1' . PHP_EOL . 'net.ipv4.route.flush = 1' . PHP_EOL . 'net.ipv6.route.flush = 1';
				$e789dc31fd146637 = BIN_PATH . 'install/';
				$b93e6a2691d72853 = array('lb' => 'loadbalancer.tar.gz', 'lb_update' => 'loadbalancer_update.tar.gz', 'proxy' => 'proxy.tar.gz');

				if ($E379394c7b1a273f == 1) {
					$D57b432dc56eb885 = array('iproute2', 'net-tools', 'libcurl4', 'libxslt1-dev', 'libonig-dev', 'e2fsprogs', 'wget', 'sysstat', 'mcrypt', 'python3', 'certbot', 'iptables-persistent', 'libjpeg-dev', 'libpng-dev', 'php-ssh2', 'xz-utils', 'zip', 'unzip');
					$cadccb1d21ac3f20 = array($b93e6a2691d72853['proxy']);
				} else {
					if ($E379394c7b1a273f == 2) {
						$D57b432dc56eb885 = array('cpufrequtils', 'iproute2', 'python', 'net-tools', 'dirmngr', 'gpg-agent', 'software-properties-common', 'libmaxminddb0', 'libmaxminddb-dev', 'mmdb-bin', 'libcurl4', 'libgeoip-dev', 'libxslt1-dev', 'libonig-dev', 'e2fsprogs', 'wget', 'sysstat', 'alsa-utils', 'v4l-utils', 'mcrypt', 'python3', 'certbot', 'iptables-persistent', 'libjpeg-dev', 'libpng-dev', 'php-ssh2', 'xz-utils', 'zip', 'unzip');
						$cadccb1d21ac3f20 = array($b93e6a2691d72853['lb']);
					} else {
						if ($E379394c7b1a273f == 3) {
							$D57b432dc56eb885 = array('cpufrequtils');
							$cadccb1d21ac3f20 = array($b93e6a2691d72853['lb_update']);
						} else {
							$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 4 WHERE `id` = ?;', $d58b4f8653a391d8);
							echo 'Invalid type specified!' . "\n";

							exit();
						}
					}
				}

				if ($E379394c7b1a273f == 1) {
					file_put_contents($e789dc31fd146637 . $d58b4f8653a391d8 . '.json', json_encode(array('root_username' => $a71afc14d6cd090d, 'root_password' => $d5249dad8e8411b7, 'ssh_port' => $b87b2986f8f49da8, 'http_broadcast_port' => $F91f810dbf66509a, 'https_broadcast_port' => $a78833bcca43d4e5, 'parent_id' => $f96fcd481c5c5bb2)));
				} else {
					file_put_contents($e789dc31fd146637 . $d58b4f8653a391d8 . '.json', json_encode(array('root_username' => $a71afc14d6cd090d, 'root_password' => $d5249dad8e8411b7, 'ssh_port' => $b87b2986f8f49da8)));
				}

				$baba170ab02ca0bd = XUI::$rServers[$d58b4f8653a391d8]['server_ip'];
				echo 'Connecting to ' . $baba170ab02ca0bd . ':' . $b87b2986f8f49da8 . "\n";

				if ($c01eb13062f5f0d3 = ssh2_connect($baba170ab02ca0bd, $b87b2986f8f49da8)) {
					if ($a71afc14d6cd090d == 'root') {
						echo 'Connected! Authenticating as root user...' . "\n";
					} else {
						echo 'Connected! Authenticating as non-root user...' . "\n";
					}

					$B59c127fecf35c15 = @ssh2_auth_password($c01eb13062f5f0d3, $a71afc14d6cd090d, $d5249dad8e8411b7);

					if ($B59c127fecf35c15) {
						echo "\n" . 'Stopping any previous version of XUI' . "\n";
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo systemctl stop xuione');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo killall -9 -u xui');
						echo "\n" . 'Updating system' . "\n";
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm /var/lib/dpkg/lock-frontend && sudo rm /var/cache/apt/archives/lock && sudo rm /var/lib/dpkg/lock');

						if ($E379394c7b1a273f != 2) {
						} else {
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo add-apt-repository -y ppa:maxmind/ppa');
						}

						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo apt-get update');

						foreach ($D57b432dc56eb885 as $fe06d74291ffa213) {
							echo 'Installing package: ' . $fe06d74291ffa213 . "\n";
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo DEBIAN_FRONTEND=noninteractive apt-get -yq install ' . $fe06d74291ffa213);
						}

						if (!in_array($E379394c7b1a273f, array(1, 2))) {
						} else {
							echo 'Creating XUI system user' . "\n";
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo adduser --system --shell /bin/false --group --disabled-login xui');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo mkdir ' . XUI_HOME);
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm -rf ' . BIN_PATH);
						}

						$Ea22c4a9ab5b2176 = 0;

						foreach ($cadccb1d21ac3f20 as $e2f848a82a80c113) {
							$Ea22c4a9ab5b2176++;
							echo 'Transferring compressed system files (' . $Ea22c4a9ab5b2176 . ' of ' . count($cadccb1d21ac3f20) . ')' . "\n";

							if (sendfile($c01eb13062f5f0d3, $e789dc31fd146637 . $e2f848a82a80c113, '/tmp/' . $e2f848a82a80c113, true)) {
								echo 'Extracting to directory' . "\n";
								$B95dc1bd2d8c3a31 = cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm -rf ' . XUI_HOME . 'status');
								$B95dc1bd2d8c3a31 = cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo tar -zxvf "/tmp/' . $e2f848a82a80c113 . '" -C "' . XUI_HOME . '"');

								if (file_exists(XUI_HOME . 'status')) {
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm -f "/tmp/' . $e2f848a82a80c113 . '.tar.gz"');
								} else {
									$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 4 WHERE `id` = ?;', $d58b4f8653a391d8);
									echo 'Failed to extract files! Exiting' . "\n";

									exit();
								}
							} else {
								$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 4 WHERE `id` = ?;', $d58b4f8653a391d8);
								echo 'Invalid MD5 checksum! Exiting' . "\n";

								exit();
							}
						}

						if (!in_array($E379394c7b1a273f, array(2, 3))) {
						} else {
							if (stripos(cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo cat /etc/fstab')['output'], STREAMS_PATH) !== false) {
							} else {
								echo 'Adding ramdisk mounts' . "\n";
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "tmpfs ' . STREAMS_PATH . ' tmpfs defaults,noatime,nosuid,nodev,noexec,mode=1777,size=90% 0 0" >> /etc/fstab');
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "tmpfs ' . TMP_PATH . ' tmpfs defaults,noatime,nosuid,nodev,noexec,mode=1777,size=2G 0 0" >> /etc/fstab');
							}

							if (stripos(cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo cat /etc/sysctl.conf')['output'], 'XUI.one') === false) {
								if ($e22648017bfc9b61) {
									echo 'Adding sysctl.conf' . "\n";
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo modprobe ip_conntrack');
									file_put_contents(TMP_PATH . 'sysctl_' . $d58b4f8653a391d8, $B753706f1970d2b5);
									sendfile($c01eb13062f5f0d3, TMP_PATH . 'sysctl_' . $d58b4f8653a391d8, '/etc/sysctl.conf');
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo sysctl -p');
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo touch ' . CONFIG_PATH . 'sysctl.on');
								} else {
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm ' . CONFIG_PATH . 'sysctl.on');
								}
							} else {
								if (!$e22648017bfc9b61) {
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm ' . CONFIG_PATH . 'sysctl.on');
								} else {
									cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo touch ' . CONFIG_PATH . 'sysctl.on');
								}
							}
						}

						echo 'Generating configuration file' . "\n";
						$c6c7cfbaeb72428d = parse_ini_file(CONFIG_PATH . 'config.ini');

						if ($E379394c7b1a273f == 1) {
							if ($D4959f87d20e3759) {
								$Ce5917427708599c = '; XUI Configuration' . "\n" . '; -----------------' . "\n\n" . '[XUI]' . "\n" . 'hostname    =   "' . XUI::$rServers[SERVER_ID]['private_ip'] . '"' . "\n" . 'port        =   ' . intval(XUI::$rServers[SERVER_ID]['http_broadcast_port']) . "\n" . 'server_id   =   ' . $d58b4f8653a391d8;
							} else {
								$Ce5917427708599c = '; XUI Configuration' . "\n" . '; -----------------' . "\n\n" . '[XUI]' . "\n" . 'hostname    =   "' . XUI::$rServers[SERVER_ID]['server_ip'] . '"' . "\n" . 'port        =   ' . intval(XUI::$rServers[SERVER_ID]['http_broadcast_port']) . "\n" . 'server_id   =   ' . $d58b4f8653a391d8;
							}
						} else {
							$Ce5917427708599c = '; XUI Configuration' . "\n" . '; -----------------' . "\n" . '; Your username and password will be encrypted and' . "\n" . "; saved to the 'credentials' file in this folder" . "\n" . '; automatically.' . "\n" . ';' . "\n" . '; To change your username or password, modify BOTH' . "\n" . '; below and XUI will read and re-encrypt them.' . "\n\n" . '[XUI]' . "\n" . 'hostname    =   "' . XUI::$rServers[SERVER_ID]['server_ip'] . '"' . "\n" . 'database    =   "xui"' . "\n" . 'port        =   ' . intval(XUI::$rConfig['port']) . "\n" . 'server_id   =   ' . $d58b4f8653a391d8 . "\n" . 'is_lb       =   1' . "\n\n" . '[Encrypted]' . "\n" . 'username    =   ""' . "\n" . 'password    =   ""';
						}

						file_put_contents(TMP_PATH . 'config_' . $d58b4f8653a391d8, $Ce5917427708599c);
						sendfile($c01eb13062f5f0d3, TMP_PATH . 'config_' . $d58b4f8653a391d8, CONFIG_PATH . 'config.ini');
						echo 'Installing service' . "\n";
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm /etc/systemd/system/xui.service');
						$e1bff58d2d81298b = '[Unit]' . "\n" . 'SourcePath=/home/xui/service' . "\n" . 'Description=XUI.one Service' . "\n" . 'After=network.target' . "\n" . 'StartLimitIntervalSec=0' . "\n\n" . '[Service]' . "\n" . 'Type=simple' . "\n" . 'User=root' . "\n" . 'Restart=always' . "\n" . 'RestartSec=1' . "\n" . 'ExecStart=/bin/bash /home/xui/service start' . "\n" . 'ExecRestart=/bin/bash /home/xui/service restart' . "\n" . 'ExecStop=/bin/bash /home/xui/service stop' . "\n\n" . '[Install]' . "\n" . 'WantedBy=multi-user.target';
						file_put_contents(TMP_PATH . 'systemd_' . $d58b4f8653a391d8, $e1bff58d2d81298b);
						sendfile($c01eb13062f5f0d3, TMP_PATH . 'systemd_' . $d58b4f8653a391d8, '/etc/systemd/system/xuione.service');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo chmod +x /etc/systemd/system/xuione.service');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm /etc/init.d/xuione');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo systemctl daemon-reload');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo systemctl enable xuione');

						if ($E379394c7b1a273f == 1) {
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm /home/xui/bin/nginx/conf/servers/*.conf');

							foreach ($f96fcd481c5c5bb2 as $fcae8575b94f8564) {
								if ($D4959f87d20e3759) {
									$c59ec257c284c894 = XUI::$rServers[$fcae8575b94f8564]['private_ip'] . ':' . XUI::$rServers[$fcae8575b94f8564]['http_broadcast_port'];
								} else {
									$c59ec257c284c894 = XUI::$rServers[$fcae8575b94f8564]['server_ip'] . ':' . XUI::$rServers[$fcae8575b94f8564]['http_broadcast_port'];
								}

								if (XUI::$rServers[$fcae8575b94f8564]['is_main']) {
									$B76ac07451d0e3e0 = 'location / {' . "\n" . '    include options.conf;' . "\n" . '    proxy_pass http://' . $c59ec257c284c894 . '$1;' . "\n" . '}';
								} else {
									$D3fa098be3f297cd = md5($d58b4f8653a391d8 . '_' . $fcae8575b94f8564 . '_' . OPENSSL_EXTRA);
									$B76ac07451d0e3e0 = 'location ~/' . $D3fa098be3f297cd . '(.*)$ {' . "\n" . '    include options.conf;' . "\n" . '    proxy_pass http://' . $c59ec257c284c894 . '$1;' . "\n" . '    proxy_set_header X-Token "' . $D3fa098be3f297cd . '";' . "\n" . '}';
								}

								$bb780ebf2b08c425 = TMP_PATH . md5(time() . $D3fa098be3f297cd . '.conf');
								file_put_contents($bb780ebf2b08c425, $B76ac07451d0e3e0);
								sendfile($c01eb13062f5f0d3, $bb780ebf2b08c425, '/home/xui/bin/nginx/conf/servers/' . intval($fcae8575b94f8564) . '.conf');
							}
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "listen ' . $F91f810dbf66509a . ';" > "/home/xui/bin/nginx/conf/ports/http.conf"');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "listen ' . $a78833bcca43d4e5 . ' ssl;" > "/home/xui/bin/nginx/conf/ports/https.conf"');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo chmod 0777 /home/xui/bin');
						} else {
							sendfile($c01eb13062f5f0d3, CONFIG_PATH . 'credentials', CONFIG_PATH . 'credentials');
							sendfile($c01eb13062f5f0d3, XUI_HOME . 'bin/nginx/conf/custom.conf', XUI_HOME . 'bin/nginx/conf/custom.conf');
							sendfile($c01eb13062f5f0d3, XUI_HOME . 'bin/nginx/conf/realip_cdn.conf', XUI_HOME . 'bin/nginx/conf/realip_cdn.conf');
							sendfile($c01eb13062f5f0d3, XUI_HOME . 'bin/nginx/conf/realip_cloudflare.conf', XUI_HOME . 'bin/nginx/conf/realip_cloudflare.conf');
							sendfile($c01eb13062f5f0d3, XUI_HOME . 'bin/nginx/conf/realip_xui.conf', XUI_HOME . 'bin/nginx/conf/realip_xui.conf');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "" > "/home/xui/bin/nginx/conf/limit.conf"');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "" > "/home/xui/bin/nginx/conf/limit_queue.conf"');

							if ($E379394c7b1a273f != 2) {
							} else {
								$c59ec257c284c894 = '127.0.0.1:' . XUI::$rServers[$d58b4f8653a391d8]['http_broadcast_port'];
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "on_play http://' . $c59ec257c284c894 . '/stream/rtmp; on_publish http://' . $c59ec257c284c894 . '/stream/rtmp; on_play_done http://' . $c59ec257c284c894 . '/stream/rtmp;" > "/home/xui/bin/nginx_rtmp/conf/live.conf"');
								$F382f5a33a1b8a8b = (intval(cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo cat /proc/cpuinfo | grep "^processor" | wc -l')['output']) ?: 4);
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo rm ' . XUI_HOME . 'bin/php/etc/*.conf');
								$a17f90c2478a8542 = '#! /bin/bash' . "\n";
								$f16804ec320c6efb = 'upstream php {' . "\n" . '    least_conn;' . "\n";
								$C9521a97067b23d1 = file_get_contents(XUI_HOME . 'bin/php/etc/template');

								foreach (range(1, $F382f5a33a1b8a8b) as $Ea22c4a9ab5b2176) {
									$a17f90c2478a8542 .= 'start-stop-daemon --start --quiet --pidfile ' . XUI_HOME . 'bin/php/sockets/' . $Ea22c4a9ab5b2176 . '.pid --exec ' . XUI_HOME . 'bin/php/sbin/php-fpm -- --daemonize --fpm-config ' . XUI_HOME . 'bin/php/etc/' . $Ea22c4a9ab5b2176 . '.conf' . "\n";
									$f16804ec320c6efb .= '    server unix:' . XUI_HOME . 'bin/php/sockets/' . $Ea22c4a9ab5b2176 . '.sock;' . "\n";
									$bb780ebf2b08c425 = TMP_PATH . md5(time() . $Ea22c4a9ab5b2176 . '.conf');
									file_put_contents($bb780ebf2b08c425, str_replace('#PATH#', XUI_HOME, str_replace('#ID#', $Ea22c4a9ab5b2176, $C9521a97067b23d1)));
									sendfile($c01eb13062f5f0d3, $bb780ebf2b08c425, XUI_HOME . 'bin/php/etc/' . $Ea22c4a9ab5b2176 . '.conf');
								}
								$f16804ec320c6efb .= '}';
								$bb780ebf2b08c425 = TMP_PATH . md5(time() . 'daemons.sh');
								file_put_contents($bb780ebf2b08c425, $a17f90c2478a8542);
								sendfile($c01eb13062f5f0d3, $bb780ebf2b08c425, XUI_HOME . 'bin/daemons.sh');
								$bb780ebf2b08c425 = TMP_PATH . md5(time() . 'balance.conf');
								file_put_contents($bb780ebf2b08c425, $f16804ec320c6efb);
								sendfile($c01eb13062f5f0d3, $bb780ebf2b08c425, XUI_HOME . 'bin/nginx/conf/balance.conf');
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo chmod +x ' . XUI_HOME . 'bin/daemons.sh');
							}
						}

						$c075166bb8886aa3 = cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo cat "/etc/systemd/system.conf"')['output'];

						if (strpos($c075166bb8886aa3, 'DefaultLimitNOFILE=1048576') !== false) {
						} else {
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "' . "\n" . 'DefaultLimitNOFILE=1048576" >> "/etc/systemd/system.conf"');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "' . "\n" . 'DefaultLimitNOFILE=1048576" >> "/etc/systemd/user.conf"');
						}

						if (strpos($c075166bb8886aa3, 'nDefaultLimitNOFILESoft=1048576') !== false) {
						} else {
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "' . "\n" . 'DefaultLimitNOFILESoft=1048576" >> "/etc/systemd/system.conf"');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo echo "' . "\n" . 'DefaultLimitNOFILESoft=1048576" >> "/etc/systemd/user.conf"');
						}

						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo systemctl stop apparmor');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo systemctl disable apparmor');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo mount -a');
						cdd71cba45f932cb($c01eb13062f5f0d3, "sudo echo 'net.ipv4.ip_unprivileged_port_start=0' > /etc/sysctl.d/50-allports-nonroot.conf && sudo sysctl --system");
						sleep(3);
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo chown -R xui:xui ' . XUI_HOME . 'tmp');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo chown -R xui:xui ' . XUI_HOME . 'content/streams');
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo chown -R xui:xui ' . XUI_HOME);
						Xui\Functions::grantPrivileges('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', $baba170ab02ca0bd);
						echo 'Installation complete! Starting XUI' . "\n";
						cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo service xuione restart');

						if ($E379394c7b1a273f == 2) {
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo ' . XUI_HOME . 'status 1');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo -u xui ' . PHP_BIN . ' ' . CLI_PATH . 'startup.php');
							cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo -u xui ' . PHP_BIN . ' ' . CRON_PATH . 'servers.php');
						} else {
							if ($E379394c7b1a273f == 3) {
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo ' . PHP_BIN . ' ' . CLI_PATH . 'update.php "post-update"');
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo ' . XUI_HOME . 'status 1');
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo -u xui ' . PHP_BIN . ' ' . CLI_PATH . 'startup.php');
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo -u xui ' . PHP_BIN . ' ' . CRON_PATH . 'servers.php');
							} else {
								cdd71cba45f932cb($c01eb13062f5f0d3, 'sudo -u xui ' . PHP_BIN . ' ' . INCLUDES_PATH . 'startup.php');
							}
						}

						if (in_array($E379394c7b1a273f, array(1, 2))) {
							$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 1, `http_broadcast_port` = ?, `https_broadcast_port` = ?, `total_services` = ? WHERE `id` = ?;', $F91f810dbf66509a, $a78833bcca43d4e5, $F382f5a33a1b8a8b, $d58b4f8653a391d8);
						} else {
							$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 1 WHERE `id` = ?;', $d58b4f8653a391d8);
						}

						unlink($e789dc31fd146637 . $d58b4f8653a391d8 . '.json');
					} else {
						$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 4 WHERE `id` = ?;', $d58b4f8653a391d8);
						echo 'Failed to authenticate using credentials. Exiting' . "\n";

						exit();
					}
				} else {
					$Fee0d5a474c96306->query('UPDATE `servers` SET `status` = 4 WHERE `id` = ?;', $d58b4f8653a391d8);
					echo 'Failed to connect to server. Exiting' . "\n";

					exit();
				}
			} else {
				exit('Not supported in Trial Mode.' . "\n");
			}
		} else {
			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function sendFile($c01eb13062f5f0d3, $Bc16cc77a681d1ed, $f433193a3297ffde, $e4d5cf87f5f62664 = false)
{
	$Ba344b2758e3e955 = md5_file($Bc16cc77a681d1ed);
	ssh2_scp_send($c01eb13062f5f0d3, $Bc16cc77a681d1ed, $f433193a3297ffde);
	$e7a65037ff952c44 = trim(explode(' ', cDD71cba45f932cb($c01eb13062f5f0d3, 'md5sum "' . $f433193a3297ffde . '"')['output'])[0]);

	if ($Ba344b2758e3e955 == $e7a65037ff952c44) {
		return true;
	}

	if (!$e4d5cf87f5f62664) {
	} else {
		echo 'Failed to write using SCP, reverting to SFTP transfer... This will be take significantly longer!' . "\n";
	}

	$f85dedffe021d602 = ssh2_sftp($c01eb13062f5f0d3);
	$b0466cedbfdd5040 = true;
	$f523e362fb81d6c8 = @fopen('ssh2.sftp://' . $f85dedffe021d602 . $f433193a3297ffde, 'wb');

	try {
		$a27e64cc6ce01033 = @file_get_contents($Bc16cc77a681d1ed);

		if (@fwrite($f523e362fb81d6c8, $a27e64cc6ce01033) !== false) {
		} else {
			$b0466cedbfdd5040 = false;
		}

		fclose($f523e362fb81d6c8);
	} catch (Exception $c34ae71903f0d920) {
		$b0466cedbfdd5040 = false;
		fclose($f523e362fb81d6c8);
	}

	return $b0466cedbfdd5040;
}

function cdD71CBa45F932CB($c01eb13062f5f0d3, $cf1c389bda3e30fd)
{
	$f523e362fb81d6c8 = ssh2_exec($c01eb13062f5f0d3, $cf1c389bda3e30fd);
	$D370fc32f973c6ca = ssh2_fetch_stream($f523e362fb81d6c8, SSH2_STREAM_STDERR);
	stream_set_blocking($D370fc32f973c6ca, true);
	stream_set_blocking($f523e362fb81d6c8, true);

	return array('output' => stream_get_contents($f523e362fb81d6c8), 'error' => stream_get_contents($D370fc32f973c6ca));
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
