<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc > 1) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		$F26087d31c2bbe4d = intval($argv[1]);
		d60457acfd5df5c9($F26087d31c2bbe4d);
		set_time_limit(0);
		cli_set_process_title('XUICreate[' . $F26087d31c2bbe4d . ']');
		$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 LEFT JOIN `profiles` t3 ON t1.transcode_profile_id = t3.profile_id WHERE t1.`id` = ?', $F26087d31c2bbe4d);

		if ($Fee0d5a474c96306->num_rows() != 0) {
			$bb0071da5a239b0c = $Fee0d5a474c96306->get_row();
			$Fee0d5a474c96306->query('SELECT * FROM `streams_servers` WHERE stream_id  = ? AND `server_id` = ? AND `parent_id` IS NULL', $F26087d31c2bbe4d, SERVER_ID);

			if ($Fee0d5a474c96306->num_rows() != 0) {
				$cc5f26dd881329b7 = $Fee0d5a474c96306->get_row();
				$bb0071da5a239b0c['stream_source'] = json_decode($bb0071da5a239b0c['stream_source'], true);
				$cc5f26dd881329b7['cchannel_rsources'] = json_decode($cc5f26dd881329b7['cchannel_rsources'], true);

				if ($cc5f26dd881329b7['cchannel_rsources']) {
				} else {
					$cc5f26dd881329b7['cchannel_rsources'] = array();
				}

				$e46bb56b3aff787a = array_diff($bb0071da5a239b0c['stream_source'], $cc5f26dd881329b7['cchannel_rsources']);

				if (empty($e46bb56b3aff787a) && $bb0071da5a239b0c['stream_source'] === $cc5f26dd881329b7['cchannel_rsources']) {
				} else {
					foreach ($e46bb56b3aff787a as $c8d91fcd2309e48a) {
						$Ba344b2758e3e955 = md5($c8d91fcd2309e48a);

						if (!file_exists(CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.pid')) {
						} else {
							$d078cc3350b3ab63 = intval(file_get_contents(CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.pid'));

							if (!XUI::bcf05FD79248269E(SERVER_ID, $d078cc3350b3ab63, XUI::$rFFMPEG_CPU)) {
							} else {
								exec('kill -9 ' . $d078cc3350b3ab63);
							}
						}

						echo 'Processing source: ' . $c8d91fcd2309e48a . '...' . "\n";
						$a27f7389bff0ad1b = XUI::dA53076ce1dFc8FD($F26087d31c2bbe4d, $c8d91fcd2309e48a);
						$Fee0d5a474c96306->close_mysql();

						while (XUI::bcf05FD79248269e(SERVER_ID, $a27f7389bff0ad1b, XUI::$rFFMPEG_CPU)) {
							sleep(1);
						}
						$cc5f26dd881329b7['cchannel_rsources'][] = $c8d91fcd2309e48a;
						$Fee0d5a474c96306->db_connect();
						$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `cchannel_rsources` = ? WHERE `server_stream_id` = ?', json_encode($cc5f26dd881329b7['cchannel_rsources']), $cc5f26dd881329b7['server_stream_id']);
						unlink(CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.pid');
						unlink(CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.errors');
					}
					$F0aa4c827e9f8453 = '';

					foreach ($bb0071da5a239b0c['stream_source'] as $c8d91fcd2309e48a) {
						if (substr($c8d91fcd2309e48a, 0, 2) == 's:') {
							$B211d7401e6242f3 = explode(':', $c8d91fcd2309e48a, 3);
							$d58b4f8653a391d8 = intval($B211d7401e6242f3[1]);
						} else {
							$d58b4f8653a391d8 = SERVER_ID;
						}

						if ($d58b4f8653a391d8 == SERVER_ID && $bb0071da5a239b0c['movie_symlink'] == 1) {
							$F9452a7efafa1aba = pathinfo($c8d91fcd2309e48a)['extension'];

							if (strlen($F9452a7efafa1aba) != 0) {
							} else {
								$F9452a7efafa1aba = 'mp4';
							}
						} else {
							$F9452a7efafa1aba = 'ts';
						}

						if (!file_exists(CREATED_PATH . $F26087d31c2bbe4d . '_' . md5($c8d91fcd2309e48a) . '.' . $F9452a7efafa1aba)) {
						} else {
							$F0aa4c827e9f8453 .= "file '" . CREATED_PATH . $F26087d31c2bbe4d . '_' . md5($c8d91fcd2309e48a) . '.' . $F9452a7efafa1aba . "'" . "\n";
						}
					}
					$F0aa4c827e9f8453 = base64_encode($F0aa4c827e9f8453);
					shell_exec('echo ' . $F0aa4c827e9f8453 . ' | base64 --decode > "' . CREATED_PATH . intval($F26087d31c2bbe4d) . '_.list"');
					XUI::Afa0f3FFb001B9Be($F26087d31c2bbe4d);
					$b6f0b24a56fe41b6 = $eff3c5536b319f0b = 0;
					$A2334a366640c078 = explode("\n", file_get_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.list'));
					$a85e1b7d42c346a0 = array();

					foreach ($A2334a366640c078 as $bb2621204e39e62d) {
						list($bc2874292e0d9ece) = explode("'", explode("'", $bb2621204e39e62d)[1]);

						if (!file_exists($bc2874292e0d9ece)) {
						} else {
							$E286a0439c475f97 = XUI::C8851B830A0692cd($bc2874292e0d9ece);
							$a85e1b7d42c346a0[] = array('position' => $b6f0b24a56fe41b6, 'filename' => basename($bc2874292e0d9ece), 'path' => $bc2874292e0d9ece, 'stream_info' => $E286a0439c475f97, 'seconds' => $E286a0439c475f97['of_duration'], 'start' => $eff3c5536b319f0b, 'finish' => $eff3c5536b319f0b + $E286a0439c475f97['of_duration']);
							$eff3c5536b319f0b += $E286a0439c475f97['of_duration'];
							$b6f0b24a56fe41b6++;
						}
					}
					file_put_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.info', json_encode($a85e1b7d42c346a0, JSON_UNESCAPED_UNICODE));
					echo 'Completed!' . "\n";
					unlink(CREATED_PATH . $F26087d31c2bbe4d . '_.create', getmypid());
				}
			} else {
				echo "Channel doesn't exist on this server." . "\n";

				exit();
			}
		} else {
			echo "Channel doesn't exist." . "\n";

			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function d60457AcFD5df5c9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(CREATED_PATH . $F26087d31c2bbe4d . '_.create')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.create'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'XUICreate\\[" . intval($F26087d31c2bbe4d) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if ($cf1c389bda3e30fd != 'XUICreate[' . $F26087d31c2bbe4d . ']') {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}

	file_put_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.create', getmypid());
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
