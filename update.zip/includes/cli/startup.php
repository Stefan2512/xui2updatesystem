<?php

set_time_limit(0);

if ($argc) {
	$Bcdabf5ffe7a6cb6 = false;

	if (1 >= count($argv)) {
	} else {
		if (intval($argv[1]) != 1) {
		} else {
			$Bcdabf5ffe7a6cb6 = true;
		}
	}

	define('XUI_HOME', '/home/xui/');
	require XUI_HOME . 'www/stream/init.php';
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(32767);

	if (!file_exists(XUI_HOME . 'status')) {
	} else {
		exec('sudo ' . XUI_HOME . 'status 1');
	}

	if (filesize(XUI_HOME . 'bin/daemons.sh') != 0) {
	} else {
		echo 'Daemons corrupted! Regenerating...' . "\n";
		$a17f90c2478a8542 = '#! /bin/bash' . "\n";
		$f16804ec320c6efb = 'upstream php {' . "\n" . '    least_conn;' . "\n";
		$C9521a97067b23d1 = file_get_contents(XUI_HOME . 'bin/php/etc/template');
		exec('rm -f ' . XUI_HOME . 'bin/php/etc/*.conf');

		foreach (range(1, 4) as $Ea22c4a9ab5b2176) {
			$a17f90c2478a8542 .= 'start-stop-daemon --start --quiet --pidfile ' . XUI_HOME . 'bin/php/sockets/' . $Ea22c4a9ab5b2176 . '.pid --exec ' . XUI_HOME . 'bin/php/sbin/php-fpm -- --daemonize --fpm-config ' . XUI_HOME . 'bin/php/etc/' . $Ea22c4a9ab5b2176 . '.conf' . "\n";
			$f16804ec320c6efb .= '    server unix:' . XUI_HOME . 'bin/php/sockets/' . $Ea22c4a9ab5b2176 . '.sock;' . "\n";
			file_put_contents(XUI_HOME . 'bin/php/etc/' . $Ea22c4a9ab5b2176 . '.conf', str_replace('#PATH#', XUI_HOME, str_replace('#ID#', $Ea22c4a9ab5b2176, $C9521a97067b23d1)));
		}
		$f16804ec320c6efb .= '}';
		file_put_contents(XUI_HOME . 'bin/daemons.sh', $a17f90c2478a8542);
		file_put_contents(XUI_HOME . 'bin/nginx/conf/balance.conf', $f16804ec320c6efb);
	}

	if (posix_getpwuid(posix_geteuid())['name'] == 'root') {
		$d1ed31fd52b1ed35 = array();

		if (!file_exists(CRON_PATH . 'root_signals.php')) {
		} else {
			$d1ed31fd52b1ed35[] = '* * * * * ' . PHP_BIN . ' ' . CRON_PATH . 'root_signals.php # XUI';
		}

		if (!file_exists(CRON_PATH . 'root_mysql.php')) {
		} else {
			$d1ed31fd52b1ed35[] = '* * * * * ' . PHP_BIN . ' ' . CRON_PATH . 'root_mysql.php # XUI';
		}

		$ba931a44d0230927 = false;
		exec('sudo crontab -l', $f433193a3297ffde);

		foreach ($d1ed31fd52b1ed35 as $E356c4b0aacf7a68) {
			if (in_array($E356c4b0aacf7a68, $f433193a3297ffde)) {
			} else {
				$f433193a3297ffde[] = $E356c4b0aacf7a68;
				$ba931a44d0230927 = true;
			}
		}

		if ($ba931a44d0230927) {
			$e8cc47b805ffe946 = tempnam(TMP_PATH, 'crontab');
			file_put_contents($e8cc47b805ffe946, implode("\n", $f433193a3297ffde) . "\n");
			exec('sudo chattr -i /var/spool/cron/crontabs/root');
			exec('sudo crontab -r');
			exec('sudo crontab ' . $e8cc47b805ffe946);
			exec('sudo chattr +i /var/spool/cron/crontabs/root');
			echo 'Crontab installed' . "\n";
		} else {
			echo 'Crontab already installed' . "\n";
		}

		if ($Bcdabf5ffe7a6cb6) {
		} else {
			exec('sudo -u xui ' . PHP_BIN . ' ' . CRON_PATH . 'cache.php 1', $f433193a3297ffde);

			if (!file_exists(CRON_PATH . 'cache_engine.php') || file_exists(CACHE_TMP_PATH . 'cache_complete')) {
			} else {
				echo 'Generating cache...' . "\n";
				exec('sudo -u xui ' . PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php >/dev/null 2>/dev/null &');
			}
		}
	} else {
		if ($Bcdabf5ffe7a6cb6) {
		} else {
			exec(PHP_BIN . ' ' . CRON_PATH . 'cache.php 1');

			if (!file_exists(CRON_PATH . 'cache_engine.php') || file_exists(CACHE_TMP_PATH . 'cache_complete')) {
			} else {
				echo 'Generating cache...' . "\n";
				exec(PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php >/dev/null 2>/dev/null &');
			}
		}
	}

	echo "\n";
} else {
	exit(0);
}
