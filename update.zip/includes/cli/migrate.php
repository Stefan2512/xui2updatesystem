<?php

require str_replace('\\', '/', dirname($argv[0])) . '/../../includes/admin.php';
set_time_limit(0);
ini_set('memory_limit', -1);

if ($argc) {
	$F33933a74021db0b = array('reg_users', 'users', 'enigma2_devices', 'mag_devices', 'user_output', 'streaming_servers', 'series', 'series_episodes', 'streams', 'streams_sys', 'streams_options', 'stream_categories', 'bouquets', 'member_groups', 'packages', 'rtmp_ips', 'epg', 'blocked_ips', 'blocked_user_agents', 'isp_addon', 'tickets', 'tickets_replies', 'transcoding_profiles', 'watch_folders', 'categories', 'epg_sources', 'members', 'blocked_isps', 'groups', 'servers', 'stream_servers');
	$E6ac1d398140e1b7 = (json_decode(file_get_contents(TMP_PATH . '.migration.options'), true) ?: array());

	if (count($E6ac1d398140e1b7) != 0) {
	} else {
		$E6ac1d398140e1b7 = $F33933a74021db0b;
	}

	file_put_contents(TMP_PATH . '.migration.pid', getmypid());
	file_put_contents(TMP_PATH . '.migration.status', 1);
	$B3baea524daa88e8 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', true);

	if (!$B3baea524daa88e8->connected) {
		echo 'Failed to connect to migration database, or database is empty!' . "\n";
		file_put_contents(TMP_PATH . '.migration.status', 3);

		exit();
	}

	echo 'Connected to migration database.' . "\n";
	$B3baea524daa88e8->query("SHOW TABLES LIKE 'access_codes';");

	if (0 >= $B3baea524daa88e8->num_rows()) {
		$Fcf7001697d4fe21 = 0;

		foreach ($F33933a74021db0b as $B1a1e80ba9ae29c7) {
			$B3baea524daa88e8->query('SHOW TABLES LIKE ?;', $B1a1e80ba9ae29c7);

			if (0 >= $B3baea524daa88e8->num_rows()) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `' . $B1a1e80ba9ae29c7 . '`;');
				$Fcf7001697d4fe21 += (intval($B3baea524daa88e8->get_row()['count']) ?: 0);
			}
		}

		if ($Fcf7001697d4fe21 != 0) {
			echo "\n" . 'Migrating database to XUI...' . "\n\n";
			echo 'Remapping bouquets.' . "\n";
			$f9c1bb233c3eb615 = $B7c4b912a2afc994 = array();
			$B3baea524daa88e8->query('SELECT `id`, `type` FROM `streams`;');
			$A2b85ede89f9df0c = $B3baea524daa88e8->get_rows();

			foreach ($A2b85ede89f9df0c as $f523e362fb81d6c8) {
				$B7c4b912a2afc994[intval($f523e362fb81d6c8['id'])] = intval($f523e362fb81d6c8['type']);
			}
			$B3baea524daa88e8->query('SELECT `id` FROM `series`;');
			$bbc84f53c534450d = $B3baea524daa88e8->get_rows();

			foreach ($bbc84f53c534450d as $ef62ade7a459ab90) {
				$f9c1bb233c3eb615[] = intval($ef62ade7a459ab90['id']);
			}

			if (!in_array('reg_users', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `reg_users`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `users`;');
					echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' users.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `reg_users` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15 = B9da5d708FC1C079('users', $B59c127fecf35c15);
								$acd0eb2c8a975903 = f4817DC607d9981D($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT INTO `users`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('members', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `members`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `users`;');
					echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' users.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `members` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15 = B9Da5d708Fc1C079('users', $B59c127fecf35c15);
								$acd0eb2c8a975903 = F4817Dc607D9981D($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT INTO `users`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('blocked_ips', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `blocked_ips`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `blocked_ips`;');
					echo 'Blocking ' . number_format(count($c15d5b523e931f51), 0) . ' IP addresses.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9Da5d708fC1c079('blocked_ips', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817Dc607D9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `blocked_ips`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('blocked_user_agents', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `blocked_user_agents`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `blocked_uas`;');
					echo 'Blocking ' . number_format(count($c15d5b523e931f51), 0) . ' user-agents.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = b9DA5d708fC1C079('blocked_uas', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817DC607d9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `blocked_uas`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('isp_addon', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `isp_addon`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `blocked_isps`;');
					echo 'Blocking ' . number_format(count($c15d5b523e931f51), 0) . " ISP's." . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9dA5d708FC1C079('blocked_isps', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817Dc607d9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `blocked_isps`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('blocked_isps', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `blocked_isps`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `blocked_isps`;');
					echo 'Blocking ' . number_format(count($c15d5b523e931f51), 0) . " ISP's." . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9Da5D708FC1C079('blocked_isps', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817Dc607D9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `blocked_isps`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('bouquets', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `bouquets`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `bouquets`;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' bouquets.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$f46da30a01f7b2d7 = json_decode($B59c127fecf35c15['bouquet_channels'], true);
							$B59c127fecf35c15['bouquet_radios'] = array();
							$B59c127fecf35c15['bouquet_movies'] = $B59c127fecf35c15['bouquet_radios'];
							$B59c127fecf35c15['bouquet_channels'] = $B59c127fecf35c15['bouquet_movies'];

							foreach ($f46da30a01f7b2d7 as $F26087d31c2bbe4d) {
								if (!isset($B7c4b912a2afc994[intval($F26087d31c2bbe4d)])) {
								} else {
									$E379394c7b1a273f = array(1 => 'channels', 2 => 'movies', 3 => 'channels', 4 => 'radio')[$B7c4b912a2afc994[intval($F26087d31c2bbe4d)]];

									if (!$E379394c7b1a273f) {
									} else {
										$B59c127fecf35c15['bouquet_' . $E379394c7b1a273f][] = intval($F26087d31c2bbe4d);
									}
								}
							}
							$bbc84f53c534450d = json_decode($B59c127fecf35c15['bouquet_series'], true);
							$B59c127fecf35c15['bouquet_series'] = array();

							foreach ($bbc84f53c534450d as $A2d65843292b5c59) {
								if (!in_array(intval($A2d65843292b5c59), $f9c1bb233c3eb615)) {
								} else {
									$B59c127fecf35c15['bouquet_series'][] = intval($A2d65843292b5c59);
								}
							}

							foreach (array('channels', 'movies', 'radios', 'series') as $E379394c7b1a273f) {
								if ($B59c127fecf35c15['bouquet_' . $E379394c7b1a273f]) {
								} else {
									$B59c127fecf35c15['bouquet_' . $E379394c7b1a273f] = '[]';
								}
							}
							$B59c127fecf35c15 = b9da5D708Fc1c079('bouquets', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817Dc607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('enigma2_devices', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `enigma2_devices`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `enigma2_devices`;');
					echo 'Authorising ' . number_format($Aa8d8af3d37ca869, 0) . ' enigma devices.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `enigma2_devices` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15['lock_device'] = 1;
								$B59c127fecf35c15 = b9Da5D708fc1C079('enigma2_devices', $B59c127fecf35c15);
								$acd0eb2c8a975903 = f4817DC607d9981D($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT INTO `enigma2_devices`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('mag_devices', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `mag_devices`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `mag_devices`;');
					echo 'Authorising ' . number_format($Aa8d8af3d37ca869, 0) . ' MAG devices.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `mag_devices` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15['mac'] = base64_decode($B59c127fecf35c15['mac']);
								$B59c127fecf35c15['lock_device'] = 1;

								if (0 >= $B59c127fecf35c15['user_id']) {
								} else {
									$B59c127fecf35c15 = b9dA5D708fc1C079('mag_devices', $B59c127fecf35c15);
									$acd0eb2c8a975903 = F4817Dc607d9981D($B59c127fecf35c15);
									$A6d7047f2fda966c = 'INSERT INTO `mag_devices`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
									$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
								}
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('epg', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `epg`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `epg`;');
					echo 'Processing ' . number_format(count($c15d5b523e931f51), 0) . ' EPG URLs.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9DA5D708fC1c079('epg', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817dC607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `epg`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('epg_sources', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `epg_sources`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `epg`;');
					echo 'Processing ' . number_format(count($c15d5b523e931f51), 0) . ' EPG URLs.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = b9Da5D708FC1c079('epg', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817dC607D9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `epg`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('member_groups', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `member_groups` WHERE `can_delete` = 1;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('DELETE FROM `users_groups` WHERE `can_delete` = 1;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' user groups.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15['can_view_vod'] = $B59c127fecf35c15['reset_stb_data'];
							$B59c127fecf35c15['allow_restrictions'] = 1;
							$B59c127fecf35c15['allow_change_username'] = 1;
							$B59c127fecf35c15['allow_change_password'] = 1;
							$B59c127fecf35c15['minimum_username_length'] = 8;
							$B59c127fecf35c15['minimum_password_length'] = 8;
							$B59c127fecf35c15 = B9da5d708Fc1C079('users_groups', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817dC607D9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `users_groups`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('groups', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `groups` WHERE `can_delete` = 1;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('DELETE FROM `users_groups` WHERE `can_delete` = 1;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' user groups.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15['can_view_vod'] = $B59c127fecf35c15['reset_stb_data'];
							$B59c127fecf35c15['allow_restrictions'] = 1;
							$B59c127fecf35c15['allow_change_username'] = 1;
							$B59c127fecf35c15['allow_change_password'] = 1;
							$B59c127fecf35c15['minimum_username_length'] = 8;
							$B59c127fecf35c15['minimum_password_length'] = 8;
							$B59c127fecf35c15 = b9da5d708fC1c079('users_groups', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817DC607D9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `users_groups`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('groups', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `groups` WHERE `can_delete` = 1;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('DELETE FROM `users_groups` WHERE `can_delete` = 1;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' user groups.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15['can_view_vod'] = $B59c127fecf35c15['reset_stb_data'];
							$B59c127fecf35c15['allow_restrictions'] = 1;
							$B59c127fecf35c15['allow_change_username'] = 1;
							$B59c127fecf35c15['allow_change_password'] = 1;
							$B59c127fecf35c15['minimum_username_length'] = 8;
							$B59c127fecf35c15['minimum_password_length'] = 8;
							$B59c127fecf35c15 = B9dA5D708Fc1C079('users_groups', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817Dc607d9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `users_groups`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('packages', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `packages`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `users_packages`;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' user packages.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							if ($B59c127fecf35c15['can_gen_mag']) {
								$B59c127fecf35c15['is_mag'] = 1;
							} else {
								$B59c127fecf35c15['is_mag'] = 0;
							}

							if ($B59c127fecf35c15['can_gen_e2']) {
								$B59c127fecf35c15['is_e2'] = 1;
							} else {
								$B59c127fecf35c15['is_e2'] = 0;
							}

							if ($B59c127fecf35c15['only_mag'] || $B59c127fecf35c15['only_e2']) {
								$B59c127fecf35c15['is_line'] = 0;
							} else {
								$B59c127fecf35c15['is_line'] = 1;
							}

							$B59c127fecf35c15['lock_device'] = 1;
							$B59c127fecf35c15['check_compatible'] = 1;

							if (count(json_decode($B59c127fecf35c15['output_formats'], true)) != 0) {
							} else {
								$B59c127fecf35c15['output_formats'] = '[1,2,3]';
							}

							$B59c127fecf35c15 = b9DA5D708fc1C079('users_packages', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817dc607D9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `users_packages`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('rtmp_ips', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `rtmp_ips`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `rtmp_ips`;');
					echo 'Authorising ' . number_format(count($c15d5b523e931f51), 0) . ' RTMP IPs.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9DA5D708fC1C079('rtmp_ips', $B59c127fecf35c15);
							$B59c127fecf35c15['push'] = 1;
							$B59c127fecf35c15['pull'] = 1;
							$acd0eb2c8a975903 = f4817dc607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `rtmp_ips`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('series', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `series`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_series`;');
					echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' TV series.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `series` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15['category_id'] = '[' . intval($B59c127fecf35c15['category_id']) . ']';
								$B59c127fecf35c15['release_date'] = $B59c127fecf35c15['releaseDate'];

								if ($B59c127fecf35c15['tmdb_id'] != 0) {
								} else {
									$B59c127fecf35c15['tmdb_id'] = null;
								}

								$B59c127fecf35c15 = b9da5D708fc1c079('streams_series', $B59c127fecf35c15);
								$acd0eb2c8a975903 = F4817Dc607d9981d($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT IGNORE INTO `streams_series`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('series_episodes', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `series_episodes`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_episodes`;');
					echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' episodes.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `series_episodes` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15['episode_num'] = $B59c127fecf35c15['sort'];
								$B59c127fecf35c15 = b9Da5d708Fc1c079('streams_episodes', $B59c127fecf35c15);
								$acd0eb2c8a975903 = f4817Dc607d9981d($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT INTO `streams_episodes`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('streaming_servers', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `streaming_servers`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$c09ba6795b707edc = false;
					$Fee0d5a474c96306->query('TRUNCATE `servers`;');
					echo 'Moving ' . number_format(count($c15d5b523e931f51), 0) . ' servers.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15['server_type'] = 0;
							$B59c127fecf35c15['parent_id'] = null;
							$B59c127fecf35c15['http_broadcast_port'] = 80;
							$B59c127fecf35c15['https_broadcast_port'] = 443;
							$B59c127fecf35c15['rtmp_port'] = 8880;
							$B59c127fecf35c15['total_services'] = 4;
							$B59c127fecf35c15['http_ports_add'] = null;
							$B59c127fecf35c15['https_ports_add'] = null;

							if ($B59c127fecf35c15['can_delete'] == 0 && !$c09ba6795b707edc) {
								$B59c127fecf35c15['is_main'] = 1;
								$c09ba6795b707edc = true;
							} else {
								$B59c127fecf35c15['is_main'] = 0;
							}

							$B59c127fecf35c15 = b9DA5d708FC1c079('servers', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817dc607D9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `servers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('servers', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `servers` ORDER BY `id` ASC;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$c09ba6795b707edc = false;
					$Fee0d5a474c96306->query('TRUNCATE `servers`;');
					echo 'Moving ' . number_format(count($c15d5b523e931f51), 0) . ' servers.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15['server_type'] = 0;
							$B59c127fecf35c15['parent_id'] = null;
							$B59c127fecf35c15['http_broadcast_port'] = 80;
							$B59c127fecf35c15['https_broadcast_port'] = 443;
							$B59c127fecf35c15['rtmp_port'] = 8880;
							$B59c127fecf35c15['total_services'] = 4;
							$B59c127fecf35c15['http_ports_add'] = null;
							$B59c127fecf35c15['https_ports_add'] = null;

							if (!$c09ba6795b707edc) {
								$B59c127fecf35c15['is_main'] = 1;
								$c09ba6795b707edc = true;
							} else {
								$B59c127fecf35c15['is_main'] = 0;
							}

							$B59c127fecf35c15 = B9da5D708Fc1c079('servers', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817Dc607D9981D($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `servers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			$e4c780e1c26c19c1 = array();

			if (!in_array('streams', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `streams`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams`;');
					echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' streams.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `streams` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								try {
									$Ac15add2aa979556 = json_decode($B59c127fecf35c15['external_push'], true);

									if ($Ac15add2aa979556) {
									} else {
										$B59c127fecf35c15['external_push'] = '{}';
									}

									$B59c127fecf35c15['category_id'] = '[' . intval($B59c127fecf35c15['category_id']) . ']';
									$B59c127fecf35c15['movie_properties'] = $B59c127fecf35c15['movie_propeties'];

									if (!$B59c127fecf35c15['target_container']) {
									} else {
										list($B59c127fecf35c15['target_container']) = json_decode($B59c127fecf35c15['target_container'], true);
									}

									$e4c780e1c26c19c1[$B59c127fecf35c15['id']] = $B59c127fecf35c15['cchannel_rsources'];
									$B59c127fecf35c15 = b9DA5D708fc1C079('streams', $B59c127fecf35c15);
									$acd0eb2c8a975903 = F4817Dc607D9981D($B59c127fecf35c15);
									$A6d7047f2fda966c = 'INSERT INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
									$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
								} catch (Exception $c34ae71903f0d920) {
									echo 'Error: ' . $c34ae71903f0d920 . "\n";
								}
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('streams_options', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `streams_options`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_options`;');
					echo 'Attributing ' . number_format($Aa8d8af3d37ca869, 0) . ' options to streams.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `streams_options` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$B59c127fecf35c15 = B9da5D708fC1C079('streams_options', $B59c127fecf35c15);
								$acd0eb2c8a975903 = f4817DC607d9981D($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT INTO `streams_options`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('streams_sys', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `streams_sys`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_servers`;');
					echo 'Allocating ' . number_format($Aa8d8af3d37ca869, 0) . ' streams to servers.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `streams_sys` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							if (0 >= count($c15d5b523e931f51)) {
							} else {
								foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
									if ($B59c127fecf35c15['parent_id'] && $B59c127fecf35c15['parent_id'] != 0) {
									} else {
										$B59c127fecf35c15['parent_id'] = null;
									}

									if (!isset($e4c780e1c26c19c1[$B59c127fecf35c15['stream_id']])) {
									} else {
										$B59c127fecf35c15['cchannel_rsources'] = $e4c780e1c26c19c1[$B59c127fecf35c15['stream_id']];
									}

									$B59c127fecf35c15['custom_ffmpeg'] = '';
									$B59c127fecf35c15['stream_status'] = 0;
									$B59c127fecf35c15['stream_started'] = null;
									$B59c127fecf35c15['monitor_pid'] = null;

									if ($B59c127fecf35c15['pid'] > 0) {
									} else {
										$B59c127fecf35c15['pid'] = null;
									}

									$B59c127fecf35c15 = B9Da5D708fC1c079('streams_servers', $B59c127fecf35c15);
									$acd0eb2c8a975903 = f4817dC607D9981D($B59c127fecf35c15);
									$A6d7047f2fda966c = 'INSERT INTO `streams_servers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
									$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
								}
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('stream_servers', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `stream_servers`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_servers`;');
					echo 'Allocating ' . number_format($Aa8d8af3d37ca869, 0) . ' streams to servers.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `stream_servers` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							if (0 >= count($c15d5b523e931f51)) {
							} else {
								foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
									if ($B59c127fecf35c15['parent_id'] && $B59c127fecf35c15['parent_id'] != 0) {
									} else {
										$B59c127fecf35c15['parent_id'] = null;
									}

									$B59c127fecf35c15['stream_status'] = 0;
									$B59c127fecf35c15['stream_started'] = null;
									$B59c127fecf35c15['monitor_pid'] = null;

									if ($B59c127fecf35c15['pid'] > 0) {
									} else {
										$B59c127fecf35c15['pid'] = null;
									}

									$B59c127fecf35c15 = b9da5D708fc1c079('streams_servers', $B59c127fecf35c15);
									$acd0eb2c8a975903 = F4817dC607d9981d($B59c127fecf35c15);
									$A6d7047f2fda966c = 'INSERT INTO `streams_servers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
									$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
								}
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('stream_categories', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `stream_categories`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_categories`;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' categories.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9Da5d708fc1C079('streams_categories', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817DC607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('categories', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `categories`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `streams_categories`;');
					echo 'Creating ' . number_format(count($c15d5b523e931f51), 0) . ' categories.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = B9Da5D708fc1c079('streams_categories', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817DC607D9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('tickets', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `tickets`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `tickets`;');
					echo 'Posting ' . number_format(count($c15d5b523e931f51), 0) . ' tickets.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = b9da5d708Fc1c079('tickets', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817dC607D9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `tickets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('tickets_replies', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `tickets_replies`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `tickets_replies`;');
					echo 'Posting ' . number_format(count($c15d5b523e931f51), 0) . ' replies.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = b9Da5D708Fc1C079('tickets_replies', $B59c127fecf35c15);
							$acd0eb2c8a975903 = f4817dC607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `tickets_replies`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('transcoding_profiles', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT * FROM `transcoding_profiles`;');
				$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

				if (0 >= count($c15d5b523e931f51)) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `profiles`;');
					echo 'Generating ' . number_format(count($c15d5b523e931f51), 0) . ' transcoding profiles.' . "\n";

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						try {
							$B59c127fecf35c15 = b9DA5D708Fc1C079('profiles', $B59c127fecf35c15);
							$acd0eb2c8a975903 = F4817DC607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `profiles`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			$f433193a3297ffde = array();

			if (!in_array('user_output', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `user_output`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					echo 'Attributing ' . number_format($Aa8d8af3d37ca869, 0) . ' output options to lines.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `user_output` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								$f433193a3297ffde[$B59c127fecf35c15['user_id']][] = $B59c127fecf35c15['access_output_id'];
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}
				}
			}

			if (!in_array('users', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `users`;');
				$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

				if (0 >= $Aa8d8af3d37ca869) {
				} else {
					$Fee0d5a474c96306->query('TRUNCATE `lines`;');
					echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' lines.' . "\n";
					$Fffb76b482d3afe0 = range(0, $Aa8d8af3d37ca869, 1000);

					if ($Fffb76b482d3afe0) {
					} else {
						$Fffb76b482d3afe0 = array(0);
					}

					foreach ($Fffb76b482d3afe0 as $be001d5ed5a7c58d) {
						try {
							$B3baea524daa88e8->query('SELECT * FROM `users` LIMIT ' . $be001d5ed5a7c58d . ', 1000;');
							$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

							foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
								if (!empty($B59c127fecf35c15['isp_desc'])) {
								} else {
									$B59c127fecf35c15['isp_desc'] = null;
								}

								if (!isset($f433193a3297ffde[$B59c127fecf35c15['id']])) {
								} else {
									$B59c127fecf35c15['allowed_outputs'] = '[' . implode(',', $f433193a3297ffde[$B59c127fecf35c15['id']]) . ']';
								}

								if (!isset($B59c127fecf35c15['output'])) {
								} else {
									$B59c127fecf35c15['allowed_outputs'] = $B59c127fecf35c15['output'];
								}

								$B59c127fecf35c15['bouquet'] = '[' . implode(',', array_map('intval', json_decode($B59c127fecf35c15['bouquet'], true))) . ']';
								$B59c127fecf35c15 = B9da5D708fc1c079('lines', $B59c127fecf35c15);
								$acd0eb2c8a975903 = F4817DC607d9981d($B59c127fecf35c15);
								$A6d7047f2fda966c = 'INSERT INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
								$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
							}
						} catch (Exception $c34ae71903f0d920) {
							echo 'Error: ' . $c34ae71903f0d920 . "\n";
						}
					}

					try {
					} catch (Exception $c34ae71903f0d920) {
						echo 'Error: ' . $c34ae71903f0d920 . "\n";
					}
				}
			}

			if (!in_array('watch_folders', $E6ac1d398140e1b7)) {
			} else {
				$B3baea524daa88e8->query("SHOW TABLES LIKE 'watch_folders';");

				if (0 >= $B3baea524daa88e8->num_rows()) {
				} else {
					$B3baea524daa88e8->query('SELECT COUNT(*) AS `count` FROM `watch_folders`;');
					$Aa8d8af3d37ca869 = $B3baea524daa88e8->get_row()['count'];

					if (0 >= $Aa8d8af3d37ca869) {
					} else {
						$Fee0d5a474c96306->query('TRUNCATE `watch_folders`;');
						echo 'Adding ' . number_format($Aa8d8af3d37ca869, 0) . ' folders to watch.' . "\n";
						$B3baea524daa88e8->query('SELECT * FROM `watch_folders`;');
						$c15d5b523e931f51 = $B3baea524daa88e8->get_rows();

						foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
							$B59c127fecf35c15 = b9dA5D708Fc1c079('watch_folders', $B59c127fecf35c15);
							$B59c127fecf35c15['bouquets'] = '[' . implode(',', array_map('intval', json_decode($B59c127fecf35c15['bouquets'], true))) . ']';
							$B59c127fecf35c15['fb_bouquets'] = '[' . implode(',', array_map('intval', json_decode($B59c127fecf35c15['fb_bouquets'], true))) . ']';
							$acd0eb2c8a975903 = f4817dc607d9981d($B59c127fecf35c15);
							$A6d7047f2fda966c = 'INSERT INTO `watch_folders`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
							$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						}
					}
				}
			}

			try {
				$B3baea524daa88e8->query('SELECT * FROM `settings` LIMIT 1;');
				$F2d4d8f7981ac574 = $B3baea524daa88e8->get_row();
				$Fee0d5a474c96306->query('UPDATE `settings` SET `server_name` = ?, `default_timezone` = ?;', $F2d4d8f7981ac574['server_name'], $F2d4d8f7981ac574['default_timezone']);
			} catch (Exception $c34ae71903f0d920) {
				echo 'Error: ' . $c34ae71903f0d920 . "\n";
			}

			try {
				$B3baea524daa88e8->query("SHOW TABLES LIKE 'admin_settings';");

				if (0 >= $B3baea524daa88e8->num_rows()) {
				} else {
					$d5cdc15a30423fc6 = array();
					$B3baea524daa88e8->query('SELECT * FROM `admin_settings`;');

					foreach ($B3baea524daa88e8->get_rows() as $C740da31596f24ef) {
						$d5cdc15a30423fc6[$C740da31596f24ef['type']] = $C740da31596f24ef['value'];
					}

					if (!(0 < strlen($d5cdc15a30423fc6['recaptcha_v2_secret_key']) && 0 < strlen($d5cdc15a30423fc6['recaptcha_v2_site_key']))) {
					} else {
						$Fee0d5a474c96306->query('UPDATE `settings` SET `recaptcha_v2_secret_key` = ?, `recaptcha_v2_site_key` = ?;', $d5cdc15a30423fc6['recaptcha_v2_secret_key'], $d5cdc15a30423fc6['recaptcha_v2_site_key']);
					}
				}
			} catch (Exception $c34ae71903f0d920) {
				echo 'Error: ' . $c34ae71903f0d920 . "\n";
			}
			echo "\n" . 'Migration has been completed!' . "\n\n" . 'Your settings have been reset to the XUI default, please take some time to review the settings page and make the desired changes.' . "\n";
			file_put_contents(TMP_PATH . '.migration.status', 2);

			if (!is_object($B3baea524daa88e8)) {
			} else {
				$B3baea524daa88e8->close_mysql();
			}
		} else {
			echo "\n" . "Couldn't find anything to migrate in the `xui_migrate` database. Please ensure you restore your backup to that database specifically." . "\n\n";

			exit();
		}
	} else {
		echo "\n" . "Can't migrate from XUI to XUI! Use the restore functions instead." . "\n\n";

		exit();
	}
} else {
	exit(0);
}
