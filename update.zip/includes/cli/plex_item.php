<?php

setlocale(LC_ALL, 'en_US.UTF-8');
putenv('LC_ALL=en_US.UTF-8');

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(30711);
		$D2165010a62b36e4 = (json_decode(file_get_contents(WATCH_TMP_PATH . 'stream_database.pcache'), true) ?: array());
		$ee462bb53fd79bcd = json_decode(base64_decode($argv[1]), true);

		if ($ee462bb53fd79bcd) {
			file_put_contents(WATCH_TMP_PATH . getmypid() . '.ppid', time());

			if ($ee462bb53fd79bcd['type'] == 'movie') {
				$cd2a4260ef308305 = 60;
			} else {
				$cd2a4260ef308305 = 600;
			}

			set_time_limit($cd2a4260ef308305);
			ini_set('max_execution_time', $cd2a4260ef308305);
			fdc97512d22b990e();
		} else {
			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function C4A6f6f0DEbD5F57($b6842cb20051e925)
{
	return strtolower(preg_replace('/[^a-z0-9_]+/i', '', $b6842cb20051e925));
}

function f4817Dc607d9981D($d49041d5f05a9270)
{
	$D480255818428bfd = $F02c388243a378a7 = $C0ad72b730f8eea3 = $a27e64cc6ce01033 = array();

	foreach (array_keys($d49041d5f05a9270) as $D3fa098be3f297cd) {
		$F02c388243a378a7[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '`';
		$D480255818428bfd[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '` = ?';
	}

	foreach (array_values($d49041d5f05a9270) as $b6842cb20051e925) {
		if (!is_array($b6842cb20051e925)) {
		} else {
			$b6842cb20051e925 = json_encode($b6842cb20051e925, JSON_UNESCAPED_UNICODE);
		}

		$C0ad72b730f8eea3[] = '?';
		$a27e64cc6ce01033[] = $b6842cb20051e925;
	}

	return array('placeholder' => implode(',', $C0ad72b730f8eea3), 'columns' => implode(',', $F02c388243a378a7), 'data' => $a27e64cc6ce01033, 'update' => implode(',', $D480255818428bfd));
}

function B9Da5D708fC1C079($B1a1e80ba9ae29c7, $a27e64cc6ce01033 = array(), $fcc4f0f10efcef42 = false)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `column_name`, `column_default`, `is_nullable`, `data_type` FROM `information_schema`.`columns` WHERE `table_schema` = (SELECT DATABASE()) AND `table_name` = ? ORDER BY `ordinal_position`;', $B1a1e80ba9ae29c7);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($C740da31596f24ef['column_default'] != 'NULL') {
		} else {
			$C740da31596f24ef['column_default'] = null;
		}

		$f2373ceca1685f65 = false;

		if ($C740da31596f24ef['is_nullable'] != 'NO' || $C740da31596f24ef['column_default']) {
		} else {
			if (in_array($C740da31596f24ef['data_type'], array('int', 'float', 'tinyint', 'double', 'decimal', 'smallint', 'mediumint', 'bigint', 'bit'))) {
				$C740da31596f24ef['column_default'] = 0;
			} else {
				$C740da31596f24ef['column_default'] = '';
			}

			$f2373ceca1685f65 = true;
		}

		if (array_key_exists($C740da31596f24ef['column_name'], $a27e64cc6ce01033)) {
			if (empty($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && !is_numeric($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && is_null($C740da31596f24ef['column_default'])) {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = ($f2373ceca1685f65 ? $C740da31596f24ef['column_default'] : null);
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $a27e64cc6ce01033[$C740da31596f24ef['column_name']];
			}
		} else {
			if ($fcc4f0f10efcef42) {
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $C740da31596f24ef['column_default'];
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function getSeriesByID($C167873ff203aefe, $Ddb572d71804d3a6)
{
	global $Fee0d5a474c96306;

	if (!(file_exists(WATCH_TMP_PATH . 'series_' . $C167873ff203aefe . '.data') && time() - filemtime(WATCH_TMP_PATH . 'series_' . $C167873ff203aefe . '.data') < 360)) {
		if (!(file_exists(WATCH_TMP_PATH . 'series_' . intval($Ddb572d71804d3a6) . '.data') && time() - filemtime(WATCH_TMP_PATH . 'series_' . intval($Ddb572d71804d3a6) . '.data') < 360)) {
			$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `plex_uuid` = ? OR `tmdb_id` = ?;', $C167873ff203aefe, $Ddb572d71804d3a6);

			if ($Fee0d5a474c96306->num_rows() != 1) {
			} else {
				return $Fee0d5a474c96306->get_row();
			}
		} else {
			return json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . intval($Ddb572d71804d3a6) . '.data'), true);
		}
	} else {
		return json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . $C167873ff203aefe . '.data'), true);
	}
}

function FFD24e407abB46Eb($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function dc95637c2da3B543()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT MAX(`order`) AS `order` FROM `streams`;');

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return 0;
	}

	return intval($Fee0d5a474c96306->get_row()['order']) + 1;
}

function D7E7F81f646193b2($E379394c7b1a273f, $C52c0b6b0f74407b, $C3c8913edb801c35)
{
	global $ee462bb53fd79bcd;
	file_put_contents(WATCH_TMP_PATH . md5($ee462bb53fd79bcd['uuid'] . '_' . $ee462bb53fd79bcd['key'] . '_' . $E379394c7b1a273f . '_' . $C52c0b6b0f74407b . '_' . $C3c8913edb801c35) . '.pbouquet', json_encode(array('type' => $E379394c7b1a273f, 'bouquet_id' => $C52c0b6b0f74407b, 'id' => $C3c8913edb801c35)));
}

function fdC97512D22B990E()
{
	global $Fee0d5a474c96306;
	global $ee462bb53fd79bcd;
	global $D2165010a62b36e4;
	$a8bb73cba48fb7f6 = array(SERVER_ID);

	if (empty($ee462bb53fd79bcd['server_add'])) {
	} else {
		foreach (json_decode($ee462bb53fd79bcd['server_add'], true) as $d58b4f8653a391d8) {
			$a8bb73cba48fb7f6[] = intval($d58b4f8653a391d8);
		}
	}

	$Adf384de46aa6175 = $A38b42a281e3c3cf = array();

	if (0 >= $ee462bb53fd79bcd['category_id']) {
	} else {
		$A38b42a281e3c3cf = array(intval($ee462bb53fd79bcd['category_id']));
	}

	if (0 >= count(json_decode($ee462bb53fd79bcd['bouquets'], true))) {
	} else {
		$Adf384de46aa6175 = json_decode($ee462bb53fd79bcd['bouquets'], true);
	}

	$rLanguage = null;
	$a2d24fc8115839d0 = $ee462bb53fd79bcd['plex_categories'];
	$eaad9527ef2b563d = b9da5d708fc1c079('streams');
	$eaad9527ef2b563d['type'] = array('movie' => 2, 'show' => 5)[$ee462bb53fd79bcd['type']];

	if ($eaad9527ef2b563d['type']) {
		$A0fa741c62cbe676 = array('movie' => 1, 'show' => 2)[$ee462bb53fd79bcd['type']];

		switch ($ee462bb53fd79bcd['type']) {
			case 'movie':
				$C700a2b357e5ed65 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/library/metadata/' . $ee462bb53fd79bcd['key'] . '?X-Plex-Token=' . $ee462bb53fd79bcd['token'];
				$ddcfd131e6154888 = json_decode(json_encode(simplexml_load_string(readURL($C700a2b357e5ed65))), true);

				if ($ddcfd131e6154888) {
					$Ddb572d71804d3a6 = null;
					$A3b0fac4071c183f = null;

					foreach (makeArray($ddcfd131e6154888['Video']['Guid']) as $f358103af14f99c7) {
						if (substr($f358103af14f99c7['@attributes']['id'], 0, 7) != 'tmdb://') {
						} else {
							$Ddb572d71804d3a6 = intval(explode('tmdb://', $f358103af14f99c7['@attributes']['id'])[1]);
							echo 'TMDB ID: ' . $Ddb572d71804d3a6 . "\n";

							break;
						}
					}
					$F232366fdfb8ffd3 = array('file' => null, 'size' => null, 'data' => null, 'key' => null);

					foreach (makeArray($ddcfd131e6154888['Video']['Media']) as $Da7bcda6c519bab3) {
						if ($A3b0fac4071c183f) {
						} else {
							$A3b0fac4071c183f = $Da7bcda6c519bab3['Part']['@attributes']['file'];
						}

						if ($F232366fdfb8ffd3['size'] && $F232366fdfb8ffd3['size'] >= intval($Da7bcda6c519bab3['Part']['@attributes']['size'])) {
						} else {
							if (!(file_exists($Da7bcda6c519bab3['Part']['@attributes']['file']) || $ee462bb53fd79bcd['direct_proxy'])) {
							} else {
								$F232366fdfb8ffd3 = array('file' => $Da7bcda6c519bab3['Part']['@attributes']['file'], 'size' => intval($Da7bcda6c519bab3['Part']['@attributes']['size']), 'data' => $Da7bcda6c519bab3, 'key' => $Da7bcda6c519bab3['Part']['@attributes']['key']);
							}
						}
					}

					if (!empty($F232366fdfb8ffd3['file'])) {
						$d6d8af96b3cd2801 = json_encode(array('s:' . SERVER_ID . ':' . $F232366fdfb8ffd3['file']), JSON_UNESCAPED_UNICODE);
						$A752edc646ab347a = json_encode(array('http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . $F232366fdfb8ffd3['key'] . '?X-Plex-Token=' . $ee462bb53fd79bcd['token']), JSON_UNESCAPED_UNICODE);

						if (in_array($d6d8af96b3cd2801, $D2165010a62b36e4) || in_array($A752edc646ab347a, $D2165010a62b36e4)) {
						} else {
							$D2165010a62b36e4[] = $d6d8af96b3cd2801;
							$D2165010a62b36e4[] = $A752edc646ab347a;

							if ($ee462bb53fd79bcd['target_container'] != 'auto' && $ee462bb53fd79bcd['target_container'] && !$ee462bb53fd79bcd['direct_proxy']) {
								$eaad9527ef2b563d['target_container'] = $ee462bb53fd79bcd['target_container'];
							} else {
								$eaad9527ef2b563d['target_container'] = pathinfo($F232366fdfb8ffd3['file'])['extension'];
							}

							if (!empty($eaad9527ef2b563d['target_container'])) {
							} else {
								$eaad9527ef2b563d['target_container'] = 'mp4';
							}

							$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `filename` = ? AND `type` = ? AND `server_id` = ?;', utf8_decode($F232366fdfb8ffd3['file']), $A0fa741c62cbe676, SERVER_ID);

							if (!$ddcfd131e6154888['Video']['@attributes']['thumb']) {
							} else {
								$d7e02302834c503e = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=300&height=450&minSize=1&quality=100&upscale=1&url=' . $ddcfd131e6154888['Video']['@attributes']['thumb'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
								$A646087ab5268867 = XUI::B2068CE8B339bF70($d7e02302834c503e);
							}

							if (!$ddcfd131e6154888['Video']['@attributes']['art']) {
							} else {
								$B1fdf64ecfc30f68 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=1280&height=720&minSize=1&quality=100&upscale=1&url=' . $ddcfd131e6154888['Video']['@attributes']['art'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
								$f86e3ca402767b9e = XUI::B2068CE8B339bf70($B1fdf64ecfc30f68);
							}

							$cc6fe5bce59818ef = array();

							foreach (array_slice(makeArray($ddcfd131e6154888['Video']['Role']), 0, 5) as $B809ba74bb572f83) {
								$cc6fe5bce59818ef[] = $B809ba74bb572f83['@attributes']['tag'];
							}
							$A094eef6d6023c0b = array();

							foreach (array_slice(makeArray($ddcfd131e6154888['Video']['Director']), 0, 3) as $B809ba74bb572f83) {
								$A094eef6d6023c0b[] = $B809ba74bb572f83['@attributes']['tag'];
							}
							$ebbdeb734c887fae = array();

							foreach (array_slice(makeArray($ddcfd131e6154888['Video']['Genre']), 0, $ee462bb53fd79bcd['max_genres']) as $B8995c76454f4b98) {
								$ebbdeb734c887fae[] = $B8995c76454f4b98['@attributes']['tag'];
							}
							$De0e117a481409e2 = (makeArray($ddcfd131e6154888['Video']['Country'])[0]['@attributes']['tag'] ?: null);
							$eff3c5536b319f0b = intval(intval($ddcfd131e6154888['Video']['@attributes']['duration']) / 1000);
							$eaad9527ef2b563d['stream_display_name'] = $ddcfd131e6154888['Video']['@attributes']['title'];

							if (!$ddcfd131e6154888['Video']['@attributes']['year']) {
							} else {
								$eaad9527ef2b563d['year'] = intval($ddcfd131e6154888['Video']['@attributes']['year']);
							}

							$eaad9527ef2b563d['tmdb_id'] = ($Ddb572d71804d3a6 ?: null);
							$eaad9527ef2b563d['movie_properties'] = array('kinopoisk_url' => ($Ddb572d71804d3a6 ? 'https://www.themoviedb.org/movie/' . $Ddb572d71804d3a6 : null), 'tmdb_id' => $Ddb572d71804d3a6, 'plex_id' => $ee462bb53fd79bcd['key'], 'name' => $ddcfd131e6154888['Video']['@attributes']['title'], 'o_name' => $ddcfd131e6154888['Video']['@attributes']['title'], 'cover_big' => $A646087ab5268867, 'movie_image' => $A646087ab5268867, 'release_date' => $ddcfd131e6154888['Video']['@attributes']['originallyAvailableAt'], 'episode_run_time' => intval($eff3c5536b319f0b / 60), 'youtube_trailer' => null, 'director' => implode(', ', $A094eef6d6023c0b), 'actors' => implode(', ', $cc6fe5bce59818ef), 'cast' => implode(', ', $cc6fe5bce59818ef), 'description' => trim($ddcfd131e6154888['Video']['@attributes']['summary']), 'plot' => $ddcfd131e6154888['Video']['@attributes']['summary'], 'age' => '', 'mpaa_rating' => '', 'rating_count_kinopoisk' => 0, 'country' => $De0e117a481409e2, 'genre' => implode(', ', $ebbdeb734c887fae), 'backdrop_path' => array($f86e3ca402767b9e), 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => (floatval($ddcfd131e6154888['Video']['@attributes']['rating']) ?: floatval($ddcfd131e6154888['Video']['@attributes']['audienceRating'])));
							$eaad9527ef2b563d['rating'] = ((floatval($ddcfd131e6154888['Video']['@attributes']['rating']) ?: floatval($ddcfd131e6154888['Video']['@attributes']['audienceRating'])) ?: 0);
							$eaad9527ef2b563d['read_native'] = $ee462bb53fd79bcd['read_native'];
							$eaad9527ef2b563d['movie_symlink'] = $ee462bb53fd79bcd['movie_symlink'];
							$eaad9527ef2b563d['remove_subtitles'] = $ee462bb53fd79bcd['remove_subtitles'];
							$eaad9527ef2b563d['transcode_profile_id'] = $ee462bb53fd79bcd['transcode_profile_id'];

							if ($ee462bb53fd79bcd['direct_proxy']) {
								$eaad9527ef2b563d['stream_source'] = $A752edc646ab347a;
								$eaad9527ef2b563d['direct_source'] = 1;
								$eaad9527ef2b563d['direct_proxy'] = 1;
							} else {
								$eaad9527ef2b563d['stream_source'] = $d6d8af96b3cd2801;
								$eaad9527ef2b563d['direct_source'] = 0;
								$eaad9527ef2b563d['direct_proxy'] = 0;
							}

							$eaad9527ef2b563d['order'] = dc95637c2da3b543();
							$eaad9527ef2b563d['tmdb_language'] = $rLanguage;

							if (count($A38b42a281e3c3cf) != 0) {
							} else {
								if (0 < $ee462bb53fd79bcd['max_genres']) {
									$Dfb47c4f9d8dd258 = array_slice(makeArray($ddcfd131e6154888['Video']['Genre']), 0, $ee462bb53fd79bcd['max_genres']);
								} else {
									$Dfb47c4f9d8dd258 = makeArray($ddcfd131e6154888['Video']['Genre']);
								}

								foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
									$cd370c6d8be0d5b1 = $B8995c76454f4b98['@attributes']['tag'];

									if (isset($a2d24fc8115839d0[3][$cd370c6d8be0d5b1])) {
										$Be965cdd996d4520 = intval($a2d24fc8115839d0[3][$cd370c6d8be0d5b1]['category_id']);

										if (0 >= $Be965cdd996d4520) {
										} else {
											if (in_array($Be965cdd996d4520, $A38b42a281e3c3cf)) {
											} else {
												$A38b42a281e3c3cf[] = $Be965cdd996d4520;
											}
										}
									} else {
										if (!$ee462bb53fd79bcd['store_categories']) {
										} else {
											addCategory($ee462bb53fd79bcd['type'], $cd370c6d8be0d5b1);
										}
									}
								}
							}

							if (!(count($A38b42a281e3c3cf) == 0 && 0 < intval($ee462bb53fd79bcd['fb_category_id']))) {
							} else {
								$A38b42a281e3c3cf = array(intval($ee462bb53fd79bcd['fb_category_id']));
							}

							if (count($Adf384de46aa6175) != 0) {
							} else {
								if (0 < $ee462bb53fd79bcd['max_genres']) {
									$Dfb47c4f9d8dd258 = array_slice(makeArray($ddcfd131e6154888['Video']['Genre']), 0, $ee462bb53fd79bcd['max_genres']);
								} else {
									$Dfb47c4f9d8dd258 = makeArray($ddcfd131e6154888['Video']['Genre']);
								}

								foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
									$cd370c6d8be0d5b1 = $B8995c76454f4b98['@attributes']['tag'];
									$cb498e4dcaac05cc = json_decode($a2d24fc8115839d0[3][$cd370c6d8be0d5b1]['bouquets'], true);

									foreach ($cb498e4dcaac05cc as $C52c0b6b0f74407b) {
										if (in_array($C52c0b6b0f74407b, $Adf384de46aa6175)) {
										} else {
											$Adf384de46aa6175[] = $C52c0b6b0f74407b;
										}
									}
								}
							}

							if (count($Adf384de46aa6175) != 0) {
							} else {
								$Adf384de46aa6175 = array_map('intval', json_decode($ee462bb53fd79bcd['fb_bouquets'], true));
							}

							if (!$A02729c83b6cd395) {
							} else {
								$eaad9527ef2b563d['year'] = $A02729c83b6cd395;
							}

							$eaad9527ef2b563d['added'] = time();
							$eaad9527ef2b563d['plex_uuid'] = $ee462bb53fd79bcd['uuid'];
							$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', $A38b42a281e3c3cf)) . ']';

							if ($Cd402430ba113e2c = getMovie($ee462bb53fd79bcd['uuid'], ($ee462bb53fd79bcd['check_tmdb'] ? $Ddb572d71804d3a6 : null))) {
								if ($Cd402430ba113e2c['source'] != $F232366fdfb8ffd3['file']) {
									if ($ee462bb53fd79bcd['auto_upgrade']) {
										echo 'Upgrade movie!' . "\n";
										$eaad9527ef2b563d['id'] = $Cd402430ba113e2c['id'];
									} else {
										echo 'Upgrade disabled' . "\n";

										exit();
									}
								} else {
									echo 'File remains unchanged' . "\n";

									exit();
								}
							} else {
								if (count($A38b42a281e3c3cf) != 0) {
								} else {
									$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 3, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']));

									exit();
								}
							}

							$acd0eb2c8a975903 = f4817dc607d9981d($eaad9527ef2b563d);
							$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

							if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
								$Fc2dc5a0ce8d07ea = $Fee0d5a474c96306->last_insert_id();

								if ($Cd402430ba113e2c) {
									foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
										$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL, `current_source` = NULL, `to_analyze` = 0, `pid` = NULL, `stream_started` = NULL, `stream_info` = NULL, `compatible` = 0, `video_codec` = NULL, `audio_codec` = NULL, `resolution` = NULL, `stream_status` = 0 WHERE `stream_id` = ? AND `server_id` = ?', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
									}
									$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 6, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']));

									if (!$ee462bb53fd79bcd['auto_encode']) {
									} else {
										foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
											XUI::queueMovie($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
										}
									}

									echo 'Success!' . "\n";
								} else {
									foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
										$Fee0d5a474c96306->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`) VALUES(?, ?, NULL);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
									}

									foreach ($Adf384de46aa6175 as $ddf0508b312dbfb8) {
										d7e7f81f646193b2('movie', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
									}
									$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 1, ?);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']), $Fc2dc5a0ce8d07ea);

									exit();
								}
							} else {
								echo 'Insert failed!' . "\n";
								$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 2, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']));

								exit();
							}
						}

						break;
					}

					if ($A3b0fac4071c183f) {
						$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 5, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($A3b0fac4071c183f));

						exit();
					}

					exit();
				} else {
					exit('Failed to get information.' . "\n");
				}

				// no break
			case 'show':
				$C700a2b357e5ed65 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/library/metadata/' . $ee462bb53fd79bcd['key'] . '?X-Plex-Token=' . $ee462bb53fd79bcd['token'];
				$ddcfd131e6154888 = json_decode(json_encode(simplexml_load_string(readURL($C700a2b357e5ed65))), true);

				if ($ddcfd131e6154888) {
					list($B7b7b2d9498c93ec) = makeArray($ddcfd131e6154888['Directory']);
					$Ddb572d71804d3a6 = null;

					if (substr($B7b7b2d9498c93ec['@attributes']['guid'], 0, 32) != 'com.plexapp.agents.themoviedb://') {
					} else {
						list(, $B211d7401e6242f3) = explode('com.plexapp.agents.themoviedb://', $B7b7b2d9498c93ec['@attributes']['guid']);
						$Ddb572d71804d3a6 = intval(explode('?lang=', $B211d7401e6242f3)[0]);
						$rLanguage = (explode('?lang=', $B211d7401e6242f3)[1] ?: null);
						echo 'TMDB ID: ' . $Ddb572d71804d3a6 . "\n";
					}

					if ($Ddb572d71804d3a6) {
					} else {
						foreach ($B7b7b2d9498c93ec['Guid'] as $f358103af14f99c7) {
							if (substr($f358103af14f99c7['@attributes']['id'], 0, 7) != 'tmdb://') {
							} else {
								$Ddb572d71804d3a6 = substr($f358103af14f99c7['@attributes']['id'], 7, strlen($f358103af14f99c7['@attributes']['id']) - 7);
								$rLanguage = (explode('?lang=', $B211d7401e6242f3)[1] ?: null);
								echo 'TMDB ID: ' . $Ddb572d71804d3a6 . "\n";

								break;
							}
						}
					}

					$d551415ef385a1e7 = $f3f708a8ce235bed = array();
					$C700a2b357e5ed65 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/library/metadata/' . $ee462bb53fd79bcd['key'] . '/children?X-Plex-Token=' . $ee462bb53fd79bcd['token'];
					$Dac6e8d3df73a8d8 = makeArray(json_decode(json_encode(simplexml_load_string(readURL($C700a2b357e5ed65))), true)['Directory']);
					$C700a2b357e5ed65 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/library/metadata/' . $ee462bb53fd79bcd['key'] . '/allLeaves?X-Plex-Token=' . $ee462bb53fd79bcd['token'];
					$b1fa0ad0bb84d114 = makeArray(json_decode(json_encode(simplexml_load_string(readURL($C700a2b357e5ed65))), true)['Video']);

					foreach ($b1fa0ad0bb84d114 as $Bd43537fab08ca31) {
						if (in_array($Bd43537fab08ca31['@attributes']['parentIndex'], array_keys($d551415ef385a1e7))) {
						} else {
							$d551415ef385a1e7[$Bd43537fab08ca31['@attributes']['parentIndex']] = $Bd43537fab08ca31['@attributes']['originallyAvailableAt'];
						}
					}

					foreach ($Dac6e8d3df73a8d8 as $b550d8eef0f542ec) {
						if (!$b550d8eef0f542ec['@attributes']['index']) {
						} else {
							$A2de43d7111ec290 = null;

							if (!$b550d8eef0f542ec['@attributes']['thumb']) {
							} else {
								$d7e02302834c503e = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=300&height=450&minSize=1&quality=100&upscale=1&url=' . $b550d8eef0f542ec['@attributes']['thumb'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
								$A2de43d7111ec290 = XUI::b2068cE8B339BF70($d7e02302834c503e);
							}

							$f3f708a8ce235bed[] = array('name' => $b550d8eef0f542ec['@attributes']['title'], 'air_date' => ($d551415ef385a1e7[$b550d8eef0f542ec['@attributes']['index']] ?: ''), 'overview' => (trim($B7b7b2d9498c93ec['@attributes']['summary']) ?: ''), 'cover_big' => $A2de43d7111ec290, 'cover' => $A2de43d7111ec290, 'episode_count' => $b550d8eef0f542ec['@attributes']['leafCount'], 'season_number' => $b550d8eef0f542ec['@attributes']['index'], 'id' => $b550d8eef0f542ec['@attributes']['ratingKey']);
						}
					}
					$bbc84f53c534450d = getseriesbyid($ee462bb53fd79bcd['uuid'], $Ddb572d71804d3a6);

					if (!$bbc84f53c534450d) {
						$cf3c8094e0d98a73 = array('title' => $B7b7b2d9498c93ec['@attributes']['title'], 'category_id' => array(), 'episode_run_time' => (intval($B7b7b2d9498c93ec['@attributes']['duration'] / 1000 / 60) ?: 0), 'tmdb_id' => $Ddb572d71804d3a6, 'cover' => '', 'genre' => '', 'plot' => trim($B7b7b2d9498c93ec['@attributes']['summary']), 'cast' => '', 'rating' => ((floatval($B7b7b2d9498c93ec['@attributes']['rating']) ?: floatval($B7b7b2d9498c93ec['@attributes']['audienceRating'])) ?: 0), 'director' => '', 'release_date' => $B7b7b2d9498c93ec['@attributes']['originallyAvailableAt'], 'last_modified' => time(), 'seasons' => $f3f708a8ce235bed, 'backdrop_path' => array(), 'youtube_trailer' => '', 'year' => null);

						if (!$cf3c8094e0d98a73['release_date']) {
						} else {
							$cf3c8094e0d98a73['year'] = intval(substr($cf3c8094e0d98a73['release_date'], 0, 4));
						}

						if (!$B7b7b2d9498c93ec['@attributes']['thumb']) {
						} else {
							$d7e02302834c503e = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=300&height=450&minSize=1&quality=100&upscale=1&url=' . $B7b7b2d9498c93ec['@attributes']['thumb'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
							$A646087ab5268867 = XUI::b2068cE8B339bF70($d7e02302834c503e);
						}

						if (!$B7b7b2d9498c93ec['@attributes']['art']) {
						} else {
							$B1fdf64ecfc30f68 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=1280&height=720&minSize=1&quality=100&upscale=1&url=' . $B7b7b2d9498c93ec['@attributes']['art'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
							$f86e3ca402767b9e = XUI::b2068cE8b339bF70($B1fdf64ecfc30f68);
						}

						$cf3c8094e0d98a73['cover'] = $A646087ab5268867;
						$cf3c8094e0d98a73['cover_big'] = $A646087ab5268867;

						if ($f86e3ca402767b9e) {
							$cf3c8094e0d98a73['backdrop_path'] = array($f86e3ca402767b9e);
						} else {
							$cf3c8094e0d98a73['backdrop_path'] = array();
						}

						$cc6fe5bce59818ef = array();

						foreach (array_slice(makeArray($B7b7b2d9498c93ec['Role']), 0, 5) as $B809ba74bb572f83) {
							$cc6fe5bce59818ef[] = $B809ba74bb572f83['@attributes']['tag'];
						}
						$cf3c8094e0d98a73['cast'] = implode(', ', $cc6fe5bce59818ef);
						$A094eef6d6023c0b = array();

						foreach (array_slice(makeArray($B7b7b2d9498c93ec['Director']), 0, 3) as $B809ba74bb572f83) {
							$A094eef6d6023c0b[] = $B809ba74bb572f83['@attributes']['tag'];
						}
						$cf3c8094e0d98a73['director'] = implode(', ', $A094eef6d6023c0b);
						$ebbdeb734c887fae = array();

						foreach (array_slice(makeArray($B7b7b2d9498c93ec['Genre']), 0, 3) as $B8995c76454f4b98) {
							$ebbdeb734c887fae[] = $B8995c76454f4b98['@attributes']['tag'];
						}
						$cf3c8094e0d98a73['genre'] = implode(', ', $ebbdeb734c887fae);

						if (count($A38b42a281e3c3cf) != 0) {
						} else {
							if (0 < $ee462bb53fd79bcd['max_genres']) {
								$Dfb47c4f9d8dd258 = array_slice(makeArray($B7b7b2d9498c93ec['Genre']), 0, $ee462bb53fd79bcd['max_genres']);
							} else {
								$Dfb47c4f9d8dd258 = makeArray($B7b7b2d9498c93ec['Genre']);
							}

							foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
								$cd370c6d8be0d5b1 = $B8995c76454f4b98['@attributes']['tag'];

								if (isset($a2d24fc8115839d0[3][$cd370c6d8be0d5b1])) {
									$Be965cdd996d4520 = intval($a2d24fc8115839d0[4][$cd370c6d8be0d5b1]['category_id']);

									if (0 >= $Be965cdd996d4520) {
									} else {
										if (in_array($Be965cdd996d4520, $A38b42a281e3c3cf)) {
										} else {
											$A38b42a281e3c3cf[] = $Be965cdd996d4520;
										}
									}
								} else {
									if (!$ee462bb53fd79bcd['store_categories']) {
									} else {
										addCategory($ee462bb53fd79bcd['type'], $cd370c6d8be0d5b1);
									}
								}
							}
						}

						if (!(count($A38b42a281e3c3cf) == 0 && 0 < intval($ee462bb53fd79bcd['fb_category_id']))) {
						} else {
							$A38b42a281e3c3cf = array(intval($ee462bb53fd79bcd['fb_category_id']));
						}

						if (count($Adf384de46aa6175) != 0) {
						} else {
							if (0 < $ee462bb53fd79bcd['max_genres']) {
								$Dfb47c4f9d8dd258 = array_slice(makeArray($B7b7b2d9498c93ec['Genre']), 0, $ee462bb53fd79bcd['max_genres']);
							} else {
								$Dfb47c4f9d8dd258 = makeArray($B7b7b2d9498c93ec['Genre']);
							}

							foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
								$cd370c6d8be0d5b1 = $B8995c76454f4b98['@attributes']['tag'];
								$cb498e4dcaac05cc = json_decode($a2d24fc8115839d0[4][$cd370c6d8be0d5b1]['bouquets'], true);

								foreach ($cb498e4dcaac05cc as $C52c0b6b0f74407b) {
									if (in_array($C52c0b6b0f74407b, $Adf384de46aa6175)) {
									} else {
										$Adf384de46aa6175[] = $C52c0b6b0f74407b;
									}
								}
							}
						}

						if (count($Adf384de46aa6175) != 0) {
						} else {
							$Adf384de46aa6175 = array_map('intval', json_decode($ee462bb53fd79bcd['fb_bouquets'], true));
						}

						if (count($A38b42a281e3c3cf) != 0) {
							$cf3c8094e0d98a73['plex_uuid'] = $ee462bb53fd79bcd['uuid'];
							$cf3c8094e0d98a73['tmdb_language'] = $rLanguage;
							$cf3c8094e0d98a73['category_id'] = '[' . implode(',', array_map('intval', $A38b42a281e3c3cf)) . ']';
							$acd0eb2c8a975903 = f4817dc607d9981d($cf3c8094e0d98a73);
							$A6d7047f2fda966c = 'INSERT INTO `streams_series`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

							if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
								$Fc2dc5a0ce8d07ea = $Fee0d5a474c96306->last_insert_id();
								$bbc84f53c534450d = ffd24e407abb46eb($Fc2dc5a0ce8d07ea);

								foreach ($Adf384de46aa6175 as $ddf0508b312dbfb8) {
									d7e7f81f646193b2('series', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
								}
							} else {
								$bbc84f53c534450d = null;
							}
						} else {
							$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 3, 0);', $A0fa741c62cbe676, SERVER_ID, 'Plex Series: ' . utf8_decode($cf3c8094e0d98a73['title']));

							exit();
						}
					} else {
						$Fee0d5a474c96306->query('UPDATE `streams_series` SET `seasons` = ? WHERE `id` = ?;', json_encode($f3f708a8ce235bed, JSON_UNESCAPED_UNICODE), $bbc84f53c534450d['id']);

						if ($bbc84f53c534450d['cover']) {
						} else {
							if (!$B7b7b2d9498c93ec['@attributes']['thumb']) {
							} else {
								$d7e02302834c503e = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=300&height=450&minSize=1&quality=100&upscale=1&url=' . $B7b7b2d9498c93ec['@attributes']['thumb'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
								$A646087ab5268867 = XUI::B2068ce8B339bF70($d7e02302834c503e);
							}

							if (!$B7b7b2d9498c93ec['@attributes']['art']) {
							} else {
								$B1fdf64ecfc30f68 = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=1280&height=720&minSize=1&quality=100&upscale=1&url=' . $B7b7b2d9498c93ec['@attributes']['art'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
								$f86e3ca402767b9e = XUI::b2068cE8b339bF70($B1fdf64ecfc30f68);
							}

							if (!($A646087ab5268867 || $f86e3ca402767b9e)) {
							} else {
								if ($f86e3ca402767b9e) {
									$f86e3ca402767b9e = array($f86e3ca402767b9e);
								} else {
									$f86e3ca402767b9e = array();
								}

								$Fee0d5a474c96306->query('UPDATE `streams_series` SET `cover` = ?, `cover_big` = ?, `backdrop_path` = ? WHERE `id` = ?;', $A646087ab5268867, $A646087ab5268867, $f86e3ca402767b9e, $bbc84f53c534450d['id']);
							}
						}
					}

					foreach ($b1fa0ad0bb84d114 as $Bd43537fab08ca31) {
						if (!($Bd43537fab08ca31['@attributes']['parentIndex'] && $Bd43537fab08ca31['@attributes']['index'])) {
						} else {
							$A3b0fac4071c183f = null;
							$d92a501f0ef30373 = $Bd43537fab08ca31['@attributes']['parentIndex'];
							$f126437af6a11597 = $Bd43537fab08ca31['@attributes']['index'];
							$F232366fdfb8ffd3 = array('file' => null, 'size' => null, 'data' => null, 'key' => null);

							foreach (makeArray($Bd43537fab08ca31['Media']) as $Da7bcda6c519bab3) {
								if ($A3b0fac4071c183f) {
								} else {
									$A3b0fac4071c183f = $Da7bcda6c519bab3['Part']['@attributes']['file'];
								}

								if ($F232366fdfb8ffd3['size'] && $F232366fdfb8ffd3['size'] >= intval($Da7bcda6c519bab3['Part']['@attributes']['size'])) {
								} else {
									if (!(file_exists($Da7bcda6c519bab3['Part']['@attributes']['file']) || $ee462bb53fd79bcd['direct_proxy'])) {
									} else {
										$F232366fdfb8ffd3 = array('file' => $Da7bcda6c519bab3['Part']['@attributes']['file'], 'size' => intval($Da7bcda6c519bab3['Part']['@attributes']['size']), 'data' => $Da7bcda6c519bab3, 'key' => $Da7bcda6c519bab3['Part']['@attributes']['key']);
									}
								}
							}

							if (!empty($F232366fdfb8ffd3['file'])) {
								$d6d8af96b3cd2801 = json_encode(array('s:' . SERVER_ID . ':' . $F232366fdfb8ffd3['file']), JSON_UNESCAPED_UNICODE);
								$A752edc646ab347a = json_encode(array('http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . $F232366fdfb8ffd3['key'] . '?X-Plex-Token=' . $ee462bb53fd79bcd['token']), JSON_UNESCAPED_UNICODE);

								if (!in_array($d6d8af96b3cd2801, $D2165010a62b36e4) && !in_array($A752edc646ab347a, $D2165010a62b36e4)) {
									$D2165010a62b36e4[] = $d6d8af96b3cd2801;
									$D2165010a62b36e4[] = $A752edc646ab347a;

									if ($ee462bb53fd79bcd['target_container'] != 'auto' && $ee462bb53fd79bcd['target_container'] && !$ee462bb53fd79bcd['direct_proxy']) {
										$eaad9527ef2b563d['target_container'] = $ee462bb53fd79bcd['target_container'];
									} else {
										$eaad9527ef2b563d['target_container'] = pathinfo($F232366fdfb8ffd3['file'])['extension'];
									}

									if (!empty($eaad9527ef2b563d['target_container'])) {
									} else {
										$eaad9527ef2b563d['target_container'] = 'mp4';
									}

									if (!($Cd402430ba113e2c = getEpisode($ee462bb53fd79bcd['uuid'], ($ee462bb53fd79bcd['check_tmdb'] ? $Ddb572d71804d3a6 : null), $d92a501f0ef30373, $f126437af6a11597))) {
										$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `filename` = ? AND `type` = ? AND `server_id` = ?;', utf8_decode($F232366fdfb8ffd3['file']), $A0fa741c62cbe676, SERVER_ID);
										$A646087ab5268867 = null;

										if (!$Bd43537fab08ca31['@attributes']['thumb']) {
										} else {
											$d7e02302834c503e = 'http://' . $ee462bb53fd79bcd['ip'] . ':' . $ee462bb53fd79bcd['port'] . '/photo/:/transcode?width=450&height=253&minSize=1&quality=100&upscale=1&url=' . $Bd43537fab08ca31['@attributes']['thumb'] . '&X-Plex-Token=' . $ee462bb53fd79bcd['token'];
											$A646087ab5268867 = XUI::b2068cE8b339bF70($d7e02302834c503e);
										}

										$eff3c5536b319f0b = intval($Bd43537fab08ca31['@attributes']['duration'] / 1000);
										$eaad9527ef2b563d['movie_properties'] = array('tmdb_id' => ($bbc84f53c534450d['tmdb_id'] ?: null), 'release_date' => $Bd43537fab08ca31['@attributes']['originallyAvailableAt'], 'plot' => $Bd43537fab08ca31['@attributes']['summary'], 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'movie_image' => $A646087ab5268867, 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => ((floatval($Bd43537fab08ca31['@attributes']['rating']) ?: floatval($Bd43537fab08ca31['@attributes']['audienceRating'])) ?: $bbc84f53c534450d['rating']), 'season' => $d92a501f0ef30373);
										$eaad9527ef2b563d['stream_display_name'] = $bbc84f53c534450d['title'] . ' - S' . sprintf('%02d', intval($d92a501f0ef30373)) . 'E' . sprintf('%02d', $f126437af6a11597) . ' - ' . $Bd43537fab08ca31['@attributes']['title'];
										$eaad9527ef2b563d['read_native'] = $ee462bb53fd79bcd['read_native'];
										$eaad9527ef2b563d['movie_symlink'] = $ee462bb53fd79bcd['movie_symlink'];
										$eaad9527ef2b563d['remove_subtitles'] = $ee462bb53fd79bcd['remove_subtitles'];
										$eaad9527ef2b563d['transcode_profile_id'] = $ee462bb53fd79bcd['transcode_profile_id'];

										if ($ee462bb53fd79bcd['direct_proxy']) {
											$eaad9527ef2b563d['stream_source'] = $A752edc646ab347a;
											$eaad9527ef2b563d['direct_source'] = 1;
											$eaad9527ef2b563d['direct_proxy'] = 1;
										} else {
											$eaad9527ef2b563d['stream_source'] = $d6d8af96b3cd2801;
											$eaad9527ef2b563d['direct_source'] = 0;
											$eaad9527ef2b563d['direct_proxy'] = 0;
										}

										$eaad9527ef2b563d['order'] = dc95637c2da3b543();
										$eaad9527ef2b563d['tmdb_language'] = $rLanguage;
										$eaad9527ef2b563d['added'] = time();
										$eaad9527ef2b563d['uuid'] = $ee462bb53fd79bcd['uuid'];
										$eaad9527ef2b563d['series_no'] = $bbc84f53c534450d['id'];
										$acd0eb2c8a975903 = f4817dc607d9981d($eaad9527ef2b563d);
										$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

										if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
											$Fc2dc5a0ce8d07ea = $Fee0d5a474c96306->last_insert_id();

											foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
												$Fee0d5a474c96306->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`) VALUES(?, ?, NULL);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
											}
											$Fee0d5a474c96306->query('INSERT INTO `streams_episodes`(`season_num`, `series_id`, `stream_id`, `episode_num`) VALUES(?, ?, ?, ?);', $d92a501f0ef30373, $bbc84f53c534450d['id'], $Fc2dc5a0ce8d07ea, $f126437af6a11597);

											if (!$ee462bb53fd79bcd['auto_encode']) {
											} else {
												foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
													XUI::queueMovie($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
												}
											}

											$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 1, ?);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']), $Fc2dc5a0ce8d07ea);
										} else {
											echo 'Insert failed!' . "\n";
											$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 2, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']));
										}
									} else {
										if ($Cd402430ba113e2c['source'] != $F232366fdfb8ffd3['file']) {
											if ($ee462bb53fd79bcd['auto_upgrade']) {
												echo 'Upgrade episode!' . "\n";
												$Fee0d5a474c96306->query('UPDATE `streams` SET `plex_uuid` = ?, `stream_source` = ?, `target_container` = ? WHERE `id` = ?;', $ee462bb53fd79bcd['uuid'], $eaad9527ef2b563d['stream_source'], $eaad9527ef2b563d['target_container'], $Cd402430ba113e2c['id']);

												foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
													$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL, `current_source` = NULL, `to_analyze` = 0, `pid` = NULL, `stream_started` = NULL, `stream_info` = NULL, `compatible` = 0, `video_codec` = NULL, `audio_codec` = NULL, `resolution` = NULL, `stream_status` = 0 WHERE `stream_id` = ? AND `server_id` = ?', $Cd402430ba113e2c['id'], $d58b4f8653a391d8);
												}

												if (!$ee462bb53fd79bcd['auto_encode']) {
												} else {
													foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
														XUI::queueMovie($Cd402430ba113e2c['id'], $d58b4f8653a391d8);
													}
												}

												$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 6, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($F232366fdfb8ffd3['file']));
											} else {
												echo 'Upgrade disabled' . "\n";
											}
										} else {
											echo 'File remains unchanged' . "\n";
										}
									}
								} else {
									echo 'Already exists!' . "\n";
								}
							} else {
								if ($A3b0fac4071c183f) {
									$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 5, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($A3b0fac4071c183f));
								} else {
									exit();
								}
							}
						}
					}

					break;
				} else {
					exit('Failed to get information.' . "\n");
				}
		}
	} else {
		exit();
	}
}

function getMovie($C167873ff203aefe, $Ddb572d71804d3a6)
{
	if (file_exists(WATCH_TMP_PATH . 'movie_' . $C167873ff203aefe . '.pcache')) {
		return json_decode(file_get_contents(WATCH_TMP_PATH . 'movie_' . $C167873ff203aefe . '.pcache'), true);
	}

	if (!file_exists(WATCH_TMP_PATH . 'movie_' . $Ddb572d71804d3a6 . '.pcache')) {
	} else {
		return json_decode(file_get_contents(WATCH_TMP_PATH . 'movie_' . $Ddb572d71804d3a6 . '.pcache'), true);
	}
}

function getEpisode($C167873ff203aefe, $Ddb572d71804d3a6, $b550d8eef0f542ec, $Bd43537fab08ca31)
{
	if (!file_exists(WATCH_TMP_PATH . 'series_' . $C167873ff203aefe . '.pcache')) {
	} else {
		$a27e64cc6ce01033 = json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . $C167873ff203aefe . '.pcache'), true);

		if (!isset($a27e64cc6ce01033[$b550d8eef0f542ec . '_' . $Bd43537fab08ca31])) {
		} else {
			return $a27e64cc6ce01033[$b550d8eef0f542ec . '_' . $Bd43537fab08ca31];
		}
	}

	if (!file_exists(WATCH_TMP_PATH . 'series_' . $Ddb572d71804d3a6 . '.pcache')) {
	} else {
		$a27e64cc6ce01033 = json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . $Ddb572d71804d3a6 . '.pcache'), true);

		if (!isset($a27e64cc6ce01033[$b550d8eef0f542ec . '_' . $Bd43537fab08ca31])) {
		} else {
			return $a27e64cc6ce01033[$b550d8eef0f542ec . '_' . $Bd43537fab08ca31];
		}
	}
}

function addCategory($E379394c7b1a273f, $cd370c6d8be0d5b1)
{
	file_put_contents(WATCH_TMP_PATH . md5($E379394c7b1a273f . '_' . $cd370c6d8be0d5b1) . '.pcat', json_encode(array('type' => $E379394c7b1a273f, 'title' => $cd370c6d8be0d5b1)));
}

function readURL($C700a2b357e5ed65)
{
	$a0eb8eb80ccd233b = curl_init($C700a2b357e5ed65);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_CONNECTTIMEOUT, 10);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_TIMEOUT, 10);

	return curl_exec($a0eb8eb80ccd233b);
}

function makeArray($d49041d5f05a9270)
{
	if (!isset($d49041d5f05a9270['@attributes'])) {
	} else {
		$d49041d5f05a9270 = array($d49041d5f05a9270);
	}

	return $d49041d5f05a9270;
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}

	@unlink(WATCH_TMP_PATH . @getmypid() . '.ppid');
}
