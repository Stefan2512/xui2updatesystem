<?php

setlocale(LC_ALL, 'en_US.UTF-8');
putenv('LC_ALL=en_US.UTF-8');

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		$cd2a4260ef308305 = 60;
		set_time_limit($cd2a4260ef308305);
		ini_set('max_execution_time', $cd2a4260ef308305);
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		require INCLUDES_PATH . 'libs/tmdb.php';
		require INCLUDES_PATH . 'libs/tmdb_release.php';
		$ee462bb53fd79bcd = json_decode(base64_decode($argv[1]), true);

		if ($ee462bb53fd79bcd) {
			file_put_contents(WATCH_TMP_PATH . getmypid() . '.wpid', time());
			fdc97512d22b990e();
		} else {
			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function FdC97512D22b990e()
{
	global $Fee0d5a474c96306;
	global $ee462bb53fd79bcd;
	global $cd2a4260ef308305;

	if (strpos($ee462bb53fd79bcd['file'], $ee462bb53fd79bcd['directory']) === 0 || $ee462bb53fd79bcd['import']) {
		$d1ea20cf43346712 = $ee462bb53fd79bcd['watch_categories'];
		$rLanguage = null;

		if (!empty($ee462bb53fd79bcd['language'])) {
			$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], $ee462bb53fd79bcd['language']);
			$rLanguage = $ee462bb53fd79bcd['language'];
		} else {
			if (!empty(XUI::$rSettings['tmdb_language'])) {
				$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
			} else {
				$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
			}
		}

		if ($ee462bb53fd79bcd['type'] == 'movie') {
		} else {
			$ee462bb53fd79bcd['extract_metadata'] = false;
		}

		$eaad9527ef2b563d = b9da5d708fc1c079('streams');
		$eaad9527ef2b563d['type'] = array('movie' => 2, 'series' => 5)[$ee462bb53fd79bcd['type']];

		if ($eaad9527ef2b563d['type']) {
			$A0fa741c62cbe676 = array('movie' => 1, 'series' => 2)[$ee462bb53fd79bcd['type']];
			$e2f848a82a80c113 = $ee462bb53fd79bcd['file'];

			if ($ee462bb53fd79bcd['import']) {
				$eaad9527ef2b563d['stream_source'] = json_encode(array($e2f848a82a80c113), JSON_UNESCAPED_UNICODE);
			} else {
				$eaad9527ef2b563d['stream_source'] = json_encode(array('s:' . SERVER_ID . ':' . $e2f848a82a80c113), JSON_UNESCAPED_UNICODE);
				$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `filename` = ? AND `type` = ? AND `server_id` = ?;', utf8_decode($e2f848a82a80c113), $A0fa741c62cbe676, SERVER_ID);
			}

			if ($ee462bb53fd79bcd['target_container'] != 'auto' && $ee462bb53fd79bcd['target_container']) {
				$eaad9527ef2b563d['target_container'] = $ee462bb53fd79bcd['target_container'];
			} else {
				$eaad9527ef2b563d['target_container'] = pathinfo(explode('?', $e2f848a82a80c113)[0])['extension'];
			}

			if (!empty($eaad9527ef2b563d['target_container'])) {
			} else {
				$eaad9527ef2b563d['target_container'] = 'mp4';
			}

			$Bfabc0fbf313d5cd = null;

			if (!($ee462bb53fd79bcd['ffprobe_input'] || $ee462bb53fd79bcd['extract_metadata'])) {
			} else {
				$Bfabc0fbf313d5cd = BBdbe7aD31018a97($e2f848a82a80c113);
			}

			if (!$ee462bb53fd79bcd['ffprobe_input'] || isset($Bfabc0fbf313d5cd['streams'])) {
				$dbc0f67b4f0fdee0 = $A02729c83b6cd395 = $af11d18297b003ed = null;
				$d2adeeaeb79a76ce = false;

				if (!($ee462bb53fd79bcd['extract_metadata'] && isset($Bfabc0fbf313d5cd['format']) && $Bfabc0fbf313d5cd['tags']['title'])) {
				} else {
					$A02729c83b6cd395 = (intval(explode('-', $Bfabc0fbf313d5cd['tags']['date'])[0]) ?: null);
					$af11d18297b003ed = array($Bfabc0fbf313d5cd['tags']['title']);
					$d2adeeaeb79a76ce = true;
				}

				if ($af11d18297b003ed) {
				} else {
					if ($ee462bb53fd79bcd['fallback_title']) {
						$af11d18297b003ed = array(pathinfo($e2f848a82a80c113)['filename'], basename(pathinfo($e2f848a82a80c113)['dirname']));
					} else {
						$af11d18297b003ed = array(pathinfo($e2f848a82a80c113)['filename']);
					}

					$d2adeeaeb79a76ce = false;
				}

				foreach ($af11d18297b003ed as $bc2874292e0d9ece) {
					echo 'Scanning: ' . $bc2874292e0d9ece . "\n";
					$c608db3e24256b76 = null;
					$c5695568a203a666 = null;

					if (!$ee462bb53fd79bcd['import']) {
					} else {
						$bc2874292e0d9ece = $ee462bb53fd79bcd['title'];
					}

					if ($ee462bb53fd79bcd['fallback_parser'] && !$ee462bb53fd79bcd['disable_tmdb'] && !$d2adeeaeb79a76ce) {
						$B0ebe2a6b4aea466 = array(XUI::$rSettings['parse_type'], (XUI::$rSettings['parse_type'] == 'guessit' ? 'ptn' : 'guessit'));
					} else {
						$B0ebe2a6b4aea466 = array(XUI::$rSettings['parse_type']);
					}

					foreach ($B0ebe2a6b4aea466 as $E20b22de0d25d951) {
						if ($ee462bb53fd79bcd['disable_tmdb'] || $d2adeeaeb79a76ce) {
						} else {
							$fab84a7bc25d47ab = E6C35233AD4e96cD($bc2874292e0d9ece, $E20b22de0d25d951);
							$c608db3e24256b76 = $fab84a7bc25d47ab['title'];

							if (!isset($fab84a7bc25d47ab['excess'])) {
							} else {
								$c608db3e24256b76 = trim($c608db3e24256b76, (is_array($fab84a7bc25d47ab['excess']) ? $fab84a7bc25d47ab['excess'][0] : $fab84a7bc25d47ab['excess']));
							}

							if (isset($fab84a7bc25d47ab['group'])) {
								$c5695568a203a666 = $c608db3e24256b76 . '-' . $fab84a7bc25d47ab['group'];
							} else {
								if (!isset($fab84a7bc25d47ab['alternative_title'])) {
								} else {
									$c5695568a203a666 = $c608db3e24256b76 . ' - ' . $fab84a7bc25d47ab['alternative_title'];
								}
							}

							$A02729c83b6cd395 = (isset($fab84a7bc25d47ab['year']) ? $fab84a7bc25d47ab['year'] : null);

							if ($ee462bb53fd79bcd['type'] != 'movie') {
								$d92a501f0ef30373 = $fab84a7bc25d47ab['season'];

								if (is_array($fab84a7bc25d47ab['episode'])) {
									$f126437af6a11597 = $fab84a7bc25d47ab['episode'][0];
								} else {
									$f126437af6a11597 = $fab84a7bc25d47ab['episode'];
								}
							} else {
								if (!isset($fab84a7bc25d47ab['season'])) {
								} else {
									$c608db3e24256b76 .= $fab84a7bc25d47ab['season'];
								}
							}
						}

						if (!($ee462bb53fd79bcd['type'] == 'series' && (!$d92a501f0ef30373 || !$f126437af6a11597))) {
							if ($c608db3e24256b76) {
							} else {
								$c608db3e24256b76 = $bc2874292e0d9ece;
							}

							echo 'Title: ' . $c608db3e24256b76 . "\n";

							if ($ee462bb53fd79bcd['disable_tmdb']) {
							} else {
								$b85ce31cd1118ad2 = array();

								foreach (range(0, 1) as $B3bfa2ea28c65ab6) {
									if (!$B3bfa2ea28c65ab6) {
									} else {
										if ($A02729c83b6cd395) {
											$A02729c83b6cd395 = null;
										} else {
											break;
										}
									}

									if ($ee462bb53fd79bcd['type'] == 'movie') {
										$c15d5b523e931f51 = $a69d576081840514->searchMovie($c608db3e24256b76, $A02729c83b6cd395);
									} else {
										$c15d5b523e931f51 = $a69d576081840514->searchTVShow($c608db3e24256b76, $A02729c83b6cd395);
									}

									foreach ($c15d5b523e931f51 as $A23155eed5a46f0a) {
										similar_text(parseTitle($c608db3e24256b76), parseTitle(($A23155eed5a46f0a->get('title') ?: $A23155eed5a46f0a->get('name'))), $Ee06f57eb50b4b36);
										$C3603fef0a57efc4 = 0;

										if (!$c5695568a203a666) {
										} else {
											similar_text(parseTitle($c5695568a203a666), parseTitle(($A23155eed5a46f0a->get('title') ?: $A23155eed5a46f0a->get('name'))), $C3603fef0a57efc4);
										}

										if (XUI::$rSettings['percentage_match'] <= $Ee06f57eb50b4b36 || XUI::$rSettings['percentage_match'] <= $C3603fef0a57efc4) {
											if ($A02729c83b6cd395 && !in_array(intval(substr(($A23155eed5a46f0a->get('release_date') ?: $A23155eed5a46f0a->get('first_air_date')), 0, 4)), range(intval($A02729c83b6cd395) - 1, intval($A02729c83b6cd395) + 1))) {
											} else {
												if ($c5695568a203a666 && parseTitle(($A23155eed5a46f0a->get('title') ?: $A23155eed5a46f0a->get('name'))) == parseTitle($c5695568a203a666)) {
													$b85ce31cd1118ad2 = array(array('percentage' => 100, 'data' => $A23155eed5a46f0a));

													break;
												}

												if (parseTitle(($A23155eed5a46f0a->get('title') ?: $A23155eed5a46f0a->get('name'))) == parseTitle($c608db3e24256b76) && !$c5695568a203a666) {
													$b85ce31cd1118ad2 = array(array('percentage' => 100, 'data' => $A23155eed5a46f0a));

													break;
												}

												$b85ce31cd1118ad2[] = array('percentage' => $Ee06f57eb50b4b36, 'data' => $A23155eed5a46f0a);
											}
										} else {
											if (!($ee462bb53fd79bcd['alternative_titles'] && in_array(intval(substr(($A23155eed5a46f0a->get('release_date') ?: $A23155eed5a46f0a->get('first_air_date')), 0, 4)), range(intval($A02729c83b6cd395) - 1, intval($A02729c83b6cd395) + 1)))) {
											} else {
												$F5774560d92d534d = false;

												if (strpos(parseTitle($c608db3e24256b76), parseTitle(($A23155eed5a46f0a->get('title') ?: $A23155eed5a46f0a->get('name')))) === 0) {
													$F5774560d92d534d = true;
												} else {
													if (!($c5695568a203a666 && strpos(parseTitle($c5695568a203a666), parseTitle(($A23155eed5a46f0a->get('title') ?: $A23155eed5a46f0a->get('name')))) === 0)) {
													} else {
														$F5774560d92d534d = true;
													}
												}

												if (!$F5774560d92d534d) {
												} else {
													if ($ee462bb53fd79bcd['type'] == 'movie') {
														$F3b5656a49a6ce3a = $a69d576081840514->getMovieTitles($A23155eed5a46f0a->get('id'))['titles'];
													} else {
														$F3b5656a49a6ce3a = $a69d576081840514->getSeriesTitles($A23155eed5a46f0a->get('id'))['titles'];
													}

													foreach ($F3b5656a49a6ce3a as $D60b6dc2b364e63a) {
														if ($c5695568a203a666 && parseTitle($D60b6dc2b364e63a['title']) == parseTitle($c5695568a203a666)) {
															$b85ce31cd1118ad2 = array(array('percentage' => 100, 'data' => $A23155eed5a46f0a));

															break;
														}

														if (parseTitle($D60b6dc2b364e63a['title']) != parseTitle($c608db3e24256b76) || $c5695568a203a666) {
														} else {
															$b85ce31cd1118ad2 = array(array('percentage' => 100, 'data' => $A23155eed5a46f0a));

															break;
														}
													}
												}
											}
										}
									}

									if (0 >= count($b85ce31cd1118ad2)) {
									} else {
										break;
									}
								}

								if (0 >= count($b85ce31cd1118ad2)) {
								} else {
									$ad13d88d0f09412f = max(array_column($b85ce31cd1118ad2, 'percentage'));
									$f16991461acd03bf = array_filter(array_map(function($b85ce31cd1118ad2) use ($ad13d88d0f09412f) {
										return ($b85ce31cd1118ad2['percentage'] == $ad13d88d0f09412f ? $b85ce31cd1118ad2['data'] : null);
									}, $b85ce31cd1118ad2));
									list($dbc0f67b4f0fdee0) = array_values($f16991461acd03bf);
								}
							}

							if (!$dbc0f67b4f0fdee0) {
							} else {
								break;
							}
						} else {
							$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 4, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

							exit();
						}
					}
				}

				if ($dbc0f67b4f0fdee0 || $ee462bb53fd79bcd['ignore_no_match']) {
					$Adf384de46aa6175 = array();
					$A38b42a281e3c3cf = array();

					if (empty($ee462bb53fd79bcd['category_id'])) {
					} else {
						if (is_array($ee462bb53fd79bcd['category_id'])) {
							$A38b42a281e3c3cf = array_map('intval', $ee462bb53fd79bcd['category_id']);
						} else {
							$A38b42a281e3c3cf = array(intval($ee462bb53fd79bcd['category_id']));
						}
					}

					if (empty($ee462bb53fd79bcd['bouquets'])) {
					} else {
						if (is_array($ee462bb53fd79bcd['bouquets'])) {
							$Adf384de46aa6175 = array_map('intval', $ee462bb53fd79bcd['bouquets']);
						} else {
							$Adf384de46aa6175 = json_decode($ee462bb53fd79bcd['bouquets'], true);
						}
					}

					if ($dbc0f67b4f0fdee0) {
						if ($ee462bb53fd79bcd['type'] == 'movie') {
							if ($ee462bb53fd79bcd['duplicate_tmdb']) {
								$Cd402430ba113e2c = null;
							} else {
								$Cd402430ba113e2c = getMovie($dbc0f67b4f0fdee0->get('id'));
							}

							if ($Cd402430ba113e2c) {
								if ($ee462bb53fd79bcd['auto_upgrade']) {
									if (substr($Cd402430ba113e2c['source'], 0, 3 + strlen(strval(SERVER_ID))) != 's:' . SERVER_ID . ':') {
										echo "Old file path doesn't match this server, don't upgrade." . "\n";

										exit();
									}

									list(, $F801b576294fd6f7) = explode('s:' . SERVER_ID . ':', $Cd402430ba113e2c['source']);

									if (!file_exists($F801b576294fd6f7) || filesize($F801b576294fd6f7) < filesize($e2f848a82a80c113)) {
										echo 'Upgrade movie!' . "\n";
										$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_source` = ?, `target_container` = ? WHERE `id` = ?;', $eaad9527ef2b563d['stream_source'], $eaad9527ef2b563d['target_container'], $Cd402430ba113e2c['id']);
										$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL, `current_source` = NULL, `to_analyze` = 0, `pid` = NULL, `stream_started` = NULL, `stream_info` = NULL, `compatible` = 0, `video_codec` = NULL, `audio_codec` = NULL, `resolution` = NULL, `stream_status` = 0 WHERE `stream_id` = ? AND `server_id` = ?', $Cd402430ba113e2c['id'], SERVER_ID);

										if (!$ee462bb53fd79bcd['auto_encode']) {
										} else {
											XUI::queueMovie($Cd402430ba113e2c['id']);
										}

										$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 6, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));
										file_put_contents(WATCH_TMP_PATH . 'movie_' . $dbc0f67b4f0fdee0->get('id') . '.cache', json_encode(array('id' => $Cd402430ba113e2c['id'], 'source' => 's:' . SERVER_ID . ':' . $e2f848a82a80c113)));

										exit();
									}

									echo "File isn't a better source, don't upgrade." . "\n";

									exit();
								}

								echo 'Upgrade disabled' . "\n";

								exit();
							}

							$a417725f28d75ef7 = $a69d576081840514->getMovie($dbc0f67b4f0fdee0->get('id'));
							$a2b9f17f5f896910 = json_decode($a417725f28d75ef7->getJSON(), true);
							$a2b9f17f5f896910['trailer'] = $a417725f28d75ef7->getTrailer();
							$A646087ab5268867 = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $a2b9f17f5f896910['poster_path'];
							$f86e3ca402767b9e = 'https://image.tmdb.org/t/p/w1280' . $a2b9f17f5f896910['backdrop_path'];

							if (!XUI::$rSettings['download_images']) {
							} else {
								$A646087ab5268867 = XUI::B2068CE8b339bF70($A646087ab5268867);
								$f86e3ca402767b9e = XUI::b2068CE8b339Bf70($f86e3ca402767b9e);
							}

							$cc6fe5bce59818ef = array();

							foreach ($a2b9f17f5f896910['credits']['cast'] as $B809ba74bb572f83) {
								if (count($cc6fe5bce59818ef) >= 5) {
								} else {
									$cc6fe5bce59818ef[] = $B809ba74bb572f83['name'];
								}
							}
							$A094eef6d6023c0b = array();

							foreach ($a2b9f17f5f896910['credits']['crew'] as $B809ba74bb572f83) {
								if (!(count($A094eef6d6023c0b) < 5 && ($B809ba74bb572f83['department'] == 'Directing' || $B809ba74bb572f83['known_for_department'] == 'Directing')) || in_array($B809ba74bb572f83['name'], $A094eef6d6023c0b)) {
								} else {
									$A094eef6d6023c0b[] = $B809ba74bb572f83['name'];
								}
							}
							$De0e117a481409e2 = '';

							if (!isset($a2b9f17f5f896910['production_countries'][0]['name'])) {
							} else {
								$De0e117a481409e2 = $a2b9f17f5f896910['production_countries'][0]['name'];
							}

							$ebbdeb734c887fae = array();

							foreach ($a2b9f17f5f896910['genres'] as $B8995c76454f4b98) {
								if (count($ebbdeb734c887fae) >= 3) {
								} else {
									$ebbdeb734c887fae[] = $B8995c76454f4b98['name'];
								}
							}
							$eff3c5536b319f0b = intval($a2b9f17f5f896910['runtime']) * 60;
							$eaad9527ef2b563d['stream_display_name'] = $a2b9f17f5f896910['title'];

							if (0 >= strlen($a2b9f17f5f896910['release_date'])) {
							} else {
								$eaad9527ef2b563d['year'] = intval(substr($a2b9f17f5f896910['release_date'], 0, 4));
							}

							$eaad9527ef2b563d['tmdb_id'] = ($a2b9f17f5f896910['id'] ?: null);
							$eaad9527ef2b563d['movie_properties'] = array('kinopoisk_url' => 'https://www.themoviedb.org/movie/' . $a2b9f17f5f896910['id'], 'tmdb_id' => $a2b9f17f5f896910['id'], 'name' => $a2b9f17f5f896910['title'], 'o_name' => $a2b9f17f5f896910['original_title'], 'cover_big' => $A646087ab5268867, 'movie_image' => $A646087ab5268867, 'release_date' => $a2b9f17f5f896910['release_date'], 'episode_run_time' => $a2b9f17f5f896910['runtime'], 'youtube_trailer' => $a2b9f17f5f896910['trailer'], 'director' => implode(', ', $A094eef6d6023c0b), 'actors' => implode(', ', $cc6fe5bce59818ef), 'cast' => implode(', ', $cc6fe5bce59818ef), 'description' => $a2b9f17f5f896910['overview'], 'plot' => $a2b9f17f5f896910['overview'], 'age' => '', 'mpaa_rating' => '', 'rating_count_kinopoisk' => 0, 'country' => $De0e117a481409e2, 'genre' => implode(', ', $ebbdeb734c887fae), 'backdrop_path' => array($f86e3ca402767b9e), 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => $a2b9f17f5f896910['vote_average']);
							$eaad9527ef2b563d['rating'] = ($eaad9527ef2b563d['movie_properties']['rating'] ?: 0);
							$eaad9527ef2b563d['read_native'] = $ee462bb53fd79bcd['read_native'];
							$eaad9527ef2b563d['movie_symlink'] = $ee462bb53fd79bcd['movie_symlink'];
							$eaad9527ef2b563d['remove_subtitles'] = $ee462bb53fd79bcd['remove_subtitles'];
							$eaad9527ef2b563d['transcode_profile_id'] = $ee462bb53fd79bcd['transcode_profile_id'];

							if (!$ee462bb53fd79bcd['import']) {
							} else {
								$eaad9527ef2b563d['direct_source'] = $ee462bb53fd79bcd['direct_source'];
								$eaad9527ef2b563d['direct_proxy'] = $ee462bb53fd79bcd['direct_proxy'];
							}

							$eaad9527ef2b563d['order'] = dC95637c2dA3B543();
							$eaad9527ef2b563d['tmdb_language'] = $rLanguage;

							if (count($A38b42a281e3c3cf) != 0) {
							} else {
								if (0 < $ee462bb53fd79bcd['max_genres']) {
									$Dfb47c4f9d8dd258 = array_slice($a2b9f17f5f896910['genres'], 0, $ee462bb53fd79bcd['max_genres']);
								} else {
									$Dfb47c4f9d8dd258 = $a2b9f17f5f896910['genres'];
								}

								foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
									$Be965cdd996d4520 = intval($d1ea20cf43346712[1][intval($B8995c76454f4b98['id'])]['category_id']);

									if (0 >= $Be965cdd996d4520) {
									} else {
										if (in_array($Be965cdd996d4520, $A38b42a281e3c3cf)) {
										} else {
											$A38b42a281e3c3cf[] = $Be965cdd996d4520;
										}
									}
								}
							}

							if (count($Adf384de46aa6175) != 0) {
							} else {
								if (0 < $ee462bb53fd79bcd['max_genres']) {
									$Dfb47c4f9d8dd258 = array_slice($a2b9f17f5f896910['genres'], 0, $ee462bb53fd79bcd['max_genres']);
								} else {
									$Dfb47c4f9d8dd258 = $a2b9f17f5f896910['genres'];
								}

								foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
									$cb498e4dcaac05cc = json_decode($d1ea20cf43346712[1][intval($B8995c76454f4b98['id'])]['bouquets'], true);

									foreach ($cb498e4dcaac05cc as $C52c0b6b0f74407b) {
										if (in_array($C52c0b6b0f74407b, $Adf384de46aa6175)) {
										} else {
											$Adf384de46aa6175[] = $C52c0b6b0f74407b;
										}
									}
								}
							}
						} else {
							$C9e42207e95f03ed = $a69d576081840514->getTVShow($dbc0f67b4f0fdee0->get('id'));

							if ($ee462bb53fd79bcd['duplicate_tmdb']) {
								$Cd402430ba113e2c = null;
							} else {
								$Cd402430ba113e2c = getEpisode($dbc0f67b4f0fdee0->get('id'), $d92a501f0ef30373, $f126437af6a11597);
							}

							if ($Cd402430ba113e2c) {
								if ($ee462bb53fd79bcd['auto_upgrade']) {
									if (substr($Cd402430ba113e2c['source'], 0, 3 + strlen(strval(SERVER_ID))) != 's:' . SERVER_ID . ':') {
										echo "Old file path doesn't match this server, don't upgrade." . "\n";

										exit();
									}

									list(, $F801b576294fd6f7) = explode('s:' . SERVER_ID . ':', $Cd402430ba113e2c['source']);

									if (!file_exists($F801b576294fd6f7) || filesize($F801b576294fd6f7) < filesize($e2f848a82a80c113)) {
										echo 'Upgrade episode!' . "\n";
										$Fee0d5a474c96306->query('UPDATE `streams` SET `stream_source` = ?, `target_container` = ? WHERE `id` = ?;', $eaad9527ef2b563d['stream_source'], $eaad9527ef2b563d['target_container'], $Cd402430ba113e2c['id']);
										$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL, `current_source` = NULL, `to_analyze` = 0, `pid` = NULL, `stream_started` = NULL, `stream_info` = NULL, `compatible` = 0, `video_codec` = NULL, `audio_codec` = NULL, `resolution` = NULL, `stream_status` = 0 WHERE `stream_id` = ? AND `server_id` = ?', $Cd402430ba113e2c['id'], SERVER_ID);

										if (!$ee462bb53fd79bcd['auto_encode']) {
										} else {
											XUI::queueMovie($Cd402430ba113e2c['id']);
										}

										$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 6, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));
										$a4742f468cc33b0b = json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . $dbc0f67b4f0fdee0->get('id') . '.cache'), true);
										$a4742f468cc33b0b[$d92a501f0ef30373 . '_' . $f126437af6a11597] = array('id' => $Cd402430ba113e2c['id'], 'source' => 's:' . SERVER_ID . ':' . $e2f848a82a80c113);
										file_put_contents(WATCH_TMP_PATH . 'series_' . $dbc0f67b4f0fdee0->get('id') . '.cache', json_encode($a4742f468cc33b0b));

										exit();
									}

									echo "File isn't a better source, don't upgrade." . "\n";

									exit();
								}

								echo 'Upgrade disabled' . "\n";

								exit();
							}

							$B7b7b2d9498c93ec = json_decode($C9e42207e95f03ed->getJSON(), true);

							if (!$B7b7b2d9498c93ec['id']) {
							} else {
								while (file_exists(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id']))) {
									if ($cd2a4260ef308305 >= time() - filemtime(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id']))) {
									} else {
										unlink(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id']));
									}

									usleep(100000);
								}
								$bfdf9b362cbb1da2 = fopen(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id']), 'w');

								while (!flock($bfdf9b362cbb1da2, LOCK_EX)) {
									usleep(100000);
								}
								fwrite($bfdf9b362cbb1da2, time());
								$f3f708a8ce235bed = array();

								foreach ($B7b7b2d9498c93ec['seasons'] as $b550d8eef0f542ec) {
									$b550d8eef0f542ec['cover'] = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $b550d8eef0f542ec['poster_path'];

									if (!XUI::$rSettings['download_images']) {
									} else {
										$b550d8eef0f542ec['cover'] = XUI::b2068CE8b339bf70($b550d8eef0f542ec['cover'], 2);
									}

									$b550d8eef0f542ec['cover_big'] = $b550d8eef0f542ec['cover'];
									unset($b550d8eef0f542ec['poster_path']);
									$f3f708a8ce235bed[] = $b550d8eef0f542ec;
								}
								$bbc84f53c534450d = F1e2F32dcCFD29A4($B7b7b2d9498c93ec['id']);

								if (!$bbc84f53c534450d) {
									$cf3c8094e0d98a73 = array('title' => $B7b7b2d9498c93ec['name'], 'category_id' => array(), 'episode_run_time' => 0, 'tmdb_id' => $B7b7b2d9498c93ec['id'], 'cover' => '', 'genre' => '', 'plot' => $B7b7b2d9498c93ec['overview'], 'cast' => '', 'rating' => $B7b7b2d9498c93ec['vote_average'], 'director' => '', 'release_date' => $B7b7b2d9498c93ec['first_air_date'], 'last_modified' => time(), 'seasons' => $f3f708a8ce235bed, 'backdrop_path' => array(), 'youtube_trailer' => '', 'year' => null);
									$cf3c8094e0d98a73['youtube_trailer'] = E6D2aeD48F58352c($B7b7b2d9498c93ec['id'], (!empty($ee462bb53fd79bcd['language']) ? $ee462bb53fd79bcd['language'] : XUI::$rSettings['tmdb_language']));
									$cf3c8094e0d98a73['cover'] = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $B7b7b2d9498c93ec['poster_path'];
									$cf3c8094e0d98a73['cover_big'] = $cf3c8094e0d98a73['cover'];
									$cf3c8094e0d98a73['backdrop_path'] = array('https://image.tmdb.org/t/p/w1280' . $B7b7b2d9498c93ec['backdrop_path']);

									if (!XUI::$rSettings['download_images']) {
									} else {
										$cf3c8094e0d98a73['cover'] = XUI::b2068CE8B339bF70($cf3c8094e0d98a73['cover'], 2);
										$cf3c8094e0d98a73['backdrop_path'] = array(XUI::b2068cE8B339bF70($cf3c8094e0d98a73['backdrop_path'][0]));
									}

									$cc6fe5bce59818ef = array();

									foreach ($B7b7b2d9498c93ec['credits']['cast'] as $B809ba74bb572f83) {
										if (count($cc6fe5bce59818ef) >= 5) {
										} else {
											$cc6fe5bce59818ef[] = $B809ba74bb572f83['name'];
										}
									}
									$cf3c8094e0d98a73['cast'] = implode(', ', $cc6fe5bce59818ef);
									$A094eef6d6023c0b = array();

									foreach ($B7b7b2d9498c93ec['credits']['crew'] as $B809ba74bb572f83) {
										if (!(count($A094eef6d6023c0b) < 5 && ($B809ba74bb572f83['department'] == 'Directing' || $B809ba74bb572f83['known_for_department'] == 'Directing')) || in_array($B809ba74bb572f83['name'], $A094eef6d6023c0b)) {
										} else {
											$A094eef6d6023c0b[] = $B809ba74bb572f83['name'];
										}
									}
									$cf3c8094e0d98a73['director'] = implode(', ', $A094eef6d6023c0b);
									$ebbdeb734c887fae = array();

									foreach ($B7b7b2d9498c93ec['genres'] as $B8995c76454f4b98) {
										if (count($ebbdeb734c887fae) >= $ee462bb53fd79bcd['max_genres']) {
										} else {
											$ebbdeb734c887fae[] = $B8995c76454f4b98['name'];
										}
									}

									if (!$B7b7b2d9498c93ec['first_air_date']) {
									} else {
										$cf3c8094e0d98a73['year'] = intval(substr($B7b7b2d9498c93ec['first_air_date'], 0, 4));
									}

									$cf3c8094e0d98a73['genre'] = implode(', ', $ebbdeb734c887fae);
									$cf3c8094e0d98a73['episode_run_time'] = intval($B7b7b2d9498c93ec['episode_run_time'][0]);

									if (count($A38b42a281e3c3cf) != 0) {
									} else {
										if (0 < $ee462bb53fd79bcd['max_genres']) {
											$Dfb47c4f9d8dd258 = array_slice($B7b7b2d9498c93ec['genres'], 0, $ee462bb53fd79bcd['max_genres']);
										} else {
											$Dfb47c4f9d8dd258 = $B7b7b2d9498c93ec['genres'];
										}

										foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
											$Be965cdd996d4520 = intval($d1ea20cf43346712[2][intval($B8995c76454f4b98['id'])]['category_id']);

											if (0 >= $Be965cdd996d4520) {
											} else {
												if (in_array($Be965cdd996d4520, $A38b42a281e3c3cf)) {
												} else {
													$A38b42a281e3c3cf[] = $Be965cdd996d4520;
												}
											}
										}
									}

									if (count($Adf384de46aa6175) != 0) {
									} else {
										if (0 < $ee462bb53fd79bcd['max_genres']) {
											$Dfb47c4f9d8dd258 = array_slice($B7b7b2d9498c93ec['genres'], 0, $ee462bb53fd79bcd['max_genres']);
										} else {
											$Dfb47c4f9d8dd258 = $B7b7b2d9498c93ec['genres'];
										}

										foreach ($Dfb47c4f9d8dd258 as $B8995c76454f4b98) {
											$cb498e4dcaac05cc = json_decode($d1ea20cf43346712[2][intval($B8995c76454f4b98['id'])]['bouquets'], true);

											foreach ($cb498e4dcaac05cc as $C52c0b6b0f74407b) {
												if (in_array($C52c0b6b0f74407b, $Adf384de46aa6175)) {
												} else {
													$Adf384de46aa6175[] = $C52c0b6b0f74407b;
												}
											}
										}
									}

									if (count($A38b42a281e3c3cf) != 0 || empty($ee462bb53fd79bcd['fb_category_id'])) {
									} else {
										if (is_array($ee462bb53fd79bcd['fb_category_id'])) {
											$A38b42a281e3c3cf = array_map('intval', $ee462bb53fd79bcd['fb_category_id']);
										} else {
											$A38b42a281e3c3cf = array(intval($ee462bb53fd79bcd['fb_category_id']));
										}
									}

									if (count($Adf384de46aa6175) != 0 || empty($ee462bb53fd79bcd['fb_bouquets'])) {
									} else {
										if (is_array($ee462bb53fd79bcd['fb_bouquets'])) {
											$Adf384de46aa6175 = array_map('intval', $ee462bb53fd79bcd['fb_bouquets']);
										} else {
											$Adf384de46aa6175 = json_decode($ee462bb53fd79bcd['fb_bouquets'], true);
										}
									}

									if (count($A38b42a281e3c3cf) != 0) {
										$cf3c8094e0d98a73['tmdb_language'] = $rLanguage;
										$cf3c8094e0d98a73['category_id'] = '[' . implode(',', array_map('intval', $A38b42a281e3c3cf)) . ']';
										$acd0eb2c8a975903 = f4817Dc607D9981d($cf3c8094e0d98a73);
										$A6d7047f2fda966c = 'INSERT INTO `streams_series`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

										if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
											$Fc2dc5a0ce8d07ea = $Fee0d5a474c96306->last_insert_id();
											$bbc84f53c534450d = fFD24e407AbB46eb($Fc2dc5a0ce8d07ea);
											file_put_contents(WATCH_TMP_PATH . 'series_' . intval($B7b7b2d9498c93ec['id']), json_encode($bbc84f53c534450d));

											foreach ($Adf384de46aa6175 as $ddf0508b312dbfb8) {
												d7E7F81f646193b2('series', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
											}
										} else {
											$bbc84f53c534450d = null;
										}
									} else {
										$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 3, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

										exit();
									}
								} else {
									$Fee0d5a474c96306->query('UPDATE `streams_series` SET `seasons` = ? WHERE `id` = ?;', json_encode($f3f708a8ce235bed, JSON_UNESCAPED_UNICODE), $bbc84f53c534450d['id']);

									if (file_exists(WATCH_TMP_PATH . 'series_' . intval($B7b7b2d9498c93ec['id']))) {
									} else {
										file_put_contents(WATCH_TMP_PATH . 'series_' . intval($B7b7b2d9498c93ec['id']), json_encode($bbc84f53c534450d));
									}
								}

								flock($bfdf9b362cbb1da2, LOCK_UN);
								unlink(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id']));
								$eaad9527ef2b563d['read_native'] = $ee462bb53fd79bcd['read_native'];
								$eaad9527ef2b563d['movie_symlink'] = $ee462bb53fd79bcd['movie_symlink'];
								$eaad9527ef2b563d['remove_subtitles'] = $ee462bb53fd79bcd['remove_subtitles'];
								$eaad9527ef2b563d['transcode_profile_id'] = $ee462bb53fd79bcd['transcode_profile_id'];

								if (!$ee462bb53fd79bcd['import']) {
								} else {
									$eaad9527ef2b563d['direct_source'] = $ee462bb53fd79bcd['direct_source'];
									$eaad9527ef2b563d['direct_proxy'] = $ee462bb53fd79bcd['direct_proxy'];
								}

								$eaad9527ef2b563d['order'] = dc95637C2Da3B543();

								if (!($d92a501f0ef30373 && $f126437af6a11597)) {
								} else {
									if (is_array($fab84a7bc25d47ab['episode']) && count($fab84a7bc25d47ab['episode']) == 2) {
										$eaad9527ef2b563d['stream_display_name'] = $B7b7b2d9498c93ec['name'] . ' - S' . sprintf('%02d', intval($d92a501f0ef30373)) . 'E' . sprintf('%02d', $fab84a7bc25d47ab['episode'][0]) . '-' . sprintf('%02d', $fab84a7bc25d47ab['episode'][1]);
									} else {
										$eaad9527ef2b563d['stream_display_name'] = $B7b7b2d9498c93ec['name'] . ' - S' . sprintf('%02d', intval($d92a501f0ef30373)) . 'E' . sprintf('%02d', $f126437af6a11597);
									}

									$b1fa0ad0bb84d114 = json_decode($a69d576081840514->getSeason($B7b7b2d9498c93ec['id'], intval($d92a501f0ef30373))->getJSON(), true);

									foreach ($b1fa0ad0bb84d114['episodes'] as $Bd43537fab08ca31) {
										if (intval($Bd43537fab08ca31['episode_number']) != $f126437af6a11597) {
										} else {
											if (0 >= strlen($Bd43537fab08ca31['still_path'])) {
											} else {
												$A639a7baefc720ee = 'https://image.tmdb.org/t/p/w1280' . $Bd43537fab08ca31['still_path'];

												if (!XUI::$rSettings['download_images']) {
												} else {
													$A639a7baefc720ee = XUI::B2068cE8b339bF70($A639a7baefc720ee, 5);
												}
											}

											if (0 >= strlen($Bd43537fab08ca31['name'])) {
											} else {
												$eaad9527ef2b563d['stream_display_name'] .= ' - ' . $Bd43537fab08ca31['name'];
											}

											$eff3c5536b319f0b = intval($B7b7b2d9498c93ec['episode_run_time'][0]) * 60;
											$eaad9527ef2b563d['movie_properties'] = array('tmdb_id' => $Bd43537fab08ca31['id'], 'release_date' => $Bd43537fab08ca31['air_date'], 'plot' => $Bd43537fab08ca31['overview'], 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'movie_image' => $A639a7baefc720ee, 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => $Bd43537fab08ca31['vote_average'], 'season' => $d92a501f0ef30373);

											if (strlen($eaad9527ef2b563d['movie_properties']['movie_image'][0]) != 0) {
											} else {
												unset($eaad9527ef2b563d['movie_properties']['movie_image']);
											}
										}
									}

									if (strlen($eaad9527ef2b563d['stream_display_name']) != 0) {
									} else {
										$eaad9527ef2b563d['stream_display_name'] = 'No Episode Title';
									}
								}
							}
						}
					} else {
						if ($ee462bb53fd79bcd['type'] == 'movie') {
							$eaad9527ef2b563d['stream_display_name'] = $c608db3e24256b76;

							if (!$A02729c83b6cd395) {
							} else {
								$eaad9527ef2b563d['year'] = $A02729c83b6cd395;
							}
						} else {
							if (!($d92a501f0ef30373 && $f126437af6a11597)) {
							} else {
								$eaad9527ef2b563d['stream_display_name'] = $c608db3e24256b76 . ' - S' . sprintf('%02d', intval($d92a501f0ef30373)) . 'E' . sprintf('%02d', $f126437af6a11597) . ' - ';
							}
						}

						$eaad9527ef2b563d['read_native'] = $ee462bb53fd79bcd['read_native'];
						$eaad9527ef2b563d['movie_symlink'] = $ee462bb53fd79bcd['movie_symlink'];
						$eaad9527ef2b563d['remove_subtitles'] = $ee462bb53fd79bcd['remove_subtitles'];
						$eaad9527ef2b563d['transcode_profile_id'] = $ee462bb53fd79bcd['transcode_profile_id'];

						if (!$ee462bb53fd79bcd['import']) {
						} else {
							$eaad9527ef2b563d['direct_source'] = $ee462bb53fd79bcd['direct_source'];
							$eaad9527ef2b563d['direct_proxy'] = $ee462bb53fd79bcd['direct_proxy'];
						}

						$eaad9527ef2b563d['order'] = DC95637C2DA3B543();
						$eaad9527ef2b563d['tmdb_language'] = $rLanguage;
					}

					if ($ee462bb53fd79bcd['type'] == 'movie') {
						if (count($A38b42a281e3c3cf) != 0 || empty($ee462bb53fd79bcd['fb_category_id'])) {
						} else {
							if (is_array($ee462bb53fd79bcd['fb_category_id'])) {
								$A38b42a281e3c3cf = array_map('intval', $ee462bb53fd79bcd['fb_category_id']);
							} else {
								$A38b42a281e3c3cf = array(intval($ee462bb53fd79bcd['fb_category_id']));
							}
						}

						if (count($Adf384de46aa6175) != 0 || empty($ee462bb53fd79bcd['fb_bouquets'])) {
						} else {
							if (is_array($ee462bb53fd79bcd['fb_bouquets'])) {
								$Adf384de46aa6175 = array_map('intval', $ee462bb53fd79bcd['fb_bouquets']);
							} else {
								$Adf384de46aa6175 = json_decode($ee462bb53fd79bcd['fb_bouquets'], true);
							}
						}

						$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', $A38b42a281e3c3cf)) . ']';

						if (count($A38b42a281e3c3cf) != 0) {
						} else {
							$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 3, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

							exit();
						}
					} else {
						if ($bbc84f53c534450d) {
							$eaad9527ef2b563d['series_no'] = $bbc84f53c534450d['id'];
						} else {
							$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 4, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

							exit();
						}
					}

					if (!$ee462bb53fd79bcd['subtitles']) {
					} else {
						$eaad9527ef2b563d['movie_subtitles'] = $ee462bb53fd79bcd['subtitles'];
					}

					$eaad9527ef2b563d['added'] = time();
					$acd0eb2c8a975903 = f4817Dc607d9981d($eaad9527ef2b563d);
					$A6d7047f2fda966c = 'INSERT INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if ($Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = $Fee0d5a474c96306->last_insert_id();

						if ($ee462bb53fd79bcd['import']) {
							foreach ($ee462bb53fd79bcd['servers'] as $d58b4f8653a391d8) {
								$Fee0d5a474c96306->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`) VALUES(?, ?, NULL);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
							}
						} else {
							$Fee0d5a474c96306->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`) VALUES(?, ?, NULL);', $Fc2dc5a0ce8d07ea, SERVER_ID);
						}

						if ($ee462bb53fd79bcd['type'] == 'movie') {
							if (!$dbc0f67b4f0fdee0 || $ee462bb53fd79bcd['import']) {
							} else {
								file_put_contents(WATCH_TMP_PATH . 'movie_' . $dbc0f67b4f0fdee0->get('id') . '.cache', json_encode(array('id' => $Fc2dc5a0ce8d07ea, 'source' => 's:' . SERVER_ID . ':' . $e2f848a82a80c113)));
							}

							foreach ($Adf384de46aa6175 as $ddf0508b312dbfb8) {
								D7e7f81F646193B2('movie', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
							}
						} else {
							$Fee0d5a474c96306->query('INSERT INTO `streams_episodes`(`season_num`, `series_id`, `stream_id`, `episode_num`) VALUES(?, ?, ?, ?);', $d92a501f0ef30373, $bbc84f53c534450d['id'], $Fc2dc5a0ce8d07ea, $f126437af6a11597);
						}

						if (!$ee462bb53fd79bcd['auto_encode']) {
						} else {
							if ($ee462bb53fd79bcd['import']) {
								foreach ($ee462bb53fd79bcd['servers'] as $d58b4f8653a391d8) {
									XUI::queueMovie($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
								}
							} else {
								XUI::queueMovie($Fc2dc5a0ce8d07ea);
							}
						}

						echo 'Success!' . "\n";
						$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 1, ?);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113), $Fc2dc5a0ce8d07ea);

						exit();
					} else {
						echo 'Insert failed!' . "\n";
						$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 2, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

						exit();
					}
				} else {
					echo 'No match!' . "\n";
					$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 4, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

					exit();
				}
			} else {
				echo 'File is broken!' . "\n";
				$Fee0d5a474c96306->query('INSERT INTO `watch_logs`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(?, ?, ?, 5, 0);', $A0fa741c62cbe676, SERVER_ID, utf8_decode($e2f848a82a80c113));

				exit();
			}
		} else {
			exit();
		}
	} else {
		echo 'Incorrect root directory!';

		exit();
	}
}

function D7e7f81f646193B2($E379394c7b1a273f, $C52c0b6b0f74407b, $C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	global $ee462bb53fd79bcd;

	if ($ee462bb53fd79bcd['import']) {
		$ddf0508b312dbfb8 = C8aDb574F9477F84($C52c0b6b0f74407b);

		if (!$ddf0508b312dbfb8) {
		} else {
			if ($E379394c7b1a273f == 'stream') {
				$f8d6610081a97651 = 'bouquet_channels';
			} else {
				if ($E379394c7b1a273f == 'movie') {
					$f8d6610081a97651 = 'bouquet_movies';
				} else {
					if ($E379394c7b1a273f == 'radio') {
						$f8d6610081a97651 = 'bouquet_radios';
					} else {
						$f8d6610081a97651 = 'bouquet_series';
					}
				}
			}

			$f46da30a01f7b2d7 = confirmIDs(json_decode($ddf0508b312dbfb8[$f8d6610081a97651], true));

			if (0 >= intval($C3c8913edb801c35) || in_array($C3c8913edb801c35, $f46da30a01f7b2d7)) {
			} else {
				$f46da30a01f7b2d7[] = $C3c8913edb801c35;

				if (0 >= count($f46da30a01f7b2d7)) {
				} else {
					$Fee0d5a474c96306->query('UPDATE `bouquets` SET `' . $f8d6610081a97651 . '` = ? WHERE `id` = ?;', '[' . implode(',', array_map('intval', $f46da30a01f7b2d7)) . ']', $C52c0b6b0f74407b);
				}
			}
		}
	} else {
		file_put_contents(WATCH_TMP_PATH . md5($ee462bb53fd79bcd['file'] . '_' . $E379394c7b1a273f . '_' . $C52c0b6b0f74407b . '_' . $C3c8913edb801c35) . '.bouquet', json_encode(array('type' => $E379394c7b1a273f, 'bouquet_id' => $C52c0b6b0f74407b, 'id' => $C3c8913edb801c35)));
	}
}

function e6c35233AD4E96Cd($fab84a7bc25d47ab, $E379394c7b1a273f = 'guessit')
{
	if ($E379394c7b1a273f == 'guessit') {
		$cf1c389bda3e30fd = XUI_HOME . 'bin/guess ' . escapeshellarg($fab84a7bc25d47ab . '.mkv');
	} else {
		$cf1c389bda3e30fd = '/usr/bin/python3 ' . XUI_HOME . 'includes/python/release.py ' . escapeshellarg(str_replace('-', '_', $fab84a7bc25d47ab));
	}

	return json_decode(shell_exec($cf1c389bda3e30fd), true);
}

function getMovie($Ddb572d71804d3a6)
{
	if (!file_exists(WATCH_TMP_PATH . 'movie_' . $Ddb572d71804d3a6 . '.cache')) {
	} else {
		return json_decode(file_get_contents(WATCH_TMP_PATH . 'movie_' . $Ddb572d71804d3a6 . '.cache'), true);
	}
}

function getEpisode($Ddb572d71804d3a6, $b550d8eef0f542ec, $Bd43537fab08ca31)
{
	if (!file_exists(WATCH_TMP_PATH . 'series_' . $Ddb572d71804d3a6 . '.cache')) {
	} else {
		$a27e64cc6ce01033 = json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . $Ddb572d71804d3a6 . '.cache'), true);

		if (!isset($a27e64cc6ce01033[$b550d8eef0f542ec . '_' . $Bd43537fab08ca31])) {
		} else {
			return $a27e64cc6ce01033[$b550d8eef0f542ec . '_' . $Bd43537fab08ca31];
		}
	}
}

function parseTitle($c608db3e24256b76)
{
	return strtolower(preg_replace("/(?![.=\$'€%-])\\p{P}/u", '', $c608db3e24256b76));
}

function bBdbe7aD31018a97($bc2874292e0d9ece)
{
	$cf1c389bda3e30fd = 'timeout 10 ' . XUI::$rFFPROBE . ' -show_streams -show_format -v quiet ' . escapeshellarg($bc2874292e0d9ece) . ' -of json';

	return json_decode(shell_exec($cf1c389bda3e30fd), true);
}

function C4A6F6f0DeBd5F57($b6842cb20051e925)
{
	return strtolower(preg_replace('/[^a-z0-9_]+/i', '', $b6842cb20051e925));
}

function F4817dc607d9981D($d49041d5f05a9270)
{
	$D480255818428bfd = $F02c388243a378a7 = $C0ad72b730f8eea3 = $a27e64cc6ce01033 = array();

	foreach (array_keys($d49041d5f05a9270) as $D3fa098be3f297cd) {
		$F02c388243a378a7[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '`';
		$D480255818428bfd[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '` = ?';
	}

	foreach (array_values($d49041d5f05a9270) as $b6842cb20051e925) {
		if (!is_array($b6842cb20051e925)) {
		} else {
			$b6842cb20051e925 = json_encode($b6842cb20051e925, JSON_UNESCAPED_UNICODE);
		}

		$C0ad72b730f8eea3[] = '?';
		$a27e64cc6ce01033[] = $b6842cb20051e925;
	}

	return array('placeholder' => implode(',', $C0ad72b730f8eea3), 'columns' => implode(',', $F02c388243a378a7), 'data' => $a27e64cc6ce01033, 'update' => implode(',', $D480255818428bfd));
}

function B9dA5D708Fc1C079($B1a1e80ba9ae29c7, $a27e64cc6ce01033 = array(), $fcc4f0f10efcef42 = false)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `column_name`, `column_default`, `is_nullable`, `data_type` FROM `information_schema`.`columns` WHERE `table_schema` = (SELECT DATABASE()) AND `table_name` = ? ORDER BY `ordinal_position`;', $B1a1e80ba9ae29c7);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($C740da31596f24ef['column_default'] != 'NULL') {
		} else {
			$C740da31596f24ef['column_default'] = null;
		}

		$f2373ceca1685f65 = false;

		if ($C740da31596f24ef['is_nullable'] != 'NO' || $C740da31596f24ef['column_default']) {
		} else {
			if (in_array($C740da31596f24ef['data_type'], array('int', 'float', 'tinyint', 'double', 'decimal', 'smallint', 'mediumint', 'bigint', 'bit'))) {
				$C740da31596f24ef['column_default'] = 0;
			} else {
				$C740da31596f24ef['column_default'] = '';
			}

			$f2373ceca1685f65 = true;
		}

		if (array_key_exists($C740da31596f24ef['column_name'], $a27e64cc6ce01033)) {
			if (empty($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && !is_numeric($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && is_null($C740da31596f24ef['column_default'])) {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = ($f2373ceca1685f65 ? $C740da31596f24ef['column_default'] : null);
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $a27e64cc6ce01033[$C740da31596f24ef['column_name']];
			}
		} else {
			if ($fcc4f0f10efcef42) {
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $C740da31596f24ef['column_default'];
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function F1e2f32dccFd29a4($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;

	if (!(file_exists(WATCH_TMP_PATH . 'series_' . intval($C3c8913edb801c35) . '.data') && time() - filemtime(WATCH_TMP_PATH . 'series_' . intval($C3c8913edb801c35) . '.data') < 360)) {
		$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `tmdb_id` = ?;', $C3c8913edb801c35);

		if ($Fee0d5a474c96306->num_rows() != 1) {
		} else {
			return $Fee0d5a474c96306->get_row();
		}
	} else {
		return json_decode(file_get_contents(WATCH_TMP_PATH . 'series_' . intval($C3c8913edb801c35) . '.data'), true);
	}
}

function e6D2aed48F58352c($Ddb572d71804d3a6, $rLanguage = null)
{
	$C700a2b357e5ed65 = 'https://api.themoviedb.org/3/tv/' . intval($Ddb572d71804d3a6) . '/videos?api_key=' . urlencode(XUI::$rSettings['tmdb_api_key']);

	if ($rLanguage) {
		$C700a2b357e5ed65 .= '&language=' . urlencode($rLanguage);
	} else {
		if (0 >= strlen(XUI::$rSettings['tmdb_language'])) {
		} else {
			$C700a2b357e5ed65 .= '&language=' . urlencode(XUI::$rSettings['tmdb_language']);
		}
	}

	$Bec25219bd671a85 = json_decode(file_get_contents($C700a2b357e5ed65), true);

	foreach ($Bec25219bd671a85['results'] as $ddf29a8b9c0c6f4f) {
		if (!(strtolower($ddf29a8b9c0c6f4f['type']) == 'trailer' && strtolower($ddf29a8b9c0c6f4f['site']) == 'youtube')) {
		} else {
			return $ddf29a8b9c0c6f4f['key'];
		}
	}

	return '';
}

function fFD24E407abB46EB($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function dc95637C2dA3b543()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT MAX(`order`) AS `order` FROM `streams`;');

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return 0;
	}

	return intval($Fee0d5a474c96306->get_row()['order']) + 1;
}

function confirmIDs($Aa8c918a2a91966f)
{
	$a85e1b7d42c346a0 = array();

	foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
		if (0 >= intval($C3c8913edb801c35)) {
		} else {
			$a85e1b7d42c346a0[] = $C3c8913edb801c35;
		}
	}

	return $a85e1b7d42c346a0;
}

function c8adb574f9477F84($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $B7b7b2d9498c93ec;

	if (!(is_array($B7b7b2d9498c93ec) && $B7b7b2d9498c93ec['id'] && file_exists(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id'])))) {
	} else {
		unlink(WATCH_TMP_PATH . 'lock_' . intval($B7b7b2d9498c93ec['id']));
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}

	@unlink(WATCH_TMP_PATH . @getmypid() . '.wpid');
}
