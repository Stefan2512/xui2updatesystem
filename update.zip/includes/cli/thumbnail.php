<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc == 2) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		$F26087d31c2bbe4d = intval($argv[1]);
		d60457acfd5df5c9($F26087d31c2bbe4d);
		set_time_limit(0);
		cli_set_process_title('Thumbnail[' . $F26087d31c2bbe4d . ']');
		fdc97512d22b990e();
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function FdC97512D22B990E()
{
	global $Fee0d5a474c96306;
	global $F26087d31c2bbe4d;
	$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t1.id = t2.stream_id AND t2.server_id = t1.vframes_server_id WHERE t1.`id` = ? AND t1.`vframes_server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);

	if (0 < $Fee0d5a474c96306->num_rows()) {
		$C740da31596f24ef = $Fee0d5a474c96306->get_row();
		$Fee0d5a474c96306->query('UPDATE `streams` SET `vframes_pid` = ? WHERE `id` = ?', getmypid(), $F26087d31c2bbe4d);
		XUI::AFA0F3Ffb001B9BE($F26087d31c2bbe4d);
		$Fee0d5a474c96306->close_mysql();

		while (XUI::F74fA4748b081619($C740da31596f24ef['pid'], $F26087d31c2bbe4d)) {
			shell_exec(XUI::$rFFMPEG_CPU . ' -y -i "' . STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8" -qscale:v 4 -frames:v 1 "' . STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg" >/dev/null 2>/dev/null &');
			sleep(5);
		}
	} else {
		exit();
	}
}

function D60457aCFD5Df5C9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.thumb')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.thumb'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'Thumbnail\\[" . $F26087d31c2bbe4d . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'Thumbnail[' . $F26087d31c2bbe4d . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}

	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.thumb', getmypid());
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
