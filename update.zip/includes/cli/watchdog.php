<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		shell_exec('kill $(ps aux | grep watchdog | grep -v grep | grep -v ' . getmypid() . " | awk '{print \$2}')");
		$F2319168a4d07d06 = (intval(XUI::$rSettings['online_capacity_interval']) ?: 10);
		$A58c41e6ba770315 = $f28cc1df497adc2f = $f619559110a3b73e = $Af547236269d8f66 = null;
		$Ba344b2758e3e955 = md5_file(__FILE__);

		if (!XUI::$rSettings['redis_handler']) {
		} else {
			XUI::bfA8B6FE314DEd7f();
		}

		$ffd0802c4358f6d2 = json_decode(XUI::$rServers[SERVER_ID]['watchdog_data'], true);
		$c86192ebceaa591f = ($ffd0802c4358f6d2['cpu_average_array'] ?: array());

		while (true && $Fee0d5a474c96306->ping() && !(XUI::$rSettings['redis_handler'] && (!XUI::$redis || !XUI::$redis->ping()))) {
			if ($Af547236269d8f66 && $F2319168a4d07d06 > time() - $Af547236269d8f66) {
				$b9e33ce83162666c = explode("\n", file_get_contents('http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/nginx_status'));
				list($B88d6f9fc844381c, $Dadf04b30057bbdd, $E6872e7118ee1a72) = explode(' ', trim($b9e33ce83162666c[2]));
				$A86de6c142e40a19 = ($A58c41e6ba770315 ? intval(floatval($E6872e7118ee1a72 - $A58c41e6ba770315) / (time() - $f28cc1df497adc2f)) : 0);
				$A58c41e6ba770315 = $E6872e7118ee1a72;
				$f28cc1df497adc2f = time();
				$e19876d9ba369ed1 = XUI::F4148D7dFAEE2F14();

				if ($f619559110a3b73e) {
				} else {
					$f619559110a3b73e = file('/proc/stat');
					sleep(2);
				}

				$F5378daabf0ee34f = file('/proc/stat');
				$d357d88d9d91995d = explode(' ', preg_replace('!cpu +!', '', $f619559110a3b73e[0]));
				$f9eee8841ca1c4c3 = explode(' ', preg_replace('!cpu +!', '', $F5378daabf0ee34f[0]));
				$f619559110a3b73e = $F5378daabf0ee34f;
				$D2df823aae4601c8 = array();
				$D2df823aae4601c8['user'] = $f9eee8841ca1c4c3[0] - $d357d88d9d91995d[0];
				$D2df823aae4601c8['nice'] = $f9eee8841ca1c4c3[1] - $d357d88d9d91995d[1];
				$D2df823aae4601c8['sys'] = $f9eee8841ca1c4c3[2] - $d357d88d9d91995d[2];
				$D2df823aae4601c8['idle'] = $f9eee8841ca1c4c3[3] - $d357d88d9d91995d[3];
				$Db02e1f7181c07ed = array_sum($D2df823aae4601c8);
				$A5f9aca3132df579 = array();

				foreach ($D2df823aae4601c8 as $b2db2d0561ace513 => $E2431f134bf1c17e) {
					$A5f9aca3132df579[$b2db2d0561ace513] = round($E2431f134bf1c17e / $Db02e1f7181c07ed * 100, 2);
				}
				$e19876d9ba369ed1['cpu'] = $A5f9aca3132df579['user'] + $A5f9aca3132df579['sys'];
				$c86192ebceaa591f[] = $e19876d9ba369ed1['cpu'];

				if (30 >= count($c86192ebceaa591f)) {
				} else {
					$c86192ebceaa591f = array_slice($c86192ebceaa591f, count($c86192ebceaa591f) - 30, 30);
				}

				$e19876d9ba369ed1['cpu_average_array'] = $c86192ebceaa591f;
				$fe600baebac1262a = array();
				exec("ps -u xui | grep php-fpm | awk {'print \$1'}", $fe600baebac1262a);
				$A90d77181715e38e = $B963b5d49ca08acf = 0;

				if (!XUI::$rSettings['redis_handler']) {
					$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `hls_end` = 0 AND `server_id` = ?;', SERVER_ID);
					$A90d77181715e38e = $Fee0d5a474c96306->get_row()['count'];
					$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `hls_end` = 0 AND `server_id` = ? GROUP BY `user_id`;', SERVER_ID);
					$B963b5d49ca08acf = $Fee0d5a474c96306->num_rows();
					$B59c127fecf35c15 = $Fee0d5a474c96306->query('UPDATE `servers` SET `watchdog_data` = ?, `last_check_ago` = UNIX_TIMESTAMP(), `requests_per_second` = ?, `php_pids` = ?, `connections` = ?, `users` = ? WHERE `id` = ?;', json_encode($e19876d9ba369ed1, JSON_PARTIAL_OUTPUT_ON_ERROR), $A86de6c142e40a19, json_encode($fe600baebac1262a), $A90d77181715e38e, $B963b5d49ca08acf, SERVER_ID);
				} else {
					$B59c127fecf35c15 = $Fee0d5a474c96306->query('UPDATE `servers` SET `watchdog_data` = ?, `last_check_ago` = UNIX_TIMESTAMP(), `requests_per_second` = ?, `php_pids` = ? WHERE `id` = ?;', json_encode($e19876d9ba369ed1, JSON_PARTIAL_OUTPUT_ON_ERROR), $A86de6c142e40a19, json_encode($fe600baebac1262a), SERVER_ID);
				}

				if ($B59c127fecf35c15) {
					if (!XUI::$rServers[SERVER_ID]['is_main']) {
					} else {
						if (XUI::$rSettings['redis_handler']) {
							$caa6c2a1dcc4ac73 = XUI::$redis->multi();

							foreach (array_keys(XUI::$rServers) as $d58b4f8653a391d8) {
								if (!XUI::$rServers[$d58b4f8653a391d8]['server_online']) {
								} else {
									$caa6c2a1dcc4ac73->zCard('SERVER#' . $d58b4f8653a391d8);
									$caa6c2a1dcc4ac73->zRangeByScore('SERVER_LINES#' . $d58b4f8653a391d8, '-inf', '+inf', array('withscores' => true));
								}
							}
							$c15d5b523e931f51 = $caa6c2a1dcc4ac73->exec();
							$D2b8fe3d07ca94db = array();
							$Ea22c4a9ab5b2176 = 0;

							foreach (array_keys(XUI::$rServers) as $d58b4f8653a391d8) {
								if (!XUI::$rServers[$d58b4f8653a391d8]['server_online']) {
								} else {
									$Fee0d5a474c96306->query('UPDATE `servers` SET `connections` = ?, `users` = ? WHERE `id` = ?;', $c15d5b523e931f51[$Ea22c4a9ab5b2176 * 2], count(array_unique(array_values($c15d5b523e931f51[$Ea22c4a9ab5b2176 * 2 + 1]))), $d58b4f8653a391d8);
									$D2b8fe3d07ca94db = array_merge(array_values($c15d5b523e931f51[$Ea22c4a9ab5b2176 * 2 + 1]), $D2b8fe3d07ca94db);
									$Ea22c4a9ab5b2176++;
								}
							}
							$Fee0d5a474c96306->query('UPDATE `settings` SET `total_users` = ?;', count(array_unique($D2b8fe3d07ca94db)));
						} else {
							$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');
							$D2b8fe3d07ca94db = $Fee0d5a474c96306->num_rows();
							$Fee0d5a474c96306->query('UPDATE `settings` SET `total_users` = ?;', $D2b8fe3d07ca94db);
						}
					}

					sleep(2);
				} else {
					echo 'Failed, break.' . "\n";
				}

				break;
			}

			if (XUI::cAe8387EDc1bF201()) {
				if (md5_file(__FILE__) == $Ba344b2758e3e955) {
					XUI::$rServers = XUI::f99D78E199d641d5(true);
					XUI::$rSettings = XUI::D761E78Da5eb70fB(true);
					XUI::Cdd1bc14D819bE74(true);
					XUI::CDd1bc14d819bE74(false);
					$Af547236269d8f66 = time();
				} else {
					echo 'File changed! Break.' . "\n";
				}
			} else {
				echo 'Not running! Break.' . "\n";
			}
		}

		if (!is_object($Fee0d5a474c96306)) {
		} else {
			$Fee0d5a474c96306->close_mysql();
		}

		shell_exec('(sleep 1; ' . PHP_BIN . ' ' . __FILE__ . ' ) > /dev/null 2>/dev/null &');
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}
