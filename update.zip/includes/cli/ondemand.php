<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		set_time_limit(0);
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		shell_exec('kill -9 $(ps aux | grep ondemand | grep -v grep | grep -v ' . getmypid() . " | awk '{print \$2}')");

		if (XUI::$rSettings['on_demand_instant_off']) {
			if (!XUI::$rSettings['redis_handler']) {
			} else {
				XUI::bFa8B6Fe314deD7f();
			}

			$F7c88f6ca9c78acc = XUI::Cb50F783b960a4eF();
			$Af547236269d8f66 = null;
			$F2319168a4d07d06 = 60;
			$Ba344b2758e3e955 = md5_file(__FILE__);

			while (true && $Fee0d5a474c96306 && $Fee0d5a474c96306->ping() && !(XUI::$rSettings['redis_handler'] && (!XUI::$redis || !XUI::$redis->ping()))) {
				if ($Af547236269d8f66 && $F2319168a4d07d06 > time() - $Af547236269d8f66) {
				} else {
					if (md5_file(__FILE__) == $Ba344b2758e3e955) {
						XUI::$rSettings = XUI::D761E78Da5EB70fb(true);
						$Af547236269d8f66 = time();
					} else {
						echo 'File changed! Break.' . "\n";
					}
				}

				$b3439582205053ea = array();

				if (XUI::$rSettings['redis_handler']) {
					$Cdb85875fd50f459 = $E17df6212d427c2d = $b3439582205053ea = array();

					if ($Fee0d5a474c96306->query('SELECT t1.stream_id, servers_attached.attached FROM `streams_servers` t1 LEFT JOIN (SELECT `stream_id`, COUNT(*) AS `attached` FROM `streams_servers` WHERE `parent_id` = ? AND `pid` IS NOT NULL AND `pid` > 0 AND `monitor_pid` IS NOT NULL AND `monitor_pid` > 0) AS `servers_attached` ON `servers_attached`.`stream_id` = t1.`stream_id` WHERE t1.pid IS NOT NULL AND t1.pid > 0 AND t1.server_id = ? AND t1.`on_demand` = 1;', SERVER_ID, SERVER_ID)) {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$Cdb85875fd50f459[] = $C740da31596f24ef['stream_id'];
							$E17df6212d427c2d[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['attached'];
						}

						if (0 >= count($Cdb85875fd50f459)) {
						} else {
							$A90d77181715e38e = XUI::getStreamConnections($Cdb85875fd50f459, false, false);

							foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
								$b3439582205053ea[] = array('stream_id' => $F26087d31c2bbe4d, 'online_clients' => (count($A90d77181715e38e[$F26087d31c2bbe4d][SERVER_ID]) ?: 0), 'attached' => ($E17df6212d427c2d[$F26087d31c2bbe4d] ?: 0));
							}
						}
					}

					break;
				}

				if ($Fee0d5a474c96306->query('SELECT t1.stream_id, clients.online_clients, servers_attached.attached FROM `streams_servers` t1 LEFT JOIN (SELECT stream_id, COUNT(*) as online_clients FROM `lines_live` WHERE `server_id` = ? AND `hls_end` = 0 GROUP BY stream_id) AS clients ON clients.stream_id = t1.stream_id LEFT JOIN (SELECT `stream_id`, COUNT(*) AS `attached` FROM `streams_servers` WHERE `parent_id` = ? AND `pid` IS NOT NULL AND `pid` > 0 AND `monitor_pid` IS NOT NULL AND `monitor_pid` > 0) AS `servers_attached` ON `servers_attached`.`stream_id` = t1.`stream_id` WHERE t1.pid IS NOT NULL AND t1.pid > 0 AND t1.server_id = ? AND t1.`on_demand` = 1;', SERVER_ID, SERVER_ID, SERVER_ID)) {
					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					}
				}
			}

			if (!is_object($Fee0d5a474c96306)) {
			} else {
				$Fee0d5a474c96306->close_mysql();
			}

			shell_exec('(sleep 1; ' . PHP_BIN . ' ' . __FILE__ . ' ) > /dev/null 2>/dev/null &');

			if (0 >= count($b3439582205053ea)) {
			} else {
				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!(0 < $C740da31596f24ef['online_clients'] || 0 < $C740da31596f24ef['attached'])) {
						$F26087d31c2bbe4d = $C740da31596f24ef['stream_id'];
						$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
						$D38e2b986fdab8eb = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
						$Fdd6c7b702a9c1b7 = $a9b7f153dce9637a = 0;

						if (!file_exists(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) {
						} else {
							foreach ((igbinary_unserialize(file_get_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) ?: array()) as $f9b07d216a168dcc) {
								if (!XUI::dd714eE89c59fBf2($f9b07d216a168dcc, 'php-fpm')) {
								} else {
									$a9b7f153dce9637a++;
								}
							}
						}

						if (!(file_exists(SIGNALS_TMP_PATH . 'admin_' . intval($F26087d31c2bbe4d)) && time() - filemtime(SIGNALS_TMP_PATH . 'admin_' . intval($F26087d31c2bbe4d)) <= 30)) {
						} else {
							$Fdd6c7b702a9c1b7 = 1;
						}

						echo 'Queue: ' . ($a9b7f153dce9637a + $Fdd6c7b702a9c1b7) . "\n";

						if (!($a9b7f153dce9637a == 0 && $Fdd6c7b702a9c1b7 == 0 && XUI::Ea4a2063E98bAEf8($D38e2b986fdab8eb, $F26087d31c2bbe4d))) {
						} else {
							echo 'Killing ID: ' . $F26087d31c2bbe4d . "\n";

							if (!(is_numeric($D38e2b986fdab8eb) && 0 < $D38e2b986fdab8eb)) {
							} else {
								posix_kill($D38e2b986fdab8eb, 9);
							}

							if (!(is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
							} else {
								posix_kill($f9b07d216a168dcc, 9);
							}

							shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*');
							$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `bitrate` = NULL,`current_source` = NULL,`to_analyze` = 0,`pid` = NULL,`stream_started` = NULL,`stream_info` = NULL,`audio_codec` = NULL,`video_codec` = NULL,`resolution` = NULL,`compatible` = 0,`stream_status` = 0,`monitor_pid` = NULL WHERE `stream_id` = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);
							$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', $F7c88f6ca9c78acc, time(), json_encode(array('type' => 'update_stream', 'id' => $F26087d31c2bbe4d)));
							unlink(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d));
							XUI::afa0f3FFb001b9bE($F26087d31c2bbe4d);
						}
					}
				}
			}

			usleep(1000000);
		} else {
			echo 'On-Demand - Instant Off setting is disabled.' . "\n";

			exit();
		}
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}
