<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc) {
		set_time_limit(0);
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		shell_exec('kill -9 $(ps aux | grep signals | grep -v grep | grep -v ' . getmypid() . " | awk '{print \$2}')");
		$Af547236269d8f66 = null;
		$F2319168a4d07d06 = 60;
		$Ba344b2758e3e955 = md5_file(__FILE__);

		if (!XUI::$rSettings['redis_handler']) {
		} else {
			XUI::bFA8B6fE314dEd7F();
		}

		while (true && $Fee0d5a474c96306 && $Fee0d5a474c96306->ping()) {
			if ($Af547236269d8f66 && $F2319168a4d07d06 > time() - $Af547236269d8f66) {
			} else {
				if (XUI::cae8387EDC1bF201()) {
					if (md5_file(__FILE__) == $Ba344b2758e3e955) {
						XUI::$rSettings = XUI::D761E78DA5EB70fB(true);
						XUI::$rServers = XUI::F99D78E199d641d5(true);
						$Af547236269d8f66 = time();
					} else {
						echo 'File changed! Break.' . "\n";
					}
				} else {
					echo 'Not running! Break.' . "\n";
				}
			}

			if (!(XUI::$rSettings['redis_handler'] && (!XUI::$redis || !XUI::$redis->ping())) && $Fee0d5a474c96306->query('SELECT `signal_id`, `pid`, `rtmp` FROM `signals` WHERE `server_id` = ? AND `pid` IS NOT NULL ORDER BY `signal_id` ASC LIMIT 100', SERVER_ID)) {
				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$Aa8c918a2a91966f = array();

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$Aa8c918a2a91966f[] = $C740da31596f24ef['signal_id'];
						$f9b07d216a168dcc = $C740da31596f24ef['pid'];

						if ($C740da31596f24ef['rtmp'] == 0) {
							if (!(!empty($f9b07d216a168dcc) && file_exists('/proc/' . $f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
							} else {
								shell_exec('kill -9 ' . intval($f9b07d216a168dcc));
							}
						} else {
							shell_exec('wget --timeout=2 -O /dev/null -o /dev/null "' . XUI::$rServers[SERVER_ID]['rtmp_mport_url'] . 'control/drop/client?clientid=' . intval($f9b07d216a168dcc) . '" >/dev/null 2>/dev/null &');
						}
					}

					if (0 >= count($Aa8c918a2a91966f)) {
					} else {
						$Fee0d5a474c96306->query('DELETE FROM `signals` WHERE `signal_id` IN (' . implode(',', $Aa8c918a2a91966f) . ')');
					}
				}

				if ($Fee0d5a474c96306->query('SELECT `signal_id`, `custom_data` FROM `signals` WHERE `server_id` = ? AND `cache` = 1 ORDER BY `signal_id` ASC LIMIT 1000;', SERVER_ID)) {
					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$Fbb12c3063b3cc3f = $dd27c5981328b568 = $c121727b49ad2f87 = $Aa8c918a2a91966f = array();

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$Bccc89fc1174404a = json_decode($C740da31596f24ef['custom_data'], true);
							$Aa8c918a2a91966f[] = $C740da31596f24ef['signal_id'];

							switch ($Bccc89fc1174404a['type']) {
								case 'update_stream':
									if (in_array($Bccc89fc1174404a['id'], $dd27c5981328b568)) {
									} else {
										$dd27c5981328b568[] = $Bccc89fc1174404a['id'];
									}

									break;

								case 'update_line':
									if (in_array($Bccc89fc1174404a['id'], $c121727b49ad2f87)) {
									} else {
										$c121727b49ad2f87[] = $Bccc89fc1174404a['id'];
									}

									break;

								case 'update_streams':
									foreach ($Bccc89fc1174404a['id'] as $C3c8913edb801c35) {
										if (in_array($C3c8913edb801c35, $dd27c5981328b568)) {
										} else {
											$dd27c5981328b568[] = $C3c8913edb801c35;
										}
									}

									break;

								case 'update_lines':
									foreach ($Bccc89fc1174404a['id'] as $C3c8913edb801c35) {
										if (in_array($C3c8913edb801c35, $c121727b49ad2f87)) {
										} else {
											$c121727b49ad2f87[] = $C3c8913edb801c35;
										}
									}

									break;

								case 'delete_con':
									unlink(CONS_TMP_PATH . $Bccc89fc1174404a['uuid']);

									break;

								case 'delete_vod':
									exec('rm ' . XUI_HOME . 'content/vod/' . intval($Bccc89fc1174404a['id']) . '.*');

									break;

								case 'delete_vods':
									foreach ($Bccc89fc1174404a['id'] as $C3c8913edb801c35) {
										exec('rm ' . XUI_HOME . 'content/vod/' . intval($C3c8913edb801c35) . '.*');
									}

									break;
							}
						}

						if (0 >= count($dd27c5981328b568)) {
						} else {
							shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php "streams_update" "' . implode(',', $dd27c5981328b568) . '"');
						}

						if (0 >= count($c121727b49ad2f87)) {
						} else {
							shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php "lines_update" "' . implode(',', $c121727b49ad2f87) . '"');
						}

						if (0 >= count($Aa8c918a2a91966f)) {
						} else {
							$Fee0d5a474c96306->query('DELETE FROM `signals` WHERE `signal_id` IN (' . implode(',', $Aa8c918a2a91966f) . ')');
						}
					}

					if (!XUI::$rSettings['redis_handler']) {
					} else {
						$fc8236a28ea7ebdd = array();

						foreach (XUI::$redis->sMembers('SIGNALS#' . SERVER_ID) as $D3fa098be3f297cd) {
							$fc8236a28ea7ebdd[] = $D3fa098be3f297cd;
						}

						if (0 >= count($fc8236a28ea7ebdd)) {
						} else {
							$add193137cabeea7 = XUI::$redis->mGet($fc8236a28ea7ebdd);
							$Aa8c918a2a91966f = array();

							foreach ($add193137cabeea7 as $a27e64cc6ce01033) {
								$C740da31596f24ef = igbinary_unserialize($a27e64cc6ce01033);
								$Aa8c918a2a91966f[] = $C740da31596f24ef['key'];
								$f9b07d216a168dcc = $C740da31596f24ef['pid'];

								if ($C740da31596f24ef['rtmp'] == 0) {
									if (!(!empty($f9b07d216a168dcc) && file_exists('/proc/' . $f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
									} else {
										shell_exec('kill -9 ' . intval($f9b07d216a168dcc));
									}
								} else {
									shell_exec('wget --timeout=2 -O /dev/null -o /dev/null "' . XUI::$rServers[SERVER_ID]['rtmp_mport_url'] . 'control/drop/client?clientid=' . intval($f9b07d216a168dcc) . '" >/dev/null 2>/dev/null &');
								}
							}
							XUI::$redis->multi()->del($Aa8c918a2a91966f)->sRem('SIGNALS#' . SERVER_ID, ...$fc8236a28ea7ebdd)->exec();
						}
					}

					usleep(250000);
				}

				break;
			}
		}

		if (!is_object($Fee0d5a474c96306)) {
		} else {
			$Fee0d5a474c96306->close_mysql();
		}

		shell_exec('(sleep 1; ' . PHP_BIN . ' ' . __FILE__ . ' ) > /dev/null 2>/dev/null &');
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}
