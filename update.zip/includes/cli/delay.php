<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'xui') {
	if ($argc && $argc > 1) {
		$F26087d31c2bbe4d = intval($argv[1]);
		$A32715b141f929f2 = 0;
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		d60457acfd5df5c9($F26087d31c2bbe4d);
		set_time_limit(0);
		cli_set_process_title('XUIDelay[' . $F26087d31c2bbe4d . ']');
		fdc97512d22b990e();
	} else {
		exit(0);
	}
} else {
	exit('Please run as XUI!' . "\n");
}

function E331a7E7a432981A()
{
	global $F26087d31c2bbe4d;
	global $A32715b141f929f2;
	shell_exec('find ' . DELAY_PATH . intval($F26087d31c2bbe4d) . '_*' . ' -type f -cmin +' . $A32715b141f929f2 . ' -delete');
}

function FAD51cF3d53DB648($Af165d3b11356e16)
{
	global $F26087d31c2bbe4d;

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $Af165d3b11356e16 . '.ts')) {
	} else {
		unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $Af165d3b11356e16 . '.ts');
	}

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $Af165d3b11356e16 . '.ts.enc')) {
	} else {
		unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $Af165d3b11356e16 . '.ts.enc');
	}
}

function f81203765833802F($B84c90216a28f6cf, &$Dddf4a2545dfe5a5, $cef7095c03f82513)
{
	$Bffc17a99eb14fd6 = array();

	if (empty($Dddf4a2545dfe5a5)) {
	} else {
		$Bffc17a99eb14fd6 = array_shift($Dddf4a2545dfe5a5);
		unlink(DELAY_PATH . $Bffc17a99eb14fd6['file']);
		$Ea22c4a9ab5b2176 = 0;

		while ($Ea22c4a9ab5b2176 < $cef7095c03f82513 && $Ea22c4a9ab5b2176 < count($Dddf4a2545dfe5a5)) {
			$Bffc17a99eb14fd6[] = $Dddf4a2545dfe5a5[$Ea22c4a9ab5b2176];
			$Ea22c4a9ab5b2176++;
		}
		$Dddf4a2545dfe5a5 = array_values($Dddf4a2545dfe5a5);
		$Bffc17a99eb14fd6 = array_shift($Dddf4a2545dfe5a5);
		a73efc2365956054($Dddf4a2545dfe5a5);
	}

	if (!file_exists($B84c90216a28f6cf)) {
	} else {
		$Bffc17a99eb14fd6 = array_merge($Bffc17a99eb14fd6, fA7937f615CAa67c($B84c90216a28f6cf, $cef7095c03f82513 - count($Bffc17a99eb14fd6)));
	}

	return $Bffc17a99eb14fd6;
}

function a73EFC2365956054($Dddf4a2545dfe5a5)
{
	global $E5e1cde94319b510;

	if (!empty($Dddf4a2545dfe5a5)) {
		$a27e64cc6ce01033 = '';

		foreach ($Dddf4a2545dfe5a5 as $d55bf693d0ece21c) {
			$a27e64cc6ce01033 .= '#EXTINF:' . $d55bf693d0ece21c['seconds'] . ',' . "\n" . $d55bf693d0ece21c['file'] . "\n";
		}
		file_put_contents($E5e1cde94319b510, $a27e64cc6ce01033, LOCK_EX);
	} else {
		unlink($E5e1cde94319b510);
	}
}

function Fa7937f615caA67c($bb62005ea7eb8380, $Bd7904d19ddefff3 = 0)
{
	$Bffc17a99eb14fd6 = array();

	if (!file_exists($bb62005ea7eb8380)) {
	} else {
		$e1644d67f855686d = fopen($bb62005ea7eb8380, 'r');

		while (!feof($e1644d67f855686d) && count($Bffc17a99eb14fd6) != $Bd7904d19ddefff3) {
			$Ff014d0ebd314fcd = trim(fgets($e1644d67f855686d));

			if (!stristr($Ff014d0ebd314fcd, 'EXTINF')) {
			} else {
				list($B3959f269ff4468b, $eff3c5536b319f0b) = explode(':', $Ff014d0ebd314fcd);
				$eff3c5536b319f0b = rtrim($eff3c5536b319f0b, ',');
				$E8601dd191bcdbba = trim(fgets($e1644d67f855686d));

				if (!file_exists(DELAY_PATH . $E8601dd191bcdbba)) {
				} else {
					$Bffc17a99eb14fd6[] = array('seconds' => $eff3c5536b319f0b, 'file' => $E8601dd191bcdbba);
				}
			}
		}
		fclose($e1644d67f855686d);
	}

	return $Bffc17a99eb14fd6;
}

function D60457ACfd5df5c9($F26087d31c2bbe4d)
{
	clearstatcache(true);

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor_delay')) {
	} else {
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor_delay'));
	}

	if (empty($f9b07d216a168dcc)) {
		shell_exec("kill -9 `ps -ef | grep 'XUIDelay\\[" . intval($F26087d31c2bbe4d) . "\\]' | grep -v grep | awk '{print \$2}'`;");
	} else {
		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			if (!($cf1c389bda3e30fd == 'XUIDelay[' . $F26087d31c2bbe4d . ']' && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}
	}

	file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor_delay', getmypid());
}

function FDc97512d22B990E()
{
	global $Fee0d5a474c96306;
	global $F26087d31c2bbe4d;
	global $A32715b141f929f2;
	$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.server_id = ? WHERE t1.id = ?', SERVER_ID, $F26087d31c2bbe4d);

	if ($Fee0d5a474c96306->num_rows() > 0) {
		$bb0071da5a239b0c = $Fee0d5a474c96306->get_row();

		if (!($bb0071da5a239b0c['delay_minutes'] == 0 || $bb0071da5a239b0c['parent_id'])) {
			$f9b07d216a168dcc = (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid') ? intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) : $bb0071da5a239b0c['pid']);
			$bb62005ea7eb8380 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8';
			$B84c90216a28f6cf = DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8';
			$E5e1cde94319b510 = DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8_old';
			$Fee0d5a474c96306->query('UPDATE `streams_servers` SET delay_pid = ? WHERE stream_id = ? AND server_id = ?', getmypid(), $F26087d31c2bbe4d, SERVER_ID);
			XUI::AfA0f3FFb001b9be($bb0071da5a239b0c['id']);
			$Fee0d5a474c96306->close_mysql();
			$A32715b141f929f2 = intval($bb0071da5a239b0c['delay_minutes']) + 5;
			e331a7e7a432981a();
			$cef7095c03f82513 = intval(XUI::$rSegmentSettings['seg_list_size']) + 5;
			$Dddf4a2545dfe5a5 = array();

			if (!file_exists($E5e1cde94319b510)) {
			} else {
				$Dddf4a2545dfe5a5 = fa7937f615caa67c($E5e1cde94319b510, -1);
			}

			$e9086056b8cf9430 = null;
			$Ba344b2758e3e955 = md5(file_get_contents($B84c90216a28f6cf));

			while (XUI::F74fa4748B081619($f9b07d216a168dcc, $F26087d31c2bbe4d) && file_exists($B84c90216a28f6cf)) {
				if ($Ba344b2758e3e955 == $e9086056b8cf9430) {
				} else {
					if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur')) {
					} else {
						$C5034884ed44603a = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur'));

						if (XUI::$rSegmentSettings['seg_time'] >= $C5034884ed44603a) {
						} else {
							XUI::$rSegmentSettings['seg_time'] = $C5034884ed44603a;
						}
					}

					$dc05e2bb97d4635d = array('vars' => array('#EXTM3U' => '', '#EXT-X-VERSION' => 3, '#EXT-X-MEDIA-SEQUENCE' => '0', '#EXT-X-TARGETDURATION' => XUI::$rSegmentSettings['seg_time']), 'segments' => f81203765833802f($B84c90216a28f6cf, $Dddf4a2545dfe5a5, $cef7095c03f82513));

					if (empty($dc05e2bb97d4635d['segments'])) {
					} else {
						$a27e64cc6ce01033 = '';
						$Af165d3b11356e16 = 0;

						if (!preg_match('/.*\\_(.*?)\\.ts/', $dc05e2bb97d4635d['segments'][0]['file'], $b85ce31cd1118ad2)) {
						} else {
							$Af165d3b11356e16 = intval($b85ce31cd1118ad2[1]);
						}

						$dc05e2bb97d4635d['vars']['#EXT-X-MEDIA-SEQUENCE'] = $Af165d3b11356e16;

						foreach ($dc05e2bb97d4635d['vars'] as $D3fa098be3f297cd => $b6842cb20051e925) {
							$a27e64cc6ce01033 .= (!empty($b6842cb20051e925) ? $D3fa098be3f297cd . ':' . $b6842cb20051e925 . "\n" : $D3fa098be3f297cd . "\n");
						}

						foreach ($dc05e2bb97d4635d['segments'] as $d55bf693d0ece21c) {
							copy(DELAY_PATH . $d55bf693d0ece21c['file'], STREAMS_PATH . $d55bf693d0ece21c['file']);
							$a27e64cc6ce01033 .= '#EXTINF:' . $d55bf693d0ece21c['seconds'] . ',' . "\n" . $d55bf693d0ece21c['file'] . "\n";
						}
						file_put_contents($bb62005ea7eb8380, $a27e64cc6ce01033, LOCK_EX);
						$Ba344b2758e3e955 = $e9086056b8cf9430;
						fad51cf3d53db648($Af165d3b11356e16 - 2);
						e331a7e7a432981a();
					}
				}

				usleep(1000);
				$e9086056b8cf9430 = md5(file_get_contents($B84c90216a28f6cf));
			}
		} else {
			exit();
		}
	} else {
		exit();
	}
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
