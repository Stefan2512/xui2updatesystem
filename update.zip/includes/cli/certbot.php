<?php

if (posix_getpwuid(posix_geteuid())['name'] == 'root') {
	if ($argc && $argc > 1) {
		register_shutdown_function('shutdown');
		require str_replace('\\', '/', dirname($argv[0])) . '/../../www/init.php';
		fdc97512d22b990e();
	} else {
		exit(0);
	}
} else {
	exit('Please run as root!' . "\n");
}

function fdC97512d22b990e()
{
	global $Fee0d5a474c96306;
	global $argv;
	$a27e64cc6ce01033 = json_decode(base64_decode($argv[1]), true);

	if ($a27e64cc6ce01033['action'] != 'certbot_generate') {
	} else {
		if (!file_exists(BIN_PATH . 'certbot/logs/xui.log')) {
		} else {
			unlink(BIN_PATH . 'certbot/logs/xui.log');
		}

		foreach (array('logs', 'config', 'work') as $Bc16cc77a681d1ed) {
			if (!file_exists(BIN_PATH . 'certbot/' . $Bc16cc77a681d1ed . '/.certbot.lock')) {
			} else {
				unlink(BIN_PATH . 'certbot/' . $Bc16cc77a681d1ed . '/.certbot.lock');
			}
		}
		$a49e7ec37dea8acb = array();

		foreach ($a27e64cc6ce01033['domain'] as $Caecf2bcd39a1efe) {
			if (filter_var($Caecf2bcd39a1efe, FILTER_VALIDATE_IP)) {
			} else {
				$a49e7ec37dea8acb[] = $Caecf2bcd39a1efe;
			}
		}
		$D370fc32f973c6ca = null;
		$f433193a3297ffde = array();
		$B59c127fecf35c15 = false;

		if (0 < count($a49e7ec37dea8acb)) {
			foreach (array('--dry-run ', '') as $b47c04c07a64a010) {
				if (XUI::$rServers[SERVER_ID]['http_broadcast_port'] == 80) {
					$cf1c389bda3e30fd = 'sudo certbot ' . $b47c04c07a64a010 . '--config-dir ' . BIN_PATH . 'certbot/config --work-dir ' . BIN_PATH . 'certbot/work --logs-dir ' . BIN_PATH . 'certbot/logs certonly --agree-tos --expand --non-interactive --register-unsafely-without-email --webroot -w /home/xui/www/';
				} else {
					$cf1c389bda3e30fd = 'sudo certbot ' . $b47c04c07a64a010 . '--config-dir ' . BIN_PATH . 'certbot/config --work-dir ' . BIN_PATH . 'certbot/work --logs-dir ' . BIN_PATH . 'certbot/logs certonly --agree-tos --expand --non-interactive --register-unsafely-without-email --standalone';
				}

				foreach ($a49e7ec37dea8acb as $Caecf2bcd39a1efe) {
					$cf1c389bda3e30fd .= ' -d ' . basename($Caecf2bcd39a1efe);
				}
				$cf1c389bda3e30fd .= ' 2>&1';
				$f433193a3297ffde = array();
				exec($cf1c389bda3e30fd, $f433193a3297ffde, $a85e1b7d42c346a0);

				if (empty($b47c04c07a64a010)) {
					if (stripos(implode("\n", $f433193a3297ffde), 'certificate and chain have been saved at') !== false) {
						$aba46ae86a79ad10 = null;

						foreach ($f433193a3297ffde as $Ff014d0ebd314fcd) {
							$aba46ae86a79ad10 = pathinfo($Ff014d0ebd314fcd)['dirname'];

							break;
						}

						if ($aba46ae86a79ad10) {
							$dd6503a196807aba = $aba46ae86a79ad10 . '/fullchain.pem';
							$A311e01d0d2204f5 = $aba46ae86a79ad10 . '/chain.pem';
							$ed1a16bf1663489b = $aba46ae86a79ad10 . '/privkey.pem';

							if (file_exists($dd6503a196807aba) && file_exists($A311e01d0d2204f5) && file_exists($ed1a16bf1663489b)) {
								$ac6f08557ea30532 = 'ssl_certificate ' . $dd6503a196807aba . ';' . "\n" . 'ssl_certificate_key ' . $ed1a16bf1663489b . ';' . "\n" . 'ssl_trusted_certificate ' . $A311e01d0d2204f5 . ';' . "\n" . 'ssl_protocols TLSv1.2 TLSv1.3;' . "\n" . 'ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;' . "\n" . 'ssl_prefer_server_ciphers off;' . "\n" . 'ssl_ecdh_curve auto;' . "\n" . 'ssl_session_timeout 10m;' . "\n" . 'ssl_session_cache shared:MozSSL:10m;' . "\n" . 'ssl_session_tickets off;';
								file_put_contents(BIN_PATH . 'nginx/conf/ssl.conf', $ac6f08557ea30532);
								shell_exec('chown xui:xui ' . BIN_PATH . 'nginx/conf/ssl.conf');
								$Eea1b980ebbe2a33 = XUI::AC86C84c80e63449();

								if (!$Eea1b980ebbe2a33['serial']) {
								} else {
									$Fee0d5a474c96306->query('UPDATE `servers` SET `certbot_ssl` = ? WHERE `id` = ?;', json_encode($Eea1b980ebbe2a33), SERVER_ID);
								}

								$B59c127fecf35c15 = true;
							} else {
								echo 'Error: Failed to generate certificate!' . "\n";
								$D370fc32f973c6ca = 0;
							}
						} else {
							echo 'Error: Failed to generate certificate!' . "\n";
							$D370fc32f973c6ca = 0;
						}
					} else {
						if (stripos(implode("\n", $f433193a3297ffde), 'cert not yet due for renewal') !== false) {
							echo 'Warning: Certificate not due for renewal!' . "\n";
							$D370fc32f973c6ca = 1;
						} else {
							echo 'Error: An error occured!' . "\n";
							$D370fc32f973c6ca = 2;
						}
					}
				} else {
					if (stripos(implode("\n", $f433193a3297ffde), 'the dry run was successful') !== false) {
						echo 'Dry run successful!' . "\n";
					} else {
						echo 'Error: Dry run failed!' . "\n";
						$D370fc32f973c6ca = 4;

						break;
					}
				}
			}
		} else {
			$D370fc32f973c6ca = 3;
		}

		if (!in_array($D370fc32f973c6ca, array(0, 1))) {
		} else {
			$Fee0d5a474c96306->query('SELECT `certbot_ssl` FROM `servers` WHERE `id` = ?;', SERVER_ID);
			$D45fcf69dd0222c8 = json_decode($Fee0d5a474c96306->get_row()['certbot_ssl'], true);

			if ($D45fcf69dd0222c8) {
			} else {
				$f4ef4c280f9e62e8 = array(null, null);

				foreach (scandir(BIN_PATH . 'certbot/config/live/') as $B8dc4ba72c7d3095) {
					if (!($B8dc4ba72c7d3095 != '.' && $B8dc4ba72c7d3095 != '..')) {
					} else {
						$B211d7401e6242f3 = explode('-', $B8dc4ba72c7d3095);

						if (is_numeric($B211d7401e6242f3[count($B211d7401e6242f3) - 1])) {
							$Caecf2bcd39a1efe = implode('-', array_slice($B211d7401e6242f3, 0, count($B211d7401e6242f3) - 1));
						} else {
							$Caecf2bcd39a1efe = $B8dc4ba72c7d3095;
						}

						if (!in_array(strtolower($Caecf2bcd39a1efe), array_map('strtolower', $a49e7ec37dea8acb))) {
						} else {
							$Eea1b980ebbe2a33 = XUI::aC86c84C80E63449(BIN_PATH . 'certbot/config/live/' . $B8dc4ba72c7d3095 . '/fullchain.pem');

							if (!($Eea1b980ebbe2a33['serial'] && $f4ef4c280f9e62e8[0] < $Eea1b980ebbe2a33['expiration']) && $f4ef4c280f9e62e8[0]) {
							} else {
								$f4ef4c280f9e62e8 = array($Eea1b980ebbe2a33['expiration'], $Eea1b980ebbe2a33);
							}
						}
					}
				}

				if (!$f4ef4c280f9e62e8[0]) {
				} else {
					$aba46ae86a79ad10 = $f4ef4c280f9e62e8[1]['path'];
					$dd6503a196807aba = $aba46ae86a79ad10 . '/fullchain.pem';
					$A311e01d0d2204f5 = $aba46ae86a79ad10 . '/chain.pem';
					$ed1a16bf1663489b = $aba46ae86a79ad10 . '/privkey.pem';

					if (!(file_exists($dd6503a196807aba) && file_exists($A311e01d0d2204f5) && file_exists($ed1a16bf1663489b))) {
					} else {
						$ac6f08557ea30532 = 'ssl_certificate ' . $dd6503a196807aba . ';' . "\n" . 'ssl_certificate_key ' . $ed1a16bf1663489b . ';' . "\n" . 'ssl_trusted_certificate ' . $A311e01d0d2204f5 . ';' . "\n" . 'ssl_protocols TLSv1.2 TLSv1.3;' . "\n" . 'ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;' . "\n" . 'ssl_prefer_server_ciphers off;' . "\n" . 'ssl_ecdh_curve auto;' . "\n" . 'ssl_session_timeout 10m;' . "\n" . 'ssl_session_cache shared:MozSSL:10m;' . "\n" . 'ssl_session_tickets off;';
						file_put_contents(BIN_PATH . 'nginx/conf/ssl.conf', $ac6f08557ea30532);
						shell_exec('chown xui:xui ' . BIN_PATH . 'nginx/conf/ssl.conf');
						$Fee0d5a474c96306->query('UPDATE `servers` SET `certbot_ssl` = ? WHERE `id` = ?;', json_encode($f4ef4c280f9e62e8[1]), SERVER_ID);
						$B59c127fecf35c15 = true;
					}
				}
			}
		}

		$a85e1b7d42c346a0 = array('status' => $B59c127fecf35c15, 'error' => $D370fc32f973c6ca, 'output' => $f433193a3297ffde);
		shell_exec('chown -R xui:xui ' . BIN_PATH . 'certbot/');
		file_put_contents(BIN_PATH . 'certbot/logs/xui.log', json_encode($a85e1b7d42c346a0));

		if (!$B59c127fecf35c15) {
		} else {
			shell_exec(XUI_HOME . 'service reload');
		}

		shell_exec(PHP_BIN . ' ' . CRON_PATH . 'certbot.php 1 > /dev/null 2>/dev/null &');
	}
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
