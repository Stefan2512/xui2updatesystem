<?php

class API
{
	public static $db = null;
	public static $rSettings = array();
	public static $rServers = array();
	public static $rProxyServers = array();
	public static $rUserInfo = array();

	public static function init($D78ff1d0edade5eb = null)
	{
		self::$rSettings = A5Fc308345057e29();
		self::$rServers = F6da964066F2f5E4();
		self::$rProxyServers = a4338a704A6a7789();

		if ($D78ff1d0edade5eb || !isset($_SESSION['hash'])) {
		} else {
			$D78ff1d0edade5eb = $_SESSION['hash'];
		}

		if (!$D78ff1d0edade5eb) {
		} else {
			self::$rUserInfo = FE76C4BcaF81Baa4($D78ff1d0edade5eb);
		}
	}

	private static function F228E3d146E758b1($a27e64cc6ce01033)
	{
		switch (debug_backtrace()[1]['function']) {
			case 'scheduleRecording':
				return !empty($a27e64cc6ce01033['title']) && !empty($a27e64cc6ce01033['source_id']);

			case 'processProvider':
				return !empty($a27e64cc6ce01033['ip']) && !empty($a27e64cc6ce01033['port']) && !empty($a27e64cc6ce01033['username']) && !empty($a27e64cc6ce01033['password']) && !empty($a27e64cc6ce01033['name']);

			case 'processBouquet':
				return !empty($a27e64cc6ce01033['bouquet_name']);

			case 'processGroup':
				return !empty($a27e64cc6ce01033['group_name']);

			case 'processPackage':
				return !empty($a27e64cc6ce01033['package_name']);

			case 'processCategory':
				return !empty($a27e64cc6ce01033['category_name']) && !empty($a27e64cc6ce01033['category_type']);

			case 'processCode':
				return !empty($a27e64cc6ce01033['code']);

			case 'reorderBouquet':
			case 'setChannelOrder':
				return is_array(json_decode($a27e64cc6ce01033['stream_order_array'], true));

			case 'sortBouquets':
				return is_array(json_decode($a27e64cc6ce01033['bouquet_order_array'], true));

			case 'blockIP':
			case 'processRTMPIP':
				return !empty($a27e64cc6ce01033['ip']);

			case 'processChannel':
			case 'processStream':
			case 'processMovie':
			case 'processRadio':
				return !empty($a27e64cc6ce01033['stream_display_name']) || isset($a27e64cc6ce01033['review']) || isset($_FILES['m3u_file']);

			case 'processEpisode':
				return !empty($a27e64cc6ce01033['series']) && is_numeric($a27e64cc6ce01033['season_num']) && is_numeric($a27e64cc6ce01033['episode']);

			case 'processSeries':
				return !empty($a27e64cc6ce01033['title']);

			case 'processEPG':
				return !empty($a27e64cc6ce01033['epg_name']) && !empty($a27e64cc6ce01033['epg_file']);

			case 'massEditEpisodes':
			case 'massEditMovies':
			case 'massEditRadios':
			case 'massEditStreams':
			case 'massEditChannels':
			case 'massDeleteStreams':
				return is_array(json_decode($a27e64cc6ce01033['streams'], true));

			case 'massEditSeries':
			case 'massDeleteSeries':
				return is_array(json_decode($a27e64cc6ce01033['series'], true));

			case 'massEditLines':
			case 'massEditUsers':
				return is_array(json_decode($a27e64cc6ce01033['users_selected'], true));

			case 'massEditMags':
			case 'massEditEnigmas':
				return is_array(json_decode($a27e64cc6ce01033['devices_selected'], true));

			case 'processISP':
				return !empty($a27e64cc6ce01033['isp']);

			case 'massDeleteMovies':
				return is_array(json_decode($a27e64cc6ce01033['movies'], true));

			case 'massDeleteLines':
				return is_array(json_decode($a27e64cc6ce01033['lines'], true));

			case 'massDeleteUsers':
				return is_array(json_decode($a27e64cc6ce01033['users'], true));

			case 'massDeleteStations':
				return is_array(json_decode($a27e64cc6ce01033['radios'], true));

			case 'massDeleteMags':
				return is_array(json_decode($a27e64cc6ce01033['mags'], true));

			case 'massDeleteEnigmas':
				return is_array(json_decode($a27e64cc6ce01033['enigmas'], true));

			case 'massDeleteEpisodes':
				return is_array(json_decode($a27e64cc6ce01033['episodes'], true));

			case 'processMAG':
			case 'processEnigma':
				return !empty($a27e64cc6ce01033['mac']);

			case 'processProfile':
				return !empty($a27e64cc6ce01033['profile_name']);

			case 'processProxy':
			case 'processServer':
				return !empty($a27e64cc6ce01033['server_name']) && !empty($a27e64cc6ce01033['server_ip']);

			case 'installServer':
				return !empty($a27e64cc6ce01033['ssh_port']) && !empty($a27e64cc6ce01033['root_password']);

			case 'orderCategories':
				return is_array(json_decode($a27e64cc6ce01033['categories'], true));

			case 'orderServers':
				return is_array(json_decode($a27e64cc6ce01033['server_order'], true));

			case 'moveStreams':
				return !empty($a27e64cc6ce01033['content_type']) && !empty($a27e64cc6ce01033['source_server']) && !empty($a27e64cc6ce01033['replacement_server']);

			case 'replaceDNS':
				return !empty($a27e64cc6ce01033['old_dns']) && !empty($a27e64cc6ce01033['new_dns']);

			case 'processUA':
				return !empty($a27e64cc6ce01033['user_agent']);

			case 'processWatchFolder':
				return !empty($a27e64cc6ce01033['folder_type']) && !empty($a27e64cc6ce01033['selected_path']) && !empty($a27e64cc6ce01033['server_id']);
		}

		return true;
	}

	public static function c6cef67e40287e05($a27e64cc6ce01033)
	{
		global $_;

		if (self::f228E3D146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AACd47D8157A1A09('adv', 'edit_bouquet')) {
					$d49041d5f05a9270 = ebDaAFc1c10F9506(c8ADB574F9477F84($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AAcd47d8157A1a09('adv', 'add_bouquet')) {
					$d49041d5f05a9270 = b9DA5D708Fc1C079('bouquets', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (is_array(json_decode($a27e64cc6ce01033['bouquet_data'], true))) {
				$E38df3d8274b8751 = json_decode($a27e64cc6ce01033['bouquet_data'], true);
				$F5c13ea196d72c3e = $E38df3d8274b8751['stream'];
				$f70bd4c3ff51b9e5 = $E38df3d8274b8751['movies'];
				$A921a65a5475186f = $E38df3d8274b8751['radios'];
				$d06d5ff50606006c = $E38df3d8274b8751['series'];
				$e24e7ecdb6d1742e = confirmIDs(array_merge($F5c13ea196d72c3e, $f70bd4c3ff51b9e5, $A921a65a5475186f));
				$A2b85ede89f9df0c = array();

				if (0 >= count($e24e7ecdb6d1742e)) {
				} else {
					self::$db->query('SELECT `id`, `type` FROM `streams` WHERE `id` IN (' . implode(',', $e24e7ecdb6d1742e) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						if (intval($C740da31596f24ef['type']) != 3) {
						} else {
							$C740da31596f24ef['type'] = 1;
						}

						$A2b85ede89f9df0c[intval($C740da31596f24ef['type'])][] = intval($C740da31596f24ef['id']);
					}
				}

				if (0 >= count($d06d5ff50606006c)) {
				} else {
					self::$db->query('SELECT `id` FROM `streams_series` WHERE `id` IN (' . implode(',', $d06d5ff50606006c) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$A2b85ede89f9df0c[5][] = intval($C740da31596f24ef['id']);
					}
				}

				$d49041d5f05a9270['bouquet_channels'] = array_intersect(array_map('intval', array_values($F5c13ea196d72c3e)), $A2b85ede89f9df0c[1]);
				$d49041d5f05a9270['bouquet_movies'] = array_intersect(array_map('intval', array_values($f70bd4c3ff51b9e5)), $A2b85ede89f9df0c[2]);
				$d49041d5f05a9270['bouquet_radios'] = array_intersect(array_map('intval', array_values($A921a65a5475186f)), $A2b85ede89f9df0c[4]);
				$d49041d5f05a9270['bouquet_series'] = array_intersect(array_map('intval', array_values($d06d5ff50606006c)), $A2b85ede89f9df0c[5]);
			} else {
				if (!isset($a27e64cc6ce01033['edit'])) {
				} else {
					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}
			}

			if (isset($a27e64cc6ce01033['edit'])) {
			} else {
				self::$db->query('SELECT MAX(`bouquet_order`) AS `max` FROM `bouquets`;');
				$d49041d5f05a9270['bouquet_order'] = intval(self::$db->get_row()['max']) + 1;
			}

			$acd0eb2c8a975903 = F4817DC607d9981d($d49041d5f05a9270);
			$A6d7047f2fda966c = 'REPLACE INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

			if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
				b47820f6e3A74994($Fc2dc5a0ce8d07ea);

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			}

			return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function c26A6946575a9b88($a27e64cc6ce01033)
	{
		if (self::f228e3D146e758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = eBDaAfC1C10F9506(B49a6A53ABb5a42B($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				$a7fc478ffc10af80 = $d49041d5f05a9270['code'];
			} else {
				$d49041d5f05a9270 = b9Da5d708Fc1c079('access_codes', $a27e64cc6ce01033);
				$a7fc478ffc10af80 = null;
				unset($d49041d5f05a9270['id']);
			}

			if (isset($a27e64cc6ce01033['enabled'])) {
				$d49041d5f05a9270['enabled'] = 1;
			} else {
				$d49041d5f05a9270['enabled'] = 0;
			}

			if (!isset($a27e64cc6ce01033['groups'])) {
			} else {
				$d49041d5f05a9270['groups'] = array();

				foreach ($a27e64cc6ce01033['groups'] as $e41ee48af2b8e2a5) {
					$d49041d5f05a9270['groups'][] = intval($e41ee48af2b8e2a5);
				}
			}

			if (in_array($a27e64cc6ce01033['type'], array(0, 1, 3, 4))) {
				$d49041d5f05a9270['groups'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['groups'])) . ']';
			} else {
				$d49041d5f05a9270['groups'] = '[]';
			}

			if (isset($a27e64cc6ce01033['whitelist'])) {
			} else {
				$d49041d5f05a9270['whitelist'] = '[]';
			}

			if ($a27e64cc6ce01033['type'] != 2 && strlen($a27e64cc6ce01033['code']) < 8) {
				return array('status' => STATUS_CODE_LENGTH, 'data' => $a27e64cc6ce01033);
			}

			if ($a27e64cc6ce01033['type'] == 2 && empty($a27e64cc6ce01033['code'])) {
				return array('status' => STATUS_INVALID_CODE, 'data' => $a27e64cc6ce01033);
			}

			if (in_array($a27e64cc6ce01033['code'], array('admin', 'stream', 'images', 'player_api', 'player', 'playlist', 'epg', 'live', 'movie', 'series', 'status', 'nginx_status', 'get', 'panel_api', 'xmltv', 'probe', 'thumb', 'timeshift', 'auth', 'vauth', 'tsauth', 'hls', 'play', 'key', 'api', 'c'))) {
				return array('status' => STATUS_RESERVED_CODE, 'data' => $a27e64cc6ce01033);
			}

			if (isset($a27e64cc6ce01033['edit'])) {
				self::$db->query('SELECT `id` FROM `access_codes` WHERE `code` = ? AND `id` <> ?;', $a27e64cc6ce01033['code'], $a27e64cc6ce01033['edit']);
			} else {
				self::$db->query('SELECT `id` FROM `access_codes` WHERE `code` = ?;', $a27e64cc6ce01033['code']);
			}

			if (0 >= self::$db->num_rows()) {
				$acd0eb2c8a975903 = F4817Dc607d9981d($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `access_codes`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					B3c0272304A383CC();

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea, 'orig_code' => $a7fc478ffc10af80, 'new_code' => $a27e64cc6ce01033['code']));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_EXISTS_CODE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function d991Ba25E32737CE($a27e64cc6ce01033)
	{
		if (self::F228E3d146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = ebDaAfc1c10F9506(A69C1563c73E6d19($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = B9Da5d708FC1c079('hmac_keys', $a27e64cc6ce01033);
				unset($d49041d5f05a9270['id']);
			}

			if (isset($a27e64cc6ce01033['enabled'])) {
				$d49041d5f05a9270['enabled'] = 1;
			} else {
				$d49041d5f05a9270['enabled'] = 0;
			}

			if (!($a27e64cc6ce01033['keygen'] != 'HMAC KEY HIDDEN' && strlen($a27e64cc6ce01033['keygen']) != 32)) {
				if (strlen($a27e64cc6ce01033['notes']) != 0) {
					if (isset($a27e64cc6ce01033['edit'])) {
						if ($a27e64cc6ce01033['keygen'] == 'HMAC KEY HIDDEN') {
						} else {
							self::$db->query('SELECT `id` FROM `hmac_keys` WHERE `key` = ? AND `id` <> ?;', Xui\Functions::encrypt($a27e64cc6ce01033['keygen'], OPENSSL_EXTRA), $a27e64cc6ce01033['edit']);

							if (0 >= self::$db->num_rows()) {
							} else {
								return array('status' => STATUS_EXISTS_HMAC, 'data' => $a27e64cc6ce01033);
							}
						}
					} else {
						self::$db->query('SELECT `id` FROM `hmac_keys` WHERE `key` = ?;', Xui\Functions::encrypt($a27e64cc6ce01033['keygen'], OPENSSL_EXTRA));

						if (0 >= self::$db->num_rows()) {
						} else {
							return array('status' => STATUS_EXISTS_HMAC, 'data' => $a27e64cc6ce01033);
						}
					}

					if ($a27e64cc6ce01033['keygen'] == 'HMAC KEY HIDDEN') {
					} else {
						$d49041d5f05a9270['key'] = Xui\Functions::encrypt($a27e64cc6ce01033['keygen'], OPENSSL_EXTRA);
					}

					$acd0eb2c8a975903 = F4817DC607d9981d($d49041d5f05a9270);
					$A6d7047f2fda966c = 'REPLACE INTO `hmac_keys`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

						return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_NO_DESCRIPTION, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_NO_KEY, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function c6EBA7C2D99567E2($a27e64cc6ce01033)
	{
		if (self::F228E3d146e758B1($a27e64cc6ce01033)) {
			$c6c389b9adf3a40c = json_decode($a27e64cc6ce01033['stream_order_array'], true);
			$c6c389b9adf3a40c['stream'] = confirmIDs($c6c389b9adf3a40c['stream']);
			$c6c389b9adf3a40c['series'] = confirmIDs($c6c389b9adf3a40c['series']);
			$c6c389b9adf3a40c['movie'] = confirmIDs($c6c389b9adf3a40c['movie']);
			$c6c389b9adf3a40c['radio'] = confirmIDs($c6c389b9adf3a40c['radio']);
			self::$db->query('UPDATE `bouquets` SET `bouquet_channels` = ?, `bouquet_series` = ?, `bouquet_movies` = ?, `bouquet_radios` = ? WHERE `id` = ?;', '[' . implode(',', array_map('intval', $c6c389b9adf3a40c['stream'])) . ']', '[' . implode(',', array_map('intval', $c6c389b9adf3a40c['series'])) . ']', '[' . implode(',', array_map('intval', $c6c389b9adf3a40c['movie'])) . ']', '[' . implode(',', array_map('intval', $c6c389b9adf3a40c['radio'])) . ']', $a27e64cc6ce01033['reorder']);

			return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $a27e64cc6ce01033['reorder']));
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function e63650987aA344Ae($a27e64cc6ce01033)
	{
		if (self::f228E3D146E758B1($a27e64cc6ce01033)) {
			if (0 >= strlen($a27e64cc6ce01033['email']) || filter_var($a27e64cc6ce01033['email'], FILTER_VALIDATE_EMAIL)) {
				if (0 < strlen($a27e64cc6ce01033['password'])) {
					$d5249dad8e8411b7 = dF65d36Bea77aE8C($a27e64cc6ce01033['password']);
				} else {
					$d5249dad8e8411b7 = self::$rUserInfo['password'];
				}

				if (ctype_xdigit($a27e64cc6ce01033['api_key']) && strlen($a27e64cc6ce01033['api_key']) == 32) {
				} else {
					$a27e64cc6ce01033['api_key'] = '';
				}

				self::$db->query('UPDATE `users` SET `password` = ?, `email` = ?, `theme` = ?, `hue` = ?, `timezone` = ?, `api_key` = ? WHERE `id` = ?;', $d5249dad8e8411b7, $a27e64cc6ce01033['email'], $a27e64cc6ce01033['theme'], $a27e64cc6ce01033['hue'], $a27e64cc6ce01033['timezone'], $a27e64cc6ce01033['api_key'], self::$rUserInfo['id']);

				return array('status' => STATUS_SUCCESS);
			}

			return array('status' => STATUS_INVALID_EMAIL);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function c638Ad4f75Ff57A6($a27e64cc6ce01033)
	{
		if (self::f228e3D146E758b1($a27e64cc6ce01033)) {
			if (DDe0b761098cA92f($a27e64cc6ce01033['ip'])) {
				$d49041d5f05a9270 = array('ip' => $a27e64cc6ce01033['ip'], 'notes' => $a27e64cc6ce01033['notes'], 'date' => time());
				touch(FLOOD_TMP_PATH . 'block_' . $a27e64cc6ce01033['ip']);
				$acd0eb2c8a975903 = f4817DC607d9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `blocked_ips`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				} else {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
				}

				if (isset($Fc2dc5a0ce8d07ea)) {
					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_IP, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function Ba3868dC0Ef46144($a27e64cc6ce01033)
	{
		if (self::f228E3d146e758B1($a27e64cc6ce01033)) {
			set_time_limit(0);
			ini_set('mysql.connect_timeout', 0);
			ini_set('max_execution_time', 0);
			ini_set('default_socket_timeout', 0);
			$c6c389b9adf3a40c = json_decode($a27e64cc6ce01033['bouquet_order_array'], true);
			$C506f7e1a1b97909 = 1;

			foreach ($c6c389b9adf3a40c as $C52c0b6b0f74407b) {
				self::$db->query('UPDATE `bouquets` SET `bouquet_order` = ? WHERE `id` = ?;', $C506f7e1a1b97909, $C52c0b6b0f74407b);
				$C506f7e1a1b97909++;
			}

			if (isset($a27e64cc6ce01033['confirmReplace'])) {
				$B963b5d49ca08acf = A7526a151f645414();

				foreach ($B963b5d49ca08acf as $d51e425eb7375255) {
					$ddf0508b312dbfb8 = json_decode($d51e425eb7375255['bouquet'], true);
					$ddf0508b312dbfb8 = array_map('intval', sortArrayByArray($ddf0508b312dbfb8, $c6c389b9adf3a40c));
					self::$db->query('UPDATE `lines` SET `bouquet` = ? WHERE `id` = ?;', '[' . implode(',', $ddf0508b312dbfb8) . ']', $d51e425eb7375255['id']);
					XUI::bc77EdC4169f1baa($d51e425eb7375255['id']);
				}
				$D57b432dc56eb885 = D19B453Ac8E32c50();

				foreach ($D57b432dc56eb885 as $fe06d74291ffa213) {
					$ddf0508b312dbfb8 = json_decode($fe06d74291ffa213['bouquets'], true);
					$ddf0508b312dbfb8 = array_map('intval', sortArrayByArray($ddf0508b312dbfb8, $c6c389b9adf3a40c));
					self::$db->query('UPDATE `users_packages` SET `bouquets` = ? WHERE `id` = ?;', '[' . implode(',', $ddf0508b312dbfb8) . ']', $fe06d74291ffa213['id']);
				}

				return array('status' => STATUS_SUCCESS_REPLACE);
			} else {
				return array('status' => STATUS_SUCCESS);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function B09A32c4530444E9($a27e64cc6ce01033)
	{
		if (self::f228e3D146E758B1($a27e64cc6ce01033)) {
			set_time_limit(0);
			ini_set('mysql.connect_timeout', 0);
			ini_set('max_execution_time', 0);
			ini_set('default_socket_timeout', 0);
			$c6c389b9adf3a40c = json_decode($a27e64cc6ce01033['stream_order_array'], true);
			$C506f7e1a1b97909 = 0;

			foreach ($c6c389b9adf3a40c as $f523e362fb81d6c8) {
				self::$db->query('UPDATE `streams` SET `order` = ? WHERE `id` = ?;', $C506f7e1a1b97909, $f523e362fb81d6c8);
				$C506f7e1a1b97909++;
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function f3b2BE29C4Dd0B5E($a27e64cc6ce01033)
	{
		if (self::F228E3D146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (aAcd47D8157A1a09('adv', 'edit_cchannel')) {
					$d49041d5f05a9270 = eBDAAFc1C10F9506(E5eCEB32F67d5e70($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AaCd47d8157A1a09('adv', 'create_channel')) {
					$d49041d5f05a9270 = b9dA5d708fC1c079('streams', $a27e64cc6ce01033);
					$d49041d5f05a9270['type'] = 3;
					$d49041d5f05a9270['added'] = time();
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (isset($a27e64cc6ce01033['restart_on_edit'])) {
				$d81f27c553f73ff4 = true;
			} else {
				$d81f27c553f73ff4 = false;
			}

			if (isset($a27e64cc6ce01033['reencode_on_edit'])) {
				$c603fc1460f6e6b1 = true;
			} else {
				$c603fc1460f6e6b1 = false;
			}

			foreach (array('allow_record', 'rtmp_output') as $D3fa098be3f297cd) {
				if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
				} else {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
				}
			}
			$d49041d5f05a9270['movie_properties'] = array('type' => intval($a27e64cc6ce01033['channel_type']));

			if (intval($a27e64cc6ce01033['channel_type']) == 0) {
				$bb62005ea7eb8380 = a239Ff4055fAa462($a27e64cc6ce01033['series_no']);
				$d49041d5f05a9270['stream_source'] = $bb62005ea7eb8380;
				$d49041d5f05a9270['series_no'] = intval($a27e64cc6ce01033['series_no']);
			} else {
				$d49041d5f05a9270['stream_source'] = $a27e64cc6ce01033['video_files'];
				$d49041d5f05a9270['series_no'] = 0;
			}

			if ($a27e64cc6ce01033['transcode_profile_id'] == -1) {
				$d49041d5f05a9270['movie_symlink'] = 1;
			} else {
				$d49041d5f05a9270['movie_symlink'] = 0;
			}

			if (0 < count($d49041d5f05a9270['stream_source'])) {
				$f518050a6d5f89c7 = array();

				foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
					$acd0eb2c8a975903 = f4817dC607D9981d(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
					$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					} else {
						$C52c0b6b0f74407b = self::$db->last_insert_id();
						$f518050a6d5f89c7[$ddf0508b312dbfb8] = $C52c0b6b0f74407b;
					}
				}
				$Ae4bd014b3779489 = array();

				foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
					$acd0eb2c8a975903 = F4817Dc607D9981d(array('category_type' => 'live', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
					$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					} else {
						$Be965cdd996d4520 = self::$db->last_insert_id();
						$Ae4bd014b3779489[$A1925ae53e9307eb] = $Be965cdd996d4520;
					}
				}
				$cb498e4dcaac05cc = array();

				foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
					if (isset($f518050a6d5f89c7[$ddf0508b312dbfb8])) {
						$cb498e4dcaac05cc[] = $f518050a6d5f89c7[$ddf0508b312dbfb8];
					} else {
						if (!is_numeric($ddf0508b312dbfb8)) {
						} else {
							$cb498e4dcaac05cc[] = intval($ddf0508b312dbfb8);
						}
					}
				}
				$A5dcdeb6ecbbf6bd = array();

				foreach ($a27e64cc6ce01033['category_id'] as $A1925ae53e9307eb) {
					if (isset($Ae4bd014b3779489[$A1925ae53e9307eb])) {
						$A5dcdeb6ecbbf6bd[] = $Ae4bd014b3779489[$A1925ae53e9307eb];
					} else {
						if (!is_numeric($A1925ae53e9307eb)) {
						} else {
							$A5dcdeb6ecbbf6bd[] = intval($A1925ae53e9307eb);
						}
					}
				}
				$d49041d5f05a9270['category_id'] = '[' . implode(',', array_map('intval', $A5dcdeb6ecbbf6bd)) . ']';

				if (!self::$rSettings['download_images']) {
				} else {
					$d49041d5f05a9270['stream_icon'] = XUI::B2068CE8b339Bf70($d49041d5f05a9270['stream_icon'], 3);
				}

				if (isset($a27e64cc6ce01033['edit'])) {
				} else {
					$d49041d5f05a9270['order'] = Dc95637C2da3B543();
				}

				$acd0eb2c8a975903 = F4817Dc607d9981d($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					$F9163b7e6a33fe89 = array();

					if (!isset($a27e64cc6ce01033['edit'])) {
					} else {
						self::$db->query('SELECT `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

						foreach (self::$db->get_rows() as $C740da31596f24ef) {
							$F9163b7e6a33fe89[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
						}
					}

					$bdb0e33425a1906e = array();
					$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

					foreach ($e80d13748eba016a as $e81220b4451f37c9) {
						if ($e81220b4451f37c9['parent'] == '#') {
						} else {
							$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);
							$bdb0e33425a1906e[] = $d58b4f8653a391d8;
							$a9fd4125120bdb0d = intval(in_array($d58b4f8653a391d8, ($a27e64cc6ce01033['on_demand'] ?: array())));

							if ($e81220b4451f37c9['parent'] == 'source') {
								$cceca8bbcbeb112d = null;
							} else {
								$cceca8bbcbeb112d = intval($e81220b4451f37c9['parent']);
							}

							if (isset($F9163b7e6a33fe89[$d58b4f8653a391d8])) {
								self::$db->query('UPDATE `streams_servers` SET `parent_id` = ?, `on_demand` = ? WHERE `server_stream_id` = ?;', $cceca8bbcbeb112d, $a9fd4125120bdb0d, $F9163b7e6a33fe89[$d58b4f8653a391d8]);
							} else {
								self::$db->query("INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `on_demand`, `pids_create_channel`, `cchannel_rsources`) VALUES(?, ?, ?, ?, '[]', '[]');", $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, $cceca8bbcbeb112d, $a9fd4125120bdb0d);
							}
						}
					}

					foreach ($F9163b7e6a33fe89 as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
						if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
						} else {
							D13c1a44a4495B05($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, false, false);
						}
					}

					if (!$c603fc1460f6e6b1) {
					} else {
						E36ec1583E223bF6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => array($Fc2dc5a0ce8d07ea)));
						self::$db->query("UPDATE `streams_servers` SET `pids_create_channel` = '[]', `cchannel_rsources` = '[]' WHERE `stream_id` = ?;", $Fc2dc5a0ce8d07ea);
						XUI::queueChannel($Fc2dc5a0ce8d07ea);
					}

					if (!$d81f27c553f73ff4) {
					} else {
						e36eC1583e223Bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array($Fc2dc5a0ce8d07ea)));
					}

					foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
						D7e7f81f646193b2('stream', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
					}

					if (!isset($a27e64cc6ce01033['edit'])) {
					} else {
						foreach (d7A15E0c2D9BECe1() as $ddf0508b312dbfb8) {
							if (in_array($ddf0508b312dbfb8['id'], $cb498e4dcaac05cc)) {
							} else {
								D83CfF66bcdBEE05('stream', $ddf0508b312dbfb8['id'], $Fc2dc5a0ce8d07ea);
							}
						}
					}

					XUI::aFA0F3ffb001B9BE($Fc2dc5a0ce8d07ea);

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				} else {
					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}
			} else {
				return array('status' => STATUS_NO_SOURCES, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function d4c0Bd97caFDfAF7($a27e64cc6ce01033)
	{
		if (self::F228e3D146e758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AACd47d8157a1A09('adv', 'epg_edit')) {
					$d49041d5f05a9270 = ebdaafC1C10f9506(getEPG($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AAcd47d8157a1a09('adv', 'add_epg')) {
					$d49041d5f05a9270 = B9da5D708fc1C079('epg', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			$acd0eb2c8a975903 = f4817dc607D9981D($d49041d5f05a9270);
			$A6d7047f2fda966c = 'REPLACE INTO `epg`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

			if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			}

			return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function processProvider($a27e64cc6ce01033)
	{
		if (self::F228E3d146e758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (aaCd47D8157A1a09('adv', 'streams')) {
					$d49041d5f05a9270 = ebdaafc1c10F9506(getStreamProvider($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AACd47d8157A1a09('adv', 'streams')) {
					$d49041d5f05a9270 = b9DA5D708Fc1c079('providers', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			foreach (array('enabled', 'ssl', 'hls', 'legacy') as $D3fa098be3f297cd) {
				if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
				} else {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
				}
			}

			if (isset($a27e64cc6ce01033['edit'])) {
				self::$db->query('SELECT `id` FROM `providers` WHERE `ip` = ? AND `username` = ? AND `id` <> ? LIMIT 1;', $d49041d5f05a9270['ip'], $d49041d5f05a9270['username'], $a27e64cc6ce01033['edit']);
			} else {
				self::$db->query('SELECT `id` FROM `providers` WHERE `ip` = ? AND `username` = ? LIMIT 1;', $d49041d5f05a9270['ip'], $d49041d5f05a9270['username']);
			}

			if (0 >= self::$db->num_rows()) {
				$acd0eb2c8a975903 = F4817dC607D9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `providers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_EXISTS_IP, 'data' => $a27e64cc6ce01033);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function b490BCCecc0E1aD3($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AaCd47d8157A1a09('adv', 'edit_episode')) {
					$d49041d5f05a9270 = eBdAAfc1C10F9506(E5eCeB32F67d5e70($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (aACd47d8157A1A09('adv', 'add_episode')) {
					$d49041d5f05a9270 = B9Da5d708fC1C079('streams', $a27e64cc6ce01033);
					$d49041d5f05a9270['type'] = 5;
					$d49041d5f05a9270['added'] = time();
					$d49041d5f05a9270['series_no'] = intval($a27e64cc6ce01033['series']);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			$d49041d5f05a9270['stream_source'] = array($a27e64cc6ce01033['stream_source']);

			if (0 < strlen($a27e64cc6ce01033['movie_subtitles'])) {
				$B211d7401e6242f3 = explode(':', $a27e64cc6ce01033['movie_subtitles']);
				$d49041d5f05a9270['movie_subtitles'] = array('files' => array($B211d7401e6242f3[2]), 'names' => array('Subtitles'), 'charset' => array('UTF-8'), 'location' => intval($B211d7401e6242f3[1]));
			} else {
				$d49041d5f05a9270['movie_subtitles'] = null;
			}

			if (0 >= $d49041d5f05a9270['transcode_profile_id']) {
			} else {
				$d49041d5f05a9270['enable_transcode'] = 1;
			}

			foreach (array('read_native', 'movie_symlink', 'direct_source', 'direct_proxy', 'remove_subtitles') as $D3fa098be3f297cd) {
				if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
				} else {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
				}
			}

			if (isset($a27e64cc6ce01033['restart_on_edit'])) {
				$d81f27c553f73ff4 = true;
			} else {
				$d81f27c553f73ff4 = false;
			}

			$D0b0fc1e85967e8a = array();

			if (isset($a27e64cc6ce01033['multi'])) {
				if (AAcD47d8157A1A09('adv', 'import_episodes')) {
					set_time_limit(0);
					include INCLUDES_PATH . 'libs/tmdb.php';
					$bbc84f53c534450d = fFD24e407abB46eb(intval($a27e64cc6ce01033['series']));

					if (0 < strlen(self::$rSettings['tmdb_language'])) {
						$a69d576081840514 = new TMDB(self::$rSettings['tmdb_api_key'], self::$rSettings['tmdb_language']);
					} else {
						$a69d576081840514 = new TMDB(self::$rSettings['tmdb_api_key']);
					}

					$Bec25219bd671a85 = json_decode($a69d576081840514->getSeason($a27e64cc6ce01033['tmdb_id'], intval($a27e64cc6ce01033['season_num']))->getJSON(), true);

					foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $bc2874292e0d9ece) {
						$B211d7401e6242f3 = explode('_', $D3fa098be3f297cd);

						if (!($B211d7401e6242f3[0] == 'episode' && $B211d7401e6242f3[2] == 'name')) {
						} else {
							if (0 >= strlen($a27e64cc6ce01033['episode_' . $B211d7401e6242f3[1] . '_num'])) {
							} else {
								$eaad9527ef2b563d = array('filename' => '', 'properties' => array(), 'name' => '', 'episode' => 0, 'target_container' => '');
								$f47cdad37b8ee743 = intval($a27e64cc6ce01033['episode_' . $B211d7401e6242f3[1] . '_num']);
								$eaad9527ef2b563d['filename'] = 's:' . $a27e64cc6ce01033['server'] . ':' . $a27e64cc6ce01033['season_folder'] . $bc2874292e0d9ece;
								$A639a7baefc720ee = '';

								if (isset($a27e64cc6ce01033['addName1']) && isset($a27e64cc6ce01033['addName2'])) {
									$eaad9527ef2b563d['name'] = $bbc84f53c534450d['title'] . ' - S' . sprintf('%02d', intval($a27e64cc6ce01033['season_num'])) . 'E' . sprintf('%02d', $f47cdad37b8ee743) . ' - ';
								} else {
									if (isset($a27e64cc6ce01033['addName1'])) {
										$eaad9527ef2b563d['name'] = $bbc84f53c534450d['title'] . ' - ';
									} else {
										if (!isset($a27e64cc6ce01033['addName2'])) {
										} else {
											$eaad9527ef2b563d['name'] = 'S' . sprintf('%02d', intval($a27e64cc6ce01033['season_num'])) . 'E' . sprintf('%02d', $f47cdad37b8ee743) . ' - ';
										}
									}
								}

								$eaad9527ef2b563d['episode'] = $f47cdad37b8ee743;

								foreach ($Bec25219bd671a85['episodes'] as $Bd43537fab08ca31) {
									if (intval($Bd43537fab08ca31['episode_number']) != $f47cdad37b8ee743) {
									} else {
										if (0 >= strlen($Bd43537fab08ca31['still_path'])) {
										} else {
											$A639a7baefc720ee = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $Bd43537fab08ca31['still_path'];

											if (!self::$rSettings['download_images']) {
											} else {
												$A639a7baefc720ee = XUI::b2068ce8b339bF70($A639a7baefc720ee, 5);
											}
										}

										$eaad9527ef2b563d['name'] .= $Bd43537fab08ca31['name'];
										$eff3c5536b319f0b = intval($bbc84f53c534450d['episode_run_time']) * 60;
										$eaad9527ef2b563d['properties'] = array('tmdb_id' => $Bd43537fab08ca31['id'], 'release_date' => $Bd43537fab08ca31['air_date'], 'plot' => $Bd43537fab08ca31['overview'], 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'movie_image' => $A639a7baefc720ee, 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => $Bd43537fab08ca31['vote_average'], 'season' => $a27e64cc6ce01033['season_num']);

										if (strlen($eaad9527ef2b563d['properties']['movie_image'][0]) != 0) {
										} else {
											unset($eaad9527ef2b563d['properties']['movie_image']);
										}
									}
								}

								if (strlen($eaad9527ef2b563d['name']) != 0) {
								} else {
									$eaad9527ef2b563d['name'] = 'No Episode Title';
								}

								$d953b066e19239c1 = pathinfo(explode('?', $bc2874292e0d9ece)[0]);
								$eaad9527ef2b563d['target_container'] = $d953b066e19239c1['extension'];
								$D0b0fc1e85967e8a[] = $eaad9527ef2b563d;
							}
						}
					}
				} else {
					exit();
				}
			} else {
				$eaad9527ef2b563d = array('filename' => $d49041d5f05a9270['stream_source'][0], 'properties' => array(), 'name' => $d49041d5f05a9270['stream_display_name'], 'episode' => $a27e64cc6ce01033['episode'], 'target_container' => $a27e64cc6ce01033['target_container']);

				if (!self::$rSettings['download_images']) {
				} else {
					$a27e64cc6ce01033['movie_image'] = XUI::b2068ce8B339bF70($a27e64cc6ce01033['movie_image'], 5);
				}

				$eff3c5536b319f0b = intval($a27e64cc6ce01033['episode_run_time']) * 60;
				$eaad9527ef2b563d['properties'] = array('release_date' => $a27e64cc6ce01033['release_date'], 'plot' => $a27e64cc6ce01033['plot'], 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'movie_image' => $a27e64cc6ce01033['movie_image'], 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => $a27e64cc6ce01033['rating'], 'season' => $a27e64cc6ce01033['season_num'], 'tmdb_id' => $a27e64cc6ce01033['tmdb_id']);

				if (strlen($eaad9527ef2b563d['properties']['movie_image'][0]) != 0) {
				} else {
					unset($eaad9527ef2b563d['properties']['movie_image']);
				}

				if (!$a27e64cc6ce01033['direct_proxy']) {
				} else {
					$F9452a7efafa1aba = pathinfo(explode('?', $a27e64cc6ce01033['stream_source'])[0])['extension'];

					if ($F9452a7efafa1aba) {
						$eaad9527ef2b563d['target_container'] = $F9452a7efafa1aba;
					} else {
						if ($eaad9527ef2b563d['target_container']) {
						} else {
							$eaad9527ef2b563d['target_container'] = 'mp4';
						}
					}
				}

				$D0b0fc1e85967e8a[] = $eaad9527ef2b563d;
			}

			$bab9eb93e0b773e4 = array();

			foreach ($D0b0fc1e85967e8a as $eaad9527ef2b563d) {
				$d49041d5f05a9270['stream_source'] = array($eaad9527ef2b563d['filename']);
				$d49041d5f05a9270['movie_properties'] = $eaad9527ef2b563d['properties'];
				$d49041d5f05a9270['stream_display_name'] = $eaad9527ef2b563d['name'];

				if (!empty($eaad9527ef2b563d['target_container'])) {
					$d49041d5f05a9270['target_container'] = $eaad9527ef2b563d['target_container'];
				} else {
					if (empty($a27e64cc6ce01033['target_container'])) {
						$d49041d5f05a9270['target_container'] = pathinfo(explode('?', $eaad9527ef2b563d['filename'])[0])['extension'];
					} else {
						$d49041d5f05a9270['target_container'] = $a27e64cc6ce01033['target_container'];
					}
				}

				$acd0eb2c8a975903 = F4817dC607D9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					self::$db->query('DELETE FROM `streams_episodes` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);
					self::$db->query('INSERT INTO `streams_episodes`(`season_num`, `series_id`, `stream_id`, `episode_num`) VALUES(?, ?, ?, ?);', $a27e64cc6ce01033['season_num'], $a27e64cc6ce01033['series'], $Fc2dc5a0ce8d07ea, $eaad9527ef2b563d['episode']);
					FfA086A148Acf057(intval($a27e64cc6ce01033['series']));
					$F9163b7e6a33fe89 = array();

					if (!isset($a27e64cc6ce01033['edit'])) {
					} else {
						self::$db->query('SELECT `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

						foreach (self::$db->get_rows() as $C740da31596f24ef) {
							$F9163b7e6a33fe89[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
						}
					}

					$bdb0e33425a1906e = array();
					$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

					foreach ($e80d13748eba016a as $e81220b4451f37c9) {
						if ($e81220b4451f37c9['parent'] == '#') {
						} else {
							$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);
							$bdb0e33425a1906e[] = $d58b4f8653a391d8;

							if (isset($F9163b7e6a33fe89[$d58b4f8653a391d8])) {
							} else {
								self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `on_demand`) VALUES(?, ?, 0);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
							}
						}
					}

					foreach ($F9163b7e6a33fe89 as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
						if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
						} else {
							d13c1A44A4495B05($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, true, false);
						}
					}

					if (!$d81f27c553f73ff4) {
					} else {
						$bab9eb93e0b773e4[] = $Fc2dc5a0ce8d07ea;
					}

					self::$db->query('UPDATE `streams_series` SET `last_modified` = ? WHERE `id` = ?;', time(), $a27e64cc6ce01033['streams_series']);
					XUI::aFA0f3fFb001B9BE($Fc2dc5a0ce8d07ea);
				} else {
					return array('status' => STATUS_FAILURE);
				}
			}

			if (!$d81f27c553f73ff4) {
			} else {
				E36Ec1583E223Bf6(array('action' => 'vod', 'sub' => 'start', 'stream_ids' => $bab9eb93e0b773e4));
			}

			if (isset($a27e64cc6ce01033['multi'])) {
				return array('status' => STATUS_SUCCESS_MULTI, 0 => array('series_id' => $a27e64cc6ce01033['series']));
			}

			return array('status' => STATUS_SUCCESS, 'data' => array('series_id' => $a27e64cc6ce01033['series'], 'insert_id' => $Fc2dc5a0ce8d07ea));
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function E6376D32625fEC98($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3d146E758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			if (!isset($a27e64cc6ce01033['c_movie_symlink'])) {
			} else {
				if (isset($a27e64cc6ce01033['movie_symlink'])) {
					$d49041d5f05a9270['movie_symlink'] = 1;
				} else {
					$d49041d5f05a9270['movie_symlink'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_direct_source'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_source'])) {
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_source'] = 0;
					$d49041d5f05a9270['direct_proxy'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_direct_proxy'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_proxy'])) {
					$d49041d5f05a9270['direct_proxy'] = 1;
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_proxy'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_read_native'])) {
			} else {
				if (isset($a27e64cc6ce01033['read_native'])) {
					$d49041d5f05a9270['read_native'] = 1;
				} else {
					$d49041d5f05a9270['read_native'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_remove_subtitles'])) {
			} else {
				if (isset($a27e64cc6ce01033['remove_subtitles'])) {
					$d49041d5f05a9270['remove_subtitles'] = 1;
				} else {
					$d49041d5f05a9270['remove_subtitles'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_target_container'])) {
			} else {
				$d49041d5f05a9270['target_container'] = $a27e64cc6ce01033['target_container'];
			}

			if (!isset($a27e64cc6ce01033['c_transcode_profile_id'])) {
			} else {
				$d49041d5f05a9270['transcode_profile_id'] = $a27e64cc6ce01033['transcode_profile_id'];

				if (0 < $d49041d5f05a9270['transcode_profile_id']) {
					$d49041d5f05a9270['enable_transcode'] = 1;
				} else {
					$d49041d5f05a9270['enable_transcode'] = 0;
				}
			}

			$Cdb85875fd50f459 = confirmIDs(json_decode($a27e64cc6ce01033['streams'], true));

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				if (!isset($a27e64cc6ce01033['c_serie_name'])) {
				} else {
					self::$db->query('UPDATE `streams_episodes` SET `series_id` = ? WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');', $a27e64cc6ce01033['serie_name']);
					self::$db->query('UPDATE `streams` SET `series_no` = ? WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');', $a27e64cc6ce01033['serie_name']);
				}

				$acd0eb2c8a975903 = f4817dC607d9981d($d49041d5f05a9270);

				if (0 >= count($acd0eb2c8a975903['data'])) {
				} else {
					$A6d7047f2fda966c = 'UPDATE `streams` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');';
					self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
				}

				$a6629cd1b10b6170 = $d1cd3e64591ec1c1 = $Ddf12215b82c5bba = $F9163b7e6a33fe89 = array();
				self::$db->query('SELECT `stream_id`, `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					$F9163b7e6a33fe89[intval($C740da31596f24ef['stream_id'])][intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
					$Ddf12215b82c5bba[intval($C740da31596f24ef['stream_id'])][] = intval($C740da31596f24ef['server_id']);
				}
				$F6fa7e329a8218d7 = '';

				foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
					if (!isset($a27e64cc6ce01033['c_server_tree'])) {
					} else {
						$bdb0e33425a1906e = array();
						$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

						foreach ($e80d13748eba016a as $e81220b4451f37c9) {
							if ($e81220b4451f37c9['parent'] == '#') {
							} else {
								$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);

								if (in_array($a27e64cc6ce01033['server_type'], array('ADD', 'SET'))) {
									$bdb0e33425a1906e[] = $d58b4f8653a391d8;

									if (isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$F6fa7e329a8218d7 .= '(' . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . '),';
										$Ddf12215b82c5bba[$F26087d31c2bbe4d][] = $d58b4f8653a391d8;
									}
								} else {
									if (!isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}

						if ($a27e64cc6ce01033['server_type'] != 'SET') {
						} else {
							foreach ($F9163b7e6a33fe89[$F26087d31c2bbe4d] as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;

									if (($D3fa098be3f297cd = array_search($d58b4f8653a391d8, $Ddf12215b82c5bba[$F26087d31c2bbe4d])) === false) {
									} else {
										unset($Ddf12215b82c5bba[$F26087d31c2bbe4d][$D3fa098be3f297cd]);
									}
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['reencode_on_edit'])) {
					} else {
						foreach ($Ddf12215b82c5bba[$F26087d31c2bbe4d] as $d58b4f8653a391d8) {
							$d1cd3e64591ec1c1[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
						}
					}

					foreach ($a6629cd1b10b6170 as $d58b4f8653a391d8 => $a811da190447e007) {
						deleteStreamsByServer($a811da190447e007, $d58b4f8653a391d8, true);
					}
				}

				if (empty($F6fa7e329a8218d7)) {
				} else {
					$F6fa7e329a8218d7 = rtrim($F6fa7e329a8218d7, ',');
					self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`) VALUES ' . $F6fa7e329a8218d7 . ';');
				}

				XUI::updateStreams($Cdb85875fd50f459);

				if (!isset($a27e64cc6ce01033['reencode_on_edit'])) {
				} else {
					foreach ($d1cd3e64591ec1c1 as $d58b4f8653a391d8 => $a71db34f1117f574) {
						XUI::queueMovies($a71db34f1117f574, $d58b4f8653a391d8);
					}
				}

				if (!isset($a27e64cc6ce01033['reprocess_tmdb'])) {
				} else {
					XUI::refreshMovies($Cdb85875fd50f459, 3);
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function BDE4E1A0450D3cD0($a27e64cc6ce01033)
	{
		if (self::F228e3d146e758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AACD47d8157A1A09('adv', 'edit_group')) {
					$d49041d5f05a9270 = EBDaafC1c10F9506(a7685e0565A15403($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (aAcd47D8157A1a09('adv', 'add_group')) {
					$d49041d5f05a9270 = B9dA5d708FC1c079('users_groups', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			foreach (array('is_admin', 'is_reseller', 'allow_restrictions', 'create_sub_resellers', 'delete_users', 'allow_download', 'can_view_vod', 'reseller_client_connection_logs', 'allow_change_bouquets', 'allow_change_username', 'allow_change_password') as $Ba3157bbbca6db35) {
				if (isset($a27e64cc6ce01033[$Ba3157bbbca6db35])) {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 1;
				} else {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 0;
				}
			}

			if ($d49041d5f05a9270['can_delete'] || !isset($a27e64cc6ce01033['edit'])) {
			} else {
				$D307572f7986a746 = A7685E0565a15403($a27e64cc6ce01033['edit']);
				$d49041d5f05a9270['is_admin'] = $D307572f7986a746['is_admin'];
				$d49041d5f05a9270['is_reseller'] = $D307572f7986a746['is_reseller'];
			}

			$d49041d5f05a9270['allowed_pages'] = array_values(json_decode($a27e64cc6ce01033['permissions_selected'], true));

			if (strlen($a27e64cc6ce01033['group_name']) != 0) {
				$d49041d5f05a9270['subresellers'] = '[' . implode(',', array_map('intval', json_decode($a27e64cc6ce01033['groups_selected'], true))) . ']';
				$d49041d5f05a9270['notice_html'] = htmlentities($a27e64cc6ce01033['notice_html']);
				$acd0eb2c8a975903 = f4817dc607D9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `users_groups`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					$D57b432dc56eb885 = json_decode($a27e64cc6ce01033['packages_selected'], true);

					foreach ($D57b432dc56eb885 as $fe06d74291ffa213) {
						self::$db->query('SELECT `groups` FROM `users_packages` WHERE `id` = ?;', $fe06d74291ffa213);

						if (self::$db->num_rows() != 1) {
						} else {
							$ca518e82bd328243 = json_decode(self::$db->get_row()['groups'], true);

							if (in_array($Fc2dc5a0ce8d07ea, $ca518e82bd328243)) {
							} else {
								$ca518e82bd328243[] = $Fc2dc5a0ce8d07ea;
								self::$db->query('UPDATE `users_packages` SET `groups` = ? WHERE `id` = ?;', '[' . implode(',', array_map('intval', $ca518e82bd328243)) . ']', $fe06d74291ffa213);
							}
						}
					}
					self::$db->query("SELECT `id`, `groups` FROM `users_packages` WHERE JSON_CONTAINS(`groups`, ?, '\$');", $Fc2dc5a0ce8d07ea);

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						if (in_array($C740da31596f24ef['id'], $D57b432dc56eb885)) {
						} else {
							$ca518e82bd328243 = json_decode($C740da31596f24ef['groups'], true);

							if (($D3fa098be3f297cd = array_search($Fc2dc5a0ce8d07ea, $ca518e82bd328243)) === false) {
							} else {
								unset($ca518e82bd328243[$D3fa098be3f297cd]);
								self::$db->query('UPDATE `users_packages` SET `groups` = ? WHERE `id` = ?;', '[' . implode(',', array_map('intval', $ca518e82bd328243)) . ']', $C740da31596f24ef['id']);
							}
						}
					}

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				} else {
					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}
			} else {
				return array('status' => STATUS_INVALID_NAME, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function cBB044Eb5b5Fa5a2($a27e64cc6ce01033)
	{
		if (self::F228e3D146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (aacD47D8157a1a09('adv', 'block_isps')) {
					$d49041d5f05a9270 = EbdAAfC1c10F9506(e7dA8338649cd1CA($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AAcd47d8157a1a09('adv', 'block_isps')) {
					$d49041d5f05a9270 = b9dA5d708Fc1C079('blocked_isps', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (isset($a27e64cc6ce01033['blocked'])) {
				$d49041d5f05a9270['blocked'] = 1;
			} else {
				$d49041d5f05a9270['blocked'] = 0;
			}

			if (strlen($d49041d5f05a9270['isp']) != 0) {
				$acd0eb2c8a975903 = F4817Dc607d9981d($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `blocked_isps`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_NAME, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function f2e77D2F6cE1e2eE($a27e64cc6ce01033, $b175c78ed63c25a1 = false)
	{
		if (!self::$rSettings['recaptcha_enable'] || $b175c78ed63c25a1) {
		} else {
			$c7488e8420e934e2 = json_decode(file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . self::$rSettings['recaptcha_v2_secret_key'] . '&response=' . $a27e64cc6ce01033['g-recaptcha-response']), true);

			if ($c7488e8420e934e2['success']) {
			} else {
				return array('status' => STATUS_INVALID_CAPTCHA);
			}
		}

		$c59ec257c284c894 = c7afD69EdC2A2940();
		$D4253f9520627819 = D3f333592A08eb86($a27e64cc6ce01033['username'], $a27e64cc6ce01033['password']);
		$ef288259a1681f9b = e787D2298DbdA85d(true);

		if (isset($D4253f9520627819)) {
			self::$db->query('SELECT COUNT(*) AS `count` FROM `access_codes`;');
			$F4b624276181a4c0 = self::$db->get_row()['count'];

			if ($F4b624276181a4c0 == 0 || in_array($D4253f9520627819['member_group_id'], json_decode($ef288259a1681f9b['groups'], true))) {
				$B2ff75c438fb3031 = F0AcF9de3389B116($D4253f9520627819['member_group_id']);

				if ($B2ff75c438fb3031['is_admin']) {
					if ($D4253f9520627819['status'] == 1) {
						$a1f8ada60879ba62 = DF65D36BEA77aE8c($a27e64cc6ce01033['password']);

						if ($D4253f9520627819['password'] != $a1f8ada60879ba62) {
							self::$db->query('UPDATE `users` SET `password` = ?, `last_login` = UNIX_TIMESTAMP(), `ip` = ? WHERE `id` = ?;', $a1f8ada60879ba62, $c59ec257c284c894, $D4253f9520627819['id']);
						} else {
							self::$db->query('UPDATE `users` SET `last_login` = UNIX_TIMESTAMP(), `ip` = ? WHERE `id` = ?;', $c59ec257c284c894, $D4253f9520627819['id']);
						}

						$_SESSION['hash'] = $D4253f9520627819['id'];
						$_SESSION['ip'] = $c59ec257c284c894;
						$_SESSION['code'] = E787D2298DBdA85D();
						$_SESSION['verify'] = md5($D4253f9520627819['username'] . '||' . $a1f8ada60879ba62);

						if (!self::$rSettings['save_login_logs']) {
						} else {
							self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('ADMIN', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'SUCCESS', $c59ec257c284c894, time());
						}

						return array('status' => STATUS_SUCCESS);
					}

					if (!($B2ff75c438fb3031 && ($B2ff75c438fb3031['is_admin'] || $B2ff75c438fb3031['is_reseller']) && !$D4253f9520627819['status'])) {
					} else {
						if (!self::$rSettings['save_login_logs']) {
						} else {
							self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('ADMIN', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'DISABLED', $c59ec257c284c894, time());
						}

						return array('status' => STATUS_DISABLED);
					}
				} else {
					if (!self::$rSettings['save_login_logs']) {
					} else {
						self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('ADMIN', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'NOT_ADMIN', $c59ec257c284c894, time());
					}

					return array('status' => STATUS_NOT_ADMIN);
				}
			} else {
				if (!self::$rSettings['save_login_logs']) {
				} else {
					self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('ADMIN', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'INVALID_CODE', $c59ec257c284c894, time());
				}

				return array('status' => STATUS_INVALID_CODE);
			}
		} else {
			if (!self::$rSettings['save_login_logs']) {
			} else {
				self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('ADMIN', ?, 0, ?, ?, ?);", $ef288259a1681f9b['id'], 'INVALID_LOGIN', $c59ec257c284c894, time());
			}

			return array('status' => STATUS_FAILURE);
		}
	}

	public static function BDb7989B92819df0($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::f228E3d146e758B1($a27e64cc6ce01033)) {
			$A2b85ede89f9df0c = json_decode($a27e64cc6ce01033['streams'], true);
			deleteStreams($A2b85ede89f9df0c, false);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function ef104395e7b7dB39($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3D146E758B1($a27e64cc6ce01033)) {
			$ae63b8db36d4a79c = json_decode($a27e64cc6ce01033['movies'], true);
			deleteStreams($ae63b8db36d4a79c, true);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function eBb672e1975480Ed($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::f228E3d146E758b1($a27e64cc6ce01033)) {
			$f2cc0807b1dc8948 = json_decode($a27e64cc6ce01033['lines'], true);
			deleteLines($f2cc0807b1dc8948);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function dA73459E65f37DfB($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228E3D146e758b1($a27e64cc6ce01033)) {
			$B963b5d49ca08acf = json_decode($a27e64cc6ce01033['users'], true);
			e4C6429a95C776cF($B963b5d49ca08acf);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function b65c3404392B5Ded($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3d146e758b1($a27e64cc6ce01033)) {
			$A2b85ede89f9df0c = json_decode($a27e64cc6ce01033['radios'], true);
			deleteStreams($A2b85ede89f9df0c, false);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function DF67D3811748bbA2($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3D146E758B1($a27e64cc6ce01033)) {
			$D099fa8eb17aac2a = json_decode($a27e64cc6ce01033['mags'], true);
			deleteMAGs($D099fa8eb17aac2a);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function C852A2b372281BCF($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3d146E758b1($a27e64cc6ce01033)) {
			$eb02384f76231a85 = json_decode($a27e64cc6ce01033['enigmas'], true);
			deleteEnigmas($eb02384f76231a85);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function c0781DFd0b51d96D($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3D146E758b1($a27e64cc6ce01033)) {
			$bbc84f53c534450d = json_decode($a27e64cc6ce01033['series'], true);
			deleteSeriesMass($bbc84f53c534450d);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function a45CB66Cf614da21($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228E3D146e758b1($a27e64cc6ce01033)) {
			$b1fa0ad0bb84d114 = json_decode($a27e64cc6ce01033['episodes'], true);
			deleteStreams($b1fa0ad0bb84d114, true);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function D4e96aC013e38C70($a27e64cc6ce01033)
	{
		if (self::f228E3d146e758b1($a27e64cc6ce01033)) {
			set_time_limit(0);
			ini_set('mysql.connect_timeout', 0);
			ini_set('max_execution_time', 0);
			ini_set('default_socket_timeout', 0);

			if (isset($a27e64cc6ce01033['edit'])) {
				if (AaCD47D8157A1A09('adv', 'edit_movie')) {
					$d49041d5f05a9270 = ebdaafC1c10F9506(E5eCEb32f67D5e70($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AacD47D8157A1a09('adv', 'add_movie')) {
					$d49041d5f05a9270 = B9dA5d708fC1c079('streams', $a27e64cc6ce01033);
					$d49041d5f05a9270['added'] = time();
					$d49041d5f05a9270['type'] = 2;
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (0 < strlen($a27e64cc6ce01033['movie_subtitles'])) {
				$B211d7401e6242f3 = explode(':', $a27e64cc6ce01033['movie_subtitles']);
				$d49041d5f05a9270['movie_subtitles'] = array('files' => array($B211d7401e6242f3[2]), 'names' => array('Subtitles'), 'charset' => array('UTF-8'), 'location' => intval($B211d7401e6242f3[1]));
			} else {
				$d49041d5f05a9270['movie_subtitles'] = null;
			}

			if (0 >= $d49041d5f05a9270['transcode_profile_id']) {
			} else {
				$d49041d5f05a9270['enable_transcode'] = 1;
			}

			if (!(!is_numeric($d49041d5f05a9270['year']) || $d49041d5f05a9270['year'] < 1900 || intval(date('Y') + 1) < $d49041d5f05a9270['year'])) {
			} else {
				$d49041d5f05a9270['year'] = null;
			}

			foreach (array('read_native', 'movie_symlink', 'direct_source', 'direct_proxy', 'remove_subtitles') as $D3fa098be3f297cd) {
				if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
				} else {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
				}
			}

			if (isset($a27e64cc6ce01033['restart_on_edit'])) {
				$d81f27c553f73ff4 = true;
			} else {
				$d81f27c553f73ff4 = false;
			}

			$faa909d3220546d8 = false;
			$Ab3cebb99a2b671e = array();

			if (isset($a27e64cc6ce01033['review'])) {
				require_once XUI_HOME . 'includes/libs/tmdb.php';

				if (0 < strlen(self::$rSettings['tmdb_language'])) {
					$a69d576081840514 = new TMDB(self::$rSettings['tmdb_api_key'], self::$rSettings['tmdb_language']);
				} else {
					$a69d576081840514 = new TMDB(self::$rSettings['tmdb_api_key']);
				}

				$faa909d3220546d8 = true;

				foreach ($a27e64cc6ce01033['review'] as $addee113c4cee30c) {
					if (!$addee113c4cee30c['tmdb_id']) {
					} else {
						$a417725f28d75ef7 = $a69d576081840514->getMovie($addee113c4cee30c['tmdb_id']);

						if (!$a417725f28d75ef7) {
						} else {
							$a2b9f17f5f896910 = json_decode($a417725f28d75ef7->getJSON(), true);
							$a2b9f17f5f896910['trailer'] = $a417725f28d75ef7->getTrailer();
							$A646087ab5268867 = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $a2b9f17f5f896910['poster_path'];
							$f86e3ca402767b9e = 'https://image.tmdb.org/t/p/w1280' . $a2b9f17f5f896910['backdrop_path'];

							if (!self::$rSettings['download_images']) {
							} else {
								$A646087ab5268867 = XUI::b2068Ce8B339Bf70($A646087ab5268867, 2);
								$f86e3ca402767b9e = XUI::B2068ce8b339BF70($f86e3ca402767b9e);
							}

							$cc6fe5bce59818ef = array();

							foreach ($a2b9f17f5f896910['credits']['cast'] as $B809ba74bb572f83) {
								if (count($cc6fe5bce59818ef) >= 5) {
								} else {
									$cc6fe5bce59818ef[] = $B809ba74bb572f83['name'];
								}
							}
							$A094eef6d6023c0b = array();

							foreach ($a2b9f17f5f896910['credits']['crew'] as $B809ba74bb572f83) {
								if (!(count($A094eef6d6023c0b) < 5 && ($B809ba74bb572f83['department'] == 'Directing' || $B809ba74bb572f83['known_for_department'] == 'Directing'))) {
								} else {
									$A094eef6d6023c0b[] = $B809ba74bb572f83['name'];
								}
							}
							$De0e117a481409e2 = '';

							if (!isset($a2b9f17f5f896910['production_countries'][0]['name'])) {
							} else {
								$De0e117a481409e2 = $a2b9f17f5f896910['production_countries'][0]['name'];
							}

							$ebbdeb734c887fae = array();

							foreach ($a2b9f17f5f896910['genres'] as $B8995c76454f4b98) {
								if (count($ebbdeb734c887fae) >= 3) {
								} else {
									$ebbdeb734c887fae[] = $B8995c76454f4b98['name'];
								}
							}
							$eff3c5536b319f0b = intval($a2b9f17f5f896910['runtime']) * 60;

							if (0 < strlen($a2b9f17f5f896910['release_date'])) {
								$A02729c83b6cd395 = intval(substr($a2b9f17f5f896910['release_date'], 0, 4));
							} else {
								$A02729c83b6cd395 = null;
							}

							$addee113c4cee30c['movie_properties'] = array('kinopoisk_url' => 'https://www.themoviedb.org/movie/' . $a2b9f17f5f896910['id'], 'tmdb_id' => $a2b9f17f5f896910['id'], 'name' => $a2b9f17f5f896910['title'], 'year' => $A02729c83b6cd395, 'o_name' => $a2b9f17f5f896910['original_title'], 'cover_big' => $A646087ab5268867, 'movie_image' => $A646087ab5268867, 'release_date' => $a2b9f17f5f896910['release_date'], 'episode_run_time' => $a2b9f17f5f896910['runtime'], 'youtube_trailer' => $a2b9f17f5f896910['trailer'], 'director' => implode(', ', $A094eef6d6023c0b), 'actors' => implode(', ', $cc6fe5bce59818ef), 'cast' => implode(', ', $cc6fe5bce59818ef), 'description' => $a2b9f17f5f896910['overview'], 'plot' => $a2b9f17f5f896910['overview'], 'age' => '', 'mpaa_rating' => '', 'rating_count_kinopoisk' => 0, 'country' => $De0e117a481409e2, 'genre' => implode(', ', $ebbdeb734c887fae), 'backdrop_path' => array($f86e3ca402767b9e), 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => $a2b9f17f5f896910['vote_average']);
						}
					}

					unset($addee113c4cee30c['tmdb_id']);
					$addee113c4cee30c['async'] = false;
					$addee113c4cee30c['target_container'] = pathinfo(explode('?', $addee113c4cee30c['stream_source'][0])[0])['extension'];

					if (!empty($addee113c4cee30c['target_container'])) {
					} else {
						$addee113c4cee30c['target_container'] = 'mp4';
					}

					$Ab3cebb99a2b671e[] = $addee113c4cee30c;
				}
			} else {
				$Ab3cebb99a2b671e = array();

				if (!empty($_FILES['m3u_file']['tmp_name'])) {
					if (aACd47D8157a1a09('adv', 'import_movies')) {
						$D2165010a62b36e4 = array();
						self::$db->query('SELECT `stream_source` FROM `streams` WHERE `type` = 2;');

						foreach (self::$db->get_rows() as $C740da31596f24ef) {
							foreach (json_decode($C740da31596f24ef['stream_source'], true) as $c8d91fcd2309e48a) {
								if (0 >= strlen($c8d91fcd2309e48a)) {
								} else {
									$D2165010a62b36e4[] = $c8d91fcd2309e48a;
								}
							}
						}
						$e2f848a82a80c113 = '';

						if (empty($_FILES['m3u_file']['tmp_name']) || strtolower(pathinfo(explode('?', $_FILES['m3u_file']['name'])[0], PATHINFO_EXTENSION)) != 'm3u') {
						} else {
							$e2f848a82a80c113 = file_get_contents($_FILES['m3u_file']['tmp_name']);
						}

						preg_match_all('/(?P<tag>#EXTINF:[-1,0])|(?:(?P<prop_key>[-a-z]+)=\\"(?P<prop_val>[^"]+)")|(?<name>,[^\\r\\n]+)|(?<url>http[^\\s]*:\\/\\/.*\\/.*)/', $e2f848a82a80c113, $b85ce31cd1118ad2);
						$c15d5b523e931f51 = array();
						$Fa5e35208ccf3528 = -1;

						for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($b85ce31cd1118ad2[0]); $Ea22c4a9ab5b2176++) {
							$bb2621204e39e62d = $b85ce31cd1118ad2[0][$Ea22c4a9ab5b2176];

							if (!empty($b85ce31cd1118ad2['tag'][$Ea22c4a9ab5b2176])) {
								$Fa5e35208ccf3528++;
							} else {
								if (!empty($b85ce31cd1118ad2['prop_key'][$Ea22c4a9ab5b2176])) {
									$c15d5b523e931f51[$Fa5e35208ccf3528][$b85ce31cd1118ad2['prop_key'][$Ea22c4a9ab5b2176]] = trim($b85ce31cd1118ad2['prop_val'][$Ea22c4a9ab5b2176]);
								} else {
									if (!empty($b85ce31cd1118ad2['name'][$Ea22c4a9ab5b2176])) {
										$c15d5b523e931f51[$Fa5e35208ccf3528]['name'] = trim(substr($bb2621204e39e62d, 1));
									} else {
										if (!empty($b85ce31cd1118ad2['url'][$Ea22c4a9ab5b2176])) {
											$c15d5b523e931f51[$Fa5e35208ccf3528]['url'] = str_replace(' ', '%20', trim($bb2621204e39e62d));
										}
									}
								}
							}
						}

						foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
							if (in_array($B59c127fecf35c15['url'], $D2165010a62b36e4)) {
							} else {
								$d953b066e19239c1 = pathinfo(explode('?', $B59c127fecf35c15['url'])[0]);
								$eaad9527ef2b563d = array('stream_source' => array($B59c127fecf35c15['url']), 'stream_icon' => ($B59c127fecf35c15['tvg-logo'] ?: ''), 'stream_display_name' => ($B59c127fecf35c15['name'] ?: ''), 'movie_properties' => array(), 'async' => true, 'target_container' => $d953b066e19239c1['extension']);
								$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;
							}
						}
					} else {
						exit();
					}
				} else {
					if (!empty($a27e64cc6ce01033['import_folder'])) {
						if (aACD47d8157a1A09('adv', 'import_movies')) {
							$D2165010a62b36e4 = array();
							self::$db->query('SELECT `stream_source` FROM `streams` WHERE `type` = 2;');

							foreach (self::$db->get_rows() as $C740da31596f24ef) {
								foreach (json_decode($C740da31596f24ef['stream_source'], true) as $c8d91fcd2309e48a) {
									if (0 >= strlen($c8d91fcd2309e48a)) {
									} else {
										$D2165010a62b36e4[] = $c8d91fcd2309e48a;
									}
								}
							}
							$Bab76ac20d8e4000 = explode(':', $a27e64cc6ce01033['import_folder']);

							if (!is_numeric($Bab76ac20d8e4000[1])) {
							} else {
								if (isset($a27e64cc6ce01033['scan_recursive'])) {
									$b93e6a2691d72853 = F101c1503ABA095B(intval($Bab76ac20d8e4000[1]), $Bab76ac20d8e4000[2], array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts'));
								} else {
									$b93e6a2691d72853 = array();

									foreach (A2C50E6040039e78(intval($Bab76ac20d8e4000[1]), rtrim($Bab76ac20d8e4000[2], '/'), array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts'))['files'] as $e2f848a82a80c113) {
										$b93e6a2691d72853[] = rtrim($Bab76ac20d8e4000[2], '/') . '/' . $e2f848a82a80c113;
									}
								}

								foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
									$Bee11ea7f1f2f0ff = 's:' . intval($Bab76ac20d8e4000[1]) . ':' . $e2f848a82a80c113;

									if (in_array($Bee11ea7f1f2f0ff, $D2165010a62b36e4)) {
									} else {
										$d953b066e19239c1 = pathinfo($e2f848a82a80c113);
										$eaad9527ef2b563d = array('stream_source' => array($Bee11ea7f1f2f0ff), 'stream_icon' => '', 'stream_display_name' => $d953b066e19239c1['filename'], 'movie_properties' => array(), 'async' => true, 'target_container' => $d953b066e19239c1['extension']);
										$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;
									}
								}
							}
						} else {
							exit();
						}
					} else {
						$eaad9527ef2b563d = array('stream_source' => array($a27e64cc6ce01033['stream_source']), 'stream_icon' => $d49041d5f05a9270['stream_icon'], 'stream_display_name' => $d49041d5f05a9270['stream_display_name'], 'movie_properties' => array(), 'async' => false, 'target_container' => $d49041d5f05a9270['target_container']);

						if (0 < strlen($a27e64cc6ce01033['tmdb_id'])) {
							$A8d7365325224edd = 'https://www.themoviedb.org/movie/' . $a27e64cc6ce01033['tmdb_id'];
						} else {
							$A8d7365325224edd = '';
						}

						if (!self::$rSettings['download_images']) {
						} else {
							$a27e64cc6ce01033['movie_image'] = XUI::b2068cE8B339Bf70($a27e64cc6ce01033['movie_image'], 2);
							$a27e64cc6ce01033['backdrop_path'] = XUI::B2068CE8B339BF70($a27e64cc6ce01033['backdrop_path']);
						}

						$eff3c5536b319f0b = intval($a27e64cc6ce01033['episode_run_time']) * 60;
						$eaad9527ef2b563d['movie_properties'] = array('kinopoisk_url' => $A8d7365325224edd, 'tmdb_id' => $a27e64cc6ce01033['tmdb_id'], 'name' => $d49041d5f05a9270['stream_display_name'], 'o_name' => $d49041d5f05a9270['stream_display_name'], 'cover_big' => $a27e64cc6ce01033['movie_image'], 'movie_image' => $a27e64cc6ce01033['movie_image'], 'release_date' => $a27e64cc6ce01033['release_date'], 'episode_run_time' => $a27e64cc6ce01033['episode_run_time'], 'youtube_trailer' => $a27e64cc6ce01033['youtube_trailer'], 'director' => $a27e64cc6ce01033['director'], 'actors' => $a27e64cc6ce01033['cast'], 'cast' => $a27e64cc6ce01033['cast'], 'description' => $a27e64cc6ce01033['plot'], 'plot' => $a27e64cc6ce01033['plot'], 'age' => '', 'mpaa_rating' => '', 'rating_count_kinopoisk' => 0, 'country' => $a27e64cc6ce01033['country'], 'genre' => $a27e64cc6ce01033['genre'], 'backdrop_path' => array($a27e64cc6ce01033['backdrop_path']), 'duration_secs' => $eff3c5536b319f0b, 'duration' => sprintf('%02d:%02d:%02d', $eff3c5536b319f0b / 3600, ($eff3c5536b319f0b / 60) % 60, $eff3c5536b319f0b % 60), 'video' => array(), 'audio' => array(), 'bitrate' => 0, 'rating' => $a27e64cc6ce01033['rating']);

						if (strlen($eaad9527ef2b563d['movie_properties']['backdrop_path'][0]) != 0) {
						} else {
							unset($eaad9527ef2b563d['movie_properties']['backdrop_path']);
						}

						if (!($a27e64cc6ce01033['movie_symlink'] || $a27e64cc6ce01033['direct_proxy'])) {
						} else {
							$F9452a7efafa1aba = pathinfo(explode('?', $a27e64cc6ce01033['stream_source'])[0])['extension'];

							if ($F9452a7efafa1aba) {
								$eaad9527ef2b563d['target_container'] = $F9452a7efafa1aba;
							} else {
								if ($eaad9527ef2b563d['target_container']) {
								} else {
									$eaad9527ef2b563d['target_container'] = 'mp4';
								}
							}
						}

						$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;
					}
				}
			}

			if (0 < count($Ab3cebb99a2b671e)) {
				$f518050a6d5f89c7 = array();
				$Ae4bd014b3779489 = array();

				if ($faa909d3220546d8) {
				} else {
					foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
						$acd0eb2c8a975903 = F4817dc607d9981d(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
						$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$C52c0b6b0f74407b = self::$db->last_insert_id();
							$f518050a6d5f89c7[$ddf0508b312dbfb8] = $C52c0b6b0f74407b;
						}
					}

					foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
						$acd0eb2c8a975903 = f4817DC607D9981d(array('category_type' => 'movie', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
						$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$Be965cdd996d4520 = self::$db->last_insert_id();
							$Ae4bd014b3779489[$A1925ae53e9307eb] = $Be965cdd996d4520;
						}
					}
				}

				$bab9eb93e0b773e4 = array();

				foreach ($Ab3cebb99a2b671e as $addee113c4cee30c) {
					$eaad9527ef2b563d = $d49041d5f05a9270;

					if ($faa909d3220546d8) {
						$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', $addee113c4cee30c['category_id'])) . ']';
						$cb498e4dcaac05cc = array_map('intval', $addee113c4cee30c['bouquets']);
						unset($addee113c4cee30c['bouquets']);
					} else {
						$cb498e4dcaac05cc = array();

						foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
							if (isset($f518050a6d5f89c7[$ddf0508b312dbfb8])) {
								$cb498e4dcaac05cc[] = $f518050a6d5f89c7[$ddf0508b312dbfb8];
							} else {
								if (!is_numeric($ddf0508b312dbfb8)) {
								} else {
									$cb498e4dcaac05cc[] = intval($ddf0508b312dbfb8);
								}
							}
						}
						$A5dcdeb6ecbbf6bd = array();

						foreach ($a27e64cc6ce01033['category_id'] as $A1925ae53e9307eb) {
							if (isset($Ae4bd014b3779489[$A1925ae53e9307eb])) {
								$A5dcdeb6ecbbf6bd[] = $Ae4bd014b3779489[$A1925ae53e9307eb];
							} else {
								if (!is_numeric($A1925ae53e9307eb)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = intval($A1925ae53e9307eb);
								}
							}
						}
						$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', $A5dcdeb6ecbbf6bd)) . ']';
					}

					if (!isset($eaad9527ef2b563d['movie_properties']['rating'])) {
					} else {
						$eaad9527ef2b563d['rating'] = $eaad9527ef2b563d['movie_properties']['rating'];
					}

					foreach (array_keys($addee113c4cee30c) as $D3fa098be3f297cd) {
						$eaad9527ef2b563d[$D3fa098be3f297cd] = $addee113c4cee30c[$D3fa098be3f297cd];
					}

					if (isset($a27e64cc6ce01033['edit'])) {
					} else {
						$eaad9527ef2b563d['order'] = dc95637C2Da3b543();
					}

					$eaad9527ef2b563d['tmdb_id'] = ($addee113c4cee30c['movie_properties']['tmdb_id'] ?: null);
					$abc2466c5bfb1b17 = $eaad9527ef2b563d['async'];
					unset($eaad9527ef2b563d['async']);
					$acd0eb2c8a975903 = F4817DC607D9981d($eaad9527ef2b563d);
					$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
						$F9163b7e6a33fe89 = array();

						if (!isset($a27e64cc6ce01033['edit'])) {
						} else {
							self::$db->query('SELECT `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

							foreach (self::$db->get_rows() as $C740da31596f24ef) {
								$F9163b7e6a33fe89[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
							}
						}

						$Bc16cc77a681d1ed = $eaad9527ef2b563d['stream_source'][0];

						if (substr($Bc16cc77a681d1ed, 0, 2) != 's:') {
						} else {
							$B211d7401e6242f3 = explode(':', $Bc16cc77a681d1ed, 3);
							$Bc16cc77a681d1ed = $B211d7401e6242f3[2];
						}

						self::$db->query('UPDATE `watch_logs` SET `status` = 1, `stream_id` = ? WHERE `filename` = ? AND `type` = 1;', $Fc2dc5a0ce8d07ea, $Bc16cc77a681d1ed);
						$bdb0e33425a1906e = array();
						$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

						foreach ($e80d13748eba016a as $e81220b4451f37c9) {
							if ($e81220b4451f37c9['parent'] == '#') {
							} else {
								$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);
								$bdb0e33425a1906e[] = $d58b4f8653a391d8;

								if (isset($F9163b7e6a33fe89[$d58b4f8653a391d8])) {
								} else {
									self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `on_demand`) VALUES(?, ?, 0);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8);
								}
							}
						}

						foreach ($F9163b7e6a33fe89 as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
							if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
							} else {
								d13c1A44A4495B05($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, true, false);
							}
						}

						if (!$d81f27c553f73ff4) {
						} else {
							$bab9eb93e0b773e4[] = $Fc2dc5a0ce8d07ea;
						}

						foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
							D7e7F81F646193b2('movie', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
						}

						foreach (d7A15E0c2d9bECE1() as $ddf0508b312dbfb8) {
							if (in_array($ddf0508b312dbfb8['id'], $cb498e4dcaac05cc)) {
							} else {
								D83CFf66bcdbEE05('movie', $ddf0508b312dbfb8['id'], $Fc2dc5a0ce8d07ea);
							}
						}

						if (!$abc2466c5bfb1b17) {
						} else {
							self::$db->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES(1, ?, 0);', $Fc2dc5a0ce8d07ea);
						}

						XUI::AfA0f3ffB001B9be($Fc2dc5a0ce8d07ea);
					} else {
						foreach ($f518050a6d5f89c7 as $ddf0508b312dbfb8 => $C3c8913edb801c35) {
							$Fee0d5a474c96306->query('DELETE FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);
						}

						foreach ($Ae4bd014b3779489 as $A1925ae53e9307eb => $C3c8913edb801c35) {
							$Fee0d5a474c96306->query('DELETE FROM `streams_categories` WHERE `id` = ?;', $C3c8913edb801c35);
						}

						return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
					}
				}

				if (!$d81f27c553f73ff4) {
				} else {
					E36EC1583e223bF6(array('action' => 'vod', 'sub' => 'start', 'stream_ids' => $bab9eb93e0b773e4));
				}

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			} else {
				return array('status' => STATUS_NO_SOURCES, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function c687A3D22C3a694a($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::f228E3d146E758b1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			if (!isset($a27e64cc6ce01033['c_movie_symlink'])) {
			} else {
				if (isset($a27e64cc6ce01033['movie_symlink'])) {
					$d49041d5f05a9270['movie_symlink'] = 1;
				} else {
					$d49041d5f05a9270['movie_symlink'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_direct_source'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_source'])) {
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_source'] = 0;
					$d49041d5f05a9270['direct_proxy'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_direct_proxy'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_proxy'])) {
					$d49041d5f05a9270['direct_proxy'] = 1;
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_proxy'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_read_native'])) {
			} else {
				if (isset($a27e64cc6ce01033['read_native'])) {
					$d49041d5f05a9270['read_native'] = 1;
				} else {
					$d49041d5f05a9270['read_native'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_remove_subtitles'])) {
			} else {
				if (isset($a27e64cc6ce01033['remove_subtitles'])) {
					$d49041d5f05a9270['remove_subtitles'] = 1;
				} else {
					$d49041d5f05a9270['remove_subtitles'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_target_container'])) {
			} else {
				$d49041d5f05a9270['target_container'] = $a27e64cc6ce01033['target_container'];
			}

			if (!isset($a27e64cc6ce01033['c_transcode_profile_id'])) {
			} else {
				$d49041d5f05a9270['transcode_profile_id'] = $a27e64cc6ce01033['transcode_profile_id'];

				if (0 < $d49041d5f05a9270['transcode_profile_id']) {
					$d49041d5f05a9270['enable_transcode'] = 1;
				} else {
					$d49041d5f05a9270['enable_transcode'] = 0;
				}
			}

			$Cdb85875fd50f459 = json_decode($a27e64cc6ce01033['streams'], true);

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				$a0ab7ba3516bce7d = array();

				if (!(isset($a27e64cc6ce01033['c_category_id']) && in_array($a27e64cc6ce01033['category_id_type'], array('ADD', 'DEL')))) {
				} else {
					self::$db->query('SELECT `id`, `category_id` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$a0ab7ba3516bce7d[$C740da31596f24ef['id']] = (json_decode($C740da31596f24ef['category_id'], true) ?: array());
					}
				}

				$a6629cd1b10b6170 = $d1cd3e64591ec1c1 = $Ddf12215b82c5bba = $F9163b7e6a33fe89 = array();
				self::$db->query('SELECT `stream_id`, `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					$F9163b7e6a33fe89[intval($C740da31596f24ef['stream_id'])][intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
					$Ddf12215b82c5bba[intval($C740da31596f24ef['stream_id'])][] = intval($C740da31596f24ef['server_id']);
				}
				$cb498e4dcaac05cc = D7a15e0c2D9beCe1();
				$ed2502d79a409dc0 = $fb5ea0f21131b307 = array();
				$F6fa7e329a8218d7 = '';

				foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
					if (!isset($a27e64cc6ce01033['c_category_id'])) {
					} else {
						$A5dcdeb6ecbbf6bd = array_map('intval', $a27e64cc6ce01033['category_id']);

						if ($a27e64cc6ce01033['category_id_type'] == 'ADD') {
							foreach (($a0ab7ba3516bce7d[$F26087d31c2bbe4d] ?: array()) as $Be965cdd996d4520) {
								if (in_array($Be965cdd996d4520, $A5dcdeb6ecbbf6bd)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = $Be965cdd996d4520;
								}
							}
						} else {
							if ($a27e64cc6ce01033['category_id_type'] != 'DEL') {
							} else {
								$C8413f429e2be20f = $a0ab7ba3516bce7d[$F26087d31c2bbe4d];

								foreach ($A5dcdeb6ecbbf6bd as $Be965cdd996d4520) {
									if (($D3fa098be3f297cd = array_search($Be965cdd996d4520, $C8413f429e2be20f)) === false) {
									} else {
										unset($C8413f429e2be20f[$D3fa098be3f297cd]);
									}
								}
								$A5dcdeb6ecbbf6bd = $C8413f429e2be20f;
							}
						}

						$d49041d5f05a9270['category_id'] = '[' . implode(',', $A5dcdeb6ecbbf6bd) . ']';
					}

					$acd0eb2c8a975903 = f4817DC607D9981D($d49041d5f05a9270);

					if (0 >= count($acd0eb2c8a975903['data'])) {
					} else {
						$acd0eb2c8a975903['data'][] = $F26087d31c2bbe4d;
						$A6d7047f2fda966c = 'UPDATE `streams` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
						self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
					}

					if (!isset($a27e64cc6ce01033['c_server_tree'])) {
					} else {
						$bdb0e33425a1906e = array();
						$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

						foreach ($e80d13748eba016a as $e81220b4451f37c9) {
							if ($e81220b4451f37c9['parent'] == '#') {
							} else {
								$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);

								if (in_array($a27e64cc6ce01033['server_type'], array('ADD', 'SET'))) {
									$bdb0e33425a1906e[] = $d58b4f8653a391d8;

									if (isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$F6fa7e329a8218d7 .= '(' . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . '),';
										$Ddf12215b82c5bba[$F26087d31c2bbe4d][] = $d58b4f8653a391d8;
									}
								} else {
									if (!isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}

						if ($a27e64cc6ce01033['server_type'] != 'SET') {
						} else {
							foreach ($F9163b7e6a33fe89[$F26087d31c2bbe4d] as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;

									if (($D3fa098be3f297cd = array_search($d58b4f8653a391d8, $Ddf12215b82c5bba[$F26087d31c2bbe4d])) === false) {
									} else {
										unset($Ddf12215b82c5bba[$F26087d31c2bbe4d][$D3fa098be3f297cd]);
									}
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['c_bouquets'])) {
					} else {
						if ($a27e64cc6ce01033['bouquets_type'] == 'SET') {
							foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
								$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								if (in_array($ddf0508b312dbfb8['id'], $a27e64cc6ce01033['bouquets'])) {
								} else {
									$fb5ea0f21131b307[$ddf0508b312dbfb8['id']][] = $F26087d31c2bbe4d;
								}
							}
						} else {
							if ($a27e64cc6ce01033['bouquets_type'] == 'ADD') {
								foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
									$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
								}
							} else {
								if ($a27e64cc6ce01033['bouquets_type'] != 'DEL') {
								} else {
									foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
										$fb5ea0f21131b307[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['reencode_on_edit'])) {
					} else {
						foreach ($Ddf12215b82c5bba[$F26087d31c2bbe4d] as $d58b4f8653a391d8) {
							$d1cd3e64591ec1c1[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
						}
					}

					foreach ($a6629cd1b10b6170 as $d58b4f8653a391d8 => $a811da190447e007) {
						deleteStreamsByServer($a811da190447e007, $d58b4f8653a391d8, true);
					}
				}

				foreach ($ed2502d79a409dc0 as $C52c0b6b0f74407b => $F541acfbbe8cc24e) {
					d7e7f81f646193B2('movie', $C52c0b6b0f74407b, $F541acfbbe8cc24e);
				}

				foreach ($fb5ea0f21131b307 as $C52c0b6b0f74407b => $Fc8096aca65c232b) {
					D83cFf66bcdBee05('movie', $C52c0b6b0f74407b, $Fc8096aca65c232b);
				}

				if (empty($F6fa7e329a8218d7)) {
				} else {
					$F6fa7e329a8218d7 = rtrim($F6fa7e329a8218d7, ',');
					self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`) VALUES ' . $F6fa7e329a8218d7 . ';');
				}

				XUI::updateStreams($Cdb85875fd50f459);

				if (!isset($a27e64cc6ce01033['reencode_on_edit'])) {
				} else {
					foreach ($d1cd3e64591ec1c1 as $d58b4f8653a391d8 => $a71db34f1117f574) {
						XUI::queueMovies($a71db34f1117f574, $d58b4f8653a391d8);
					}
				}

				if (!isset($a27e64cc6ce01033['reprocess_tmdb'])) {
				} else {
					XUI::refreshMovies($Cdb85875fd50f459, 1);
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function BA66921612ED64B0($a27e64cc6ce01033)
	{
		if (self::F228e3d146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AacD47d8157a1a09('adv', 'edit_package')) {
					$d49041d5f05a9270 = EbdaAfc1c10f9506(F0acaB09e248fc13($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (aacD47D8157A1A09('adv', 'add_packages')) {
					$d49041d5f05a9270 = b9da5D708Fc1c079('users_packages', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (strlen($a27e64cc6ce01033['package_name']) != 0) {
				foreach (array('is_trial', 'is_official', 'is_mag', 'is_e2', 'is_line', 'lock_device', 'is_restreamer', 'is_isplock', 'check_compatible') as $Ba3157bbbca6db35) {
					if (isset($a27e64cc6ce01033[$Ba3157bbbca6db35])) {
						$d49041d5f05a9270[$Ba3157bbbca6db35] = 1;
					} else {
						$d49041d5f05a9270[$Ba3157bbbca6db35] = 0;
					}
				}
				$d49041d5f05a9270['groups'] = '[' . implode(',', array_map('intval', json_decode($a27e64cc6ce01033['groups_selected'], true))) . ']';
				$d49041d5f05a9270['bouquets'] = sortArrayByArray(array_values(json_decode($a27e64cc6ce01033['bouquets_selected'], true)), array_keys(a53403FC10f556BE()));
				$d49041d5f05a9270['bouquets'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['bouquets'])) . ']';

				if (!isset($a27e64cc6ce01033['output_formats'])) {
				} else {
					$d49041d5f05a9270['output_formats'] = array();

					foreach ($a27e64cc6ce01033['output_formats'] as $f433193a3297ffde) {
						$d49041d5f05a9270['output_formats'][] = $f433193a3297ffde;
					}
					$d49041d5f05a9270['output_formats'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['output_formats'])) . ']';
				}

				$acd0eb2c8a975903 = F4817dC607D9981d($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `users_packages`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			} else {
				return array('status' => STATUS_INVALID_NAME, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function EB9eaD5B16d184F3($a27e64cc6ce01033)
	{
		if (self::f228e3d146e758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (aACD47D8157a1A09('adv', 'edit_mag')) {
					$d49041d5f05a9270 = EbdaafC1c10f9506(bfE9937c6D242a3D($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
					$d51e425eb7375255 = b4036eF9a1DB8473($d49041d5f05a9270['user_id']);

					if ($d51e425eb7375255) {
						$C2cdb5dc50f13c15 = EBDaaFC1c10F9506($d51e425eb7375255, $a27e64cc6ce01033);
					} else {
						$C2cdb5dc50f13c15 = B9DA5D708fC1c079('lines', $a27e64cc6ce01033);
						$C2cdb5dc50f13c15['created_at'] = time();
						unset($C2cdb5dc50f13c15['id']);
					}
				} else {
					exit();
				}
			} else {
				if (AACD47d8157A1a09('adv', 'add_mag')) {
					$d49041d5f05a9270 = B9da5d708fC1C079('mag_devices', $a27e64cc6ce01033);
					$d49041d5f05a9270['theme_type'] = XUI::$rSettings['mag_default_type'];
					$C2cdb5dc50f13c15 = B9Da5D708fC1c079('lines', $a27e64cc6ce01033);
					$C2cdb5dc50f13c15['created_at'] = time();
					unset($d49041d5f05a9270['mag_id'], $C2cdb5dc50f13c15['id']);
				} else {
					exit();
				}
			}

			if (strlen($C2cdb5dc50f13c15['username']) != 0) {
			} else {
				$C2cdb5dc50f13c15['username'] = D7445B70978659Ba(32);
			}

			if (strlen($C2cdb5dc50f13c15['password']) != 0) {
			} else {
				$C2cdb5dc50f13c15['password'] = D7445B70978659ba(32);
			}

			if (strlen($a27e64cc6ce01033['isp_clear']) != 0) {
			} else {
				$C2cdb5dc50f13c15['isp_desc'] = '';
				$C2cdb5dc50f13c15['as_number'] = null;
			}

			$C2cdb5dc50f13c15['is_mag'] = 1;
			$C2cdb5dc50f13c15['is_e2'] = 0;
			$C2cdb5dc50f13c15['max_connections'] = 1;
			$C2cdb5dc50f13c15['is_restreamer'] = 0;

			if (isset($a27e64cc6ce01033['is_trial'])) {
				$C2cdb5dc50f13c15['is_trial'] = 1;
			} else {
				$C2cdb5dc50f13c15['is_trial'] = 0;
			}

			if (isset($a27e64cc6ce01033['is_isplock'])) {
				$C2cdb5dc50f13c15['is_isplock'] = 1;
			} else {
				$C2cdb5dc50f13c15['is_isplock'] = 0;
			}

			if (isset($a27e64cc6ce01033['lock_device'])) {
				$d49041d5f05a9270['lock_device'] = 1;
			} else {
				$d49041d5f05a9270['lock_device'] = 0;
			}

			$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray(array_values(json_decode($a27e64cc6ce01033['bouquets_selected'], true)), array_keys(A53403fc10F556bE()));
			$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';

			if (isset($a27e64cc6ce01033['exp_date']) && !isset($a27e64cc6ce01033['no_expire'])) {
				if (!(0 < strlen($a27e64cc6ce01033['exp_date']) && $a27e64cc6ce01033['exp_date'] != '1970-01-01')) {
				} else {
					try {
						$c94b497359f8aed9 = new DateTime($a27e64cc6ce01033['exp_date']);
						$C2cdb5dc50f13c15['exp_date'] = $c94b497359f8aed9->format('U');
					} catch (Exception $c34ae71903f0d920) {
						return array('status' => STATUS_INVALID_DATE, 'data' => $a27e64cc6ce01033);
					}
				}
			} else {
				$C2cdb5dc50f13c15['exp_date'] = null;
			}

			if ($C2cdb5dc50f13c15['member_id']) {
			} else {
				$C2cdb5dc50f13c15['member_id'] = self::$rUserInfo['id'];
			}

			if (isset($a27e64cc6ce01033['allowed_ips'])) {
				if (is_array($a27e64cc6ce01033['allowed_ips'])) {
				} else {
					$a27e64cc6ce01033['allowed_ips'] = array($a27e64cc6ce01033['allowed_ips']);
				}

				$C2cdb5dc50f13c15['allowed_ips'] = json_encode($a27e64cc6ce01033['allowed_ips']);
			} else {
				$C2cdb5dc50f13c15['allowed_ips'] = '[]';
			}

			if (isset($a27e64cc6ce01033['pair_id'])) {
				$C2cdb5dc50f13c15['pair_id'] = intval($a27e64cc6ce01033['pair_id']);
			} else {
				$C2cdb5dc50f13c15['pair_id'] = null;
			}

			$C2cdb5dc50f13c15['allowed_outputs'] = '[' . implode(',', array(1, 2)) . ']';
			$cdc93dae5ba3d206 = $d49041d5f05a9270;
			$cdc93dae5ba3d206['user'] = $C2cdb5dc50f13c15;

			if (0 >= $cdc93dae5ba3d206['user']['pair_id']) {
			} else {
				$cb2ed88e93784ffb = b4036eF9A1db8473($cdc93dae5ba3d206['user']['pair_id']);

				if ($cb2ed88e93784ffb) {
				} else {
					return array('status' => STATUS_INVALID_USER, 'data' => $a27e64cc6ce01033);
				}
			}

			if (filter_var($a27e64cc6ce01033['mac'], FILTER_VALIDATE_MAC)) {
				if (isset($a27e64cc6ce01033['edit'])) {
					self::$db->query('SELECT `mag_id` FROM `mag_devices` WHERE mac = ? AND `mag_id` <> ? LIMIT 1;', $d49041d5f05a9270['mac'], $a27e64cc6ce01033['edit']);
				} else {
					self::$db->query('SELECT `mag_id` FROM `mag_devices` WHERE mac = ? LIMIT 1;', $d49041d5f05a9270['mac']);
				}

				if (0 >= self::$db->num_rows()) {
					$acd0eb2c8a975903 = f4817Dc607D9981d($C2cdb5dc50f13c15);
					$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					} else {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
						$d49041d5f05a9270['user_id'] = $Fc2dc5a0ce8d07ea;
						XUI::BC77eDC4169F1BaA($d49041d5f05a9270['user_id']);
						unset($d49041d5f05a9270['user'], $d49041d5f05a9270['paired']);

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							$d49041d5f05a9270['ver'] = '';
							$d49041d5f05a9270['device_id2'] = $d49041d5f05a9270['ver'];
							$d49041d5f05a9270['device_id'] = $d49041d5f05a9270['device_id2'];
							$d49041d5f05a9270['hw_version'] = $d49041d5f05a9270['device_id'];
							$d49041d5f05a9270['stb_type'] = $d49041d5f05a9270['hw_version'];
							$d49041d5f05a9270['image_version'] = $d49041d5f05a9270['stb_type'];
							$d49041d5f05a9270['sn'] = $d49041d5f05a9270['image_version'];
						}

						$acd0eb2c8a975903 = F4817Dc607D9981D($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `mag_devices`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

							if (0 >= $cdc93dae5ba3d206['user']['pair_id']) {
							} else {
								a85a61d6F165008a($cdc93dae5ba3d206['user']['pair_id'], $Fc2dc5a0ce8d07ea);
								XUI::BC77eDC4169f1BAa($cdc93dae5ba3d206['user']['pair_id']);
							}

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							self::$db->query('DELETE FROM `lines` WHERE `id` = ?;', $Fc2dc5a0ce8d07ea);
						}
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_EXISTS_MAC, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_MAC, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function ECAF66B237906519($a27e64cc6ce01033)
	{
		if (self::f228e3D146E758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (Aacd47D8157a1a09('adv', 'edit_e2')) {
					$d49041d5f05a9270 = ebDaAFC1c10F9506(BA960cAb7fE0CD93($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
					$d51e425eb7375255 = b4036eF9A1Db8473($d49041d5f05a9270['user_id']);

					if ($d51e425eb7375255) {
						$C2cdb5dc50f13c15 = EbdAAfc1C10f9506($d51e425eb7375255, $a27e64cc6ce01033);
					} else {
						$C2cdb5dc50f13c15 = B9Da5d708FC1c079('lines', $a27e64cc6ce01033);
						$C2cdb5dc50f13c15['created_at'] = time();
						unset($C2cdb5dc50f13c15['id']);
					}
				} else {
					exit();
				}
			} else {
				if (aaCD47d8157A1A09('adv', 'add_e2')) {
					$d49041d5f05a9270 = b9da5D708FC1c079('enigma2_devices', $a27e64cc6ce01033);
					$C2cdb5dc50f13c15 = b9da5D708FC1c079('lines', $a27e64cc6ce01033);
					$C2cdb5dc50f13c15['created_at'] = time();
					unset($d49041d5f05a9270['device_id'], $C2cdb5dc50f13c15['id']);
				} else {
					exit();
				}
			}

			if (strlen($C2cdb5dc50f13c15['username']) != 0) {
			} else {
				$C2cdb5dc50f13c15['username'] = D7445b70978659BA(32);
			}

			if (strlen($C2cdb5dc50f13c15['password']) != 0) {
			} else {
				$C2cdb5dc50f13c15['password'] = d7445b70978659ba(32);
			}

			if (strlen($a27e64cc6ce01033['isp_clear']) != 0) {
			} else {
				$C2cdb5dc50f13c15['isp_desc'] = '';
				$C2cdb5dc50f13c15['as_number'] = null;
			}

			$C2cdb5dc50f13c15['is_e2'] = 1;
			$C2cdb5dc50f13c15['is_mag'] = 0;
			$C2cdb5dc50f13c15['max_connections'] = 1;
			$C2cdb5dc50f13c15['is_restreamer'] = 0;

			if (isset($a27e64cc6ce01033['is_trial'])) {
				$C2cdb5dc50f13c15['is_trial'] = 1;
			} else {
				$C2cdb5dc50f13c15['is_trial'] = 0;
			}

			if (isset($a27e64cc6ce01033['is_isplock'])) {
				$C2cdb5dc50f13c15['is_isplock'] = 1;
			} else {
				$C2cdb5dc50f13c15['is_isplock'] = 0;
			}

			if (isset($a27e64cc6ce01033['lock_device'])) {
				$d49041d5f05a9270['lock_device'] = 1;
			} else {
				$d49041d5f05a9270['lock_device'] = 0;
			}

			$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray(array_values(json_decode($a27e64cc6ce01033['bouquets_selected'], true)), array_keys(a53403FC10f556BE()));
			$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';

			if (isset($a27e64cc6ce01033['exp_date']) && !isset($a27e64cc6ce01033['no_expire'])) {
				if (!(0 < strlen($a27e64cc6ce01033['exp_date']) && $a27e64cc6ce01033['exp_date'] != '1970-01-01')) {
				} else {
					try {
						$c94b497359f8aed9 = new DateTime($a27e64cc6ce01033['exp_date']);
						$C2cdb5dc50f13c15['exp_date'] = $c94b497359f8aed9->format('U');
					} catch (Exception $c34ae71903f0d920) {
						return array('status' => STATUS_INVALID_DATE, 'data' => $a27e64cc6ce01033);
					}
				}
			} else {
				$C2cdb5dc50f13c15['exp_date'] = null;
			}

			if ($C2cdb5dc50f13c15['member_id']) {
			} else {
				$C2cdb5dc50f13c15['member_id'] = self::$rUserInfo['id'];
			}

			if (isset($a27e64cc6ce01033['allowed_ips'])) {
				if (is_array($a27e64cc6ce01033['allowed_ips'])) {
				} else {
					$a27e64cc6ce01033['allowed_ips'] = array($a27e64cc6ce01033['allowed_ips']);
				}

				$C2cdb5dc50f13c15['allowed_ips'] = json_encode($a27e64cc6ce01033['allowed_ips']);
			} else {
				$C2cdb5dc50f13c15['allowed_ips'] = '[]';
			}

			if (isset($a27e64cc6ce01033['pair_id'])) {
				$C2cdb5dc50f13c15['pair_id'] = intval($a27e64cc6ce01033['pair_id']);
			} else {
				$C2cdb5dc50f13c15['pair_id'] = null;
			}

			$C2cdb5dc50f13c15['allowed_outputs'] = '[' . implode(',', array(1, 2)) . ']';
			$cdc93dae5ba3d206 = $d49041d5f05a9270;
			$cdc93dae5ba3d206['user'] = $C2cdb5dc50f13c15;

			if (0 >= $cdc93dae5ba3d206['user']['pair_id']) {
			} else {
				$cb2ed88e93784ffb = B4036eF9A1DB8473($cdc93dae5ba3d206['user']['pair_id']);

				if ($cb2ed88e93784ffb) {
				} else {
					return array('status' => STATUS_INVALID_USER, 'data' => $a27e64cc6ce01033);
				}
			}

			if (filter_var($a27e64cc6ce01033['mac'], FILTER_VALIDATE_MAC)) {
				if (isset($a27e64cc6ce01033['edit'])) {
					self::$db->query('SELECT `device_id` FROM `enigma2_devices` WHERE mac = ? AND `device_id` <> ? LIMIT 1;', $d49041d5f05a9270['mac'], $a27e64cc6ce01033['edit']);
				} else {
					self::$db->query('SELECT `device_id` FROM `enigma2_devices` WHERE mac = ? LIMIT 1;', $d49041d5f05a9270['mac']);
				}

				if (0 >= self::$db->num_rows()) {
					$acd0eb2c8a975903 = f4817DC607d9981D($C2cdb5dc50f13c15);
					$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					} else {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
						$d49041d5f05a9270['user_id'] = $Fc2dc5a0ce8d07ea;
						XUI::Bc77edc4169F1Baa($d49041d5f05a9270['user_id']);
						unset($d49041d5f05a9270['user'], $d49041d5f05a9270['paired']);

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							$d49041d5f05a9270['token'] = '';
							$d49041d5f05a9270['lversion'] = $d49041d5f05a9270['token'];
							$d49041d5f05a9270['cpu'] = $d49041d5f05a9270['lversion'];
							$d49041d5f05a9270['enigma_version'] = $d49041d5f05a9270['cpu'];
							$d49041d5f05a9270['local_ip'] = $d49041d5f05a9270['enigma_version'];
							$d49041d5f05a9270['modem_mac'] = $d49041d5f05a9270['local_ip'];
						}

						$acd0eb2c8a975903 = F4817Dc607d9981D($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `enigma2_devices`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

							if (0 >= $cdc93dae5ba3d206['user']['pair_id']) {
							} else {
								a85a61d6F165008A($cdc93dae5ba3d206['user']['pair_id'], $Fc2dc5a0ce8d07ea);
								XUI::bC77Edc4169F1baa($cdc93dae5ba3d206['user']['pair_id']);
							}

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							self::$db->query('DELETE FROM `lines` WHERE `id` = ?;', $Fc2dc5a0ce8d07ea);
						}
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_EXISTS_MAC, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_MAC, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function A6c9cF2c4EDc8627($a27e64cc6ce01033)
	{
		if (self::f228E3D146E758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array('profile_name' => $a27e64cc6ce01033['profile_name'], 'profile_options' => null);
			$Acdfe35de0f15bdd = array();

			if ($a27e64cc6ce01033['gpu_device'] != 0) {
				$Acdfe35de0f15bdd['software_decoding'] = (intval($a27e64cc6ce01033['software_decoding']) ?: 0);
				$Acdfe35de0f15bdd['gpu'] = array('val' => $a27e64cc6ce01033['gpu_device'], 'cmd' => '');
				$Acdfe35de0f15bdd['gpu']['device'] = intval(explode('_', $a27e64cc6ce01033['gpu_device'])[1]);

				if (!$a27e64cc6ce01033['software_decoding']) {
					$cf1c389bda3e30fd = array();
					$cf1c389bda3e30fd[] = '-hwaccel cuvid';
					$cf1c389bda3e30fd[] = '-hwaccel_device ' . $Acdfe35de0f15bdd['gpu']['device'];

					if (0 >= strlen($a27e64cc6ce01033['resize'])) {
					} else {
						$Acdfe35de0f15bdd['gpu']['resize'] = $a27e64cc6ce01033['resize'];
						$cf1c389bda3e30fd[] = '-resize ' . escapeshellcmd($a27e64cc6ce01033['resize']);
					}

					if (0 >= $a27e64cc6ce01033['deint']) {
					} else {
						$Acdfe35de0f15bdd['gpu']['deint'] = intval($a27e64cc6ce01033['deint']);
						$cf1c389bda3e30fd[] = '-deint ' . intval($a27e64cc6ce01033['deint']);
					}

					$A387578f69b4c724 = '';

					if (0 >= strlen($a27e64cc6ce01033['video_codec_gpu'])) {
					} else {
						$Acdfe35de0f15bdd['-vcodec'] = escapeshellcmd($a27e64cc6ce01033['video_codec_gpu']);
						$cf1c389bda3e30fd[] = '{INPUT_CODEC}';

						switch ($a27e64cc6ce01033['video_codec_gpu']) {
							case 'hevc_nvenc':
								$A387578f69b4c724 = 'hevc';

								break;

							default:
								$A387578f69b4c724 = 'h264';

								break;
						}
					}

					if (0 >= strlen($a27e64cc6ce01033['preset_' . $A387578f69b4c724])) {
					} else {
						$Acdfe35de0f15bdd['-preset'] = escapeshellcmd($a27e64cc6ce01033['preset_' . $A387578f69b4c724]);
					}

					if (0 >= strlen($a27e64cc6ce01033['video_profile_' . $A387578f69b4c724])) {
					} else {
						$Acdfe35de0f15bdd['-profile:v'] = escapeshellcmd($a27e64cc6ce01033['video_profile_' . $A387578f69b4c724]);
					}

					$cf1c389bda3e30fd[] = '-gpu ' . $Acdfe35de0f15bdd['gpu']['device'];
					$cf1c389bda3e30fd[] = '-drop_second_field 1';
					$Acdfe35de0f15bdd['gpu']['cmd'] = implode(' ', $cf1c389bda3e30fd);
				} else {
					$A387578f69b4c724 = '';

					if (0 >= strlen($a27e64cc6ce01033['video_codec_gpu'])) {
					} else {
						$Acdfe35de0f15bdd['-vcodec'] = escapeshellcmd($a27e64cc6ce01033['video_codec_gpu']);

						switch ($a27e64cc6ce01033['video_codec_gpu']) {
							case 'hevc_nvenc':
								$A387578f69b4c724 = 'hevc';

								break;
						}
						$A387578f69b4c724 = 'h264';
					}

					if (0 >= strlen($a27e64cc6ce01033['preset_' . $A387578f69b4c724])) {
					} else {
						$Acdfe35de0f15bdd['-preset'] = escapeshellcmd($a27e64cc6ce01033['preset_' . $A387578f69b4c724]);
					}

					if (0 >= strlen($a27e64cc6ce01033['video_profile_' . $A387578f69b4c724])) {
					} else {
						$Acdfe35de0f15bdd['-profile:v'] = escapeshellcmd($a27e64cc6ce01033['video_profile_' . $A387578f69b4c724]);
					}
				}
			} else {
				if (0 >= strlen($a27e64cc6ce01033['video_codec_cpu'])) {
				} else {
					$Acdfe35de0f15bdd['-vcodec'] = escapeshellcmd($a27e64cc6ce01033['video_codec_cpu']);
				}

				if (0 >= strlen($a27e64cc6ce01033['preset_cpu'])) {
				} else {
					$Acdfe35de0f15bdd['-preset'] = escapeshellcmd($a27e64cc6ce01033['preset_cpu']);
				}

				if (0 >= strlen($a27e64cc6ce01033['video_profile_cpu'])) {
				} else {
					$Acdfe35de0f15bdd['-profile:v'] = escapeshellcmd($a27e64cc6ce01033['video_profile_cpu']);
				}
			}

			if (0 >= strlen($a27e64cc6ce01033['audio_codec'])) {
			} else {
				$Acdfe35de0f15bdd['-acodec'] = escapeshellcmd($a27e64cc6ce01033['audio_codec']);
			}

			if (0 >= strlen($a27e64cc6ce01033['video_bitrate'])) {
			} else {
				$Acdfe35de0f15bdd[3] = array('cmd' => '-b:v ' . intval($a27e64cc6ce01033['video_bitrate']) . 'k', 'val' => intval($a27e64cc6ce01033['video_bitrate']));
			}

			if (0 >= strlen($a27e64cc6ce01033['audio_bitrate'])) {
			} else {
				$Acdfe35de0f15bdd[4] = array('cmd' => '-b:a ' . intval($a27e64cc6ce01033['audio_bitrate']) . 'k', 'val' => intval($a27e64cc6ce01033['audio_bitrate']));
			}

			if (0 >= strlen($a27e64cc6ce01033['min_tolerance'])) {
			} else {
				$Acdfe35de0f15bdd[5] = array('cmd' => '-minrate ' . intval($a27e64cc6ce01033['min_tolerance']) . 'k', 'val' => intval($a27e64cc6ce01033['min_tolerance']));
			}

			if (0 >= strlen($a27e64cc6ce01033['max_tolerance'])) {
			} else {
				$Acdfe35de0f15bdd[6] = array('cmd' => '-maxrate ' . intval($a27e64cc6ce01033['max_tolerance']) . 'k', 'val' => intval($a27e64cc6ce01033['max_tolerance']));
			}

			if (0 >= strlen($a27e64cc6ce01033['buffer_size'])) {
			} else {
				$Acdfe35de0f15bdd[7] = array('cmd' => '-bufsize ' . intval($a27e64cc6ce01033['buffer_size']) . 'k', 'val' => intval($a27e64cc6ce01033['buffer_size']));
			}

			if (0 >= strlen($a27e64cc6ce01033['crf_value'])) {
			} else {
				$Acdfe35de0f15bdd[8] = array('cmd' => '-crf ' . intval($a27e64cc6ce01033['crf_value']), 'val' => $a27e64cc6ce01033['crf_value']);
			}

			if (0 >= strlen($a27e64cc6ce01033['aspect_ratio'])) {
			} else {
				$Acdfe35de0f15bdd[10] = array('cmd' => '-aspect ' . escapeshellcmd($a27e64cc6ce01033['aspect_ratio']), 'val' => $a27e64cc6ce01033['aspect_ratio']);
			}

			if (0 >= strlen($a27e64cc6ce01033['framerate'])) {
			} else {
				$Acdfe35de0f15bdd[11] = array('cmd' => '-r ' . intval($a27e64cc6ce01033['framerate']), 'val' => intval($a27e64cc6ce01033['framerate']));
			}

			if (0 >= strlen($a27e64cc6ce01033['samplerate'])) {
			} else {
				$Acdfe35de0f15bdd[12] = array('cmd' => '-ar ' . intval($a27e64cc6ce01033['samplerate']), 'val' => intval($a27e64cc6ce01033['samplerate']));
			}

			if (0 >= strlen($a27e64cc6ce01033['audio_channels'])) {
			} else {
				$Acdfe35de0f15bdd[13] = array('cmd' => '-ac ' . intval($a27e64cc6ce01033['audio_channels']), 'val' => intval($a27e64cc6ce01033['audio_channels']));
			}

			if (0 >= strlen($a27e64cc6ce01033['threads'])) {
			} else {
				$Acdfe35de0f15bdd[15] = array('cmd' => '-threads ' . intval($a27e64cc6ce01033['threads']), 'val' => intval($a27e64cc6ce01033['threads']));
			}

			$C156097d0746b164 = false;
			$d8af01b7cb70c0fe = $c94ff1c8fddf38e8 = $C3d1a0acaf4eb3a3 = '';

			if (0 >= strlen($a27e64cc6ce01033['logo_path'])) {
			} else {
				$C156097d0746b164 = true;
				$Aa07a44246fb374e = array_map('intval', explode(':', $a27e64cc6ce01033['logo_pos']));

				if (count($Aa07a44246fb374e) == 2) {
				} else {
					$Aa07a44246fb374e = array(10, 10);
				}

				$C3d1a0acaf4eb3a3 = '-i ' . escapeshellarg($a27e64cc6ce01033['logo_path']);
				$Acdfe35de0f15bdd[16] = array('cmd' => '', 'val' => $a27e64cc6ce01033['logo_path'], 'pos' => implode(':', $Aa07a44246fb374e));

				if ($a27e64cc6ce01033['gpu_device'] != 0 && !$a27e64cc6ce01033['software_decoding']) {
					$c94ff1c8fddf38e8 = '[0:v]hwdownload,format=nv12 [base]; [base][1:v] overlay=' . $Aa07a44246fb374e[0] . ':' . $Aa07a44246fb374e[1];
				} else {
					$c94ff1c8fddf38e8 = 'overlay=' . $Aa07a44246fb374e[0] . ':' . $Aa07a44246fb374e[1];
				}
			}

			if ($a27e64cc6ce01033['gpu_device'] == 0) {
				if (!(isset($a27e64cc6ce01033['yadif_filter']) && 0 < strlen($a27e64cc6ce01033['scaling']))) {
				} else {
					$C156097d0746b164 = true;
				}

				if ($C156097d0746b164) {
					if (isset($a27e64cc6ce01033['yadif_filter']) && 0 < strlen($a27e64cc6ce01033['scaling'])) {
						if (!$a27e64cc6ce01033['software_decoding']) {
							$d8af01b7cb70c0fe = '[0:v]yadif,scale=' . escapeshellcmd($a27e64cc6ce01033['scaling']) . '[bg];[bg][1:v]';
						} else {
							$d8af01b7cb70c0fe = 'yadif,scale=' . escapeshellcmd($a27e64cc6ce01033['scaling']);
						}

						$Acdfe35de0f15bdd[9] = array('cmd' => '', 'val' => $a27e64cc6ce01033['scaling']);
						$Acdfe35de0f15bdd[17] = array('cmd' => '', 'val' => 1);
					} else {
						if (0 < strlen($a27e64cc6ce01033['scaling'])) {
							$d8af01b7cb70c0fe = 'scale=' . escapeshellcmd($a27e64cc6ce01033['scaling']);
							$Acdfe35de0f15bdd[9] = array('cmd' => '', 'val' => $a27e64cc6ce01033['scaling']);
						} else {
							if (!isset($a27e64cc6ce01033['yadif_filter'])) {
							} else {
								if (!$a27e64cc6ce01033['software_decoding']) {
									$d8af01b7cb70c0fe = '[0:v]yadif[bg];[bg][1:v]';
								} else {
									$d8af01b7cb70c0fe = 'yadif';
								}

								$Acdfe35de0f15bdd[17] = array('cmd' => '', 'val' => 1);
							}
						}
					}
				} else {
					if (0 >= strlen($a27e64cc6ce01033['scaling'])) {
					} else {
						$Acdfe35de0f15bdd[9] = array('cmd' => '-vf scale=' . escapeshellcmd($a27e64cc6ce01033['scaling']), 'val' => $a27e64cc6ce01033['scaling']);
					}

					if (!isset($a27e64cc6ce01033['yadif_filter'])) {
					} else {
						$Acdfe35de0f15bdd[17] = array('cmd' => '-vf yadif', 'val' => 1);
					}
				}
			} else {
				if (!$a27e64cc6ce01033['software_decoding']) {
				} else {
					if (!(0 < intval($a27e64cc6ce01033['deint']) && 0 < strlen($a27e64cc6ce01033['resize']))) {
					} else {
						$C156097d0746b164 = true;
					}

					if ($C156097d0746b164) {
						if (0 < intval($a27e64cc6ce01033['deint']) && 0 < strlen($a27e64cc6ce01033['resize'])) {
							if (!$a27e64cc6ce01033['software_decoding']) {
								$d8af01b7cb70c0fe = '[0:v]yadif,scale=' . escapeshellcmd($a27e64cc6ce01033['resize']) . '[bg];[bg][1:v]';
							} else {
								$d8af01b7cb70c0fe = 'yadif,scale=' . escapeshellcmd($a27e64cc6ce01033['resize']);
							}

							$Acdfe35de0f15bdd[9] = array('cmd' => '', 'val' => $a27e64cc6ce01033['resize']);
							$Acdfe35de0f15bdd[17] = array('cmd' => '', 'val' => 1);
						} else {
							if (0 < strlen($a27e64cc6ce01033['resize'])) {
								if (!$a27e64cc6ce01033['software_decoding']) {
									$d8af01b7cb70c0fe = '[0:v]scale=' . escapeshellcmd($a27e64cc6ce01033['resize']) . '[bg];[bg][1:v]';
								} else {
									$d8af01b7cb70c0fe = 'scale=' . escapeshellcmd($a27e64cc6ce01033['resize']);
								}

								$Acdfe35de0f15bdd[9] = array('cmd' => '', 'val' => $a27e64cc6ce01033['resize']);
							} else {
								if (0 >= intval($a27e64cc6ce01033['deint'])) {
								} else {
									if (!$a27e64cc6ce01033['software_decoding']) {
										$d8af01b7cb70c0fe = '[0:v]yadif[bg];[bg][1:v]';
									} else {
										$d8af01b7cb70c0fe = 'yadif';
									}

									$Acdfe35de0f15bdd[17] = array('cmd' => '', 'val' => 1);
								}
							}
						}
					} else {
						if (0 >= strlen($a27e64cc6ce01033['resize'])) {
						} else {
							$Acdfe35de0f15bdd[9] = array('cmd' => '-vf scale=' . escapeshellcmd($a27e64cc6ce01033['resize']), 'val' => $a27e64cc6ce01033['resize']);
						}

						if (0 >= intval($a27e64cc6ce01033['deint'])) {
						} else {
							$Acdfe35de0f15bdd[17] = array('cmd' => '-vf yadif', 'val' => 1);
						}
					}
				}
			}

			if (!$C156097d0746b164) {
			} else {
				if (!empty($d8af01b7cb70c0fe) && substr($d8af01b7cb70c0fe, strlen($d8af01b7cb70c0fe) - 1, 1) != ']') {
					$c94ff1c8fddf38e8 = ',' . $c94ff1c8fddf38e8;
				} else {
					if (empty($d8af01b7cb70c0fe)) {
					} else {
						$c94ff1c8fddf38e8 = ' ' . $c94ff1c8fddf38e8;
					}
				}

				$Acdfe35de0f15bdd[16]['cmd'] = str_replace(array('{SCALE}', '{OVERLAY}', '{LOGO}'), array($d8af01b7cb70c0fe, $c94ff1c8fddf38e8, $C3d1a0acaf4eb3a3), '{LOGO} -filter_complex "{SCALE}{OVERLAY}"');
			}

			$d49041d5f05a9270['profile_options'] = json_encode($Acdfe35de0f15bdd, JSON_UNESCAPED_UNICODE);

			if (!isset($a27e64cc6ce01033['edit'])) {
			} else {
				$d49041d5f05a9270['profile_id'] = $a27e64cc6ce01033['edit'];
			}

			$acd0eb2c8a975903 = f4817dC607D9981D($d49041d5f05a9270);
			$A6d7047f2fda966c = 'REPLACE INTO `profiles`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

			if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			}

			return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function BfECe7b7Fa4F9Dc0($a27e64cc6ce01033)
	{
		if (self::f228E3D146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (aAcd47D8157a1A09('adv', 'edit_radio')) {
					$d49041d5f05a9270 = Ebdaafc1c10F9506(e5eceB32f67D5e70($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (aAcd47d8157A1a09('adv', 'add_radio')) {
					$d49041d5f05a9270 = B9Da5D708fC1C079('streams', $a27e64cc6ce01033);
					$d49041d5f05a9270['type'] = 4;
					$d49041d5f05a9270['added'] = time();
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (isset($a27e64cc6ce01033['days_to_restart']) && preg_match('/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/', $a27e64cc6ce01033['time_to_restart'])) {
				$b7832adc388cb5a7 = array('days' => array(), 'at' => $a27e64cc6ce01033['time_to_restart']);

				foreach ($a27e64cc6ce01033['days_to_restart'] as $C3c8913edb801c35 => $d20afc15ac839efc) {
					$b7832adc388cb5a7['days'][] = $d20afc15ac839efc;
				}
				$d49041d5f05a9270['auto_restart'] = $b7832adc388cb5a7;
			} else {
				$d49041d5f05a9270['auto_restart'] = '';
			}

			if (isset($a27e64cc6ce01033['direct_source'])) {
				$d49041d5f05a9270['direct_source'] = 1;
			} else {
				$d49041d5f05a9270['direct_source'] = 0;
			}

			if (isset($a27e64cc6ce01033['probesize_ondemand'])) {
				$d49041d5f05a9270['probesize_ondemand'] = intval($a27e64cc6ce01033['probesize_ondemand']);
			} else {
				$d49041d5f05a9270['probesize_ondemand'] = 128000;
			}

			if (isset($a27e64cc6ce01033['restart_on_edit'])) {
				$d81f27c553f73ff4 = true;
			} else {
				$d81f27c553f73ff4 = false;
			}

			$Ab3cebb99a2b671e = array();

			if (0 < strlen($a27e64cc6ce01033['stream_source'][0])) {
				$eaad9527ef2b563d = array('stream_source' => $a27e64cc6ce01033['stream_source'], 'stream_icon' => $d49041d5f05a9270['stream_icon'], 'stream_display_name' => $d49041d5f05a9270['stream_display_name']);
				$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;

				if (0 < count($Ab3cebb99a2b671e)) {
					$f518050a6d5f89c7 = array();

					foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
						$acd0eb2c8a975903 = f4817dC607d9981d(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
						$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$C52c0b6b0f74407b = self::$db->last_insert_id();
							$f518050a6d5f89c7[$ddf0508b312dbfb8] = $C52c0b6b0f74407b;
						}
					}
					$Ae4bd014b3779489 = array();

					foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
						$acd0eb2c8a975903 = f4817DC607d9981D(array('category_type' => 'radio', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
						$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$Be965cdd996d4520 = self::$db->last_insert_id();
							$Ae4bd014b3779489[$A1925ae53e9307eb] = $Be965cdd996d4520;
						}
					}

					foreach ($Ab3cebb99a2b671e as $addee113c4cee30c) {
						$cb498e4dcaac05cc = array();

						foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
							if (isset($f518050a6d5f89c7[$ddf0508b312dbfb8])) {
								$cb498e4dcaac05cc[] = $f518050a6d5f89c7[$ddf0508b312dbfb8];
							} else {
								if (!is_numeric($ddf0508b312dbfb8)) {
								} else {
									$cb498e4dcaac05cc[] = intval($ddf0508b312dbfb8);
								}
							}
						}
						$A5dcdeb6ecbbf6bd = array();

						foreach ($a27e64cc6ce01033['category_id'] as $A1925ae53e9307eb) {
							if (isset($Ae4bd014b3779489[$A1925ae53e9307eb])) {
								$A5dcdeb6ecbbf6bd[] = $Ae4bd014b3779489[$A1925ae53e9307eb];
							} else {
								if (!is_numeric($A1925ae53e9307eb)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = intval($A1925ae53e9307eb);
								}
							}
						}
						$d49041d5f05a9270['category_id'] = '[' . implode(',', array_map('intval', $A5dcdeb6ecbbf6bd)) . ']';
						$eaad9527ef2b563d = $d49041d5f05a9270;

						if (!self::$rSettings['download_images']) {
						} else {
							$addee113c4cee30c['stream_icon'] = XUI::B2068cE8B339bF70($addee113c4cee30c['stream_icon'], 4);
						}

						foreach (array_keys($addee113c4cee30c) as $D3fa098be3f297cd) {
							$eaad9527ef2b563d[$D3fa098be3f297cd] = $addee113c4cee30c[$D3fa098be3f297cd];
						}

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							$eaad9527ef2b563d['order'] = dc95637c2Da3B543();
						}

						$acd0eb2c8a975903 = F4817Dc607D9981D($eaad9527ef2b563d);
						$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
							$f172236cc7920e32 = array();

							if (!isset($a27e64cc6ce01033['edit'])) {
							} else {
								self::$db->query('SELECT `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

								foreach (self::$db->get_rows() as $C740da31596f24ef) {
									$f172236cc7920e32[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
								}
							}

							$bdb0e33425a1906e = array();
							$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

							foreach ($e80d13748eba016a as $e81220b4451f37c9) {
								if ($e81220b4451f37c9['parent'] == '#') {
								} else {
									$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);
									$bdb0e33425a1906e[] = $d58b4f8653a391d8;
									$a9fd4125120bdb0d = intval(in_array($d58b4f8653a391d8, ($a27e64cc6ce01033['on_demand'] ?: array())));

									if ($e81220b4451f37c9['parent'] == 'source') {
										$cceca8bbcbeb112d = null;
									} else {
										$cceca8bbcbeb112d = intval($e81220b4451f37c9['parent']);
									}

									if (isset($f172236cc7920e32[$d58b4f8653a391d8])) {
										self::$db->query('UPDATE `streams_servers` SET `parent_id` = ?, `on_demand` = ? WHERE `server_stream_id` = ?;', $cceca8bbcbeb112d, $a9fd4125120bdb0d, $f172236cc7920e32[$d58b4f8653a391d8]);
									} else {
										self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES(?, ?, ?, ?);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, $cceca8bbcbeb112d, $a9fd4125120bdb0d);
									}
								}
							}

							foreach ($f172236cc7920e32 as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									D13C1a44A4495B05($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, false, false);
								}
							}
							self::$db->query('DELETE FROM `streams_options` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

							if (!(isset($a27e64cc6ce01033['user_agent']) && 0 < strlen($a27e64cc6ce01033['user_agent']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 1, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['user_agent']);
							}

							if (!(isset($a27e64cc6ce01033['http_proxy']) && 0 < strlen($a27e64cc6ce01033['http_proxy']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 2, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['http_proxy']);
							}

							if (!(isset($a27e64cc6ce01033['cookie']) && 0 < strlen($a27e64cc6ce01033['cookie']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 17, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['cookie']);
							}

							if (!(isset($a27e64cc6ce01033['headers']) && 0 < strlen($a27e64cc6ce01033['headers']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 19, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['headers']);
							}

							if (!$d81f27c553f73ff4) {
							} else {
								E36Ec1583e223bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array($Fc2dc5a0ce8d07ea)));
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								D7e7f81F646193B2('radio', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
							}

							if (!isset($a27e64cc6ce01033['edit'])) {
							} else {
								foreach (d7a15e0c2D9bECE1() as $ddf0508b312dbfb8) {
									if (in_array($ddf0508b312dbfb8['id'], $cb498e4dcaac05cc)) {
									} else {
										d83CFf66bcdBeE05('radio', $ddf0508b312dbfb8['id'], $Fc2dc5a0ce8d07ea);
									}
								}
							}

							XUI::AfA0f3FFb001B9BE($Fc2dc5a0ce8d07ea);

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						} else {
							foreach ($f518050a6d5f89c7 as $ddf0508b312dbfb8 => $C3c8913edb801c35) {
								$Fee0d5a474c96306->query('DELETE FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);
							}

							foreach ($Ae4bd014b3779489 as $A1925ae53e9307eb => $C3c8913edb801c35) {
								$Fee0d5a474c96306->query('DELETE FROM `streams_categories` WHERE `id` = ?;', $C3c8913edb801c35);
							}

							return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
						}
					}
				} else {
					return array('status' => STATUS_NO_SOURCES, 'data' => $a27e64cc6ce01033);
				}
			} else {
				return array('status' => STATUS_NO_SOURCES, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function F109967ac71CC0dA($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::f228E3d146e758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			if (!isset($a27e64cc6ce01033['c_direct_source'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_source'])) {
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_source'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_custom_sid'])) {
			} else {
				$d49041d5f05a9270['custom_sid'] = $a27e64cc6ce01033['custom_sid'];
			}

			$Cdb85875fd50f459 = json_decode($a27e64cc6ce01033['streams'], true);

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				$a0ab7ba3516bce7d = array();

				if (!(isset($a27e64cc6ce01033['c_category_id']) && in_array($a27e64cc6ce01033['category_id_type'], array('ADD', 'DEL')))) {
				} else {
					self::$db->query('SELECT `id`, `category_id` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$a0ab7ba3516bce7d[$C740da31596f24ef['id']] = (json_decode($C740da31596f24ef['category_id'], true) ?: array());
					}
				}

				$a6629cd1b10b6170 = $F9163b7e6a33fe89 = array();
				self::$db->query('SELECT `stream_id`, `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					$F9163b7e6a33fe89[intval($C740da31596f24ef['stream_id'])][intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
				}
				$cb498e4dcaac05cc = D7A15e0c2D9bECe1();
				$ed2502d79a409dc0 = $fb5ea0f21131b307 = array();
				$F6fa7e329a8218d7 = '';

				foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
					if (!isset($a27e64cc6ce01033['c_category_id'])) {
					} else {
						$A5dcdeb6ecbbf6bd = array_map('intval', $a27e64cc6ce01033['category_id']);

						if ($a27e64cc6ce01033['category_id_type'] == 'ADD') {
							foreach (($a0ab7ba3516bce7d[$F26087d31c2bbe4d] ?: array()) as $Be965cdd996d4520) {
								if (in_array($Be965cdd996d4520, $A5dcdeb6ecbbf6bd)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = $Be965cdd996d4520;
								}
							}
						} else {
							if ($a27e64cc6ce01033['category_id_type'] != 'DEL') {
							} else {
								$C8413f429e2be20f = $a0ab7ba3516bce7d[$F26087d31c2bbe4d];

								foreach ($A5dcdeb6ecbbf6bd as $Be965cdd996d4520) {
									if (($D3fa098be3f297cd = array_search($Be965cdd996d4520, $C8413f429e2be20f)) === false) {
									} else {
										unset($C8413f429e2be20f[$D3fa098be3f297cd]);
									}
								}
								$A5dcdeb6ecbbf6bd = $C8413f429e2be20f;
							}
						}

						$d49041d5f05a9270['category_id'] = '[' . implode(',', $A5dcdeb6ecbbf6bd) . ']';
					}

					$acd0eb2c8a975903 = f4817DC607D9981d($d49041d5f05a9270);

					if (0 >= count($acd0eb2c8a975903['data'])) {
					} else {
						$acd0eb2c8a975903['data'][] = $F26087d31c2bbe4d;
						$A6d7047f2fda966c = 'UPDATE `streams` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
						self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
					}

					if (!isset($a27e64cc6ce01033['c_server_tree'])) {
					} else {
						$bdb0e33425a1906e = array();
						$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);
						$db86ce11e4fc67a2 = json_decode($a27e64cc6ce01033['od_tree_data'], true);

						foreach ($e80d13748eba016a as $e81220b4451f37c9) {
							if ($e81220b4451f37c9['parent'] == '#') {
							} else {
								$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);

								if (in_array($a27e64cc6ce01033['server_type'], array('ADD', 'SET'))) {
									$a9fd4125120bdb0d = intval(in_array($d58b4f8653a391d8, ($a27e64cc6ce01033['on_demand'] ?: array())));

									if ($e81220b4451f37c9['parent'] == 'source') {
										$cceca8bbcbeb112d = null;
									} else {
										$cceca8bbcbeb112d = intval($e81220b4451f37c9['parent']);
									}

									$bdb0e33425a1906e[] = $d58b4f8653a391d8;

									if (isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
										self::$db->query('UPDATE `streams_servers` SET `parent_id` = ?, `on_demand` = ? WHERE `server_stream_id` = ?;', $cceca8bbcbeb112d, $a9fd4125120bdb0d, $F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8]);
									} else {
										$F6fa7e329a8218d7 .= '(' . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . ', ' . (($cceca8bbcbeb112d ?: 'NULL')) . ', ' . $a9fd4125120bdb0d . '),';
									}
								} else {
									if (!isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}

						if ($a27e64cc6ce01033['server_type'] != 'SET') {
						} else {
							foreach ($F9163b7e6a33fe89[$F26087d31c2bbe4d] as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['c_bouquets'])) {
					} else {
						if ($a27e64cc6ce01033['bouquets_type'] == 'SET') {
							foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
								$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								if (in_array($ddf0508b312dbfb8['id'], $a27e64cc6ce01033['bouquets'])) {
								} else {
									$fb5ea0f21131b307[$ddf0508b312dbfb8['id']][] = $F26087d31c2bbe4d;
								}
							}
						} else {
							if ($a27e64cc6ce01033['bouquets_type'] == 'ADD') {
								foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
									$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
								}
							} else {
								if ($a27e64cc6ce01033['bouquets_type'] != 'DEL') {
								} else {
									foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
										$fb5ea0f21131b307[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}
					}

					foreach ($a6629cd1b10b6170 as $d58b4f8653a391d8 => $a811da190447e007) {
						deleteStreamsByServer($a811da190447e007, $d58b4f8653a391d8, false);
					}
				}

				foreach ($ed2502d79a409dc0 as $C52c0b6b0f74407b => $F541acfbbe8cc24e) {
					D7e7f81F646193B2('radio', $C52c0b6b0f74407b, $F541acfbbe8cc24e);
				}

				foreach ($fb5ea0f21131b307 as $C52c0b6b0f74407b => $Fc8096aca65c232b) {
					d83CFf66bcdbEe05('radio', $C52c0b6b0f74407b, $Fc8096aca65c232b);
				}

				if (empty($F6fa7e329a8218d7)) {
				} else {
					$F6fa7e329a8218d7 = rtrim($F6fa7e329a8218d7, ',');
					self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES ' . $F6fa7e329a8218d7 . ';');
				}

				XUI::updateStreams($Cdb85875fd50f459);

				if (!isset($a27e64cc6ce01033['restart_on_edit'])) {
				} else {
					E36eC1583e223Bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array_values($Cdb85875fd50f459)));
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function E8EbE0D3E389584e($a27e64cc6ce01033, $d13f08302ea360eb = false)
	{
		if (self::f228e3d146e758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AACd47D8157a1a09('adv', 'edit_reguser') || $d13f08302ea360eb) {
					$d51e425eb7375255 = Fe76C4bcaf81BAA4($a27e64cc6ce01033['edit']);
					$d49041d5f05a9270 = eBdaafc1C10f9506($d51e425eb7375255, $a27e64cc6ce01033, array('password'));
				} else {
					exit();
				}
			} else {
				if (aaCD47d8157a1A09('adv', 'add_reguser') || $d13f08302ea360eb) {
					$d49041d5f05a9270 = B9dA5d708FC1C079('users', $a27e64cc6ce01033);
					$d49041d5f05a9270['date_registered'] = time();
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (!empty($a27e64cc6ce01033['member_group_id'])) {
				if (strlen($a27e64cc6ce01033['username']) != 0) {
				} else {
					$d49041d5f05a9270['username'] = D7445B70978659ba(10);
				}

				if (!Aa5550e4A234cbe6('users', 'username', $d49041d5f05a9270['username'], 'id', $a27e64cc6ce01033['edit'])) {
					if (0 >= strlen($a27e64cc6ce01033['password'])) {
					} else {
						$d49041d5f05a9270['password'] = df65d36bEa77Ae8C($a27e64cc6ce01033['password']);
					}

					$B4a5141c87d1c427 = array();

					foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $F17f20a56056dab3) {
						if (substr($D3fa098be3f297cd, 0, 9) != 'override_') {
						} else {
							$C3c8913edb801c35 = intval(explode('override_', $D3fa098be3f297cd)[1]);

							if (0 < strlen($F17f20a56056dab3)) {
								$F17f20a56056dab3 = intval($F17f20a56056dab3);
							} else {
								$F17f20a56056dab3 = null;
							}

							if (!$F17f20a56056dab3) {
							} else {
								$B4a5141c87d1c427[$C3c8913edb801c35] = array('assign' => 1, 'official_credits' => $F17f20a56056dab3);
							}
						}
					}

					if (ctype_xdigit($d49041d5f05a9270['api_key']) && strlen($d49041d5f05a9270['api_key']) == 32) {
					} else {
						$d49041d5f05a9270['api_key'] = '';
					}

					$d49041d5f05a9270['override_packages'] = json_encode($B4a5141c87d1c427);

					if (!(isset($d51e425eb7375255) && $d51e425eb7375255['credits'] != $a27e64cc6ce01033['credits'])) {
					} else {
						$A609ba0803b21608 = $a27e64cc6ce01033['credits'] - $d51e425eb7375255['credits'];
						$bbb9e3ea56d49450 = $a27e64cc6ce01033['credits_reason'];
					}

					$acd0eb2c8a975903 = f4817dc607D9981D($d49041d5f05a9270);
					$A6d7047f2fda966c = 'REPLACE INTO `users`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

						if (!isset($A609ba0803b21608)) {
						} else {
							self::$db->query('INSERT INTO `users_credits_logs`(`target_id`, `admin_id`, `amount`, `date`, `reason`) VALUES(?, ?, ?, ?, ?);', $Fc2dc5a0ce8d07ea, self::$rUserInfo['id'], $A609ba0803b21608, time(), $bbb9e3ea56d49450);
						}

						return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				} else {
					return array('status' => STATUS_EXISTS_USERNAME, 'data' => $a27e64cc6ce01033);
				}
			} else {
				return array('status' => STATUS_INVALID_GROUP, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function A6858093B7b0EDA5($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = EBdaafc1C10f9506(ae44475ca4238899($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = b9DA5D708Fc1C079('rtmp_ips', $a27e64cc6ce01033);
				unset($d49041d5f05a9270['id']);
			}

			foreach (array('push', 'pull') as $Ba3157bbbca6db35) {
				if (isset($a27e64cc6ce01033[$Ba3157bbbca6db35])) {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 1;
				} else {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 0;
				}
			}

			if (filter_var($a27e64cc6ce01033['ip'], FILTER_VALIDATE_IP)) {
				if (!aa5550E4a234cbE6('rtmp_ips', 'ip', $a27e64cc6ce01033['ip'], 'id', $d49041d5f05a9270['id'])) {
					if (strlen($a27e64cc6ce01033['password']) != 0) {
					} else {
						$d49041d5f05a9270['password'] = D7445B70978659ba(16);
					}

					$acd0eb2c8a975903 = F4817dC607d9981D($d49041d5f05a9270);
					$A6d7047f2fda966c = 'REPLACE INTO `rtmp_ips`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

						return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_EXISTS_IP, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_IP, 'data' => $a27e64cc6ce01033);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function importSeries($a27e64cc6ce01033)
	{
		if (AaCd47d8157a1A09('adv', 'import_movies')) {
			if (self::f228e3D146e758b1($a27e64cc6ce01033)) {
				$C4033c5a05611ed1 = $a27e64cc6ce01033;

				foreach (array('read_native', 'movie_symlink', 'direct_source', 'direct_proxy', 'remove_subtitles') as $D3fa098be3f297cd) {
					if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
						$a27e64cc6ce01033[$D3fa098be3f297cd] = 1;
					} else {
						$a27e64cc6ce01033[$D3fa098be3f297cd] = 0;
					}
				}

				if (isset($a27e64cc6ce01033['restart_on_edit'])) {
					$d81f27c553f73ff4 = true;
				} else {
					$d81f27c553f73ff4 = false;
				}

				$D2165010a62b36e4 = array();
				self::$db->query('SELECT `stream_source` FROM `streams` WHERE `type` = 5;');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					foreach (json_decode($C740da31596f24ef['stream_source'], true) as $c8d91fcd2309e48a) {
						if (0 >= strlen($c8d91fcd2309e48a)) {
						} else {
							$D2165010a62b36e4[] = $c8d91fcd2309e48a;
						}
					}
				}
				$Ab3cebb99a2b671e = array();

				if (!empty($_FILES['m3u_file']['tmp_name'])) {
					$e2f848a82a80c113 = '';

					if (empty($_FILES['m3u_file']['tmp_name']) || strtolower(pathinfo(explode('?', $_FILES['m3u_file']['name'])[0], PATHINFO_EXTENSION)) != 'm3u') {
					} else {
						$e2f848a82a80c113 = file_get_contents($_FILES['m3u_file']['tmp_name']);
					}

					preg_match_all('/(?P<tag>#EXTINF:[-1,0])|(?:(?P<prop_key>[-a-z]+)=\\"(?P<prop_val>[^"]+)")|(?<name>,[^\\r\\n]+)|(?<url>http[^\\s]*:\\/\\/.*\\/.*)/', $e2f848a82a80c113, $b85ce31cd1118ad2);
					$c15d5b523e931f51 = array();
					$Fa5e35208ccf3528 = -1;

					for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($b85ce31cd1118ad2[0]); $Ea22c4a9ab5b2176++) {
						$bb2621204e39e62d = $b85ce31cd1118ad2[0][$Ea22c4a9ab5b2176];

						if (!empty($b85ce31cd1118ad2['tag'][$Ea22c4a9ab5b2176])) {
							$Fa5e35208ccf3528++;
						} else {
							if (!empty($b85ce31cd1118ad2['prop_key'][$Ea22c4a9ab5b2176])) {
								$c15d5b523e931f51[$Fa5e35208ccf3528][$b85ce31cd1118ad2['prop_key'][$Ea22c4a9ab5b2176]] = trim($b85ce31cd1118ad2['prop_val'][$Ea22c4a9ab5b2176]);
							} else {
								if (!empty($b85ce31cd1118ad2['name'][$Ea22c4a9ab5b2176])) {
									$c15d5b523e931f51[$Fa5e35208ccf3528]['name'] = trim(substr($bb2621204e39e62d, 1));
								} else {
									if (!empty($b85ce31cd1118ad2['url'][$Ea22c4a9ab5b2176])) {
										$c15d5b523e931f51[$Fa5e35208ccf3528]['url'] = str_replace(' ', '%20', trim($bb2621204e39e62d));
									}
								}
							}
						}
					}

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						if (empty($B59c127fecf35c15['url']) || in_array($B59c127fecf35c15['url'], $D2165010a62b36e4)) {
						} else {
							$d953b066e19239c1 = pathinfo(explode('?', $B59c127fecf35c15['url'])[0]);

							if (!empty($d953b066e19239c1['extension'])) {
							} else {
								$d953b066e19239c1['extension'] = ($a27e64cc6ce01033['target_container'] ?: 'mp4');
							}

							$Ab3cebb99a2b671e[] = array('url' => $B59c127fecf35c15['url'], 'title' => ($B59c127fecf35c15['name'] ?: ''), 'container' => ($a27e64cc6ce01033['movie_symlink'] || $a27e64cc6ce01033['direct_source'] ? $d953b066e19239c1['extension'] : $a27e64cc6ce01033['target_container']));
						}
					}
				} else {
					if (empty($a27e64cc6ce01033['import_folder'])) {
					} else {
						$Bab76ac20d8e4000 = explode(':', $a27e64cc6ce01033['import_folder']);

						if (!is_numeric($Bab76ac20d8e4000[1])) {
						} else {
							if (isset($a27e64cc6ce01033['scan_recursive'])) {
								$b93e6a2691d72853 = f101c1503aba095b(intval($Bab76ac20d8e4000[1]), $Bab76ac20d8e4000[2], array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts'));
							} else {
								$b93e6a2691d72853 = array();

								foreach (a2C50e6040039E78(intval($Bab76ac20d8e4000[1]), rtrim($Bab76ac20d8e4000[2], '/'), array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts'))['files'] as $e2f848a82a80c113) {
									$b93e6a2691d72853[] = rtrim($Bab76ac20d8e4000[2], '/') . '/' . $e2f848a82a80c113;
								}
							}

							foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
								$Bee11ea7f1f2f0ff = 's:' . intval($Bab76ac20d8e4000[1]) . ':' . $e2f848a82a80c113;

								if (empty($Bee11ea7f1f2f0ff) || in_array($Bee11ea7f1f2f0ff, $D2165010a62b36e4)) {
								} else {
									$d953b066e19239c1 = pathinfo($e2f848a82a80c113);

									if (!empty($d953b066e19239c1['extension'])) {
									} else {
										$d953b066e19239c1['extension'] = ($a27e64cc6ce01033['target_container'] ?: 'mp4');
									}

									$Ab3cebb99a2b671e[] = array('url' => $Bee11ea7f1f2f0ff, 'title' => $d953b066e19239c1['filename'], 'container' => ($a27e64cc6ce01033['movie_symlink'] || $a27e64cc6ce01033['direct_source'] ? $d953b066e19239c1['extension'] : $a27e64cc6ce01033['target_container']));
								}
							}
						}
					}
				}

				$f20ff2fe05992cec = array_keys(CbE87e2A9A996111('series'));

				if (0 < count($Ab3cebb99a2b671e)) {
					$cb498e4dcaac05cc = array();

					foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
						$acd0eb2c8a975903 = f4817dC607d9981d(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
						$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$cb498e4dcaac05cc[] = self::$db->last_insert_id();
						}
					}

					foreach ($a27e64cc6ce01033['bouquets'] as $C52c0b6b0f74407b) {
						if (!(is_numeric($C52c0b6b0f74407b) && in_array($C52c0b6b0f74407b, array_keys(XUI::$rBouquets)))) {
						} else {
							$cb498e4dcaac05cc[] = intval($C52c0b6b0f74407b);
						}
					}
					unset($a27e64cc6ce01033['bouquets'], $a27e64cc6ce01033['bouquet_create_list']);

					$A5dcdeb6ecbbf6bd = array();

					foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
						$acd0eb2c8a975903 = F4817DC607d9981D(array('category_type' => 'series', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
						$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$A5dcdeb6ecbbf6bd[] = self::$db->last_insert_id();
						}
					}

					foreach ($a27e64cc6ce01033['category_id'] as $Be965cdd996d4520) {
						if (!(is_numeric($Be965cdd996d4520) && in_array($Be965cdd996d4520, $f20ff2fe05992cec))) {
						} else {
							$A5dcdeb6ecbbf6bd[] = intval($Be965cdd996d4520);
						}
					}
					unset($a27e64cc6ce01033['category_id'], $a27e64cc6ce01033['category_create_list']);

					$E708d4730d21125b = array();

					foreach (json_decode($a27e64cc6ce01033['server_tree_data'], true) as $e81220b4451f37c9) {
						if ($e81220b4451f37c9['parent'] == '#') {
						} else {
							$E708d4730d21125b[] = intval($e81220b4451f37c9['id']);
						}
					}
					$d1ea20cf43346712 = array(1 => C91bF2e51c65beBc(1), 2 => c91bF2e51C65BEBC(2));

					foreach ($Ab3cebb99a2b671e as $addee113c4cee30c) {
						$a27e64cc6ce01033 = array('import' => true, 'type' => 'series', 'title' => $addee113c4cee30c['title'], 'file' => $addee113c4cee30c['url'], 'subtitles' => array(), 'servers' => $E708d4730d21125b, 'fb_category_id' => $A5dcdeb6ecbbf6bd, 'fb_bouquets' => $cb498e4dcaac05cc, 'disable_tmdb' => false, 'ignore_no_match' => false, 'bouquets' => array(), 'category_id' => array(), 'language' => XUI::$rSettings['tmdb_language'], 'watch_categories' => $d1ea20cf43346712, 'read_native' => $a27e64cc6ce01033['read_native'], 'movie_symlink' => $a27e64cc6ce01033['movie_symlink'], 'remove_subtitles' => $a27e64cc6ce01033['remove_subtitles'], 'direct_source' => $a27e64cc6ce01033['direct_source'], 'direct_proxy' => $a27e64cc6ce01033['direct_proxy'], 'auto_encode' => $d81f27c553f73ff4, 'auto_upgrade' => false, 'fallback_title' => false, 'ffprobe_input' => false, 'transcode_profile_id' => $a27e64cc6ce01033['transcode_profile_id'], 'target_container' => $addee113c4cee30c['container'], 'max_genres' => intval(XUI::$rSettings['max_genres']), 'duplicate_tmdb' => true);
						$cf1c389bda3e30fd = '/usr/bin/timeout 300 ' . PHP_BIN . ' ' . INCLUDES_PATH . 'cli/watch_item.php "' . base64_encode(json_encode($a27e64cc6ce01033, JSON_UNESCAPED_UNICODE)) . '" > /dev/null 2>/dev/null &';
						shell_exec($cf1c389bda3e30fd);
					}

					return array('status' => STATUS_SUCCESS);
				} else {
					return array('status' => STATUS_NO_SOURCES, 'data' => $C4033c5a05611ed1);
				}
			} else {
				return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
			}
		} else {
			exit();
		}
	}

	public static function importMovies($a27e64cc6ce01033)
	{
		if (aacd47D8157A1a09('adv', 'import_movies')) {
			if (self::f228E3d146E758b1($a27e64cc6ce01033)) {
				$C4033c5a05611ed1 = $a27e64cc6ce01033;

				foreach (array('read_native', 'movie_symlink', 'direct_source', 'direct_proxy', 'remove_subtitles') as $D3fa098be3f297cd) {
					if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
						$a27e64cc6ce01033[$D3fa098be3f297cd] = 1;
					} else {
						$a27e64cc6ce01033[$D3fa098be3f297cd] = 0;
					}
				}

				if (isset($a27e64cc6ce01033['restart_on_edit'])) {
					$d81f27c553f73ff4 = true;
				} else {
					$d81f27c553f73ff4 = false;
				}

				if (isset($a27e64cc6ce01033['disable_tmdb'])) {
					$b38cee190bd6759b = true;
				} else {
					$b38cee190bd6759b = false;
				}

				if (isset($a27e64cc6ce01033['ignore_no_match'])) {
					$b7d4a8c66f4dae2b = true;
				} else {
					$b7d4a8c66f4dae2b = false;
				}

				$D2165010a62b36e4 = array();
				self::$db->query('SELECT `stream_source` FROM `streams` WHERE `type` = 2;');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					foreach (json_decode($C740da31596f24ef['stream_source'], true) as $c8d91fcd2309e48a) {
						if (0 >= strlen($c8d91fcd2309e48a)) {
						} else {
							$D2165010a62b36e4[] = $c8d91fcd2309e48a;
						}
					}
				}
				$Ab3cebb99a2b671e = array();

				if (!empty($_FILES['m3u_file']['tmp_name'])) {
					$e2f848a82a80c113 = '';

					if (empty($_FILES['m3u_file']['tmp_name']) || strtolower(pathinfo(explode('?', $_FILES['m3u_file']['name'])[0], PATHINFO_EXTENSION)) != 'm3u') {
					} else {
						$e2f848a82a80c113 = file_get_contents($_FILES['m3u_file']['tmp_name']);
					}

					preg_match_all('/(?P<tag>#EXTINF:[-1,0])|(?:(?P<prop_key>[-a-z]+)=\\"(?P<prop_val>[^"]+)")|(?<name>,[^\\r\\n]+)|(?<url>http[^\\s]*:\\/\\/.*\\/.*)/', $e2f848a82a80c113, $b85ce31cd1118ad2);
					$c15d5b523e931f51 = array();
					$Fa5e35208ccf3528 = -1;

					for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($b85ce31cd1118ad2[0]); $Ea22c4a9ab5b2176++) {
						$bb2621204e39e62d = $b85ce31cd1118ad2[0][$Ea22c4a9ab5b2176];

						if (!empty($b85ce31cd1118ad2['tag'][$Ea22c4a9ab5b2176])) {
							$Fa5e35208ccf3528++;
						} else {
							if (!empty($b85ce31cd1118ad2['prop_key'][$Ea22c4a9ab5b2176])) {
								$c15d5b523e931f51[$Fa5e35208ccf3528][$b85ce31cd1118ad2['prop_key'][$Ea22c4a9ab5b2176]] = trim($b85ce31cd1118ad2['prop_val'][$Ea22c4a9ab5b2176]);
							} else {
								if (!empty($b85ce31cd1118ad2['name'][$Ea22c4a9ab5b2176])) {
									$c15d5b523e931f51[$Fa5e35208ccf3528]['name'] = trim(substr($bb2621204e39e62d, 1));
								} else {
									if (!empty($b85ce31cd1118ad2['url'][$Ea22c4a9ab5b2176])) {
										$c15d5b523e931f51[$Fa5e35208ccf3528]['url'] = str_replace(' ', '%20', trim($bb2621204e39e62d));
									}
								}
							}
						}
					}

					foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
						if (empty($B59c127fecf35c15['url']) || in_array($B59c127fecf35c15['url'], $D2165010a62b36e4)) {
						} else {
							$d953b066e19239c1 = pathinfo(explode('?', $B59c127fecf35c15['url'])[0]);

							if (!empty($d953b066e19239c1['extension'])) {
							} else {
								$d953b066e19239c1['extension'] = ($a27e64cc6ce01033['target_container'] ?: 'mp4');
							}

							$Ab3cebb99a2b671e[] = array('url' => $B59c127fecf35c15['url'], 'title' => ($B59c127fecf35c15['name'] ?: ''), 'container' => ($a27e64cc6ce01033['movie_symlink'] || $a27e64cc6ce01033['direct_source'] ? $d953b066e19239c1['extension'] : $a27e64cc6ce01033['target_container']));
						}
					}
				} else {
					if (empty($a27e64cc6ce01033['import_folder'])) {
					} else {
						$Bab76ac20d8e4000 = explode(':', $a27e64cc6ce01033['import_folder']);

						if (!is_numeric($Bab76ac20d8e4000[1])) {
						} else {
							if (isset($a27e64cc6ce01033['scan_recursive'])) {
								$b93e6a2691d72853 = f101c1503Aba095b(intval($Bab76ac20d8e4000[1]), $Bab76ac20d8e4000[2], array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts'));
							} else {
								$b93e6a2691d72853 = array();

								foreach (A2C50e6040039E78(intval($Bab76ac20d8e4000[1]), rtrim($Bab76ac20d8e4000[2], '/'), array('mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts'))['files'] as $e2f848a82a80c113) {
									$b93e6a2691d72853[] = rtrim($Bab76ac20d8e4000[2], '/') . '/' . $e2f848a82a80c113;
								}
							}

							foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
								$Bee11ea7f1f2f0ff = 's:' . intval($Bab76ac20d8e4000[1]) . ':' . $e2f848a82a80c113;

								if (empty($Bee11ea7f1f2f0ff) || in_array($Bee11ea7f1f2f0ff, $D2165010a62b36e4)) {
								} else {
									$d953b066e19239c1 = pathinfo($e2f848a82a80c113);

									if (!empty($d953b066e19239c1['extension'])) {
									} else {
										$d953b066e19239c1['extension'] = ($a27e64cc6ce01033['target_container'] ?: 'mp4');
									}

									$Ab3cebb99a2b671e[] = array('url' => $Bee11ea7f1f2f0ff, 'title' => $d953b066e19239c1['filename'], 'container' => ($a27e64cc6ce01033['movie_symlink'] || $a27e64cc6ce01033['direct_source'] ? $d953b066e19239c1['extension'] : $a27e64cc6ce01033['target_container']));
								}
							}
						}
					}
				}

				$dabeb91310ebd1c3 = array_keys(cBe87e2A9a996111('movie'));

				if (0 < count($Ab3cebb99a2b671e)) {
					$cb498e4dcaac05cc = array();

					foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
						$acd0eb2c8a975903 = f4817Dc607d9981d(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
						$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$cb498e4dcaac05cc[] = self::$db->last_insert_id();
						}
					}

					foreach ($a27e64cc6ce01033['bouquets'] as $C52c0b6b0f74407b) {
						if (!(is_numeric($C52c0b6b0f74407b) && in_array($C52c0b6b0f74407b, array_keys(XUI::$rBouquets)))) {
						} else {
							$cb498e4dcaac05cc[] = intval($C52c0b6b0f74407b);
						}
					}
					unset($a27e64cc6ce01033['bouquets'], $a27e64cc6ce01033['bouquet_create_list']);

					$A5dcdeb6ecbbf6bd = array();

					foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
						$acd0eb2c8a975903 = f4817dc607d9981D(array('category_type' => 'movie', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
						$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$A5dcdeb6ecbbf6bd[] = self::$db->last_insert_id();
						}
					}

					foreach ($a27e64cc6ce01033['category_id'] as $Be965cdd996d4520) {
						if (!(is_numeric($Be965cdd996d4520) && in_array($Be965cdd996d4520, $dabeb91310ebd1c3))) {
						} else {
							$A5dcdeb6ecbbf6bd[] = intval($Be965cdd996d4520);
						}
					}
					unset($a27e64cc6ce01033['category_id'], $a27e64cc6ce01033['category_create_list']);

					$E708d4730d21125b = array();

					foreach (json_decode($a27e64cc6ce01033['server_tree_data'], true) as $e81220b4451f37c9) {
						if ($e81220b4451f37c9['parent'] == '#') {
						} else {
							$E708d4730d21125b[] = intval($e81220b4451f37c9['id']);
						}
					}
					$d1ea20cf43346712 = array(1 => C91Bf2E51c65BebC(1), 2 => C91bf2E51c65BEBc(2));

					foreach ($Ab3cebb99a2b671e as $addee113c4cee30c) {
						$a27e64cc6ce01033 = array('import' => true, 'type' => 'movie', 'title' => $addee113c4cee30c['title'], 'file' => $addee113c4cee30c['url'], 'subtitles' => array(), 'servers' => $E708d4730d21125b, 'fb_category_id' => $A5dcdeb6ecbbf6bd, 'fb_bouquets' => $cb498e4dcaac05cc, 'disable_tmdb' => $b38cee190bd6759b, 'ignore_no_match' => $b7d4a8c66f4dae2b, 'bouquets' => array(), 'category_id' => array(), 'language' => XUI::$rSettings['tmdb_language'], 'watch_categories' => $d1ea20cf43346712, 'read_native' => $a27e64cc6ce01033['read_native'], 'movie_symlink' => $a27e64cc6ce01033['movie_symlink'], 'remove_subtitles' => $a27e64cc6ce01033['remove_subtitles'], 'direct_source' => $a27e64cc6ce01033['direct_source'], 'direct_proxy' => $a27e64cc6ce01033['direct_proxy'], 'auto_encode' => $d81f27c553f73ff4, 'auto_upgrade' => false, 'fallback_title' => false, 'ffprobe_input' => false, 'transcode_profile_id' => $a27e64cc6ce01033['transcode_profile_id'], 'target_container' => $addee113c4cee30c['container'], 'max_genres' => intval(XUI::$rSettings['max_genres']), 'duplicate_tmdb' => true);
						$cf1c389bda3e30fd = '/usr/bin/timeout 300 ' . PHP_BIN . ' ' . INCLUDES_PATH . 'cli/watch_item.php "' . base64_encode(json_encode($a27e64cc6ce01033, JSON_UNESCAPED_UNICODE)) . '" > /dev/null 2>/dev/null &';
						shell_exec($cf1c389bda3e30fd);
					}

					return array('status' => STATUS_SUCCESS);
				} else {
					return array('status' => STATUS_NO_SOURCES, 'data' => $C4033c5a05611ed1);
				}
			} else {
				return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
			}
		} else {
			exit();
		}
	}

	public static function deFd4d23B6637937($a27e64cc6ce01033)
	{
		if (self::F228e3d146E758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (aAcD47D8157a1a09('adv', 'edit_series')) {
					$d49041d5f05a9270 = ebdAAfc1C10F9506(ffD24e407AbB46Eb($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AAcD47d8157a1A09('adv', 'add_series')) {
					$d49041d5f05a9270 = B9Da5D708FC1C079('streams_series', $a27e64cc6ce01033);
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (!self::$rSettings['download_images']) {
			} else {
				$a27e64cc6ce01033['cover'] = XUI::b2068CE8b339Bf70($a27e64cc6ce01033['cover'], 2);
				$a27e64cc6ce01033['backdrop_path'] = XUI::B2068ce8B339bF70($a27e64cc6ce01033['backdrop_path']);
			}

			if (strlen($a27e64cc6ce01033['backdrop_path']) == 0) {
				$d49041d5f05a9270['backdrop_path'] = array();
			} else {
				$d49041d5f05a9270['backdrop_path'] = array($a27e64cc6ce01033['backdrop_path']);
			}

			$d49041d5f05a9270['last_modified'] = time();
			$d49041d5f05a9270['cover'] = $a27e64cc6ce01033['cover'];
			$d49041d5f05a9270['cover_big'] = $a27e64cc6ce01033['cover'];
			$f518050a6d5f89c7 = array();

			foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
				$acd0eb2c8a975903 = f4817DC607D9981D(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
				$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				} else {
					$C52c0b6b0f74407b = self::$db->last_insert_id();
					$f518050a6d5f89c7[$ddf0508b312dbfb8] = $C52c0b6b0f74407b;
				}
			}
			$Ae4bd014b3779489 = array();

			foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
				$acd0eb2c8a975903 = F4817dC607D9981d(array('category_type' => 'series', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
				$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				} else {
					$Be965cdd996d4520 = self::$db->last_insert_id();
					$Ae4bd014b3779489[$A1925ae53e9307eb] = $Be965cdd996d4520;
				}
			}
			$cb498e4dcaac05cc = array();

			foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
				if (isset($f518050a6d5f89c7[$ddf0508b312dbfb8])) {
					$cb498e4dcaac05cc[] = $f518050a6d5f89c7[$ddf0508b312dbfb8];
				} else {
					if (!is_numeric($ddf0508b312dbfb8)) {
					} else {
						$cb498e4dcaac05cc[] = intval($ddf0508b312dbfb8);
					}
				}
			}
			$A5dcdeb6ecbbf6bd = array();

			foreach ($a27e64cc6ce01033['category_id'] as $A1925ae53e9307eb) {
				if (isset($Ae4bd014b3779489[$A1925ae53e9307eb])) {
					$A5dcdeb6ecbbf6bd[] = $Ae4bd014b3779489[$A1925ae53e9307eb];
				} else {
					if (!is_numeric($A1925ae53e9307eb)) {
					} else {
						$A5dcdeb6ecbbf6bd[] = intval($A1925ae53e9307eb);
					}
				}
			}
			$d49041d5f05a9270['category_id'] = '[' . implode(',', array_map('intval', $A5dcdeb6ecbbf6bd)) . ']';
			$acd0eb2c8a975903 = f4817DC607d9981D($d49041d5f05a9270);
			$A6d7047f2fda966c = 'REPLACE INTO `streams_series`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

			if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
				fFA086a148ACf057($Fc2dc5a0ce8d07ea);

				foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
					D7e7f81f646193b2('series', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
				}

				foreach (d7a15E0C2D9Bece1() as $ddf0508b312dbfb8) {
					if (in_array($ddf0508b312dbfb8['id'], $cb498e4dcaac05cc)) {
					} else {
						d83CFF66BCDBeE05('series', $ddf0508b312dbfb8['id'], $Fc2dc5a0ce8d07ea);
					}
				}

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			} else {
				foreach ($f518050a6d5f89c7 as $ddf0508b312dbfb8 => $C3c8913edb801c35) {
					$Fee0d5a474c96306->query('DELETE FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);
				}

				foreach ($Ae4bd014b3779489 as $A1925ae53e9307eb => $C3c8913edb801c35) {
					$Fee0d5a474c96306->query('DELETE FROM `streams_categories` WHERE `id` = ?;', $C3c8913edb801c35);
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function dEFa8D6cB43b3d68($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228E3d146e758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();
			$b58b71142a808858 = json_decode($a27e64cc6ce01033['series'], true);

			if (0 >= count($b58b71142a808858)) {
			} else {
				$a0ab7ba3516bce7d = array();

				if (!(isset($a27e64cc6ce01033['c_category_id']) && in_array($a27e64cc6ce01033['category_id_type'], array('ADD', 'DEL')))) {
				} else {
					self::$db->query('SELECT `id`, `category_id` FROM `streams_series` WHERE `id` IN (' . implode(',', array_map('intval', $b58b71142a808858)) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$a0ab7ba3516bce7d[$C740da31596f24ef['id']] = (json_decode($C740da31596f24ef['category_id'], true) ?: array());
					}
				}

				$cb498e4dcaac05cc = d7A15e0c2D9bECe1();
				$ed2502d79a409dc0 = $fb5ea0f21131b307 = array();

				foreach ($b58b71142a808858 as $A2d65843292b5c59) {
					if (!isset($a27e64cc6ce01033['c_category_id'])) {
					} else {
						$A5dcdeb6ecbbf6bd = array_map('intval', $a27e64cc6ce01033['category_id']);

						if ($a27e64cc6ce01033['category_id_type'] == 'ADD') {
							foreach (($a0ab7ba3516bce7d[$A2d65843292b5c59] ?: array()) as $Be965cdd996d4520) {
								if (in_array($Be965cdd996d4520, $A5dcdeb6ecbbf6bd)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = $Be965cdd996d4520;
								}
							}
						} else {
							if ($a27e64cc6ce01033['category_id_type'] != 'DEL') {
							} else {
								$C8413f429e2be20f = $a0ab7ba3516bce7d[$A2d65843292b5c59];

								foreach ($A5dcdeb6ecbbf6bd as $Be965cdd996d4520) {
									if (($D3fa098be3f297cd = array_search($Be965cdd996d4520, $C8413f429e2be20f)) === false) {
									} else {
										unset($C8413f429e2be20f[$D3fa098be3f297cd]);
									}
								}
								$A5dcdeb6ecbbf6bd = $C8413f429e2be20f;
							}
						}

						$d49041d5f05a9270['category_id'] = '[' . implode(',', $A5dcdeb6ecbbf6bd) . ']';
					}

					$acd0eb2c8a975903 = F4817dc607D9981D($d49041d5f05a9270);

					if (0 >= count($acd0eb2c8a975903['data'])) {
					} else {
						$acd0eb2c8a975903['data'][] = $A2d65843292b5c59;
						$A6d7047f2fda966c = 'UPDATE `streams_series` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
						self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
					}

					if (!isset($a27e64cc6ce01033['c_bouquets'])) {
					} else {
						if ($a27e64cc6ce01033['bouquets_type'] == 'SET') {
							foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
								$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $A2d65843292b5c59;
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								if (in_array($ddf0508b312dbfb8['id'], $a27e64cc6ce01033['bouquets'])) {
								} else {
									$fb5ea0f21131b307[$ddf0508b312dbfb8['id']][] = $A2d65843292b5c59;
								}
							}
						} else {
							if ($a27e64cc6ce01033['bouquets_type'] == 'ADD') {
								foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
									$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $A2d65843292b5c59;
								}
							} else {
								if ($a27e64cc6ce01033['bouquets_type'] != 'DEL') {
								} else {
									foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
										$fb5ea0f21131b307[$ddf0508b312dbfb8][] = $A2d65843292b5c59;
									}
								}
							}
						}
					}
				}

				foreach ($ed2502d79a409dc0 as $C52c0b6b0f74407b => $F541acfbbe8cc24e) {
					D7E7f81F646193b2('series', $C52c0b6b0f74407b, $F541acfbbe8cc24e);
				}

				foreach ($fb5ea0f21131b307 as $C52c0b6b0f74407b => $Fc8096aca65c232b) {
					D83Cff66bcDbeE05('series', $C52c0b6b0f74407b, $Fc8096aca65c232b);
				}

				if (!isset($a27e64cc6ce01033['reprocess_tmdb'])) {
				} else {
					foreach ($b58b71142a808858 as $A2d65843292b5c59) {
						if (0 >= intval($A2d65843292b5c59)) {
						} else {
							self::$db->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES(2, ?, 0);', $A2d65843292b5c59);
						}
					}
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function f6891F9c339ac681($a27e64cc6ce01033)
	{
		if (aaCD47d8157a1a09('adv', 'edit_server')) {
			if (self::F228E3d146e758B1($a27e64cc6ce01033)) {
				$e81220b4451f37c9 = EEcb64fd7D6b8430($a27e64cc6ce01033['edit']);

				if ($e81220b4451f37c9) {
					$d49041d5f05a9270 = B9DA5D708fc1c079('servers', $a27e64cc6ce01033, true);
					$fe4e3e8ff0a114f6 = array('http' => array(), 'https' => array());

					foreach ($a27e64cc6ce01033['http_broadcast_ports'] as $b87b2986f8f49da8) {
						if (!(is_numeric($b87b2986f8f49da8) && 80 <= $b87b2986f8f49da8 && $b87b2986f8f49da8 <= 65535 && !in_array($b87b2986f8f49da8, ($fe4e3e8ff0a114f6['http'] ?: array())) && $b87b2986f8f49da8 != $a27e64cc6ce01033['rtmp_port'])) {
						} else {
							$fe4e3e8ff0a114f6['http'][] = $b87b2986f8f49da8;
						}
					}
					$fe4e3e8ff0a114f6['http'] = array_unique($fe4e3e8ff0a114f6['http']);
					unset($a27e64cc6ce01033['http_broadcast_ports']);

					foreach ($a27e64cc6ce01033['https_broadcast_ports'] as $b87b2986f8f49da8) {
						if (!(is_numeric($b87b2986f8f49da8) && 80 <= $b87b2986f8f49da8 && $b87b2986f8f49da8 <= 65535 && !in_array($b87b2986f8f49da8, ($fe4e3e8ff0a114f6['http'] ?: array())) && !in_array($b87b2986f8f49da8, ($fe4e3e8ff0a114f6['https'] ?: array())) && $b87b2986f8f49da8 != $a27e64cc6ce01033['rtmp_port'])) {
						} else {
							$fe4e3e8ff0a114f6['https'][] = $b87b2986f8f49da8;
						}
					}
					$fe4e3e8ff0a114f6['https'] = array_unique($fe4e3e8ff0a114f6['https']);
					unset($a27e64cc6ce01033['https_broadcast_ports']);
					$d49041d5f05a9270['http_broadcast_port'] = null;
					$d49041d5f05a9270['http_ports_add'] = null;

					if (0 >= count($fe4e3e8ff0a114f6['http'])) {
					} else {
						$d49041d5f05a9270['http_broadcast_port'] = $fe4e3e8ff0a114f6['http'][0];

						if (1 >= count($fe4e3e8ff0a114f6['http'])) {
						} else {
							$d49041d5f05a9270['http_ports_add'] = implode(',', array_slice($fe4e3e8ff0a114f6['http'], 1, count($fe4e3e8ff0a114f6['http']) - 1));
						}
					}

					$d49041d5f05a9270['https_broadcast_port'] = null;
					$d49041d5f05a9270['https_ports_add'] = null;

					if (0 >= count($fe4e3e8ff0a114f6['https'])) {
					} else {
						$d49041d5f05a9270['https_broadcast_port'] = $fe4e3e8ff0a114f6['https'][0];

						if (1 >= count($fe4e3e8ff0a114f6['https'])) {
						} else {
							$d49041d5f05a9270['https_ports_add'] = implode(',', array_slice($fe4e3e8ff0a114f6['https'], 1, count($fe4e3e8ff0a114f6['https']) - 1));
						}
					}

					foreach (array('enable_gzip', 'timeshift_only', 'enable_https', 'random_ip', 'enable_geoip', 'enable_isp', 'enabled', 'enable_proxy') as $D3fa098be3f297cd) {
						if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
							$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
						} else {
							$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
						}
					}

					if (!$e81220b4451f37c9['is_main']) {
					} else {
						$d49041d5f05a9270['enabled'] = 1;
					}

					if (isset($a27e64cc6ce01033['geoip_countries'])) {
						$d49041d5f05a9270['geoip_countries'] = array();

						foreach ($a27e64cc6ce01033['geoip_countries'] as $De0e117a481409e2) {
							$d49041d5f05a9270['geoip_countries'][] = $De0e117a481409e2;
						}
					} else {
						$d49041d5f05a9270['geoip_countries'] = array();
					}

					if (isset($a27e64cc6ce01033['isp_names'])) {
						$d49041d5f05a9270['isp_names'] = array();

						foreach ($a27e64cc6ce01033['isp_names'] as $Fbe730b7a1211b54) {
							$d49041d5f05a9270['isp_names'][] = strtolower(trim(preg_replace('/[^A-Za-z0-9 ]/', '', $Fbe730b7a1211b54)));
						}
					} else {
						$d49041d5f05a9270['isp_names'] = array();
					}

					if (isset($a27e64cc6ce01033['domain_name'])) {
						$d49041d5f05a9270['domain_name'] = implode(',', $a27e64cc6ce01033['domain_name']);
					} else {
						$d49041d5f05a9270['domain_name'] = '';
					}

					if (strlen($a27e64cc6ce01033['server_ip']) != 0 && filter_var($a27e64cc6ce01033['server_ip'], FILTER_VALIDATE_IP)) {
						if (0 >= strlen($a27e64cc6ce01033['private_ip']) || filter_var($a27e64cc6ce01033['private_ip'], FILTER_VALIDATE_IP)) {
							$d49041d5f05a9270['total_services'] = $a27e64cc6ce01033['total_services'];
							$F6b01d6517d94533 = $d49041d5f05a9270['php_version'];
							$d49041d5f05a9270['php_version'] = $a27e64cc6ce01033['php_version_num'];
							$acd0eb2c8a975903 = f4817dc607d9981D($d49041d5f05a9270);
							$acd0eb2c8a975903['data'][] = $a27e64cc6ce01033['edit'];
							$A6d7047f2fda966c = 'UPDATE `servers` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';

							if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
								$Fc2dc5a0ce8d07ea = $a27e64cc6ce01033['edit'];
								$fe4e3e8ff0a114f6 = array('http' => array(), 'https' => array());

								foreach (array_merge(array(intval($d49041d5f05a9270['http_broadcast_port'])), explode(',', $d49041d5f05a9270['http_ports_add'])) as $b87b2986f8f49da8) {
									if (!(is_numeric($b87b2986f8f49da8) && 0 < $b87b2986f8f49da8 && $b87b2986f8f49da8 <= 65535)) {
									} else {
										$fe4e3e8ff0a114f6['http'][] = intval($b87b2986f8f49da8);
									}
								}

								foreach (array_merge(array(intval($d49041d5f05a9270['https_broadcast_port'])), explode(',', $d49041d5f05a9270['https_ports_add'])) as $b87b2986f8f49da8) {
									if (!(is_numeric($b87b2986f8f49da8) && 0 < $b87b2986f8f49da8 && $b87b2986f8f49da8 <= 65535)) {
									} else {
										$fe4e3e8ff0a114f6['https'][] = intval($b87b2986f8f49da8);
									}
								}
								B5F175E537cdef60($Fc2dc5a0ce8d07ea, 0, $fe4e3e8ff0a114f6['http'], false);
								B5f175e537CdeF60($Fc2dc5a0ce8d07ea, 1, $fe4e3e8ff0a114f6['https'], false);
								b5F175e537Cdef60($Fc2dc5a0ce8d07ea, 2, array($d49041d5f05a9270['rtmp_port']), false);
								f455c4fa1194F818($Fc2dc5a0ce8d07ea, intval($d49041d5f05a9270['total_services']), true);

								if (empty($d49041d5f05a9270['governor'])) {
								} else {
									setGovernor($Fc2dc5a0ce8d07ea, $d49041d5f05a9270['governor']);
								}

								if (empty($d49041d5f05a9270['sysctl'])) {
								} else {
									setSysctl($Fc2dc5a0ce8d07ea, $d49041d5f05a9270['sysctl']);
								}

								if (!file_exists(CACHE_TMP_PATH . 'servers')) {
								} else {
									unlink(CACHE_TMP_PATH . 'servers');
								}

								$Ed937f6c4a4c540b = B4167cfCa7fE90f8($Fc2dc5a0ce8d07ea);
								$Ade42e4d9f18eba7 = false;

								foreach ($Ed937f6c4a4c540b as $Fc1271795b9f5cfc) {
									if ($Fc1271795b9f5cfc['mount'] != rtrim(STREAMS_PATH, '/')) {
									} else {
										$Ade42e4d9f18eba7 = true;

										break;
									}
								}

								if ($a27e64cc6ce01033['disable_ramdisk'] && $Ade42e4d9f18eba7) {
									self::$db->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $Fc2dc5a0ce8d07ea, time(), json_encode(array('action' => 'disable_ramdisk')));
								} else {
									if ($a27e64cc6ce01033['disable_ramdisk'] || $Ade42e4d9f18eba7) {
									} else {
										self::$db->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $Fc2dc5a0ce8d07ea, time(), json_encode(array('action' => 'enable_ramdisk')));
									}
								}

								if ($e81220b4451f37c9['php_version'] == $a27e64cc6ce01033['php_version_num']) {
								} else {
									self::$db->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $Fc2dc5a0ce8d07ea, time(), json_encode(array('action' => 'switch_php' . intval($a27e64cc6ce01033['php_version_num']))));
								}

								return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
							} else {
								return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
							}
						} else {
							return array('status' => STATUS_INVALID_IP, 'data' => $a27e64cc6ce01033);
						}
					} else {
						return array('status' => STATUS_INVALID_IP, 'data' => $a27e64cc6ce01033);
					}
				} else {
					return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
				}
			} else {
				return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
			}
		} else {
			exit();
		}
	}

	public static function fa3e5A3ea20dA904($a27e64cc6ce01033)
	{
		if (self::F228e3d146e758b1($a27e64cc6ce01033)) {
			if (AaCd47D8157a1a09('adv', 'edit_server')) {
				$d49041d5f05a9270 = EbDAaFc1c10F9506(eecB64fD7d6b8430($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);

				foreach (array('enable_https', 'random_ip', 'enable_geoip', 'enabled') as $D3fa098be3f297cd) {
					if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
						$d49041d5f05a9270[$D3fa098be3f297cd] = true;
					} else {
						$d49041d5f05a9270[$D3fa098be3f297cd] = false;
					}
				}

				if (isset($a27e64cc6ce01033['geoip_countries'])) {
					$d49041d5f05a9270['geoip_countries'] = array();

					foreach ($a27e64cc6ce01033['geoip_countries'] as $De0e117a481409e2) {
						$d49041d5f05a9270['geoip_countries'][] = $De0e117a481409e2;
					}
				} else {
					$d49041d5f05a9270['geoip_countries'] = array();
				}

				if (isset($a27e64cc6ce01033['domain_name'])) {
					$d49041d5f05a9270['domain_name'] = implode(',', $a27e64cc6ce01033['domain_name']);
				} else {
					$d49041d5f05a9270['domain_name'] = '';
				}

				if (strlen($a27e64cc6ce01033['server_ip']) != 0 && filter_var($a27e64cc6ce01033['server_ip'], FILTER_VALIDATE_IP)) {
					if (!AA5550E4A234cBE6('servers', 'server_ip', $a27e64cc6ce01033['server_ip'], 'id', $d49041d5f05a9270['id'])) {
						$d49041d5f05a9270['server_type'] = 1;
						$acd0eb2c8a975903 = F4817dc607d9981D($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `servers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

							if (!file_exists(CACHE_TMP_PATH . 'servers')) {
							} else {
								unlink(CACHE_TMP_PATH . 'servers');
							}

							if (!file_exists(CACHE_TMP_PATH . 'proxy_servers')) {
							} else {
								unlink(CACHE_TMP_PATH . 'proxy_servers');
							}

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
					}

					return array('status' => STATUS_EXISTS_IP, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_INVALID_IP, 'data' => $a27e64cc6ce01033);
			} else {
				exit();
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function BAAb8972232156Ee($a27e64cc6ce01033)
	{
		if (self::f228e3D146e758b1($a27e64cc6ce01033)) {
			if (aAcD47D8157a1A09('adv', 'add_server')) {
				if (isset($a27e64cc6ce01033['update_sysctl'])) {
					$e22648017bfc9b61 = 1;
				} else {
					$e22648017bfc9b61 = 0;
				}

				if (isset($a27e64cc6ce01033['use_private_ip'])) {
					$D4959f87d20e3759 = 1;
				} else {
					$D4959f87d20e3759 = 0;
				}

				if ($a27e64cc6ce01033['type'] != 1) {
				} else {
					$f96fcd481c5c5bb2 = array();

					foreach (json_decode($a27e64cc6ce01033['parent_id'], true) as $d58b4f8653a391d8) {
						if (self::$rServers[$d58b4f8653a391d8]['server_type'] != 0) {
						} else {
							$f96fcd481c5c5bb2[] = intval($d58b4f8653a391d8);
						}
					}
				}

				if (isset($a27e64cc6ce01033['edit'])) {
					if (!isset($a27e64cc6ce01033['update_only'])) {
					} else {
						$a27e64cc6ce01033['type'] = 3;
					}

					if ($a27e64cc6ce01033['type'] == 1) {
						$e81220b4451f37c9 = self::$rProxyServers[$a27e64cc6ce01033['edit']];
					} else {
						$e81220b4451f37c9 = self::$rServers[$a27e64cc6ce01033['edit']];
					}

					if (!$e81220b4451f37c9) {
						return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
					}

					self::$db->query('UPDATE `servers` SET `status` = 3, `parent_id` = ? WHERE `id` = ?;', '[' . implode(',', $f96fcd481c5c5bb2) . ']', $e81220b4451f37c9['id']);

					if ($a27e64cc6ce01033['type'] == 1) {
						$cf1c389bda3e30fd = PHP_BIN . ' ' . CLI_PATH . 'balancer.php ' . intval($a27e64cc6ce01033['type']) . ' ' . intval($e81220b4451f37c9['id']) . ' ' . intval($a27e64cc6ce01033['ssh_port']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_username']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_password']) . ' ' . intval($a27e64cc6ce01033['http_broadcast_port']) . ' ' . intval($a27e64cc6ce01033['https_broadcast_port']) . ' ' . intval($e22648017bfc9b61) . ' ' . intval($D4959f87d20e3759) . ' "' . json_encode($f96fcd481c5c5bb2) . '" > "' . BIN_PATH . 'install/' . intval($e81220b4451f37c9['id']) . '.install" 2>/dev/null &';
					} else {
						$cf1c389bda3e30fd = PHP_BIN . ' ' . CLI_PATH . 'balancer.php ' . intval($a27e64cc6ce01033['type']) . ' ' . intval($e81220b4451f37c9['id']) . ' ' . intval($a27e64cc6ce01033['ssh_port']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_username']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_password']) . ' 80 443 ' . intval($e22648017bfc9b61) . ' > "' . BIN_PATH . 'install/' . intval($e81220b4451f37c9['id']) . '.install" 2>/dev/null &';
					}

					shell_exec($cf1c389bda3e30fd);

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $e81220b4451f37c9['id']));
				}

				$d49041d5f05a9270 = B9da5D708FC1C079('servers', $a27e64cc6ce01033);
				$d49041d5f05a9270['status'] = 3;
				unset($d49041d5f05a9270['id']);

				if (strlen($d49041d5f05a9270['server_ip']) != 0 && filter_var($d49041d5f05a9270['server_ip'], FILTER_VALIDATE_IP)) {
					if ($a27e64cc6ce01033['type'] == 1) {
						$d49041d5f05a9270['server_type'] = 1;
						$d49041d5f05a9270['parent_id'] = '[' . implode(',', $f96fcd481c5c5bb2) . ']';
					} else {
						$d49041d5f05a9270['server_type'] = 0;
					}

					$d49041d5f05a9270['network_interface'] = 'auto';
					$acd0eb2c8a975903 = f4817Dc607d9981D($d49041d5f05a9270);
					$A6d7047f2fda966c = 'INSERT INTO `servers`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

						if ($d49041d5f05a9270['server_type'] != 0) {
						} else {
							Xui\Functions::grantPrivileges('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', $d49041d5f05a9270['server_ip']);
						}

						if ($a27e64cc6ce01033['type'] == 1) {
							$cf1c389bda3e30fd = PHP_BIN . ' ' . CLI_PATH . 'balancer.php ' . intval($a27e64cc6ce01033['type']) . ' ' . intval($Fc2dc5a0ce8d07ea) . ' ' . intval($a27e64cc6ce01033['ssh_port']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_username']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_password']) . ' ' . intval($a27e64cc6ce01033['http_broadcast_port']) . ' ' . intval($a27e64cc6ce01033['https_broadcast_port']) . ' ' . intval($e22648017bfc9b61) . ' ' . intval($D4959f87d20e3759) . ' "' . json_encode($f96fcd481c5c5bb2) . '" > "' . BIN_PATH . 'install/' . intval($Fc2dc5a0ce8d07ea) . '.install" 2>/dev/null &';
						} else {
							$cf1c389bda3e30fd = PHP_BIN . ' ' . CLI_PATH . 'balancer.php ' . intval($a27e64cc6ce01033['type']) . ' ' . intval($Fc2dc5a0ce8d07ea) . ' ' . intval($a27e64cc6ce01033['ssh_port']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_username']) . ' ' . escapeshellarg($a27e64cc6ce01033['root_password']) . ' 80 443 ' . intval($e22648017bfc9b61) . ' > "' . BIN_PATH . 'install/' . intval($Fc2dc5a0ce8d07ea) . '.install" 2>/dev/null &';
						}

						shell_exec($cf1c389bda3e30fd);

						return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_INVALID_IP, 'data' => $a27e64cc6ce01033);
			}

			exit();
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function AfF4e84A1B89b55f($a27e64cc6ce01033)
	{
		if (self::f228E3d146e758b1($a27e64cc6ce01033)) {
			foreach (array('user_agent', 'http_proxy', 'cookie', 'headers') as $D3fa098be3f297cd) {
				self::$db->query('UPDATE `streams_arguments` SET `argument_default_value` = ? WHERE `argument_key` = ?;', ($a27e64cc6ce01033[$D3fa098be3f297cd] ?: null), $D3fa098be3f297cd);
				unset($a27e64cc6ce01033[$D3fa098be3f297cd]);
			}
			$d49041d5f05a9270 = B9da5d708fc1C079('settings', $a27e64cc6ce01033, true);

			foreach (array('php_loopback', 'restreamer_bypass_proxy', 'request_prebuffer', 'modal_edit', 'group_buttons', 'enable_search', 'on_demand_checker', 'ondemand_balance_equal', 'disable_mag_token', 'allow_cdn_access', 'dts_legacy_ffmpeg', 'mag_load_all_channels', 'disable_xmltv_restreamer', 'disable_playlist_restreamer', 'ffmpeg_warnings', 'auto_send_logs', 'reseller_ssl_domain', 'extract_subtitles', 'show_category_duplicates', 'vod_sort_newest', 'header_stats', 'mag_keep_extension', 'keep_protocol', 'read_native_hls', 'player_allow_playlist', 'player_allow_bouquet', 'player_hide_incompatible', 'player_allow_hevc', 'force_epg_timezone', 'check_vod', 'ignore_keyframes', 'save_login_logs', 'save_restart_logs', 'mag_legacy_redirect', 'restrict_playlists', 'monitor_connection_status', 'kill_rogue_ffmpeg', 'show_images', 'on_demand_instant_off', 'on_demand_failure_exit', 'playlist_from_mysql', 'ignore_invalid_users', 'legacy_mag_auth', 'ministra_allow_blank', 'block_proxies', 'block_streaming_servers', 'ip_subnet_match', 'debug_show_errors', 'restart_php_fpm', 'restream_deny_unauthorised', 'api_probe', 'legacy_panel_api', 'hide_failures', 'verify_host', 'encrypt_playlist', 'encrypt_playlist_restreamer', 'mag_disable_ssl', 'legacy_get', 'legacy_xmltv', 'save_closed_connection', 'show_tickets', 'stream_logs_save', 'client_logs_save', 'streams_grouped', 'cloudflare', 'cleanup', 'dashboard_stats', 'dashboard_status', 'dashboard_map', 'dashboard_display_alt', 'enable_epg_api', 'recaptcha_enable', 'ip_logout', 'disable_player_api', 'disable_playlist', 'disable_xmltv', 'disable_enigma2', 'disable_ministra', 'enable_isp_lock', 'block_svp', 'disable_ts', 'disable_ts_allow_restream', 'disable_hls', 'disable_hls_allow_restream', 'disable_rtmp', 'disable_rtmp_allow_restream', 'case_sensitive_line', 'county_override_1st', 'disallow_2nd_ip_con', 'use_mdomain_in_lists', 'encrypt_hls', 'disallow_empty_user_agents', 'detect_restream_block_user', 'download_images', 'api_redirect', 'use_buffer', 'audio_restart_loss', 'show_isps', 'priority_backup', 'rtmp_random', 'show_connected_video', 'show_not_on_air_video', 'show_banned_video', 'show_expired_video', 'show_expiring_video', 'show_all_category_mag', 'always_enabled_subtitles', 'enable_connection_problem_indication', 'show_tv_channel_logo', 'show_channel_logo_in_preview', 'disable_trial', 'restrict_same_ip', 'js_navigate') as $b590fb979d3dfabf) {
				if (isset($a27e64cc6ce01033[$b590fb979d3dfabf])) {
					$d49041d5f05a9270[$b590fb979d3dfabf] = 1;
				} else {
					$d49041d5f05a9270[$b590fb979d3dfabf] = 0;
				}
			}

			if (isset($a27e64cc6ce01033['allowed_stb_types_for_local_recording'])) {
			} else {
				$d49041d5f05a9270['allowed_stb_types_for_local_recording'] = array();
			}

			if (isset($a27e64cc6ce01033['allowed_stb_types'])) {
			} else {
				$d49041d5f05a9270['allowed_stb_types'] = array();
			}

			if (isset($a27e64cc6ce01033['allow_countries'])) {
			} else {
				$d49041d5f05a9270['allow_countries'] = array('ALL');
			}

			if ($d49041d5f05a9270['mag_legacy_redirect']) {
				if (file_exists(XUI_HOME . 'www/c/')) {
				} else {
					self::$db->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', SERVER_ID, time(), json_encode(array('action' => 'enable_ministra')));
				}
			} else {
				if (!file_exists(XUI_HOME . 'www/c/')) {
				} else {
					self::$db->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', SERVER_ID, time(), json_encode(array('action' => 'disable_ministra')));
				}
			}

			if (100 >= $d49041d5f05a9270['search_items']) {
			} else {
				$d49041d5f05a9270['search_items'] = 100;
			}

			if ($d49041d5f05a9270['search_items'] > 0) {
			} else {
				$d49041d5f05a9270['search_items'] = 1;
			}

			$acd0eb2c8a975903 = F4817DC607D9981d($d49041d5f05a9270);

			if (0 >= count($acd0eb2c8a975903['data'])) {
			} else {
				$A6d7047f2fda966c = 'UPDATE `settings` SET ' . $acd0eb2c8a975903['update'] . ';';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					Df627deA2E5cd3Cb();

					return array('status' => STATUS_SUCCESS);
				}

				return array('status' => STATUS_FAILURE);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function B345ae7d1a648eDA($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = b9dA5D708Fc1c079('settings', $a27e64cc6ce01033, true);

			foreach (array('dropbox_remote') as $b590fb979d3dfabf) {
				if (isset($a27e64cc6ce01033[$b590fb979d3dfabf])) {
					$d49041d5f05a9270[$b590fb979d3dfabf] = 1;
				} else {
					$d49041d5f05a9270[$b590fb979d3dfabf] = 0;
				}
			}

			if (isset($a27e64cc6ce01033['allowed_stb_types_for_local_recording'])) {
			} else {
				$d49041d5f05a9270['allowed_stb_types_for_local_recording'] = array();
			}

			if (isset($a27e64cc6ce01033['allowed_stb_types'])) {
			} else {
				$d49041d5f05a9270['allowed_stb_types'] = array();
			}

			$acd0eb2c8a975903 = f4817dC607d9981d($d49041d5f05a9270);

			if (0 >= count($acd0eb2c8a975903['data'])) {
			} else {
				$A6d7047f2fda966c = 'UPDATE `settings` SET ' . $acd0eb2c8a975903['update'] . ';';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					df627DeA2E5CD3cb();

					return array('status' => STATUS_SUCCESS);
				}

				return array('status' => STATUS_FAILURE);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function editCacheCron($a27e64cc6ce01033)
	{
		if (self::F228e3D146e758b1($a27e64cc6ce01033)) {
			$f94c7a6e1c38c47c = array(false, false);
			$E356c4b0aacf7a68 = array('*', '*', '*', '*', '*');
			$B213d02f48d88809 = '/^[0-9\\/*,-]+$/';
			$E356c4b0aacf7a68[0] = $a27e64cc6ce01033['minute'];
			preg_match($B213d02f48d88809, $E356c4b0aacf7a68[0], $b85ce31cd1118ad2);
			$f94c7a6e1c38c47c[0] = 0 < count($b85ce31cd1118ad2);
			$E356c4b0aacf7a68[1] = $a27e64cc6ce01033['hour'];
			preg_match($B213d02f48d88809, $E356c4b0aacf7a68[1], $b85ce31cd1118ad2);
			$f94c7a6e1c38c47c[1] = 0 < count($b85ce31cd1118ad2);
			$A3af7cd87833ee91 = implode(' ', $E356c4b0aacf7a68);

			if (isset($a27e64cc6ce01033['cache_changes'])) {
				$F7dcc87f6e5dff85 = true;
			} else {
				$F7dcc87f6e5dff85 = false;
			}

			if ($f94c7a6e1c38c47c[0] && $f94c7a6e1c38c47c[1]) {
				self::$db->query("UPDATE `crontab` SET `time` = ? WHERE `filename` = 'cache_engine.php';", $A3af7cd87833ee91);
				self::$db->query('UPDATE `settings` SET `cache_thread_count` = ?, `cache_changes` = ?;', $a27e64cc6ce01033['cache_thread_count'], $F7dcc87f6e5dff85);

				if (!file_exists(TMP_PATH . 'crontab')) {
				} else {
					unlink(TMP_PATH . 'crontab');
				}

				df627dea2e5cD3cb();

				return array('status' => STATUS_SUCCESS);
			}

			return array('status' => STATUS_FAILURE);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function editPlexSettings($a27e64cc6ce01033)
	{
		if (self::f228e3D146E758b1($a27e64cc6ce01033)) {
			foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
				$B211d7401e6242f3 = explode('_', $D3fa098be3f297cd);

				if ($B211d7401e6242f3[0] != 'genre') {
				} else {
					if (isset($a27e64cc6ce01033['bouquet_' . $B211d7401e6242f3[1]])) {
						$cb498e4dcaac05cc = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['bouquet_' . $B211d7401e6242f3[1]])) . ']';
					} else {
						$cb498e4dcaac05cc = '[]';
					}

					self::$db->query('UPDATE `watch_categories` SET `category_id` = ?, `bouquets` = ? WHERE `genre_id` = ? AND `type` = 3;', $b6842cb20051e925, $cb498e4dcaac05cc, $B211d7401e6242f3[1]);
				}
			}

			foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
				$B211d7401e6242f3 = explode('_', $D3fa098be3f297cd);

				if ($B211d7401e6242f3[0] != 'genretv') {
				} else {
					if (isset($a27e64cc6ce01033['bouquettv_' . $B211d7401e6242f3[1]])) {
						$cb498e4dcaac05cc = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['bouquettv_' . $B211d7401e6242f3[1]])) . ']';
					} else {
						$cb498e4dcaac05cc = '[]';
					}

					self::$db->query('UPDATE `watch_categories` SET `category_id` = ?, `bouquets` = ? WHERE `genre_id` = ? AND `type` = 4;', $b6842cb20051e925, $cb498e4dcaac05cc, $B211d7401e6242f3[1]);
				}
			}
			self::$db->query('UPDATE `settings` SET `scan_seconds` = ?, `max_genres` = ?, `thread_count_movie` = ?, `thread_count_show` = ?;', $a27e64cc6ce01033['scan_seconds'], $a27e64cc6ce01033['max_genres'], $a27e64cc6ce01033['thread_count_movie'], $a27e64cc6ce01033['thread_count_show']);
			df627dEa2e5Cd3cB();

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function A5Ed159E8bfd9e84($a27e64cc6ce01033)
	{
		if (self::F228e3D146E758b1($a27e64cc6ce01033)) {
			foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
				$B211d7401e6242f3 = explode('_', $D3fa098be3f297cd);

				if ($B211d7401e6242f3[0] != 'genre') {
				} else {
					if (isset($a27e64cc6ce01033['bouquet_' . $B211d7401e6242f3[1]])) {
						$cb498e4dcaac05cc = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['bouquet_' . $B211d7401e6242f3[1]])) . ']';
					} else {
						$cb498e4dcaac05cc = '[]';
					}

					self::$db->query('UPDATE `watch_categories` SET `category_id` = ?, `bouquets` = ? WHERE `genre_id` = ? AND `type` = 1;', $b6842cb20051e925, $cb498e4dcaac05cc, $B211d7401e6242f3[1]);
				}
			}

			foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
				$B211d7401e6242f3 = explode('_', $D3fa098be3f297cd);

				if ($B211d7401e6242f3[0] != 'genretv') {
				} else {
					if (isset($a27e64cc6ce01033['bouquettv_' . $B211d7401e6242f3[1]])) {
						$cb498e4dcaac05cc = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['bouquettv_' . $B211d7401e6242f3[1]])) . ']';
					} else {
						$cb498e4dcaac05cc = '[]';
					}

					self::$db->query('UPDATE `watch_categories` SET `category_id` = ?, `bouquets` = ? WHERE `genre_id` = ? AND `type` = 2;', $b6842cb20051e925, $cb498e4dcaac05cc, $B211d7401e6242f3[1]);
				}
			}

			if (isset($a27e64cc6ce01033['alternative_titles'])) {
				$eadf06508e46d395 = true;
			} else {
				$eadf06508e46d395 = false;
			}

			if (isset($a27e64cc6ce01033['fallback_parser'])) {
				$Fc7eb810a84440f2 = true;
			} else {
				$Fc7eb810a84440f2 = false;
			}

			self::$db->query('UPDATE `settings` SET `percentage_match` = ?, `scan_seconds` = ?, `thread_count` = ?, `max_genres` = ?, `max_items` = ?, `alternative_titles` = ?, `fallback_parser` = ?;', $a27e64cc6ce01033['percentage_match'], $a27e64cc6ce01033['scan_seconds'], $a27e64cc6ce01033['thread_count'], $a27e64cc6ce01033['max_genres'], $a27e64cc6ce01033['max_items'], $eadf06508e46d395, $Fc7eb810a84440f2);
			DF627dea2E5CD3cb();

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function e10Da8800b7e2241($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228E3D146E758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			if (!isset($a27e64cc6ce01033['c_days_to_restart'])) {
			} else {
				if (isset($a27e64cc6ce01033['days_to_restart']) && preg_match('/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/', $a27e64cc6ce01033['time_to_restart'])) {
					$b7832adc388cb5a7 = array('days' => array(), 'at' => $a27e64cc6ce01033['time_to_restart']);

					foreach ($a27e64cc6ce01033['days_to_restart'] as $C3c8913edb801c35 => $d20afc15ac839efc) {
						$b7832adc388cb5a7['days'][] = $d20afc15ac839efc;
					}
					$d49041d5f05a9270['auto_restart'] = json_encode($b7832adc388cb5a7);
				} else {
					$d49041d5f05a9270['auto_restart'] = '';
				}
			}

			foreach (array('gen_timestamps', 'allow_record', 'rtmp_output', 'fps_restart', 'stream_all', 'read_native') as $D3fa098be3f297cd) {
				if (!isset($a27e64cc6ce01033['c_' . $D3fa098be3f297cd])) {
				} else {
					if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
						$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
					} else {
						$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_direct_source'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_source'])) {
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_source'] = 0;
					$d49041d5f05a9270['direct_proxy'] = 0;
				}
			}

			if (!isset($a27e64cc6ce01033['c_direct_proxy'])) {
			} else {
				if (isset($a27e64cc6ce01033['direct_proxy'])) {
					$d49041d5f05a9270['direct_proxy'] = 1;
					$d49041d5f05a9270['direct_source'] = 1;
				} else {
					$d49041d5f05a9270['direct_proxy'] = 0;
				}
			}

			foreach (array('tv_archive_server_id', 'vframes_server_id', 'tv_archive_duration', 'delay_minutes', 'probesize_ondemand', 'fps_threshold', 'llod') as $D3fa098be3f297cd) {
				if (!isset($a27e64cc6ce01033['c_' . $D3fa098be3f297cd])) {
				} else {
					$d49041d5f05a9270[$D3fa098be3f297cd] = intval($a27e64cc6ce01033[$D3fa098be3f297cd]);
				}
			}

			if (!isset($a27e64cc6ce01033['c_custom_sid'])) {
			} else {
				$d49041d5f05a9270['custom_sid'] = $a27e64cc6ce01033['custom_sid'];
			}

			if (!isset($a27e64cc6ce01033['c_transcode_profile_id'])) {
			} else {
				$d49041d5f05a9270['transcode_profile_id'] = $a27e64cc6ce01033['transcode_profile_id'];

				if (0 < $d49041d5f05a9270['transcode_profile_id']) {
					$d49041d5f05a9270['enable_transcode'] = 1;
				} else {
					$d49041d5f05a9270['enable_transcode'] = 0;
				}
			}

			$Cdb85875fd50f459 = json_decode($a27e64cc6ce01033['streams'], true);

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				$a0ab7ba3516bce7d = array();

				if (!(isset($a27e64cc6ce01033['c_category_id']) && in_array($a27e64cc6ce01033['category_id_type'], array('ADD', 'DEL')))) {
				} else {
					self::$db->query('SELECT `id`, `category_id` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$a0ab7ba3516bce7d[$C740da31596f24ef['id']] = (json_decode($C740da31596f24ef['category_id'], true) ?: array());
					}
				}

				$a6629cd1b10b6170 = $F9163b7e6a33fe89 = array();
				self::$db->query('SELECT `stream_id`, `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					$F9163b7e6a33fe89[intval($C740da31596f24ef['stream_id'])][intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
				}
				$cb498e4dcaac05cc = D7A15e0c2D9bECE1();
				$E1f2e5d16be8efdf = $ed2502d79a409dc0 = $fb5ea0f21131b307 = array();
				$cec8d7b2f57ce2cb = $F6fa7e329a8218d7 = '';

				foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
					if (!isset($a27e64cc6ce01033['c_category_id'])) {
					} else {
						$A5dcdeb6ecbbf6bd = array_map('intval', $a27e64cc6ce01033['category_id']);

						if ($a27e64cc6ce01033['category_id_type'] == 'ADD') {
							foreach (($a0ab7ba3516bce7d[$F26087d31c2bbe4d] ?: array()) as $Be965cdd996d4520) {
								if (in_array($Be965cdd996d4520, $A5dcdeb6ecbbf6bd)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = $Be965cdd996d4520;
								}
							}
						} else {
							if ($a27e64cc6ce01033['category_id_type'] != 'DEL') {
							} else {
								$C8413f429e2be20f = $a0ab7ba3516bce7d[$F26087d31c2bbe4d];

								foreach ($A5dcdeb6ecbbf6bd as $Be965cdd996d4520) {
									if (($D3fa098be3f297cd = array_search($Be965cdd996d4520, $C8413f429e2be20f)) === false) {
									} else {
										unset($C8413f429e2be20f[$D3fa098be3f297cd]);
									}
								}
								$A5dcdeb6ecbbf6bd = $C8413f429e2be20f;
							}
						}

						$d49041d5f05a9270['category_id'] = '[' . implode(',', $A5dcdeb6ecbbf6bd) . ']';
					}

					$acd0eb2c8a975903 = F4817DC607D9981D($d49041d5f05a9270);

					if (0 >= count($acd0eb2c8a975903['data'])) {
					} else {
						$acd0eb2c8a975903['data'][] = $F26087d31c2bbe4d;
						$A6d7047f2fda966c = 'UPDATE `streams` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
						self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
					}

					if (!isset($a27e64cc6ce01033['c_server_tree'])) {
					} else {
						$bdb0e33425a1906e = array();
						$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

						foreach ($e80d13748eba016a as $e81220b4451f37c9) {
							if ($e81220b4451f37c9['parent'] == '#') {
							} else {
								$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);

								if (in_array($a27e64cc6ce01033['server_type'], array('ADD', 'SET'))) {
									$a9fd4125120bdb0d = intval(in_array($d58b4f8653a391d8, ($a27e64cc6ce01033['on_demand'] ?: array())));

									if ($e81220b4451f37c9['parent'] == 'source') {
										$cceca8bbcbeb112d = null;
									} else {
										$cceca8bbcbeb112d = intval($e81220b4451f37c9['parent']);
									}

									$bdb0e33425a1906e[] = $d58b4f8653a391d8;

									if (isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
										self::$db->query('UPDATE `streams_servers` SET `parent_id` = ?, `on_demand` = ? WHERE `server_stream_id` = ?;', $cceca8bbcbeb112d, $a9fd4125120bdb0d, $F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8]);
									} else {
										$F6fa7e329a8218d7 .= '(' . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . ', ' . (($cceca8bbcbeb112d ?: 'NULL')) . ', ' . $a9fd4125120bdb0d . '),';
									}
								} else {
									if (!isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}

						if ($a27e64cc6ce01033['server_type'] != 'SET') {
						} else {
							foreach ($F9163b7e6a33fe89[$F26087d31c2bbe4d] as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['c_user_agent'])) {
					} else {
						if (!(isset($a27e64cc6ce01033['user_agent']) && 0 < strlen($a27e64cc6ce01033['user_agent']))) {
						} else {
							$E1f2e5d16be8efdf[1][] = $F26087d31c2bbe4d;
							$cec8d7b2f57ce2cb .= '(' . intval($F26087d31c2bbe4d) . ', 1, ' . self::$db->escape($a27e64cc6ce01033['user_agent']) . '),';
						}
					}

					if (!isset($a27e64cc6ce01033['c_http_proxy'])) {
					} else {
						if (!(isset($a27e64cc6ce01033['http_proxy']) && 0 < strlen($a27e64cc6ce01033['http_proxy']))) {
						} else {
							$E1f2e5d16be8efdf[2][] = $F26087d31c2bbe4d;
							$cec8d7b2f57ce2cb .= '(' . intval($F26087d31c2bbe4d) . ', 2, ' . self::$db->escape($a27e64cc6ce01033['http_proxy']) . '),';
						}
					}

					if (!isset($a27e64cc6ce01033['c_cookie'])) {
					} else {
						if (!(isset($a27e64cc6ce01033['cookie']) && 0 < strlen($a27e64cc6ce01033['cookie']))) {
						} else {
							$E1f2e5d16be8efdf[17][] = $F26087d31c2bbe4d;
							$cec8d7b2f57ce2cb .= '(' . intval($F26087d31c2bbe4d) . ', 17, ' . self::$db->escape($a27e64cc6ce01033['cookie']) . '),';
						}
					}

					if (!isset($a27e64cc6ce01033['c_headers'])) {
					} else {
						if (!(isset($a27e64cc6ce01033['headers']) && 0 < strlen($a27e64cc6ce01033['headers']))) {
						} else {
							$E1f2e5d16be8efdf[19][] = $F26087d31c2bbe4d;
							$cec8d7b2f57ce2cb .= '(' . intval($F26087d31c2bbe4d) . ', 19, ' . self::$db->escape($a27e64cc6ce01033['headers']) . '),';
						}
					}

					if (!isset($a27e64cc6ce01033['c_bouquets'])) {
					} else {
						if ($a27e64cc6ce01033['bouquets_type'] == 'SET') {
							foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
								$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								if (in_array($ddf0508b312dbfb8['id'], $a27e64cc6ce01033['bouquets'])) {
								} else {
									$fb5ea0f21131b307[$ddf0508b312dbfb8['id']][] = $F26087d31c2bbe4d;
								}
							}
						} else {
							if ($a27e64cc6ce01033['bouquets_type'] == 'ADD') {
								foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
									$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
								}
							} else {
								if ($a27e64cc6ce01033['bouquets_type'] != 'DEL') {
								} else {
									foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
										$fb5ea0f21131b307[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}
					}

					foreach ($a6629cd1b10b6170 as $d58b4f8653a391d8 => $a811da190447e007) {
						deleteStreamsByServer($a811da190447e007, $d58b4f8653a391d8, false);
					}
				}

				foreach ($E1f2e5d16be8efdf as $c3421043492d27cf => $da2ca16bd8bde6cb) {
					self::$db->query('DELETE FROM `streams_options` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') AND `argument_id` = 1;', $F26087d31c2bbe4d);
				}

				if (empty($cec8d7b2f57ce2cb)) {
				} else {
					$cec8d7b2f57ce2cb = rtrim($cec8d7b2f57ce2cb, ',');
					self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES ' . $cec8d7b2f57ce2cb . ';');
				}

				foreach ($ed2502d79a409dc0 as $C52c0b6b0f74407b => $F541acfbbe8cc24e) {
					d7e7f81f646193b2('stream', $C52c0b6b0f74407b, $F541acfbbe8cc24e);
				}

				foreach ($fb5ea0f21131b307 as $C52c0b6b0f74407b => $Fc8096aca65c232b) {
					D83CFF66bCdBEe05('stream', $C52c0b6b0f74407b, $Fc8096aca65c232b);
				}

				if (empty($F6fa7e329a8218d7)) {
				} else {
					$F6fa7e329a8218d7 = rtrim($F6fa7e329a8218d7, ',');
					self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES ' . $F6fa7e329a8218d7 . ';');
				}

				XUI::updateStreams($Cdb85875fd50f459);

				if (!isset($a27e64cc6ce01033['restart_on_edit'])) {
				} else {
					e36EC1583E223BF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array_values($Cdb85875fd50f459)));
				}
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function massEditChannels($a27e64cc6ce01033)
	{
		set_time_limit(0);
		ini_set('mysql.connect_timeout', 0);
		ini_set('max_execution_time', 0);
		ini_set('default_socket_timeout', 0);

		if (self::F228e3D146e758b1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			foreach (array('allow_record', 'rtmp_output') as $D3fa098be3f297cd) {
				if (!isset($a27e64cc6ce01033['c_' . $D3fa098be3f297cd])) {
				} else {
					if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
						$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
					} else {
						$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_transcode_profile_id'])) {
			} else {
				$d49041d5f05a9270['transcode_profile_id'] = $a27e64cc6ce01033['transcode_profile_id'];

				if (0 < $d49041d5f05a9270['transcode_profile_id']) {
					$d49041d5f05a9270['enable_transcode'] = 1;
				} else {
					$d49041d5f05a9270['enable_transcode'] = 0;
				}
			}

			$Cdb85875fd50f459 = json_decode($a27e64cc6ce01033['streams'], true);

			if (0 >= count($Cdb85875fd50f459)) {
			} else {
				$a0ab7ba3516bce7d = array();

				if (!(isset($a27e64cc6ce01033['c_category_id']) && in_array($a27e64cc6ce01033['category_id_type'], array('ADD', 'DEL')))) {
				} else {
					self::$db->query('SELECT `id`, `category_id` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$a0ab7ba3516bce7d[$C740da31596f24ef['id']] = (json_decode($C740da31596f24ef['category_id'], true) ?: array());
					}
				}

				$a6629cd1b10b6170 = $Ddf12215b82c5bba = $F9163b7e6a33fe89 = array();
				self::$db->query('SELECT `stream_id`, `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					$F9163b7e6a33fe89[intval($C740da31596f24ef['stream_id'])][intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
					$Ddf12215b82c5bba[intval($C740da31596f24ef['stream_id'])][] = intval($C740da31596f24ef['server_id']);
				}
				$cb498e4dcaac05cc = d7a15e0C2D9BeCE1();
				$E1f2e5d16be8efdf = $ed2502d79a409dc0 = $fb5ea0f21131b307 = array();
				$cc2d28ce73f817b8 = $F6fa7e329a8218d7 = '';

				foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
					if (!isset($a27e64cc6ce01033['c_category_id'])) {
					} else {
						$A5dcdeb6ecbbf6bd = array_map('intval', $a27e64cc6ce01033['category_id']);

						if ($a27e64cc6ce01033['category_id_type'] == 'ADD') {
							foreach (($a0ab7ba3516bce7d[$F26087d31c2bbe4d] ?: array()) as $Be965cdd996d4520) {
								if (in_array($Be965cdd996d4520, $A5dcdeb6ecbbf6bd)) {
								} else {
									$A5dcdeb6ecbbf6bd[] = $Be965cdd996d4520;
								}
							}
						} else {
							if ($a27e64cc6ce01033['category_id_type'] != 'DEL') {
							} else {
								$C8413f429e2be20f = $a0ab7ba3516bce7d[$F26087d31c2bbe4d];

								foreach ($A5dcdeb6ecbbf6bd as $Be965cdd996d4520) {
									if (($D3fa098be3f297cd = array_search($Be965cdd996d4520, $C8413f429e2be20f)) === false) {
									} else {
										unset($C8413f429e2be20f[$D3fa098be3f297cd]);
									}
								}
								$A5dcdeb6ecbbf6bd = $C8413f429e2be20f;
							}
						}

						$d49041d5f05a9270['category_id'] = '[' . implode(',', $A5dcdeb6ecbbf6bd) . ']';
					}

					$acd0eb2c8a975903 = f4817Dc607D9981D($d49041d5f05a9270);

					if (0 >= count($acd0eb2c8a975903['data'])) {
					} else {
						$acd0eb2c8a975903['data'][] = $F26087d31c2bbe4d;
						$A6d7047f2fda966c = 'UPDATE `streams` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
						self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
					}

					if (!isset($a27e64cc6ce01033['c_server_tree'])) {
					} else {
						$bdb0e33425a1906e = array();
						$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

						foreach ($e80d13748eba016a as $e81220b4451f37c9) {
							if ($e81220b4451f37c9['parent'] == '#') {
							} else {
								$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);

								if (in_array($a27e64cc6ce01033['server_type'], array('ADD', 'SET'))) {
									$bdb0e33425a1906e[] = $d58b4f8653a391d8;
									$a9fd4125120bdb0d = intval(in_array($d58b4f8653a391d8, ($a27e64cc6ce01033['on_demand'] ?: array())));

									if ($e81220b4451f37c9['parent'] == 'source') {
										$cceca8bbcbeb112d = null;
									} else {
										$cceca8bbcbeb112d = intval($e81220b4451f37c9['parent']);
									}

									if (isset($F9163b7e6a33fe89[$d58b4f8653a391d8])) {
										self::$db->query('UPDATE `streams_servers` SET `parent_id` = ?, `on_demand` = ? WHERE `server_stream_id` = ?;', $cceca8bbcbeb112d, $a9fd4125120bdb0d, $F9163b7e6a33fe89[$d58b4f8653a391d8]);
									} else {
										$F6fa7e329a8218d7 .= '(' . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . ', ' . (($cceca8bbcbeb112d ?: 'NULL')) . ', ' . $a9fd4125120bdb0d . '),';
									}

									$Ddf12215b82c5bba[$F26087d31c2bbe4d][] = $d58b4f8653a391d8;
								} else {
									if (!isset($F9163b7e6a33fe89[$F26087d31c2bbe4d][$d58b4f8653a391d8])) {
									} else {
										$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}

						if ($a27e64cc6ce01033['server_type'] != 'SET') {
						} else {
							foreach ($F9163b7e6a33fe89 as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									$a6629cd1b10b6170[$d58b4f8653a391d8][] = $F26087d31c2bbe4d;

									if (($D3fa098be3f297cd = array_search($d58b4f8653a391d8, $Ddf12215b82c5bba[$F26087d31c2bbe4d])) === false) {
									} else {
										unset($Ddf12215b82c5bba[$F26087d31c2bbe4d][$D3fa098be3f297cd]);
									}
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['c_bouquets'])) {
					} else {
						if ($a27e64cc6ce01033['bouquets_type'] == 'SET') {
							foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
								$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								if (in_array($ddf0508b312dbfb8['id'], $a27e64cc6ce01033['bouquets'])) {
								} else {
									$fb5ea0f21131b307[$ddf0508b312dbfb8['id']][] = $F26087d31c2bbe4d;
								}
							}
						} else {
							if ($a27e64cc6ce01033['bouquets_type'] == 'ADD') {
								foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
									$ed2502d79a409dc0[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
								}
							} else {
								if ($a27e64cc6ce01033['bouquets_type'] != 'DEL') {
								} else {
									foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
										$fb5ea0f21131b307[$ddf0508b312dbfb8][] = $F26087d31c2bbe4d;
									}
								}
							}
						}
					}

					if (!isset($a27e64cc6ce01033['reencode_on_edit'])) {
					} else {
						foreach ($Ddf12215b82c5bba[$F26087d31c2bbe4d] as $d58b4f8653a391d8) {
							$cc2d28ce73f817b8 .= "('channel', " . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . ', ' . time() . '),';
						}
					}

					foreach ($a6629cd1b10b6170 as $d58b4f8653a391d8 => $a811da190447e007) {
						deleteStreamsByServer($a811da190447e007, $d58b4f8653a391d8, false);
					}
				}

				foreach ($ed2502d79a409dc0 as $C52c0b6b0f74407b => $F541acfbbe8cc24e) {
					D7e7f81F646193b2('stream', $C52c0b6b0f74407b, $F541acfbbe8cc24e);
				}

				foreach ($fb5ea0f21131b307 as $C52c0b6b0f74407b => $Fc8096aca65c232b) {
					D83cfF66bcDbee05('stream', $C52c0b6b0f74407b, $Fc8096aca65c232b);
				}

				if (empty($F6fa7e329a8218d7)) {
				} else {
					$F6fa7e329a8218d7 = rtrim($F6fa7e329a8218d7, ',');
					self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES ' . $F6fa7e329a8218d7 . ';');
				}

				XUI::updateStreams($Cdb85875fd50f459);

				if (isset($a27e64cc6ce01033['reencode_on_edit'])) {
					self::$db->query("UPDATE `streams_servers` SET `pids_create_channel` = '[]', `cchannel_rsources` = '[]' WHERE `stream_id` IN (" . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

					if (empty($cc2d28ce73f817b8)) {
					} else {
						$cc2d28ce73f817b8 = rtrim($cc2d28ce73f817b8, ',');
						self::$db->query('INSERT INTO `queue`(`type`, `stream_id`, `server_id`, `added`) VALUES ' . $cc2d28ce73f817b8 . ';');
					}

					E36Ec1583E223Bf6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => array_values($Cdb85875fd50f459)));
				} else {
					if (!isset($a27e64cc6ce01033['restart_on_edit'])) {
					} else {
						e36eC1583e223bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array_values($Cdb85875fd50f459)));
					}
				}
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function E0407c2c64b2c037($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758b1($a27e64cc6ce01033)) {
			set_time_limit(0);
			ini_set('mysql.connect_timeout', 0);
			ini_set('max_execution_time', 0);
			ini_set('default_socket_timeout', 0);

			if (isset($a27e64cc6ce01033['edit'])) {
				if (aacd47D8157a1a09('adv', 'edit_stream')) {
					$d49041d5f05a9270 = ebdAAfC1c10F9506(e5ecEB32f67D5e70($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (AacD47D8157a1a09('adv', 'add_stream')) {
					$d49041d5f05a9270 = B9DA5D708fc1C079('streams', $a27e64cc6ce01033);
					$d49041d5f05a9270['type'] = 1;
					$d49041d5f05a9270['added'] = time();
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (isset($a27e64cc6ce01033['days_to_restart']) && preg_match('/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/', $a27e64cc6ce01033['time_to_restart'])) {
				$b7832adc388cb5a7 = array('days' => array(), 'at' => $a27e64cc6ce01033['time_to_restart']);

				foreach ($a27e64cc6ce01033['days_to_restart'] as $C3c8913edb801c35 => $d20afc15ac839efc) {
					$b7832adc388cb5a7['days'][] = $d20afc15ac839efc;
				}
				$d49041d5f05a9270['auto_restart'] = $b7832adc388cb5a7;
			} else {
				$d49041d5f05a9270['auto_restart'] = '';
			}

			foreach (array('fps_restart', 'gen_timestamps', 'allow_record', 'rtmp_output', 'stream_all', 'direct_source', 'direct_proxy', 'read_native') as $D3fa098be3f297cd) {
				if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
				} else {
					$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
				}
			}

			if ($d49041d5f05a9270['transcode_profile_id']) {
			} else {
				$d49041d5f05a9270['transcode_profile_id'] = 0;
			}

			if (0 >= $d49041d5f05a9270['transcode_profile_id']) {
			} else {
				$d49041d5f05a9270['enable_transcode'] = 1;
			}

			if (isset($a27e64cc6ce01033['restart_on_edit'])) {
				$d81f27c553f73ff4 = true;
			} else {
				$d81f27c553f73ff4 = false;
			}

			$faa909d3220546d8 = false;
			$Ab3cebb99a2b671e = array();

			if (isset($a27e64cc6ce01033['review'])) {
				$faa909d3220546d8 = true;

				foreach ($a27e64cc6ce01033['review'] as $addee113c4cee30c) {
					if ($addee113c4cee30c['channel_id'] || !$addee113c4cee30c['tvg_id']) {
					} else {
						$d8a1409105424710 = A1D06cA5A4835cfa($addee113c4cee30c['tvg_id']);

						if (!isset($d8a1409105424710)) {
						} else {
							$addee113c4cee30c['epg_id'] = $d8a1409105424710['epg_id'];
							$addee113c4cee30c['channel_id'] = $d8a1409105424710['channel_id'];

							if (empty($d8a1409105424710['epg_lang'])) {
							} else {
								$addee113c4cee30c['epg_lang'] = $d8a1409105424710['epg_lang'];
							}
						}
					}

					$Ab3cebb99a2b671e[] = $addee113c4cee30c;
				}
			} else {
				if (isset($_FILES['m3u_file'])) {
					if (aacd47D8157A1a09('adv', 'import_streams')) {
						if (!(empty($_FILES['m3u_file']['tmp_name']) || strtolower(pathinfo(explode('?', $_FILES['m3u_file']['name'])[0], PATHINFO_EXTENSION)) != 'm3u')) {
							$c15d5b523e931f51 = Bea20353771f9Ba3($_FILES['m3u_file']['tmp_name']);

							if (0 >= count($c15d5b523e931f51)) {
							} else {
								$E625d2d73b6533b9 = $dfafdeb19c68a177 = $D2165010a62b36e4 = array();
								self::$db->query('SELECT `id`, `stream_display_name`, `stream_source`, `channel_id` FROM `streams` WHERE `type` = 1;');

								foreach (self::$db->get_rows() as $C740da31596f24ef) {
									$d9ee1cc8e0f43f6e = preg_replace('/[^A-Za-z0-9 ]/', '', strtolower($C740da31596f24ef['stream_display_name']));

									if (empty($d9ee1cc8e0f43f6e)) {
									} else {
										$D2165010a62b36e4[$d9ee1cc8e0f43f6e] = $C740da31596f24ef['id'];
									}

									$E625d2d73b6533b9[$C740da31596f24ef['channel_id']] = $C740da31596f24ef['id'];

									foreach (json_decode($C740da31596f24ef['stream_source'], true) as $c8d91fcd2309e48a) {
										if (empty($c8d91fcd2309e48a)) {
										} else {
											$dfafdeb19c68a177[md5(preg_replace('(^https?://)', '', str_replace(' ', '%20', $c8d91fcd2309e48a)))] = $C740da31596f24ef['id'];
										}
									}
								}
								$d2454400cc015d2a = $d3937ae721b3afff = array();
								$Ea22c4a9ab5b2176 = 0;

								foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
									list($b82f49489b692793) = $B59c127fecf35c15->getExtTags();

									if (!$b82f49489b692793) {
									} else {
										if (!$b82f49489b692793->getAttribute('tvg-id')) {
										} else {
											$C3c8913edb801c35 = $b82f49489b692793->getAttribute('tvg-id');
											$d3937ae721b3afff[$C3c8913edb801c35][] = $Ea22c4a9ab5b2176;
										}
									}

									$Ea22c4a9ab5b2176++;
								}

								if (0 >= count($d3937ae721b3afff)) {
								} else {
									self::$db->query('SELECT `id`, `data` FROM `epg`;');

									if (0 >= self::$db->num_rows()) {
									} else {
										foreach (self::$db->get_rows() as $C740da31596f24ef) {
											foreach (json_decode($C740da31596f24ef['data'], true) as $F8c99b2741720390 => $Db855a676405656d) {
												if (!isset($d3937ae721b3afff[$F8c99b2741720390])) {
												} else {
													if (0 < count($Db855a676405656d['langs'])) {
														$ab84908c720bf94d = $Db855a676405656d['langs'][0];
													} else {
														$ab84908c720bf94d = '';
													}

													foreach ($d3937ae721b3afff[$F8c99b2741720390] as $Ea22c4a9ab5b2176) {
														$d2454400cc015d2a[$Ea22c4a9ab5b2176] = array('channel_id' => $F8c99b2741720390, 'epg_lang' => $ab84908c720bf94d, 'epg_id' => intval($C740da31596f24ef['id']));
													}
												}
											}
										}
									}
								}

								$Ea22c4a9ab5b2176 = 0;

								foreach ($c15d5b523e931f51 as $B59c127fecf35c15) {
									list($b82f49489b692793) = $B59c127fecf35c15->getExtTags();

									if (!$b82f49489b692793) {
									} else {
										$C700a2b357e5ed65 = $B59c127fecf35c15->getPath();
										$eaad9527ef2b563d = array('stream_source' => array($C700a2b357e5ed65), 'stream_icon' => ($b82f49489b692793->getAttribute('tvg-logo') ?: ''), 'stream_display_name' => ($b82f49489b692793->getTitle() ?: ''), 'epg_id' => null, 'epg_lang' => null, 'channel_id' => null);

										if (!$b82f49489b692793->getAttribute('tvg-id')) {
										} else {
											$d8a1409105424710 = ($d2454400cc015d2a[$Ea22c4a9ab5b2176] ?: null);

											if (!isset($d8a1409105424710)) {
											} else {
												$eaad9527ef2b563d['epg_id'] = $d8a1409105424710['epg_id'];
												$eaad9527ef2b563d['channel_id'] = $d8a1409105424710['channel_id'];

												if (empty($d8a1409105424710['epg_lang'])) {
												} else {
													$eaad9527ef2b563d['epg_lang'] = $d8a1409105424710['epg_lang'];
												}
											}
										}

										$d226d9b0cd5586aa = $db9a4d28d67ad60b = null;
										$c857e57ce6074885 = md5(preg_replace('(^https?://)', '', str_replace(' ', '%20', $C700a2b357e5ed65)));

										if (!isset($dfafdeb19c68a177[$c857e57ce6074885])) {
										} else {
											$db9a4d28d67ad60b = $dfafdeb19c68a177[$c857e57ce6074885];
										}

										$d9ee1cc8e0f43f6e = preg_replace('/[^A-Za-z0-9 ]/', '', strtolower($b82f49489b692793->getTitle()));

										if (!empty($d9ee1cc8e0f43f6e) && isset($D2165010a62b36e4[$d9ee1cc8e0f43f6e])) {
											$d226d9b0cd5586aa = $D2165010a62b36e4[$d9ee1cc8e0f43f6e];
										} else {
											if (empty($eaad9527ef2b563d['channel_id']) || !isset($E625d2d73b6533b9[$eaad9527ef2b563d['channel_id']])) {
											} else {
												$d226d9b0cd5586aa = $E625d2d73b6533b9[$eaad9527ef2b563d['channel_id']];
											}
										}

										if ($d226d9b0cd5586aa && !$db9a4d28d67ad60b && isset($a27e64cc6ce01033['add_source_as_backup'])) {
											self::$db->query('SELECT `stream_source` FROM `streams` WHERE `id` = ?;', $d226d9b0cd5586aa);

											if (0 >= self::$db->num_rows()) {
											} else {
												$bbfc9bd8432031f5 = (json_decode(self::$db->get_row()['stream_source'], true) ?: array());
												$bbfc9bd8432031f5[] = $C700a2b357e5ed65;
												self::$db->query('UPDATE `streams` SET `stream_source` = ? WHERE `id` = ?;', json_encode($bbfc9bd8432031f5), $d226d9b0cd5586aa);
												$Ab3cebb99a2b671e[] = array('update' => true, 'id' => $d226d9b0cd5586aa);
											}
										} else {
											if ($db9a4d28d67ad60b && isset($a27e64cc6ce01033['update_existing'])) {
												$eaad9527ef2b563d['id'] = $db9a4d28d67ad60b;
												$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;
											} else {
												if ($db9a4d28d67ad60b) {
												} else {
													$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;
												}
											}
										}
									}

									$Ea22c4a9ab5b2176++;
								}
							}
						} else {
							return array('status' => STATUS_INVALID_FILE, 'data' => $a27e64cc6ce01033);
						}
					} else {
						exit();
					}
				} else {
					if (!$a27e64cc6ce01033['epg_api']) {
					} else {
						$d49041d5f05a9270['channel_id'] = $a27e64cc6ce01033['epg_api_id'];
						$d49041d5f05a9270['epg_id'] = 0;
						$d49041d5f05a9270['epg_lang'] = null;
					}

					$eaad9527ef2b563d = array('stream_source' => array(), 'stream_icon' => $d49041d5f05a9270['stream_icon'], 'stream_display_name' => $d49041d5f05a9270['stream_display_name'], 'epg_id' => $d49041d5f05a9270['epg_id'], 'epg_lang' => $d49041d5f05a9270['epg_lang'], 'channel_id' => $d49041d5f05a9270['channel_id']);

					if (!isset($a27e64cc6ce01033['stream_source'])) {
					} else {
						foreach ($a27e64cc6ce01033['stream_source'] as $C3c8913edb801c35 => $C700a2b357e5ed65) {
							if (0 >= strlen($C700a2b357e5ed65)) {
							} else {
								$eaad9527ef2b563d['stream_source'][] = $C700a2b357e5ed65;
							}
						}
					}

					$Ab3cebb99a2b671e[] = $eaad9527ef2b563d;
				}
			}

			if (0 < count($Ab3cebb99a2b671e)) {
				$f518050a6d5f89c7 = array();
				$Ae4bd014b3779489 = array();

				if ($faa909d3220546d8) {
				} else {
					foreach (json_decode($a27e64cc6ce01033['bouquet_create_list'], true) as $ddf0508b312dbfb8) {
						$acd0eb2c8a975903 = f4817dC607D9981D(array('bouquet_name' => $ddf0508b312dbfb8, 'bouquet_channels' => array(), 'bouquet_movies' => array(), 'bouquet_series' => array(), 'bouquet_radios' => array()));
						$A6d7047f2fda966c = 'INSERT INTO `bouquets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$C52c0b6b0f74407b = self::$db->last_insert_id();
							$f518050a6d5f89c7[$ddf0508b312dbfb8] = $C52c0b6b0f74407b;
						}
					}

					foreach (json_decode($a27e64cc6ce01033['category_create_list'], true) as $A1925ae53e9307eb) {
						$acd0eb2c8a975903 = F4817DC607D9981D(array('category_type' => 'live', 'category_name' => $A1925ae53e9307eb, 'parent_id' => 0, 'cat_order' => 99, 'is_adult' => 0));
						$A6d7047f2fda966c = 'INSERT INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						} else {
							$Be965cdd996d4520 = self::$db->last_insert_id();
							$Ae4bd014b3779489[$A1925ae53e9307eb] = $Be965cdd996d4520;
						}
					}
				}

				foreach ($Ab3cebb99a2b671e as $addee113c4cee30c) {
					if (!$addee113c4cee30c['update']) {
						$eaad9527ef2b563d = $d49041d5f05a9270;

						if (!self::$rSettings['download_images']) {
						} else {
							$addee113c4cee30c['stream_icon'] = XUI::B2068ce8B339bf70($addee113c4cee30c['stream_icon'], 1);
						}

						if ($faa909d3220546d8) {
							$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', $addee113c4cee30c['category_id'])) . ']';
							$cb498e4dcaac05cc = array_map('intval', $addee113c4cee30c['bouquets']);
							unset($addee113c4cee30c['bouquets']);
						} else {
							$cb498e4dcaac05cc = array();

							foreach ($a27e64cc6ce01033['bouquets'] as $ddf0508b312dbfb8) {
								if (isset($f518050a6d5f89c7[$ddf0508b312dbfb8])) {
									$cb498e4dcaac05cc[] = $f518050a6d5f89c7[$ddf0508b312dbfb8];
								} else {
									if (!is_numeric($ddf0508b312dbfb8)) {
									} else {
										$cb498e4dcaac05cc[] = intval($ddf0508b312dbfb8);
									}
								}
							}
							$A5dcdeb6ecbbf6bd = array();

							foreach ($a27e64cc6ce01033['category_id'] as $A1925ae53e9307eb) {
								if (isset($Ae4bd014b3779489[$A1925ae53e9307eb])) {
									$A5dcdeb6ecbbf6bd[] = $Ae4bd014b3779489[$A1925ae53e9307eb];
								} else {
									if (!is_numeric($A1925ae53e9307eb)) {
									} else {
										$A5dcdeb6ecbbf6bd[] = intval($A1925ae53e9307eb);
									}
								}
							}
							$eaad9527ef2b563d['category_id'] = '[' . implode(',', array_map('intval', $A5dcdeb6ecbbf6bd)) . ']';

							if (isset($a27e64cc6ce01033['adaptive_link']) && 0 < count($a27e64cc6ce01033['adaptive_link'])) {
								$eaad9527ef2b563d['adaptive_link'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['adaptive_link'])) . ']';
							} else {
								$eaad9527ef2b563d['adaptive_link'] = null;
							}
						}

						foreach (array_keys($addee113c4cee30c) as $D3fa098be3f297cd) {
							$eaad9527ef2b563d[$D3fa098be3f297cd] = $addee113c4cee30c[$D3fa098be3f297cd];
						}

						if (isset($a27e64cc6ce01033['edit']) || isset($addee113c4cee30c['id'])) {
						} else {
							$eaad9527ef2b563d['order'] = DC95637C2DA3B543();
						}

						$eaad9527ef2b563d['title_sync'] = ($a27e64cc6ce01033['title_sync'] ?: null);

						if (!$eaad9527ef2b563d['title_sync']) {
						} else {
							list($fcd0ecd32f34b573, $c894f96a1558aac7) = array_map('intval', explode('_', $eaad9527ef2b563d['title_sync']));
							self::$db->query('SELECT `stream_display_name` FROM `providers_streams` WHERE `provider_id` = ? AND `stream_id` = ?;', $fcd0ecd32f34b573, $c894f96a1558aac7);

							if (self::$db->num_rows() != 1) {
							} else {
								$eaad9527ef2b563d['stream_display_name'] = self::$db->get_row()['stream_display_name'];
							}
						}

						$acd0eb2c8a975903 = f4817dC607D9981D($eaad9527ef2b563d);
						$A6d7047f2fda966c = 'REPLACE INTO `streams`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
							$F9163b7e6a33fe89 = array();

							if (!(isset($a27e64cc6ce01033['edit']) || isset($addee113c4cee30c['id']))) {
							} else {
								self::$db->query('SELECT `server_stream_id`, `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

								foreach (self::$db->get_rows() as $C740da31596f24ef) {
									$F9163b7e6a33fe89[intval($C740da31596f24ef['server_id'])] = intval($C740da31596f24ef['server_stream_id']);
								}
							}

							$bdb0e33425a1906e = array();
							$e80d13748eba016a = json_decode($a27e64cc6ce01033['server_tree_data'], true);

							foreach ($e80d13748eba016a as $e81220b4451f37c9) {
								if ($e81220b4451f37c9['parent'] == '#') {
								} else {
									$d58b4f8653a391d8 = intval($e81220b4451f37c9['id']);
									$bdb0e33425a1906e[] = $d58b4f8653a391d8;
									$a9fd4125120bdb0d = intval(in_array($d58b4f8653a391d8, ($a27e64cc6ce01033['on_demand'] ?: array())));

									if ($e81220b4451f37c9['parent'] == 'source') {
										$cceca8bbcbeb112d = null;
									} else {
										$cceca8bbcbeb112d = intval($e81220b4451f37c9['parent']);
									}

									if (isset($F9163b7e6a33fe89[$d58b4f8653a391d8])) {
										self::$db->query('UPDATE `streams_servers` SET `parent_id` = ?, `on_demand` = ? WHERE `server_stream_id` = ?;', $cceca8bbcbeb112d, $a9fd4125120bdb0d, $F9163b7e6a33fe89[$d58b4f8653a391d8]);
									} else {
										self::$db->query('INSERT INTO `streams_servers`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES(?, ?, ?, ?);', $Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, $cceca8bbcbeb112d, $a9fd4125120bdb0d);
									}
								}
							}

							foreach ($F9163b7e6a33fe89 as $d58b4f8653a391d8 => $Cc1397bd13b7db04) {
								if (in_array($d58b4f8653a391d8, $bdb0e33425a1906e)) {
								} else {
									D13C1A44A4495B05($Fc2dc5a0ce8d07ea, $d58b4f8653a391d8, false, false);
								}
							}
							self::$db->query('DELETE FROM `streams_options` WHERE `stream_id` = ?;', $Fc2dc5a0ce8d07ea);

							if (!(isset($a27e64cc6ce01033['user_agent']) && 0 < strlen($a27e64cc6ce01033['user_agent']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 1, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['user_agent']);
							}

							if (!(isset($a27e64cc6ce01033['http_proxy']) && 0 < strlen($a27e64cc6ce01033['http_proxy']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 2, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['http_proxy']);
							}

							if (!(isset($a27e64cc6ce01033['cookie']) && 0 < strlen($a27e64cc6ce01033['cookie']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 17, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['cookie']);
							}

							if (!(isset($a27e64cc6ce01033['headers']) && 0 < strlen($a27e64cc6ce01033['headers']))) {
							} else {
								self::$db->query('INSERT INTO `streams_options`(`stream_id`, `argument_id`, `value`) VALUES(?, 19, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['headers']);
							}

							if (!$d81f27c553f73ff4) {
							} else {
								e36Ec1583E223bF6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array($Fc2dc5a0ce8d07ea)));
							}

							foreach ($cb498e4dcaac05cc as $ddf0508b312dbfb8) {
								d7e7F81F646193B2('stream', $ddf0508b312dbfb8, $Fc2dc5a0ce8d07ea);
							}

							if (!(isset($a27e64cc6ce01033['edit']) || isset($addee113c4cee30c['id']))) {
							} else {
								foreach (D7a15E0C2d9BecE1() as $ddf0508b312dbfb8) {
									if (in_array($ddf0508b312dbfb8['id'], $cb498e4dcaac05cc)) {
									} else {
										D83Cff66bcdBEe05('stream', $ddf0508b312dbfb8['id'], $Fc2dc5a0ce8d07ea);
									}
								}
							}

							if ($d49041d5f05a9270['epg_id'] != 0 || empty($d49041d5f05a9270['channel_id'])) {
							} else {
								processEPGAPI($Fc2dc5a0ce8d07ea, $d49041d5f05a9270['channel_id']);
							}

							XUI::afA0F3FfB001b9bE($Fc2dc5a0ce8d07ea);
						} else {
							foreach ($f518050a6d5f89c7 as $ddf0508b312dbfb8 => $C3c8913edb801c35) {
								$Fee0d5a474c96306->query('DELETE FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);
							}

							foreach ($Ae4bd014b3779489 as $A1925ae53e9307eb => $C3c8913edb801c35) {
								$Fee0d5a474c96306->query('DELETE FROM `streams_categories` WHERE `id` = ?;', $C3c8913edb801c35);
							}

							return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
						}
					}
				}

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			} else {
				return array('status' => STATUS_NO_SOURCES, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function b33B7A37bC32714a($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758b1($a27e64cc6ce01033)) {
			$ae09e83aa317932c = json_decode($a27e64cc6ce01033['categories'], true);

			if (0 >= count($ae09e83aa317932c)) {
			} else {
				foreach ($ae09e83aa317932c as $c6c389b9adf3a40c => $A0fe8eef6d1f1af0) {
					self::$db->query('UPDATE `streams_categories` SET `cat_order` = ?, `parent_id` = 0 WHERE `id` = ?;', intval($c6c389b9adf3a40c) + 1, $A0fe8eef6d1f1af0['id']);
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function orderServers($a27e64cc6ce01033)
	{
		if (self::F228E3d146E758b1($a27e64cc6ce01033)) {
			$D73fc69fad47d1cd = json_decode($a27e64cc6ce01033['server_order'], true);

			if (0 >= count($D73fc69fad47d1cd)) {
			} else {
				foreach ($D73fc69fad47d1cd as $c6c389b9adf3a40c => $bd0e2d6798cc673d) {
					self::$db->query('UPDATE `servers` SET `order` = ? WHERE `id` = ?;', intval($c6c389b9adf3a40c) + 1, $bd0e2d6798cc673d['id']);
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function Dc7b22871ac995E5($a27e64cc6ce01033)
	{
		if (self::F228E3d146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = EBDAAfC1c10f9506(E0E9955E91fa6027($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = b9Da5D708FC1c079('streams_categories', $a27e64cc6ce01033);
				$d49041d5f05a9270['cat_order'] = 99;
				unset($d49041d5f05a9270['id']);
			}

			if (isset($a27e64cc6ce01033['is_adult'])) {
				$d49041d5f05a9270['is_adult'] = 1;
			} else {
				$d49041d5f05a9270['is_adult'] = 0;
			}

			$acd0eb2c8a975903 = F4817dC607D9981d($d49041d5f05a9270);
			$A6d7047f2fda966c = 'REPLACE INTO `streams_categories`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

			if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			}

			return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function B6076D4e3FeD8702($a27e64cc6ce01033)
	{
		if (self::f228E3d146e758B1($a27e64cc6ce01033)) {
			$E379394c7b1a273f = intval($a27e64cc6ce01033['content_type']);
			$c8d91fcd2309e48a = intval($a27e64cc6ce01033['source_server']);
			$f1806fd2b4ae4335 = intval($a27e64cc6ce01033['replacement_server']);

			if (!(0 < $c8d91fcd2309e48a && 0 < $f1806fd2b4ae4335 && $c8d91fcd2309e48a != $f1806fd2b4ae4335)) {
			} else {
				$cef0df8c5b964cc8 = array();

				if ($E379394c7b1a273f == 0) {
					self::$db->query('SELECT `stream_id` FROM `streams_servers` WHERE `server_id` = ?;', $f1806fd2b4ae4335);

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$cef0df8c5b964cc8[] = intval($C740da31596f24ef['stream_id']);
					}
				} else {
					self::$db->query('SELECT `streams_servers`.`stream_id` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams_servers`.`server_id` = ? AND `streams`.`type` = ?;', $f1806fd2b4ae4335, $E379394c7b1a273f);

					foreach (self::$db->get_rows() as $C740da31596f24ef) {
						$cef0df8c5b964cc8[] = intval($C740da31596f24ef['stream_id']);
					}
				}

				self::$db->query('SELECT `stream_id` FROM `streams_servers` WHERE `server_id` = ?;', $c8d91fcd2309e48a);

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					if (!in_array(intval($C740da31596f24ef['stream_id']), $cef0df8c5b964cc8)) {
					} else {
						self::$db->query('DELETE FROM `streams_servers` WHERE `stream_id` = ? AND `server_id` = ?;', $C740da31596f24ef['stream_id'], $c8d91fcd2309e48a);
					}
				}

				if ($E379394c7b1a273f == 0) {
					self::$db->query('UPDATE `streams_servers` SET `server_id` = ? WHERE `server_id` = ?;', $f1806fd2b4ae4335, $c8d91fcd2309e48a);
				} else {
					self::$db->query('UPDATE `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` SET `streams_servers`.`server_id` = ? WHERE `streams_servers`.`server_id` = ? AND `streams`.`type` = ?;', $f1806fd2b4ae4335, $c8d91fcd2309e48a, $E379394c7b1a273f);
				}
			}

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function ADDE0be331F79Aad($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758B1($a27e64cc6ce01033)) {
			$c653e50873723ab9 = str_replace('/', '\\/', $a27e64cc6ce01033['old_dns']);
			$e92b75f428976914 = str_replace('/', '\\/', $a27e64cc6ce01033['new_dns']);
			self::$db->query('UPDATE `streams` SET `stream_source` = REPLACE(`stream_source`, ?, ?);', $c653e50873723ab9, $e92b75f428976914);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function Ae1C2e59b87C9B1B($a27e64cc6ce01033)
	{
		if (self::f228e3d146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = EbdaaFC1c10F9506(d42EDD31c6eF0655($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = b9Da5D708FC1c079('tickets', $a27e64cc6ce01033);
				unset($d49041d5f05a9270['id']);
			}

			if (!(strlen($a27e64cc6ce01033['title']) == 0 && !isset($a27e64cc6ce01033['respond']) || strlen($a27e64cc6ce01033['message']) == 0)) {
				if (!isset($a27e64cc6ce01033['respond'])) {
					$acd0eb2c8a975903 = f4817Dc607D9981D($d49041d5f05a9270);
					$A6d7047f2fda966c = 'REPLACE INTO `tickets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
						self::$db->query('INSERT INTO `tickets_replies`(`ticket_id`, `admin_reply`, `message`, `date`) VALUES(?, 0, ?, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['message'], time());

						return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				$Fc045a436f741403 = d42EDd31c6EF0655($a27e64cc6ce01033['respond']);

				if ($Fc045a436f741403) {
					if (intval(self::$rUserInfo['id']) == intval($Fc045a436f741403['member_id'])) {
						self::$db->query('UPDATE `tickets` SET `admin_read` = 0, `user_read` = 1 WHERE `id` = ?;', $a27e64cc6ce01033['respond']);
						self::$db->query('INSERT INTO `tickets_replies`(`ticket_id`, `admin_reply`, `message`, `date`) VALUES(?, 0, ?, ?);', $a27e64cc6ce01033['respond'], $a27e64cc6ce01033['message'], time());
					} else {
						self::$db->query('UPDATE `tickets` SET `admin_read` = 0, `user_read` = 0 WHERE `id` = ?;', $a27e64cc6ce01033['respond']);
						self::$db->query('INSERT INTO `tickets_replies`(`ticket_id`, `admin_reply`, `message`, `date`) VALUES(?, 1, ?, ?);', $a27e64cc6ce01033['respond'], $a27e64cc6ce01033['message'], time());
					}

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $a27e64cc6ce01033['respond']));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_DATA, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function ac56fd7a04748A62($a27e64cc6ce01033)
	{
		if (self::F228E3D146E758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = ebDaAFc1c10F9506(b24A2F16afe7fAAF($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = B9DA5D708fc1C079('blocked_uas', $a27e64cc6ce01033);
				unset($d49041d5f05a9270['id']);
			}

			if (isset($a27e64cc6ce01033['exact_match'])) {
				$d49041d5f05a9270['exact_match'] = true;
			} else {
				$d49041d5f05a9270['exact_match'] = false;
			}

			$acd0eb2c8a975903 = F4817Dc607d9981d($d49041d5f05a9270);
			$A6d7047f2fda966c = 'REPLACE INTO `blocked_uas`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

			if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
				$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
			}

			return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}

	public static function processPlexSync($a27e64cc6ce01033)
	{
		if (self::F228E3D146e758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = ebDaAfc1c10f9506(E6e296dD0051114b($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = b9Da5D708fC1c079('watch_folders', $a27e64cc6ce01033);
				unset($d49041d5f05a9270['id']);
			}

			if (isset($a27e64cc6ce01033['edit'])) {
				self::$db->query('SELECT COUNT(*) AS `count` FROM `watch_folders` WHERE `directory` = ? AND `server_id` = ? AND `plex_ip` = ? AND `id` <> ?;', $a27e64cc6ce01033['library_id'], $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['plex_ip'], $d49041d5f05a9270['id']);
			} else {
				self::$db->query('SELECT COUNT(*) AS `count` FROM `watch_folders` WHERE `directory` = ? AND `server_id` = ? AND `plex_ip` = ?;', $a27e64cc6ce01033['library_id'], $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['plex_ip']);
			}

			if (0 >= self::$db->get_row()['count']) {
				$d49041d5f05a9270['type'] = 'plex';
				$d49041d5f05a9270['directory'] = $a27e64cc6ce01033['library_id'];

				if (is_array($a27e64cc6ce01033['server_id'])) {
					$a8bb73cba48fb7f6 = $a27e64cc6ce01033['server_id'];
					$d49041d5f05a9270['server_id'] = intval(array_shift($a8bb73cba48fb7f6));
					$d49041d5f05a9270['server_add'] = '[' . implode(',', array_map('intval', $a8bb73cba48fb7f6)) . ']';
				} else {
					$d49041d5f05a9270['server_id'] = intval($a27e64cc6ce01033['server_id']);
					$d49041d5f05a9270['server_add'] = null;
				}

				$d49041d5f05a9270['plex_ip'] = $a27e64cc6ce01033['plex_ip'];
				$d49041d5f05a9270['plex_port'] = $a27e64cc6ce01033['plex_port'];
				$d49041d5f05a9270['plex_libraries'] = $a27e64cc6ce01033['libraries'];
				$d49041d5f05a9270['plex_username'] = $a27e64cc6ce01033['username'];

				if (isset($a27e64cc6ce01033['direct_proxy'])) {
					$d49041d5f05a9270['direct_proxy'] = 1;
				} else {
					$d49041d5f05a9270['direct_proxy'] = 0;
				}

				if (0 >= strlen($a27e64cc6ce01033['password'])) {
				} else {
					$d49041d5f05a9270['plex_password'] = $a27e64cc6ce01033['password'];
				}

				foreach (array('remove_subtitles', 'check_tmdb', 'store_categories', 'scan_missing', 'auto_upgrade', 'read_native', 'movie_symlink', 'auto_encode', 'active') as $D3fa098be3f297cd) {
					if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
						$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
					} else {
						$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
					}
				}
				$d49041d5f05a9270['category_id'] = intval($a27e64cc6ce01033['override_category']);
				$d49041d5f05a9270['fb_category_id'] = intval($a27e64cc6ce01033['fallback_category']);
				$d49041d5f05a9270['bouquets'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['override_bouquets'])) . ']';
				$d49041d5f05a9270['fb_bouquets'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['fallback_bouquets'])) . ']';
				$d49041d5f05a9270['target_container'] = ($a27e64cc6ce01033['target_container'] == 'auto' ? null : $a27e64cc6ce01033['target_container']);
				$acd0eb2c8a975903 = F4817dC607D9981d($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `watch_folders`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			} else {
				return array('status' => STATUS_EXISTS_DIR, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function a85970f9953C4294($a27e64cc6ce01033)
	{
		if (self::f228e3d146E758b1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = EBdAAFC1c10f9506(E6E296DD0051114b($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
			} else {
				$d49041d5f05a9270 = B9DA5d708fC1c079('watch_folders', $a27e64cc6ce01033);
				unset($d49041d5f05a9270['id']);
			}

			$Bc16cc77a681d1ed = $a27e64cc6ce01033['selected_path'];

			if (0 < strlen($Bc16cc77a681d1ed) && $Bc16cc77a681d1ed != '/') {
				if (isset($a27e64cc6ce01033['edit'])) {
					self::$db->query('SELECT COUNT(*) AS `count` FROM `watch_folders` WHERE `directory` = ? AND `server_id` = ? AND `type` = ? AND `id` <> ?;', $Bc16cc77a681d1ed, $d49041d5f05a9270['server_id'], $a27e64cc6ce01033['folder_type'], $d49041d5f05a9270['id']);
				} else {
					self::$db->query('SELECT COUNT(*) AS `count` FROM `watch_folders` WHERE `directory` = ? AND `server_id` = ? AND `type` = ?;', $Bc16cc77a681d1ed, $d49041d5f05a9270['server_id'], $a27e64cc6ce01033['folder_type']);
				}

				if (0 >= self::$db->get_row()['count']) {
					$d49041d5f05a9270['type'] = $a27e64cc6ce01033['folder_type'];
					$d49041d5f05a9270['directory'] = $Bc16cc77a681d1ed;
					$d49041d5f05a9270['bouquets'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['bouquets'])) . ']';
					$d49041d5f05a9270['fb_bouquets'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['fb_bouquets'])) . ']';

					if (0 < count($a27e64cc6ce01033['allowed_extensions'])) {
						$d49041d5f05a9270['allowed_extensions'] = json_encode($a27e64cc6ce01033['allowed_extensions']);
					} else {
						$d49041d5f05a9270['allowed_extensions'] = '[]';
					}

					$d49041d5f05a9270['target_container'] = ($a27e64cc6ce01033['target_container'] == 'auto' ? null : $a27e64cc6ce01033['target_container']);
					$d49041d5f05a9270['category_id'] = intval($a27e64cc6ce01033['category_id_' . $a27e64cc6ce01033['folder_type']]);
					$d49041d5f05a9270['fb_category_id'] = intval($a27e64cc6ce01033['fb_category_id_' . $a27e64cc6ce01033['folder_type']]);

					foreach (array('remove_subtitles', 'duplicate_tmdb', 'extract_metadata', 'fallback_title', 'disable_tmdb', 'ignore_no_match', 'auto_subtitles', 'auto_upgrade', 'read_native', 'movie_symlink', 'auto_encode', 'ffprobe_input', 'active') as $D3fa098be3f297cd) {
						if (isset($a27e64cc6ce01033[$D3fa098be3f297cd])) {
							$d49041d5f05a9270[$D3fa098be3f297cd] = 1;
						} else {
							$d49041d5f05a9270[$D3fa098be3f297cd] = 0;
						}
					}
					$acd0eb2c8a975903 = f4817dc607D9981d($d49041d5f05a9270);
					$A6d7047f2fda966c = 'REPLACE INTO `watch_folders`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

						return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				} else {
					return array('status' => STATUS_EXISTS_DIR, 'data' => $a27e64cc6ce01033);
				}
			} else {
				return array('status' => STATUS_INVALID_DIR, 'data' => $a27e64cc6ce01033);
			}
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function aD583f76ccc9bD2a($a27e64cc6ce01033)
	{
		if (self::F228e3d146E758b1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			foreach (array('is_stalker', 'is_isplock', 'is_restreamer', 'is_trial') as $bb2621204e39e62d) {
				if (!isset($a27e64cc6ce01033['c_' . $bb2621204e39e62d])) {
				} else {
					if (isset($a27e64cc6ce01033[$bb2621204e39e62d])) {
						$d49041d5f05a9270[$bb2621204e39e62d] = 1;
					} else {
						$d49041d5f05a9270[$bb2621204e39e62d] = 0;
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_admin_notes'])) {
			} else {
				$d49041d5f05a9270['admin_notes'] = $a27e64cc6ce01033['admin_notes'];
			}

			if (!isset($a27e64cc6ce01033['c_reseller_notes'])) {
			} else {
				$d49041d5f05a9270['reseller_notes'] = $a27e64cc6ce01033['reseller_notes'];
			}

			if (!isset($a27e64cc6ce01033['c_forced_country'])) {
			} else {
				$d49041d5f05a9270['forced_country'] = $a27e64cc6ce01033['forced_country'];
			}

			if (!isset($a27e64cc6ce01033['c_member_id'])) {
			} else {
				$d49041d5f05a9270['member_id'] = intval($a27e64cc6ce01033['member_id']);
			}

			if (!isset($a27e64cc6ce01033['c_force_server_id'])) {
			} else {
				$d49041d5f05a9270['force_server_id'] = intval($a27e64cc6ce01033['force_server_id']);
			}

			if (!isset($a27e64cc6ce01033['c_max_connections'])) {
			} else {
				$d49041d5f05a9270['max_connections'] = intval($a27e64cc6ce01033['max_connections']);
			}

			if (!isset($a27e64cc6ce01033['c_exp_date'])) {
			} else {
				if (isset($a27e64cc6ce01033['no_expire'])) {
					$d49041d5f05a9270['exp_date'] = null;
				} else {
					try {
						$c94b497359f8aed9 = new DateTime($a27e64cc6ce01033['exp_date']);
						$d49041d5f05a9270['exp_date'] = $c94b497359f8aed9->format('U');
					} catch (Exception $c34ae71903f0d920) {
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_access_output'])) {
			} else {
				$C5c92158885984fd = array();

				foreach ($a27e64cc6ce01033['access_output'] as $F3ba21e7eb72c779) {
					$C5c92158885984fd[] = $F3ba21e7eb72c779;
				}
				$d49041d5f05a9270['allowed_outputs'] = '[' . implode(',', array_map('intval', $C5c92158885984fd)) . ']';
			}

			if (!isset($a27e64cc6ce01033['c_bouquets'])) {
			} else {
				$d49041d5f05a9270['bouquet'] = array();

				foreach (json_decode($a27e64cc6ce01033['bouquets_selected'], true) as $ddf0508b312dbfb8) {
					if (!is_numeric($ddf0508b312dbfb8)) {
					} else {
						$d49041d5f05a9270['bouquet'][] = $ddf0508b312dbfb8;
					}
				}
				$d49041d5f05a9270['bouquet'] = sortArrayByArray($d49041d5f05a9270['bouquet'], array_keys(A53403Fc10F556BE()));
				$d49041d5f05a9270['bouquet'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['bouquet'])) . ']';
			}

			if (!isset($a27e64cc6ce01033['reset_isp_lock'])) {
			} else {
				$d49041d5f05a9270['isp_desc'] = '';
				$d49041d5f05a9270['as_number'] = $d49041d5f05a9270['isp_desc'];
			}

			$B963b5d49ca08acf = confirmIDs(json_decode($a27e64cc6ce01033['users_selected'], true));

			if (0 >= count($B963b5d49ca08acf)) {
			} else {
				$acd0eb2c8a975903 = F4817dc607d9981d($d49041d5f05a9270);

				if (0 >= count($acd0eb2c8a975903['data'])) {
				} else {
					$A6d7047f2fda966c = 'UPDATE `lines` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` IN (' . implode(',', $B963b5d49ca08acf) . ');';
					self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
				}

				self::$db->query('SELECT `pair_id` FROM `lines` WHERE `pair_id` IN (' . implode(',', $B963b5d49ca08acf) . ');');

				foreach (self::$db->get_rows() as $C740da31596f24ef) {
					A85A61D6F165008a($C740da31596f24ef['pair_id']);
				}
				XUI::updateLines($B963b5d49ca08acf);
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function FBB31EeA1c81d1f8($a27e64cc6ce01033)
	{
		if (self::f228e3d146e758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();
			$C2cdb5dc50f13c15 = array();

			foreach (array('lock_device') as $bb2621204e39e62d) {
				if (!isset($a27e64cc6ce01033['c_' . $bb2621204e39e62d])) {
				} else {
					if (isset($a27e64cc6ce01033[$bb2621204e39e62d])) {
						$d49041d5f05a9270[$bb2621204e39e62d] = 1;
					} else {
						$d49041d5f05a9270[$bb2621204e39e62d] = 0;
					}
				}
			}

			foreach (array('is_isplock', 'is_trial') as $bb2621204e39e62d) {
				if (!isset($a27e64cc6ce01033['c_' . $bb2621204e39e62d])) {
				} else {
					if (isset($a27e64cc6ce01033[$bb2621204e39e62d])) {
						$C2cdb5dc50f13c15[$bb2621204e39e62d] = 1;
					} else {
						$C2cdb5dc50f13c15[$bb2621204e39e62d] = 0;
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_modern_theme'])) {
			} else {
				if (isset($a27e64cc6ce01033['modern_theme'])) {
					$d49041d5f05a9270['theme_type'] = 0;
				} else {
					$d49041d5f05a9270['theme_type'] = 1;
				}
			}

			if (!isset($a27e64cc6ce01033['c_parent_password'])) {
			} else {
				$d49041d5f05a9270['parent_password'] = $a27e64cc6ce01033['parent_password'];
			}

			if (!isset($a27e64cc6ce01033['c_admin_notes'])) {
			} else {
				$C2cdb5dc50f13c15['admin_notes'] = $a27e64cc6ce01033['admin_notes'];
			}

			if (!isset($a27e64cc6ce01033['c_reseller_notes'])) {
			} else {
				$C2cdb5dc50f13c15['reseller_notes'] = $a27e64cc6ce01033['reseller_notes'];
			}

			if (!isset($a27e64cc6ce01033['c_forced_country'])) {
			} else {
				$C2cdb5dc50f13c15['forced_country'] = $a27e64cc6ce01033['forced_country'];
			}

			if (!isset($a27e64cc6ce01033['c_member_id'])) {
			} else {
				$C2cdb5dc50f13c15['member_id'] = intval($a27e64cc6ce01033['member_id']);
			}

			if (!isset($a27e64cc6ce01033['c_force_server_id'])) {
			} else {
				$C2cdb5dc50f13c15['force_server_id'] = intval($a27e64cc6ce01033['force_server_id']);
			}

			if (!isset($a27e64cc6ce01033['c_exp_date'])) {
			} else {
				if (isset($a27e64cc6ce01033['no_expire'])) {
					$C2cdb5dc50f13c15['exp_date'] = null;
				} else {
					try {
						$c94b497359f8aed9 = new DateTime($a27e64cc6ce01033['exp_date']);
						$C2cdb5dc50f13c15['exp_date'] = $c94b497359f8aed9->format('U');
					} catch (Exception $c34ae71903f0d920) {
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_bouquets'])) {
			} else {
				$C2cdb5dc50f13c15['bouquet'] = array();

				foreach (json_decode($a27e64cc6ce01033['bouquets_selected'], true) as $ddf0508b312dbfb8) {
					if (!is_numeric($ddf0508b312dbfb8)) {
					} else {
						$C2cdb5dc50f13c15['bouquet'][] = $ddf0508b312dbfb8;
					}
				}
				$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray($C2cdb5dc50f13c15['bouquet'], array_keys(a53403Fc10f556Be()));
				$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';
			}

			if (!isset($a27e64cc6ce01033['reset_isp_lock'])) {
			} else {
				$C2cdb5dc50f13c15['isp_desc'] = '';
				$C2cdb5dc50f13c15['as_number'] = $C2cdb5dc50f13c15['isp_desc'];
			}

			if (!isset($a27e64cc6ce01033['reset_device_lock'])) {
			} else {
				$d49041d5f05a9270['ver'] = '';
				$d49041d5f05a9270['device_id2'] = $d49041d5f05a9270['ver'];
				$d49041d5f05a9270['device_id'] = $d49041d5f05a9270['device_id2'];
				$d49041d5f05a9270['hw_version'] = $d49041d5f05a9270['device_id'];
				$d49041d5f05a9270['image_version'] = $d49041d5f05a9270['hw_version'];
				$d49041d5f05a9270['stb_type'] = $d49041d5f05a9270['image_version'];
				$d49041d5f05a9270['sn'] = $d49041d5f05a9270['stb_type'];
			}

			if (empty($a27e64cc6ce01033['message_type'])) {
			} else {
				$C594577200dcd1a3 = array('event' => $a27e64cc6ce01033['message_type'], 'need_confirm' => 0, 'msg' => '', 'reboot_after_ok' => intval(isset($a27e64cc6ce01033['reboot_portal'])));

				if ($a27e64cc6ce01033['message_type'] == 'send_msg') {
					$C594577200dcd1a3['need_confirm'] = 1;
					$C594577200dcd1a3['msg'] = $a27e64cc6ce01033['message'];
				} else {
					if ($a27e64cc6ce01033['message_type'] == 'play_channel') {
						$C594577200dcd1a3['msg'] = intval($a27e64cc6ce01033['selected_channel']);
						$C594577200dcd1a3['reboot_after_ok'] = 0;
					} else {
						$C594577200dcd1a3['need_confirm'] = 0;
						$C594577200dcd1a3['reboot_after_ok'] = 0;
					}
				}
			}

			$Bb1e97d0ea20bca0 = json_decode($a27e64cc6ce01033['devices_selected'], true);

			foreach ($Bb1e97d0ea20bca0 as $cdc93dae5ba3d206) {
				$Fdc8e0fc5edb3ca8 = BfE9937c6D242A3D($cdc93dae5ba3d206);

				if (!$Fdc8e0fc5edb3ca8) {
				} else {
					if (empty($a27e64cc6ce01033['message_type'])) {
					} else {
						self::$db->query('INSERT INTO `mag_events`(`status`, `mag_device_id`, `event`, `need_confirm`, `msg`, `reboot_after_ok`, `send_time`) VALUES (0, ?, ?, ?, ?, ?, ?);', $cdc93dae5ba3d206, $C594577200dcd1a3['event'], $C594577200dcd1a3['need_confirm'], $C594577200dcd1a3['msg'], $C594577200dcd1a3['reboot_after_ok'], time());
					}

					if (0 >= count($d49041d5f05a9270)) {
					} else {
						$acd0eb2c8a975903 = f4817dc607d9981d($d49041d5f05a9270);

						if (0 >= count($acd0eb2c8a975903['data'])) {
						} else {
							$acd0eb2c8a975903['data'][] = $cdc93dae5ba3d206;
							$A6d7047f2fda966c = 'UPDATE `mag_devices` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `mag_id` = ?;';
							self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						}
					}

					if (0 >= count($C2cdb5dc50f13c15)) {
					} else {
						$b174976b99c4ec48 = array();

						if (!isset($Fdc8e0fc5edb3ca8['user']['id'])) {
						} else {
							$b174976b99c4ec48[] = $Fdc8e0fc5edb3ca8['user']['id'];
						}

						if (!isset($Fdc8e0fc5edb3ca8['user']['paired'])) {
						} else {
							$b174976b99c4ec48[] = $Fdc8e0fc5edb3ca8['paired']['id'];
						}

						foreach ($b174976b99c4ec48 as $D78ff1d0edade5eb) {
							$acd0eb2c8a975903 = f4817dc607d9981D($C2cdb5dc50f13c15);

							if (0 >= count($acd0eb2c8a975903['data'])) {
							} else {
								$acd0eb2c8a975903['data'][] = $D78ff1d0edade5eb;
								$A6d7047f2fda966c = 'UPDATE `lines` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
								self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
								XUI::BC77Edc4169F1bAa($D78ff1d0edade5eb);
							}
						}
					}
				}
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function c86d70b28399D723($a27e64cc6ce01033)
	{
		if (self::f228E3d146e758B1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();
			$C2cdb5dc50f13c15 = array();

			foreach (array('is_isplock', 'is_trial') as $bb2621204e39e62d) {
				if (!isset($a27e64cc6ce01033['c_' . $bb2621204e39e62d])) {
				} else {
					if (isset($a27e64cc6ce01033[$bb2621204e39e62d])) {
						$C2cdb5dc50f13c15[$bb2621204e39e62d] = 1;
					} else {
						$C2cdb5dc50f13c15[$bb2621204e39e62d] = 0;
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_admin_notes'])) {
			} else {
				$C2cdb5dc50f13c15['admin_notes'] = $a27e64cc6ce01033['admin_notes'];
			}

			if (!isset($a27e64cc6ce01033['c_reseller_notes'])) {
			} else {
				$C2cdb5dc50f13c15['reseller_notes'] = $a27e64cc6ce01033['reseller_notes'];
			}

			if (!isset($a27e64cc6ce01033['c_forced_country'])) {
			} else {
				$C2cdb5dc50f13c15['forced_country'] = $a27e64cc6ce01033['forced_country'];
			}

			if (!isset($a27e64cc6ce01033['c_member_id'])) {
			} else {
				$C2cdb5dc50f13c15['member_id'] = intval($a27e64cc6ce01033['member_id']);
			}

			if (!isset($a27e64cc6ce01033['c_force_server_id'])) {
			} else {
				$C2cdb5dc50f13c15['force_server_id'] = intval($a27e64cc6ce01033['force_server_id']);
			}

			if (!isset($a27e64cc6ce01033['c_exp_date'])) {
			} else {
				if (isset($a27e64cc6ce01033['no_expire'])) {
					$C2cdb5dc50f13c15['exp_date'] = null;
				} else {
					try {
						$c94b497359f8aed9 = new DateTime($a27e64cc6ce01033['exp_date']);
						$C2cdb5dc50f13c15['exp_date'] = $c94b497359f8aed9->format('U');
					} catch (Exception $c34ae71903f0d920) {
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_bouquets'])) {
			} else {
				$C2cdb5dc50f13c15['bouquet'] = array();

				foreach (json_decode($a27e64cc6ce01033['bouquets_selected'], true) as $ddf0508b312dbfb8) {
					if (!is_numeric($ddf0508b312dbfb8)) {
					} else {
						$C2cdb5dc50f13c15['bouquet'][] = $ddf0508b312dbfb8;
					}
				}
				$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray($C2cdb5dc50f13c15['bouquet'], array_keys(a53403Fc10f556bE()));
				$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';
			}

			if (!isset($a27e64cc6ce01033['reset_isp_lock'])) {
			} else {
				$C2cdb5dc50f13c15['isp_desc'] = '';
				$C2cdb5dc50f13c15['as_number'] = $C2cdb5dc50f13c15['isp_desc'];
			}

			if (!isset($a27e64cc6ce01033['reset_device_lock'])) {
			} else {
				$d49041d5f05a9270['token'] = '';
				$d49041d5f05a9270['lversion'] = $d49041d5f05a9270['token'];
				$d49041d5f05a9270['cpu'] = $d49041d5f05a9270['lversion'];
				$d49041d5f05a9270['enigma_version'] = $d49041d5f05a9270['cpu'];
				$d49041d5f05a9270['modem_mac'] = $d49041d5f05a9270['enigma_version'];
				$d49041d5f05a9270['local_ip'] = $d49041d5f05a9270['modem_mac'];
			}

			$Bb1e97d0ea20bca0 = json_decode($a27e64cc6ce01033['devices_selected'], true);

			foreach ($Bb1e97d0ea20bca0 as $cdc93dae5ba3d206) {
				$Fdc8e0fc5edb3ca8 = Ba960Cab7FE0cD93($cdc93dae5ba3d206);

				if (!$Fdc8e0fc5edb3ca8) {
				} else {
					if (0 >= count($d49041d5f05a9270)) {
					} else {
						$acd0eb2c8a975903 = f4817Dc607D9981D($d49041d5f05a9270);

						if (0 >= count($acd0eb2c8a975903['data'])) {
						} else {
							$acd0eb2c8a975903['data'][] = $cdc93dae5ba3d206;
							$A6d7047f2fda966c = 'UPDATE `enigma2_devices` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `device_id` = ?;';
							self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
						}
					}

					if (0 >= count($C2cdb5dc50f13c15)) {
					} else {
						$b174976b99c4ec48 = array();

						if (!isset($Fdc8e0fc5edb3ca8['user']['id'])) {
						} else {
							$b174976b99c4ec48[] = $Fdc8e0fc5edb3ca8['user']['id'];
						}

						if (!isset($Fdc8e0fc5edb3ca8['user']['paired'])) {
						} else {
							$b174976b99c4ec48[] = $Fdc8e0fc5edb3ca8['paired']['id'];
						}

						foreach ($b174976b99c4ec48 as $D78ff1d0edade5eb) {
							$acd0eb2c8a975903 = f4817DC607D9981D($C2cdb5dc50f13c15);

							if (0 >= count($acd0eb2c8a975903['data'])) {
							} else {
								$acd0eb2c8a975903['data'][] = $D78ff1d0edade5eb;
								$A6d7047f2fda966c = 'UPDATE `lines` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` = ?;';
								self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
								XUI::bc77eDC4169F1BaA($D78ff1d0edade5eb);
							}
						}
					}
				}
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function cFa8a15c57DD64f2($a27e64cc6ce01033)
	{
		if (self::f228E3d146e758b1($a27e64cc6ce01033)) {
			$d49041d5f05a9270 = array();

			foreach (array('status') as $bb2621204e39e62d) {
				if (!isset($a27e64cc6ce01033['c_' . $bb2621204e39e62d])) {
				} else {
					if (isset($a27e64cc6ce01033[$bb2621204e39e62d])) {
						$d49041d5f05a9270[$bb2621204e39e62d] = 1;
					} else {
						$d49041d5f05a9270[$bb2621204e39e62d] = 0;
					}
				}
			}

			if (!isset($a27e64cc6ce01033['c_owner_id'])) {
			} else {
				$d49041d5f05a9270['owner_id'] = intval($a27e64cc6ce01033['owner_id']);
			}

			if (!isset($a27e64cc6ce01033['c_member_group_id'])) {
			} else {
				$d49041d5f05a9270['member_group_id'] = intval($a27e64cc6ce01033['member_group_id']);
			}

			if (!isset($a27e64cc6ce01033['c_reseller_dns'])) {
			} else {
				$d49041d5f05a9270['reseller_dns'] = $a27e64cc6ce01033['reseller_dns'];
			}

			if (!isset($a27e64cc6ce01033['c_override'])) {
			} else {
				$B4a5141c87d1c427 = array();

				foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $F17f20a56056dab3) {
					if (substr($D3fa098be3f297cd, 0, 9) != 'override_') {
					} else {
						$C3c8913edb801c35 = intval(explode('override_', $D3fa098be3f297cd)[1]);

						if (0 < strlen($F17f20a56056dab3)) {
							$F17f20a56056dab3 = intval($F17f20a56056dab3);
						} else {
							$F17f20a56056dab3 = null;
						}

						if (!$F17f20a56056dab3) {
						} else {
							$B4a5141c87d1c427[$C3c8913edb801c35] = array('assign' => 1, 'official_credits' => $F17f20a56056dab3);
						}
					}
				}
				$d49041d5f05a9270['override_packages'] = json_encode($B4a5141c87d1c427);
			}

			$B963b5d49ca08acf = confirmIDs(json_decode($a27e64cc6ce01033['users_selected'], true));

			if (0 >= count($B963b5d49ca08acf)) {
			} else {
				if (!(isset($a27e64cc6ce01033['c_owner_id']) && $d51e425eb7375255 == $d49041d5f05a9270['owner_id'])) {
				} else {
					unset($d49041d5f05a9270['owner_id']);
				}

				$acd0eb2c8a975903 = f4817DC607D9981d($d49041d5f05a9270);

				if (0 >= count($acd0eb2c8a975903['data'])) {
				} else {
					$A6d7047f2fda966c = 'UPDATE `users` SET ' . $acd0eb2c8a975903['update'] . ' WHERE `id` IN (' . implode(',', $B963b5d49ca08acf) . ');';
					self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
				}
			}

			return array('status' => STATUS_SUCCESS);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function D4CDF8772E0D536B($a27e64cc6ce01033)
	{
		if (self::F228e3D146E758B1($a27e64cc6ce01033)) {
			if (isset($a27e64cc6ce01033['edit'])) {
				if (AACd47d8157A1A09('adv', 'edit_user')) {
					$d49041d5f05a9270 = EBdaafc1C10F9506(B4036ef9a1DB8473($a27e64cc6ce01033['edit']), $a27e64cc6ce01033);
				} else {
					exit();
				}
			} else {
				if (aAcD47D8157A1a09('adv', 'add_user')) {
					$d49041d5f05a9270 = b9da5d708fC1C079('lines', $a27e64cc6ce01033);
					$d49041d5f05a9270['created_at'] = time();
					unset($d49041d5f05a9270['id']);
				} else {
					exit();
				}
			}

			if (strlen($a27e64cc6ce01033['username']) != 0) {
			} else {
				$d49041d5f05a9270['username'] = D7445b70978659bA(10);
			}

			if (strlen($a27e64cc6ce01033['password']) != 0) {
			} else {
				$d49041d5f05a9270['password'] = d7445b70978659BA(10);
			}

			foreach (array('max_connections', 'enabled', 'admin_enabled') as $Ba3157bbbca6db35) {
				if (isset($a27e64cc6ce01033[$Ba3157bbbca6db35])) {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = intval($a27e64cc6ce01033[$Ba3157bbbca6db35]);
				} else {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 1;
				}
			}

			foreach (array('is_stalker', 'is_restreamer', 'is_trial', 'is_isplock', 'bypass_ua') as $Ba3157bbbca6db35) {
				if (isset($a27e64cc6ce01033[$Ba3157bbbca6db35])) {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 1;
				} else {
					$d49041d5f05a9270[$Ba3157bbbca6db35] = 0;
				}
			}

			if (strlen($a27e64cc6ce01033['isp_clear']) != 0) {
			} else {
				$d49041d5f05a9270['isp_desc'] = '';
				$d49041d5f05a9270['as_number'] = null;
			}

			$d49041d5f05a9270['bouquet'] = sortArrayByArray(array_values(json_decode($a27e64cc6ce01033['bouquets_selected'], true)), array_keys(a53403fC10F556Be()));
			$d49041d5f05a9270['bouquet'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['bouquet'])) . ']';

			if (isset($a27e64cc6ce01033['exp_date']) && !isset($a27e64cc6ce01033['no_expire'])) {
				if (!(0 < strlen($a27e64cc6ce01033['exp_date']) && $a27e64cc6ce01033['exp_date'] != '1970-01-01')) {
				} else {
					try {
						$c94b497359f8aed9 = new DateTime($a27e64cc6ce01033['exp_date']);
						$d49041d5f05a9270['exp_date'] = $c94b497359f8aed9->format('U');
					} catch (Exception $c34ae71903f0d920) {
						return array('status' => STATUS_INVALID_DATE, 'data' => $a27e64cc6ce01033);
					}
				}
			} else {
				$d49041d5f05a9270['exp_date'] = null;
			}

			if ($d49041d5f05a9270['member_id']) {
			} else {
				$d49041d5f05a9270['member_id'] = self::$rUserInfo['id'];
			}

			if (isset($a27e64cc6ce01033['allowed_ips'])) {
				if (is_array($a27e64cc6ce01033['allowed_ips'])) {
				} else {
					$a27e64cc6ce01033['allowed_ips'] = array($a27e64cc6ce01033['allowed_ips']);
				}

				$d49041d5f05a9270['allowed_ips'] = json_encode($a27e64cc6ce01033['allowed_ips']);
			} else {
				$d49041d5f05a9270['allowed_ips'] = '[]';
			}

			if (isset($a27e64cc6ce01033['allowed_ua'])) {
				if (is_array($a27e64cc6ce01033['allowed_ua'])) {
				} else {
					$a27e64cc6ce01033['allowed_ua'] = array($a27e64cc6ce01033['allowed_ua']);
				}

				$d49041d5f05a9270['allowed_ua'] = json_encode($a27e64cc6ce01033['allowed_ua']);
			} else {
				$d49041d5f05a9270['allowed_ua'] = '[]';
			}

			$C5c92158885984fd = array();

			if (!isset($a27e64cc6ce01033['access_output'])) {
			} else {
				foreach ($a27e64cc6ce01033['access_output'] as $F3ba21e7eb72c779) {
					$C5c92158885984fd[] = $F3ba21e7eb72c779;
				}
			}

			$d49041d5f05a9270['allowed_outputs'] = '[' . implode(',', array_map('intval', $C5c92158885984fd)) . ']';

			if (!Aa5550E4a234cBE6('lines', 'username', $d49041d5f05a9270['username'], 'id', $a27e64cc6ce01033['edit'])) {
				$acd0eb2c8a975903 = F4817Dc607D9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					A85A61D6f165008a($Fc2dc5a0ce8d07ea);
					XUI::bC77eDc4169f1bAa($Fc2dc5a0ce8d07ea);

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_EXISTS_USERNAME, 'data' => $a27e64cc6ce01033);
		} else {
			return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
		}
	}

	public static function scheduleRecording($a27e64cc6ce01033)
	{
		if (self::F228e3D146E758b1($a27e64cc6ce01033)) {
			if (aAcd47D8157A1a09('adv', 'add_stream')) {
				if (!empty($a27e64cc6ce01033['title'])) {
					if (!empty($a27e64cc6ce01033['source_id'])) {
						$d49041d5f05a9270 = b9Da5d708fc1c079('recordings', $a27e64cc6ce01033);
						$d49041d5f05a9270['bouquets'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['bouquets'])) . ']';
						$d49041d5f05a9270['category_id'] = '[' . implode(',', array_map('intval', $a27e64cc6ce01033['category_id'])) . ']';
						$acd0eb2c8a975903 = F4817dc607d9981D($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `recordings`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
					}

					return array('status' => STATUS_NO_SOURCE);
				}

				return array('status' => STATUS_NO_TITLE);
			}

			exit();
		}

		return array('status' => STATUS_INVALID_INPUT, 'data' => $a27e64cc6ce01033);
	}
}
