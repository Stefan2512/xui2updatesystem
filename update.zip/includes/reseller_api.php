<?php

class ResellerAPI
{
	public static $db = null;
	public static $rSettings = array();
	public static $rServers = array();
	public static $rProxyServers = array();
	public static $rUserInfo = array();
	public static $rPermissions = array();

	public static function processData($E379394c7b1a273f, $a27e64cc6ce01033)
	{
		$d49041d5f05a9270 = array('line' => array('edit', 'trial', 'bouquets_selected', 'pair_id', 'username', 'password', 'member_id', 'package', 'contact', 'reseller_notes', 'allowed_ips', 'allowed_ua', 'bypass_ua', 'is_isplock', 'isp_clear'), 'mag' => array('edit', 'trial', 'bouquets_selected', 'pair_id', 'mac', 'member_id', 'package', 'parent_password', 'sn', 'stb_type', 'image_version', 'hw_version', 'device_id', 'device_id2', 'ver', 'reseller_notes', 'allowed_ips', 'is_isplock', 'isp_clear'), 'enigma' => array('edit', 'trial', 'bouquets_selected', 'pair_id', 'mac', 'member_id', 'package', 'modem_mac', 'local_ip', 'enigma_version', 'cpu', 'lversion', 'token', 'reseller_notes', 'allowed_ips', 'is_isplock', 'isp_clear'), 'user' => array('edit', 'username', 'password', 'owner_id', 'email', 'reseller_dns', 'notes', 'member_group_id'), 'ticket' => array('edit', 'message', 'title', 'respond'), 'profile' => array('email', 'password', 'api_key', 'reseller_dns', 'theme', 'hue', 'timezone'));

		foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
			if (in_array($D3fa098be3f297cd, $d49041d5f05a9270[$E379394c7b1a273f])) {
			} else {
				unset($a27e64cc6ce01033[$D3fa098be3f297cd]);
			}
		}

		return $a27e64cc6ce01033;
	}

	public static function init($D78ff1d0edade5eb = null)
	{
		self::$rSettings = a5fc308345057e29();
		self::$rServers = F6dA964066F2F5E4();
		self::$rProxyServers = A4338a704A6A7789();

		if ($D78ff1d0edade5eb || !isset($_SESSION['reseller'])) {
		} else {
			$D78ff1d0edade5eb = $_SESSION['reseller'];
		}

		if (!$D78ff1d0edade5eb) {
		} else {
			self::$rUserInfo = fe76c4bcaF81Baa4($D78ff1d0edade5eb);
			self::$rPermissions = array_merge((f0Acf9de3389b116(self::$rUserInfo['member_group_id']) ?: array()), (d29d7D4E98eA26da(self::$rUserInfo['id']) ?: array()));
		}
	}

	public static function be978F889C508681($a27e64cc6ce01033)
	{
		global $a0bf9d3bd74d9b1f;
		$a27e64cc6ce01033 = self::processData('profile', $a27e64cc6ce01033);

		if (0 >= strlen($a27e64cc6ce01033['email']) || filter_var($a27e64cc6ce01033['email'], FILTER_VALIDATE_EMAIL)) {
			if (0 < strlen($a27e64cc6ce01033['password'])) {
				if (!(strlen($a27e64cc6ce01033['password']) < intval(self::$rPermissions['minimum_password_length']) && 0 < intval(self::$rPermissions['minimum_password_length']))) {
					$d5249dad8e8411b7 = df65d36bEA77Ae8C($a27e64cc6ce01033['password']);
				} else {
					return array('status' => STATUS_INVALID_PASSWORD);
				}
			} else {
				$d5249dad8e8411b7 = self::$rUserInfo['password'];
			}

			if (ctype_xdigit($a27e64cc6ce01033['api_key']) && strlen($a27e64cc6ce01033['api_key']) == 32) {
			} else {
				$a27e64cc6ce01033['api_key'] = '';
			}

			if (in_array($a27e64cc6ce01033['hue'], $a0bf9d3bd74d9b1f)) {
			} else {
				$a27e64cc6ce01033['hue'] = '';
			}

			if (in_array($a27e64cc6ce01033['theme'], array(0, 1))) {
			} else {
				$a27e64cc6ce01033['theme'] = 0;
			}

			self::$db->query('UPDATE `users` SET `password` = ?, `email` = ?, `reseller_dns` = ?, `theme` = ?, `hue` = ?, `timezone` = ?, `api_key` = ? WHERE `id` = ?;', $d5249dad8e8411b7, $a27e64cc6ce01033['email'], $a27e64cc6ce01033['reseller_dns'], $a27e64cc6ce01033['theme'], $a27e64cc6ce01033['hue'], $a27e64cc6ce01033['timezone'], $a27e64cc6ce01033['api_key'], self::$rUserInfo['id']);

			return array('status' => STATUS_SUCCESS);
		}

		return array('status' => STATUS_INVALID_EMAIL);
	}

	public static function f2e77D2F6ce1E2eE($a27e64cc6ce01033)
	{
		if (!self::$rSettings['recaptcha_enable']) {
		} else {
			$c7488e8420e934e2 = json_decode(file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . self::$rSettings['recaptcha_v2_secret_key'] . '&response=' . $a27e64cc6ce01033['g-recaptcha-response']), true);

			if ($c7488e8420e934e2['success']) {
			} else {
				return array('status' => STATUS_INVALID_CAPTCHA);
			}
		}

		$c59ec257c284c894 = C7afd69edc2A2940();
		$D4253f9520627819 = d3f333592A08EB86($a27e64cc6ce01033['username'], $a27e64cc6ce01033['password']);
		$ef288259a1681f9b = E787d2298DBdA85D(true);

		if (isset($D4253f9520627819)) {
			if (in_array($D4253f9520627819['member_group_id'], json_decode($ef288259a1681f9b['groups'], true)) || count(b805779562E68625()) == 0) {
				$B2ff75c438fb3031 = F0Acf9de3389b116($D4253f9520627819['member_group_id']);

				if ($B2ff75c438fb3031['is_reseller']) {
					if ($D4253f9520627819['status'] == 1) {
						$a1f8ada60879ba62 = dF65D36BEa77aE8c($a27e64cc6ce01033['password']);

						if ($D4253f9520627819['password'] != $a1f8ada60879ba62) {
							self::$db->query('UPDATE `users` SET `password` = ?, `last_login` = UNIX_TIMESTAMP(), `ip` = ? WHERE `id` = ?;', $a1f8ada60879ba62, $c59ec257c284c894, $D4253f9520627819['id']);
						} else {
							self::$db->query('UPDATE `users` SET `last_login` = UNIX_TIMESTAMP(), `ip` = ? WHERE `id` = ?;', $c59ec257c284c894, $D4253f9520627819['id']);
						}

						$_SESSION['reseller'] = $D4253f9520627819['id'];
						$_SESSION['rip'] = $c59ec257c284c894;
						$_SESSION['rcode'] = E787d2298DBdA85d();
						$_SESSION['rverify'] = md5($D4253f9520627819['username'] . '||' . $a1f8ada60879ba62);

						if (!self::$rSettings['save_login_logs']) {
						} else {
							self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('RESELLER', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'SUCCESS', $c59ec257c284c894, time());
						}

						return array('status' => STATUS_SUCCESS);
					}

					if (!($B2ff75c438fb3031 && ($B2ff75c438fb3031['is_admin'] || $B2ff75c438fb3031['is_reseller']) && !$D4253f9520627819['status'])) {
					} else {
						if (!self::$rSettings['save_login_logs']) {
						} else {
							self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('RESELLER', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'DISABLED', $c59ec257c284c894, time());
						}

						return array('status' => STATUS_DISABLED);
					}
				} else {
					if (!self::$rSettings['save_login_logs']) {
					} else {
						self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('RESELLER', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'NOT_ADMIN', $c59ec257c284c894, time());
					}

					return array('status' => STATUS_NOT_RESELLER);
				}
			} else {
				if (!self::$rSettings['save_login_logs']) {
				} else {
					self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('RESELLER', ?, ?, ?, ?, ?);", $ef288259a1681f9b['id'], $D4253f9520627819['id'], 'INVALID_CODE', $c59ec257c284c894, time());
				}

				return array('status' => STATUS_INVALID_CODE);
			}
		} else {
			if (!self::$rSettings['save_login_logs']) {
			} else {
				self::$db->query("INSERT INTO `login_logs`(`type`, `access_code`, `user_id`, `status`, `login_ip`, `date`) VALUES('RESELLER', ?, 0, ?, ?, ?);", $ef288259a1681f9b['id'], 'INVALID_LOGIN', $c59ec257c284c894, time());
			}

			return array('status' => STATUS_FAILURE);
		}
	}

	public static function Eb9ead5B16D184F3($a27e64cc6ce01033)
	{
		$a27e64cc6ce01033 = self::processData('mag', $a27e64cc6ce01033);

		if (self::$rPermissions['create_mag']) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = Bfe9937c6d242A3d($a27e64cc6ce01033['edit']);

				if ($d49041d5f05a9270 && AAcd47D8157A1a09('line', $d49041d5f05a9270['user_id'])) {
					$C2cdb5dc50f13c15 = B4036ef9a1Db8473($d49041d5f05a9270['user_id']);
				} else {
					return false;
				}
			} else {
				$d49041d5f05a9270 = B9DA5D708FC1c079('mag_devices', $a27e64cc6ce01033);
				$d49041d5f05a9270['theme_type'] = self::$rSettings['mag_default_type'];
				$C2cdb5dc50f13c15 = b9DA5d708fc1C079('lines', $a27e64cc6ce01033);
				$C2cdb5dc50f13c15['username'] = D7445B70978659Ba(32);
				$C2cdb5dc50f13c15['password'] = D7445b70978659Ba(32);
				$C2cdb5dc50f13c15['created_at'] = time();
				unset($d49041d5f05a9270['mag_id'], $C2cdb5dc50f13c15['id']);
			}

			$C2cdb5dc50f13c15['is_mag'] = 1;
			$C2cdb5dc50f13c15['is_e2'] = 0;
			$f4281667b3862fbd = A820b9E9F53E0924(self::$rUserInfo['id']);

			if (!empty($a27e64cc6ce01033['package'])) {
				$fe06d74291ffa213 = F0ACab09E248Fc13($a27e64cc6ce01033['package']);

				if ($fe06d74291ffa213['is_mag']) {
					if (0 < intval($C2cdb5dc50f13c15['package_id']) && $fe06d74291ffa213['check_compatible']) {
						$f03f005ea6f01679 = c26e8c91D782C235($C2cdb5dc50f13c15['package_id'], $fe06d74291ffa213['id']);
					} else {
						$f03f005ea6f01679 = true;
					}

					if ($fe06d74291ffa213 && in_array(self::$rUserInfo['member_group_id'], json_decode($fe06d74291ffa213['groups'], true))) {
						if ($a27e64cc6ce01033['trial']) {
							if ($f4281667b3862fbd) {
								$Dd1c42dae240b328 = intval($fe06d74291ffa213['trial_credits']);
							} else {
								return array('status' => STATUS_NO_TRIALS, 'data' => $a27e64cc6ce01033);
							}
						} else {
							$B4a5141c87d1c427 = json_decode(self::$rUserInfo['override_packages'], true);

							if (isset($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']) && 0 < strlen($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits'])) {
								$Dd1c42dae240b328 = intval($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']);
							} else {
								$Dd1c42dae240b328 = intval($fe06d74291ffa213['official_credits']);
							}
						}

						if ($Dd1c42dae240b328 <= intval(self::$rUserInfo['credits'])) {
							if ($a27e64cc6ce01033['trial']) {
								$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['trial_duration']) . ' ' . $fe06d74291ffa213['trial_duration_in']);
								$C2cdb5dc50f13c15['is_trial'] = 1;
							} else {
								if (isset($C2cdb5dc50f13c15['id']) && $f03f005ea6f01679) {
									if (time() <= $C2cdb5dc50f13c15['exp_date']) {
										$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in'], intval($C2cdb5dc50f13c15['exp_date']));
									} else {
										$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in']);
									}
								} else {
									$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in']);
								}

								$C2cdb5dc50f13c15['is_trial'] = 0;
							}

							$cb498e4dcaac05cc = array_values(json_decode($fe06d74291ffa213['bouquets'], true));

							if (!(self::$rPermissions['allow_change_bouquets'] && 0 < count($a27e64cc6ce01033['bouquets_selected']))) {
							} else {
								$E6c91886bd30f7b9 = array();

								foreach ($a27e64cc6ce01033['bouquets_selected'] as $C52c0b6b0f74407b) {
									if (!in_array($C52c0b6b0f74407b, $cb498e4dcaac05cc)) {
									} else {
										$E6c91886bd30f7b9[] = $C52c0b6b0f74407b;
									}
								}

								if (0 >= count($E6c91886bd30f7b9)) {
								} else {
									$cb498e4dcaac05cc = $E6c91886bd30f7b9;
								}
							}

							$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray($cb498e4dcaac05cc, array_keys(a53403fC10f556BE()));
							$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';
							$C2cdb5dc50f13c15['max_connections'] = $fe06d74291ffa213['max_connections'];
							$C2cdb5dc50f13c15['is_restreamer'] = $fe06d74291ffa213['is_restreamer'];
							$C2cdb5dc50f13c15['force_server_id'] = $fe06d74291ffa213['force_server_id'];
							$C2cdb5dc50f13c15['forced_country'] = $fe06d74291ffa213['forced_country'];
							$C2cdb5dc50f13c15['is_isplock'] = $fe06d74291ffa213['is_isplock'];
							$C5c92158885984fd = array();
							$b35f92c785c60f5c = json_decode($fe06d74291ffa213['output_formats'], true);

							foreach ($b35f92c785c60f5c as $F3ba21e7eb72c779) {
								$C5c92158885984fd[] = $F3ba21e7eb72c779;
							}
							$C2cdb5dc50f13c15['allowed_outputs'] = '[' . implode(',', array_map('intval', $C5c92158885984fd)) . ']';
							$C2cdb5dc50f13c15['package_id'] = $fe06d74291ffa213['id'];
							$d49041d5f05a9270['lock_device'] = $fe06d74291ffa213['lock_device'];
						} else {
							return array('status' => STATUS_INSUFFICIENT_CREDITS, 'data' => $a27e64cc6ce01033);
						}
					} else {
						return array('status' => STATUS_INVALID_PACKAGE, 'data' => $a27e64cc6ce01033);
					}
				} else {
					return array('status' => STATUS_INVALID_TYPE, 'data' => $a27e64cc6ce01033);
				}
			} else {
				if (!isset($C2cdb5dc50f13c15['id'])) {
					return array('status' => STATUS_INVALID_PACKAGE, 'data' => $a27e64cc6ce01033);
				}

				if (!(isset($a27e64cc6ce01033['edit']) && $C2cdb5dc50f13c15['package_id'])) {
				} else {
					$fe06d74291ffa213 = f0ACAB09e248fC13($C2cdb5dc50f13c15['package_id']);
					$cb498e4dcaac05cc = array_values(json_decode($fe06d74291ffa213['bouquets'], true));

					if (!(self::$rPermissions['allow_change_bouquets'] && 0 < count($a27e64cc6ce01033['bouquets_selected']))) {
					} else {
						$E6c91886bd30f7b9 = array();

						foreach ($a27e64cc6ce01033['bouquets_selected'] as $C52c0b6b0f74407b) {
							if (!in_array($C52c0b6b0f74407b, $cb498e4dcaac05cc)) {
							} else {
								$E6c91886bd30f7b9[] = $C52c0b6b0f74407b;
							}
						}

						if (0 >= count($E6c91886bd30f7b9)) {
						} else {
							$cb498e4dcaac05cc = $E6c91886bd30f7b9;
						}
					}

					$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray($cb498e4dcaac05cc, array_keys(a53403FC10F556Be()));
					$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';
				}
			}

			foreach (array('parent_password', 'sn', 'stb_type', 'image_version', 'hw_version', 'device_id', 'device_id2', 'ver') as $D3fa098be3f297cd) {
				$d49041d5f05a9270[$D3fa098be3f297cd] = $a27e64cc6ce01033[$D3fa098be3f297cd];
			}
			$C2cdb5dc50f13c15['reseller_notes'] = $a27e64cc6ce01033['reseller_notes'];
			$Dbb9e190755fc819 = $a27e64cc6ce01033['member_id'];

			if (aaCD47d8157A1A09('user', $Dbb9e190755fc819)) {
				$C2cdb5dc50f13c15['member_id'] = $Dbb9e190755fc819;
			} else {
				$C2cdb5dc50f13c15['member_id'] = self::$rUserInfo['id'];
			}

			if (!self::$rPermissions['allow_restrictions']) {
			} else {
				if (isset($a27e64cc6ce01033['allowed_ips'])) {
					if (is_array($a27e64cc6ce01033['allowed_ips'])) {
					} else {
						$a27e64cc6ce01033['allowed_ips'] = array($a27e64cc6ce01033['allowed_ips']);
					}

					$C2cdb5dc50f13c15['allowed_ips'] = json_encode($a27e64cc6ce01033['allowed_ips']);
				} else {
					$C2cdb5dc50f13c15['allowed_ips'] = '[]';
				}

				if (isset($a27e64cc6ce01033['is_isplock'])) {
					$C2cdb5dc50f13c15['is_isplock'] = 1;
				} else {
					$C2cdb5dc50f13c15['is_isplock'] = 0;
				}

				if (strlen($a27e64cc6ce01033['isp_clear']) != 0) {
				} else {
					$C2cdb5dc50f13c15['isp_desc'] = '';
					$C2cdb5dc50f13c15['as_number'] = null;
				}
			}

			if (filter_var($a27e64cc6ce01033['mac'], FILTER_VALIDATE_MAC)) {
				if (isset($a27e64cc6ce01033['edit'])) {
					self::$db->query('SELECT `mag_id` FROM `mag_devices` WHERE mac = ? AND `mag_id` <> ? LIMIT 1;', $d49041d5f05a9270['mac'], $a27e64cc6ce01033['edit']);
				} else {
					self::$db->query('SELECT `mag_id` FROM `mag_devices` WHERE mac = ? LIMIT 1;', $d49041d5f05a9270['mac']);
				}

				if (0 >= self::$db->num_rows()) {
					$d49041d5f05a9270['mac'] = $a27e64cc6ce01033['mac'];

					if (isset($a27e64cc6ce01033['pair_id']) && aAcd47D8157a1a09('line', $a27e64cc6ce01033['pair_id'])) {
						$C2cdb5dc50f13c15['pair_id'] = intval($a27e64cc6ce01033['pair_id']);
					} else {
						$C2cdb5dc50f13c15['pair_id'] = null;
					}

					$acd0eb2c8a975903 = f4817Dc607d9981d($C2cdb5dc50f13c15);
					$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					} else {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
						a85a61D6F165008a($Fc2dc5a0ce8d07ea);
						self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', SERVER_ID, time(), json_encode(array('type' => 'update_line', 'id' => $Fc2dc5a0ce8d07ea)));
						$d49041d5f05a9270['user_id'] = $Fc2dc5a0ce8d07ea;
						unset($d49041d5f05a9270['user'], $d49041d5f05a9270['paired']);

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							$d49041d5f05a9270['ver'] = '';
							$d49041d5f05a9270['device_id2'] = $d49041d5f05a9270['ver'];
							$d49041d5f05a9270['device_id'] = $d49041d5f05a9270['device_id2'];
							$d49041d5f05a9270['hw_version'] = $d49041d5f05a9270['device_id'];
							$d49041d5f05a9270['stb_type'] = $d49041d5f05a9270['hw_version'];
							$d49041d5f05a9270['image_version'] = $d49041d5f05a9270['stb_type'];
							$d49041d5f05a9270['sn'] = $d49041d5f05a9270['image_version'];
						}

						$acd0eb2c8a975903 = f4817dC607D9981d($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `mag_devices`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

							if (isset($fe06d74291ffa213)) {
								$Bf75a78bd3a0711d = intval(self::$rUserInfo['credits']) - intval($Dd1c42dae240b328);
								self::$db->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $Bf75a78bd3a0711d, self::$rUserInfo['id']);

								if (isset($d49041d5f05a9270['id'])) {
									if ($C2cdb5dc50f13c15['package_id']) {
										$E379394c7b1a273f = 'extend';
									} else {
										$E379394c7b1a273f = 'edit';
									}
								} else {
									$E379394c7b1a273f = 'new';
								}

								$a27e64cc6ce01033 = bfE9937C6d242a3D($Fc2dc5a0ce8d07ea);
								self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'mag', ?, ?, ?, ?, ?, ?, ?);", self::$rUserInfo['id'], $E379394c7b1a273f, $Fc2dc5a0ce8d07ea, $fe06d74291ffa213['id'], $Dd1c42dae240b328, $Bf75a78bd3a0711d, time(), json_encode($a27e64cc6ce01033));
							} else {
								self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'mag', ?, ?, null, ?, ?, ?, ?);", self::$rUserInfo['id'], 'edit', $Fc2dc5a0ce8d07ea, 0, self::$rUserInfo['credits'], time(), json_encode($a27e64cc6ce01033));
							}

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							self::$db->query('DELETE FROM `lines` WHERE `id` = ?;', $Fc2dc5a0ce8d07ea);
						}
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_EXISTS_MAC, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_MAC, 'data' => $a27e64cc6ce01033);
		} else {
			return false;
		}
	}

	public static function Ecaf66b237906519($a27e64cc6ce01033)
	{
		$a27e64cc6ce01033 = self::processData('enigma', $a27e64cc6ce01033);

		if (self::$rPermissions['create_enigma']) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = BA960cab7fE0CD93($a27e64cc6ce01033['edit']);

				if ($d49041d5f05a9270 && AacD47d8157a1a09('line', $d49041d5f05a9270['user_id'])) {
					$C2cdb5dc50f13c15 = B4036EF9A1DB8473($d49041d5f05a9270['user_id']);
				} else {
					return false;
				}
			} else {
				$d49041d5f05a9270 = B9dA5d708FC1C079('enigma2_devices', $a27e64cc6ce01033);
				$C2cdb5dc50f13c15 = B9da5d708FC1c079('lines', $a27e64cc6ce01033);
				$C2cdb5dc50f13c15['username'] = d7445B70978659BA(32);
				$C2cdb5dc50f13c15['password'] = d7445b70978659Ba(32);
				$C2cdb5dc50f13c15['created_at'] = time();
				unset($d49041d5f05a9270['device_id'], $C2cdb5dc50f13c15['id']);
			}

			$C2cdb5dc50f13c15['is_mag'] = 0;
			$C2cdb5dc50f13c15['is_e2'] = 1;
			$f4281667b3862fbd = A820B9e9F53E0924(self::$rUserInfo['id']);

			if (!empty($a27e64cc6ce01033['package'])) {
				$fe06d74291ffa213 = f0ACab09E248FC13($a27e64cc6ce01033['package']);

				if ($fe06d74291ffa213['is_e2']) {
					if (0 < intval($C2cdb5dc50f13c15['package_id']) && $fe06d74291ffa213['check_compatible']) {
						$f03f005ea6f01679 = C26E8c91D782c235($C2cdb5dc50f13c15['package_id'], $fe06d74291ffa213['id']);
					} else {
						$f03f005ea6f01679 = true;
					}

					if ($fe06d74291ffa213 && in_array(self::$rUserInfo['member_group_id'], json_decode($fe06d74291ffa213['groups'], true))) {
						if ($a27e64cc6ce01033['trial']) {
							if ($f4281667b3862fbd) {
								$Dd1c42dae240b328 = intval($fe06d74291ffa213['trial_credits']);
							} else {
								return array('status' => STATUS_NO_TRIALS, 'data' => $a27e64cc6ce01033);
							}
						} else {
							$B4a5141c87d1c427 = json_decode(self::$rUserInfo['override_packages'], true);

							if (isset($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']) && 0 < strlen($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits'])) {
								$Dd1c42dae240b328 = intval($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']);
							} else {
								$Dd1c42dae240b328 = intval($fe06d74291ffa213['official_credits']);
							}
						}

						if ($Dd1c42dae240b328 <= intval(self::$rUserInfo['credits'])) {
							if ($a27e64cc6ce01033['trial']) {
								$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['trial_duration']) . ' ' . $fe06d74291ffa213['trial_duration_in']);
								$C2cdb5dc50f13c15['is_trial'] = 1;
							} else {
								if (isset($C2cdb5dc50f13c15['id']) && $f03f005ea6f01679) {
									if (time() <= $C2cdb5dc50f13c15['exp_date']) {
										$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in'], intval($C2cdb5dc50f13c15['exp_date']));
									} else {
										$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in']);
									}
								} else {
									$C2cdb5dc50f13c15['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in']);
								}

								$C2cdb5dc50f13c15['is_trial'] = 0;
							}

							$cb498e4dcaac05cc = array_values(json_decode($fe06d74291ffa213['bouquets'], true));

							if (!(self::$rPermissions['allow_change_bouquets'] && 0 < count($a27e64cc6ce01033['bouquets_selected']))) {
							} else {
								$E6c91886bd30f7b9 = array();

								foreach ($a27e64cc6ce01033['bouquets_selected'] as $C52c0b6b0f74407b) {
									if (!in_array($C52c0b6b0f74407b, $cb498e4dcaac05cc)) {
									} else {
										$E6c91886bd30f7b9[] = $C52c0b6b0f74407b;
									}
								}

								if (0 >= count($E6c91886bd30f7b9)) {
								} else {
									$cb498e4dcaac05cc = $E6c91886bd30f7b9;
								}
							}

							$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray($cb498e4dcaac05cc, array_keys(a53403Fc10f556Be()));
							$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';
							$C2cdb5dc50f13c15['max_connections'] = $fe06d74291ffa213['max_connections'];
							$C2cdb5dc50f13c15['is_restreamer'] = $fe06d74291ffa213['is_restreamer'];
							$C2cdb5dc50f13c15['force_server_id'] = $fe06d74291ffa213['force_server_id'];
							$C2cdb5dc50f13c15['forced_country'] = $fe06d74291ffa213['forced_country'];
							$C2cdb5dc50f13c15['is_isplock'] = $fe06d74291ffa213['is_isplock'];
							$C5c92158885984fd = array();
							$b35f92c785c60f5c = json_decode($fe06d74291ffa213['output_formats'], true);

							foreach ($b35f92c785c60f5c as $F3ba21e7eb72c779) {
								$C5c92158885984fd[] = $F3ba21e7eb72c779;
							}
							$C2cdb5dc50f13c15['allowed_outputs'] = '[' . implode(',', array_map('intval', $C5c92158885984fd)) . ']';
							$C2cdb5dc50f13c15['package_id'] = $fe06d74291ffa213['id'];
							$d49041d5f05a9270['lock_device'] = $fe06d74291ffa213['lock_device'];
						} else {
							return array('status' => STATUS_INSUFFICIENT_CREDITS, 'data' => $a27e64cc6ce01033);
						}
					} else {
						return array('status' => STATUS_INVALID_PACKAGE, 'data' => $a27e64cc6ce01033);
					}
				} else {
					return array('status' => STATUS_INVALID_TYPE, 'data' => $a27e64cc6ce01033);
				}
			} else {
				if (!isset($C2cdb5dc50f13c15['id'])) {
					return array('status' => STATUS_INVALID_PACKAGE, 'data' => $a27e64cc6ce01033);
				}

				if (!(isset($a27e64cc6ce01033['edit']) && $C2cdb5dc50f13c15['package_id'])) {
				} else {
					$fe06d74291ffa213 = F0acAB09E248FC13($C2cdb5dc50f13c15['package_id']);
					$cb498e4dcaac05cc = array_values(json_decode($fe06d74291ffa213['bouquets'], true));

					if (!(self::$rPermissions['allow_change_bouquets'] && 0 < count($a27e64cc6ce01033['bouquets_selected']))) {
					} else {
						$E6c91886bd30f7b9 = array();

						foreach ($a27e64cc6ce01033['bouquets_selected'] as $C52c0b6b0f74407b) {
							if (!in_array($C52c0b6b0f74407b, $cb498e4dcaac05cc)) {
							} else {
								$E6c91886bd30f7b9[] = $C52c0b6b0f74407b;
							}
						}

						if (0 >= count($E6c91886bd30f7b9)) {
						} else {
							$cb498e4dcaac05cc = $E6c91886bd30f7b9;
						}
					}

					$C2cdb5dc50f13c15['bouquet'] = sortArrayByArray($cb498e4dcaac05cc, array_keys(A53403fC10F556Be()));
					$C2cdb5dc50f13c15['bouquet'] = '[' . implode(',', array_map('intval', $C2cdb5dc50f13c15['bouquet'])) . ']';
				}
			}

			foreach (array('modem_mac', 'local_ip', 'enigma_version', 'cpu', 'lversion', 'token') as $D3fa098be3f297cd) {
				$d49041d5f05a9270[$D3fa098be3f297cd] = $a27e64cc6ce01033[$D3fa098be3f297cd];
			}
			$C2cdb5dc50f13c15['reseller_notes'] = $a27e64cc6ce01033['reseller_notes'];
			$Dbb9e190755fc819 = $a27e64cc6ce01033['member_id'];

			if (Aacd47D8157a1A09('user', $Dbb9e190755fc819)) {
				$C2cdb5dc50f13c15['member_id'] = $Dbb9e190755fc819;
			} else {
				$C2cdb5dc50f13c15['member_id'] = self::$rUserInfo['id'];
			}

			if (!self::$rPermissions['allow_restrictions']) {
			} else {
				if (isset($a27e64cc6ce01033['allowed_ips'])) {
					if (is_array($a27e64cc6ce01033['allowed_ips'])) {
					} else {
						$a27e64cc6ce01033['allowed_ips'] = array($a27e64cc6ce01033['allowed_ips']);
					}

					$C2cdb5dc50f13c15['allowed_ips'] = json_encode($a27e64cc6ce01033['allowed_ips']);
				} else {
					$C2cdb5dc50f13c15['allowed_ips'] = '[]';
				}

				if (isset($a27e64cc6ce01033['is_isplock'])) {
					$C2cdb5dc50f13c15['is_isplock'] = 1;
				} else {
					$C2cdb5dc50f13c15['is_isplock'] = 0;
				}

				if (strlen($a27e64cc6ce01033['isp_clear']) != 0) {
				} else {
					$C2cdb5dc50f13c15['isp_desc'] = '';
					$C2cdb5dc50f13c15['as_number'] = null;
				}
			}

			if (filter_var($a27e64cc6ce01033['mac'], FILTER_VALIDATE_MAC)) {
				if (isset($a27e64cc6ce01033['edit'])) {
					self::$db->query('SELECT `device_id` FROM `enigma2_devices` WHERE mac = ? AND `device_id` <> ? LIMIT 1;', $d49041d5f05a9270['mac'], $a27e64cc6ce01033['edit']);
				} else {
					self::$db->query('SELECT `device_id` FROM `enigma2_devices` WHERE mac = ? LIMIT 1;', $d49041d5f05a9270['mac']);
				}

				if (0 >= self::$db->num_rows()) {
					$d49041d5f05a9270['mac'] = $a27e64cc6ce01033['mac'];

					if (isset($a27e64cc6ce01033['pair_id']) && aACd47d8157a1A09('line', $a27e64cc6ce01033['pair_id'])) {
						$C2cdb5dc50f13c15['pair_id'] = intval($a27e64cc6ce01033['pair_id']);
					} else {
						$C2cdb5dc50f13c15['pair_id'] = null;
					}

					$acd0eb2c8a975903 = F4817Dc607D9981D($C2cdb5dc50f13c15);
					$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

					if (!self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					} else {
						$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
						A85a61d6f165008a($Fc2dc5a0ce8d07ea);
						self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', SERVER_ID, time(), json_encode(array('type' => 'update_line', 'id' => $Fc2dc5a0ce8d07ea)));
						$d49041d5f05a9270['user_id'] = $Fc2dc5a0ce8d07ea;
						unset($d49041d5f05a9270['user'], $d49041d5f05a9270['paired']);

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							$d49041d5f05a9270['token'] = '';
							$d49041d5f05a9270['lversion'] = $d49041d5f05a9270['token'];
							$d49041d5f05a9270['cpu'] = $d49041d5f05a9270['lversion'];
							$d49041d5f05a9270['enigma_version'] = $d49041d5f05a9270['cpu'];
							$d49041d5f05a9270['local_ip'] = $d49041d5f05a9270['enigma_version'];
							$d49041d5f05a9270['modem_mac'] = $d49041d5f05a9270['local_ip'];
						}

						$acd0eb2c8a975903 = f4817dc607d9981D($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `enigma2_devices`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();

							if (isset($fe06d74291ffa213)) {
								$Bf75a78bd3a0711d = intval(self::$rUserInfo['credits']) - intval($Dd1c42dae240b328);
								self::$db->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $Bf75a78bd3a0711d, self::$rUserInfo['id']);

								if (isset($d49041d5f05a9270['id'])) {
									if ($d49041d5f05a9270['package_id']) {
										$E379394c7b1a273f = 'extend';
									} else {
										$E379394c7b1a273f = 'edit';
									}
								} else {
									$E379394c7b1a273f = 'new';
								}

								$a27e64cc6ce01033 = ba960CAB7fe0CD93($Fc2dc5a0ce8d07ea);
								self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'enigma', ?, ?, ?, ?, ?, ?, ?);", self::$rUserInfo['id'], $E379394c7b1a273f, $Fc2dc5a0ce8d07ea, $fe06d74291ffa213['id'], $Dd1c42dae240b328, $Bf75a78bd3a0711d, time(), json_encode($a27e64cc6ce01033));
							} else {
								self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'enigma', ?, ?, null, ?, ?, ?, ?);", self::$rUserInfo['id'], 'edit', $Fc2dc5a0ce8d07ea, 0, self::$rUserInfo['credits'], time(), json_encode($a27e64cc6ce01033));
							}

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							self::$db->query('DELETE FROM `lines` WHERE `id` = ?;', $Fc2dc5a0ce8d07ea);
						}
					}

					return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_EXISTS_MAC, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_MAC, 'data' => $a27e64cc6ce01033);
		} else {
			return false;
		}
	}

	public static function e8eBe0d3E389584e($a27e64cc6ce01033)
	{
		$a27e64cc6ce01033 = self::processData('user', $a27e64cc6ce01033);

		if (self::$rPermissions['create_sub_resellers']) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = fE76c4bCaF81BaA4($a27e64cc6ce01033['edit']);

				if ($d49041d5f05a9270 && AAcd47d8157a1a09('user', $d49041d5f05a9270['id'])) {
					if ($d49041d5f05a9270['id'] != self::$rUserInfo['id']) {
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				$d49041d5f05a9270 = B9dA5D708Fc1C079('users', $a27e64cc6ce01033);
				$d49041d5f05a9270['date_registered'] = time();
				unset($d49041d5f05a9270['id']);
			}

			if (self::$rPermissions['allow_change_username']) {
			} else {
				if (isset($d49041d5f05a9270['id'])) {
					$a27e64cc6ce01033['username'] = $d49041d5f05a9270['username'];
				} else {
					$a27e64cc6ce01033['username'] = D7445b70978659ba((10 < self::$rPermissions['minimum_username_length'] ? self::$rPermissions['minimum_username_length'] : 10));
				}
			}

			if (self::$rPermissions['allow_change_password']) {
			} else {
				if (isset($d49041d5f05a9270['id'])) {
					$a27e64cc6ce01033['password'] = '';
				} else {
					$a27e64cc6ce01033['password'] = D7445B70978659ba((10 < self::$rPermissions['minimum_password_length'] ? self::$rPermissions['minimum_password_length'] : 10));
				}
			}

			if (strlen($a27e64cc6ce01033['username']) >= self::$rPermissions['minimum_username_length'] || (isset($a27e64cc6ce01033['edit']) && strlen($a27e64cc6ce01033['username']) == 0)) {
				if (strlen($a27e64cc6ce01033['password']) >= self::$rPermissions['minimum_password_length'] || (isset($a27e64cc6ce01033['edit']) && strlen($a27e64cc6ce01033['password']) == 0)) {
					if (!Aa5550e4a234cBE6('users', 'username', $d49041d5f05a9270['username'], 'id', $a27e64cc6ce01033['edit'])) {
						$d49041d5f05a9270['username'] = $a27e64cc6ce01033['username'];

						if (0 >= strlen($a27e64cc6ce01033['password'])) {
						} else {
							$d49041d5f05a9270['password'] = Df65d36bEA77ae8c($a27e64cc6ce01033['password']);
						}

						if (0 < count(self::$rPermissions['all_reports']) && in_array(intval($a27e64cc6ce01033['owner_id']), self::$rPermissions['all_reports']) && (!isset($d49041d5f05a9270['id']) || $d49041d5f05a9270['id'] != $a27e64cc6ce01033['owner_id'])) {
							$d49041d5f05a9270['owner_id'] = intval($a27e64cc6ce01033['owner_id']);
						} else {
							$d49041d5f05a9270['owner_id'] = self::$rUserInfo['id'];
						}

						if (isset($a27e64cc6ce01033['edit'])) {
						} else {
							$Dd1c42dae240b328 = intval(self::$rPermissions['create_sub_resellers_price']);

							if (self::$rUserInfo['credits'] - $Dd1c42dae240b328 >= 0) {
							} else {
								return array('status' => STATUS_INSUFFICIENT_CREDITS, 'data' => $a27e64cc6ce01033);
							}
						}

						if (isset($a27e64cc6ce01033['member_group_id']) && in_array($a27e64cc6ce01033['member_group_id'], self::$rPermissions['subresellers'])) {
							$d49041d5f05a9270['member_group_id'] = $a27e64cc6ce01033['member_group_id'];
						} else {
							if (0 < count(self::$rPermissions['subresellers'])) {
								$d49041d5f05a9270['member_group_id'] = self::$rPermissions['subresellers'][0];
							} else {
								return array('status' => STATUS_INVALID_SUBRESELLER, 'data' => $a27e64cc6ce01033);
							}
						}

						$d49041d5f05a9270['email'] = $a27e64cc6ce01033['email'];
						$d49041d5f05a9270['reseller_dns'] = $a27e64cc6ce01033['reseller_dns'];
						$d49041d5f05a9270['notes'] = $a27e64cc6ce01033['notes'];
						$acd0eb2c8a975903 = F4817Dc607d9981d($d49041d5f05a9270);
						$A6d7047f2fda966c = 'REPLACE INTO `users`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

						if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
							$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
							$a27e64cc6ce01033 = fe76C4BCAF81BAa4($Fc2dc5a0ce8d07ea);

							if (isset($Dd1c42dae240b328)) {
								$Bf75a78bd3a0711d = intval(self::$rUserInfo['credits']) - intval($Dd1c42dae240b328);
								self::$db->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $Bf75a78bd3a0711d, self::$rUserInfo['id']);
								self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'user', ?, ?, null, ?, ?, ?, ?);", self::$rUserInfo['id'], 'new', $Fc2dc5a0ce8d07ea, $Dd1c42dae240b328, $Bf75a78bd3a0711d, time(), json_encode($a27e64cc6ce01033));
							} else {
								self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'user', ?, ?, null, ?, ?, ?, ?);", self::$rUserInfo['id'], 'edit', $Fc2dc5a0ce8d07ea, 0, self::$rUserInfo['credits'], time(), json_encode($a27e64cc6ce01033));
							}

							return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
						}

						return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
					}

					return array('status' => STATUS_EXISTS_USERNAME, 'data' => $a27e64cc6ce01033);
				}

				return array('status' => STATUS_INVALID_PASSWORD, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_INVALID_USERNAME, 'data' => $a27e64cc6ce01033);
		}

		return false;
	}

	public static function Ae1c2E59b87c9b1B($a27e64cc6ce01033)
	{
		$a27e64cc6ce01033 = self::processData('ticket', $a27e64cc6ce01033);

		if (isset($a27e64cc6ce01033['edit'])) {
			$d49041d5f05a9270 = D42eDD31C6Ef0655($a27e64cc6ce01033['edit']);

			if ($d49041d5f05a9270 && aAcD47d8157a1a09('user', $d49041d5f05a9270['member_id'])) {
			} else {
				return false;
			}
		} else {
			$d49041d5f05a9270 = b9da5D708FC1c079('tickets', $a27e64cc6ce01033);
			unset($d49041d5f05a9270['id']);
		}

		if (!(strlen($a27e64cc6ce01033['title']) == 0 && !isset($a27e64cc6ce01033['respond']) || strlen($a27e64cc6ce01033['message']) == 0)) {
			$d49041d5f05a9270['member_id'] = self::$rUserInfo['id'];

			if (!isset($a27e64cc6ce01033['respond'])) {
				$d49041d5f05a9270['title'] = $a27e64cc6ce01033['title'];
				$d49041d5f05a9270['status'] = 1;
				$d49041d5f05a9270['admin_read'] = 0;
				$d49041d5f05a9270['user_read'] = 0;
				$acd0eb2c8a975903 = F4817Dc607D9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `tickets`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					self::$db->query('INSERT INTO `tickets_replies`(`ticket_id`, `admin_reply`, `message`, `date`) VALUES(?, 0, ?, ?);', $Fc2dc5a0ce8d07ea, $a27e64cc6ce01033['message'], time());

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			$Fc045a436f741403 = D42Edd31c6ef0655($a27e64cc6ce01033['respond']);

			if ($Fc045a436f741403) {
				if (intval(self::$rUserInfo['id']) == intval($Fc045a436f741403['member_id'])) {
					self::$db->query('UPDATE `tickets` SET `admin_read` = 0, `user_read` = 1 WHERE `id` = ?;', $a27e64cc6ce01033['respond']);
					self::$db->query('INSERT INTO `tickets_replies`(`ticket_id`, `admin_reply`, `message`, `date`) VALUES(?, 0, ?, ?);', $a27e64cc6ce01033['respond'], $a27e64cc6ce01033['message'], time());
				} else {
					self::$db->query('UPDATE `tickets` SET `admin_read` = 0, `user_read` = 0 WHERE `id` = ?;', $a27e64cc6ce01033['respond']);
					self::$db->query('INSERT INTO `tickets_replies`(`ticket_id`, `admin_reply`, `message`, `date`) VALUES(?, 1, ?, ?);', $a27e64cc6ce01033['respond'], $a27e64cc6ce01033['message'], time());
				}

				return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $a27e64cc6ce01033['respond']));
			}

			return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
		}

		return array('status' => STATUS_INVALID_DATA, 'data' => $a27e64cc6ce01033);
	}

	public static function d4cDF8772e0d536b($a27e64cc6ce01033)
	{
		$a27e64cc6ce01033 = self::processData('line', $a27e64cc6ce01033);

		if (self::$rPermissions['create_line']) {
			if (isset($a27e64cc6ce01033['edit'])) {
				$d49041d5f05a9270 = b4036EF9A1db8473($a27e64cc6ce01033['edit']);
				$Cde547a7a347dc5c = array('username' => $d49041d5f05a9270['username'], 'password' => $d49041d5f05a9270['password']);

				if ($d49041d5f05a9270 && AacD47d8157a1a09('line', $d49041d5f05a9270['id'])) {
				} else {
					return false;
				}
			} else {
				$d49041d5f05a9270 = B9dA5d708fC1c079('lines', $a27e64cc6ce01033);
				$d49041d5f05a9270['created_at'] = time();
				unset($d49041d5f05a9270['id']);
			}

			$d49041d5f05a9270['is_mag'] = 0;
			$d49041d5f05a9270['is_e2'] = 0;
			$f4281667b3862fbd = A820B9e9F53E0924(self::$rUserInfo['id']);

			if (!empty($a27e64cc6ce01033['package'])) {
				$fe06d74291ffa213 = F0AcAb09e248Fc13($a27e64cc6ce01033['package']);

				if ($fe06d74291ffa213['is_line']) {
					if (0 < intval($d49041d5f05a9270['package_id']) && $fe06d74291ffa213['check_compatible']) {
						$f03f005ea6f01679 = C26E8C91d782c235($d49041d5f05a9270['package_id'], $fe06d74291ffa213['id']);
					} else {
						$f03f005ea6f01679 = true;
					}

					if ($fe06d74291ffa213 && in_array(self::$rUserInfo['member_group_id'], json_decode($fe06d74291ffa213['groups'], true))) {
						if ($a27e64cc6ce01033['trial']) {
							if ($f4281667b3862fbd) {
								$Dd1c42dae240b328 = intval($fe06d74291ffa213['trial_credits']);
							} else {
								return array('status' => STATUS_NO_TRIALS, 'data' => $a27e64cc6ce01033);
							}
						} else {
							$B4a5141c87d1c427 = json_decode(self::$rUserInfo['override_packages'], true);

							if (isset($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']) && 0 < strlen($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits'])) {
								$Dd1c42dae240b328 = intval($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']);
							} else {
								$Dd1c42dae240b328 = intval($fe06d74291ffa213['official_credits']);
							}
						}

						if ($Dd1c42dae240b328 <= intval(self::$rUserInfo['credits'])) {
							if ($a27e64cc6ce01033['trial']) {
								$d49041d5f05a9270['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['trial_duration']) . ' ' . $fe06d74291ffa213['trial_duration_in']);
								$d49041d5f05a9270['is_trial'] = 1;
							} else {
								if (isset($d49041d5f05a9270['id']) && $f03f005ea6f01679) {
									if (time() <= $d49041d5f05a9270['exp_date']) {
										$d49041d5f05a9270['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in'], intval($d49041d5f05a9270['exp_date']));
									} else {
										$d49041d5f05a9270['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in']);
									}
								} else {
									$d49041d5f05a9270['exp_date'] = strtotime('+' . intval($fe06d74291ffa213['official_duration']) . ' ' . $fe06d74291ffa213['official_duration_in']);
								}

								$d49041d5f05a9270['is_trial'] = 0;
							}

							$cb498e4dcaac05cc = array_values(json_decode($fe06d74291ffa213['bouquets'], true));

							if (!(self::$rPermissions['allow_change_bouquets'] && 0 < count($a27e64cc6ce01033['bouquets_selected']))) {
							} else {
								$E6c91886bd30f7b9 = array();

								foreach ($a27e64cc6ce01033['bouquets_selected'] as $C52c0b6b0f74407b) {
									if (!in_array($C52c0b6b0f74407b, $cb498e4dcaac05cc)) {
									} else {
										$E6c91886bd30f7b9[] = $C52c0b6b0f74407b;
									}
								}

								if (0 >= count($E6c91886bd30f7b9)) {
								} else {
									$cb498e4dcaac05cc = $E6c91886bd30f7b9;
								}
							}

							$d49041d5f05a9270['bouquet'] = sortArrayByArray($cb498e4dcaac05cc, array_keys(a53403fC10f556bE()));
							$d49041d5f05a9270['bouquet'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['bouquet'])) . ']';
							$d49041d5f05a9270['max_connections'] = $fe06d74291ffa213['max_connections'];
							$d49041d5f05a9270['is_restreamer'] = $fe06d74291ffa213['is_restreamer'];
							$d49041d5f05a9270['force_server_id'] = $fe06d74291ffa213['force_server_id'];
							$d49041d5f05a9270['forced_country'] = $fe06d74291ffa213['forced_country'];
							$d49041d5f05a9270['is_isplock'] = $fe06d74291ffa213['is_isplock'];
							$d49041d5f05a9270['package_id'] = $fe06d74291ffa213['id'];
						} else {
							return array('status' => STATUS_INSUFFICIENT_CREDITS, 'data' => $a27e64cc6ce01033);
						}
					} else {
						return array('status' => STATUS_INVALID_PACKAGE, 'data' => $a27e64cc6ce01033);
					}
				} else {
					return array('status' => STATUS_INVALID_TYPE, 'data' => $a27e64cc6ce01033);
				}
			} else {
				if (!isset($d49041d5f05a9270['id'])) {
					return array('status' => STATUS_INVALID_PACKAGE, 'data' => $a27e64cc6ce01033);
				}

				if (!(isset($a27e64cc6ce01033['edit']) && $d49041d5f05a9270['package_id'])) {
				} else {
					$fe06d74291ffa213 = f0acAB09e248FC13($d49041d5f05a9270['package_id']);
					$cb498e4dcaac05cc = array_values(json_decode($fe06d74291ffa213['bouquets'], true));

					if (!(self::$rPermissions['allow_change_bouquets'] && 0 < count($a27e64cc6ce01033['bouquets_selected']))) {
					} else {
						$E6c91886bd30f7b9 = array();

						foreach ($a27e64cc6ce01033['bouquets_selected'] as $C52c0b6b0f74407b) {
							if (!in_array($C52c0b6b0f74407b, $cb498e4dcaac05cc)) {
							} else {
								$E6c91886bd30f7b9[] = $C52c0b6b0f74407b;
							}
						}

						if (0 >= count($E6c91886bd30f7b9)) {
						} else {
							$cb498e4dcaac05cc = $E6c91886bd30f7b9;
						}
					}

					$d49041d5f05a9270['bouquet'] = sortArrayByArray($cb498e4dcaac05cc, array_keys(A53403fC10F556BE()));
					$d49041d5f05a9270['bouquet'] = '[' . implode(',', array_map('intval', $d49041d5f05a9270['bouquet'])) . ']';
				}
			}

			$d49041d5f05a9270['contact'] = $a27e64cc6ce01033['contact'];
			$d49041d5f05a9270['reseller_notes'] = $a27e64cc6ce01033['reseller_notes'];
			$Dbb9e190755fc819 = $a27e64cc6ce01033['member_id'];

			if (aaCd47D8157A1A09('user', $Dbb9e190755fc819)) {
				$d49041d5f05a9270['member_id'] = $Dbb9e190755fc819;
			} else {
				$d49041d5f05a9270['member_id'] = self::$rUserInfo['id'];
			}

			if (self::$rPermissions['allow_change_username']) {
			} else {
				if (isset($d49041d5f05a9270['id'])) {
					$a27e64cc6ce01033['username'] = $d49041d5f05a9270['username'];
				} else {
					$a27e64cc6ce01033['username'] = '';
				}
			}

			if (self::$rPermissions['allow_change_password']) {
			} else {
				if (isset($d49041d5f05a9270['id'])) {
					$a27e64cc6ce01033['password'] = $d49041d5f05a9270['password'];
				} else {
					$a27e64cc6ce01033['password'] = '';
				}
			}

			if (strlen($a27e64cc6ce01033['username']) == 0) {
				if (!isset($a27e64cc6ce01033['edit'])) {
					$a27e64cc6ce01033['username'] = D7445B70978659BA((10 < self::$rPermissions['minimum_username_length'] ? self::$rPermissions['minimum_username_length'] : 10));
				} else {
					$a27e64cc6ce01033['username'] = $d49041d5f05a9270['username'];
				}
			} else {
				if (strlen($a27e64cc6ce01033['username']) >= self::$rPermissions['minimum_username_length']) {
				} else {
					if (isset($a27e64cc6ce01033['edit']) && $a27e64cc6ce01033['username'] == $Cde547a7a347dc5c['username']) {
					} else {
						return array('status' => STATUS_INVALID_USERNAME, 'data' => $a27e64cc6ce01033);
					}
				}
			}

			if (strlen($a27e64cc6ce01033['password']) == 0) {
				if (!isset($a27e64cc6ce01033['edit'])) {
					$a27e64cc6ce01033['password'] = d7445B70978659Ba((10 < self::$rPermissions['minimum_password_length'] ? self::$rPermissions['minimum_password_length'] : 10));
				} else {
					$a27e64cc6ce01033['password'] = $d49041d5f05a9270['password'];
				}
			} else {
				if (strlen($a27e64cc6ce01033['password']) >= self::$rPermissions['minimum_password_length']) {
				} else {
					if (isset($a27e64cc6ce01033['edit']) && $a27e64cc6ce01033['password'] == $Cde547a7a347dc5c['password']) {
					} else {
						return array('status' => STATUS_INVALID_PASSWORD, 'data' => $a27e64cc6ce01033);
					}
				}
			}

			if (empty($a27e64cc6ce01033['username'])) {
			} else {
				$d49041d5f05a9270['username'] = $a27e64cc6ce01033['username'];
			}

			if (empty($a27e64cc6ce01033['password'])) {
			} else {
				$d49041d5f05a9270['password'] = $a27e64cc6ce01033['password'];
			}

			if (!Aa5550E4a234CbE6('lines', 'username', $d49041d5f05a9270['username'], 'id', $a27e64cc6ce01033['edit'])) {
				if (!self::$rPermissions['allow_restrictions']) {
				} else {
					if (isset($a27e64cc6ce01033['allowed_ips'])) {
						if (is_array($a27e64cc6ce01033['allowed_ips'])) {
						} else {
							$a27e64cc6ce01033['allowed_ips'] = array($a27e64cc6ce01033['allowed_ips']);
						}

						$d49041d5f05a9270['allowed_ips'] = json_encode($a27e64cc6ce01033['allowed_ips']);
					} else {
						$d49041d5f05a9270['allowed_ips'] = '[]';
					}

					if (isset($a27e64cc6ce01033['allowed_ua'])) {
						if (is_array($a27e64cc6ce01033['allowed_ua'])) {
						} else {
							$a27e64cc6ce01033['allowed_ua'] = array($a27e64cc6ce01033['allowed_ua']);
						}

						$d49041d5f05a9270['allowed_ua'] = json_encode($a27e64cc6ce01033['allowed_ua']);
					} else {
						$d49041d5f05a9270['allowed_ua'] = '[]';
					}

					if (isset($a27e64cc6ce01033['bypass_ua'])) {
						$d49041d5f05a9270['bypass_ua'] = 1;
					} else {
						$d49041d5f05a9270['bypass_ua'] = 0;
					}

					if (isset($a27e64cc6ce01033['is_isplock'])) {
						$d49041d5f05a9270['is_isplock'] = 1;
					} else {
						$d49041d5f05a9270['is_isplock'] = 0;
					}

					if (strlen($a27e64cc6ce01033['isp_clear']) != 0) {
					} else {
						$d49041d5f05a9270['isp_desc'] = '';
						$d49041d5f05a9270['as_number'] = null;
					}
				}

				if (!isset($fe06d74291ffa213)) {
				} else {
					$C5c92158885984fd = array();
					$b35f92c785c60f5c = json_decode($fe06d74291ffa213['output_formats'], true);

					foreach ($b35f92c785c60f5c as $F3ba21e7eb72c779) {
						$C5c92158885984fd[] = $F3ba21e7eb72c779;
					}
					$d49041d5f05a9270['allowed_outputs'] = '[' . implode(',', array_map('intval', $C5c92158885984fd)) . ']';
				}

				$acd0eb2c8a975903 = f4817Dc607D9981D($d49041d5f05a9270);
				$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';

				if (self::$db->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data'])) {
					$Fc2dc5a0ce8d07ea = self::$db->last_insert_id();
					A85A61D6f165008A($Fc2dc5a0ce8d07ea);
					self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', SERVER_ID, time(), json_encode(array('type' => 'update_line', 'id' => $Fc2dc5a0ce8d07ea)));

					if (isset($fe06d74291ffa213)) {
						$Bf75a78bd3a0711d = intval(self::$rUserInfo['credits']) - intval($Dd1c42dae240b328);
						self::$db->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $Bf75a78bd3a0711d, self::$rUserInfo['id']);

						if (isset($d49041d5f05a9270['id'])) {
							if ($d49041d5f05a9270['package_id']) {
								$E379394c7b1a273f = 'extend';
							} else {
								$E379394c7b1a273f = 'edit';
							}
						} else {
							$E379394c7b1a273f = 'new';
						}

						$a27e64cc6ce01033 = b4036eF9a1db8473($Fc2dc5a0ce8d07ea);
						self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'line', ?, ?, ?, ?, ?, ?, ?);", self::$rUserInfo['id'], $E379394c7b1a273f, $Fc2dc5a0ce8d07ea, $fe06d74291ffa213['id'], $Dd1c42dae240b328, $Bf75a78bd3a0711d, time(), json_encode($a27e64cc6ce01033));
					} else {
						self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'line', ?, ?, null, ?, ?, ?, ?);", self::$rUserInfo['id'], 'edit', $Fc2dc5a0ce8d07ea, 0, self::$rUserInfo['credits'], time(), json_encode($a27e64cc6ce01033));
					}

					return array('status' => STATUS_SUCCESS, 'data' => array('insert_id' => $Fc2dc5a0ce8d07ea));
				}

				return array('status' => STATUS_FAILURE, 'data' => $a27e64cc6ce01033);
			}

			return array('status' => STATUS_EXISTS_USERNAME, 'data' => $a27e64cc6ce01033);
		}

		return false;
	}
}
