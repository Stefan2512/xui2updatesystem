<?php

class XUI
{
	public static $db = null;
	public static $redis = null;
	public static $rRequest = array();
	public static $rConfig = array();
	public static $rSettings = array();
	public static $rBouquets = array();
	public static $rServers = array();
	public static $rSegmentSettings = array();
	public static $rBlockedUA = array();
	public static $rBlockedISP = array();
	public static $rBlockedIPs = array();
	public static $rBlockedServers = array();
	public static $rAllowedIPs = array();
	public static $rProxies = array();
	public static $rAllowedDomains = array();
	public static $rCategories = array();
	public static $rFFMPEG_CPU = null;
	public static $rFFMPEG_GPU = null;
	public static $rFFPROBE = null;
	public static $rCached = null;

	public static function init($fa976d6ba5c47e5d = false)
	{
		if (empty($_GET)) {
		} else {
			self::eE2659aE23e1E78C($_GET);
		}

		if (empty($_POST)) {
		} else {
			self::Ee2659ae23E1E78C($_POST);
		}

		if (empty($_SESSION)) {
		} else {
			self::Ee2659Ae23e1E78c($_SESSION);
		}

		if (empty($_COOKIE)) {
		} else {
			self::EE2659ae23E1E78C($_COOKIE);
		}

		$a68b12348744a7ff = @self::C13491863979FcF0($_GET, array());
		self::$rRequest = @self::C13491863979fCf0($_POST, $a68b12348744a7ff);
		self::$rConfig = parse_ini_file(CONFIG_PATH . 'config.ini');

		if (defined('SERVER_ID')) {
		} else {
			define('SERVER_ID', intval(self::$rConfig['server_id']));
		}

		if ($fa976d6ba5c47e5d) {
			self::$rSettings = self::AbB674425a8b1B0d('settings');
		} else {
			self::$rSettings = self::d761e78Da5eb70Fb();
		}

		if (empty(self::$rSettings['default_timezone'])) {
		} else {
			date_default_timezone_set(self::$rSettings['default_timezone']);
		}

		if (self::$rSettings['on_demand_wait_time'] != 0) {
		} else {
			self::$rSettings['on_demand_wait_time'] = 15;
		}

		self::$rSegmentSettings = array('seg_type' => self::$rSettings['segment_type'], 'seg_time' => intval(self::$rSettings['seg_time']), 'seg_list_size' => intval(self::$rSettings['seg_list_size']), 'seg_delete_threshold' => intval(self::$rSettings['seg_delete_threshold']));

		switch (self::$rSettings['ffmpeg_cpu']) {
			case '4.4':
				self::$rFFMPEG_CPU = FFMPEG_BIN_44;
				self::$rFFPROBE = FFPROBE_BIN_44;

				break;

			case '4.3':
				self::$rFFMPEG_CPU = FFMPEG_BIN_43;
				self::$rFFPROBE = FFPROBE_BIN_43;

				break;

			default:
				self::$rFFMPEG_CPU = FFMPEG_BIN_40;
				self::$rFFPROBE = FFPROBE_BIN_40;

				break;
		}
		self::$rFFMPEG_GPU = FFMPEG_BIN_40;
		self::$rCached = self::$rSettings['enable_cache'];

		if ($fa976d6ba5c47e5d) {
			self::$rServers = self::ABB674425a8B1B0D('servers');
			self::$rBouquets = self::ABB674425a8b1B0d('bouquets');
			self::$rBlockedUA = self::AbB674425a8B1b0D('blocked_ua');
			self::$rBlockedISP = self::abb674425a8b1B0D('blocked_isp');
			self::$rBlockedIPs = self::aBb674425A8B1b0D('blocked_ips');
			self::$rProxies = self::ABb674425A8b1B0D('proxy_servers');
			self::$rBlockedServers = self::AbB674425a8b1b0d('blocked_servers');
			self::$rAllowedDomains = self::aBB674425A8B1B0D('allowed_domains');
			self::$rAllowedIPs = self::abB674425A8B1B0D('allowed_ips');
			self::$rCategories = self::abb674425a8B1B0D('categories');
		} else {
			self::$rServers = self::f99D78e199D641D5();
			self::$rBouquets = self::D265fF208b308269();
			self::$rBlockedUA = self::f471340647959118();
			self::$rBlockedISP = self::F9F33384E45A2e9D();
			self::$rBlockedIPs = self::C9E378BB69540811();
			self::$rProxies = self::b6977Dc3FF93404E();
			self::$rBlockedServers = self::A4A7866bFdda3129();
			self::$rAllowedDomains = self::A46162b3007Ee572();
			self::$rAllowedIPs = self::C5931CD0269D0A3d();
			self::$rCategories = self::C7BABCBeC16c28ED();
			self::C0bD407e39154323();
		}
	}

	public static function CBFcF0C8cE3D62B9($f338147e1f8d2e97)
	{
		$c07026622e355713 = new DateTime('UTC', new DateTimeZone(date_default_timezone_get()));
		$af336dce58c6bd50 = new DateTime('UTC', new DateTimeZone($f338147e1f8d2e97));

		return $af336dce58c6bd50->getTimestamp() - $c07026622e355713->getTimestamp();
	}

	public static function a46162B3007Ee572($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::abB674425A8B1b0D('allowed_domains', 20);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$D6a9557a9314f79b = array('127.0.0.1', 'localhost');
		self::$db->query('SELECT `server_ip`, `private_ip`, `domain_name` FROM `servers` WHERE `enabled` = 1;');

		foreach (self::$db->get_rows() as $C740da31596f24ef) {
			foreach (explode(',', $C740da31596f24ef['domain_name']) as $Caecf2bcd39a1efe) {
				$D6a9557a9314f79b[] = $Caecf2bcd39a1efe;
			}

			if (!$C740da31596f24ef['server_ip']) {
			} else {
				$D6a9557a9314f79b[] = $C740da31596f24ef['server_ip'];
			}

			if (!$C740da31596f24ef['private_ip']) {
			} else {
				$D6a9557a9314f79b[] = $C740da31596f24ef['private_ip'];
			}
		}
		self::$db->query('SELECT `reseller_dns` FROM `users` WHERE `status` = 1;');

		foreach (self::$db->get_rows() as $C740da31596f24ef) {
			if (!$C740da31596f24ef['reseller_dns']) {
			} else {
				$D6a9557a9314f79b[] = $C740da31596f24ef['reseller_dns'];
			}
		}
		$D6a9557a9314f79b = array_filter(array_unique($D6a9557a9314f79b));
		self::cc314074194522D2('allowed_domains', $D6a9557a9314f79b);

		return $D6a9557a9314f79b;
	}

	public static function b6977DC3fF93404e($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::aBB674425A8b1b0D('proxy_servers', 20);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$f433193a3297ffde = array();

		foreach (self::$rServers as $e81220b4451f37c9) {
			if ($e81220b4451f37c9['server_type'] != 1) {
			} else {
				$f433193a3297ffde[$e81220b4451f37c9['server_ip']] = $e81220b4451f37c9;

				if (!$e81220b4451f37c9['private_ip']) {
				} else {
					$f433193a3297ffde[$e81220b4451f37c9['private_ip']] = $e81220b4451f37c9;
				}
			}
		}
		self::Cc314074194522D2('proxy_servers', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function BB41388445081a3d($c59ec257c284c894)
	{
		if (!isset(self::$rProxies[$c59ec257c284c894])) {
		} else {
			return self::$rProxies[$c59ec257c284c894];
		}
	}

	public static function f471340647959118($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::ABb674425A8B1B0d('blocked_ua', 20);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		self::$db->query('SELECT id,exact_match,LOWER(user_agent) as blocked_ua FROM `blocked_uas`');
		$f433193a3297ffde = self::$db->get_rows(true, 'id');
		self::cC314074194522d2('blocked_ua', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function c9E378bb69540811($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::aBB674425A8B1b0d('blocked_ips', 20);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$f433193a3297ffde = array();
		self::$db->query('SELECT `ip` FROM `blocked_ips`');

		foreach (self::$db->get_rows() as $C740da31596f24ef) {
			$f433193a3297ffde[] = $C740da31596f24ef['ip'];
		}
		self::CC314074194522D2('blocked_ips', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function f9F33384e45A2E9D($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::abB674425a8B1b0D('blocked_isp', 20);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		self::$db->query('SELECT id,isp,blocked FROM `blocked_isps`');
		$f433193a3297ffde = self::$db->get_rows();
		self::cc314074194522D2('blocked_isp', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function a4a7866BFdDa3129($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::aBb674425a8b1B0D('blocked_servers', 20);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$f433193a3297ffde = array();
		self::$db->query('SELECT `asn` FROM `blocked_asns` WHERE `blocked` = 1;');

		foreach (self::$db->get_rows() as $C740da31596f24ef) {
			$f433193a3297ffde[] = $C740da31596f24ef['asn'];
		}
		self::cC314074194522d2('blocked_servers', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function D265Ff208B308269($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::AbB674425a8B1B0d('bouquets', 60);

			if (empty($Eace02ff35917268)) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$f433193a3297ffde = array();
		self::$db->query('SELECT *, IF(`bouquet_order` > 0, `bouquet_order`, 999) AS `order` FROM `bouquets` ORDER BY `order` ASC;');

		foreach (self::$db->get_rows(true, 'id') as $C3c8913edb801c35 => $f46da30a01f7b2d7) {
			$f433193a3297ffde[$C3c8913edb801c35]['streams'] = array_merge(json_decode($f46da30a01f7b2d7['bouquet_channels'], true), json_decode($f46da30a01f7b2d7['bouquet_movies'], true), json_decode($f46da30a01f7b2d7['bouquet_radios'], true));
			$f433193a3297ffde[$C3c8913edb801c35]['series'] = json_decode($f46da30a01f7b2d7['bouquet_series'], true);
			$f433193a3297ffde[$C3c8913edb801c35]['channels'] = json_decode($f46da30a01f7b2d7['bouquet_channels'], true);
			$f433193a3297ffde[$C3c8913edb801c35]['movies'] = json_decode($f46da30a01f7b2d7['bouquet_movies'], true);
			$f433193a3297ffde[$C3c8913edb801c35]['radios'] = json_decode($f46da30a01f7b2d7['bouquet_radios'], true);
		}
		self::cC314074194522D2('bouquets', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function d761E78dA5EB70FB($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::aBb674425A8b1b0D('settings', 20);

			if (empty($Eace02ff35917268)) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$f433193a3297ffde = array();
		self::$db->query('SELECT * FROM `settings`');
		$b3439582205053ea = self::$db->get_row();

		foreach ($b3439582205053ea as $D3fa098be3f297cd => $b6842cb20051e925) {
			$f433193a3297ffde[$D3fa098be3f297cd] = $b6842cb20051e925;
		}
		$f433193a3297ffde['allow_countries'] = json_decode($f433193a3297ffde['allow_countries'], true);
		$f433193a3297ffde['allowed_stb_types'] = array_map('strtolower', json_decode($f433193a3297ffde['allowed_stb_types'], true));
		$f433193a3297ffde['stalker_lock_images'] = json_decode($f433193a3297ffde['stalker_lock_images'], true);

		if (!array_key_exists('bouquet_name', $f433193a3297ffde)) {
		} else {
			$f433193a3297ffde['bouquet_name'] = str_replace(' ', '_', $f433193a3297ffde['bouquet_name']);
		}

		$f433193a3297ffde['api_ips'] = explode(',', $f433193a3297ffde['api_ips']);
		$f433193a3297ffde['live_streaming_pass'] = md5(sha1(self::$rSettings['license']) . OPENSSL_EXTRA);
		self::cC314074194522D2('settings', $f433193a3297ffde);

		return $f433193a3297ffde;
	}

	public static function cC314074194522d2($Eace02ff35917268, $a27e64cc6ce01033)
	{
		$a27e64cc6ce01033 = igbinary_serialize($a27e64cc6ce01033);
		file_put_contents(CACHE_TMP_PATH . $Eace02ff35917268, $a27e64cc6ce01033, LOCK_EX);
	}

	public static function ABB674425a8B1B0D($Eace02ff35917268, $eff3c5536b319f0b = null)
	{
		if (!file_exists(CACHE_TMP_PATH . $Eace02ff35917268)) {
		} else {
			if ($eff3c5536b319f0b && time() - filemtime(CACHE_TMP_PATH . $Eace02ff35917268) >= $eff3c5536b319f0b) {
			} else {
				$a27e64cc6ce01033 = file_get_contents(CACHE_TMP_PATH . $Eace02ff35917268);

				return igbinary_unserialize($a27e64cc6ce01033);
			}
		}

		return false;
	}

	public static function f99d78e199d641D5($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::abB674425a8b1b0d('servers', 10);

			if (empty($Eace02ff35917268)) {
			} else {
				return $Eace02ff35917268;
			}
		}

		if (!empty($_SERVER['REQUEST_SCHEME'])) {
		} else {
			$_SERVER['REQUEST_SCHEME'] = 'http';
		}

		self::$db->query('SELECT * FROM `servers`');
		$a8bb73cba48fb7f6 = array();
		$B4b2277a2ec6b074 = array(1);

		foreach (self::$db->get_rows() as $C740da31596f24ef) {
			if (empty($C740da31596f24ef['domain_name'])) {
				$C700a2b357e5ed65 = escapeshellcmd($C740da31596f24ef['server_ip']);
			} else {
				$C700a2b357e5ed65 = str_replace(array('http://', '/', 'https://'), '', escapeshellcmd(explode(',', $C740da31596f24ef['domain_name'])[0]));
			}

			if ($C740da31596f24ef['enable_https'] == 1) {
				$C6033ec178efa2ae = 'https';
			} else {
				$C6033ec178efa2ae = 'http';
			}

			$b87b2986f8f49da8 = ($C6033ec178efa2ae == 'http' ? intval($C740da31596f24ef['http_broadcast_port']) : intval($C740da31596f24ef['https_broadcast_port']));
			$C740da31596f24ef['server_protocol'] = $C6033ec178efa2ae;
			$C740da31596f24ef['request_port'] = $b87b2986f8f49da8;
			$C740da31596f24ef['site_url'] = $C6033ec178efa2ae . '://' . $C700a2b357e5ed65 . ':' . $b87b2986f8f49da8 . '/';
			$C740da31596f24ef['http_url'] = 'http://' . $C700a2b357e5ed65 . ':' . intval($C740da31596f24ef['http_broadcast_port']) . '/';
			$C740da31596f24ef['https_url'] = 'https://' . $C700a2b357e5ed65 . ':' . intval($C740da31596f24ef['https_broadcast_port']) . '/';
			$C740da31596f24ef['rtmp_server'] = 'rtmp://' . $C700a2b357e5ed65 . ':' . intval($C740da31596f24ef['rtmp_port']) . '/live/';
			$C740da31596f24ef['domains'] = array('protocol' => $C6033ec178efa2ae, 'port' => $b87b2986f8f49da8, 'urls' => array_filter(array_map('escapeshellcmd', explode(',', $C740da31596f24ef['domain_name']))));
			$C740da31596f24ef['rtmp_mport_url'] = 'http://127.0.0.1:31210/';
			$C740da31596f24ef['api_url_ip'] = 'http://' . escapeshellcmd($C740da31596f24ef['server_ip']) . ':' . intval($C740da31596f24ef['http_broadcast_port']) . '/api?password=' . urlencode(self::$rSettings['live_streaming_pass']);
			$C740da31596f24ef['api_url'] = $C740da31596f24ef['api_url_ip'];
			$C740da31596f24ef['site_url_ip'] = $C6033ec178efa2ae . '://' . escapeshellcmd($C740da31596f24ef['server_ip']) . ':' . $b87b2986f8f49da8 . '/';
			$C740da31596f24ef['private_url_ip'] = (!empty($C740da31596f24ef['private_ip']) ? 'http://' . escapeshellcmd($C740da31596f24ef['private_ip']) . ':' . intval($C740da31596f24ef['http_broadcast_port']) . '/' : null);
			$C740da31596f24ef['public_url_ip'] = 'http://' . escapeshellcmd($C740da31596f24ef['server_ip']) . ':' . intval($C740da31596f24ef['http_broadcast_port']) . '/';
			$C740da31596f24ef['geoip_countries'] = (empty($C740da31596f24ef['geoip_countries']) ? array() : json_decode($C740da31596f24ef['geoip_countries'], true));
			$C740da31596f24ef['isp_names'] = (empty($C740da31596f24ef['isp_names']) ? array() : json_decode($C740da31596f24ef['isp_names'], true));

			if (is_numeric($C740da31596f24ef['parent_id'])) {
				$C740da31596f24ef['parent_id'] = array(intval($C740da31596f24ef['parent_id']));
			} else {
				$C740da31596f24ef['parent_id'] = array_map('intval', json_decode($C740da31596f24ef['parent_id'], true));
			}

			if ($C740da31596f24ef['enable_https'] == 2) {
				$C740da31596f24ef['allow_http'] = false;
			} else {
				$C740da31596f24ef['allow_http'] = true;
			}

			if ($C740da31596f24ef['server_type'] == 1) {
				$F9fc841fa5dedffc = 180;
			} else {
				$F9fc841fa5dedffc = 90;
			}

			$C740da31596f24ef['watchdog'] = json_decode($C740da31596f24ef['watchdog_data'], true);
			$C740da31596f24ef['server_online'] = $C740da31596f24ef['enabled'] && in_array($C740da31596f24ef['status'], $B4b2277a2ec6b074) && time() - $C740da31596f24ef['last_check_ago'] <= $F9fc841fa5dedffc || SERVER_ID == $C740da31596f24ef['id'];
			$a8bb73cba48fb7f6[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
		self::Cc314074194522d2('servers', $a8bb73cba48fb7f6);

		return $a8bb73cba48fb7f6;
	}

	public static function EFB9E3C68A59b340($ce2460e0c52a99da, $af3e562c938c2bf3 = null, $cd2a4260ef308305 = 5)
	{
		if (!empty($ce2460e0c52a99da)) {
			$E4700ad423244dbc = array();
			$a0eb8eb80ccd233b = array();
			$c15d5b523e931f51 = array();
			$caa6c2a1dcc4ac73 = curl_multi_init();

			foreach ($ce2460e0c52a99da as $D3fa098be3f297cd => $b6842cb20051e925) {
				if (self::$rServers[$D3fa098be3f297cd]['server_online']) {
					$a0eb8eb80ccd233b[$D3fa098be3f297cd] = curl_init();
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_URL, $b6842cb20051e925['url']);
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_RETURNTRANSFER, true);
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_FOLLOWLOCATION, true);
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_CONNECTTIMEOUT, 5);
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_TIMEOUT, $cd2a4260ef308305);
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_SSL_VERIFYHOST, 0);
					curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_SSL_VERIFYPEER, 0);

					if ($b6842cb20051e925['postdata'] == null) {
					} else {
						curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_POST, true);
						curl_setopt($a0eb8eb80ccd233b[$D3fa098be3f297cd], CURLOPT_POSTFIELDS, http_build_query($b6842cb20051e925['postdata']));
					}

					curl_multi_add_handle($caa6c2a1dcc4ac73, $a0eb8eb80ccd233b[$D3fa098be3f297cd]);
				} else {
					$E4700ad423244dbc[] = $D3fa098be3f297cd;
				}
			}
			$ccf88201f4394db1 = null;

			do {
				$D6526bd9416952fb = curl_multi_exec($caa6c2a1dcc4ac73, $ccf88201f4394db1);
			} while ($D6526bd9416952fb == CURLM_CALL_MULTI_PERFORM);

			while ($ccf88201f4394db1 && $D6526bd9416952fb == CURLM_OK) {
				if (curl_multi_select($caa6c2a1dcc4ac73) != -1) {
				} else {
					usleep(50000);
				}

				do {
					$D6526bd9416952fb = curl_multi_exec($caa6c2a1dcc4ac73, $ccf88201f4394db1);
				} while ($D6526bd9416952fb == CURLM_CALL_MULTI_PERFORM);
			}

			foreach ($a0eb8eb80ccd233b as $D3fa098be3f297cd => $b6842cb20051e925) {
				$c15d5b523e931f51[$D3fa098be3f297cd] = curl_multi_getcontent($b6842cb20051e925);

				if ($af3e562c938c2bf3 == null) {
				} else {
					$c15d5b523e931f51[$D3fa098be3f297cd] = call_user_func($af3e562c938c2bf3, $c15d5b523e931f51[$D3fa098be3f297cd], true);
				}

				curl_multi_remove_handle($caa6c2a1dcc4ac73, $b6842cb20051e925);
			}

			foreach ($E4700ad423244dbc as $D3fa098be3f297cd) {
				$c15d5b523e931f51[$D3fa098be3f297cd] = false;
			}
			curl_multi_close($caa6c2a1dcc4ac73);

			return $c15d5b523e931f51;
		} else {
			return array();
		}
	}

	public static function ee2659AE23e1E78C(&$a27e64cc6ce01033, $Bb3e51c7e44e9edc = 0)
	{
		if (10 > $Bb3e51c7e44e9edc) {
			foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
				if (is_array($b6842cb20051e925)) {
					self::Ee2659AE23E1e78c($a27e64cc6ce01033[$D3fa098be3f297cd], ++$Bb3e51c7e44e9edc);
				} else {
					$b6842cb20051e925 = str_replace(chr('0'), '', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace('', '', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace('', '', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace('../', '&#46;&#46;/', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace('&#8238;', '', $b6842cb20051e925);
					$a27e64cc6ce01033[$D3fa098be3f297cd] = $b6842cb20051e925;
				}
			}
		} else {
			return null;
		}
	}

	public static function C13491863979fcf0(&$a27e64cc6ce01033, $a68b12348744a7ff = array(), $Bb3e51c7e44e9edc = 0)
	{
		if (20 > $Bb3e51c7e44e9edc) {
			if (is_array($a27e64cc6ce01033)) {
				foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
					if (is_array($b6842cb20051e925)) {
						$a68b12348744a7ff[$D3fa098be3f297cd] = self::C13491863979Fcf0($a27e64cc6ce01033[$D3fa098be3f297cd], array(), $Bb3e51c7e44e9edc + 1);
					} else {
						$D3fa098be3f297cd = self::EE07012DE438C358($D3fa098be3f297cd);
						$b6842cb20051e925 = self::a48C65Aa888cD29A($b6842cb20051e925);
						$a68b12348744a7ff[$D3fa098be3f297cd] = $b6842cb20051e925;
					}
				}

				return $a68b12348744a7ff;
			} else {
				return $a68b12348744a7ff;
			}
		} else {
			return $a68b12348744a7ff;
		}
	}

	public static function EE07012dE438c358($D3fa098be3f297cd)
	{
		if ($D3fa098be3f297cd !== '') {
			$D3fa098be3f297cd = htmlspecialchars(urldecode($D3fa098be3f297cd));
			$D3fa098be3f297cd = str_replace('..', '', $D3fa098be3f297cd);
			$D3fa098be3f297cd = preg_replace('/\\_\\_(.+?)\\_\\_/', '', $D3fa098be3f297cd);

			return preg_replace('/^([\\w\\.\\-\\_]+)$/', '$1', $D3fa098be3f297cd);
		}

		return '';
	}

	public static function a48C65Aa888cD29A($b6842cb20051e925)
	{
		if ($b6842cb20051e925 != '') {
			$b6842cb20051e925 = str_replace('&#032;', ' ', stripslashes($b6842cb20051e925));
			$b6842cb20051e925 = str_replace(array("\r\n", "\n\r", "\r"), "\n", $b6842cb20051e925);
			$b6842cb20051e925 = str_replace('<!--', '&#60;&#33;--', $b6842cb20051e925);
			$b6842cb20051e925 = str_replace('-->', '--&#62;', $b6842cb20051e925);
			$b6842cb20051e925 = str_ireplace('<script', '&#60;script', $b6842cb20051e925);
			$b6842cb20051e925 = preg_replace('/&amp;#([0-9]+);/s', '&#\\1;', $b6842cb20051e925);
			$b6842cb20051e925 = preg_replace('/&#(\\d+?)([^\\d;])/i', '&#\\1;\\2', $b6842cb20051e925);

			return trim($b6842cb20051e925);
		}

		return '';
	}

	public static function e22BC2fFBb9818EA($E379394c7b1a273f, $Ce1f39c684b3082c, $B28e0d26329880d3 = '', $Ff014d0ebd314fcd = 0)
	{
		if (!(stripos($B28e0d26329880d3, 'panel_logs') === false && stripos($Ce1f39c684b3082c, 'timeout exceeded') === false && stripos($Ce1f39c684b3082c, 'lock wait timeout') === false && stripos($Ce1f39c684b3082c, 'duplicate entry') === false)) {
		} else {
			panelLog($E379394c7b1a273f, $Ce1f39c684b3082c, $B28e0d26329880d3, $Ff014d0ebd314fcd);
		}
	}

	public static function bb7f1B0ed6C4b87d($f0434521ea9d1547 = 10)
	{
		$b5808391c52eb3a3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789qwertyuiopasdfghjklzxcvbnm';
		$Faf50feea3df4ce1 = '';
		$ad13d88d0f09412f = strlen($b5808391c52eb3a3) - 1;
		$Ea22c4a9ab5b2176 = 0;

		while ($Ea22c4a9ab5b2176 < $f0434521ea9d1547) {
			$Faf50feea3df4ce1 .= $b5808391c52eb3a3[rand(0, $ad13d88d0f09412f)];
			$Ea22c4a9ab5b2176++;
		}

		return $Faf50feea3df4ce1;
	}

	public static function CD3F5D3709165697($d49041d5f05a9270)
	{
		if (is_array($d49041d5f05a9270)) {
			$bc74e212c55daeb9 = array();

			foreach ($d49041d5f05a9270 as $b6842cb20051e925) {
				if (is_scalar($b6842cb20051e925) || is_resource($b6842cb20051e925)) {
					$bc74e212c55daeb9[] = $b6842cb20051e925;
				} else {
					if (!is_array($b6842cb20051e925)) {
					} else {
						$bc74e212c55daeb9 = array_merge($bc74e212c55daeb9, self::CD3F5d3709165697($b6842cb20051e925));
					}
				}
			}

			return $bc74e212c55daeb9;
		} else {
			return $d49041d5f05a9270;
		}
	}

	public static function E382D8e812e470e1()
	{
		$Db02e1f7181c07ed = 0;
		exec('df | grep tmpfs', $f433193a3297ffde);

		foreach ($f433193a3297ffde as $Ff014d0ebd314fcd) {
			$B211d7401e6242f3 = explode(' ', preg_replace('!\\s+!', ' ', $Ff014d0ebd314fcd));

			if ($B211d7401e6242f3[0] != 'tmpfs') {
			} else {
				$Db02e1f7181c07ed += intval($B211d7401e6242f3[2]);
			}
		}

		return $Db02e1f7181c07ed;
	}

	public static function F4148D7DfaEe2f14()
	{
		$Bec25219bd671a85 = array();
		$Bec25219bd671a85['cpu'] = round(self::cA6F24478d510003(), 2);
		$Bec25219bd671a85['cpu_cores'] = intval(shell_exec('cat /proc/cpuinfo | grep "^processor" | wc -l'));
		$Bec25219bd671a85['cpu_avg'] = round((sys_getloadavg()[0] * 100) / (($Bec25219bd671a85['cpu_cores'] ?: 1)), 2);
		$Bec25219bd671a85['cpu_name'] = trim(shell_exec("cat /proc/cpuinfo | grep 'model name' | uniq | awk -F: '{print \$2}'"));

		if (100 >= $Bec25219bd671a85['cpu_avg']) {
		} else {
			$Bec25219bd671a85['cpu_avg'] = 100;
		}

		$baebdd7cfe7cb353 = explode("\n", trim(shell_exec('free')));
		$d59f1e1722d945bf = preg_split('/[\\s]+/', $baebdd7cfe7cb353[1]);
		$F259a109c38d9c14 = intval($d59f1e1722d945bf[2]);
		$c46a91289344b8ac = intval($d59f1e1722d945bf[1]);
		$Bec25219bd671a85['total_mem'] = $c46a91289344b8ac;
		$Bec25219bd671a85['total_mem_free'] = $c46a91289344b8ac - $F259a109c38d9c14;
		$Bec25219bd671a85['total_mem_used'] = $F259a109c38d9c14 + self::E382D8E812E470e1();
		$Bec25219bd671a85['total_mem_used_percent'] = round($Bec25219bd671a85['total_mem_used'] / $Bec25219bd671a85['total_mem'] * 100, 2);
		$Bec25219bd671a85['total_disk_space'] = disk_total_space(XUI_HOME);
		$Bec25219bd671a85['free_disk_space'] = disk_free_space(XUI_HOME);
		$Bec25219bd671a85['kernel'] = trim(shell_exec('uname -r'));
		$Bec25219bd671a85['uptime'] = self::D9898c8A81f5817A();
		$Bec25219bd671a85['total_running_streams'] = (int) trim(shell_exec('ps ax | grep -v grep | grep -c ffmpeg'));
		$Bec25219bd671a85['bytes_sent'] = 0;
		$Bec25219bd671a85['bytes_sent_total'] = 0;
		$Bec25219bd671a85['bytes_received'] = 0;
		$Bec25219bd671a85['bytes_received_total'] = 0;
		$Bec25219bd671a85['network_speed'] = 0;
		$Bec25219bd671a85['interfaces'] = self::bdB739c737519422();
		$Bec25219bd671a85['network_speed'] = 0;

		if (100 >= $Bec25219bd671a85['cpu']) {
		} else {
			$Bec25219bd671a85['cpu'] = 100;
		}

		if ($Bec25219bd671a85['total_mem'] >= $Bec25219bd671a85['total_mem_used']) {
		} else {
			$Bec25219bd671a85['total_mem_used'] = $Bec25219bd671a85['total_mem'];
		}

		if (100 >= $Bec25219bd671a85['total_mem_used_percent']) {
		} else {
			$Bec25219bd671a85['total_mem_used_percent'] = 100;
		}

		$Bec25219bd671a85['network_info'] = XUI::getNetwork((self::$rServers[SERVER_ID]['network_interface'] == 'auto' ? null : self::$rServers[SERVER_ID]['network_interface']));

		foreach ($Bec25219bd671a85['network_info'] as $d9ad9627c40dff4d => $a27e64cc6ce01033) {
			if (!file_exists('/sys/class/net/' . $d9ad9627c40dff4d . '/speed')) {
			} else {
				$F70952efe15b7ec9 = intval(file_get_contents('/sys/class/net/' . $d9ad9627c40dff4d . '/speed'));

				if (!(0 < $F70952efe15b7ec9 && $Bec25219bd671a85['network_speed'] == 0)) {
				} else {
					$Bec25219bd671a85['network_speed'] = $F70952efe15b7ec9;
				}
			}

			$Bec25219bd671a85['bytes_sent_total'] = (intval(trim(file_get_contents('/sys/class/net/' . $d9ad9627c40dff4d . '/statistics/tx_bytes'))) ?: 0);
			$Bec25219bd671a85['bytes_received_total'] = (intval(trim(file_get_contents('/sys/class/net/' . $d9ad9627c40dff4d . '/statistics/tx_bytes'))) ?: 0);
			$Bec25219bd671a85['bytes_sent'] += $a27e64cc6ce01033['out_bytes'];
			$Bec25219bd671a85['bytes_received'] += $a27e64cc6ce01033['in_bytes'];
		}
		$Bec25219bd671a85['audio_devices'] = array();
		$Bec25219bd671a85['video_devices'] = $Bec25219bd671a85['audio_devices'];
		$Bec25219bd671a85['gpu_info'] = $Bec25219bd671a85['video_devices'];
		$Bec25219bd671a85['iostat_info'] = $Bec25219bd671a85['gpu_info'];

		if (!shell_exec('which iostat')) {
		} else {
			$Bec25219bd671a85['iostat_info'] = self::eF4097F4F6184E3c();
		}

		if (!shell_exec('which nvidia-smi')) {
		} else {
			$Bec25219bd671a85['gpu_info'] = self::DEfe244dAA97F7a4();
		}

		if (!shell_exec('which v4l2-ctl')) {
		} else {
			$Bec25219bd671a85['video_devices'] = self::b42c5caDD77930aB();
		}

		if (!shell_exec('which arecord')) {
		} else {
			$Bec25219bd671a85['audio_devices'] = self::BFB30a293708C066();
		}

		list($Bec25219bd671a85['cpu_load_average']) = sys_getloadavg();

		return $Bec25219bd671a85;
	}

	public static function Bdb739c737519422()
	{
		$a85e1b7d42c346a0 = array();
		exec('ls /sys/class/net/', $f433193a3297ffde, $E072e4fd80a065b3);

		foreach ($f433193a3297ffde as $d9ad9627c40dff4d) {
			$d9ad9627c40dff4d = trim(rtrim($d9ad9627c40dff4d, ':'));

			if (!($d9ad9627c40dff4d != 'lo' && substr($d9ad9627c40dff4d, 0, 4) != 'bond')) {
			} else {
				$a85e1b7d42c346a0[] = $d9ad9627c40dff4d;
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function b42C5CadD77930ab()
	{
		$a85e1b7d42c346a0 = array();
		$C3c8913edb801c35 = 0;

		try {
			$Bb1e97d0ea20bca0 = array_values(array_filter(explode("\n", shell_exec('v4l2-ctl --list-devices'))));

			if (!is_array($Bb1e97d0ea20bca0)) {
			} else {
				foreach ($Bb1e97d0ea20bca0 as $D3fa098be3f297cd => $b6842cb20051e925) {
					if ($D3fa098be3f297cd % 2 != 0) {
					} else {
						$a85e1b7d42c346a0[$C3c8913edb801c35]['name'] = $b6842cb20051e925;
						list(, $a85e1b7d42c346a0[$C3c8913edb801c35]['video_device']) = explode('/dev/', $Bb1e97d0ea20bca0[$D3fa098be3f297cd + 1]);
						$C3c8913edb801c35++;
					}
				}
			}
		} catch (Exception $c34ae71903f0d920) {
		}

		return $a85e1b7d42c346a0;
	}

	public static function bfb30A293708c066()
	{
		try {
			return array_filter(explode("\n", shell_exec('arecord -L | grep "hw:CARD="')));
		} catch (Exception $c34ae71903f0d920) {
			return array();
		}
	}

	public static function EF4097f4f6184E3c()
	{
		exec('iostat -o JSON -m', $f433193a3297ffde, $E072e4fd80a065b3);
		$f433193a3297ffde = implode('', $f433193a3297ffde);
		$Bec25219bd671a85 = json_decode($f433193a3297ffde, true);

		if (isset($Bec25219bd671a85['sysstat'])) {
			return $Bec25219bd671a85['sysstat']['hosts'][0]['statistics'][0];
		}

		return array();
	}

	public static function DeFe244daa97f7a4()
	{
		exec('nvidia-smi -x -q', $f433193a3297ffde, $E072e4fd80a065b3);
		$f433193a3297ffde = implode('', $f433193a3297ffde);

		if (stripos($f433193a3297ffde, '<?xml') === false) {
		} else {
			$Bec25219bd671a85 = json_decode(json_encode(simplexml_load_string($f433193a3297ffde)), true);

			if (!isset($Bec25219bd671a85['driver_version'])) {
			} else {
				$d5aa7e5e1de00526 = array('attached_gpus' => $Bec25219bd671a85['attached_gpus'], 'driver_version' => $Bec25219bd671a85['driver_version'], 'cuda_version' => $Bec25219bd671a85['cuda_version'], 'gpus' => array());

				if (!isset($Bec25219bd671a85['gpu']['board_id'])) {
				} else {
					$Bec25219bd671a85['gpu'] = array($Bec25219bd671a85['gpu']);
				}

				foreach ($Bec25219bd671a85['gpu'] as $E3ac875d75b91241) {
					$d49041d5f05a9270 = array('name' => $E3ac875d75b91241['product_name'], 'power_readings' => $E3ac875d75b91241['power_readings'], 'utilisation' => $E3ac875d75b91241['utilization'], 'memory_usage' => $E3ac875d75b91241['fb_memory_usage'], 'fan_speed' => $E3ac875d75b91241['fan_speed'], 'temperature' => $E3ac875d75b91241['temperature'], 'clocks' => $E3ac875d75b91241['clocks'], 'uuid' => $E3ac875d75b91241['uuid'], 'id' => intval($E3ac875d75b91241['pci']['pci_device']), 'processes' => array());

					foreach ($E3ac875d75b91241['processes']['process_info'] as $Df1e7eea7d843145) {
						$d49041d5f05a9270['processes'][] = array('pid' => intval($Df1e7eea7d843145['pid']), 'memory' => $Df1e7eea7d843145['used_memory']);
					}
					$d5aa7e5e1de00526['gpus'][] = $d49041d5f05a9270;
				}

				return $d5aa7e5e1de00526;
			}
		}

		return array();
	}

	public static function ef3e56BA4e1e5a58($d49041d5f05a9270, $D3fa098be3f297cd, $b6842cb20051e925)
	{
		$c15d5b523e931f51 = array();
		self::E1c5E682Bc7Eea20($d49041d5f05a9270, $D3fa098be3f297cd, $b6842cb20051e925, $c15d5b523e931f51);

		return $c15d5b523e931f51;
	}

	public static function e1c5e682BC7eEa20($d49041d5f05a9270, $D3fa098be3f297cd, $b6842cb20051e925, &$c15d5b523e931f51)
	{
		if (is_array($d49041d5f05a9270)) {
			if (!(isset($d49041d5f05a9270[$D3fa098be3f297cd]) && $d49041d5f05a9270[$D3fa098be3f297cd] == $b6842cb20051e925)) {
			} else {
				$c15d5b523e931f51[] = $d49041d5f05a9270;
			}

			foreach ($d49041d5f05a9270 as $caff8cbbbc94e2e9) {
				self::E1c5e682bc7eeA20($caff8cbbbc94e2e9, $D3fa098be3f297cd, $b6842cb20051e925, $c15d5b523e931f51);
			}
		} else {
			return null;
		}
	}

	public static function b839EE4c00AB33C2($bc2874292e0d9ece, $C4af185e24cf9086 = 1800)
	{
		if (!file_exists($bc2874292e0d9ece)) {
		} else {
			$f9b07d216a168dcc = trim(file_get_contents($bc2874292e0d9ece));

			if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
			} else {
				if (time() - filemtime($bc2874292e0d9ece) >= $C4af185e24cf9086) {
					if (!(is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
					} else {
						posix_kill($f9b07d216a168dcc, 9);
					}
				} else {
					exit('Running...');
				}
			}
		}

		file_put_contents($bc2874292e0d9ece, getmypid());

		return false;
	}

	public static function fC8474658ec80360($c59ec257c284c894 = null)
	{
		if (self::$rSettings['flood_limit'] != 0) {
			if ($c59ec257c284c894) {
			} else {
				$c59ec257c284c894 = self::a9Bc416fa6fA55C3();
			}

			if (!(empty($c59ec257c284c894) || in_array($c59ec257c284c894, self::$rAllowedIPs))) {
				$D4a9631cb1db6a7b = array_filter(array_unique(explode(',', self::$rSettings['flood_ips_exclude'])));

				if (!in_array($c59ec257c284c894, $D4a9631cb1db6a7b)) {
					$b784c383b47a49fd = FLOOD_TMP_PATH . $c59ec257c284c894;

					if (file_exists($b784c383b47a49fd)) {
						$A707ccd39fee7276 = json_decode(file_get_contents($b784c383b47a49fd), true);
						$be54debae5869cd3 = self::$rSettings['flood_seconds'];
						$A96a38e6b91953f2 = self::$rSettings['flood_limit'];

						if (time() - $A707ccd39fee7276['last_request'] <= $be54debae5869cd3) {
							$A707ccd39fee7276['requests']++;

							if ($A96a38e6b91953f2 > $A707ccd39fee7276['requests']) {
								$A707ccd39fee7276['last_request'] = time();
								file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
							} else {
								if (in_array($c59ec257c284c894, self::$rBlockedIPs)) {
								} else {
									self::$db->query('INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES(?,?,?)', $c59ec257c284c894, 'FLOOD ATTACK', time());
									self::$rBlockedIPs = self::c9e378bb69540811();
								}

								touch(FLOOD_TMP_PATH . 'block_' . $c59ec257c284c894);
								unlink($b784c383b47a49fd);

								return null;
							}
						} else {
							$A707ccd39fee7276['requests'] = 0;
							$A707ccd39fee7276['last_request'] = time();
							file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
						}
					} else {
						file_put_contents($b784c383b47a49fd, json_encode(array('requests' => 0, 'last_request' => time())), LOCK_EX);
					}
				} else {
					return null;
				}
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function B6f740FabC7265Bf($c59ec257c284c894 = null, $C3cdd40816db3399 = null, $a71afc14d6cd090d = null)
	{
		if ($C3cdd40816db3399 || $a71afc14d6cd090d) {
			if (!($C3cdd40816db3399 && self::$rSettings['bruteforce_mac_attempts'] == 0)) {
				if (!($a71afc14d6cd090d && self::$rSettings['bruteforce_username_attempts'] == 0)) {
					if ($c59ec257c284c894) {
					} else {
						$c59ec257c284c894 = self::a9Bc416fa6FA55C3();
					}

					if (!(empty($c59ec257c284c894) || in_array($c59ec257c284c894, self::$rAllowedIPs))) {
						$D4a9631cb1db6a7b = array_filter(array_unique(explode(',', self::$rSettings['flood_ips_exclude'])));

						if (!in_array($c59ec257c284c894, $D4a9631cb1db6a7b)) {
							$b9dd61c40657d13d = (!is_null($C3cdd40816db3399) ? 'mac' : 'user');
							$Be47c94a460069d8 = (!is_null($C3cdd40816db3399) ? $C3cdd40816db3399 : $a71afc14d6cd090d);
							$b784c383b47a49fd = FLOOD_TMP_PATH . $c59ec257c284c894 . '_' . $b9dd61c40657d13d;

							if (file_exists($b784c383b47a49fd)) {
								$A707ccd39fee7276 = json_decode(file_get_contents($b784c383b47a49fd), true);
								$be54debae5869cd3 = intval(self::$rSettings['bruteforce_frequency']);
								$A96a38e6b91953f2 = intval(self::$rSettings[array('mac' => 'bruteforce_mac_attempts', 'user' => 'bruteforce_username_attempts')[$b9dd61c40657d13d]]);
								$A707ccd39fee7276['attempts'] = self::C7d4656747098c59($A707ccd39fee7276['attempts'], $be54debae5869cd3);

								if (in_array($Be47c94a460069d8, array_keys($A707ccd39fee7276['attempts']))) {
								} else {
									$A707ccd39fee7276['attempts'][$Be47c94a460069d8] = time();

									if ($A96a38e6b91953f2 > count($A707ccd39fee7276['attempts'])) {
										file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
									} else {
										self::$db->query('INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES(?,?,?)', $c59ec257c284c894, 'BRUTEFORCE ' . strtoupper($b9dd61c40657d13d) . ' ATTACK', time());
										touch(FLOOD_TMP_PATH . 'block_' . $c59ec257c284c894);
										unlink($b784c383b47a49fd);

										return null;
									}
								}
							} else {
								$A707ccd39fee7276 = array('attempts' => array($Be47c94a460069d8 => time()));
								file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
							}
						} else {
							return null;
						}
					} else {
						return null;
					}
				} else {
					return null;
				}
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function c7d4656747098C59($ed4c668b21748203, $Dea739940867923b, $A2334a366640c078 = false)
	{
		$A11bd3dafa3511e9 = array();
		$C4af185e24cf9086 = time();

		if ($A2334a366640c078) {
			foreach ($ed4c668b21748203 as $C402db0b1e917573) {
				if ($C4af185e24cf9086 - $C402db0b1e917573 > $Dea739940867923b) {
				} else {
					$A11bd3dafa3511e9[] = $C402db0b1e917573;
				}
			}
		} else {
			foreach ($ed4c668b21748203 as $fa682959477a699f => $C402db0b1e917573) {
				if ($C4af185e24cf9086 - $C402db0b1e917573 > $Dea739940867923b) {
				} else {
					$A11bd3dafa3511e9[$fa682959477a699f] = $C402db0b1e917573;
				}
			}
		}

		return $A11bd3dafa3511e9;
	}

	public static function CA6F24478D510003()
	{
		$D39d2163eebf362a = 0;
		exec('ps -Ao pid,pcpu', $C392102bdadf03e9);

		foreach ($C392102bdadf03e9 as $C7b53b084f4c1049) {
			$d558a1bfea30d8b2 = explode(' ', preg_replace('!\\s+!', ' ', trim($C7b53b084f4c1049)));
			$D39d2163eebf362a += floatval($d558a1bfea30d8b2[1]);
		}

		return $D39d2163eebf362a / intval(shell_exec("grep -P '^processor' /proc/cpuinfo|wc -l"));
	}

	public static function C7BaBcBeC16C28ED($E379394c7b1a273f = null, $b91591a6218018bb = false)
	{
		if (is_string($E379394c7b1a273f)) {
			self::$db->query('SELECT t1.* FROM `streams_categories` t1 WHERE t1.category_type = ? GROUP BY t1.id ORDER BY t1.cat_order ASC', $E379394c7b1a273f);

			return (0 < self::$db->num_rows() ? self::$db->get_rows(true, 'id') : array());
		}

		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::ABB674425A8B1B0d('categories', 20);

			if (empty($Eace02ff35917268)) {
			} else {
				return $Eace02ff35917268;
			}
		}

		self::$db->query('SELECT t1.* FROM `streams_categories` t1 ORDER BY t1.cat_order ASC');
		$A5dcdeb6ecbbf6bd = (0 < self::$db->num_rows() ? self::$db->get_rows(true, 'id') : array());
		self::Cc314074194522D2('categories', $A5dcdeb6ecbbf6bd);

		return $A5dcdeb6ecbbf6bd;
	}

	public static function B28089331F7ADba7()
	{
		return substr(md5(self::$rSettings['live_streaming_pass']), 0, 15);
	}

	public static function ac3e721852A33591($eb156ef2770d2039)
	{
		$a85e1b7d42c346a0 = array();
		$db752e19806388c2 = 0;

		while ($db752e19806388c2 < strlen($eb156ef2770d2039)) {
			if (strstr(substr($eb156ef2770d2039, $db752e19806388c2), '|')) {
				$Aa07a44246fb374e = strpos($eb156ef2770d2039, '|', $db752e19806388c2);
				$F80ea1676db4f3fe = $Aa07a44246fb374e - $db752e19806388c2;
				$bb9775be05184c44 = substr($eb156ef2770d2039, $db752e19806388c2, $F80ea1676db4f3fe);
				$db752e19806388c2 += $F80ea1676db4f3fe + 1;
				$a27e64cc6ce01033 = igbinary_unserialize(substr($eb156ef2770d2039, $db752e19806388c2));
				$a85e1b7d42c346a0[$bb9775be05184c44] = $a27e64cc6ce01033;
				$db752e19806388c2 += strlen(igbinary_serialize($a27e64cc6ce01033));
			} else {
				return array();
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function C8C03C8A7AFeb053($D4253f9520627819, $a94d5d59ff9b8d05, $B5179d3aa5ad70dd = 'ts', $E6ba93c1fc86556a = null, $b9b8c6585c0f1e33 = false, $Fa288895c003c519 = false)
	{
		if (!empty($a94d5d59ff9b8d05)) {
			if ($B5179d3aa5ad70dd != 'mpegts') {
			} else {
				$B5179d3aa5ad70dd = 'ts';
			}

			if ($B5179d3aa5ad70dd != 'hls') {
			} else {
				$B5179d3aa5ad70dd = 'm3u8';
			}

			if (empty($B5179d3aa5ad70dd)) {
				self::$db->query('SELECT t1.output_ext FROM `output_formats` t1 INNER JOIN `output_devices` t2 ON t2.default_output = t1.access_output_id AND `device_key` = ?', $a94d5d59ff9b8d05);
			} else {
				self::$db->query('SELECT t1.output_ext FROM `output_formats` t1 WHERE `output_key` = ?', $B5179d3aa5ad70dd);
			}

			if (self::$db->num_rows() > 0) {
				$B269b356f5a0b8f3 = $D4253f9520627819['id'] . '_' . $a94d5d59ff9b8d05 . '_' . $B5179d3aa5ad70dd . '_' . implode('_', ($E6ba93c1fc86556a ?: array()));
				$Fa0e147e24bf5583 = self::$db->get_col();
				$ff78fc37403b734f = ($D4253f9520627819['is_restreamer'] ? self::$rSettings['encrypt_playlist_restreamer'] : self::$rSettings['encrypt_playlist']);

				if (!$D4253f9520627819['is_stalker']) {
				} else {
					$ff78fc37403b734f = false;
				}

				$Ca5a0830e8583ff3 = self::d55a1d8acD201840();

				if ($Ca5a0830e8583ff3) {
					if (!$Fa288895c003c519) {
						$D1a2cac9f6a3c78a = array();

						if ($B5179d3aa5ad70dd != 'rtmp') {
						} else {
							self::$db->query('SELECT t1.id,t2.server_id FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id WHERE t1.rtmp_output = 1');
							$D1a2cac9f6a3c78a = self::$db->get_rows(true, 'id', false, 'server_id');
						}
					} else {
						if ($B5179d3aa5ad70dd != 'rtmp') {
						} else {
							$B5179d3aa5ad70dd = 'ts';
						}
					}

					if (!empty($Fa0e147e24bf5583)) {
					} else {
						$Fa0e147e24bf5583 = 'ts';
					}

					self::$db->query('SELECT t1.*,t2.* FROM `output_devices` t1 LEFT JOIN `output_formats` t2 ON t2.access_output_id = t1.default_output WHERE t1.device_key = ? LIMIT 1', $a94d5d59ff9b8d05);

					if (0 >= self::$db->num_rows()) {
						return false;
					}

					$Fdc8e0fc5edb3ca8 = self::$db->get_row();

					if (strlen($D4253f9520627819['access_token']) == 32) {
						$bc2874292e0d9ece = str_replace('{USERNAME}', $D4253f9520627819['access_token'], $Fdc8e0fc5edb3ca8['device_filename']);
					} else {
						$bc2874292e0d9ece = str_replace('{USERNAME}', $D4253f9520627819['username'], $Fdc8e0fc5edb3ca8['device_filename']);
					}

					if (!(0 < self::$rSettings['cache_playlists'] && !$b9b8c6585c0f1e33 && file_exists(PLAYLIST_PATH . md5($B269b356f5a0b8f3)))) {
						$a27e64cc6ce01033 = '';
						$a2771663c11e526e = $A9c7f0cd94ef2cf0 = $Be8acff8875eca91 = array();
						$D4253f9520627819['episode_ids'] = array();

						if (0 >= count($D4253f9520627819['series_ids'])) {
						} else {
							if (self::$rCached) {
								foreach ($D4253f9520627819['series_ids'] as $A2d65843292b5c59) {
									$Be8acff8875eca91[$A2d65843292b5c59] = igbinary_unserialize(file_get_contents(SERIES_TMP_PATH . 'series_' . intval($A2d65843292b5c59)));
									$db82b1cafeb50651 = igbinary_unserialize(file_get_contents(SERIES_TMP_PATH . 'episodes_' . intval($A2d65843292b5c59)));

									foreach ($db82b1cafeb50651 as $f4b0dd7c7320bd8d => $b1fa0ad0bb84d114) {
										foreach ($b1fa0ad0bb84d114 as $Bd43537fab08ca31) {
											$A9c7f0cd94ef2cf0[$Bd43537fab08ca31['stream_id']] = array($f4b0dd7c7320bd8d, $Bd43537fab08ca31['episode_num']);
											$a2771663c11e526e[$Bd43537fab08ca31['stream_id']] = $A2d65843292b5c59;
											$D4253f9520627819['episode_ids'][] = $Bd43537fab08ca31['stream_id'];
										}
									}
								}
							} else {
								self::$db->query('SELECT * FROM `streams_series` WHERE `id` IN (' . implode(',', $D4253f9520627819['series_ids']) . ')');
								$Be8acff8875eca91 = self::$db->get_rows(true, 'id');

								if (0 >= count($D4253f9520627819['series_ids'])) {
								} else {
									self::$db->query('SELECT stream_id, series_id, season_num, episode_num FROM `streams_episodes` WHERE series_id IN (' . implode(',', $D4253f9520627819['series_ids']) . ') ORDER BY FIELD(series_id,' . implode(',', $D4253f9520627819['series_ids']) . '), season_num ASC, episode_num ASC');

									foreach (self::$db->get_rows(true, 'series_id', false) as $A2d65843292b5c59 => $b1fa0ad0bb84d114) {
										foreach ($b1fa0ad0bb84d114 as $Bd43537fab08ca31) {
											$A9c7f0cd94ef2cf0[$Bd43537fab08ca31['stream_id']] = array($Bd43537fab08ca31['season_num'], $Bd43537fab08ca31['episode_num']);
											$a2771663c11e526e[$Bd43537fab08ca31['stream_id']] = $A2d65843292b5c59;
											$D4253f9520627819['episode_ids'][] = $Bd43537fab08ca31['stream_id'];
										}
									}
								}
							}
						}

						if (0 >= count($D4253f9520627819['episode_ids'])) {
						} else {
							$D4253f9520627819['channel_ids'] = array_merge($D4253f9520627819['channel_ids'], $D4253f9520627819['episode_ids']);
						}

						$B2fdaed180cd0049 = array();
						$bb7e0fa5e5b4c1e0 = false;

						if ($E6ba93c1fc86556a) {
							foreach ($E6ba93c1fc86556a as $E379394c7b1a273f) {
								switch ($E379394c7b1a273f) {
									case 'live':
									case 'created_live':
										if (!$bb7e0fa5e5b4c1e0) {
											$B2fdaed180cd0049 = array_merge($B2fdaed180cd0049, $D4253f9520627819['live_ids']);
											$bb7e0fa5e5b4c1e0 = true;

											break;
										}

										break;

									case 'movie':
										$B2fdaed180cd0049 = array_merge($B2fdaed180cd0049, $D4253f9520627819['vod_ids']);

										break;

									case 'radio_streams':
										$B2fdaed180cd0049 = array_merge($B2fdaed180cd0049, $D4253f9520627819['radio_ids']);

										break;

									case 'series':
										$B2fdaed180cd0049 = array_merge($B2fdaed180cd0049, $D4253f9520627819['episode_ids']);

										break;
								}
							}
						} else {
							$B2fdaed180cd0049 = $D4253f9520627819['channel_ids'];
						}

						if (!in_array(self::$rSettings['channel_number_type'], array('bouquet_new', 'manual'))) {
						} else {
							$B2fdaed180cd0049 = self::E43CB741AA22A6d8($B2fdaed180cd0049);
						}

						unset($D4253f9520627819['live_ids'], $D4253f9520627819['vod_ids'], $D4253f9520627819['radio_ids'], $D4253f9520627819['episode_ids'], $D4253f9520627819['channel_ids']);

						$b3a398f749be1716 = null;
						header('Content-Description: File Transfer');
						header('Content-Type: application/octet-stream');
						header('Expires: 0');
						header('Cache-Control: must-revalidate');
						header('Pragma: public');

						if (strlen($D4253f9520627819['access_token']) == 32) {
							header('Content-Disposition: attachment; filename="' . str_replace('{USERNAME}', $D4253f9520627819['access_token'], $Fdc8e0fc5edb3ca8['device_filename']) . '"');
						} else {
							header('Content-Disposition: attachment; filename="' . str_replace('{USERNAME}', $D4253f9520627819['username'], $Fdc8e0fc5edb3ca8['device_filename']) . '"');
						}

						if (0 >= self::$rSettings['cache_playlists']) {
						} else {
							$C18586cd337049a8 = PLAYLIST_PATH . md5($B269b356f5a0b8f3) . '.write';
							$b3a398f749be1716 = fopen($C18586cd337049a8, 'w');
						}

						if ($a94d5d59ff9b8d05 == 'starlivev5') {
							$f433193a3297ffde = array();
							$f433193a3297ffde['iptvstreams_list'] = array();
							$f433193a3297ffde['iptvstreams_list']['@version'] = 1;
							$f433193a3297ffde['iptvstreams_list']['group'] = array();
							$f433193a3297ffde['iptvstreams_list']['group']['name'] = 'IPTV';
							$f433193a3297ffde['iptvstreams_list']['group']['channel'] = array();

							foreach (array_chunk($B2fdaed180cd0049, 1000) as $Bbdb5d4feececbb6) {
								if (self::$rSettings['playlist_from_mysql'] || !self::$rCached) {
									$c6c389b9adf3a40c = 'FIELD(`t1`.`id`,' . implode(',', $Bbdb5d4feececbb6) . ')';
									self::$db->query('SELECT t1.id,t1.channel_id,t1.year,t1.movie_properties,t1.stream_icon,t1.custom_sid,t1.category_id,t1.stream_display_name,t2.type_output,t2.type_key,t1.target_container,t2.live FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type WHERE `t1`.`id` IN (' . implode(',', array_map('intval', $Bbdb5d4feececbb6)) . ') ORDER BY ' . $c6c389b9adf3a40c . ';');
									$b3439582205053ea = self::$db->get_rows();
								} else {
									$b3439582205053ea = array();

									foreach ($Bbdb5d4feececbb6 as $C3c8913edb801c35) {
										$b3439582205053ea[] = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($C3c8913edb801c35)))['info'];
									}
								}

								foreach ($b3439582205053ea as $fca7edf85daa1695) {
									if (!$E6ba93c1fc86556a || in_array($fca7edf85daa1695['type_output'], $E6ba93c1fc86556a)) {
										if ($fca7edf85daa1695['target_container']) {
										} else {
											$fca7edf85daa1695['target_container'] = 'mp4';
										}

										$D92b16dc36690ab9 = (!is_array($fca7edf85daa1695['movie_properties']) ? json_decode($fca7edf85daa1695['movie_properties'], true) : $fca7edf85daa1695['movie_properties']);

										if ($fca7edf85daa1695['type_key'] == 'series') {
											$A2d65843292b5c59 = $a2771663c11e526e[$fca7edf85daa1695['id']];
											$fca7edf85daa1695['live'] = 0;
											$fca7edf85daa1695['stream_display_name'] = $Be8acff8875eca91[$A2d65843292b5c59]['title'] . ' S' . sprintf('%02d', $A9c7f0cd94ef2cf0[$fca7edf85daa1695['id']][0]) . 'E' . sprintf('%02d', $A9c7f0cd94ef2cf0[$fca7edf85daa1695['id']][1]);
											$fca7edf85daa1695['movie_properties'] = array('movie_image' => (!empty($D92b16dc36690ab9['movie_image']) ? $D92b16dc36690ab9['movie_image'] : $Be8acff8875eca91['cover']));
											$fca7edf85daa1695['type_output'] = 'series';
											$fca7edf85daa1695['category_id'] = $Be8acff8875eca91[$A2d65843292b5c59]['category_id'];
										} else {
											$fca7edf85daa1695['stream_display_name'] = self::Ae6Bb580Baa323c2($fca7edf85daa1695['stream_display_name'], $fca7edf85daa1695['year']);
										}

										if (strlen($D4253f9520627819['access_token']) == 32) {
											$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $fca7edf85daa1695['type_output'] . '/' . $D4253f9520627819['access_token'] . '/';

											if ($fca7edf85daa1695['live'] == 0) {
												$C700a2b357e5ed65 .= $fca7edf85daa1695['id'] . '.' . $fca7edf85daa1695['target_container'];
											} else {
												if (self::$rSettings['cloudflare'] && $Fa0e147e24bf5583 == 'ts') {
													$C700a2b357e5ed65 .= $fca7edf85daa1695['id'];
												} else {
													$C700a2b357e5ed65 .= $fca7edf85daa1695['id'] . '.' . $Fa0e147e24bf5583;
												}
											}
										} else {
											if ($ff78fc37403b734f) {
												$b1a9a67f7480d1f6 = $fca7edf85daa1695['type_output'] . '/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/';

												if ($fca7edf85daa1695['live'] == 0) {
													$b1a9a67f7480d1f6 .= $fca7edf85daa1695['id'] . '/' . $fca7edf85daa1695['target_container'];
												} else {
													if (self::$rSettings['cloudflare'] && $Fa0e147e24bf5583 == 'ts') {
														$b1a9a67f7480d1f6 .= $fca7edf85daa1695['id'];
													} else {
														$b1a9a67f7480d1f6 .= $fca7edf85daa1695['id'] . '/' . $Fa0e147e24bf5583;
													}
												}

												$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
												$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;

												if ($fca7edf85daa1695['live'] != 0) {
												} else {
													$C700a2b357e5ed65 .= '#.' . $fca7edf85daa1695['target_container'];
												}
											} else {
												$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $fca7edf85daa1695['type_output'] . '/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/';

												if ($fca7edf85daa1695['live'] == 0) {
													$C700a2b357e5ed65 .= $fca7edf85daa1695['id'] . '.' . $fca7edf85daa1695['target_container'];
												} else {
													if (self::$rSettings['cloudflare'] && $Fa0e147e24bf5583 == 'ts') {
														$C700a2b357e5ed65 .= $fca7edf85daa1695['id'];
													} else {
														$C700a2b357e5ed65 .= $fca7edf85daa1695['id'] . '.' . $Fa0e147e24bf5583;
													}
												}
											}
										}

										if ($fca7edf85daa1695['live'] == 0) {
											if (empty($D92b16dc36690ab9['movie_image'])) {
											} else {
												$E9c8d08bfb6ef33c = $D92b16dc36690ab9['movie_image'];
											}
										} else {
											$E9c8d08bfb6ef33c = $fca7edf85daa1695['stream_icon'];
										}

										$Fe753328765ad26c = array();
										$Fe753328765ad26c['name'] = $fca7edf85daa1695['stream_display_name'];
										$Fe753328765ad26c['icon'] = self::B8F3DeF724810918($E9c8d08bfb6ef33c);
										$Fe753328765ad26c['stream_url'] = $C700a2b357e5ed65;
										$Fe753328765ad26c['stream_type'] = 0;
										$f433193a3297ffde['iptvstreams_list']['group']['channel'][] = $Fe753328765ad26c;
									}
								}
								unset($b3439582205053ea);
							}
							$a27e64cc6ce01033 = json_encode((object) $f433193a3297ffde);
						} else {
							if (empty($Fdc8e0fc5edb3ca8['device_header'])) {
							} else {
								$db3ed2c46ee45435 = ($Fdc8e0fc5edb3ca8['device_header'] == '#EXTM3U' ? "\n" . '#EXT-X-SESSION-DATA:DATA-ID="com.xui.' . str_replace('.', '_', XUI_VERSION) . ((XUI_REVISION ? 'r' . XUI_REVISION : '')) . '"' : '');
								$a27e64cc6ce01033 = str_replace(array('&lt;', '&gt;'), array('<', '>'), str_replace(array('{BOUQUET_NAME}', '{USERNAME}', '{PASSWORD}', '{SERVER_URL}', '{OUTPUT_KEY}'), array(self::$rSettings['server_name'], $D4253f9520627819['username'], $D4253f9520627819['password'], $Ca5a0830e8583ff3, $B5179d3aa5ad70dd), $Fdc8e0fc5edb3ca8['device_header'] . $db3ed2c46ee45435)) . "\n";

								if (!$b3a398f749be1716) {
								} else {
									fwrite($b3a398f749be1716, $a27e64cc6ce01033);
								}

								echo $a27e64cc6ce01033;
								unset($a27e64cc6ce01033);
							}

							if (empty($Fdc8e0fc5edb3ca8['device_conf'])) {
							} else {
								if (preg_match('/\\{URL\\#(.*?)\\}/', $Fdc8e0fc5edb3ca8['device_conf'], $b85ce31cd1118ad2)) {
									$F94badb7f167139c = str_split($b85ce31cd1118ad2[1]);
									$B213d02f48d88809 = $b85ce31cd1118ad2[0];
								} else {
									$F94badb7f167139c = array();
									$B213d02f48d88809 = '{URL}';
								}

								foreach (array_chunk($B2fdaed180cd0049, 1000) as $Bbdb5d4feececbb6) {
									if (self::$rSettings['playlist_from_mysql'] || !self::$rCached) {
										$c6c389b9adf3a40c = 'FIELD(`t1`.`id`,' . implode(',', $Bbdb5d4feececbb6) . ')';
										self::$db->query('SELECT t1.id,t1.channel_id,t1.year,t1.movie_properties,t1.stream_icon,t1.custom_sid,t1.category_id,t1.stream_display_name,t2.type_output,t2.type_key,t1.target_container,t2.live,t1.tv_archive_duration,t1.tv_archive_server_id FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type WHERE `t1`.`id` IN (' . implode(',', array_map('intval', $Bbdb5d4feececbb6)) . ') ORDER BY ' . $c6c389b9adf3a40c . ';');
										$b3439582205053ea = self::$db->get_rows();
									} else {
										$b3439582205053ea = array();

										foreach ($Bbdb5d4feececbb6 as $C3c8913edb801c35) {
											$b3439582205053ea[] = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($C3c8913edb801c35)))['info'];
										}
									}

									foreach ($b3439582205053ea as $Fe753328765ad26c) {
										if ($E6ba93c1fc86556a && !in_array($Fe753328765ad26c['type_output'], $E6ba93c1fc86556a)) {
										} else {
											if ($Fe753328765ad26c['target_container']) {
											} else {
												$Fe753328765ad26c['target_container'] = 'mp4';
											}

											$Df06db369f6b9832 = $Fdc8e0fc5edb3ca8['device_conf'];

											if ($Fdc8e0fc5edb3ca8['device_key'] != 'm3u_plus') {
											} else {
												if ($Fe753328765ad26c['live']) {
												} else {
													$Df06db369f6b9832 = str_replace('tvg-id="{CHANNEL_ID}" ', '', $Df06db369f6b9832);
												}

												if ($ff78fc37403b734f) {
												} else {
													$Df06db369f6b9832 = str_replace('xui-id="{XUI_ID}" ', '', $Df06db369f6b9832);
												}

												if (!(0 < $Fe753328765ad26c['tv_archive_server_id'] && 0 < $Fe753328765ad26c['tv_archive_duration'])) {
												} else {
													$Df06db369f6b9832 = str_replace('#EXTINF:-1 ', '#EXTINF:-1 timeshift="' . intval($Fe753328765ad26c['tv_archive_duration']) . '" ', $Df06db369f6b9832);
												}
											}

											$D92b16dc36690ab9 = (!is_array($Fe753328765ad26c['movie_properties']) ? json_decode($Fe753328765ad26c['movie_properties'], true) : $Fe753328765ad26c['movie_properties']);

											if ($Fe753328765ad26c['type_key'] == 'series') {
												$A2d65843292b5c59 = $a2771663c11e526e[$Fe753328765ad26c['id']];
												$Fe753328765ad26c['live'] = 0;
												$Fe753328765ad26c['stream_display_name'] = $Be8acff8875eca91[$A2d65843292b5c59]['title'] . ' S' . sprintf('%02d', $A9c7f0cd94ef2cf0[$Fe753328765ad26c['id']][0]) . 'E' . sprintf('%02d', $A9c7f0cd94ef2cf0[$Fe753328765ad26c['id']][1]);
												$Fe753328765ad26c['movie_properties'] = array('movie_image' => (!empty($D92b16dc36690ab9['movie_image']) ? $D92b16dc36690ab9['movie_image'] : $Be8acff8875eca91['cover']));
												$Fe753328765ad26c['type_output'] = 'series';
												$Fe753328765ad26c['category_id'] = $Be8acff8875eca91[$A2d65843292b5c59]['category_id'];
											} else {
												$Fe753328765ad26c['stream_display_name'] = self::aE6BB580BAa323c2($Fe753328765ad26c['stream_display_name'], $Fe753328765ad26c['year']);
											}

											if ($Fe753328765ad26c['live'] == 0) {
												if (strlen($D4253f9520627819['access_token']) == 32) {
													$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $Fe753328765ad26c['type_output'] . '/' . $D4253f9520627819['access_token'] . '/' . $Fe753328765ad26c['id'] . '.' . $Fe753328765ad26c['target_container'];
												} else {
													if ($ff78fc37403b734f) {
														$b1a9a67f7480d1f6 = $Fe753328765ad26c['type_output'] . '/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'] . '/' . $Fe753328765ad26c['target_container'];
														$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
														$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730 . '#.' . $Fe753328765ad26c['target_container'];
													} else {
														$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $Fe753328765ad26c['type_output'] . '/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'] . '.' . $Fe753328765ad26c['target_container'];
													}
												}

												if (empty($D92b16dc36690ab9['movie_image'])) {
												} else {
													$E9c8d08bfb6ef33c = $D92b16dc36690ab9['movie_image'];
												}
											} else {
												if ($B5179d3aa5ad70dd != 'rtmp' || !array_key_exists($Fe753328765ad26c['id'], $D1a2cac9f6a3c78a)) {
													if (strlen($D4253f9520627819['access_token']) == 32) {
														if (self::$rSettings['cloudflare'] && $Fa0e147e24bf5583 == 'ts') {
															$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $Fe753328765ad26c['type_output'] . '/' . $D4253f9520627819['access_token'] . '/' . $Fe753328765ad26c['id'];
														} else {
															$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $Fe753328765ad26c['type_output'] . '/' . $D4253f9520627819['access_token'] . '/' . $Fe753328765ad26c['id'] . '.' . $Fa0e147e24bf5583;
														}
													} else {
														if ($ff78fc37403b734f) {
															$b1a9a67f7480d1f6 = $Fe753328765ad26c['type_output'] . '/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'];
															$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

															if (self::$rSettings['cloudflare'] && $Fa0e147e24bf5583 == 'ts') {
																$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;
															} else {
																$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730 . '/' . $Fa0e147e24bf5583;
															}
														} else {
															if (self::$rSettings['cloudflare'] && $Fa0e147e24bf5583 == 'ts') {
																$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'];
															} else {
																$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'] . '.' . $Fa0e147e24bf5583;
															}
														}
													}
												} else {
													$c43b488500f8fab7 = array_values(array_keys($D1a2cac9f6a3c78a[$Fe753328765ad26c['id']]));

													if (in_array($D4253f9520627819['force_server_id'], $c43b488500f8fab7)) {
														$d58b4f8653a391d8 = $D4253f9520627819['force_server_id'];
													} else {
														if (self::$rSettings['rtmp_random'] == 1) {
															$d58b4f8653a391d8 = $c43b488500f8fab7[array_rand($c43b488500f8fab7, 1)];
														} else {
															$d58b4f8653a391d8 = $c43b488500f8fab7[0];
														}
													}

													if (strlen($D4253f9520627819['access_token']) == 32) {
														$C700a2b357e5ed65 = self::$rServers[$d58b4f8653a391d8]['rtmp_server'] . $Fe753328765ad26c['id'] . '?token=' . $D4253f9520627819['access_token'];
													} else {
														if ($ff78fc37403b734f) {
															$b1a9a67f7480d1f6 = $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'];
															$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
															$C700a2b357e5ed65 = self::$rServers[$d58b4f8653a391d8]['rtmp_server'] . $Fe753328765ad26c['id'] . '?token=' . $ea5296071288c730;
														} else {
															$C700a2b357e5ed65 = self::$rServers[$d58b4f8653a391d8]['rtmp_server'] . $Fe753328765ad26c['id'] . '?username=' . $D4253f9520627819['username'] . '&password=' . $D4253f9520627819['password'];
														}
													}
												}

												$E9c8d08bfb6ef33c = $Fe753328765ad26c['stream_icon'];
											}

											$E75a7738c39423d2 = ($Fe753328765ad26c['live'] == 1 ? 1 : 4097);
											$e154835c9fa166f7 = (!empty($Fe753328765ad26c['custom_sid']) ? $Fe753328765ad26c['custom_sid'] : ':0:1:0:0:0:0:0:0:0:');
											$A38b42a281e3c3cf = json_decode($Fe753328765ad26c['category_id'], true);

											foreach ($A38b42a281e3c3cf as $Be965cdd996d4520) {
												if (!isset(self::$rCategories[$Be965cdd996d4520])) {
												} else {
													$a27e64cc6ce01033 = str_replace(array('&lt;', '&gt;'), array('<', '>'), str_replace(array($B213d02f48d88809, '{ESR_ID}', '{SID}', '{CHANNEL_NAME}', '{CHANNEL_ID}', '{XUI_ID}', '{CATEGORY}', '{CHANNEL_ICON}'), array(str_replace($F94badb7f167139c, array_map('urlencode', $F94badb7f167139c), $C700a2b357e5ed65), $E75a7738c39423d2, $e154835c9fa166f7, $Fe753328765ad26c['stream_display_name'], $Fe753328765ad26c['channel_id'], $Fe753328765ad26c['id'], self::$rCategories[$Be965cdd996d4520]['category_name'], self::B8F3dEF724810918($E9c8d08bfb6ef33c)), $Df06db369f6b9832)) . "\r\n";

													if (!$b3a398f749be1716) {
													} else {
														fwrite($b3a398f749be1716, $a27e64cc6ce01033);
													}

													echo $a27e64cc6ce01033;
													unset($a27e64cc6ce01033);

													if (stripos($Fdc8e0fc5edb3ca8['device_conf'], '{CATEGORY}') !== false) {
													} else {
														break;
													}
												}
											}
										}
									}
									unset($b3439582205053ea);
								}
								$a27e64cc6ce01033 = trim(str_replace(array('&lt;', '&gt;'), array('<', '>'), $Fdc8e0fc5edb3ca8['device_footer']));

								if (!$b3a398f749be1716) {
								} else {
									fwrite($b3a398f749be1716, $a27e64cc6ce01033);
								}

								echo $a27e64cc6ce01033;
								unset($a27e64cc6ce01033);
							}
						}

						if (!$b3a398f749be1716) {
						} else {
							fclose($b3a398f749be1716);
							rename(PLAYLIST_PATH . md5($B269b356f5a0b8f3) . '.write', PLAYLIST_PATH . md5($B269b356f5a0b8f3));
						}

						exit();
					} else {
						header('Content-Description: File Transfer');
						header('Content-Type: audio/mpegurl');
						header('Expires: 0');
						header('Cache-Control: must-revalidate');
						header('Pragma: public');
						header('Content-Disposition: attachment; filename="' . $bc2874292e0d9ece . '"');
						header('Content-Length: ' . filesize(PLAYLIST_PATH . md5($B269b356f5a0b8f3)));
						readfile(PLAYLIST_PATH . md5($B269b356f5a0b8f3));

						exit();
					}
				} else {
					exit();
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public static function C0BD407E39154323()
	{
		if (!file_exists(TMP_PATH . 'crontab')) {
			$d8e1ad6b188dbdf4 = array();
			self::$db->query('SELECT * FROM `crontab` WHERE `enabled` = 1;');

			foreach (self::$db->get_rows() as $C740da31596f24ef) {
				$Ceae75a565e98862 = CRON_PATH . $C740da31596f24ef['filename'];

				if (!(pathinfo($Ceae75a565e98862, PATHINFO_EXTENSION) == 'php' && file_exists($Ceae75a565e98862))) {
				} else {
					$d8e1ad6b188dbdf4[] = $C740da31596f24ef['time'] . ' ' . PHP_BIN . ' ' . $Ceae75a565e98862 . ' # XUI';
				}
			}
			shell_exec('crontab -r');
			$daccb76819c06304 = tempnam('/tmp', 'crontab');
			$a8f3762d489787d6 = fopen($daccb76819c06304, 'w');
			fwrite($a8f3762d489787d6, implode("\n", $d8e1ad6b188dbdf4) . "\n");
			fclose($a8f3762d489787d6);
			shell_exec('crontab -u xui ' . $daccb76819c06304);
			@unlink($daccb76819c06304);
			file_put_contents(TMP_PATH . 'crontab', 1);

			return true;
		} else {
			return false;
		}
	}

	public static function d9898c8a81f5817a()
	{
		if (!(file_exists('/proc/uptime') && is_readable('/proc/uptime'))) {
			return '';
		}

		$B323f688a9d7f9a2 = explode(' ', file_get_contents('/proc/uptime'));

		return self::F01c2e2CfC16141E(intval($B323f688a9d7f9a2[0]));
	}

	public static function F01c2E2cfc16141E($de16adba583fc9f0, $Eb458c5ab98b7766 = true)
	{
		$f5a40933cd131650 = 60;
		$D190f42f27c7722c = 60 * $f5a40933cd131650;
		$Ae94b8d1425dede2 = 24 * $D190f42f27c7722c;
		$cd539c9a539b9f0a = (int) floor($de16adba583fc9f0 / (($Ae94b8d1425dede2 ?: 1)));
		$beea34473e378980 = $de16adba583fc9f0 % $Ae94b8d1425dede2;
		$cfd208d2a440ee12 = (int) floor($beea34473e378980 / (($D190f42f27c7722c ?: 1)));
		$f81290abe8fd3503 = $beea34473e378980 % $D190f42f27c7722c;
		$D1b34eaa5eef40cc = (int) floor($f81290abe8fd3503 / (($f5a40933cd131650 ?: 1)));
		$c9cdf5b680dc2a9a = $f81290abe8fd3503 % $f5a40933cd131650;
		$eff3c5536b319f0b = (int) ceil($c9cdf5b680dc2a9a);
		$f433193a3297ffde = '';

		if ($cd539c9a539b9f0a == 0) {
		} else {
			$f433193a3297ffde .= $cd539c9a539b9f0a . 'd ';
		}

		if ($cfd208d2a440ee12 == 0) {
		} else {
			$f433193a3297ffde .= $cfd208d2a440ee12 . 'h ';
		}

		if ($D1b34eaa5eef40cc == 0) {
		} else {
			$f433193a3297ffde .= $D1b34eaa5eef40cc . 'm ';
		}

		if (!$Eb458c5ab98b7766) {
		} else {
			$f433193a3297ffde .= $eff3c5536b319f0b . 's';
		}

		return $f433193a3297ffde;
	}

	public static function d7d15e7eC17683F7($Bd256313624d4d54, $c078f3ed0fe7b4fa, $acd3b41bac740313)
	{
		if (is_array($Bd256313624d4d54)) {
		} else {
			$Bd256313624d4d54 = array(intval($Bd256313624d4d54));
		}

		$c078f3ed0fe7b4fa = array_map('intval', $c078f3ed0fe7b4fa);
		$f433193a3297ffde = array();

		foreach ($Bd256313624d4d54 as $d58b4f8653a391d8) {
			if (array_key_exists($d58b4f8653a391d8, self::$rServers)) {
				$c7488e8420e934e2 = self::E16FCF8dD53043ea($d58b4f8653a391d8, self::$rServers[$d58b4f8653a391d8]['api_url_ip'] . '&action=pidsAreRunning', array('program' => $acd3b41bac740313, 'pids' => $c078f3ed0fe7b4fa));

				if ($c7488e8420e934e2) {
					$f433193a3297ffde[$d58b4f8653a391d8] = array_map('trim', json_decode($c7488e8420e934e2, true));
				} else {
					$f433193a3297ffde[$d58b4f8653a391d8] = false;
				}
			}
		}

		return $f433193a3297ffde;
	}

	public static function bcf05fD79248269e($d58b4f8653a391d8, $f9b07d216a168dcc, $acd3b41bac740313)
	{
		if (!is_null($f9b07d216a168dcc) && is_numeric($f9b07d216a168dcc) && array_key_exists($d58b4f8653a391d8, self::$rServers)) {
			if (!($f433193a3297ffde = self::d7d15e7eC17683F7($d58b4f8653a391d8, array($f9b07d216a168dcc), $acd3b41bac740313))) {
				return false;
			}

			return $f433193a3297ffde[$d58b4f8653a391d8][$f9b07d216a168dcc];
		}

		return false;
	}

	public static function E16FCf8dd53043eA($d58b4f8653a391d8, $C700a2b357e5ed65, $C4033c5a05611ed1 = array())
	{
		if (self::$rServers[$d58b4f8653a391d8]['server_online']) {
			$f433193a3297ffde = false;
			$Ea22c4a9ab5b2176 = 1;

			while ($Ea22c4a9ab5b2176 <= 2) {
				$a0eb8eb80ccd233b = curl_init();
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_URL, $C700a2b357e5ed65);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:9.0) Gecko/20100101 Firefox/9.0');
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_HEADER, 0);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_CONNECTTIMEOUT, 10);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_TIMEOUT, 10);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_FOLLOWLOCATION, true);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_FRESH_CONNECT, true);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_FORBID_REUSE, true);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_SSL_VERIFYPEER, 0);

				if (empty($C4033c5a05611ed1)) {
				} else {
					curl_setopt($a0eb8eb80ccd233b, CURLOPT_POST, true);
					curl_setopt($a0eb8eb80ccd233b, CURLOPT_POSTFIELDS, http_build_query($C4033c5a05611ed1));
				}

				$f433193a3297ffde = curl_exec($a0eb8eb80ccd233b);
				$Bda0d94d4afc8eda = curl_getinfo($a0eb8eb80ccd233b, CURLINFO_HTTP_CODE);
				$D370fc32f973c6ca = curl_errno($a0eb8eb80ccd233b);
				@curl_close($a0eb8eb80ccd233b);

				if ($D370fc32f973c6ca != 0 || $Bda0d94d4afc8eda != 200) {
					$Ea22c4a9ab5b2176++;

					break;
				}
			}

			return $f433193a3297ffde;
		}

		return false;
	}

	public static function e8382A1682c8dB80($bbfc9bd8432031f5)
	{
		if (!empty($bbfc9bd8432031f5)) {
			foreach ($bbfc9bd8432031f5 as $c8d91fcd2309e48a) {
				if (!file_exists(CACHE_TMP_PATH . md5($c8d91fcd2309e48a))) {
				} else {
					unlink(CACHE_TMP_PATH . md5($c8d91fcd2309e48a));
				}
			}
		} else {
			return null;
		}
	}

	public static function queueChannel($F26087d31c2bbe4d, $d58b4f8653a391d8 = null)
	{
		if ($d58b4f8653a391d8) {
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		self::$db->query('SELECT `id` FROM `queue` WHERE `stream_id` = ? AND `server_id` = ?;', $F26087d31c2bbe4d, $d58b4f8653a391d8);

		if (self::$db->num_rows() != 0) {
		} else {
			self::$db->query("INSERT INTO `queue`(`type`, `stream_id`, `server_id`, `added`) VALUES('channel', ?, ?, ?);", $F26087d31c2bbe4d, $d58b4f8653a391d8, time());
		}
	}

	public static function d2c822a2E8D18C4e($F26087d31c2bbe4d)
	{
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'created.php ' . intval($F26087d31c2bbe4d) . ' >/dev/null 2>/dev/null &');

		return true;
	}

	public static function DA53076ce1DFC8FD($F26087d31c2bbe4d, $c8d91fcd2309e48a)
	{
		$f523e362fb81d6c8 = array();
		self::$db->query('SELECT * FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type AND t1.type = 3 LEFT JOIN `profiles` t4 ON t1.transcode_profile_id = t4.profile_id WHERE t1.direct_source = 0 AND t1.id = ?', $F26087d31c2bbe4d);

		if (self::$db->num_rows() > 0) {
			$f523e362fb81d6c8['stream_info'] = self::$db->get_row();
			self::$db->query('SELECT * FROM `streams_servers` WHERE stream_id  = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);

			if (self::$db->num_rows() > 0) {
				$f523e362fb81d6c8['server_info'] = self::$db->get_row();
				$Ba344b2758e3e955 = md5($c8d91fcd2309e48a);

				if (substr($c8d91fcd2309e48a, 0, 2) == 's:') {
					$B211d7401e6242f3 = explode(':', $c8d91fcd2309e48a, 3);
					$d58b4f8653a391d8 = intval($B211d7401e6242f3[1]);

					if ($d58b4f8653a391d8 != SERVER_ID) {
						$ffcc333700be728e = self::$rServers[$d58b4f8653a391d8]['api_url'] . '&action=getFile&filename=' . urlencode($B211d7401e6242f3[2]);
					} else {
						$ffcc333700be728e = $B211d7401e6242f3[2];
					}
				} else {
					$d58b4f8653a391d8 = SERVER_ID;
					$ffcc333700be728e = $c8d91fcd2309e48a;
				}

				if ($d58b4f8653a391d8 == SERVER_ID && $f523e362fb81d6c8['stream_info']['movie_symlink'] == 1) {
					$F9452a7efafa1aba = pathinfo($c8d91fcd2309e48a)['extension'];

					if (strlen($F9452a7efafa1aba) != 0) {
					} else {
						$F9452a7efafa1aba = 'mp4';
					}

					$cf1c389bda3e30fd = 'ln -sfn ' . escapeshellarg($ffcc333700be728e) . ' "' . CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.' . escapeshellcmd($F9452a7efafa1aba) . '" >/dev/null 2>/dev/null & echo $! > "' . CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.pid"';
				} else {
					$f523e362fb81d6c8['stream_info']['transcode_attributes'] = json_decode($f523e362fb81d6c8['stream_info']['profile_options'], true);
					$a35d06dcea116901 = (isset($f523e362fb81d6c8['stream_info']['transcode_attributes'][16]) && !$feb762ab0abc1ea0 ? $f523e362fb81d6c8['stream_info']['transcode_attributes'][16]['cmd'] : '');
					$af3d0e7328416f86 = (isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']) ? $f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']['cmd'] : '');
					$D36982f48af7b142 = '';

					if (empty($af3d0e7328416f86)) {
					} else {
						$e4cfabbf1b1ea27e = self::C8851B830A0692cd($ffcc333700be728e);

						if (!in_array($e4cfabbf1b1ea27e['codecs']['video']['codec_name'], array('h264', 'hevc', 'mjpeg', 'mpeg1', 'mpeg2', 'mpeg4', 'vc1', 'vp8', 'vp9'))) {
						} else {
							$D36982f48af7b142 = '-c:v ' . $e4cfabbf1b1ea27e['codecs']['video']['codec_name'] . '_cuvid';
						}
					}

					$cf1c389bda3e30fd = ((isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']) ? self::$rFFMPEG_GPU : self::$rFFMPEG_CPU)) . ' -y -nostdin -hide_banner -loglevel ' . ((self::$rSettings['ffmpeg_warnings'] ? 'warning' : 'error')) . ' -err_detect ignore_err {GPU} -fflags +genpts -async 1 -i {STREAM_SOURCE} {LOGO} ';

					if (array_key_exists('-acodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-acodec'] = 'copy';
					}

					if (array_key_exists('-vcodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-vcodec'] = 'copy';
					}

					if (!isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu'])) {
					} else {
						$cf1c389bda3e30fd .= '-gpu ' . intval($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']['device']) . ' ';
					}

					$cf1c389bda3e30fd .= implode(' ', self::f40647De56F1867D($f523e362fb81d6c8['stream_info']['transcode_attributes'])) . ' ';
					$cf1c389bda3e30fd .= '-strict -2 -mpegts_flags +initial_discontinuity -f mpegts "' . CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.ts"';
					$cf1c389bda3e30fd .= ' >/dev/null 2>"' . CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.errors" & echo $! > "' . CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.pid"';
					$cf1c389bda3e30fd = str_replace(array('{GPU}', '{INPUT_CODEC}', '{LOGO}', '{STREAM_SOURCE}'), array($af3d0e7328416f86, $D36982f48af7b142, $a35d06dcea116901, escapeshellarg($ffcc333700be728e)), $cf1c389bda3e30fd);
				}

				shell_exec($cf1c389bda3e30fd);

				return intval(file_get_contents(CREATED_PATH . intval($F26087d31c2bbe4d) . '_' . $Ba344b2758e3e955 . '.pid'));
			}

			return false;
		}

		return false;
	}

	public static function extractSubtitle($F26087d31c2bbe4d, $a0ab3474f3e3df3b, $Fa5e35208ccf3528)
	{
		$cd2a4260ef308305 = 10;
		$cf1c389bda3e30fd = 'timeout ' . $cd2a4260ef308305 . ' ' . self::$rFFMPEG_CPU . ' -y -nostdin -hide_banner -loglevel ' . ((self::$rSettings['ffmpeg_warnings'] ? 'warning' : 'error')) . ' -err_detect ignore_err -i "' . $a0ab3474f3e3df3b . '" -map 0:s:' . intval($Fa5e35208ccf3528) . ' ' . VOD_PATH . intval($F26087d31c2bbe4d) . '_' . intval($Fa5e35208ccf3528) . '.srt';
		exec($cf1c389bda3e30fd, $f433193a3297ffde);

		if (file_exists(VOD_PATH . intval($F26087d31c2bbe4d) . '_' . intval($Fa5e35208ccf3528) . '.srt')) {
			if (filesize(VOD_PATH . intval($F26087d31c2bbe4d) . '_' . intval($Fa5e35208ccf3528) . '.srt') != 0) {
				return true;
			}

			unlink(VOD_PATH . intval($F26087d31c2bbe4d) . '_' . intval($Fa5e35208ccf3528) . '.srt');

			return false;
		}

		return false;
	}

	public static function c8851B830A0692CD($a0ab3474f3e3df3b, $f145176c7c32ac18 = array(), $b4ec3275c5363e97 = '', $fafb517aced09d9a = true)
	{
		$a8d6b4f70a067a08 = abs(intval(self::$rSettings['stream_max_analyze']));
		$c16539fff4ffd50f = abs(intval(self::$rSettings['probesize']));
		$cd2a4260ef308305 = intval($a8d6b4f70a067a08 / 1000000) + self::$rSettings['probe_extra_wait'];
		$cf1c389bda3e30fd = $b4ec3275c5363e97 . 'timeout ' . $cd2a4260ef308305 . ' ' . self::$rFFPROBE . ' -probesize ' . $c16539fff4ffd50f . ' -analyzeduration ' . $a8d6b4f70a067a08 . ' ' . implode(' ', $f145176c7c32ac18) . ' -i "' . $a0ab3474f3e3df3b . '" -v quiet -print_format json -show_streams -show_format';
		exec($cf1c389bda3e30fd, $a85e1b7d42c346a0);
		$Ba6c0ac3f64f8274 = implode("\n", $a85e1b7d42c346a0);

		if ($fafb517aced09d9a) {
			return self::CEfc1ce0aDBb45d2(json_decode($Ba6c0ac3f64f8274, true));
		}

		return json_decode($Ba6c0ac3f64f8274, true);
	}

	public static function CeFc1cE0adBb45D2($D3957f583a2b0d0c)
	{
		if (empty($D3957f583a2b0d0c)) {
			return false;
		}

		if (empty($D3957f583a2b0d0c['codecs'])) {
			$f433193a3297ffde = array();
			$f433193a3297ffde['codecs']['video'] = '';
			$f433193a3297ffde['codecs']['audio'] = '';
			$f433193a3297ffde['container'] = $D3957f583a2b0d0c['format']['format_name'];
			$f433193a3297ffde['filename'] = $D3957f583a2b0d0c['format']['filename'];
			$f433193a3297ffde['bitrate'] = (!empty($D3957f583a2b0d0c['format']['bit_rate']) ? $D3957f583a2b0d0c['format']['bit_rate'] : null);
			$f433193a3297ffde['of_duration'] = (!empty($D3957f583a2b0d0c['format']['duration']) ? $D3957f583a2b0d0c['format']['duration'] : 'N/A');
			$f433193a3297ffde['duration'] = (!empty($D3957f583a2b0d0c['format']['duration']) ? gmdate('H:i:s', intval($D3957f583a2b0d0c['format']['duration'])) : 'N/A');

			foreach ($D3957f583a2b0d0c['streams'] as $A387578f69b4c724) {
				if (isset($A387578f69b4c724['codec_type']) && !($A387578f69b4c724['codec_type'] != 'audio' && $A387578f69b4c724['codec_type'] != 'video' && $A387578f69b4c724['codec_type'] != 'subtitle')) {
					if ($A387578f69b4c724['codec_type'] == 'audio' || $A387578f69b4c724['codec_type'] == 'video') {
						if (!empty($f433193a3297ffde['codecs'][$A387578f69b4c724['codec_type']])) {
						} else {
							$f433193a3297ffde['codecs'][$A387578f69b4c724['codec_type']] = $A387578f69b4c724;
						}
					} else {
						if ($A387578f69b4c724['codec_type'] != 'subtitle') {
						} else {
							if (isset($f433193a3297ffde['codecs'][$A387578f69b4c724['codec_type']])) {
							} else {
								$f433193a3297ffde['codecs'][$A387578f69b4c724['codec_type']] = array();
							}

							$f433193a3297ffde['codecs'][$A387578f69b4c724['codec_type']][] = $A387578f69b4c724;
						}
					}
				}
			}

			return $f433193a3297ffde;
		} else {
			return $D3957f583a2b0d0c;
		}
	}

	public static function a52eA4c1EAD81de2($F26087d31c2bbe4d, $D00cf8fa3b1195d0 = false)
	{
		if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
			$E27108b229227a45 = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
		} else {
			self::$db->query('SELECT `monitor_pid` FROM `streams_servers` WHERE `server_id` = ? AND `stream_id` = ? LIMIT 1;', SERVER_ID, $F26087d31c2bbe4d);
			$E27108b229227a45 = intval(self::$db->get_row()['monitor_pid']);
		}

		if (0 >= $E27108b229227a45) {
		} else {
			if (!(self::a20f10AE10C29e2B($E27108b229227a45, array('XUI[' . $F26087d31c2bbe4d . ']', 'XUIProxy[' . $F26087d31c2bbe4d . ']')) && is_numeric($E27108b229227a45) && 0 < $E27108b229227a45)) {
			} else {
				posix_kill($E27108b229227a45, 9);
			}
		}

		if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
			$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
		} else {
			self::$db->query('SELECT `pid` FROM `streams_servers` WHERE `server_id` = ? AND `stream_id` = ? LIMIT 1;', SERVER_ID, $F26087d31c2bbe4d);
			$f9b07d216a168dcc = intval(self::$db->get_row()['pid']);
		}

		if (0 >= $f9b07d216a168dcc) {
		} else {
			if (!(self::A20f10Ae10c29E2B($f9b07d216a168dcc, array($F26087d31c2bbe4d . '_.m3u8', $F26087d31c2bbe4d . '_%d.ts', 'LLOD[' . $F26087d31c2bbe4d . ']', 'XUIProxy[' . $F26087d31c2bbe4d . ']', 'Loopback[' . $F26087d31c2bbe4d . ']')) && is_numeric($f9b07d216a168dcc) && 0 < $f9b07d216a168dcc)) {
			} else {
				posix_kill($f9b07d216a168dcc, 9);
			}
		}

		if (!file_exists(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) {
		} else {
			unlink(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d));
		}

		self::efFEb9f2c8015c8A($F26087d31c2bbe4d, SERVER_ID, 'STREAM_STOP');
		shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*');

		if (!$D00cf8fa3b1195d0) {
		} else {
			shell_exec('rm -f ' . DELAY_PATH . intval($F26087d31c2bbe4d) . '_*');
			self::$db->query('UPDATE `streams_servers` SET `bitrate` = NULL,`current_source` = NULL,`to_analyze` = 0,`pid` = NULL,`stream_started` = NULL,`stream_info` = NULL,`audio_codec` = NULL,`video_codec` = NULL,`resolution` = NULL,`compatible` = 0,`stream_status` = 0,`monitor_pid` = NULL WHERE `stream_id` = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);
			self::afA0f3FfB001b9bE($F26087d31c2bbe4d);
		}
	}

	public static function A20F10ae10c29e2b($f9b07d216a168dcc, $bbf487337b8f5211)
	{
		if (is_array($bbf487337b8f5211)) {
		} else {
			$bbf487337b8f5211 = array($bbf487337b8f5211);
		}

		if (!file_exists('/proc/' . $f9b07d216a168dcc)) {
		} else {
			$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

			foreach ($bbf487337b8f5211 as $Be47c94a460069d8) {
				if (!stristr($cf1c389bda3e30fd, $Be47c94a460069d8)) {
				} else {
					return true;
				}
			}
		}

		return false;
	}

	public static function daC4d82F05378662($F26087d31c2bbe4d, $d81f27c553f73ff4 = 0)
	{
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'monitor.php ' . intval($F26087d31c2bbe4d) . ' ' . intval($d81f27c553f73ff4) . ' >/dev/null 2>/dev/null &');

		return true;
	}

	public static function startProxy($F26087d31c2bbe4d)
	{
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'proxy.php ' . intval($F26087d31c2bbe4d) . ' >/dev/null 2>/dev/null &');

		return true;
	}

	public static function bC6AAAb975e5678C($F26087d31c2bbe4d)
	{
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'thumbnail.php ' . intval($F26087d31c2bbe4d) . ' >/dev/null 2>/dev/null &');

		return true;
	}

	public static function cE7106285C19a01A($F26087d31c2bbe4d, $b91591a6218018bb = false)
	{
		shell_exec("kill -9 `ps -ef | grep '/" . intval($F26087d31c2bbe4d) . ".' | grep -v grep | awk '{print \$2}'`;");

		if ($b91591a6218018bb) {
			exec('rm ' . XUI_HOME . 'content/vod/' . intval($F26087d31c2bbe4d) . '.*');
		} else {
			self::$db->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`, `cache`) VALUES(?, ?, ?, 1);', SERVER_ID, time(), json_encode(array('type' => 'delete_vod', 'id' => $F26087d31c2bbe4d)));
		}

		self::$db->query('UPDATE `streams_servers` SET `bitrate` = NULL,`current_source` = NULL,`to_analyze` = 0,`pid` = NULL,`stream_started` = NULL,`stream_info` = NULL,`audio_codec` = NULL,`video_codec` = NULL,`resolution` = NULL,`compatible` = 0,`stream_status` = 0 WHERE `stream_id` = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);
		self::afA0f3ffb001B9be($F26087d31c2bbe4d);
	}

	public static function queueMovie($F26087d31c2bbe4d, $d58b4f8653a391d8 = null)
	{
		if ($d58b4f8653a391d8) {
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		self::$db->query('DELETE FROM `queue` WHERE `stream_id` = ? AND `server_id` = ?;', $F26087d31c2bbe4d, $d58b4f8653a391d8);
		self::$db->query("INSERT INTO `queue`(`type`, `stream_id`, `server_id`, `added`) VALUES('movie', ?, ?, ?);", $F26087d31c2bbe4d, $d58b4f8653a391d8, time());
	}

	public static function queueMovies($Cdb85875fd50f459, $d58b4f8653a391d8 = null)
	{
		if ($d58b4f8653a391d8) {
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		if (0 >= count($Cdb85875fd50f459)) {
		} else {
			self::$db->query('DELETE FROM `queue` WHERE `stream_id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ') AND `server_id` = ?;', $d58b4f8653a391d8);
			$A6d7047f2fda966c = '';

			foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
				if (0 >= $F26087d31c2bbe4d) {
				} else {
					$A6d7047f2fda966c .= "('movie', " . intval($F26087d31c2bbe4d) . ', ' . intval($d58b4f8653a391d8) . ', ' . time() . '),';
				}
			}

			if (empty($A6d7047f2fda966c)) {
			} else {
				$A6d7047f2fda966c = rtrim($A6d7047f2fda966c, ',');
				self::$db->query('INSERT INTO `queue`(`type`, `stream_id`, `server_id`, `added`) VALUES ' . $A6d7047f2fda966c . ';');
			}
		}
	}

	public static function refreshMovies($Aa8c918a2a91966f, $E379394c7b1a273f = 1)
	{
		if (0 >= count($Aa8c918a2a91966f)) {
		} else {
			self::$db->query('DELETE FROM `watch_refresh` WHERE `type` = ? AND `stream_id` IN (' . implode(',', array_map('intval', $Aa8c918a2a91966f)) . ');', $E379394c7b1a273f);
			$A6d7047f2fda966c = '';

			foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
				if (0 >= $C3c8913edb801c35) {
				} else {
					$A6d7047f2fda966c .= '(' . intval($E379394c7b1a273f) . ', ' . intval($C3c8913edb801c35) . ', 0),';
				}
			}

			if (empty($A6d7047f2fda966c)) {
			} else {
				$A6d7047f2fda966c = rtrim($A6d7047f2fda966c, ',');
				self::$db->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES ' . $A6d7047f2fda966c . ';');
			}
		}
	}

	public static function ED56A02053a7dD1f($F26087d31c2bbe4d)
	{
		$f523e362fb81d6c8 = array();
		self::$db->query('SELECT * FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type AND t2.live = 0 LEFT JOIN `profiles` t4 ON t1.transcode_profile_id = t4.profile_id WHERE t1.direct_source = 0 AND t1.id = ?', $F26087d31c2bbe4d);

		if (self::$db->num_rows() > 0) {
			$f523e362fb81d6c8['stream_info'] = self::$db->get_row();
			self::$db->query('SELECT * FROM `streams_servers` WHERE stream_id  = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);

			if (self::$db->num_rows() > 0) {
				$f523e362fb81d6c8['server_info'] = self::$db->get_row();
				self::$db->query('SELECT t1.*, t2.* FROM `streams_options` t1, `streams_arguments` t2 WHERE t1.stream_id = ? AND t1.argument_id = t2.id', $F26087d31c2bbe4d);
				$f523e362fb81d6c8['stream_arguments'] = self::$db->get_rows();
				list($ecc9029bfbc77eed) = json_decode($f523e362fb81d6c8['stream_info']['stream_source'], true);

				if (substr($ecc9029bfbc77eed, 0, 2) == 's:') {
					$A54349e51a0595df = explode(':', $ecc9029bfbc77eed, 3);
					$bbf6b6364a5f68a4 = $A54349e51a0595df[1];

					if ($bbf6b6364a5f68a4 != SERVER_ID) {
						$d845052e64fd1022 = self::$rServers[$bbf6b6364a5f68a4]['api_url'] . '&action=getFile&filename=' . urlencode($A54349e51a0595df[2]);
					} else {
						$d845052e64fd1022 = $A54349e51a0595df[2];
					}

					$C6033ec178efa2ae = null;
				} else {
					if (substr($ecc9029bfbc77eed, 0, 1) == '/') {
						$bbf6b6364a5f68a4 = SERVER_ID;
						$d845052e64fd1022 = $ecc9029bfbc77eed;
						$C6033ec178efa2ae = null;
					} else {
						$C6033ec178efa2ae = substr($ecc9029bfbc77eed, 0, strpos($ecc9029bfbc77eed, '://'));
						$d845052e64fd1022 = str_replace(' ', '%20', $ecc9029bfbc77eed);
						$ffce8f666f9d039c = implode(' ', self::A4c93c52F5D2d72d($f523e362fb81d6c8['stream_arguments'], $C6033ec178efa2ae, 'fetch'));
					}
				}

				if ((isset($bbf6b6364a5f68a4) && $bbf6b6364a5f68a4 == SERVER_ID || file_exists($d845052e64fd1022)) && $f523e362fb81d6c8['stream_info']['movie_symlink'] == 1) {
					$D59cad1840440e04 = 'ln -sfn ' . escapeshellarg($d845052e64fd1022) . ' ' . VOD_PATH . intval($F26087d31c2bbe4d) . '.' . escapeshellcmd(pathinfo($d845052e64fd1022)['extension']) . ' >/dev/null 2>/dev/null & echo $! > ' . VOD_PATH . intval($F26087d31c2bbe4d) . '_.pid';
				} else {
					$Eeedbc996b3feb87 = json_decode($f523e362fb81d6c8['stream_info']['movie_subtitles'], true);
					$a72d3a836b5f8b87 = '';

					for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($Eeedbc996b3feb87['files']); $Ea22c4a9ab5b2176++) {
						$d23c38c09c7c6dbc = escapeshellarg($Eeedbc996b3feb87['files'][$Ea22c4a9ab5b2176]);
						$F9969fc249582b23 = escapeshellarg($Eeedbc996b3feb87['charset'][$Ea22c4a9ab5b2176]);

						if ($Eeedbc996b3feb87['location'] == SERVER_ID) {
							$a72d3a836b5f8b87 .= '-sub_charenc ' . $F9969fc249582b23 . ' -i ' . $d23c38c09c7c6dbc . ' ';
						} else {
							$a72d3a836b5f8b87 .= '-sub_charenc ' . $F9969fc249582b23 . ' -i "' . self::$rServers[$Eeedbc996b3feb87['location']]['api_url'] . '&action=getFile&filename=' . urlencode($d23c38c09c7c6dbc) . '" ';
						}
					}
					$D2db3d503de3a5de = '';

					for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($Eeedbc996b3feb87['files']); $Ea22c4a9ab5b2176++) {
						$D2db3d503de3a5de .= '-map ' . ($Ea22c4a9ab5b2176 + 1) . ' -metadata:s:s:' . $Ea22c4a9ab5b2176 . ' title=' . escapeshellcmd($Eeedbc996b3feb87['names'][$Ea22c4a9ab5b2176]) . ' -metadata:s:s:' . $Ea22c4a9ab5b2176 . ' language=' . escapeshellcmd($Eeedbc996b3feb87['names'][$Ea22c4a9ab5b2176]) . ' ';
					}

					if ($f523e362fb81d6c8['stream_info']['read_native'] == 1) {
						$D0607bae080293c1 = '-re';
					} else {
						$D0607bae080293c1 = '';
					}

					if ($f523e362fb81d6c8['stream_info']['enable_transcode'] == 1) {
						if ($f523e362fb81d6c8['stream_info']['transcode_profile_id'] == -1) {
							$f523e362fb81d6c8['stream_info']['transcode_attributes'] = array_merge(self::a4c93c52F5D2D72D($f523e362fb81d6c8['stream_arguments'], $C6033ec178efa2ae, 'transcode'), json_decode($f523e362fb81d6c8['stream_info']['transcode_attributes'], true));
						} else {
							$f523e362fb81d6c8['stream_info']['transcode_attributes'] = json_decode($f523e362fb81d6c8['stream_info']['profile_options'], true);
						}
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes'] = array();
					}

					$a35d06dcea116901 = (isset($f523e362fb81d6c8['stream_info']['transcode_attributes'][16]) && !$feb762ab0abc1ea0 ? $f523e362fb81d6c8['stream_info']['transcode_attributes'][16]['cmd'] : '');
					$af3d0e7328416f86 = (isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']) ? $f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']['cmd'] : '');
					$D36982f48af7b142 = '';

					if (empty($af3d0e7328416f86)) {
					} else {
						$e4cfabbf1b1ea27e = self::C8851b830a0692cd($d845052e64fd1022);

						if (!in_array($e4cfabbf1b1ea27e['codecs']['video']['codec_name'], array('h264', 'hevc', 'mjpeg', 'mpeg1', 'mpeg2', 'mpeg4', 'vc1', 'vp8', 'vp9'))) {
						} else {
							$D36982f48af7b142 = '-c:v ' . $e4cfabbf1b1ea27e['codecs']['video']['codec_name'] . '_cuvid';
						}
					}

					$D59cad1840440e04 = ((isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']) ? self::$rFFMPEG_GPU : self::$rFFMPEG_CPU)) . ' -y -nostdin -hide_banner -loglevel ' . ((self::$rSettings['ffmpeg_warnings'] ? 'warning' : 'error')) . ' -err_detect ignore_err {GPU} {FETCH_OPTIONS} -fflags +genpts -async 1 {READ_NATIVE} -i {STREAM_SOURCE} {LOGO} ' . $a72d3a836b5f8b87;
					$D67755bf4741426c = '-map 0 -copy_unknown ';

					if (!empty($f523e362fb81d6c8['stream_info']['custom_map'])) {
						$D67755bf4741426c = escapeshellcmd($f523e362fb81d6c8['stream_info']['custom_map']) . ' -copy_unknown ';
					} else {
						if ($f523e362fb81d6c8['stream_info']['remove_subtitles'] != 1) {
						} else {
							$D67755bf4741426c = '-map 0:a -map 0:v';
						}
					}

					if (array_key_exists('-acodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-acodec'] = 'copy';
					}

					if (array_key_exists('-vcodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-vcodec'] = 'copy';
					}

					if ($f523e362fb81d6c8['stream_info']['target_container'] == 'mp4') {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-scodec'] = 'mov_text';
					} else {
						if ($f523e362fb81d6c8['stream_info']['target_container'] == 'mkv') {
							$f523e362fb81d6c8['stream_info']['transcode_attributes']['-scodec'] = 'srt';
						} else {
							$f523e362fb81d6c8['stream_info']['transcode_attributes']['-scodec'] = 'copy';
						}
					}

					$C5c92158885984fd = array();
					$C5c92158885984fd[$f523e362fb81d6c8['stream_info']['target_container']] = '-movflags +faststart -dn ' . $D67755bf4741426c . ' -ignore_unknown ' . $D2db3d503de3a5de . ' ' . VOD_PATH . intval($F26087d31c2bbe4d) . '.' . escapeshellcmd($f523e362fb81d6c8['stream_info']['target_container']);

					foreach ($C5c92158885984fd as $B5179d3aa5ad70dd => $c6373985d9e9bb45) {
						$D59cad1840440e04 .= implode(' ', self::f40647dE56f1867D($f523e362fb81d6c8['stream_info']['transcode_attributes'])) . ' ';
						$D59cad1840440e04 .= $c6373985d9e9bb45;
					}
					$D59cad1840440e04 .= ' >/dev/null 2>' . VOD_PATH . intval($F26087d31c2bbe4d) . '.errors & echo $! > ' . VOD_PATH . intval($F26087d31c2bbe4d) . '_.pid';
					$D59cad1840440e04 = str_replace(array('{GPU}', '{INPUT_CODEC}', '{LOGO}', '{FETCH_OPTIONS}', '{STREAM_SOURCE}', '{READ_NATIVE}'), array($af3d0e7328416f86, $D36982f48af7b142, $a35d06dcea116901, (empty($ffce8f666f9d039c) ? '' : $ffce8f666f9d039c), escapeshellarg($d845052e64fd1022), (empty($f523e362fb81d6c8['stream_info']['custom_ffmpeg']) ? $D0607bae080293c1 : '')), $D59cad1840440e04);
				}

				shell_exec($D59cad1840440e04);
				file_put_contents(VOD_PATH . $F26087d31c2bbe4d . '_.ffmpeg', $D59cad1840440e04);
				$f9b07d216a168dcc = intval(file_get_contents(VOD_PATH . $F26087d31c2bbe4d . '_.pid'));
				self::$db->query('UPDATE `streams_servers` SET `to_analyze` = 1,`stream_started` = ?,`stream_status` = 0,`pid` = ? WHERE `stream_id` = ? AND `server_id` = ?', time(), $f9b07d216a168dcc, $F26087d31c2bbe4d, SERVER_ID);
				self::aFA0F3ffB001B9bE($F26087d31c2bbe4d);

				return $f9b07d216a168dcc;
			}

			return false;
		}

		return false;
	}

	public static function A52d5062b20aE826($F5bd74e6a8ba5c58)
	{
		$Bc16cc77a681d1ed = false;
		$Caecf2bcd39a1efe = false;
		$B211d7401e6242f3 = explode(';', $F5bd74e6a8ba5c58);

		foreach ($B211d7401e6242f3 as $Eb40a01879a37d71) {
			list($D3fa098be3f297cd, $b6842cb20051e925) = explode('=', $Eb40a01879a37d71, 1);

			if (strtolower($D3fa098be3f297cd) == 'path') {
				$Bc16cc77a681d1ed = true;
			} else {
				if (strtolower($D3fa098be3f297cd) != 'domain') {
				} else {
					$Caecf2bcd39a1efe = true;
				}
			}
		}

		if (!substr($F5bd74e6a8ba5c58, -1) != ';') {
		} else {
			$F5bd74e6a8ba5c58 .= ';';
		}

		if ($Bc16cc77a681d1ed) {
		} else {
			$F5bd74e6a8ba5c58 .= 'path=/;';
		}

		if ($Caecf2bcd39a1efe) {
		} else {
			$F5bd74e6a8ba5c58 .= 'domain=;';
		}

		return $F5bd74e6a8ba5c58;
	}

	public static function b4A8D88202193a1D($F26087d31c2bbe4d)
	{
	}

	public static function E5D50da8f3ab33b2($F26087d31c2bbe4d, $bb0071da5a239b0c, $f86c7f12032c787a, $D9b6e988c8c78276 = null)
	{
		shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*.ts');

		if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
		} else {
			unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid');
		}

		$bbfc9bd8432031f5 = ($D9b6e988c8c78276 ? array($D9b6e988c8c78276) : json_decode($bb0071da5a239b0c['stream_source'], true));
		$Ed2c3a26f896baf7 = array();

		foreach ($f86c7f12032c787a as $e19af2d024431b72) {
			$Ed2c3a26f896baf7[$e19af2d024431b72['argument_key']] = array('value' => $e19af2d024431b72['value'], 'argument_default_value' => $e19af2d024431b72['argument_default_value']);
		}
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'llod.php ' . intval($F26087d31c2bbe4d) . ' "' . base64_encode(json_encode($bbfc9bd8432031f5)) . '" "' . base64_encode(json_encode($Ed2c3a26f896baf7)) . '" >/dev/null 2>/dev/null & echo $! > ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.pid');
		$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
		$D3fa098be3f297cd = openssl_random_pseudo_bytes(16);
		file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.key', $D3fa098be3f297cd);
		$cea2fe9cb44ba9b9 = openssl_cipher_iv_length('AES-128-CBC');
		$e7ae92f8387d5936 = openssl_random_pseudo_bytes($cea2fe9cb44ba9b9);
		file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.iv', $e7ae92f8387d5936);
		self::$db->query('UPDATE `streams_servers` SET `delay_available_at` = ?,`to_analyze` = 0,`stream_started` = ?,`stream_info` = ?,`stream_status` = 2,`pid` = ?,`progress_info` = ?,`current_source` = ? WHERE `stream_id` = ? AND `server_id` = ?', null, time(), null, $f9b07d216a168dcc, json_encode(array()), $bbfc9bd8432031f5[0], $F26087d31c2bbe4d, SERVER_ID);
		self::afA0f3ffB001B9BE($F26087d31c2bbe4d);

		return array('main_pid' => $f9b07d216a168dcc, 'stream_source' => $bbfc9bd8432031f5[0], 'delay_enabled' => false, 'parent_id' => 0, 'delay_start_at' => null, 'playlist' => STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8', 'transcode' => false, 'offset' => 0);
	}

	public static function startLoopback($F26087d31c2bbe4d)
	{
		shell_exec('rm -f ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_*.ts');

		if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
		} else {
			unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid');
		}

		$f523e362fb81d6c8 = array();
		self::$db->query('SELECT * FROM `streams` WHERE direct_source = 0 AND id = ?', $F26087d31c2bbe4d);

		if (self::$db->num_rows() > 0) {
			$f523e362fb81d6c8['stream_info'] = self::$db->get_row();
			self::$db->query('SELECT * FROM `streams_servers` WHERE stream_id  = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);

			if (self::$db->num_rows() > 0) {
				$f523e362fb81d6c8['server_info'] = self::$db->get_row();

				if ($f523e362fb81d6c8['server_info']['parent_id'] != 0) {
					shell_exec(PHP_BIN . ' ' . CLI_PATH . 'loopback.php ' . intval($F26087d31c2bbe4d) . ' ' . intval($f523e362fb81d6c8['server_info']['parent_id']) . ' >/dev/null 2>/dev/null & echo $! > ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.pid');
					$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
					$D3fa098be3f297cd = openssl_random_pseudo_bytes(16);
					file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.key', $D3fa098be3f297cd);
					$cea2fe9cb44ba9b9 = openssl_cipher_iv_length('AES-128-CBC');
					$e7ae92f8387d5936 = openssl_random_pseudo_bytes($cea2fe9cb44ba9b9);
					file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.iv', $e7ae92f8387d5936);
					self::$db->query('UPDATE `streams_servers` SET `delay_available_at` = ?,`to_analyze` = 0,`stream_started` = ?,`stream_info` = ?,`stream_status` = 2,`pid` = ?,`progress_info` = ?,`current_source` = ? WHERE `stream_id` = ? AND `server_id` = ?', null, time(), null, $f9b07d216a168dcc, json_encode(array()), $bbfc9bd8432031f5[0], $F26087d31c2bbe4d, SERVER_ID);
					self::AFa0f3ffB001B9Be($F26087d31c2bbe4d);
					$e3019184fb1785ff = (!is_null(self::$rServers[SERVER_ID]['private_url_ip']) && !is_null(self::$rServers[$f523e362fb81d6c8['server_info']['parent_id']]['private_url_ip']) ? self::$rServers[$f523e362fb81d6c8['server_info']['parent_id']]['private_url_ip'] : self::$rServers[$f523e362fb81d6c8['server_info']['parent_id']]['public_url_ip']);

					return array('main_pid' => $f9b07d216a168dcc, 'stream_source' => $e3019184fb1785ff . 'admin/live?stream=' . intval($F26087d31c2bbe4d) . '&password=' . urlencode(self::$rSettings['live_streaming_pass']) . '&extension=ts', 'delay_enabled' => false, 'parent_id' => 0, 'delay_start_at' => null, 'playlist' => STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8', 'transcode' => false, 'offset' => 0);
				}

				return 0;
			}

			return false;
		}

		return false;
	}

	public static function Ec4e6c6A6aabE235($F26087d31c2bbe4d, $db93dbf6891e1fbe = false, $D9b6e988c8c78276 = null, $ac8b0e05fab6bfa0 = false, $Df3b27de030b3f6d = 0)
	{
		if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
		} else {
			unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid');
		}

		$f523e362fb81d6c8 = array();
		self::$db->query('SELECT * FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type AND t2.live = 1 LEFT JOIN `profiles` t4 ON t1.transcode_profile_id = t4.profile_id WHERE t1.direct_source = 0 AND t1.id = ?', $F26087d31c2bbe4d);

		if (self::$db->num_rows() > 0) {
			$f523e362fb81d6c8['stream_info'] = self::$db->get_row();
			self::$db->query('SELECT * FROM `streams_servers` WHERE stream_id  = ? AND `server_id` = ?', $F26087d31c2bbe4d, SERVER_ID);

			if (self::$db->num_rows() > 0) {
				$f523e362fb81d6c8['server_info'] = self::$db->get_row();
				self::$db->query('SELECT t1.*, t2.* FROM `streams_options` t1, `streams_arguments` t2 WHERE t1.stream_id = ? AND t1.argument_id = t2.id', $F26087d31c2bbe4d);
				$f523e362fb81d6c8['stream_arguments'] = self::$db->get_rows();

				if ($f523e362fb81d6c8['server_info']['on_demand'] == 1) {
					$c16539fff4ffd50f = intval($f523e362fb81d6c8['stream_info']['probesize_ondemand']);
					$a8d6b4f70a067a08 = '10000000';
				} else {
					$a8d6b4f70a067a08 = abs(intval(self::$rSettings['stream_max_analyze']));
					$c16539fff4ffd50f = abs(intval(self::$rSettings['probesize']));
				}

				$cd2a4260ef308305 = intval($a8d6b4f70a067a08 / 1000000) + self::$rSettings['probe_extra_wait'];
				$f4efda65b81ca641 = 'timeout ' . $cd2a4260ef308305 . ' ' . self::$rFFPROBE . ' {FETCH_OPTIONS} -probesize ' . $c16539fff4ffd50f . ' -analyzeduration ' . $a8d6b4f70a067a08 . ' {CONCAT} -i {STREAM_SOURCE} -v quiet -print_format json -show_streams -show_format';
				$ffce8f666f9d039c = array();
				$feb762ab0abc1ea0 = false;
				$db752e19806388c2 = 0;

				if (!$f523e362fb81d6c8['server_info']['parent_id']) {
					if ($f523e362fb81d6c8['stream_info']['type_key'] == 'created_live') {
						$bbfc9bd8432031f5 = array(CREATED_PATH . $F26087d31c2bbe4d . '_.list');

						if (0 >= $Df3b27de030b3f6d) {
						} else {
							$d02a587b6a72fddd = array();
							$E915d9aaa0a161dd = array();
							$a0e727eef95293df = json_decode($f523e362fb81d6c8['server_info']['cc_info'], true);

							foreach ($a0e727eef95293df as $bb2621204e39e62d) {
								$E915d9aaa0a161dd[$bb2621204e39e62d['path']] = intval(explode('.', $bb2621204e39e62d['seconds'])[0]);
							}
							$b474f9b1144a5e0e = 0;
							$C6f3cb4bd7753e67 = true;

							foreach (explode("\n", file_get_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.list')) as $bb2621204e39e62d) {
								list($Bc16cc77a681d1ed) = explode("'", explode("file '", $bb2621204e39e62d)[1]);

								if (!$Bc16cc77a681d1ed) {
								} else {
									if ($E915d9aaa0a161dd[$Bc16cc77a681d1ed]) {
										$C5034884ed44603a = $E915d9aaa0a161dd[$Bc16cc77a681d1ed];

										if ($b474f9b1144a5e0e <= $Df3b27de030b3f6d && $Df3b27de030b3f6d < $b474f9b1144a5e0e + $C5034884ed44603a) {
											$db752e19806388c2 = $b474f9b1144a5e0e;
											$d02a587b6a72fddd[] = $Bc16cc77a681d1ed;
										} else {
											if ($Df3b27de030b3f6d >= $b474f9b1144a5e0e + $C5034884ed44603a) {
											} else {
												$d02a587b6a72fddd[] = $Bc16cc77a681d1ed;
											}
										}

										$b474f9b1144a5e0e += $C5034884ed44603a;
									} else {
										$C6f3cb4bd7753e67 = false;
									}
								}
							}

							if (!$C6f3cb4bd7753e67) {
							} else {
								$bbfc9bd8432031f5 = array(CREATED_PATH . $F26087d31c2bbe4d . '_.tlist');
								$De954c61aecf9559 = '';

								foreach ($d02a587b6a72fddd as $bb2621204e39e62d) {
									$De954c61aecf9559 .= "file '" . $bb2621204e39e62d . "'" . "\n";
								}
								file_put_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.tlist', $De954c61aecf9559);
							}
						}
					} else {
						$bbfc9bd8432031f5 = json_decode($f523e362fb81d6c8['stream_info']['stream_source'], true);
					}

					if (0 >= count($bbfc9bd8432031f5)) {
					} else {
						if (!empty($D9b6e988c8c78276)) {
							$bbfc9bd8432031f5 = array($D9b6e988c8c78276);
						} else {
							if (self::$rSettings['priority_backup'] == 1) {
							} else {
								if (empty($f523e362fb81d6c8['server_info']['current_source'])) {
								} else {
									$Ac27cedcae486add = array_search($f523e362fb81d6c8['server_info']['current_source'], $bbfc9bd8432031f5);

									if ($Ac27cedcae486add === false) {
									} else {
										$Ea22c4a9ab5b2176 = 0;

										while ($Ea22c4a9ab5b2176 <= $Ac27cedcae486add) {
											$c9c7f5aa6e945b07 = $bbfc9bd8432031f5[$Ea22c4a9ab5b2176];
											unset($bbfc9bd8432031f5[$Ea22c4a9ab5b2176]);
											array_push($bbfc9bd8432031f5, $c9c7f5aa6e945b07);
											$Ea22c4a9ab5b2176++;
										}
										$bbfc9bd8432031f5 = array_values($bbfc9bd8432031f5);
									}
								}
							}
						}
					}
				} else {
					$feb762ab0abc1ea0 = true;

					if (!$f523e362fb81d6c8['server_info']['on_demand']) {
					} else {
						$ac8b0e05fab6bfa0 = true;
					}

					$e3019184fb1785ff = (!is_null(self::$rServers[SERVER_ID]['private_url_ip']) && !is_null(self::$rServers[$f523e362fb81d6c8['server_info']['parent_id']]['private_url_ip']) ? self::$rServers[$f523e362fb81d6c8['server_info']['parent_id']]['private_url_ip'] : self::$rServers[$f523e362fb81d6c8['server_info']['parent_id']]['public_url_ip']);
					$bbfc9bd8432031f5 = array($e3019184fb1785ff . 'admin/live?stream=' . intval($F26087d31c2bbe4d) . '&password=' . urlencode(self::$rSettings['live_streaming_pass']) . '&extension=ts');
				}

				if (!$f523e362fb81d6c8['server_info']['on_demand']) {
				} else {
					self::$rSegmentSettings['seg_type'] = 1;
				}

				if (!($f523e362fb81d6c8['stream_info']['type_key'] == 'created_live' && file_exists(CREATED_PATH . $F26087d31c2bbe4d . '_.info'))) {
				} else {
					self::$db->query('UPDATE `streams_servers` SET `cc_info` = ? WHERE `server_id` = ? AND `stream_id` = ?;', file_get_contents(CREATED_PATH . $F26087d31c2bbe4d . '_.info'), SERVER_ID, $F26087d31c2bbe4d);
				}

				if ($db93dbf6891e1fbe) {
				} else {
					self::E8382a1682c8db80($bbfc9bd8432031f5);
				}

				foreach ($bbfc9bd8432031f5 as $c8d91fcd2309e48a) {
					$Ce7e235cbd59b7c3 = false;
					$B7f18f2aa03cd644 = $c8d91fcd2309e48a;
					$ecc9029bfbc77eed = self::CE3bA3178bC00d1C($c8d91fcd2309e48a);
					echo 'Checking source: ' . $c8d91fcd2309e48a . "\n";
					$e97435234acb895c = parse_url($ecc9029bfbc77eed);
					$e1aa7b5f34c25c15 = ($feb762ab0abc1ea0 ? true : self::C7c23f3AAeA4f10E($ecc9029bfbc77eed));

					if (!($e1aa7b5f34c25c15 && !$feb762ab0abc1ea0 && self::$rSettings['send_xui_header'])) {
					} else {
						foreach (array_keys($f523e362fb81d6c8['stream_arguments']) as $C3c8913edb801c35) {
							if ($f523e362fb81d6c8['stream_arguments'][$C3c8913edb801c35]['argument_key'] != 'headers') {
							} else {
								$f523e362fb81d6c8['stream_arguments'][$C3c8913edb801c35]['value'] .= "\r\n" . 'X-XUI-Detect:1';
								$Ce7e235cbd59b7c3 = true;
							}
						}

						if ($Ce7e235cbd59b7c3) {
						} else {
							$f523e362fb81d6c8['stream_arguments'][] = array('value' => 'X-XUI-Detect:1', 'argument_key' => 'headers', 'argument_cat' => 'fetch', 'argument_wprotocol' => 'http', 'argument_type' => 'text', 'argument_cmd' => "-headers '%s" . "\r\n" . "'");
						}
					}

					$d056a6c82385a152 = $f523e362fb81d6c8['stream_arguments'];

					if (!($e1aa7b5f34c25c15 && $f523e362fb81d6c8['server_info']['on_demand'] == 1 && self::$rSettings['request_prebuffer'] == 1)) {
					} else {
						foreach (array_keys($f523e362fb81d6c8['stream_arguments']) as $C3c8913edb801c35) {
							if ($f523e362fb81d6c8['stream_arguments'][$C3c8913edb801c35]['argument_key'] != 'headers') {
							} else {
								$f523e362fb81d6c8['stream_arguments'][$C3c8913edb801c35]['value'] .= "\r\n" . 'X-XUI-Prebuffer:1';
								$Ce7e235cbd59b7c3 = true;
							}
						}

						if ($Ce7e235cbd59b7c3) {
						} else {
							$f523e362fb81d6c8['stream_arguments'][] = array('value' => 'X-XUI-Prebuffer:1', 'argument_key' => 'headers', 'argument_cat' => 'fetch', 'argument_wprotocol' => 'http', 'argument_type' => 'text', 'argument_cmd' => "-headers '%s" . "\r\n" . "'");
						}
					}

					foreach (array_keys($d056a6c82385a152) as $C3c8913edb801c35) {
						if ($d056a6c82385a152[$C3c8913edb801c35]['argument_key'] != 'headers') {
						} else {
							$d056a6c82385a152[$C3c8913edb801c35]['value'] .= "\r\n" . 'X-XUI-Prebuffer:1';
							$Ce7e235cbd59b7c3 = true;
						}
					}

					if ($Ce7e235cbd59b7c3) {
					} else {
						$d056a6c82385a152[] = array('value' => 'X-XUI-Prebuffer:1', 'argument_key' => 'headers', 'argument_cat' => 'fetch', 'argument_wprotocol' => 'http', 'argument_type' => 'text', 'argument_cmd' => "-headers '%s" . "\r\n" . "'");
					}

					$C6033ec178efa2ae = strtolower(substr($ecc9029bfbc77eed, 0, strpos($ecc9029bfbc77eed, '://')));
					$e622c64a8eac4664 = implode(' ', self::A4C93C52f5d2d72D($d056a6c82385a152, $C6033ec178efa2ae, 'fetch'));
					$ffce8f666f9d039c = implode(' ', self::a4c93c52f5d2d72d($f523e362fb81d6c8['stream_arguments'], $C6033ec178efa2ae, 'fetch'));

					if ($db93dbf6891e1fbe && file_exists(CACHE_TMP_PATH . md5($c8d91fcd2309e48a)) && time() - filemtime(CACHE_TMP_PATH . md5($c8d91fcd2309e48a)) <= 300) {
						$e4cfabbf1b1ea27e = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . md5($ecc9029bfbc77eed)));

						if (!($e4cfabbf1b1ea27e && (isset($e4cfabbf1b1ea27e['streams']) || isset($e4cfabbf1b1ea27e['codecs'])))) {
						} else {
							echo 'Got stream information via cache' . "\n";

							break;
						}
					} else {
						if (!($db93dbf6891e1fbe && file_exists(CACHE_TMP_PATH . md5($c8d91fcd2309e48a)))) {
						} else {
							$db93dbf6891e1fbe = false;
						}
					}

					if ($f523e362fb81d6c8['server_info']['on_demand'] && $ac8b0e05fab6bfa0) {
					} else {
						if (!($e1aa7b5f34c25c15 && self::$rSettings['api_probe'])) {
						} else {
							$d88a567c47b3ff49 = $e97435234acb895c['scheme'] . '://' . $e97435234acb895c['host'] . ':' . $e97435234acb895c['port'] . '/probe/' . base64_encode($e97435234acb895c['path']);
							$e4cfabbf1b1ea27e = json_decode(self::a2AF9198CFd841A1($d88a567c47b3ff49), true);

							if (!($e4cfabbf1b1ea27e && isset($e4cfabbf1b1ea27e['codecs']))) {
							} else {
								echo 'Got stream information via API' . "\n";

								break;
							}
						}

						$e4cfabbf1b1ea27e = json_decode(shell_exec(str_replace(array('{FETCH_OPTIONS}', '{CONCAT}', '{STREAM_SOURCE}'), array($e622c64a8eac4664, ($f523e362fb81d6c8['stream_info']['type_key'] == 'created_live' && !$f523e362fb81d6c8['server_info']['parent_id'] ? '-safe 0 -f concat' : ''), escapeshellarg($ecc9029bfbc77eed)), $f4efda65b81ca641)), true);

						if (!($e4cfabbf1b1ea27e && isset($e4cfabbf1b1ea27e['streams']))) {
						} else {
							echo 'Got stream information via ffprobe' . "\n";

							break;
						}
					}
				}

				if ($f523e362fb81d6c8['server_info']['on_demand'] && $ac8b0e05fab6bfa0) {
				} else {
					if (isset($e4cfabbf1b1ea27e['codecs'])) {
					} else {
						$e4cfabbf1b1ea27e = self::cEfc1CE0aDBB45d2($e4cfabbf1b1ea27e);
					}

					if (empty($e4cfabbf1b1ea27e)) {
						self::$db->query("UPDATE `streams_servers` SET `progress_info` = '',`to_analyze` = 0,`pid` = -1,`stream_status` = 1 WHERE `server_id` = ? AND `stream_id` = ?", SERVER_ID, $F26087d31c2bbe4d);

						return 0;
					}

					if ($db93dbf6891e1fbe) {
					} else {
						file_put_contents(CACHE_TMP_PATH . md5($c8d91fcd2309e48a), igbinary_serialize($e4cfabbf1b1ea27e));
					}
				}

				$Bd50e062416a884c = json_decode($f523e362fb81d6c8['stream_info']['external_push'], true);
				$a5a4263f3309ea34 = 'http://127.0.0.1:' . intval(self::$rServers[SERVER_ID]['http_broadcast_port']) . '/progress?stream_id=' . intval($F26087d31c2bbe4d);

				if (empty($f523e362fb81d6c8['stream_info']['custom_ffmpeg'])) {
					if ($feb762ab0abc1ea0) {
						$Be3590384c940166 = '{FETCH_OPTIONS}';
					} else {
						$Be3590384c940166 = '{GPU} {FETCH_OPTIONS}';
					}

					if ($f523e362fb81d6c8['stream_info']['stream_all'] == 1) {
						$D67755bf4741426c = '-map 0 -copy_unknown ';
					} else {
						if (!empty($f523e362fb81d6c8['stream_info']['custom_map'])) {
							$D67755bf4741426c = escapeshellcmd($f523e362fb81d6c8['stream_info']['custom_map']) . ' -copy_unknown ';
						} else {
							if ($f523e362fb81d6c8['stream_info']['type_key'] == 'radio_streams') {
								$D67755bf4741426c = '-map 0:a? ';
							} else {
								$D67755bf4741426c = '';
							}
						}
					}

					if (($f523e362fb81d6c8['stream_info']['gen_timestamps'] == 1 || empty($C6033ec178efa2ae)) && $f523e362fb81d6c8['stream_info']['type_key'] != 'created_live') {
						$e37f5b13ee277c9e = '-fflags +genpts -async 1';
					} else {
						if (!(in_array($e4cfabbf1b1ea27e['codecs']['audio']['codec_name'], array('ac3', 'eac3')) && self::$rSettings['dts_legacy_ffmpeg'])) {
						} else {
							self::$rFFMPEG_CPU = FFMPEG_BIN_40;
							self::$rFFPROBE = FFPROBE_BIN_40;
						}

						$d7da72bba87e0650 = (self::$rFFMPEG_CPU == FFMPEG_BIN_40 ? '-nofix_dts' : '');
						$e37f5b13ee277c9e = $d7da72bba87e0650 . ' -start_at_zero -copyts -vsync 0 -correct_ts_overflow 0 -avoid_negative_ts disabled -max_interleave_delta 0';
					}

					if (!$f523e362fb81d6c8['server_info']['parent_id'] && ($f523e362fb81d6c8['stream_info']['read_native'] == 1 || stristr($e4cfabbf1b1ea27e['container'], 'hls') && self::$rSettings['read_native_hls'] || empty($C6033ec178efa2ae) || stristr($e4cfabbf1b1ea27e['container'], 'mp4') || stristr($e4cfabbf1b1ea27e['container'], 'matroska'))) {
						$D0607bae080293c1 = '-re';
					} else {
						$D0607bae080293c1 = '';
					}

					if (!$f523e362fb81d6c8['server_info']['parent_id'] && $f523e362fb81d6c8['stream_info']['enable_transcode'] == 1 && $f523e362fb81d6c8['stream_info']['type_key'] != 'created_live') {
						if ($f523e362fb81d6c8['stream_info']['transcode_profile_id'] == -1) {
							$f523e362fb81d6c8['stream_info']['transcode_attributes'] = array_merge(self::A4c93C52F5D2d72d($f523e362fb81d6c8['stream_arguments'], $C6033ec178efa2ae, 'transcode'), json_decode($f523e362fb81d6c8['stream_info']['transcode_attributes'], true));
						} else {
							$f523e362fb81d6c8['stream_info']['transcode_attributes'] = json_decode($f523e362fb81d6c8['stream_info']['profile_options'], true);
						}
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes'] = array();
					}

					$D59cad1840440e04 = ((isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']) ? self::$rFFMPEG_GPU : self::$rFFMPEG_CPU)) . ' -y -nostdin -hide_banner -loglevel ' . ((self::$rSettings['ffmpeg_warnings'] ? 'warning' : 'error')) . ' -err_detect ignore_err ' . $Be3590384c940166 . ' {GEN_PTS} {READ_NATIVE} -probesize ' . $c16539fff4ffd50f . ' -analyzeduration ' . $a8d6b4f70a067a08 . ' -progress "' . $a5a4263f3309ea34 . '" {CONCAT} -i {STREAM_SOURCE} {LOGO} ';

					if (array_key_exists('-acodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-acodec'] = 'copy';
					}

					if (array_key_exists('-vcodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						$f523e362fb81d6c8['stream_info']['transcode_attributes']['-vcodec'] = 'copy';
					}

					if (array_key_exists('-scodec', $f523e362fb81d6c8['stream_info']['transcode_attributes'])) {
					} else {
						if (self::$rSegmentSettings['seg_type'] == 0) {
							$f523e362fb81d6c8['stream_info']['transcode_attributes']['-sn'] = '';
						} else {
							$f523e362fb81d6c8['stream_info']['transcode_attributes']['-scodec'] = 'copy';
						}
					}
				} else {
					$f523e362fb81d6c8['stream_info']['transcode_attributes'] = array();
					$D59cad1840440e04 = ((stripos($f523e362fb81d6c8['stream_info']['custom_ffmpeg'], 'nvenc') !== false ? self::$rFFMPEG_GPU : self::$rFFMPEG_CPU)) . ' -y -nostdin -hide_banner -loglevel ' . ((self::$rSettings['ffmpeg_warnings'] ? 'warning' : 'error')) . ' -progress "' . $a5a4263f3309ea34 . '" ' . $f523e362fb81d6c8['stream_info']['custom_ffmpeg'];
				}

				$C39cc828abe7b7b4 = ($ac8b0e05fab6bfa0 && !$feb762ab0abc1ea0 ? '-fflags nobuffer -flags low_delay -strict experimental' : '');
				$C5c92158885984fd = array();

				if ($feb762ab0abc1ea0) {
					$Be3590384c940166 = '{MAP}';
					$ee15494d54354e3f = '{MAP}';
					$D67755bf4741426c = '-map 0 -copy_unknown ';
				} else {
					$Be3590384c940166 = '{MAP} {LLOD}';
					$ee15494d54354e3f = '{MAP} {AAC_FILTER}';
				}

				if (self::$rSegmentSettings['seg_type'] == 0) {
					$d9efda01fa488883 = (self::$rSettings['ignore_keyframes'] ? '+split_by_time' : '');
					$C5c92158885984fd['mpegts'][] = $Be3590384c940166 . ' -individual_header_trailer 0 -f hls -hls_time ' . intval(self::$rSegmentSettings['seg_time']) . ' -hls_list_size ' . intval(self::$rSegmentSettings['seg_list_size']) . ' -hls_delete_threshold ' . intval(self::$rSegmentSettings['seg_delete_threshold']) . ' -hls_flags delete_segments+discont_start+omit_endlist' . $d9efda01fa488883 . ' -hls_segment_type mpegts -hls_segment_filename "' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_%d.ts" "' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.m3u8" ';
				} else {
					$d9efda01fa488883 = (self::$rSettings['ignore_keyframes'] ? ' -break_non_keyframes 1' : '');
					$C5c92158885984fd['mpegts'][] = $Be3590384c940166 . ' -individual_header_trailer 0 -f segment -segment_format mpegts -segment_time ' . intval(self::$rSegmentSettings['seg_time']) . ' -segment_list_size ' . intval(self::$rSegmentSettings['seg_list_size']) . ' -segment_format_options "mpegts_flags=+initial_discontinuity:mpegts_copyts=1" -segment_list_type m3u8 -segment_list_flags +live+delete' . $d9efda01fa488883 . ' -segment_list "' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.m3u8" "' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_%d.ts" ';
				}

				if ($f523e362fb81d6c8['stream_info']['rtmp_output'] != 1) {
				} else {
					$C5c92158885984fd['flv'][] = $ee15494d54354e3f . ' -f flv -flvflags no_duration_filesize rtmp://127.0.0.1:' . intval(self::$rServers[$f523e362fb81d6c8['server_info']['server_id']]['rtmp_port']) . '/live/' . intval($F26087d31c2bbe4d) . '?password=' . urlencode(self::$rSettings['live_streaming_pass']) . ' ';
				}

				if (empty($Bd50e062416a884c[SERVER_ID])) {
				} else {
					foreach ($Bd50e062416a884c[SERVER_ID] as $afd4a457c81b23c4) {
						$C5c92158885984fd['flv'][] = $ee15494d54354e3f . ' -f flv -flvflags no_duration_filesize ' . escapeshellarg($afd4a457c81b23c4) . ' ';
					}
				}

				$a35d06dcea116901 = (isset($f523e362fb81d6c8['stream_info']['transcode_attributes'][16]) && !$feb762ab0abc1ea0 ? $f523e362fb81d6c8['stream_info']['transcode_attributes'][16]['cmd'] : '');
				$af3d0e7328416f86 = (isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']) ? $f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']['cmd'] : '');
				$D36982f48af7b142 = '';

				if (empty($af3d0e7328416f86) || !in_array($e4cfabbf1b1ea27e['codecs']['video']['codec_name'], array('h264', 'hevc', 'mjpeg', 'mpeg1', 'mpeg2', 'mpeg4', 'vc1', 'vp8', 'vp9'))) {
				} else {
					$D36982f48af7b142 = '-c:v ' . $e4cfabbf1b1ea27e['codecs']['video']['codec_name'] . '_cuvid';
				}

				if (0 >= $f523e362fb81d6c8['stream_info']['delay_minutes'] || $f523e362fb81d6c8['server_info']['parent_id']) {
					foreach ($C5c92158885984fd as $B5179d3aa5ad70dd => $ac334cf1d304d78f) {
						foreach ($ac334cf1d304d78f as $c6373985d9e9bb45) {
							if (!isset($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu'])) {
							} else {
								$D59cad1840440e04 .= '-gpu ' . intval($f523e362fb81d6c8['stream_info']['transcode_attributes']['gpu']['device']) . ' ';
							}

							$D59cad1840440e04 .= implode(' ', self::F40647DE56F1867d($f523e362fb81d6c8['stream_info']['transcode_attributes'])) . ' ';
							$D59cad1840440e04 .= $c6373985d9e9bb45;
						}
					}
				} else {
					$Ee9039ea711fcca3 = 0;

					if (!file_exists(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8')) {
					} else {
						$e2f848a82a80c113 = file(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8');

						if (stristr($e2f848a82a80c113[count($e2f848a82a80c113) - 1], $F26087d31c2bbe4d . '_')) {
							if (!preg_match('/\\_(.*?)\\.ts/', $e2f848a82a80c113[count($e2f848a82a80c113) - 1], $b85ce31cd1118ad2)) {
							} else {
								$Ee9039ea711fcca3 = intval($b85ce31cd1118ad2[1]) + 1;
							}
						} else {
							if (!preg_match('/\\_(.*?)\\.ts/', $e2f848a82a80c113[count($e2f848a82a80c113) - 2], $b85ce31cd1118ad2)) {
							} else {
								$Ee9039ea711fcca3 = intval($b85ce31cd1118ad2[1]) + 1;
							}
						}

						if (file_exists(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8_old')) {
							file_put_contents(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8_old', file_get_contents(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8_old') . file_get_contents(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8'));
							shell_exec("sed -i '/EXTINF\\|.ts/!d' " . DELAY_PATH . intval($F26087d31c2bbe4d) . '_.m3u8_old');
						} else {
							copy(DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8', DELAY_PATH . intval($F26087d31c2bbe4d) . '_.m3u8_old');
						}
					}

					$D59cad1840440e04 .= implode(' ', self::f40647dE56F1867d($f523e362fb81d6c8['stream_info']['transcode_attributes'])) . ' ';

					if (self::$rSegmentSettings['seg_type'] == 0) {
						$D59cad1840440e04 .= '{MAP} -individual_header_trailer 0 -f hls -hls_time ' . intval(self::$rSegmentSettings['seg_time']) . ' -hls_list_size ' . intval($f523e362fb81d6c8['stream_info']['delay_minutes']) * 6 . ' -hls_delete_threshold 4 -start_number ' . $Ee9039ea711fcca3 . ' -hls_flags delete_segments+discont_start+omit_endlist -hls_segment_type mpegts -hls_segment_filename "' . DELAY_PATH . intval($F26087d31c2bbe4d) . '_%d.ts" "' . DELAY_PATH . intval($F26087d31c2bbe4d) . '_.m3u8" ';
					} else {
						$D59cad1840440e04 .= '{MAP} -individual_header_trailer 0 -f segment -segment_format mpegts -segment_time ' . intval(self::$rSegmentSettings['seg_time']) . ' -segment_list_size ' . intval($f523e362fb81d6c8['stream_info']['delay_minutes']) * 6 . ' -segment_start_number ' . $Ee9039ea711fcca3 . ' -segment_format_options "mpegts_flags=+initial_discontinuity:mpegts_copyts=1" -segment_list_type m3u8 -segment_list_flags +live+delete -segment_list "' . DELAY_PATH . intval($F26087d31c2bbe4d) . '_.m3u8" "' . DELAY_PATH . intval($F26087d31c2bbe4d) . '_%d.ts" ';
					}

					$a2f81559ef67859e = $f523e362fb81d6c8['stream_info']['delay_minutes'] * 60;

					if (0 >= $Ee9039ea711fcca3) {
					} else {
						$a2f81559ef67859e -= ($Ee9039ea711fcca3 - 1) * 10;

						if ($a2f81559ef67859e > 0) {
						} else {
							$a2f81559ef67859e = 0;
						}
					}
				}

				$D59cad1840440e04 .= ' >/dev/null 2>>' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '.errors & echo $! > ' . STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.pid';
				$D59cad1840440e04 = str_replace(array('{FETCH_OPTIONS}', '{GEN_PTS}', '{STREAM_SOURCE}', '{MAP}', '{READ_NATIVE}', '{CONCAT}', '{AAC_FILTER}', '{GPU}', '{INPUT_CODEC}', '{LOGO}', '{LLOD}'), array((empty($f523e362fb81d6c8['stream_info']['custom_ffmpeg']) ? $ffce8f666f9d039c : ''), (empty($f523e362fb81d6c8['stream_info']['custom_ffmpeg']) ? $e37f5b13ee277c9e : ''), escapeshellarg($ecc9029bfbc77eed), (empty($f523e362fb81d6c8['stream_info']['custom_ffmpeg']) ? $D67755bf4741426c : ''), (empty($f523e362fb81d6c8['stream_info']['custom_ffmpeg']) ? $D0607bae080293c1 : ''), ($f523e362fb81d6c8['stream_info']['type_key'] == 'created_live' && !$f523e362fb81d6c8['server_info']['parent_id'] ? '-safe 0 -f concat' : ''), (!stristr($e4cfabbf1b1ea27e['container'], 'flv') && $e4cfabbf1b1ea27e['codecs']['audio']['codec_name'] == 'aac' && $f523e362fb81d6c8['stream_info']['transcode_attributes']['-acodec'] == 'copy' ? '-bsf:a aac_adtstoasc' : ''), $af3d0e7328416f86, $D36982f48af7b142, $a35d06dcea116901, $C39cc828abe7b7b4), $D59cad1840440e04);
				shell_exec($D59cad1840440e04);
				file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.ffmpeg', $D59cad1840440e04);
				$D3fa098be3f297cd = openssl_random_pseudo_bytes(16);
				file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.key', $D3fa098be3f297cd);
				$cea2fe9cb44ba9b9 = openssl_cipher_iv_length('AES-128-CBC');
				$e7ae92f8387d5936 = openssl_random_pseudo_bytes($cea2fe9cb44ba9b9);
				file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.iv', $e7ae92f8387d5936);
				$f9b07d216a168dcc = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));

				if ($f523e362fb81d6c8['stream_info']['tv_archive_server_id'] != SERVER_ID) {
				} else {
					shell_exec(PHP_BIN . ' ' . CLI_PATH . 'archive.php ' . intval($F26087d31c2bbe4d) . ' >/dev/null 2>/dev/null & echo $!');
				}

				if ($f523e362fb81d6c8['stream_info']['vframes_server_id'] != SERVER_ID) {
				} else {
					self::bC6aaab975E5678C($F26087d31c2bbe4d);
				}

				$E4ecc26f7bf1f1b6 = 0 < $f523e362fb81d6c8['stream_info']['delay_minutes'] && !$f523e362fb81d6c8['server_info']['parent_id'];
				$B58f99fee900c2fe = ($E4ecc26f7bf1f1b6 ? time() + $a2f81559ef67859e : 0);

				if (!$f523e362fb81d6c8['stream_info']['enable_transcode']) {
				} else {
					$e4cfabbf1b1ea27e = array();
				}

				$f03f005ea6f01679 = 0;
				$Dd7dd922fac30f26 = $F2735dad02d30e84 = $fbf4f3f4868222b7 = null;

				if (!$e4cfabbf1b1ea27e) {
				} else {
					$f03f005ea6f01679 = intval(self::a267181c61bDfff9($e4cfabbf1b1ea27e));
					$Dd7dd922fac30f26 = ($e4cfabbf1b1ea27e['codecs']['audio']['codec_name'] ?: null);
					$F2735dad02d30e84 = ($e4cfabbf1b1ea27e['codecs']['video']['codec_name'] ?: null);
					$fbf4f3f4868222b7 = ($e4cfabbf1b1ea27e['codecs']['video']['height'] ?: null);

					if (!$fbf4f3f4868222b7) {
					} else {
						$fbf4f3f4868222b7 = self::CcEDFAEA1d970310(array(240, 360, 480, 576, 720, 1080, 1440, 2160), $fbf4f3f4868222b7);
					}
				}

				self::$db->query('UPDATE `streams_servers` SET `delay_available_at` = ?,`to_analyze` = 0,`stream_started` = ?,`stream_info` = ?,`audio_codec` = ?, `video_codec` = ?, `resolution` = ?,`compatible` = ?,`stream_status` = 2,`pid` = ?,`progress_info` = ?,`current_source` = ? WHERE `stream_id` = ? AND `server_id` = ?', $B58f99fee900c2fe, time(), json_encode($e4cfabbf1b1ea27e), $Dd7dd922fac30f26, $F2735dad02d30e84, $fbf4f3f4868222b7, $f03f005ea6f01679, $f9b07d216a168dcc, json_encode(array()), $c8d91fcd2309e48a, $F26087d31c2bbe4d, SERVER_ID);
				self::aFA0F3FFB001b9bE($F26087d31c2bbe4d);
				$bb62005ea7eb8380 = (!$E4ecc26f7bf1f1b6 ? STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8' : DELAY_PATH . $F26087d31c2bbe4d . '_.m3u8');

				return array('main_pid' => $f9b07d216a168dcc, 'stream_source' => $B7f18f2aa03cd644, 'delay_enabled' => $E4ecc26f7bf1f1b6, 'parent_id' => $f523e362fb81d6c8['server_info']['parent_id'], 'delay_start_at' => $B58f99fee900c2fe, 'playlist' => $bb62005ea7eb8380, 'transcode' => $f523e362fb81d6c8['stream_info']['enable_transcode'], 'offset' => $db752e19806388c2);
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public static function E8E86f3fB3Dc3f67($d7e6e8fcd8d94d98, $dbc1091ca2977adb)
	{
		if (substr($d7e6e8fcd8d94d98, 0, 3) == '-i ') {
			return -1;
		}

		return 1;
	}

	public static function A4C93C52F5d2d72D($dc0404bcfb9cd8f1, $C6033ec178efa2ae, $E379394c7b1a273f)
	{
		$a85e1b7d42c346a0 = array();

		if (empty($dc0404bcfb9cd8f1)) {
		} else {
			foreach ($dc0404bcfb9cd8f1 as $e539b23e2b25889e => $c830296a190faad8) {
				if ($c830296a190faad8['argument_cat'] == $E379394c7b1a273f && (is_null($c830296a190faad8['argument_wprotocol']) || stristr($C6033ec178efa2ae, $c830296a190faad8['argument_wprotocol']) || is_null($C6033ec178efa2ae))) {
					if ($c830296a190faad8['argument_key'] != 'cookie') {
					} else {
						$c830296a190faad8['value'] = self::a52d5062B20aE826($c830296a190faad8['value']);
					}

					if ($c830296a190faad8['argument_type'] == 'text') {
						$a85e1b7d42c346a0[] = sprintf($c830296a190faad8['argument_cmd'], $c830296a190faad8['value']);
					} else {
						$a85e1b7d42c346a0[] = $c830296a190faad8['argument_cmd'];
					}
				}
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function F40647de56F1867d($C4afe46ee5612bc9)
	{
		$e1ace189a3bc8c0a = array();

		foreach ($C4afe46ee5612bc9 as $D3fa098be3f297cd => $c830296a190faad8) {
			if (!($D3fa098be3f297cd == 'gpu' || $D3fa098be3f297cd == 'software_decoding' || $D3fa098be3f297cd == '16')) {
				if (!isset($c830296a190faad8['cmd'])) {
				} else {
					$C4afe46ee5612bc9[$D3fa098be3f297cd] = $c830296a190faad8 = $c830296a190faad8['cmd'];
				}

				if (!preg_match('/-filter_complex "(.*?)"/', $c830296a190faad8, $b85ce31cd1118ad2)) {
				} else {
					$C4afe46ee5612bc9[$D3fa098be3f297cd] = trim(str_replace($b85ce31cd1118ad2[0], '', $C4afe46ee5612bc9[$D3fa098be3f297cd]));
					$e1ace189a3bc8c0a[] = $b85ce31cd1118ad2[1];
				}
			}
		}

		if (empty($e1ace189a3bc8c0a)) {
		} else {
			$C4afe46ee5612bc9[] = '-filter_complex "' . implode(',', $e1ace189a3bc8c0a) . '"';
		}

		$F5f02185ba840f16 = array();

		foreach ($C4afe46ee5612bc9 as $D3fa098be3f297cd => $Baec69a68419246c) {
			if ($D3fa098be3f297cd != 'gpu' && $D3fa098be3f297cd != 'software_decoding') {
				if (is_numeric($D3fa098be3f297cd)) {
					$F5f02185ba840f16[] = $Baec69a68419246c;
				} else {
					$F5f02185ba840f16[] = $D3fa098be3f297cd . ' ' . $Baec69a68419246c;
				}
			}
		}
		$F5f02185ba840f16 = array_filter($F5f02185ba840f16);
		uasort($F5f02185ba840f16, array('XUI', 'customOrder'));

		return array_map('trim', array_values(array_filter($F5f02185ba840f16)));
	}

	public static function Ce3ba3178bc00d1C($C700a2b357e5ed65)
	{
		$C6033ec178efa2ae = strtolower(substr($C700a2b357e5ed65, 0, 4));

		if ($C6033ec178efa2ae == 'rtmp') {
			if (!stristr($C700a2b357e5ed65, '$OPT')) {
			} else {
				$B213d02f48d88809 = 'rtmp://$OPT:rtmp-raw=';
				$C700a2b357e5ed65 = trim(substr($C700a2b357e5ed65, stripos($C700a2b357e5ed65, $B213d02f48d88809) + strlen($B213d02f48d88809)));
			}

			$C700a2b357e5ed65 .= ' live=1 timeout=10';
		} else {
			if ($C6033ec178efa2ae != 'http') {
			} else {
				$c49f9d7aa0f9372a = array('livestream.com', 'ustream.tv', 'twitch.tv', 'vimeo.com', 'facebook.com', 'dailymotion.com', 'cnn.com', 'edition.cnn.com', 'youtube.com', 'youtu.be');
				$baba170ab02ca0bd = str_ireplace('www.', '', parse_url($C700a2b357e5ed65, PHP_URL_HOST));

				if (!in_array($baba170ab02ca0bd, $c49f9d7aa0f9372a)) {
				} else {
					$ce2460e0c52a99da = trim(shell_exec(YOUTUBE_BIN . ' ' . escapeshellarg($C700a2b357e5ed65) . ' -q --get-url --skip-download -f best'));
					list($C700a2b357e5ed65) = explode("\n", $ce2460e0c52a99da);
				}
			}
		}

		return $C700a2b357e5ed65;
	}

	public static function c7C23F3AaEA4F10E($C700a2b357e5ed65)
	{
		$Bc16cc77a681d1ed = parse_url($C700a2b357e5ed65)['path'];
		$cb261e066dc5f336 = count(explode('/', $Bc16cc77a681d1ed));
		$B71e407f03516d91 = array('/\\/auth\\/(.*)$/m' => 3, '/\\/play\\/(.*)$/m' => 3, '/\\/play\\/(.*)\\/(.*)$/m' => 4, '/\\/live\\/(.*)\\/(\\d+)$/m' => 4, '/\\/live\\/(.*)\\/(\\d+)\\.(.*)$/m' => 4, '/\\/(.*)\\/(.*)\\/(\\d+)\\.(.*)$/m' => 4, '/\\/(.*)\\/(.*)\\/(\\d+)$/m' => 4, '/\\/live\\/(.*)\\/(.*)\\/(\\d+)\\.(.*)$/m' => 5, '/\\/live\\/(.*)\\/(.*)\\/(\\d+)$/m' => 5);

		foreach ($B71e407f03516d91 as $A6d7047f2fda966c => $Aa8d8af3d37ca869) {
			if ($cb261e066dc5f336 != $Aa8d8af3d37ca869) {
			} else {
				preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

				if (0 >= count($b85ce31cd1118ad2)) {
				} else {
					return true;
				}
			}
		}

		return false;
	}

	public static function c5931cd0269d0A3D($b91591a6218018bb = false)
	{
		if ($b91591a6218018bb) {
		} else {
			$Eace02ff35917268 = self::Abb674425a8B1b0d('allowed_ips', 60);

			if ($Eace02ff35917268 === false) {
			} else {
				return $Eace02ff35917268;
			}
		}

		$D2fc52591d8dd160 = array('127.0.0.1', $_SERVER['SERVER_ADDR']);

		foreach (self::$rServers as $d58b4f8653a391d8 => $cc5f26dd881329b7) {
			if (empty($cc5f26dd881329b7['whitelist_ips'])) {
			} else {
				$D2fc52591d8dd160 = array_merge($D2fc52591d8dd160, json_decode($cc5f26dd881329b7['whitelist_ips'], true));
			}

			$D2fc52591d8dd160[] = $cc5f26dd881329b7['server_ip'];

			if (!$cc5f26dd881329b7['private_ip']) {
			} else {
				$D2fc52591d8dd160[] = $cc5f26dd881329b7['private_ip'];
			}

			foreach (explode(',', $cc5f26dd881329b7['domain_name']) as $c59ec257c284c894) {
				if (!filter_var($c59ec257c284c894, FILTER_VALIDATE_IP)) {
				} else {
					$D2fc52591d8dd160[] = $c59ec257c284c894;
				}
			}
		}

		if (empty(self::$rSettings['allowed_ips_admin'])) {
		} else {
			$D2fc52591d8dd160 = array_merge($D2fc52591d8dd160, explode(',', self::$rSettings['allowed_ips_admin']));
		}

		self::CC314074194522D2('allowed_ips', $D2fc52591d8dd160);

		return array_unique($D2fc52591d8dd160);
	}

	public static function D7Ca435aC70e9a78($D78ff1d0edade5eb = null, $a71afc14d6cd090d = null, $d5249dad8e8411b7 = null, $f741fb10659d3472 = false, $E7654bf2f4eff2fe = false, $c59ec257c284c894 = '')
	{
		$D4253f9520627819 = null;

		if (self::$rCached) {
			if (empty($d5249dad8e8411b7) && empty($D78ff1d0edade5eb) && strlen($a71afc14d6cd090d) == 32) {
				if (self::$rSettings['case_sensitive_line']) {
					$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_t_' . $a71afc14d6cd090d));
				} else {
					$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_t_' . strtolower($a71afc14d6cd090d)));
				}
			} else {
				if (!empty($a71afc14d6cd090d) && !empty($d5249dad8e8411b7)) {
					if (self::$rSettings['case_sensitive_line']) {
						$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_c_' . $a71afc14d6cd090d . '_' . $d5249dad8e8411b7));
					} else {
						$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_c_' . strtolower($a71afc14d6cd090d) . '_' . strtolower($d5249dad8e8411b7)));
					}
				} else {
					if (!empty($D78ff1d0edade5eb)) {
					} else {
						return false;
					}
				}
			}

			if (!$D78ff1d0edade5eb) {
			} else {
				$D4253f9520627819 = igbinary_unserialize(file_get_contents(LINES_TMP_PATH . 'line_i_' . $D78ff1d0edade5eb));
			}
		} else {
			if (empty($d5249dad8e8411b7) && empty($D78ff1d0edade5eb) && strlen($a71afc14d6cd090d) == 32) {
				self::$db->query('SELECT * FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 0 AND `access_token` = ? AND LENGTH(`access_token`) = 32', $a71afc14d6cd090d);
			} else {
				if (!empty($a71afc14d6cd090d) && !empty($d5249dad8e8411b7)) {
					self::$db->query('SELECT `lines`.*, `mag_devices`.`token` AS `mag_token` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` WHERE `username` = ? AND `password` = ? LIMIT 1', $a71afc14d6cd090d, $d5249dad8e8411b7);
				} else {
					if (!empty($D78ff1d0edade5eb)) {
						self::$db->query('SELECT `lines`.*, `mag_devices`.`token` AS `mag_token` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` WHERE `id` = ?', $D78ff1d0edade5eb);
					} else {
						return false;
					}
				}
			}

			if (0 >= self::$db->num_rows()) {
			} else {
				$D4253f9520627819 = self::$db->get_row();
			}
		}

		if (!$D4253f9520627819) {
			return false;
		}

		if (!self::$rCached) {
		} else {
			if (empty($d5249dad8e8411b7) && empty($D78ff1d0edade5eb) && strlen($a71afc14d6cd090d) == 32) {
				if ($a71afc14d6cd090d == $D4253f9520627819['access_token']) {
				} else {
					return false;
				}
			} else {
				if (empty($a71afc14d6cd090d) || empty($d5249dad8e8411b7)) {
				} else {
					if (!($a71afc14d6cd090d != $D4253f9520627819['username'] || $d5249dad8e8411b7 != $D4253f9520627819['password'])) {
					} else {
						return false;
					}
				}
			}
		}

		if (!(self::$rSettings['county_override_1st'] == 1 && empty($D4253f9520627819['forced_country']) && !empty($c59ec257c284c894) && $D4253f9520627819['max_connections'] == 1)) {
		} else {
			$D4253f9520627819['forced_country'] = self::b74F652C92CEc688($c59ec257c284c894)['registered_country']['iso_code'];

			if (self::$rCached) {
				self::Cf592c234dcD0B19('forced_country/' . $D4253f9520627819['id'], $D4253f9520627819['forced_country']);
			} else {
				self::$db->query('UPDATE `lines` SET `forced_country` = ? WHERE `id` = ?', $D4253f9520627819['forced_country'], $D4253f9520627819['id']);
			}
		}

		$D4253f9520627819['bouquet'] = json_decode($D4253f9520627819['bouquet'], true);
		$D4253f9520627819['allowed_ips'] = @array_filter(@array_map('trim', @json_decode($D4253f9520627819['allowed_ips'], true)));
		$D4253f9520627819['allowed_ua'] = @array_filter(@array_map('trim', @json_decode($D4253f9520627819['allowed_ua'], true)));
		$D4253f9520627819['allowed_outputs'] = array_map('intval', json_decode($D4253f9520627819['allowed_outputs'], true));
		$D4253f9520627819['output_formats'] = array();

		if (self::$rCached) {
			foreach (igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'output_formats')) as $C740da31596f24ef) {
				if (!in_array(intval($C740da31596f24ef['access_output_id']), $D4253f9520627819['allowed_outputs'])) {
				} else {
					$D4253f9520627819['output_formats'][] = $C740da31596f24ef['output_key'];
				}
			}
		} else {
			self::$db->query('SELECT `access_output_id`, `output_key` FROM `output_formats`;');

			foreach (self::$db->get_rows() as $C740da31596f24ef) {
				if (!in_array(intval($C740da31596f24ef['access_output_id']), $D4253f9520627819['allowed_outputs'])) {
				} else {
					$D4253f9520627819['output_formats'][] = $C740da31596f24ef['output_key'];
				}
			}
		}

		$D4253f9520627819['con_isp_name'] = null;
		$D4253f9520627819['isp_violate'] = 0;
		$D4253f9520627819['isp_is_server'] = 0;

		if (self::$rSettings['show_isps'] != 1 || empty($c59ec257c284c894)) {
		} else {
			$da7f3c43bffc92dd = self::eE2D851924a79e53($c59ec257c284c894);

			if (!is_array($da7f3c43bffc92dd)) {
			} else {
				if (empty($da7f3c43bffc92dd['isp'])) {
				} else {
					$D4253f9520627819['con_isp_name'] = $da7f3c43bffc92dd['isp'];
					$D4253f9520627819['isp_asn'] = $da7f3c43bffc92dd['autonomous_system_number'];
					$D4253f9520627819['isp_violate'] = self::e38afbcF35978bE3($D4253f9520627819['con_isp_name']);

					if (self::$rSettings['block_svp'] != 1) {
					} else {
						$D4253f9520627819['isp_is_server'] = intval(self::ACe0eaCBDe53512c($D4253f9520627819['isp_asn']));
					}
				}
			}

			if (!(!empty($D4253f9520627819['con_isp_name']) && self::$rSettings['enable_isp_lock'] == 1 && $D4253f9520627819['is_stalker'] == 0 && $D4253f9520627819['is_isplock'] == 1 && !empty($D4253f9520627819['isp_desc']) && strtolower($D4253f9520627819['con_isp_name']) != strtolower($D4253f9520627819['isp_desc']))) {
			} else {
				$D4253f9520627819['isp_violate'] = 1;
			}

			if (!($D4253f9520627819['isp_violate'] == 0 && strtolower($D4253f9520627819['con_isp_name']) != strtolower($D4253f9520627819['isp_desc']))) {
			} else {
				if (self::$rCached) {
					self::cf592c234DcD0B19('isp/' . $D4253f9520627819['id'], json_encode(array($D4253f9520627819['con_isp_name'], $D4253f9520627819['isp_asn'])));
				} else {
					self::$db->query('UPDATE `lines` SET `isp_desc` = ?, `as_number` = ? WHERE `id` = ?', $D4253f9520627819['con_isp_name'], $D4253f9520627819['isp_asn'], $D4253f9520627819['id']);
				}
			}
		}

		if (!$f741fb10659d3472) {
		} else {
			$e3f5a327db5b3930 = $c07a93bf577a961d = $d04121afcfd82dc3 = $A38b42a281e3c3cf = $B2fdaed180cd0049 = $b58b71142a808858 = array();

			foreach ($D4253f9520627819['bouquet'] as $C3c8913edb801c35) {
				if (!isset(self::$rBouquets[$C3c8913edb801c35]['streams'])) {
				} else {
					$B2fdaed180cd0049 = array_merge($B2fdaed180cd0049, self::$rBouquets[$C3c8913edb801c35]['streams']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['series'])) {
				} else {
					$b58b71142a808858 = array_merge($b58b71142a808858, self::$rBouquets[$C3c8913edb801c35]['series']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['channels'])) {
				} else {
					$e3f5a327db5b3930 = array_merge($e3f5a327db5b3930, self::$rBouquets[$C3c8913edb801c35]['channels']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['movies'])) {
				} else {
					$c07a93bf577a961d = array_merge($c07a93bf577a961d, self::$rBouquets[$C3c8913edb801c35]['movies']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['radios'])) {
				} else {
					$d04121afcfd82dc3 = array_merge($d04121afcfd82dc3, self::$rBouquets[$C3c8913edb801c35]['radios']);
				}
			}
			$D4253f9520627819['channel_ids'] = array_map('intval', array_unique($B2fdaed180cd0049));
			$D4253f9520627819['series_ids'] = array_map('intval', array_unique($b58b71142a808858));
			$D4253f9520627819['vod_ids'] = array_map('intval', array_unique($c07a93bf577a961d));
			$D4253f9520627819['live_ids'] = array_map('intval', array_unique($e3f5a327db5b3930));
			$D4253f9520627819['radio_ids'] = array_map('intval', array_unique($d04121afcfd82dc3));
		}

		$C150dcc8bd89c268 = array();
		$a0ab7ba3516bce7d = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'category_map'));

		foreach ($D4253f9520627819['bouquet'] as $C3c8913edb801c35) {
			$C150dcc8bd89c268 = array_merge($C150dcc8bd89c268, ($a0ab7ba3516bce7d[$C3c8913edb801c35] ?: array()));
		}
		$D4253f9520627819['category_ids'] = array_values(array_unique($C150dcc8bd89c268));

		return $D4253f9520627819;
	}

	public static function cC61DbEfE4F00951()
	{
		$a85e1b7d42c346a0 = array();

		foreach (self::$rCategories as $A1925ae53e9307eb) {
			if (!$A1925ae53e9307eb['is_adult']) {
			} else {
				$a85e1b7d42c346a0[] = intval($A1925ae53e9307eb['id']);
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function C4f66339524747c9($B9e15adb20cf8ff9 = null, $C3cdd40816db3399 = null, $f741fb10659d3472 = false, $Fb5c3920e31291eb = false, $E7654bf2f4eff2fe = false)
	{
		if (empty($B9e15adb20cf8ff9)) {
			self::$db->query('SELECT * FROM `mag_devices` WHERE `mac` = ?', base64_encode($C3cdd40816db3399));
		} else {
			self::$db->query('SELECT * FROM `mag_devices` WHERE `mag_id` = ?', $B9e15adb20cf8ff9);
		}

		if (0 >= self::$db->num_rows()) {
			return false;
		}

		$f9de1ed2c1a28abe = array();
		$f9de1ed2c1a28abe['mag_device'] = self::$db->get_row();
		$f9de1ed2c1a28abe['mag_device']['mac'] = base64_decode($f9de1ed2c1a28abe['mag_device']['mac']);
		$f9de1ed2c1a28abe['user_info'] = array();

		if (!($D4253f9520627819 = self::D7Ca435Ac70E9a78($f9de1ed2c1a28abe['mag_device']['user_id'], null, null, $f741fb10659d3472, $E7654bf2f4eff2fe))) {
		} else {
			$f9de1ed2c1a28abe['user_info'] = $D4253f9520627819;
		}

		$f9de1ed2c1a28abe['pair_line_info'] = array();

		if (empty($f9de1ed2c1a28abe['user_info'])) {
		} else {
			$f9de1ed2c1a28abe['pair_line_info'] = array();

			if (is_null($f9de1ed2c1a28abe['user_info']['pair_id'])) {
			} else {
				if (!($D4253f9520627819 = self::d7ca435AC70E9A78($f9de1ed2c1a28abe['user_info']['pair_id'], null, null, $f741fb10659d3472, $E7654bf2f4eff2fe))) {
				} else {
					$f9de1ed2c1a28abe['pair_line_info'] = $D4253f9520627819;
				}
			}
		}

		return $f9de1ed2c1a28abe;
	}

	public static function fC10B2257ED1989A($cdc93dae5ba3d206, $f741fb10659d3472 = false, $Fb5c3920e31291eb = false, $E7654bf2f4eff2fe = false)
	{
		if (empty($cdc93dae5ba3d206['device_id'])) {
			self::$db->query('SELECT * FROM `enigma2_devices` WHERE `mac` = ?', $cdc93dae5ba3d206['mac']);
		} else {
			self::$db->query('SELECT * FROM `enigma2_devices` WHERE `device_id` = ?', $cdc93dae5ba3d206['device_id']);
		}

		if (0 >= self::$db->num_rows()) {
			return false;
		}

		$a85e1b7d42c346a0 = array();
		$a85e1b7d42c346a0['enigma2'] = self::$db->get_row();
		$a85e1b7d42c346a0['user_info'] = array();

		if (!($D4253f9520627819 = self::D7Ca435Ac70E9a78($a85e1b7d42c346a0['enigma2']['user_id'], null, null, $f741fb10659d3472, $E7654bf2f4eff2fe))) {
		} else {
			$a85e1b7d42c346a0['user_info'] = $D4253f9520627819;
		}

		$a85e1b7d42c346a0['pair_line_info'] = array();

		if (empty($a85e1b7d42c346a0['user_info'])) {
		} else {
			$a85e1b7d42c346a0['pair_line_info'] = array();

			if (is_null($a85e1b7d42c346a0['user_info']['pair_id'])) {
			} else {
				if (!($D4253f9520627819 = self::D7CA435Ac70e9a78($a85e1b7d42c346a0['user_info']['pair_id'], null, null, $f741fb10659d3472, $E7654bf2f4eff2fe))) {
				} else {
					$a85e1b7d42c346a0['pair_line_info'] = $D4253f9520627819;
				}
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function Cb312596CE3652d6()
	{
		$C700a2b357e5ed65 = self::$rServers[SERVER_ID]['rtmp_mport_url'] . 'stat';
		$B2976aadbf91a696 = stream_context_create(array('http' => array('timeout' => 1)));
		$cd4d474fc2ee8031 = file_get_contents($C700a2b357e5ed65, false, $B2976aadbf91a696);

		return json_decode(json_encode(simplexml_load_string($cd4d474fc2ee8031, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
	}

	public static function E8e9D6B2B107d8Ae($A9d34c0517e4c2a9, $b9919e6ef45bbbad = true, $ae0b1e2a40cbc62a = true)
	{
		if (!empty($A9d34c0517e4c2a9)) {
			if (!self::$rSettings['redis_handler'] || is_object(self::$redis)) {
			} else {
				self::BfA8b6fe314DED7f();
			}

			if (is_array($A9d34c0517e4c2a9)) {
			} else {
				if (!self::$rSettings['redis_handler']) {
					if (strlen(strval($A9d34c0517e4c2a9)) == 32) {
						self::$db->query('SELECT * FROM `lines_live` WHERE `uuid` = ?', $A9d34c0517e4c2a9);
					} else {
						self::$db->query('SELECT * FROM `lines_live` WHERE `activity_id` = ?', $A9d34c0517e4c2a9);
					}

					$A9d34c0517e4c2a9 = self::$db->get_row();
				} else {
					$A9d34c0517e4c2a9 = igbinary_unserialize(self::$redis->get($A9d34c0517e4c2a9));
				}
			}

			if (is_array($A9d34c0517e4c2a9)) {
				if ($A9d34c0517e4c2a9['container'] == 'rtmp') {
					if ($A9d34c0517e4c2a9['server_id'] == SERVER_ID) {
						shell_exec('wget --timeout=2 -O /dev/null -o /dev/null "' . self::$rServers[SERVER_ID]['rtmp_mport_url'] . 'control/drop/client?clientid=' . intval($A9d34c0517e4c2a9['pid']) . '" >/dev/null 2>/dev/null &');
					} else {
						if (self::$rSettings['redis_handler']) {
							self::aa941Cf79c4F48cF($A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id'], 1);
						} else {
							self::$db->query('INSERT INTO `signals` (`pid`,`server_id`,`rtmp`,`time`) VALUES(?,?,?,UNIX_TIMESTAMP())', $A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id'], 1);
						}
					}
				} else {
					if ($A9d34c0517e4c2a9['container'] == 'hls') {
						if (!(!$b9919e6ef45bbbad && $ae0b1e2a40cbc62a && $A9d34c0517e4c2a9['hls_end'] == 0)) {
						} else {
							if (self::$rSettings['redis_handler']) {
								self::e3484F74D3C8B5A7($A9d34c0517e4c2a9, array(), 'close');
							} else {
								self::$db->query('UPDATE `lines_live` SET `hls_end` = 1 WHERE `activity_id` = ?', $A9d34c0517e4c2a9['activity_id']);
							}

							@unlink(CONS_TMP_PATH . $A9d34c0517e4c2a9['stream_id'] . '/' . $A9d34c0517e4c2a9['uuid']);
						}
					} else {
						if ($A9d34c0517e4c2a9['server_id'] == SERVER_ID) {
							if (!($A9d34c0517e4c2a9['pid'] != getmypid() && is_numeric($A9d34c0517e4c2a9['pid']) && 0 < $A9d34c0517e4c2a9['pid'])) {
							} else {
								posix_kill(intval($A9d34c0517e4c2a9['pid']), 9);
							}
						} else {
							if (self::$rSettings['redis_handler']) {
								self::aA941cf79c4f48Cf($A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id'], 0);
							} else {
								self::$db->query('INSERT INTO `signals` (`pid`,`server_id`,`time`) VALUES(?,?,UNIX_TIMESTAMP())', $A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id']);
							}
						}
					}
				}

				if ($A9d34c0517e4c2a9['server_id'] != SERVER_ID) {
				} else {
					@unlink(CONS_TMP_PATH . $A9d34c0517e4c2a9['uuid']);
				}

				if (!$b9919e6ef45bbbad) {
				} else {
					if ($A9d34c0517e4c2a9['server_id'] != SERVER_ID) {
					} else {
						@unlink(CONS_TMP_PATH . $A9d34c0517e4c2a9['stream_id'] . '/' . $A9d34c0517e4c2a9['uuid']);
					}

					if (self::$rSettings['redis_handler']) {
						$F42a951cf0a3370a = self::$redis->multi();
						$F42a951cf0a3370a->zRem('LINE#' . $A9d34c0517e4c2a9['identity'], $A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->zRem('LINE_ALL#' . $A9d34c0517e4c2a9['identity'], $A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->zRem('STREAM#' . $A9d34c0517e4c2a9['stream_id'], $A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->zRem('SERVER#' . $A9d34c0517e4c2a9['server_id'], $A9d34c0517e4c2a9['uuid']);

						if (!$A9d34c0517e4c2a9['user_id']) {
						} else {
							$F42a951cf0a3370a->zRem('SERVER_LINES#' . $A9d34c0517e4c2a9['server_id'], $A9d34c0517e4c2a9['uuid']);
						}

						if (!$A9d34c0517e4c2a9['proxy_id']) {
						} else {
							$F42a951cf0a3370a->zRem('PROXY#' . $A9d34c0517e4c2a9['proxy_id'], $A9d34c0517e4c2a9['uuid']);
						}

						$F42a951cf0a3370a->del($A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->zRem('CONNECTIONS', $A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->zRem('LIVE', $A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->sRem('ENDED', $A9d34c0517e4c2a9['uuid']);
						$F42a951cf0a3370a->exec();
					} else {
						self::$db->query('DELETE FROM `lines_live` WHERE `activity_id` = ?', $A9d34c0517e4c2a9['activity_id']);
					}
				}

				self::DCFCfA5d9d05Df5A($A9d34c0517e4c2a9['server_id'], $A9d34c0517e4c2a9['proxy_id'], $A9d34c0517e4c2a9['user_id'], $A9d34c0517e4c2a9['stream_id'], $A9d34c0517e4c2a9['date_start'], $A9d34c0517e4c2a9['user_agent'], $A9d34c0517e4c2a9['user_ip'], $A9d34c0517e4c2a9['container'], $A9d34c0517e4c2a9['geoip_country_code'], $A9d34c0517e4c2a9['isp'], $A9d34c0517e4c2a9['external_device'], $A9d34c0517e4c2a9['divergence'], $A9d34c0517e4c2a9['hmac_id'], $A9d34c0517e4c2a9['hmac_identifier']);

				return true;
			}

			return false;
		}

		return false;
	}

	public static function DcFCFA5d9D05dF5a($d58b4f8653a391d8, $b2a9243e8304033d, $D78ff1d0edade5eb, $F26087d31c2bbe4d, $D031c48a1422c07e, $b3374866087774a1, $c59ec257c284c894, $F9452a7efafa1aba, $C4a76d9a69ca8231, $Fbe730b7a1211b54, $d080620e03289080 = '', $b25be5f9af7a0a91 = 0, $B08e7d3cd339391a = null, $E18c40e895ee55c2 = '')
	{
		if (self::$rSettings['save_closed_connection'] != 0) {
			if (!($d58b4f8653a391d8 && $D78ff1d0edade5eb && $F26087d31c2bbe4d)) {
			} else {
				$A9d34c0517e4c2a9 = array('user_id' => intval($D78ff1d0edade5eb), 'stream_id' => intval($F26087d31c2bbe4d), 'server_id' => intval($d58b4f8653a391d8), 'proxy_id' => intval($b2a9243e8304033d), 'date_start' => intval($D031c48a1422c07e), 'user_agent' => $b3374866087774a1, 'user_ip' => htmlentities($c59ec257c284c894), 'date_end' => time(), 'container' => $F9452a7efafa1aba, 'geoip_country_code' => $C4a76d9a69ca8231, 'isp' => $Fbe730b7a1211b54, 'external_device' => htmlentities($d080620e03289080), 'divergence' => intval($b25be5f9af7a0a91), 'hmac_id' => $B08e7d3cd339391a, 'hmac_identifier' => $E18c40e895ee55c2);
				file_put_contents(LOGS_TMP_PATH . 'activity', base64_encode(json_encode($A9d34c0517e4c2a9)) . "\n", FILE_APPEND | LOCK_EX);
			}
		} else {
			return null;
		}
	}

	public static function eFFEb9f2c8015C8A($F26087d31c2bbe4d, $d58b4f8653a391d8, $fa7da6c202358e0c, $c8d91fcd2309e48a = '')
	{
		if (self::$rSettings['save_restart_logs'] != 0) {
			$a27e64cc6ce01033 = array('server_id' => $d58b4f8653a391d8, 'stream_id' => $F26087d31c2bbe4d, 'action' => $fa7da6c202358e0c, 'source' => $c8d91fcd2309e48a, 'time' => time());
			file_put_contents(LOGS_TMP_PATH . 'stream_log.log', base64_encode(json_encode($a27e64cc6ce01033)) . "\n", FILE_APPEND);
		} else {
			return null;
		}
	}

	public static function d076f5A2CC104c49($bb62005ea7eb8380, $e1034511e63f0e9e = 0, $Ce2588e350bd2724 = 10)
	{
		if (!file_exists($bb62005ea7eb8380)) {
		} else {
			$c8d91fcd2309e48a = file_get_contents($bb62005ea7eb8380);

			if (!preg_match_all('/(.*?).ts/', $c8d91fcd2309e48a, $b85ce31cd1118ad2)) {
			} else {
				if (0 < $e1034511e63f0e9e) {
					$cef7095c03f82513 = intval($e1034511e63f0e9e / (($Ce2588e350bd2724 ?: 1)));

					return array_slice($b85ce31cd1118ad2[0], -1 * $cef7095c03f82513);
				}

				if ($e1034511e63f0e9e == -1) {
					return $b85ce31cd1118ad2[0];
				}

				preg_match('/_(.*)\\./', array_pop($b85ce31cd1118ad2[0]), $E415df512cb68430);

				return $E415df512cb68430[1];
			}
		}
	}

	public static function F116d0b6A51D41cF($dc05e2bb97d4635d, $d5249dad8e8411b7, $F26087d31c2bbe4d, $f6cb1b77556fb98a)
	{
		if (!file_exists($dc05e2bb97d4635d)) {
		} else {
			$c8d91fcd2309e48a = file_get_contents($dc05e2bb97d4635d);

			if (!preg_match_all('/(.*?)\\.ts/', $c8d91fcd2309e48a, $b85ce31cd1118ad2)) {
			} else {
				foreach ($b85ce31cd1118ad2[0] as $dbc0f67b4f0fdee0) {
					if ($f6cb1b77556fb98a) {
						$c8d91fcd2309e48a = str_replace($dbc0f67b4f0fdee0, '/admin/live?extension=m3u8&segment=' . $dbc0f67b4f0fdee0 . '&uitoken=' . $f6cb1b77556fb98a, $c8d91fcd2309e48a);
					} else {
						$c8d91fcd2309e48a = str_replace($dbc0f67b4f0fdee0, '/admin/live?password=' . $d5249dad8e8411b7 . '&extension=m3u8&segment=' . $dbc0f67b4f0fdee0 . '&stream=' . $F26087d31c2bbe4d, $c8d91fcd2309e48a);
					}
				}

				return $c8d91fcd2309e48a;
			}
		}

		return false;
	}

	public static function E416910CA4dA4695($b3374866087774a1, $a85e1b7d42c346a0 = false)
	{
		$b3374866087774a1 = strtolower($b3374866087774a1);
		$b62bd0478d66aff2 = false;

		foreach (self::$rBlockedUA as $D3fa098be3f297cd => $cda44bf16c8f250e) {
			if ($cda44bf16c8f250e['exact_match'] == 1) {
				if ($cda44bf16c8f250e['blocked_ua'] != $b3374866087774a1) {
				} else {
					$b62bd0478d66aff2 = $D3fa098be3f297cd;

					break;
				}
			} else {
				if (!stristr($b3374866087774a1, $cda44bf16c8f250e['blocked_ua'])) {
				} else {
					$b62bd0478d66aff2 = $D3fa098be3f297cd;

					break;
				}
			}
		}

		if (0 >= $b62bd0478d66aff2) {
		} else {
			self::$db->query('UPDATE `blocked_uas` SET `attempts_blocked` = `attempts_blocked`+1 WHERE `id` = ?', $b62bd0478d66aff2);

			if ($a85e1b7d42c346a0) {
				return true;
			}

			exit();
		}
	}

	public static function EA4A2063e98BaEF8($f9b07d216a168dcc, $F26087d31c2bbe4d, $acd3b41bac740313 = PHP_BIN)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($acd3b41bac740313)) === 0)) {
			} else {
				$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

				if (!($cf1c389bda3e30fd == 'XUI[' . $F26087d31c2bbe4d . ']' || $cf1c389bda3e30fd == 'XUIProxy[' . $F26087d31c2bbe4d . ']')) {
				} else {
					return true;
				}
			}

			return false;
		}

		return false;
	}

	public static function BB4b153536b0FB02($f9b07d216a168dcc, $F26087d31c2bbe4d, $acd3b41bac740313 = PHP_BIN)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($acd3b41bac740313)) === 0)) {
			} else {
				$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

				if ($cf1c389bda3e30fd != 'Thumbnail[' . $F26087d31c2bbe4d . ']') {
				} else {
					return true;
				}
			}

			return false;
		}

		return false;
	}

	public static function c6a27909F716cBeb($f9b07d216a168dcc, $F26087d31c2bbe4d, $acd3b41bac740313 = PHP_BIN)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($acd3b41bac740313)) === 0)) {
			} else {
				$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

				if ($cf1c389bda3e30fd != 'TVArchive[' . $F26087d31c2bbe4d . ']') {
				} else {
					return true;
				}
			}

			return false;
		}

		return false;
	}

	public static function A8CCfD5Db103a765($f9b07d216a168dcc, $F26087d31c2bbe4d)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe'))) {
			} else {
				$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

				if ($cf1c389bda3e30fd != 'XUIDelay[' . $F26087d31c2bbe4d . ']') {
				} else {
					return true;
				}
			}

			return false;
		}

		return false;
	}

	public static function f74FA4748B081619($f9b07d216a168dcc, $F26087d31c2bbe4d)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe'))) {
			} else {
				if (strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), 'ffmpeg') === 0) {
					$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

					if (!(stristr($cf1c389bda3e30fd, '/' . $F26087d31c2bbe4d . '_.m3u8') || stristr($cf1c389bda3e30fd, '/' . $F26087d31c2bbe4d . '_%d.ts'))) {
					} else {
						return true;
					}
				} else {
					if (strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), 'php') !== 0) {
					} else {
						return true;
					}
				}
			}

			return false;
		}

		return false;
	}

	public static function dD714EE89C59Fbf2($f9b07d216a168dcc, $acd3b41bac740313 = null)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($acd3b41bac740313)) === 0) && $acd3b41bac740313) {
				return false;
			}

			return true;
		}

		return false;
	}

	public static function A82B635b748C0318($bb62005ea7eb8380, $f9b07d216a168dcc)
	{
		return (self::dd714EE89c59fBF2($f9b07d216a168dcc, 'ffmpeg') || self::Dd714eE89C59fbf2($f9b07d216a168dcc, 'php')) && file_exists($bb62005ea7eb8380);
	}

	public static function findKeyframe($d55bf693d0ece21c)
	{
		$E15602e066cab9ca = 188;
		$c502afbe855cf486 = $Dfa7f7fd6a9f18a8 = 0;
		$c337c7b104d7cd79 = false;

		if (!file_exists($d55bf693d0ece21c)) {
		} else {
			$e1644d67f855686d = fopen($d55bf693d0ece21c, 'rb');

			if (!$e1644d67f855686d) {
			} else {
				while (!feof($e1644d67f855686d)) {
					if ($c337c7b104d7cd79) {
					} else {
						$Da031c633bef43e3 = fread($e1644d67f855686d, $E15602e066cab9ca);
						$Bb9bc27ca742e21f = fread($e1644d67f855686d, $E15602e066cab9ca);
						$Ea22c4a9ab5b2176 = 0;

						while ($Ea22c4a9ab5b2176 < strlen($Da031c633bef43e3)) {
							list(, $a59ebbe795126728) = unpack('N', substr($Da031c633bef43e3, $Ea22c4a9ab5b2176, 4));
							list(, $Fbf65de30154cb80) = unpack('N', substr($Bb9bc27ca742e21f, $Ea22c4a9ab5b2176, 4));
							$abc2466c5bfb1b17 = ($a59ebbe795126728 >> 24 & 255) == 71 && ($Fbf65de30154cb80 >> 24 & 255) == 71;

							if (!$abc2466c5bfb1b17) {
								$Ea22c4a9ab5b2176++;
							} else {
								$c337c7b104d7cd79 = true;
								$Dfa7f7fd6a9f18a8 = $Ea22c4a9ab5b2176;
								fseek($e1644d67f855686d, $Ea22c4a9ab5b2176);
							}
						}
					}

					$b9f3f039ea3bf5ca .= fread($e1644d67f855686d, $E15602e066cab9ca * 64 - strlen($b9f3f039ea3bf5ca));

					if (empty($b9f3f039ea3bf5ca)) {
					} else {
						foreach (str_split($b9f3f039ea3bf5ca, $E15602e066cab9ca) as $fe4c6aae49a89941) {
							list(, $Eb5dde5d027876ce) = unpack('N', substr($fe4c6aae49a89941, 0, 4));
							$abc2466c5bfb1b17 = $Eb5dde5d027876ce >> 24 & 255;

							if ($abc2466c5bfb1b17 != 71) {
							} else {
								if (substr($fe4c6aae49a89941, 6, 4) == '?' . '' . "\r" . '' . '' . '' . "\x01") {
									$c502afbe855cf486 = $Dfa7f7fd6a9f18a8;
								} else {
									$b49d848d5d4e13b6 = $Eb5dde5d027876ce >> 4 & 3;

									if (($b49d848d5d4e13b6 & 2) !== 2) {
									} else {
										if (!(0 < $c502afbe855cf486 && unpack('C', $fe4c6aae49a89941[4])[1] == 7 && substr($fe4c6aae49a89941, 4, 2) == "\x07" . 'P')) {
										} else {
											break;
										}
									}
								}
							}

							$Dfa7f7fd6a9f18a8 += strlen($fe4c6aae49a89941);
						}
					}

					$b9f3f039ea3bf5ca = '';
				}
				fclose($e1644d67f855686d);
			}
		}

		return $c502afbe855cf486;
	}

	public static function A9BC416FA6Fa55C3()
	{
		return $_SERVER['REMOTE_ADDR'];
	}

	public static function bB02b8e7d661C337($E379394c7b1a273f, $Bc16cc77a681d1ed, $ec3df080adee1613 = null)
	{
		clearstatcache();

		if (file_exists($Bc16cc77a681d1ed)) {
			switch ($E379394c7b1a273f) {
				case 'movie':
					if (is_null($ec3df080adee1613)) {
					} else {
						sscanf($ec3df080adee1613, '%d:%d:%d', $cfd208d2a440ee12, $D1b34eaa5eef40cc, $eff3c5536b319f0b);
						$C4af185e24cf9086 = (isset($eff3c5536b319f0b) ? $cfd208d2a440ee12 * 3600 + $D1b34eaa5eef40cc * 60 + $eff3c5536b319f0b : $cfd208d2a440ee12 * 60 + $D1b34eaa5eef40cc);
						$aa2e54fde620d6b3 = round((filesize($Bc16cc77a681d1ed) * 0.008) / (($C4af185e24cf9086 ?: 1)));
					}

					break;

				case 'live':
					$e1644d67f855686d = fopen($Bc16cc77a681d1ed, 'r');
					$E2cd63a70fcfd172 = array();

					while (!feof($e1644d67f855686d)) {
						$Ff014d0ebd314fcd = trim(fgets($e1644d67f855686d));

						if (!stristr($Ff014d0ebd314fcd, 'EXTINF')) {
						} else {
							list($E653e6cc956d8b61, $eff3c5536b319f0b) = explode(':', $Ff014d0ebd314fcd);
							$eff3c5536b319f0b = rtrim($eff3c5536b319f0b, ',');

							if ($eff3c5536b319f0b > 0) {
								$E8601dd191bcdbba = trim(fgets($e1644d67f855686d));

								if (file_exists(dirname($Bc16cc77a681d1ed) . '/' . $E8601dd191bcdbba)) {
									$b6c1b012e942c0b8 = filesize(dirname($Bc16cc77a681d1ed) . '/' . $E8601dd191bcdbba) * 0.008;
									$E2cd63a70fcfd172[] = $b6c1b012e942c0b8 / (($eff3c5536b319f0b ?: 1));
								} else {
									fclose($e1644d67f855686d);

									return false;
								}
							}
						}
					}
					fclose($e1644d67f855686d);
					$aa2e54fde620d6b3 = (0 < count($E2cd63a70fcfd172) ? round(array_sum($E2cd63a70fcfd172) / count($E2cd63a70fcfd172)) : 0);

					break;
			}

			return (0 < $aa2e54fde620d6b3 ? $aa2e54fde620d6b3 : false);
		}

		return false;
	}

	public static function EE2D851924a79e53($c59ec257c284c894)
	{
		if (!empty($c59ec257c284c894)) {
			if (!file_exists(CONS_TMP_PATH . md5($c59ec257c284c894) . '_isp')) {
				$C4a76d9a69ca8231 = new MaxMind\Db\Reader(GEOISP_BIN);
				$c7488e8420e934e2 = $C4a76d9a69ca8231->get($c59ec257c284c894);
				$C4a76d9a69ca8231->close();

				if (!$c7488e8420e934e2) {
				} else {
					file_put_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_isp', json_encode($c7488e8420e934e2));
				}

				return $c7488e8420e934e2;
			}

			return json_decode(file_get_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_isp'), true);
		}

		return false;
	}

	public static function E38AfBCF35978bE3($e11e06c11ab94fe2)
	{
		foreach (self::$rBlockedISP as $Fbe730b7a1211b54) {
			if (strtolower($e11e06c11ab94fe2) != strtolower($Fbe730b7a1211b54['isp'])) {
			} else {
				return intval($Fbe730b7a1211b54['blocked']);
			}
		}

		return 0;
	}

	public static function aCE0eacbde53512c($Fcd691b0388768ab)
	{
		return in_array($Fcd691b0388768ab, self::$rBlockedServers);
	}

	public static function b74F652c92cEc688($c59ec257c284c894)
	{
		if (!empty($c59ec257c284c894)) {
			if (!file_exists(CONS_TMP_PATH . md5($c59ec257c284c894) . '_geo2')) {
				$C4a76d9a69ca8231 = new MaxMind\Db\Reader(GEOLITE2_BIN);
				$c7488e8420e934e2 = $C4a76d9a69ca8231->get($c59ec257c284c894);
				$C4a76d9a69ca8231->close();

				if (!$c7488e8420e934e2) {
				} else {
					file_put_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_geo2', json_encode($c7488e8420e934e2));
				}

				return $c7488e8420e934e2;
			}

			return json_decode(file_get_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_geo2'), true);
		}

		return false;
	}

	public static function cae8387EDC1bF201()
	{
		$b9e33ce83162666c = 0;
		exec('ps -fp $(pgrep -u xui)', $f433193a3297ffde, $E072e4fd80a065b3);

		foreach ($f433193a3297ffde as $Df1e7eea7d843145) {
			$B211d7401e6242f3 = explode(' ', preg_replace('!\\s+!', ' ', trim($Df1e7eea7d843145)));

			if (!($B211d7401e6242f3[8] == 'nginx:' && $B211d7401e6242f3[9] == 'master')) {
			} else {
				$b9e33ce83162666c++;
			}
		}

		return 0 < $b9e33ce83162666c;
	}

	public static function ac86c84c80E63449($dd6503a196807aba = null)
	{
		$a85e1b7d42c346a0 = array('serial' => null, 'expiration' => null, 'subject' => null, 'path' => null);

		if ($dd6503a196807aba) {
		} else {
			$Df06db369f6b9832 = explode("\n", file_get_contents(BIN_PATH . 'nginx/conf/ssl.conf'));

			foreach ($Df06db369f6b9832 as $Ff014d0ebd314fcd) {
				if (stripos($Ff014d0ebd314fcd, 'ssl_certificate ') === false) {
				} else {
					$dd6503a196807aba = rtrim(trim(explode('ssl_certificate ', $Ff014d0ebd314fcd)[1]), ';');

					break;
				}
			}
		}

		if (!$dd6503a196807aba) {
		} else {
			$a85e1b7d42c346a0['path'] = pathinfo($dd6503a196807aba)['dirname'];
			exec('openssl x509 -serial -enddate -subject -noout -in ' . escapeshellarg($dd6503a196807aba), $f433193a3297ffde, $E072e4fd80a065b3);

			foreach ($f433193a3297ffde as $Ff014d0ebd314fcd) {
				if (stripos($Ff014d0ebd314fcd, 'serial=') !== false) {
					$a85e1b7d42c346a0['serial'] = trim(explode('serial=', $Ff014d0ebd314fcd)[1]);
				} else {
					if (stripos($Ff014d0ebd314fcd, 'subject=') !== false) {
						$a85e1b7d42c346a0['subject'] = trim(explode('subject=', $Ff014d0ebd314fcd)[1]);
					} else {
						if (stripos($Ff014d0ebd314fcd, 'notAfter=') === false) {
						} else {
							$a85e1b7d42c346a0['expiration'] = strtotime(trim(explode('notAfter=', $Ff014d0ebd314fcd)[1]));
						}
					}
				}
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function B2068ce8b339bF70($A639a7baefc720ee, $E379394c7b1a273f = null)
	{
		if (!(0 < strlen($A639a7baefc720ee) && substr(strtolower($A639a7baefc720ee), 0, 4) == 'http')) {
		} else {
			$d953b066e19239c1 = pathinfo($A639a7baefc720ee);
			$C6a7103a3e51b098 = $d953b066e19239c1['extension'];

			if ($C6a7103a3e51b098) {
			} else {
				$ec80f61435f9402e = getimagesize($A639a7baefc720ee);

				if (!$ec80f61435f9402e['mime']) {
				} else {
					list(, $C6a7103a3e51b098) = explode('/', $ec80f61435f9402e['mime']);
				}
			}

			if (!in_array(strtolower($C6a7103a3e51b098), array('jpg', 'jpeg', 'png'))) {
			} else {
				$bc2874292e0d9ece = Xui\Functions::encrypt($A639a7baefc720ee, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
				$b9d9701068b80f80 = IMAGES_PATH . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;

				if (file_exists($b9d9701068b80f80)) {
					return 's:' . SERVER_ID . ':/images/' . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;
				}

				$a0eb8eb80ccd233b = curl_init();
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_URL, $A639a7baefc720ee);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_CONNECTTIMEOUT, 5);
				curl_setopt($a0eb8eb80ccd233b, CURLOPT_TIMEOUT, 5);
				$a27e64cc6ce01033 = curl_exec($a0eb8eb80ccd233b);

				if (0 >= strlen($a27e64cc6ce01033)) {
				} else {
					$Bc16cc77a681d1ed = IMAGES_PATH . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;
					file_put_contents($Bc16cc77a681d1ed, $a27e64cc6ce01033);

					if (!file_exists($Bc16cc77a681d1ed)) {
					} else {
						return 's:' . SERVER_ID . ':/images/' . $bc2874292e0d9ece . '.' . $C6a7103a3e51b098;
					}
				}
			}
		}

		return $A639a7baefc720ee;
	}

	public static function F4e1807144Dd84EF($d8a4881c582e2a3b, $a6456d2c57df0603, $a0823d4a2de30431, $b61c83ca0fef311e)
	{
		if ($a0823d4a2de30431 != 0) {
		} else {
			$a0823d4a2de30431 = $d8a4881c582e2a3b;
		}

		if ($b61c83ca0fef311e != 0) {
		} else {
			$b61c83ca0fef311e = $a6456d2c57df0603;
		}

		$C6147bf9a509b6cb = $a0823d4a2de30431 / (($d8a4881c582e2a3b ?: 1));
		$b6448faba596a90d = $b61c83ca0fef311e / (($a6456d2c57df0603 ?: 1));
		$c8bc885ceee305ea = min($C6147bf9a509b6cb, $b6448faba596a90d);

		if ($c8bc885ceee305ea < 1) {
			$ce0e1db0c5b7c9b1 = (int) $d8a4881c582e2a3b * $c8bc885ceee305ea;
			$Cafa4c31cfd7ae7f = (int) $a6456d2c57df0603 * $c8bc885ceee305ea;
		} else {
			$Cafa4c31cfd7ae7f = $a6456d2c57df0603;
			$ce0e1db0c5b7c9b1 = $d8a4881c582e2a3b;
		}

		return array('height' => round($Cafa4c31cfd7ae7f, 0), 'width' => round($ce0e1db0c5b7c9b1, 0));
	}

	public static function e388AB16A4D83c5e($C700a2b357e5ed65)
	{
		$B213d02f48d88809 = "/^(?:ftp|https?|feed)?:?\\/\\/(?:(?:(?:[\\w\\.\\-\\+!\$&'\\(\\)*\\+,;=]|%[0-9a-f]{2})+:)*" . "\n" . "        (?:[\\w\\.\\-\\+%!\$&'\\(\\)*\\+,;=]|%[0-9a-f]{2})+@)?(?:" . "\n" . '        (?:[a-z0-9\\-\\.]|%[0-9a-f]{2})+|(?:\\[(?:[0-9a-f]{0,4}:)*(?:[0-9a-f]{0,4})\\]))(?::[0-9]+)?(?:[\\/|\\?]' . "\n" . "        (?:[\\w#!:\\.\\?\\+\\|=&@\$'~*,;\\/\\(\\)\\[\\]\\-]|%[0-9a-f]{2})*)?\$/xi";

		return (bool) preg_match($B213d02f48d88809, $C700a2b357e5ed65);
	}

	public static function F886d9808f2B2A64($A639a7baefc720ee, $E379394c7b1a273f)
	{
		if ($E379394c7b1a273f == 1 || $E379394c7b1a273f == 5 || $E379394c7b1a273f == 4) {
			$D8e1dc68b81d5702 = 96;
			$ea69abb4ad0055aa = 32;
		} else {
			if ($E379394c7b1a273f == 2) {
				$D8e1dc68b81d5702 = 58;
				$ea69abb4ad0055aa = 32;
			} else {
				if ($E379394c7b1a273f == 5) {
					$D8e1dc68b81d5702 = 32;
					$ea69abb4ad0055aa = 64;
				} else {
					return false;
				}
			}
		}

		list($F9452a7efafa1aba) = explode('.', strtolower(pathinfo($A639a7baefc720ee)['extension']));

		if (!in_array($F9452a7efafa1aba, array('png', 'jpg', 'jpeg'))) {
		} else {
			$cff016622381f6ab = IMAGES_PATH . 'admin/' . md5($A639a7baefc720ee) . '_' . $D8e1dc68b81d5702 . '_' . $ea69abb4ad0055aa . '.' . $F9452a7efafa1aba;

			if (file_exists($cff016622381f6ab)) {
			} else {
				if (self::e388ab16a4D83c5e($A639a7baefc720ee)) {
					$a37e8780318ad4bb = $A639a7baefc720ee;
				} else {
					$a37e8780318ad4bb = IMAGES_PATH . basename($A639a7baefc720ee);
				}

				list($c29dfa683545802c, $d30b6b589a9a7ff6) = getimagesize($a37e8780318ad4bb);
				$D4f101ff179f7d78 = self::F4e1807144Dd84ef($c29dfa683545802c, $d30b6b589a9a7ff6, $D8e1dc68b81d5702, $ea69abb4ad0055aa);

				if (!($D4f101ff179f7d78['width'] && $D4f101ff179f7d78['height'])) {
				} else {
					$Ade25d0ea49cbef5 = imagecreatetruecolor($D4f101ff179f7d78['width'], $D4f101ff179f7d78['height']);

					if ($F9452a7efafa1aba == 'png') {
						$A639a7baefc720ee = imagecreatefrompng($a37e8780318ad4bb);
					} else {
						$A639a7baefc720ee = imagecreatefromjpeg($a37e8780318ad4bb);
					}

					imagealphablending($Ade25d0ea49cbef5, false);
					imagesavealpha($Ade25d0ea49cbef5, true);
					imagecopyresampled($Ade25d0ea49cbef5, $A639a7baefc720ee, 0, 0, 0, 0, $D4f101ff179f7d78['width'], $D4f101ff179f7d78['height'], $c29dfa683545802c, $d30b6b589a9a7ff6);
					imagepng($Ade25d0ea49cbef5, $cff016622381f6ab);
				}
			}

			if (!file_exists($cff016622381f6ab)) {
			} else {
				return true;
			}
		}

		return false;
	}

	public static function B8F3dEF724810918($C700a2b357e5ed65, $e739adf85c8ac121 = null)
	{
		if (substr($C700a2b357e5ed65, 0, 2) == 's:') {
			$B211d7401e6242f3 = explode(':', $C700a2b357e5ed65, 3);
			$f4116b9928c8b494 = self::ca8708baE84a9148(intval($B211d7401e6242f3[1]), $e739adf85c8ac121);

			if ($f4116b9928c8b494) {
				return $f4116b9928c8b494 . 'images/' . basename($C700a2b357e5ed65);
			}

			return '';
		}

		return $C700a2b357e5ed65;
	}

	public static function cA8708bAE84A9148($d58b4f8653a391d8 = null, $e739adf85c8ac121 = null)
	{
		$a70eaa0ab42179dd = null;

		if (isset($d58b4f8653a391d8)) {
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		if ($e739adf85c8ac121) {
			$C6033ec178efa2ae = $e739adf85c8ac121;
		} else {
			if (isset($_SERVER['SERVER_PORT']) && self::$rSettings['keep_protocol']) {
				$C6033ec178efa2ae = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443 ? 'https' : 'http');
			} else {
				$C6033ec178efa2ae = self::$rServers[$d58b4f8653a391d8]['server_protocol'];
			}
		}

		if (!self::$rServers[$d58b4f8653a391d8]) {
		} else {
			if (!self::$rServers[$d58b4f8653a391d8]['enable_proxy']) {
			} else {
				$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8));

				if (count($Da9a40906d3d1c5f) != 0) {
				} else {
					$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8, false));
				}

				if (count($Da9a40906d3d1c5f) != 0) {
					$a70eaa0ab42179dd = $d58b4f8653a391d8;
					$d58b4f8653a391d8 = $Da9a40906d3d1c5f[array_rand($Da9a40906d3d1c5f)];
				} else {
					return '';
				}
			}

			$baba170ab02ca0bd = (defined('host') ? HOST : null);

			if ($baba170ab02ca0bd && in_array(strtolower($baba170ab02ca0bd), array_map('strtolower', self::$rServers[$d58b4f8653a391d8]['domains']['urls']))) {
				$Caecf2bcd39a1efe = $baba170ab02ca0bd;
			} else {
				$Caecf2bcd39a1efe = (empty(self::$rServers[$d58b4f8653a391d8]['domain_name']) ? self::$rServers[$d58b4f8653a391d8]['server_ip'] : explode(',', self::$rServers[$d58b4f8653a391d8]['domain_name'])[0]);
			}

			$f4116b9928c8b494 = $C6033ec178efa2ae . '://' . $Caecf2bcd39a1efe . ':' . self::$rServers[$d58b4f8653a391d8][$C6033ec178efa2ae . '_broadcast_port'] . '/';

			if (!(self::$rServers[$d58b4f8653a391d8]['server_type'] == 1 && $a70eaa0ab42179dd && self::$rServers[$a70eaa0ab42179dd]['is_main'] == 0)) {
			} else {
				$f4116b9928c8b494 .= md5($d58b4f8653a391d8 . '_' . $a70eaa0ab42179dd . '_' . OPENSSL_EXTRA) . '/';
			}

			return $f4116b9928c8b494;
		}
	}

	public static function a2AF9198Cfd841A1($C700a2b357e5ed65, $da786f106d3fe6fe = true)
	{
		$c88afcbaf19918af = curl_init();
		curl_setopt($c88afcbaf19918af, CURLOPT_CONNECTTIMEOUT, 3);
		curl_setopt($c88afcbaf19918af, CURLOPT_TIMEOUT, 3);
		curl_setopt($c88afcbaf19918af, CURLOPT_URL, $C700a2b357e5ed65);
		curl_setopt($c88afcbaf19918af, CURLOPT_USERAGENT, 'XUI/' . XUI_VERSION);
		curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, $da786f106d3fe6fe);
		$a85e1b7d42c346a0 = curl_exec($c88afcbaf19918af);
		curl_close($c88afcbaf19918af);

		return $a85e1b7d42c346a0;
	}

	public static function A93CAb970D8D7916($E379394c7b1a273f, $d51e425eb7375255, $e95c908b2c0cb60b)
	{
		$A96a38e6b91953f2 = intval(self::$rSettings['max_simultaneous_downloads']);

		if ($A96a38e6b91953f2 != 0) {
			if (!$d51e425eb7375255['is_restreamer']) {
				$e2f848a82a80c113 = FLOOD_TMP_PATH . $d51e425eb7375255['id'] . '_downloads';

				if (file_exists($e2f848a82a80c113) && time() - filemtime($e2f848a82a80c113) < 10) {
					$A707ccd39fee7276[$E379394c7b1a273f] = array();

					foreach (json_decode(file_get_contents($e2f848a82a80c113), true)[$E379394c7b1a273f] as $f9b07d216a168dcc) {
						if (!(self::dD714Ee89c59Fbf2($f9b07d216a168dcc, 'php-fpm') && $f9b07d216a168dcc != $e95c908b2c0cb60b)) {
						} else {
							$A707ccd39fee7276[$E379394c7b1a273f][] = $f9b07d216a168dcc;
						}
					}
				} else {
					$A707ccd39fee7276 = array('epg' => array(), 'playlist' => array());
				}

				$D329e25fc49eec41 = false;

				if (count($A707ccd39fee7276[$E379394c7b1a273f]) >= $A96a38e6b91953f2) {
				} else {
					$A707ccd39fee7276[$E379394c7b1a273f][] = $e95c908b2c0cb60b;
					$D329e25fc49eec41 = true;
				}

				file_put_contents($e2f848a82a80c113, json_encode($A707ccd39fee7276), LOCK_EX);

				return $D329e25fc49eec41;
			} else {
				return true;
			}
		} else {
			return true;
		}
	}

	public static function CD81a6df500dcFFd($E379394c7b1a273f, $d51e425eb7375255, $e95c908b2c0cb60b)
	{
		if (intval(self::$rSettings['max_simultaneous_downloads']) != 0) {
			if (!$d51e425eb7375255['is_restreamer']) {
				$e2f848a82a80c113 = FLOOD_TMP_PATH . $d51e425eb7375255['id'] . '_downloads';

				if (file_exists($e2f848a82a80c113)) {
					$A707ccd39fee7276[$E379394c7b1a273f] = array();

					foreach (json_decode(file_get_contents($e2f848a82a80c113), true)[$E379394c7b1a273f] as $f9b07d216a168dcc) {
						if (!(self::DD714Ee89c59fBf2($f9b07d216a168dcc, 'php-fpm') && $f9b07d216a168dcc != $e95c908b2c0cb60b)) {
						} else {
							$A707ccd39fee7276[$E379394c7b1a273f][] = $f9b07d216a168dcc;
						}
					}
				} else {
					$A707ccd39fee7276 = array('epg' => array(), 'playlist' => array());
				}

				file_put_contents($e2f848a82a80c113, json_encode($A707ccd39fee7276), LOCK_EX);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function d3E665b5427479Fe($d51e425eb7375255, $c59ec257c284c894 = null)
	{
		if (self::$rSettings['auth_flood_limit'] != 0) {
			if (!$d51e425eb7375255['is_restreamer']) {
				if ($c59ec257c284c894) {
				} else {
					$c59ec257c284c894 = self::a9bc416Fa6FA55C3();
				}

				if (!(empty($c59ec257c284c894) || in_array($c59ec257c284c894, self::$rAllowedIPs))) {
					$D4a9631cb1db6a7b = array_filter(array_unique(explode(',', self::$rSettings['flood_ips_exclude'])));

					if (!in_array($c59ec257c284c894, $D4a9631cb1db6a7b)) {
						$C3aa51e8b5c8bdc2 = FLOOD_TMP_PATH . intval($d51e425eb7375255['id']) . '_' . $c59ec257c284c894;

						if (file_exists($C3aa51e8b5c8bdc2)) {
							$A707ccd39fee7276 = json_decode(file_get_contents($C3aa51e8b5c8bdc2), true);

							if (!(isset($A707ccd39fee7276['block_until']) && time() < $A707ccd39fee7276['block_until'])) {
							} else {
								sleep(intval(self::$rSettings['auth_flood_sleep']));
							}

							$be54debae5869cd3 = self::$rSettings['auth_flood_seconds'];
							$A96a38e6b91953f2 = self::$rSettings['auth_flood_limit'];
							$A707ccd39fee7276['attempts'] = self::C7D4656747098C59($A707ccd39fee7276['attempts'], $be54debae5869cd3, true);

							if ($A96a38e6b91953f2 > count($A707ccd39fee7276['attempts'])) {
							} else {
								$A707ccd39fee7276['block_until'] = time() + intval(self::$rSettings['auth_flood_seconds']);
							}

							$A707ccd39fee7276['attempts'][] = time();
							file_put_contents($C3aa51e8b5c8bdc2, json_encode($A707ccd39fee7276), LOCK_EX);
						} else {
							file_put_contents($C3aa51e8b5c8bdc2, json_encode(array('attempts' => array(time()))), LOCK_EX);
						}
					} else {
						return null;
					}
				} else {
					return null;
				}
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function cDD1bc14D819Be74($Fa288895c003c519 = false)
	{
		$e2f848a82a80c113 = ($Fa288895c003c519 ? 'proxy_capacity' : 'servers_capacity');

		if (!(self::$rSettings['redis_handler'] && $Fa288895c003c519 && self::$rSettings['split_by'] == 'maxclients')) {
		} else {
			self::$rSettings['split_by'] == 'guar_band';
		}

		if (self::$rSettings['redis_handler']) {
			$b3439582205053ea = array();
			$caa6c2a1dcc4ac73 = self::$redis->multi();

			foreach (array_keys(self::$rServers) as $d58b4f8653a391d8) {
				if (!self::$rServers[$d58b4f8653a391d8]['server_online']) {
				} else {
					$caa6c2a1dcc4ac73->zCard((($Fa288895c003c519 ? 'PROXY#' : 'SERVER#')) . $d58b4f8653a391d8);
				}
			}
			$c15d5b523e931f51 = $caa6c2a1dcc4ac73->exec();
			$Ea22c4a9ab5b2176 = 0;

			foreach (array_keys(self::$rServers) as $d58b4f8653a391d8) {
				if (!self::$rServers[$d58b4f8653a391d8]['server_online']) {
				} else {
					$b3439582205053ea[$d58b4f8653a391d8] = array('online_clients' => ($c15d5b523e931f51[$Ea22c4a9ab5b2176] ?: 0));
					$Ea22c4a9ab5b2176++;
				}
			}
		} else {
			if ($Fa288895c003c519) {
				self::$db->query('SELECT `proxy_id`, COUNT(*) AS `online_clients` FROM `lines_live` WHERE `proxy_id` <> 0 AND `hls_end` = 0 GROUP BY `proxy_id`;');
				$b3439582205053ea = self::$db->get_rows(true, 'proxy_id');
			} else {
				self::$db->query('SELECT `server_id`, COUNT(*) AS `online_clients` FROM `lines_live` WHERE `server_id` <> 0 AND `hls_end` = 0 GROUP BY `server_id`;');
				$b3439582205053ea = self::$db->get_rows(true, 'server_id');
			}
		}

		if (self::$rSettings['split_by'] == 'band') {
			$A13a56c522d510bd = array();

			foreach (array_keys(self::$rServers) as $d58b4f8653a391d8) {
				$ae33391e8b827bba = json_decode(self::$rServers[$d58b4f8653a391d8]['server_hardware'], true);

				if (!empty($ae33391e8b827bba['network_speed'])) {
					$A13a56c522d510bd[$d58b4f8653a391d8] = (double) $ae33391e8b827bba['network_speed'];
				} else {
					if (0 < self::$rServers[$d58b4f8653a391d8]['network_guaranteed_speed']) {
						$A13a56c522d510bd[$d58b4f8653a391d8] = self::$rServers[$d58b4f8653a391d8]['network_guaranteed_speed'];
					} else {
						$A13a56c522d510bd[$d58b4f8653a391d8] = 1000;
					}
				}
			}

			foreach ($b3439582205053ea as $d58b4f8653a391d8 => $C740da31596f24ef) {
				$E6652dddfd6bdd23 = intval(self::$rServers[$d58b4f8653a391d8]['watchdog']['bytes_sent'] / 125000);
				$b3439582205053ea[$d58b4f8653a391d8]['capacity'] = (double) ($E6652dddfd6bdd23 / (($A13a56c522d510bd[$d58b4f8653a391d8] ?: 1000)));
			}
		} else {
			if (self::$rSettings['split_by'] == 'maxclients') {
				foreach ($b3439582205053ea as $d58b4f8653a391d8 => $C740da31596f24ef) {
					$b3439582205053ea[$d58b4f8653a391d8]['capacity'] = (double) ($C740da31596f24ef['online_clients'] / ((self::$rServers[$d58b4f8653a391d8]['total_clients'] ?: 1)));
				}
			} else {
				if (self::$rSettings['split_by'] == 'guar_band') {
					foreach ($b3439582205053ea as $d58b4f8653a391d8 => $C740da31596f24ef) {
						$E6652dddfd6bdd23 = intval(self::$rServers[$d58b4f8653a391d8]['watchdog']['bytes_sent'] / 125000);
						$b3439582205053ea[$d58b4f8653a391d8]['capacity'] = (double) ($E6652dddfd6bdd23 / ((self::$rServers[$d58b4f8653a391d8]['network_guaranteed_speed'] ?: 1)));
					}
				} else {
					foreach ($b3439582205053ea as $d58b4f8653a391d8 => $C740da31596f24ef) {
						$b3439582205053ea[$d58b4f8653a391d8]['capacity'] = $C740da31596f24ef['online_clients'];
					}
				}
			}
		}

		file_put_contents(CACHE_TMP_PATH . $e2f848a82a80c113, json_encode($b3439582205053ea), LOCK_EX);

		return $b3439582205053ea;
	}

	public static function Bc23764ED0732F3F($d58b4f8653a391d8 = null, $D78ff1d0edade5eb = null, $F26087d31c2bbe4d = null)
	{
		if (!self::$rSettings['redis_handler'] || is_object(self::$redis)) {
		} else {
			self::Bfa8B6fe314DED7f();
		}

		if (self::$rSettings['redis_handler']) {
			if ($d58b4f8653a391d8) {
				$f16991461acd03bf = self::$redis->zRangeByScore('SERVER#' . $d58b4f8653a391d8, '-inf', '+inf');
			} else {
				if ($D78ff1d0edade5eb) {
					$f16991461acd03bf = self::$redis->zRangeByScore('LINE#' . $D78ff1d0edade5eb, '-inf', '+inf');
				} else {
					if ($F26087d31c2bbe4d) {
						$f16991461acd03bf = self::$redis->zRangeByScore('STREAM#' . $F26087d31c2bbe4d, '-inf', '+inf');
					} else {
						$f16991461acd03bf = self::$redis->zRangeByScore('LIVE', '-inf', '+inf');
					}
				}
			}

			if (0 >= count($f16991461acd03bf)) {
			} else {
				return array($f16991461acd03bf, array_map('igbinary_unserialize', self::$redis->mGet($f16991461acd03bf)));
			}
		} else {
			$f86e19bdb1e7dae8 = array();

			if (empty($d58b4f8653a391d8)) {
			} else {
				$f86e19bdb1e7dae8[] = 't1.server_id = ' . intval($d58b4f8653a391d8);
			}

			if (empty($D78ff1d0edade5eb)) {
			} else {
				$f86e19bdb1e7dae8[] = 't1.user_id = ' . intval($D78ff1d0edade5eb);
			}

			$B28e0d26329880d3 = '';

			if (0 >= count($f86e19bdb1e7dae8)) {
			} else {
				$B28e0d26329880d3 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			}

			$A6d7047f2fda966c = 'SELECT t2.*,t3.*,t5.bitrate,t1.*,t1.uuid AS `uuid` FROM `lines_live` t1 LEFT JOIN `lines` t2 ON t2.id = t1.user_id LEFT JOIN `streams` t3 ON t3.id = t1.stream_id LEFT JOIN `streams_servers` t5 ON t5.stream_id = t1.stream_id AND t5.server_id = t1.server_id ' . $B28e0d26329880d3 . ' ORDER BY t1.activity_id ASC';
			self::$db->query($A6d7047f2fda966c);

			return self::$db->get_rows(true, 'user_id', false);
		}
	}

	public static function getEnded()
	{
		if (is_object(self::$redis)) {
		} else {
			self::BFA8B6fe314deD7F();
		}

		$f16991461acd03bf = self::$redis->sMembers('ENDED');

		if (0 >= count($f16991461acd03bf)) {
		} else {
			return array_map('igbinary_unserialize', self::$redis->mGet($f16991461acd03bf));
		}
	}

	public static function getBouquetMap($F26087d31c2bbe4d)
	{
		$B7c4b912a2afc994 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'bouquet_map'));
		$a85e1b7d42c346a0 = ($B7c4b912a2afc994[$F26087d31c2bbe4d] ?: array());
		unset($B7c4b912a2afc994);

		return $a85e1b7d42c346a0;
	}

	public static function afA0F3FFB001B9bE($F26087d31c2bbe4d, $b91591a6218018bb = false)
	{
		if (self::$rCached) {
			self::$db->query('SELECT COUNT(*) AS `count` FROM `signals` WHERE `server_id` = ? AND `cache` = 1 AND `custom_data` = ?;', self::cB50F783B960a4ef(), json_encode(array('type' => 'update_stream', 'id' => $F26087d31c2bbe4d)));

			if (self::$db->get_row()['count'] != 0) {
			} else {
				self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', self::CB50f783b960A4Ef(), time(), json_encode(array('type' => 'update_stream', 'id' => $F26087d31c2bbe4d)));
			}

			return true;
		}

		return false;
	}

	public static function updateStreams($Cdb85875fd50f459)
	{
		if (self::$rCached) {
			self::$db->query('SELECT COUNT(*) AS `count` FROM `signals` WHERE `server_id` = ? AND `cache` = 1 AND `custom_data` = ?;', self::CB50F783b960A4eF(), json_encode(array('type' => 'update_streams', 'id' => $Cdb85875fd50f459)));

			if (self::$db->get_row()['count'] != 0) {
			} else {
				self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', self::CB50f783B960A4eF(), time(), json_encode(array('type' => 'update_streams', 'id' => $Cdb85875fd50f459)));
			}

			return true;
		}

		return false;
	}

	public static function d6d7dca66BBF5219($D78ff1d0edade5eb, $b91591a6218018bb = false)
	{
		self::BC77eDc4169f1BAa($D78ff1d0edade5eb, $b91591a6218018bb);
	}

	public static function deleteLines($b174976b99c4ec48, $b91591a6218018bb = false)
	{
		self::updateLines($b174976b99c4ec48);
	}

	public static function BC77EdC4169f1baa($D78ff1d0edade5eb, $b91591a6218018bb = false)
	{
		if (self::$rCached) {
			self::$db->query('SELECT COUNT(*) AS `count` FROM `signals` WHERE `server_id` = ? AND `cache` = 1 AND `custom_data` = ?;', self::cB50F783b960A4Ef(), json_encode(array('type' => 'update_line', 'id' => $D78ff1d0edade5eb)));

			if (self::$db->get_row()['count'] != 0) {
			} else {
				self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', self::cb50F783b960a4EF(), time(), json_encode(array('type' => 'update_line', 'id' => $D78ff1d0edade5eb)));
			}

			return true;
		}

		return false;
	}

	public static function updateLines($b174976b99c4ec48)
	{
		if (self::$rCached) {
			self::$db->query('SELECT COUNT(*) AS `count` FROM `signals` WHERE `server_id` = ? AND `cache` = 1 AND `custom_data` = ?;', self::CB50f783b960A4ef(), json_encode(array('type' => 'update_lines', 'id' => $b174976b99c4ec48)));

			if (self::$db->get_row()['count'] != 0) {
			} else {
				self::$db->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', self::cB50F783b960A4Ef(), time(), json_encode(array('type' => 'update_lines', 'id' => $b174976b99c4ec48)));
			}

			return true;
		}

		return false;
	}

	public static function cB50F783B960A4eF()
	{
		foreach (self::$rServers as $d58b4f8653a391d8 => $e81220b4451f37c9) {
			if (!$e81220b4451f37c9['is_main']) {
			} else {
				return $d58b4f8653a391d8;
			}
		}
	}

	public static function a2aA2B94d2D97a7f($F26087d31c2bbe4d, $e91e92047b92eb25)
	{
		$d919bf727d78c4ca = $c078f3ed0fe7b4fa = array();

		if (!file_exists(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) {
		} else {
			$c078f3ed0fe7b4fa = igbinary_unserialize(file_get_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d)));
		}

		foreach ($c078f3ed0fe7b4fa as $f9b07d216a168dcc) {
			if (!self::DD714ee89C59FBF2($f9b07d216a168dcc, 'php-fpm')) {
			} else {
				$d919bf727d78c4ca[] = $f9b07d216a168dcc;
			}
		}

		if (in_array($d919bf727d78c4ca, $e91e92047b92eb25)) {
		} else {
			$d919bf727d78c4ca[] = $e91e92047b92eb25;
		}

		file_put_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d), igbinary_serialize($d919bf727d78c4ca));
	}

	public static function Ca490cE3385c630e($F26087d31c2bbe4d, $f9b07d216a168dcc)
	{
		$d919bf727d78c4ca = array();

		foreach ((igbinary_unserialize(file_get_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) ?: array()) as $adbe9b306d12ef6b) {
			if (!(self::Dd714EE89c59fbF2($adbe9b306d12ef6b, 'php-fpm') && $f9b07d216a168dcc != $adbe9b306d12ef6b)) {
			} else {
				$d919bf727d78c4ca[] = $adbe9b306d12ef6b;
			}
		}

		if (0 < count($d919bf727d78c4ca)) {
			file_put_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d), igbinary_serialize($d919bf727d78c4ca));
		} else {
			unlink(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d));
		}
	}

	public static function B40c00E4C44A1eb9($d58b4f8653a391d8)
	{
		return (array_rand(array_keys(self::getProxies($d58b4f8653a391d8, false))) ?: null);
	}

	public static function ae6bB580baA323c2($c608db3e24256b76, $A02729c83b6cd395)
	{
		if (!(is_numeric($A02729c83b6cd395) && 1900 <= $A02729c83b6cd395 && $A02729c83b6cd395 <= intval(date('Y') + 1))) {
		} else {
			if (self::$rSettings['movie_year_append'] == 0) {
				return trim($c608db3e24256b76) . ' (' . $A02729c83b6cd395 . ')';
			}

			if (self::$rSettings['movie_year_append'] != 0) {
			} else {
				return trim($c608db3e24256b76) . ' - ' . $A02729c83b6cd395;
			}
		}

		return $c608db3e24256b76;
	}

	public static function e43Cb741AA22a6d8($f46da30a01f7b2d7)
	{
		if (!(0 < count($f46da30a01f7b2d7) && file_exists(CACHE_TMP_PATH . 'channel_order') && self::$rSettings['channel_number_type'] != 'bouquet')) {
		} else {
			$c6c389b9adf3a40c = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'channel_order'));
			$f46da30a01f7b2d7 = array_flip($f46da30a01f7b2d7);
			$F8dd9a1b55d9bf0b = array();

			foreach ($c6c389b9adf3a40c as $C3c8913edb801c35) {
				if (!isset($f46da30a01f7b2d7[$C3c8913edb801c35])) {
				} else {
					$F8dd9a1b55d9bf0b[] = $C3c8913edb801c35;
				}
			}

			if (0 >= count($F8dd9a1b55d9bf0b)) {
			} else {
				return $F8dd9a1b55d9bf0b;
			}
		}

		return $f46da30a01f7b2d7;
	}

	public static function sortSeries($bbc84f53c534450d)
	{
		if (!(0 < count($bbc84f53c534450d) && file_exists(CACHE_TMP_PATH . 'series_order'))) {
		} else {
			$c6c389b9adf3a40c = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'series_order'));
			$bbc84f53c534450d = array_flip($bbc84f53c534450d);
			$F8dd9a1b55d9bf0b = array();

			foreach ($c6c389b9adf3a40c as $C3c8913edb801c35) {
				if (!isset($bbc84f53c534450d[$C3c8913edb801c35])) {
				} else {
					$F8dd9a1b55d9bf0b[] = $C3c8913edb801c35;
				}
			}

			if (0 >= count($F8dd9a1b55d9bf0b)) {
			} else {
				return $F8dd9a1b55d9bf0b;
			}
		}

		return $bbc84f53c534450d;
	}

	public static function CF592C234DCD0b19($D3fa098be3f297cd, $a27e64cc6ce01033)
	{
		file_put_contents(SIGNALS_TMP_PATH . 'cache_' . md5($D3fa098be3f297cd), json_encode(array($D3fa098be3f297cd, $a27e64cc6ce01033)));
	}

	public static function BfA8B6FE314dED7F()
	{
		if (is_object(self::$redis)) {
		} else {
			try {
				self::$redis = new Redis();
				self::$redis->connect(self::$rConfig['hostname'], 6379);
				self::$redis->auth(self::$rSettings['redis_password']);
			} catch (Exception $c34ae71903f0d920) {
				self::$redis = null;

				return false;
			}
		}

		return true;
	}

	public static function E3484f74D3c8b5a7($a27e64cc6ce01033, $a6b40128767dfe4f = array(), $ec42cf0557b72e6f = null)
	{
		if (is_object(self::$redis)) {
		} else {
			self::bfA8B6fe314DeD7F();
		}

		$d9b341c05baed5be = $a27e64cc6ce01033;

		foreach ($a6b40128767dfe4f as $D3fa098be3f297cd => $b6842cb20051e925) {
			$a27e64cc6ce01033[$D3fa098be3f297cd] = $b6842cb20051e925;
		}
		$F42a951cf0a3370a = self::$redis->multi();

		if ($ec42cf0557b72e6f == 'open') {
			$F42a951cf0a3370a->sRem('ENDED', $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('LIVE', $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('LINE#' . $a27e64cc6ce01033['identity'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('STREAM#' . $a27e64cc6ce01033['stream_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('SERVER#' . $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);

			if (!$a27e64cc6ce01033['proxy_id']) {
			} else {
				$F42a951cf0a3370a->zAdd('PROXY#' . $a27e64cc6ce01033['proxy_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			}

			if ($a27e64cc6ce01033['hls_end'] != 1) {
			} else {
				$a27e64cc6ce01033['hls_end'] = 0;

				if (!$a27e64cc6ce01033['user_id']) {
				} else {
					$F42a951cf0a3370a->zAdd('SERVER_LINES#' . $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['user_id'], $a27e64cc6ce01033['uuid']);
				}
			}
		} else {
			if ($ec42cf0557b72e6f != 'close') {
			} else {
				$F42a951cf0a3370a->sAdd('ENDED', $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('LIVE', $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('LINE#' . $d9b341c05baed5be['identity'], $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('STREAM#' . $d9b341c05baed5be['stream_id'], $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('SERVER#' . $d9b341c05baed5be['server_id'], $a27e64cc6ce01033['uuid']);

				if (!$a27e64cc6ce01033['proxy_id']) {
				} else {
					$F42a951cf0a3370a->zRem('PROXY#' . $d9b341c05baed5be['proxy_id'], $a27e64cc6ce01033['uuid']);
				}

				if ($a27e64cc6ce01033['hls_end'] != 0) {
				} else {
					$a27e64cc6ce01033['hls_end'] = 1;

					if (!$a27e64cc6ce01033['user_id']) {
					} else {
						$F42a951cf0a3370a->zRem('SERVER_LINES#' . $d9b341c05baed5be['server_id'], $a27e64cc6ce01033['uuid']);
					}
				}
			}
		}

		$F42a951cf0a3370a->set($a27e64cc6ce01033['uuid'], igbinary_serialize($a27e64cc6ce01033));

		if ($F42a951cf0a3370a->exec()) {
			return $a27e64cc6ce01033;
		}

		return null;
	}

	public static function aA941cf79C4F48CF($f9b07d216a168dcc, $d58b4f8653a391d8, $C2897f488ae9e7fe, $Bccc89fc1174404a = null)
	{
		if (is_object(self::$redis)) {
		} else {
			self::BFa8B6FE314DEd7F();
		}

		$D3fa098be3f297cd = 'SIGNAL#' . md5($d58b4f8653a391d8 . '#' . $f9b07d216a168dcc . '#' . $C2897f488ae9e7fe);
		$a27e64cc6ce01033 = array('pid' => $f9b07d216a168dcc, 'server_id' => $d58b4f8653a391d8, 'rtmp' => $C2897f488ae9e7fe, 'time' => time(), 'custom_data' => $Bccc89fc1174404a, 'key' => $D3fa098be3f297cd);

		return self::$redis->multi()->sAdd('SIGNALS#' . $d58b4f8653a391d8, $D3fa098be3f297cd)->set($D3fa098be3f297cd, igbinary_serialize($a27e64cc6ce01033))->exec();
	}

	public static function dE78b5e00A0718D6($b174976b99c4ec48, $Aa8d8af3d37ca869 = false, $D99fd35721c99593 = false)
	{
		if (is_object(self::$redis)) {
		} else {
			self::bfA8B6fe314DEd7F();
		}

		$F42a951cf0a3370a = self::$redis->multi();

		foreach ($b174976b99c4ec48 as $D78ff1d0edade5eb) {
			$F42a951cf0a3370a->zRevRangeByScore('LINE#' . $D78ff1d0edade5eb, '+inf', '-inf');
		}
		$ca518e82bd328243 = $F42a951cf0a3370a->exec();
		$C7dc44e2b269673a = $E85784c325b1fed5 = array();

		foreach ($ca518e82bd328243 as $e41ee48af2b8e2a5 => $f16991461acd03bf) {
			if ($Aa8d8af3d37ca869) {
				$C7dc44e2b269673a[$b174976b99c4ec48[$e41ee48af2b8e2a5]] = count($f16991461acd03bf);
			} else {
				if (0 >= count($f16991461acd03bf)) {
				} else {
					$E85784c325b1fed5 = array_merge($E85784c325b1fed5, $f16991461acd03bf);
				}
			}
		}
		$E85784c325b1fed5 = array_unique($E85784c325b1fed5);

		if (!$D99fd35721c99593) {
			if ($Aa8d8af3d37ca869) {
			} else {
				foreach (self::$redis->mGet($E85784c325b1fed5) as $C740da31596f24ef) {
					$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);
					$C7dc44e2b269673a[$C740da31596f24ef['user_id']][] = $C740da31596f24ef;
				}
			}

			return $C7dc44e2b269673a;
		}

		return $E85784c325b1fed5;
	}

	public static function getServerConnections($E708d4730d21125b, $Fa288895c003c519 = false, $Aa8d8af3d37ca869 = false, $D99fd35721c99593 = false)
	{
		if (is_object(self::$redis)) {
		} else {
			self::BfA8B6FE314DEd7f();
		}

		$F42a951cf0a3370a = self::$redis->multi();

		foreach ($E708d4730d21125b as $d58b4f8653a391d8) {
			$F42a951cf0a3370a->zRevRangeByScore(($Fa288895c003c519 ? 'PROXY#' . $d58b4f8653a391d8 : 'SERVER#' . $d58b4f8653a391d8), '+inf', '-inf');
		}
		$ca518e82bd328243 = $F42a951cf0a3370a->exec();
		$C7dc44e2b269673a = $E85784c325b1fed5 = array();

		foreach ($ca518e82bd328243 as $e41ee48af2b8e2a5 => $f16991461acd03bf) {
			if ($Aa8d8af3d37ca869) {
				$C7dc44e2b269673a[$E708d4730d21125b[$e41ee48af2b8e2a5]] = count($f16991461acd03bf);
			} else {
				if (0 >= count($f16991461acd03bf)) {
				} else {
					$E85784c325b1fed5 = array_merge($E85784c325b1fed5, $f16991461acd03bf);
				}
			}
		}
		$E85784c325b1fed5 = array_unique($E85784c325b1fed5);

		if (!$D99fd35721c99593) {
			if ($Aa8d8af3d37ca869) {
			} else {
				foreach (self::$redis->mGet($E85784c325b1fed5) as $C740da31596f24ef) {
					$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);
					$C7dc44e2b269673a[$C740da31596f24ef['server_id']][] = $C740da31596f24ef;
				}
			}

			return $C7dc44e2b269673a;
		}

		return $E85784c325b1fed5;
	}

	public static function getFirstConnection($b174976b99c4ec48)
	{
		if (is_object(self::$redis)) {
		} else {
			self::bfA8B6Fe314dEd7F();
		}

		$F42a951cf0a3370a = self::$redis->multi();

		foreach ($b174976b99c4ec48 as $D78ff1d0edade5eb) {
			$F42a951cf0a3370a->zRevRangeByScore('LINE#' . $D78ff1d0edade5eb, '+inf', '-inf', array('limit' => array(0, 1)));
		}
		$ca518e82bd328243 = $F42a951cf0a3370a->exec();
		$C7dc44e2b269673a = $E85784c325b1fed5 = array();

		foreach ($ca518e82bd328243 as $e41ee48af2b8e2a5 => $f16991461acd03bf) {
			if (0 >= count($f16991461acd03bf)) {
			} else {
				$E85784c325b1fed5[] = $f16991461acd03bf[0];
			}
		}

		foreach (self::$redis->mGet(array_unique($E85784c325b1fed5)) as $C740da31596f24ef) {
			$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);
			$C7dc44e2b269673a[$C740da31596f24ef['user_id']] = $C740da31596f24ef;
		}

		return $C7dc44e2b269673a;
	}

	public static function getStreamConnections($Cdb85875fd50f459, $D307572f7986a746 = true, $Aa8d8af3d37ca869 = false)
	{
		if (is_object(self::$redis)) {
		} else {
			self::bfA8b6fe314deD7f();
		}

		$F42a951cf0a3370a = self::$redis->multi();

		foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
			$F42a951cf0a3370a->zRevRangeByScore('STREAM#' . $F26087d31c2bbe4d, '+inf', '-inf');
		}
		$ca518e82bd328243 = $F42a951cf0a3370a->exec();
		$C7dc44e2b269673a = $E85784c325b1fed5 = array();

		foreach ($ca518e82bd328243 as $e41ee48af2b8e2a5 => $f16991461acd03bf) {
			if ($Aa8d8af3d37ca869) {
				$C7dc44e2b269673a[$Cdb85875fd50f459[$e41ee48af2b8e2a5]] = count($f16991461acd03bf);
			} else {
				if (0 >= count($f16991461acd03bf)) {
				} else {
					$E85784c325b1fed5 = array_merge($E85784c325b1fed5, $f16991461acd03bf);
				}
			}
		}

		if ($Aa8d8af3d37ca869) {
		} else {
			foreach (self::$redis->mGet(array_unique($E85784c325b1fed5)) as $C740da31596f24ef) {
				$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);

				if ($D307572f7986a746) {
					$C7dc44e2b269673a[$C740da31596f24ef['stream_id']][] = $C740da31596f24ef;
				} else {
					$C7dc44e2b269673a[$C740da31596f24ef['stream_id']][$C740da31596f24ef['server_id']][] = $C740da31596f24ef;
				}
			}
		}

		return $C7dc44e2b269673a;
	}

	public static function D92de48C36CF9438($D78ff1d0edade5eb = null, $d58b4f8653a391d8 = null, $F26087d31c2bbe4d = null, $De2266aa64a9a191 = false, $a8a160a877a19105 = false, $D307572f7986a746 = true, $fb91bbdc30b81567 = false)
	{
		$a85e1b7d42c346a0 = ($a8a160a877a19105 ? array(0, 0) : array());

		if (is_object(self::$redis)) {
		} else {
			self::bFA8b6Fe314dED7F();
		}

		$b13cc96700ec086d = array();
		$D78ff1d0edade5eb = (0 < intval($D78ff1d0edade5eb) ? intval($D78ff1d0edade5eb) : null);
		$d58b4f8653a391d8 = (0 < intval($d58b4f8653a391d8) ? intval($d58b4f8653a391d8) : null);
		$F26087d31c2bbe4d = (0 < intval($F26087d31c2bbe4d) ? intval($F26087d31c2bbe4d) : null);

		if ($D78ff1d0edade5eb) {
			$f16991461acd03bf = self::$redis->zRangeByScore('LINE#' . $D78ff1d0edade5eb, '-inf', '+inf');
		} else {
			if ($F26087d31c2bbe4d) {
				$f16991461acd03bf = self::$redis->zRangeByScore('STREAM#' . $F26087d31c2bbe4d, '-inf', '+inf');
			} else {
				if ($d58b4f8653a391d8) {
					$f16991461acd03bf = self::$redis->zRangeByScore('SERVER#' . $d58b4f8653a391d8, '-inf', '+inf');
				} else {
					$f16991461acd03bf = self::$redis->zRangeByScore('LIVE', '-inf', '+inf');
				}
			}
		}

		if (0 >= count($f16991461acd03bf)) {
		} else {
			foreach (self::$redis->mGet(array_unique($f16991461acd03bf)) as $C740da31596f24ef) {
				$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);

				if (!($d58b4f8653a391d8 && $d58b4f8653a391d8 != $C740da31596f24ef['server_id']) && !($F26087d31c2bbe4d && $F26087d31c2bbe4d != $C740da31596f24ef['stream_id']) && !($D78ff1d0edade5eb && $D78ff1d0edade5eb != $C740da31596f24ef['user_id']) && !($fb91bbdc30b81567 && $C740da31596f24ef['container'] == 'hls')) {
					$B08b62d9f7870287 = ($C740da31596f24ef['user_id'] ?: $C740da31596f24ef['hmac_id'] . '_' . $C740da31596f24ef['hmac_identifier']);

					if ($a8a160a877a19105) {
						$a85e1b7d42c346a0[0]++;
						$b13cc96700ec086d[] = $B08b62d9f7870287;
					} else {
						if ($D307572f7986a746) {
							if (isset($a85e1b7d42c346a0[$B08b62d9f7870287])) {
							} else {
								$a85e1b7d42c346a0[$B08b62d9f7870287] = array();
							}

							$a85e1b7d42c346a0[$B08b62d9f7870287][] = $C740da31596f24ef;
						} else {
							$a85e1b7d42c346a0[] = $C740da31596f24ef;
						}
					}
				}
			}
		}

		if (!$a8a160a877a19105) {
		} else {
			$a85e1b7d42c346a0[1] = count(array_unique($b13cc96700ec086d));
		}

		return $a85e1b7d42c346a0;
	}

	public static function d55A1d8aCd201840($bdd1eae90d142462 = false)
	{
		$a70eaa0ab42179dd = null;
		$d58b4f8653a391d8 = SERVER_ID;

		if ($bdd1eae90d142462) {
			$C6033ec178efa2ae = 'https';
		} else {
			if (isset($_SERVER['SERVER_PORT']) && self::$rSettings['keep_protocol']) {
				$C6033ec178efa2ae = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443 ? 'https' : 'http');
			} else {
				$C6033ec178efa2ae = self::$rServers[$d58b4f8653a391d8]['server_protocol'];
			}
		}

		$A1fe548fd94fcef3 = self::$rServers[$d58b4f8653a391d8]['enable_proxy'];

		if (!$A1fe548fd94fcef3) {
		} else {
			$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8));

			if (count($Da9a40906d3d1c5f) != 0) {
			} else {
				$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8, false));
			}

			if (count($Da9a40906d3d1c5f) != 0) {
				$a70eaa0ab42179dd = $d58b4f8653a391d8;
				$d58b4f8653a391d8 = $Da9a40906d3d1c5f[array_rand($Da9a40906d3d1c5f)];
			} else {
				return '';
			}
		}

		list($Caecf2bcd39a1efe, $dc7aa3c286c6a885) = explode(':', $_SERVER['HTTP_HOST']);

		if (!($A1fe548fd94fcef3 || self::$rSettings['use_mdomain_in_lists'] == 1)) {
		} else {
			if (in_array(strtolower($Caecf2bcd39a1efe), (self::abB674425a8B1B0D('reseller_domains') ?: array()))) {
			} else {
				if (empty(self::$rServers[$d58b4f8653a391d8]['domain_name'])) {
					$Caecf2bcd39a1efe = escapeshellcmd(self::$rServers[$d58b4f8653a391d8]['server_ip']);
				} else {
					$Caecf2bcd39a1efe = str_replace(array('http://', '/', 'https://'), '', escapeshellcmd(explode(',', self::$rServers[$d58b4f8653a391d8]['domain_name'])[0]));
				}
			}
		}

		$f4116b9928c8b494 = $C6033ec178efa2ae . '://' . $Caecf2bcd39a1efe . ':' . self::$rServers[$d58b4f8653a391d8][$C6033ec178efa2ae . '_broadcast_port'] . '/';

		if (!(self::$rServers[$d58b4f8653a391d8]['server_type'] == 1 && $a70eaa0ab42179dd && self::$rServers[$a70eaa0ab42179dd]['is_main'] == 0)) {
		} else {
			$f4116b9928c8b494 .= md5($d58b4f8653a391d8 . '_' . $a70eaa0ab42179dd . '_' . OPENSSL_EXTRA) . '/';
		}

		return $f4116b9928c8b494;
	}

	public static function A267181c61BdFfF9($a27e64cc6ce01033)
	{
		if (is_array($a27e64cc6ce01033)) {
		} else {
			$a27e64cc6ce01033 = json_decode($a27e64cc6ce01033, true);
		}

		$E6652981ffae09cc = array('aac', 'libfdk_aac', 'opus', 'vorbis', 'pcm_s16le', 'mp2', 'mp3', 'flac', null);
		$E79a0db1471ddfdf = array('h264', 'vp8', 'vp9', 'ogg', 'av1', null);

		if (!self::$rSettings['player_allow_hevc']) {
		} else {
			$E79a0db1471ddfdf[] = 'hevc';
			$E79a0db1471ddfdf[] = 'h265';
			$E6652981ffae09cc[] = 'ac3';
		}

		return ($a27e64cc6ce01033['codecs']['audio']['codec_name'] || $a27e64cc6ce01033['codecs']['video']['codec_name']) && in_array(strtolower($a27e64cc6ce01033['codecs']['audio']['codec_name']), $E6652981ffae09cc) && in_array(strtolower($a27e64cc6ce01033['codecs']['video']['codec_name']), $E79a0db1471ddfdf);
	}

	public static function CCEDFaEA1d970310($b847427c74689f7f, $a5cbf8a0668cece1)
	{
		$C81f5f7d4b192c6d = null;

		foreach ($b847427c74689f7f as $D45382ad8061de32) {
			if (!($C81f5f7d4b192c6d === null || abs($D45382ad8061de32 - $a5cbf8a0668cece1) < abs($a5cbf8a0668cece1 - $C81f5f7d4b192c6d))) {
			} else {
				$C81f5f7d4b192c6d = $D45382ad8061de32;
			}
		}

		return $C81f5f7d4b192c6d;
	}

	public static function submitPanelLogs()
	{
		ini_set('default_socket_timeout', 60);
		self::$db->query("SELECT `type`, `log_message`, `log_extra`, `line`, `date` FROM `panel_logs` WHERE `type` <> 'epg' GROUP BY CONCAT(`type`, `log_message`, `log_extra`) ORDER BY `date` DESC LIMIT 1000;");
		$c85ed032f7e37367 = 'https://xui.one/report.php';
		$a27e64cc6ce01033 = array('errors' => self::$db->get_rows(), 'license' => self::$rConfig['license'], 'version' => XUI_VERSION, 'revision' => XUI_REVISION);
		$E330444f58f09645 = http_build_query($a27e64cc6ce01033);
		self::$db->query('TRUNCATE `panel_logs`;');
		$c88afcbaf19918af = curl_init();
		curl_setopt($c88afcbaf19918af, CURLOPT_URL, $c85ed032f7e37367);
		curl_setopt($c88afcbaf19918af, CURLOPT_POST, true);
		curl_setopt($c88afcbaf19918af, CURLOPT_POSTFIELDS, $E330444f58f09645);
		curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($c88afcbaf19918af, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($c88afcbaf19918af, CURLOPT_TIMEOUT, 60);

		return curl_exec($c88afcbaf19918af);
	}

	public static function confirmIDs($Aa8c918a2a91966f)
	{
		$a85e1b7d42c346a0 = array();

		foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
			if (0 >= intval($C3c8913edb801c35)) {
			} else {
				$a85e1b7d42c346a0[] = $C3c8913edb801c35;
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function getTSInfo($bc2874292e0d9ece)
	{
		return json_decode(shell_exec(BIN_PATH . 'tsinfo ' . escapeshellarg($bc2874292e0d9ece)), true);
	}

	public static function getEPG($F26087d31c2bbe4d, $a63ba41c5c63ce14 = null, $cdc10b88b0856b7b = null, $C68268feb7926b70 = false)
	{
		$a85e1b7d42c346a0 = array();
		$a27e64cc6ce01033 = (file_exists(EPG_PATH . 'stream_' . $F26087d31c2bbe4d) ? igbinary_unserialize(file_get_contents(EPG_PATH . 'stream_' . $F26087d31c2bbe4d)) : array());

		foreach ($a27e64cc6ce01033 as $bb2621204e39e62d) {
			if ($a63ba41c5c63ce14 && !($a63ba41c5c63ce14 < $bb2621204e39e62d['end'] && $bb2621204e39e62d['start'] < $cdc10b88b0856b7b)) {
			} else {
				if ($C68268feb7926b70) {
					$a85e1b7d42c346a0[$bb2621204e39e62d['id']] = $bb2621204e39e62d;
				} else {
					$a85e1b7d42c346a0[] = $bb2621204e39e62d;
				}
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function fae50Dee78EcD0fb($Cdb85875fd50f459, $a63ba41c5c63ce14 = null, $cdc10b88b0856b7b = null)
	{
		$a85e1b7d42c346a0 = array();

		foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
			$a85e1b7d42c346a0[$F26087d31c2bbe4d] = self::getEPG($F26087d31c2bbe4d, $a63ba41c5c63ce14, $cdc10b88b0856b7b);
		}

		return $a85e1b7d42c346a0;
	}

	public static function getProgramme($F26087d31c2bbe4d, $ed76c60b8966bbc4)
	{
		$a27e64cc6ce01033 = self::getEPG($F26087d31c2bbe4d, null, null, true);

		if (!isset($a27e64cc6ce01033[$ed76c60b8966bbc4])) {
		} else {
			return $a27e64cc6ce01033[$ed76c60b8966bbc4];
		}
	}

	public static function getNetwork($d9ad9627c40dff4d = null)
	{
		$a85e1b7d42c346a0 = array();

		if (!file_exists(LOGS_TMP_PATH . 'network')) {
		} else {
			$befbd070ebd83c29 = json_decode(file_get_contents(LOGS_TMP_PATH . 'network'), true);

			foreach ($befbd070ebd83c29 as $Ff014d0ebd314fcd) {
				if (!($d9ad9627c40dff4d && $Ff014d0ebd314fcd[0] != $d9ad9627c40dff4d) && !($Ff014d0ebd314fcd[0] == 'lo' || !$d9ad9627c40dff4d && substr($Ff014d0ebd314fcd[0], 0, 4) == 'bond')) {
					$a85e1b7d42c346a0[$Ff014d0ebd314fcd[0]] = array('in_bytes' => intval($Ff014d0ebd314fcd[1] / 2), 'in_packets' => $Ff014d0ebd314fcd[2], 'in_errors' => $Ff014d0ebd314fcd[3], 'out_bytes' => intval($Ff014d0ebd314fcd[4] / 2), 'out_packets' => $Ff014d0ebd314fcd[5], 'out_errors' => $Ff014d0ebd314fcd[6]);
				}
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function getProxies($d58b4f8653a391d8, $F148ac2342eb3b2b = true)
	{
		$a85e1b7d42c346a0 = array();

		foreach (self::$rServers as $b2a9243e8304033d => $cc5f26dd881329b7) {
			if (!($cc5f26dd881329b7['server_type'] == 1 && in_array($d58b4f8653a391d8, $cc5f26dd881329b7['parent_id']) && ($cc5f26dd881329b7['server_online'] || !$F148ac2342eb3b2b))) {
			} else {
				$a85e1b7d42c346a0[$b2a9243e8304033d] = $cc5f26dd881329b7;
			}
		}

		return $a85e1b7d42c346a0;
	}
}
