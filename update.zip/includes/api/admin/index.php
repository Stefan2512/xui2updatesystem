<?php

if (defined('XUI_HOME')) {
} else {
	define('XUI_HOME', '/home/xui/');
}

require_once XUI_HOME . 'includes/admin.php';
$b6f6dd705fb93d5e = array();

foreach (get_defined_constants(true)['user'] as $D3fa098be3f297cd => $b6842cb20051e925) {
	if (substr($D3fa098be3f297cd, 0, 7) != 'STATUS_') {
	} else {
		$b6f6dd705fb93d5e[intval($b6842cb20051e925)] = $D3fa098be3f297cd;
	}
}
$a27e64cc6ce01033 = XUI::$rRequest;
APIWrapper::$db = &$Fee0d5a474c96306;
APIWrapper::$rKey = $a27e64cc6ce01033['api_key'];

if (!empty(XUI::$rRequest['api_key']) && APIWrapper::createSession()) {
	$fa7da6c202358e0c = $a27e64cc6ce01033['action'];
	$D031c48a1422c07e = (intval($a27e64cc6ce01033['start']) ?: 0);
	$E400a3101514583e = (intval($a27e64cc6ce01033['limit']) ?: 50);
	unset($a27e64cc6ce01033['api_key'], $a27e64cc6ce01033['action'], $a27e64cc6ce01033['start'], $a27e64cc6ce01033['limit']);

	if (isset(XUI::$rRequest['show_columns'])) {
		$E19a3b45051e169e = explode(',', XUI::$rRequest['show_columns']);
	} else {
		$E19a3b45051e169e = null;
	}

	if (isset(XUI::$rRequest['hide_columns'])) {
		$feb740b7803efea9 = explode(',', XUI::$rRequest['hide_columns']);
	} else {
		$feb740b7803efea9 = null;
	}

	switch ($fa7da6c202358e0c) {
		case 'mysql_query':
			echo json_encode(APIWrapper::runQuery($a27e64cc6ce01033['query']));

			break;

		case 'user_info':
			echo json_encode(APIWrapper::filterRow(APIWrapper::d7CA435Ac70e9a78(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_lines':
			echo json_encode(APIWrapper::TableAPI('lines', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_mags':
			echo json_encode(APIWrapper::TableAPI('mags', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_enigmas':
			echo json_encode(APIWrapper::TableAPI('enigmas', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_users':
			echo json_encode(APIWrapper::TableAPI('reg_users', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_streams':
			echo json_encode(APIWrapper::TableAPI('streams', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_provider_streams':
			echo json_encode(APIWrapper::TableAPI('provider_streams', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_channels':
			$a27e64cc6ce01033['created'] = true;
			echo json_encode(APIWrapper::TableAPI('streams', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_stations':
			echo json_encode(APIWrapper::TableAPI('radios', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_movies':
			echo json_encode(APIWrapper::TableAPI('movies', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_series_list':
			echo json_encode(APIWrapper::TableAPI('series', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_episodes':
			echo json_encode(APIWrapper::TableAPI('episodes', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'activity_logs':
			echo json_encode(APIWrapper::TableAPI('line_activity', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'live_connections':
			echo json_encode(APIWrapper::TableAPI('live_connections', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'credit_logs':
			echo json_encode(APIWrapper::TableAPI('credits_log', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'client_logs':
			echo json_encode(APIWrapper::TableAPI('client_logs', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'user_logs':
			echo json_encode(APIWrapper::TableAPI('reg_user_logs', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'stream_errors':
			echo json_encode(APIWrapper::TableAPI('stream_errors', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'watch_output':
			echo json_encode(APIWrapper::TableAPI('watch_output', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'system_logs':
			echo json_encode(APIWrapper::TableAPI('mysql_syslog', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'login_logs':
			echo json_encode(APIWrapper::TableAPI('login_logs', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'restream_logs':
			echo json_encode(APIWrapper::TableAPI('restream_logs', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'mag_events':
			echo json_encode(APIWrapper::TableAPI('mag_events', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_line':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getLine($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_line':
			echo json_encode(APIWrapper::createLine($a27e64cc6ce01033));

			break;

		case 'edit_line':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editLine($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_line':
			echo json_encode(APIWrapper::D6D7DCA66bBf5219($a27e64cc6ce01033['id']));

			break;

		case 'disable_line':
			echo json_encode(APIWrapper::disableLine($a27e64cc6ce01033['id']));

			break;

		case 'enable_line':
			echo json_encode(APIWrapper::enableLine($a27e64cc6ce01033['id']));

			break;

		case 'unban_line':
			echo json_encode(APIWrapper::unbanLine($a27e64cc6ce01033['id']));

			break;

		case 'ban_line':
			echo json_encode(APIWrapper::banLine($a27e64cc6ce01033['id']));

			break;

		case 'get_user':
			echo json_encode(APIWrapper::filterRow(APIWrapper::CAF753aeB829E1DC($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_user':
			echo json_encode(APIWrapper::createUser($a27e64cc6ce01033));

			break;

		case 'edit_user':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editUser($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_user':
			echo json_encode(APIWrapper::B764C5DB9b0c0680($a27e64cc6ce01033['id']));

			break;

		case 'disable_user':
			echo json_encode(APIWrapper::disableUser($a27e64cc6ce01033['id']));

			break;

		case 'enable_user':
			echo json_encode(APIWrapper::enableUser($a27e64cc6ce01033['id']));

			break;

		case 'get_mag':
			echo json_encode(APIWrapper::filterRow(APIWrapper::CE5219a73Fa42510($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_mag':
			echo json_encode(APIWrapper::createMAG($a27e64cc6ce01033));

			break;

		case 'edit_mag':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editMAG($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_mag':
			echo json_encode(APIWrapper::a5b26FBa2af56EA0($a27e64cc6ce01033['id']));

			break;

		case 'disable_mag':
			echo json_encode(APIWrapper::disableMAG($a27e64cc6ce01033['id']));

			break;

		case 'enable_mag':
			echo json_encode(APIWrapper::enableMAG($a27e64cc6ce01033['id']));

			break;

		case 'unban_mag':
			echo json_encode(APIWrapper::unbanMAG($a27e64cc6ce01033['id']));

			break;

		case 'ban_mag':
			echo json_encode(APIWrapper::banMAG($a27e64cc6ce01033['id']));

			break;

		case 'convert_mag':
			echo json_encode(APIWrapper::convertMAG($a27e64cc6ce01033['id']));

			break;

		case 'get_enigma':
			echo json_encode(APIWrapper::filterRow(APIWrapper::C5E57969C08075A1($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_enigma':
			echo json_encode(APIWrapper::createEnigma($a27e64cc6ce01033));

			break;

		case 'edit_enigma':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editEnigma($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_enigma':
			echo json_encode(APIWrapper::de6358BA78F3971d($a27e64cc6ce01033['id']));

			break;

		case 'disable_enigma':
			echo json_encode(APIWrapper::disableEnigma($a27e64cc6ce01033['id']));

			break;

		case 'enable_enigma':
			echo json_encode(APIWrapper::enableEnigma($a27e64cc6ce01033['id']));

			break;

		case 'unban_enigma':
			echo json_encode(APIWrapper::unbanEnigma($a27e64cc6ce01033['id']));

			break;

		case 'ban_enigma':
			echo json_encode(APIWrapper::banEnigma($a27e64cc6ce01033['id']));

			break;

		case 'convert_enigma':
			echo json_encode(APIWrapper::convertEnigma($a27e64cc6ce01033['id']));

			break;

		case 'get_bouquets':
			echo json_encode(APIWrapper::filterRows(APIWrapper::D265fF208B308269(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_bouquet':
			echo json_encode(APIWrapper::filterRow(APIWrapper::e72E2A65258E1e8a($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_bouquet':
			echo json_encode(APIWrapper::createBouquet($a27e64cc6ce01033));

			break;

		case 'edit_bouquet':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editBouquet($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_bouquet':
			echo json_encode(APIWrapper::faDA9d7505259037($a27e64cc6ce01033['id']));

			break;

		case 'get_access_codes':
			echo json_encode(APIWrapper::filterRows(APIWrapper::getAccessCodes(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_access_code':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getAccessCode($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_access_code':
			echo json_encode(APIWrapper::createAccessCode($a27e64cc6ce01033));

			break;

		case 'edit_access_code':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editAccessCode($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_access_code':
			echo json_encode(APIWrapper::deleteAccessCode($a27e64cc6ce01033['id']));

			break;

		case 'get_hmacs':
			echo json_encode(APIWrapper::filterRows(APIWrapper::getHMACs(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_hmac':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getHMAC($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_hmac':
			echo json_encode(APIWrapper::createHMAC($a27e64cc6ce01033));

			break;

		case 'edit_hmac':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editHMAC($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_hmac':
			echo json_encode(APIWrapper::aAAa9643e21EDcB7($a27e64cc6ce01033['id']));

			break;

		case 'get_epgs':
			echo json_encode(APIWrapper::filterRows(APIWrapper::fAE50dEE78EcD0Fb(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_epg':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getEPG($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_epg':
			echo json_encode(APIWrapper::createEPG($a27e64cc6ce01033));

			break;

		case 'edit_epg':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editEPG($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_epg':
			echo json_encode(APIWrapper::C9197556B739E655($a27e64cc6ce01033['id']));

			break;

		case 'reload_epg':
			echo json_encode(APIWrapper::reloadEPG((isset($a27e64cc6ce01033['id']) ? intval($a27e64cc6ce01033['id']) : null)));

			break;

		case 'get_providers':
			echo json_encode(APIWrapper::filterRows(APIWrapper::getProviders(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_provider':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getProvider($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_provider':
			echo json_encode(APIWrapper::createProvider($a27e64cc6ce01033));

			break;

		case 'edit_provider':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editProvider($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_provider':
			echo json_encode(APIWrapper::deleteProvider($a27e64cc6ce01033['id']));

			break;

		case 'reload_provider':
			echo json_encode(APIWrapper::reloadProvider((isset($a27e64cc6ce01033['id']) ? intval($a27e64cc6ce01033['id']) : null)));

			break;

		case 'get_groups':
			echo json_encode(APIWrapper::filterRows(APIWrapper::getGroups(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_group':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getGroup($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_group':
			echo json_encode(APIWrapper::createGroup($a27e64cc6ce01033));

			break;

		case 'edit_group':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editGroup($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_group':
			echo json_encode(APIWrapper::a2131b0F20f53705($a27e64cc6ce01033['id']));

			break;

		case 'get_packages':
			echo json_encode(APIWrapper::filterRows(APIWrapper::F22bC4Cb88ADAfD4(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_package':
			echo json_encode(APIWrapper::filterRow(APIWrapper::c1e8f3a78f5105fb($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_package':
			echo json_encode(APIWrapper::createPackage($a27e64cc6ce01033));

			break;

		case 'edit_package':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editPackage($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_package':
			echo json_encode(APIWrapper::e7DaF1C9C4775cb4($a27e64cc6ce01033['id']));

			break;

		case 'get_transcode_profiles':
			echo json_encode(APIWrapper::filterRows(APIWrapper::B1dA0f08C5C7b733(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_transcode_profile':
			echo json_encode(APIWrapper::filterRow(APIWrapper::F0e31E0BE8A5f743($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_transcode_profile':
			echo json_encode(APIWrapper::createTranscodeProfile($a27e64cc6ce01033));

			break;

		case 'edit_transcode_profile':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editTranscodeProfile($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_transcode_profile':
			echo json_encode(APIWrapper::deleteTranscodeProfile($a27e64cc6ce01033['id']));

			break;

		case 'get_rtmp_ips':
			echo json_encode(APIWrapper::filterRows(APIWrapper::E86a870a729dA398(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_rtmp_ip':
			echo json_encode(APIWrapper::filterRow(APIWrapper::e36bD523A0481fbc($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_rtmp_ip':
			echo json_encode(APIWrapper::addRTMPIP($a27e64cc6ce01033));

			break;

		case 'edit_rtmp_ip':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editRTMPIP($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_rtmp_ip':
			echo json_encode(APIWrapper::D8FF63df5c3A4cBF($a27e64cc6ce01033['id']));

			break;

		case 'get_categories':
			echo json_encode(APIWrapper::filterRows(APIWrapper::C7baBcbEC16c28eD(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_category':
			echo json_encode(APIWrapper::filterRow(APIWrapper::c792ce38dD4C21Ea($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_category':
			echo json_encode(APIWrapper::createCategory($a27e64cc6ce01033));

			break;

		case 'edit_category':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editCategory($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_category':
			echo json_encode(APIWrapper::a8738016bbD2FcF0($a27e64cc6ce01033['id']));

			break;

		case 'get_watch_folders':
			echo json_encode(APIWrapper::filterRows(APIWrapper::D6e21C0570bC3541(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_watch_folder':
			echo json_encode(APIWrapper::filterRow(APIWrapper::a9eca43EBf2640Fd($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_watch_folder':
			echo json_encode(APIWrapper::createWatchFolder($a27e64cc6ce01033));

			break;

		case 'edit_watch_folder':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editWatchFolder($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_watch_folder':
			echo json_encode(APIWrapper::b63515c157DDD098($a27e64cc6ce01033['id']));

			break;

		case 'reload_watch_folder':
			echo json_encode(APIWrapper::reloadWatchFolder((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID), $a27e64cc6ce01033['id']));

			break;

		case 'get_blocked_isps':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getBlockedISPs(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'add_blocked_isp':
			echo json_encode(APIWrapper::addBlockedISP($a27e64cc6ce01033['id']));

			break;

		case 'delete_blocked_isp':
			echo json_encode(APIWrapper::D7F379BbB97fAf1e($a27e64cc6ce01033['id']));

			break;

		case 'get_blocked_uas':
			echo json_encode(APIWrapper::filterRows(APIWrapper::getBlockedUAs(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'add_blocked_ua':
			echo json_encode(APIWrapper::addBlockedUA($a27e64cc6ce01033));

			break;

		case 'delete_blocked_ua':
			echo json_encode(APIWrapper::b8c0fd726e5B5b03($a27e64cc6ce01033['id']));

			break;

		case 'get_blocked_ips':
			echo json_encode(APIWrapper::filterRows(APIWrapper::c9E378bB69540811(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'add_blocked_ip':
			echo json_encode(APIWrapper::addBlockedIP($a27e64cc6ce01033['id']));

			break;

		case 'delete_blocked_ip':
			echo json_encode(APIWrapper::d79E572360c9DB6e($a27e64cc6ce01033['id']));

			break;

		case 'flush_blocked_ips':
			echo json_encode(APIWrapper::flushBlockedIPs());

			break;

		case 'get_stream':
			echo json_encode(APIWrapper::filterRow(APIWrapper::A12935C1A18F636A($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_stream':
			echo json_encode(APIWrapper::createStream($a27e64cc6ce01033));

			break;

		case 'edit_stream':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editStream($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_stream':
			echo json_encode(APIWrapper::F8468F4BA80B0a9E($a27e64cc6ce01033['id'], (isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : -1)));

			break;

		case 'start_station':
		case 'start_channel':
		case 'start_stream':
			echo json_encode(APIWrapper::EC4e6C6a6aABE235($a27e64cc6ce01033['id'], $a27e64cc6ce01033['server_id']));

			break;

		case 'stop_station':
		case 'stop_channel':
		case 'stop_stream':
			echo json_encode(APIWrapper::a52ea4C1eAD81De2($a27e64cc6ce01033['id'], $a27e64cc6ce01033['server_id']));

			break;

		case 'get_channel':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getChannel($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_channel':
			echo json_encode(APIWrapper::D2C822A2e8d18c4e($a27e64cc6ce01033));

			break;

		case 'edit_channel':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editChannel($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_channel':
			echo json_encode(APIWrapper::deleteChannel($a27e64cc6ce01033['id'], (isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : -1)));

			break;

		case 'get_station':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getStation($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_station':
			echo json_encode(APIWrapper::createStation($a27e64cc6ce01033));

			break;

		case 'edit_station':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editStation($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_station':
			echo json_encode(APIWrapper::deleteStation($a27e64cc6ce01033['id'], (isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : -1)));

			break;

		case 'get_movie':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getMovie($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_movie':
			echo json_encode(APIWrapper::createMovie($a27e64cc6ce01033));

			break;

		case 'edit_movie':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editMovie($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_movie':
			echo json_encode(APIWrapper::deleteMovie($a27e64cc6ce01033['id'], (isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : -1)));

			break;

		case 'start_episode':
		case 'start_movie':
			echo json_encode(APIWrapper::eD56a02053a7Dd1f($a27e64cc6ce01033['id'], $a27e64cc6ce01033['server_id']));

			break;

		case 'stop_episode':
		case 'stop_movie':
			echo json_encode(APIWrapper::cE7106285C19A01a($a27e64cc6ce01033['id'], $a27e64cc6ce01033['server_id']));

			break;

		case 'get_episode':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getEpisode($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_episode':
			echo json_encode(APIWrapper::createEpisode($a27e64cc6ce01033));

			break;

		case 'edit_episode':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editEpisode($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_episode':
			echo json_encode(APIWrapper::deleteEpisode($a27e64cc6ce01033['id'], (isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : -1)));

			break;

		case 'get_series':
			echo json_encode(APIWrapper::filterRow(APIWrapper::a0ddBAeA7eD9417b($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_series':
			echo json_encode(APIWrapper::createSeries($a27e64cc6ce01033));

			break;

		case 'edit_series':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editSeries($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_series':
			echo json_encode(APIWrapper::a91fDcBDa1F567f6($a27e64cc6ce01033['id']));

			break;

		case 'get_servers':
			echo json_encode(APIWrapper::filterRows(APIWrapper::f99d78e199d641D5(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_server':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getServer($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'install_server':
			$a27e64cc6ce01033['type'] = 0;
			echo json_encode(APIWrapper::BAAB8972232156Ee($a27e64cc6ce01033));

			break;

		case 'install_proxy':
			$a27e64cc6ce01033['type'] = 1;
			echo json_encode(APIWrapper::bAAB8972232156ee($a27e64cc6ce01033));

			break;

		case 'edit_server':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editServer($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'edit_proxy':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editProxy($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_server':
			echo json_encode(APIWrapper::c795D9C914339333($a27e64cc6ce01033['id']));

			break;

		case 'get_settings':
			echo json_encode(APIWrapper::filterRow(APIWrapper::d761e78da5eB70Fb(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'edit_settings':
			echo json_encode(APIWrapper::AFf4e84a1B89B55f($a27e64cc6ce01033));

			break;

		case 'get_server_stats':
			echo json_encode(APIWrapper::f4148D7DfAeE2F14((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'get_fpm_status':
			echo json_encode(APIWrapper::getFPMStatus((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'get_rtmp_stats':
			echo json_encode(APIWrapper::Cb312596CE3652d6((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'get_free_space':
			echo json_encode(APIWrapper::A691e4567DA91C78((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'get_pids':
			echo json_encode(APIWrapper::A2056Cb885588825((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'get_certificate_info':
			echo json_encode(APIWrapper::ac86c84C80E63449((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'reload_nginx':
			echo json_encode(APIWrapper::b208451Be469f925((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'clear_temp':
			echo json_encode(APIWrapper::clearTemp((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'clear_streams':
			echo json_encode(APIWrapper::clearStreams((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID)));

			break;

		case 'get_directory':
			echo json_encode(APIWrapper::getDirectory((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID), $a27e64cc6ce01033['dir']));

			break;

		case 'kill_pid':
			echo json_encode(APIWrapper::killPID((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID), $a27e64cc6ce01033['pid']));

			break;

		case 'kill_connection':
			echo json_encode(APIWrapper::killConnection((isset($a27e64cc6ce01033['server_id']) ? $a27e64cc6ce01033['server_id'] : SERVER_ID), $a27e64cc6ce01033['activity_id']));

			break;

		case 'adjust_credits':
			echo json_encode(APIWrapper::adjustCredits($a27e64cc6ce01033['id'], $a27e64cc6ce01033['credits'], (isset($a27e64cc6ce01033['reason']) ? $a27e64cc6ce01033['reason'] : '')));

			break;

		case 'reload_cache':
			echo json_encode(APIWrapper::reloadCache());

			break;

		default:
			echo json_encode(array('status' => 'STATUS_FAILURE', 'error' => 'Invalid action.'));

			break;
	}
} else {
	echo json_encode(array('status' => 'STATUS_FAILURE', 'error' => 'Invalid API key.'));
}

class APIWrapper
{
	public static $db = null;
	public static $rKey = null;

	public static function filterRow($a27e64cc6ce01033, $C9e42207e95f03ed, $Be763c6c88600252, $a7d423ebcdb2f5a0 = false)
	{
		if ($C9e42207e95f03ed || $Be763c6c88600252) {
			if ($a7d423ebcdb2f5a0) {
				$C740da31596f24ef = $a27e64cc6ce01033;
			} else {
				$C740da31596f24ef = $a27e64cc6ce01033['data'];
			}

			$a85e1b7d42c346a0 = array();

			if (!$C740da31596f24ef) {
			} else {
				foreach (array_keys($C740da31596f24ef) as $D3fa098be3f297cd) {
					if ($C9e42207e95f03ed) {
						if (!in_array($D3fa098be3f297cd, $C9e42207e95f03ed)) {
						} else {
							$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
						}
					} else {
						if (!$Be763c6c88600252) {
						} else {
							if (in_array($D3fa098be3f297cd, $Be763c6c88600252)) {
							} else {
								$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
							}
						}
					}
				}
			}

			if ($a7d423ebcdb2f5a0) {
				return $a85e1b7d42c346a0;
			}

			$a27e64cc6ce01033['data'] = $a85e1b7d42c346a0;

			return $a27e64cc6ce01033;
		}

		return $a27e64cc6ce01033;
	}

	public static function filterRows($b3439582205053ea, $C9e42207e95f03ed, $Be763c6c88600252)
	{
		$a85e1b7d42c346a0 = array();

		if (!$b3439582205053ea['data']) {
		} else {
			foreach ($b3439582205053ea['data'] as $C740da31596f24ef) {
				$a85e1b7d42c346a0[] = self::filterRow($C740da31596f24ef, $C9e42207e95f03ed, $Be763c6c88600252, true);
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function TableAPI($C3c8913edb801c35, $D031c48a1422c07e = 0, $E400a3101514583e = 10, $a27e64cc6ce01033 = array(), $E19a3b45051e169e = array(), $feb740b7803efea9 = array())
	{
		$d8d87e2673758d96 = 'http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/' . trim(dirname($_SERVER['PHP_SELF']), '/') . '/table.php';
		$a27e64cc6ce01033['api_key'] = self::$rKey;
		$a27e64cc6ce01033['id'] = $C3c8913edb801c35;
		$a27e64cc6ce01033['start'] = $D031c48a1422c07e;
		$a27e64cc6ce01033['length'] = $E400a3101514583e;
		$a27e64cc6ce01033['show_columns'] = $E19a3b45051e169e;
		$a27e64cc6ce01033['hide_columns'] = $feb740b7803efea9;
		$c88afcbaf19918af = curl_init();
		curl_setopt($c88afcbaf19918af, CURLOPT_URL, $d8d87e2673758d96);
		curl_setopt($c88afcbaf19918af, CURLOPT_POST, 1);
		curl_setopt($c88afcbaf19918af, CURLOPT_POSTFIELDS, http_build_query($a27e64cc6ce01033));
		curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($c88afcbaf19918af, CURLOPT_HTTPHEADER, array('X-Requested-With: xmlhttprequest'));
		$a85e1b7d42c346a0 = json_decode(curl_exec($c88afcbaf19918af), true);
		curl_close($c88afcbaf19918af);

		return $a85e1b7d42c346a0;
	}

	public static function createSession()
	{
		global $D4253f9520627819;
		global $B2ff75c438fb3031;
		self::$db->query('SELECT * FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `api_key` = ? AND LENGTH(`api_key`) > 0 AND `is_admin` = 1 AND `status` = 1;', self::$rKey);

		if (0 >= self::$db->num_rows()) {
			return false;
		}

		API::$db = &self::$db;
		API::init(self::$db->get_row()['id']);
		unset(API::$rUserInfo['password']);
		$D4253f9520627819 = API::$rUserInfo;
		$B2ff75c438fb3031 = f0aCF9DE3389B116($D4253f9520627819['member_group_id']);
		$B2ff75c438fb3031['advanced'] = array();

		if (0 >= strlen($D4253f9520627819['timezone'])) {
		} else {
			date_default_timezone_set($D4253f9520627819['timezone']);
		}

		return true;
	}

	public static function d7CA435ac70E9A78()
	{
		global $D4253f9520627819;
		global $B2ff75c438fb3031;

		return array('status' => 'STATUS_SUCCESS', 'data' => $D4253f9520627819, 'permissions' => $B2ff75c438fb3031);
	}

	public static function getLine($C3c8913edb801c35)
	{
		if (!($Ff014d0ebd314fcd = B4036ef9a1dB8473($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $Ff014d0ebd314fcd);
	}

	public static function createLine($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::d4cdf8772e0D536b($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getLine($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editLine($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($Ff014d0ebd314fcd = self::getLine($C3c8913edb801c35)) && isset($Ff014d0ebd314fcd['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;

		if (!isset($a27e64cc6ce01033['isp_clear'])) {
		} else {
			$a27e64cc6ce01033['isp_clear'] = '';
		}

		$a85e1b7d42c346a0 = parseerror(API::D4CDf8772E0D536B($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getLine($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function D6d7DcA66BBF5219($C3c8913edb801c35)
	{
		if (!(($Ff014d0ebd314fcd = self::getLine($C3c8913edb801c35)) && isset($Ff014d0ebd314fcd['data']))) {
		} else {
			if (!F8E4778e49869d84($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableLine($C3c8913edb801c35)
	{
		if (!(($Ff014d0ebd314fcd = self::getLine($C3c8913edb801c35)) && isset($Ff014d0ebd314fcd['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableLine($C3c8913edb801c35)
	{
		if (!(($Ff014d0ebd314fcd = self::getLine($C3c8913edb801c35)) && isset($Ff014d0ebd314fcd['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function banLine($C3c8913edb801c35)
	{
		if (!(($Ff014d0ebd314fcd = self::getLine($C3c8913edb801c35)) && isset($Ff014d0ebd314fcd['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function unbanLine($C3c8913edb801c35)
	{
		if (!(($Ff014d0ebd314fcd = self::getLine($C3c8913edb801c35)) && isset($Ff014d0ebd314fcd['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function CAf753aEB829e1DC($C3c8913edb801c35)
	{
		if (!($d51e425eb7375255 = FE76c4bcAf81Baa4($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $d51e425eb7375255);
	}

	public static function createUser($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::e8Ebe0D3e389584e($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::CAf753Aeb829e1Dc($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editUser($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($d51e425eb7375255 = self::CaF753aEb829E1dC($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::E8eBe0d3E389584e($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::cAF753aeB829E1dc($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function B764c5Db9b0c0680($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = self::Caf753Aeb829e1dC($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
		} else {
			if (!E4c6429A95c776Cf($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableUser($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = self::Caf753aEb829e1Dc($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `users` SET `status` = 0 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableUser($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = self::CAf753aEB829E1DC($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `users` SET `status` = 1 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function Ce5219A73Fa42510($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = bfe9937C6d242A3D($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $cdc93dae5ba3d206);
	}

	public static function createMAG($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::eB9eaD5B16d184f3($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::ce5219A73fA42510($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editMAG($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($cdc93dae5ba3d206 = self::ce5219a73fA42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;

		if (!isset($a27e64cc6ce01033['isp_clear'])) {
		} else {
			$a27e64cc6ce01033['isp_clear'] = '';
		}

		$a85e1b7d42c346a0 = parseerror(API::Eb9EAD5B16d184f3($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::cE5219A73FA42510($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function a5B26fBa2af56EA0($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::CE5219a73fa42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
		} else {
			if (!d8974b51b74C80Ee($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableMAG($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::cE5219a73FA42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableMAG($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::ce5219a73Fa42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function banMAG($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::Ce5219a73fa42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function unbanMAG($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::Ce5219a73Fa42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function convertMAG($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::Ce5219A73fa42510($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		d8974B51B74c80eE($C3c8913edb801c35, false, false, true);

		return array('status' => 'STATUS_SUCCESS', 'data' => self::getLine($cdc93dae5ba3d206['user_id']));
	}

	public static function C5E57969C08075A1($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = ba960cAb7Fe0cD93($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $cdc93dae5ba3d206);
	}

	public static function createEnigma($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::eCAF66B237906519($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::CE5219a73fA42510($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editEnigma($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($cdc93dae5ba3d206 = self::c5E57969C08075A1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;

		if (!isset($a27e64cc6ce01033['isp_clear'])) {
		} else {
			$a27e64cc6ce01033['isp_clear'] = '';
		}

		$a85e1b7d42c346a0 = parseerror(API::EcAf66B237906519($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::Ce5219a73fA42510($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function dE6358bA78f3971d($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::c5e57969c08075a1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
		} else {
			if (!a8Cd7c1DF629a648($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableEnigma($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::c5e57969C08075a1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableEnigma($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::c5e57969C08075A1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function banEnigma($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::C5e57969C08075A1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function unbanEnigma($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::C5e57969c08075a1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `admin_enabled` = 1 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function convertEnigma($C3c8913edb801c35)
	{
		if (!(($cdc93dae5ba3d206 = self::C5e57969C08075a1($C3c8913edb801c35)) && isset($cdc93dae5ba3d206['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		a8CD7c1DF629a648($C3c8913edb801c35, false, false, true);

		return array('status' => 'STATUS_SUCCESS', 'data' => self::getLine($cdc93dae5ba3d206['user_id']));
	}

	public static function D265fF208b308269()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => d7a15E0C2d9BECE1());
	}

	public static function e72E2a65258E1E8A($C3c8913edb801c35)
	{
		if (!($ddf0508b312dbfb8 = C8ADB574f9477F84($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $ddf0508b312dbfb8);
	}

	public static function createBouquet($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::c6ceF67e40287E05($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::E72E2a65258E1E8a($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editBouquet($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($ddf0508b312dbfb8 = self::e72e2a65258E1E8a($C3c8913edb801c35)) && isset($ddf0508b312dbfb8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::C6CEf67e40287e05($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::e72e2A65258E1e8A($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function FADA9D7505259037($C3c8913edb801c35)
	{
		if (!(($ddf0508b312dbfb8 = self::e72E2A65258e1E8A($C3c8913edb801c35)) && isset($ddf0508b312dbfb8['data']))) {
		} else {
			if (!DC08DdCe27705eCf($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function getAccessCodes()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => B0492aE58018Ce29());
	}

	public static function getAccessCode($C3c8913edb801c35)
	{
		if (!($c47b624a230c406a = b49a6a53AbB5A42b($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $c47b624a230c406a);
	}

	public static function createAccessCode($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::c26A6946575A9b88($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getAccessCode($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editAccessCode($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($c47b624a230c406a = self::getAccessCode($C3c8913edb801c35)) && isset($c47b624a230c406a['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::C26a6946575a9b88($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getAccessCode($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteAccessCode($C3c8913edb801c35)
	{
		if (!(($c47b624a230c406a = self::getAccessCode($C3c8913edb801c35)) && isset($c47b624a230c406a['data']))) {
		} else {
			if (!CEA678961006676D($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function getHMACs()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => E0E0b33ec3E01E79());
	}

	public static function getHMAC($C3c8913edb801c35)
	{
		if (!($ea5296071288c730 = A69c1563C73e6d19($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $ea5296071288c730);
	}

	public static function createHMAC($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::D991ba25e32737cE($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getHMAC($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editHMAC($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($ea5296071288c730 = self::getHMAC($C3c8913edb801c35)) && isset($ea5296071288c730['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::d991ba25E32737ce($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getHMAC($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function AAAa9643e21EDCb7($C3c8913edb801c35)
	{
		if (!(($ea5296071288c730 = self::getHMAC($C3c8913edb801c35)) && isset($ea5296071288c730['data']))) {
		} else {
			if (!cE67e6AC1132a14C($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function Fae50DEe78ecd0Fb()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => BaEa42B3F8E1780c());
	}

	public static function getEPG($C3c8913edb801c35)
	{
		if (!($d8a1409105424710 = getEPG($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $d8a1409105424710);
	}

	public static function createEPG($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::D4c0BD97CafdFaf7($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getEPG($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editEPG($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($d8a1409105424710 = self::getEPG($C3c8913edb801c35)) && isset($d8a1409105424710['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::d4c0Bd97CAFDfaf7($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getEPG($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function C9197556B739E655($C3c8913edb801c35)
	{
		if (!(($d8a1409105424710 = self::getEPG($C3c8913edb801c35)) && isset($d8a1409105424710['data']))) {
		} else {
			if (!F62970f78A40Cd4C($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function reloadEPG($C3c8913edb801c35 = null)
	{
		if ($C3c8913edb801c35) {
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'epg.php "' . intval($C3c8913edb801c35) . '" > /dev/null 2>/dev/null &');
		} else {
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'epg.php > /dev/null 2>/dev/null &');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getProviders()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => getStreamProviders());
	}

	public static function getProvider($C3c8913edb801c35)
	{
		if (!($Ad973fd3103e20dc = getStreamProvider($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $Ad973fd3103e20dc);
	}

	public static function createProvider($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::processProvider($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getProvider($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editProvider($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($Ad973fd3103e20dc = self::getProvider($C3c8913edb801c35)) && isset($Ad973fd3103e20dc['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::processProvider($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getProvider($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteProvider($C3c8913edb801c35)
	{
		if (!(($Ad973fd3103e20dc = self::getProvider($C3c8913edb801c35)) && isset($Ad973fd3103e20dc['data']))) {
		} else {
			if (!deleteProvider($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function reloadProvider($C3c8913edb801c35 = null)
	{
		if ($C3c8913edb801c35) {
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'providers.php "' . intval($C3c8913edb801c35) . '" > /dev/null 2>/dev/null &');
		} else {
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'providers.php > /dev/null 2>/dev/null &');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getGroups()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => ba348b5700EE9ff3());
	}

	public static function getGroup($C3c8913edb801c35)
	{
		if (!($D307572f7986a746 = a7685E0565a15403($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $D307572f7986a746);
	}

	public static function createGroup($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::BDe4e1A0450D3CD0($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getGroup($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editGroup($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($D307572f7986a746 = self::getGroup($C3c8913edb801c35)) && isset($D307572f7986a746['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::bDe4E1A0450D3CD0($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getGroup($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function A2131B0F20F53705($C3c8913edb801c35)
	{
		if (!(($D307572f7986a746 = self::getGroup($C3c8913edb801c35)) && isset($D307572f7986a746['data']))) {
		} else {
			if (!B7e0f83FC2BFC30b($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function F22BC4CB88aDaFD4()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => d19B453AC8E32c50());
	}

	public static function c1E8F3A78f5105fb($C3c8913edb801c35)
	{
		if (!($fe06d74291ffa213 = f0aCab09E248fc13($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $fe06d74291ffa213);
	}

	public static function createPackage($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::ba66921612ED64b0($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::c1E8F3A78F5105fb($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editPackage($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($fe06d74291ffa213 = self::C1E8f3a78F5105Fb($C3c8913edb801c35)) && isset($fe06d74291ffa213['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::Ba66921612ed64B0($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::C1e8f3a78F5105FB($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function E7dAF1c9c4775cB4($C3c8913edb801c35)
	{
		if (!(($fe06d74291ffa213 = self::c1e8F3a78F5105fB($C3c8913edb801c35)) && isset($fe06d74291ffa213['data']))) {
		} else {
			if (!C6084d728C503734($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function b1da0F08C5c7b733()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => efe0ce577Fb769BC());
	}

	public static function f0E31e0Be8a5f743($C3c8913edb801c35)
	{
		if (!($b8a339227222357b = CBC22956B573E5Cc($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $b8a339227222357b);
	}

	public static function createTranscodeProfile($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::a6c9CF2c4EdC8627($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::F0e31e0BE8A5F743($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editTranscodeProfile($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($b8a339227222357b = self::F0E31E0Be8A5F743($C3c8913edb801c35)) && isset($b8a339227222357b['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::a6C9cF2C4Edc8627($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::F0E31e0BE8A5F743($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteTranscodeProfile($C3c8913edb801c35)
	{
		if (!(($b8a339227222357b = self::f0E31e0bE8A5F743($C3c8913edb801c35)) && isset($b8a339227222357b['data']))) {
		} else {
			if (!E35e424dD2C18a18($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function e86a870A729dA398()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => b504eDC146895Dbd());
	}

	public static function E36Bd523a0481Fbc($C3c8913edb801c35)
	{
		if (!($c59ec257c284c894 = ae44475cA4238899($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $c59ec257c284c894);
	}

	public static function addRTMPIP($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::a6858093b7b0EDa5($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::E36bD523A0481fbc($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editRTMPIP($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($c59ec257c284c894 = self::e36bd523A0481fBC($C3c8913edb801c35)) && isset($c59ec257c284c894['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::A6858093b7b0EDa5($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::e36bD523A0481FBC($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function D8Ff63df5C3a4cBF($C3c8913edb801c35)
	{
		if (!(($c59ec257c284c894 = self::e36bd523A0481fbC($C3c8913edb801c35)) && isset($c59ec257c284c894['data']))) {
		} else {
			if (!baBdBAE2be721c62($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function c7BABCBeC16C28Ed()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => CBe87E2a9A996111());
	}

	public static function c792cE38Dd4C21Ea($C3c8913edb801c35)
	{
		if (!($A1925ae53e9307eb = E0e9955e91fA6027($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $A1925ae53e9307eb);
	}

	public static function createCategory($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::dc7B22871ac995e5($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::c792cE38Dd4C21ea($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editCategory($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($A1925ae53e9307eb = self::C792Ce38dd4C21EA($C3c8913edb801c35)) && isset($A1925ae53e9307eb['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::dc7B22871Ac995E5($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::C792ce38DD4C21EA($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function a8738016BBd2fcF0($C3c8913edb801c35)
	{
		if (!(($A1925ae53e9307eb = self::C792ce38dd4c21eA($C3c8913edb801c35)) && isset($A1925ae53e9307eb['data']))) {
		} else {
			if (!DBc1bc20914d084b($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function d6E21C0570bC3541()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => A4Cc632F26Df90DD());
	}

	public static function A9eCA43EbF2640Fd($C3c8913edb801c35)
	{
		if (!($b53b03db133532c7 = e6E296dD0051114B($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $b53b03db133532c7);
	}

	public static function createWatchFolder($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::a85970F9953C4294($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::A9ECA43ebF2640Fd($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editWatchFolder($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($b53b03db133532c7 = self::A9eCa43EBf2640Fd($C3c8913edb801c35)) && isset($b53b03db133532c7['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::A85970f9953c4294($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::A9Eca43ebf2640Fd($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function B63515C157dDd098($C3c8913edb801c35)
	{
		if (!(($b53b03db133532c7 = self::A9eca43eBF2640Fd($C3c8913edb801c35)) && isset($b53b03db133532c7['data']))) {
		} else {
			if (!eeC455fa54e2999D($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function reloadWatchFolder($d58b4f8653a391d8, $C3c8913edb801c35)
	{
		forceWatch($d58b4f8653a391d8, $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getBlockedISPs()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => F37B535A34F45fF6());
	}

	public static function addBlockedISP($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::cBb044eB5b5Fa5A2($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = $a85e1b7d42c346a0['data']['insert_id'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function d7f379BBB97faF1e($C3c8913edb801c35)
	{
		if (!bC0eC13f813c4ec5($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getBlockedUAs()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => EEe159feE39Ed442());
	}

	public static function addBlockedUA($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::ac56Fd7a04748A62($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = $a85e1b7d42c346a0['data']['insert_id'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function b8c0Fd726E5b5b03($C3c8913edb801c35)
	{
		if (!a67F300c600b609B($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function C9E378BB69540811()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => DD18CD7b718cd0f2());
	}

	public static function addBlockedIP($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::c638Ad4f75FF57A6($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = $a85e1b7d42c346a0['data']['insert_id'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function d79e572360C9db6E($C3c8913edb801c35)
	{
		if (!AA1526517E33a365($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function flushBlockedIPs()
	{
		Fa3A80ba9EfF25Da();

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function A12935C1a18F636A($C3c8913edb801c35)
	{
		if (!(($f523e362fb81d6c8 = E5ECeb32f67D5e70($C3c8913edb801c35)) && $f523e362fb81d6c8['type'] == 1)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $f523e362fb81d6c8);
	}

	public static function createStream($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::e0407C2c64B2C037($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::a12935c1A18F636A($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editStream($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($f523e362fb81d6c8 = self::A12935c1a18F636a($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::E0407c2C64b2c037($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::a12935c1A18f636a($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function F8468F4BA80b0a9e($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if (!(($f523e362fb81d6c8 = self::A12935c1a18f636a($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
		} else {
			if (!d13C1A44a4495B05($C3c8913edb801c35, $d58b4f8653a391d8)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function Ec4E6C6A6aABe235($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if ($d58b4f8653a391d8 == -1) {
			$a27e64cc6ce01033 = json_decode(e36Ec1583e223bf6(array('action' => 'stream', 'sub' => 'start', 'stream_ids' => array($C3c8913edb801c35), 'servers' => array_keys(XUI::$rServers))), true);
		} else {
			$a27e64cc6ce01033 = json_decode(a200986BBAE4b322($d58b4f8653a391d8, array('action' => 'stream', 'stream_ids' => array($C3c8913edb801c35), 'function' => 'start')), true);
		}

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function A52eA4C1EAd81de2($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if ($d58b4f8653a391d8 == -1) {
			$a27e64cc6ce01033 = json_decode(e36ec1583e223bF6(array('action' => 'stream', 'sub' => 'stop', 'stream_ids' => array($C3c8913edb801c35), 'servers' => array_keys(XUI::$rServers))), true);
		} else {
			$a27e64cc6ce01033 = json_decode(a200986BBAE4B322($d58b4f8653a391d8, array('action' => 'stream', 'stream_ids' => array($C3c8913edb801c35), 'function' => 'stop')), true);
		}

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getChannel($C3c8913edb801c35)
	{
		if (!(($f523e362fb81d6c8 = E5EceB32f67D5E70($C3c8913edb801c35)) && $f523e362fb81d6c8['type'] == 3)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $f523e362fb81d6c8);
	}

	public static function d2C822a2e8D18C4E($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::F3b2BE29C4Dd0b5E($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getChannel($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editChannel($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($f523e362fb81d6c8 = self::getChannel($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::F3b2be29C4DD0b5e($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getChannel($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteChannel($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if (!(($f523e362fb81d6c8 = self::getChannel($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
		} else {
			if (!d13C1A44A4495B05($C3c8913edb801c35, $d58b4f8653a391d8)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function getStation($C3c8913edb801c35)
	{
		if (!(($f523e362fb81d6c8 = E5eCeb32f67D5e70($C3c8913edb801c35)) && $f523e362fb81d6c8['type'] == 4)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $f523e362fb81d6c8);
	}

	public static function createStation($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::bfeCe7b7Fa4f9DC0($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getStation($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editStation($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($f523e362fb81d6c8 = self::getStation($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::BFecE7B7FA4F9dC0($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getStation($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteStation($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if (!(($f523e362fb81d6c8 = self::getStation($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
		} else {
			if (!D13C1A44a4495b05($C3c8913edb801c35, $d58b4f8653a391d8)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function getMovie($C3c8913edb801c35)
	{
		if (!(($f523e362fb81d6c8 = e5ecEb32f67d5E70($C3c8913edb801c35)) && $f523e362fb81d6c8['type'] == 2)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $f523e362fb81d6c8);
	}

	public static function createMovie($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::d4E96aC013e38c70($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getMovie($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editMovie($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($f523e362fb81d6c8 = self::getMovie($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::D4E96ac013e38c70($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getMovie($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteMovie($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if (!(($f523e362fb81d6c8 = self::getMovie($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
		} else {
			if (!D13C1a44A4495B05($C3c8913edb801c35, $d58b4f8653a391d8)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function Ed56A02053a7dD1f($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if ($d58b4f8653a391d8 == -1) {
			$a27e64cc6ce01033 = json_decode(E36eC1583E223bf6(array('action' => 'vod', 'sub' => 'start', 'stream_ids' => array($C3c8913edb801c35), 'servers' => array_keys(XUI::$rServers))), true);
		} else {
			$a27e64cc6ce01033 = json_decode(A200986bbaE4b322($d58b4f8653a391d8, array('action' => 'vod', 'stream_ids' => array($C3c8913edb801c35), 'function' => 'start')), true);
		}

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function cE7106285c19A01A($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if ($d58b4f8653a391d8 == -1) {
			$a27e64cc6ce01033 = json_decode(E36ec1583e223bF6(array('action' => 'vod', 'sub' => 'stop', 'stream_ids' => array($C3c8913edb801c35), 'servers' => array_keys(XUI::$rServers))), true);
		} else {
			$a27e64cc6ce01033 = json_decode(A200986BBae4b322($d58b4f8653a391d8, array('action' => 'vod', 'stream_ids' => array($C3c8913edb801c35), 'function' => 'stop')), true);
		}

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getEpisode($C3c8913edb801c35)
	{
		if (!(($f523e362fb81d6c8 = E5ecEB32f67D5E70($C3c8913edb801c35)) && $f523e362fb81d6c8['type'] == 5)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $f523e362fb81d6c8);
	}

	public static function createEpisode($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::B490BCcECC0e1ad3($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getEpisode($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editEpisode($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($f523e362fb81d6c8 = self::getEpisode($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::B490bCcECC0e1ad3($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getEpisode($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function deleteEpisode($C3c8913edb801c35, $d58b4f8653a391d8 = -1)
	{
		if (!(($f523e362fb81d6c8 = self::getEpisode($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
		} else {
			if (!d13c1A44a4495B05($C3c8913edb801c35, $d58b4f8653a391d8)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function a0DDbaea7Ed9417b($C3c8913edb801c35)
	{
		if (!($bbc84f53c534450d = fFD24E407AbB46EB($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $bbc84f53c534450d);
	}

	public static function createSeries($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(API::DeFd4d23b6637937($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::a0dDBAeA7ed9417b($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editSeries($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($f523e362fb81d6c8 = self::a0ddbaEA7ED9417B($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::Defd4d23B6637937($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::a0ddbaea7Ed9417B($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function A91FdcbDA1F567F6($C3c8913edb801c35)
	{
		if (!(($f523e362fb81d6c8 = self::a0dDbaEA7Ed9417B($C3c8913edb801c35)) && isset($f523e362fb81d6c8['data']))) {
		} else {
			if (!Bc3DfBaa6322045e($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function f99d78E199d641d5()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => f6dA964066F2F5e4());
	}

	public static function getServer($C3c8913edb801c35)
	{
		if (!($e81220b4451f37c9 = eeCB64fd7D6B8430($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $e81220b4451f37c9);
	}

	public static function BAAb8972232156eE($a27e64cc6ce01033)
	{
		if (!(empty($a27e64cc6ce01033['type']) || empty($a27e64cc6ce01033['ssh_port']) || empty($a27e64cc6ce01033['root_username']) || empty($a27e64cc6ce01033['root_password']))) {
			if (!($a27e64cc6ce01033['type'] == 1 && (empty($a27e64cc6ce01033['type']) || empty($a27e64cc6ce01033['ssh_port'])))) {
				$a85e1b7d42c346a0 = parseerror(API::BAAb8972232156eE($a27e64cc6ce01033));

				if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
				} else {
					$a85e1b7d42c346a0['data'] = self::getServer($a85e1b7d42c346a0['data']['insert_id']);
				}

				return array('status' => 'STATUS_FAILURE');
			}

			return array('status' => 'STATUS_INVALID_INPUT');
		}

		return array('status' => 'STATUS_INVALID_INPUT');
	}

	public static function editServer($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($e81220b4451f37c9 = self::getServer($C3c8913edb801c35)) && isset($e81220b4451f37c9['data']))) {
			return array('status' => 'STATUS_FAILURE');
		} else{

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::F6891f9C339Ac681($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getServer($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;}
	}

	public static function editProxy($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($e81220b4451f37c9 = self::getServer($C3c8913edb801c35)) && isset($e81220b4451f37c9['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(API::fA3e5A3EA20DA904($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getServer($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function C795d9c914339333($C3c8913edb801c35)
	{
		if (!(($e81220b4451f37c9 = self::getServer($C3c8913edb801c35)) && isset($e81220b4451f37c9['data']))) {
		} else {
			if (!c234Ae70b52D65a2($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function D761e78DA5eB70fB()
	{
		return array('status' => 'STATUS_SUCCESS', 'data' => A5fC308345057e29());
	}

	public static function aFF4E84a1b89b55F($a27e64cc6ce01033)
	{
		$a85e1b7d42c346a0 = parseerror(API::afF4E84a1B89B55f($a27e64cc6ce01033));
		$a85e1b7d42c346a0['data'] = self::D761e78Da5eB70Fb()['data'];

		return $a85e1b7d42c346a0;
	}

	public static function f4148D7dfAee2f14($d58b4f8653a391d8)
	{
		global $Fee0d5a474c96306;
		$a27e64cc6ce01033 = json_decode(a200986bBAe4B322($d58b4f8653a391d8, array('action' => 'stats')), true);

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['requests_per_second'] = XUI::$rServers[$d58b4f8653a391d8]['requests_per_second'];
		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `server_id` = ? AND `hls_end` = 0;', $d58b4f8653a391d8);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['open_connections'] = $Fee0d5a474c96306->get_row()['count'];
		}

		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `hls_end` = 0;');

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['total_connections'] = $Fee0d5a474c96306->get_row()['count'];
		}

		$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `server_id` = ? AND `hls_end` = 0 GROUP BY `user_id`;', $d58b4f8653a391d8);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['online_users'] = $Fee0d5a474c96306->num_rows();
		}

		$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['total_users'] = $Fee0d5a474c96306->num_rows();
		}

		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `stream_status` <> 2 AND `type` = 1;', $d58b4f8653a391d8);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['total_streams'] = $Fee0d5a474c96306->get_row()['count'];
		}

		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `pid` > 0 AND `type` = 1;', $d58b4f8653a391d8);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['total_running_streams'] = $Fee0d5a474c96306->get_row()['count'];
		}

		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `server_id` = ? AND `type` = 1 AND (`streams`.`direct_source` = 0 AND (`streams_servers`.`monitor_pid` IS NOT NULL AND `streams_servers`.`monitor_pid` > 0) AND (`streams_servers`.`pid` IS NULL OR `streams_servers`.`pid` <= 0) AND `streams_servers`.`stream_status` <> 0);', $d58b4f8653a391d8);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$a27e64cc6ce01033['offline_streams'] = $Fee0d5a474c96306->get_row()['count'];
		}

		$a27e64cc6ce01033['network_guaranteed_speed'] = XUI::$rServers[$d58b4f8653a391d8]['network_guaranteed_speed'];

		return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
	}

	public static function getFPMStatus($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = a200986bbAE4B322($d58b4f8653a391d8, array('action' => 'fpm_status'));

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
	}

	public static function Cb312596CE3652d6($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = json_decode(A200986Bbae4B322($d58b4f8653a391d8, array('action' => 'rtmp_stats')), true);

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
	}

	public static function A691E4567Da91C78($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = json_decode(A200986bBAe4b322($d58b4f8653a391d8, array('action' => 'get_free_space')), true);

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
	}

	public static function A2056Cb885588825($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = json_decode(A200986bBae4b322($d58b4f8653a391d8, array('action' => 'get_pids')), true);

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
	}

	public static function aC86c84c80e63449($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = json_decode(A200986bbAe4b322($d58b4f8653a391d8, array('action' => 'get_certificate_info')), true);

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
	}

	public static function b208451Be469F925($d58b4f8653a391d8)
	{
		a200986bBaE4B322($d58b4f8653a391d8, array('action' => 'reload_nginx'));

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function clearTemp($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = json_decode(a200986bBae4B322($d58b4f8653a391d8, array('action' => 'free_temp')), true);

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function clearStreams($d58b4f8653a391d8)
	{
		$a27e64cc6ce01033 = json_decode(A200986bbae4B322($d58b4f8653a391d8, array('action' => 'free_streams')), true);

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function getDirectory($d58b4f8653a391d8, $aba46ae86a79ad10)
	{
		$a27e64cc6ce01033 = json_decode(a200986bbAe4b322($d58b4f8653a391d8, array('action' => 'scandir', 'dir' => $aba46ae86a79ad10)), true);

		if (!$a27e64cc6ce01033) {
			return array('status' => 'STATUS_FAILURE');
		}

		unset($a27e64cc6ce01033['result']);

		if (!isset($a27e64cc6ce01033['result']) || $a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_SUCCESS', 'data' => $a27e64cc6ce01033);
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function killPID($d58b4f8653a391d8, $f9b07d216a168dcc)
	{
		$a27e64cc6ce01033 = json_decode(a200986BBaE4B322($d58b4f8653a391d8, array('action' => 'kill_pid', 'pid' => intval($f9b07d216a168dcc))), true);

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function killConnection($d58b4f8653a391d8, $E45885a3d47bc07e)
	{
		$a27e64cc6ce01033 = json_decode(a200986BBae4B322($d58b4f8653a391d8, array('action' => 'closeConnection', 'activity_id' => intval($E45885a3d47bc07e))), true);

		if (!$a27e64cc6ce01033['result']) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function adjustCredits($C3c8913edb801c35, $F17f20a56056dab3, $bbb9e3ea56d49450 = '')
	{
		global $Fee0d5a474c96306;
		global $D4253f9520627819;

		if (!(is_numeric($F17f20a56056dab3) && ($d51e425eb7375255 = self::caf753aeB829E1dc($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
		} else {
			$F17f20a56056dab3 = intval($d51e425eb7375255['data']['credits']) + intval($F17f20a56056dab3);

			if (0 > $F17f20a56056dab3) {
			} else {
				$Fee0d5a474c96306->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $F17f20a56056dab3, $C3c8913edb801c35);
				$Fee0d5a474c96306->query('INSERT INTO `users_credits_logs`(`target_id`, `admin_id`, `amount`, `date`, `reason`) VALUES(?, ?, ?, ?, ?);', $C3c8913edb801c35, $D4253f9520627819['id'], $F17f20a56056dab3, time(), $bbb9e3ea56d49450);

				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function reloadCache()
	{
		shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache_engine.php > /dev/null 2>/dev/null &');

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function runQuery($A6d7047f2fda966c)
	{
		global $Fee0d5a474c96306;

		if (!$Fee0d5a474c96306->query($A6d7047f2fda966c)) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $Fee0d5a474c96306->get_rows(), 'insert_id' => $Fee0d5a474c96306->last_insert_id());
	}
}

function parseError($d49041d5f05a9270)
{
	global $b6f6dd705fb93d5e;

	if (!(isset($d49041d5f05a9270['status']) && is_numeric($d49041d5f05a9270['status']))) {
	} else {
		$d49041d5f05a9270['status'] = $b6f6dd705fb93d5e[$d49041d5f05a9270['status']];
	}

	if ($d49041d5f05a9270) {
	} else {
		$d49041d5f05a9270['status'] = 'STATUS_NO_PERMISSIONS';
	}

	return $d49041d5f05a9270;
}
