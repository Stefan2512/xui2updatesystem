<?php

if (defined('XUI_HOME')) {
} else {
	define('XUI_HOME', '/home/xui/');
}

require_once XUI_HOME . 'includes/admin.php';
$b6f6dd705fb93d5e = array();

foreach (get_defined_constants(true)['user'] as $D3fa098be3f297cd => $b6842cb20051e925) {
	if (substr($D3fa098be3f297cd, 0, 7) != 'STATUS_') {
	} else {
		$b6f6dd705fb93d5e[intval($b6842cb20051e925)] = $D3fa098be3f297cd;
	}
}
$a27e64cc6ce01033 = XUI::$rRequest;
APIWrapper::$db = &$Fee0d5a474c96306;
APIWrapper::$rKey = $a27e64cc6ce01033['api_key'];

if (!empty(XUI::$rRequest['api_key']) && APIWrapper::createSession()) {
	$fa7da6c202358e0c = $a27e64cc6ce01033['action'];
	$D031c48a1422c07e = (intval($a27e64cc6ce01033['start']) ?: 0);
	$E400a3101514583e = (intval($a27e64cc6ce01033['limit']) ?: 50);
	unset($a27e64cc6ce01033['api_key'], $a27e64cc6ce01033['action'], $a27e64cc6ce01033['start'], $a27e64cc6ce01033['limit']);

	if (isset(XUI::$rRequest['show_columns'])) {
		$E19a3b45051e169e = explode(',', XUI::$rRequest['show_columns']);
	} else {
		$E19a3b45051e169e = null;
	}

	if (isset(XUI::$rRequest['hide_columns'])) {
		$feb740b7803efea9 = explode(',', XUI::$rRequest['hide_columns']);
	} else {
		$feb740b7803efea9 = null;
	}

	switch ($fa7da6c202358e0c) {
		case 'packages':
			echo json_encode(APIWrapper::filterRow(APIWrapper::F22Bc4cB88aDafd4(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'user_info':
			echo json_encode(APIWrapper::filterRow(APIWrapper::d7CA435ac70E9A78(), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_lines':
			echo json_encode(APIWrapper::TableAPI('lines', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_mags':
			echo json_encode(APIWrapper::TableAPI('mags', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_enigmas':
			echo json_encode(APIWrapper::TableAPI('enigmas', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_users':
			echo json_encode(APIWrapper::TableAPI('reg_users', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'activity_logs':
			echo json_encode(APIWrapper::TableAPI('line_activity', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'live_connections':
			echo json_encode(APIWrapper::TableAPI('live_connections', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'user_logs':
			echo json_encode(APIWrapper::TableAPI('reg_user_logs', $D031c48a1422c07e, $E400a3101514583e, $a27e64cc6ce01033, $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'get_line':
			echo json_encode(APIWrapper::filterRow(APIWrapper::getLine(XUI::$rRequest['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_line':
			echo json_encode(APIWrapper::createLine(XUI::$rRequest));

			break;

		case 'edit_line':
			$a27e64cc6ce01033 = XUI::$rRequest;
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editLine(XUI::$rRequest['id'], $a27e64cc6ce01033));

			break;

		case 'delete_line':
			echo json_encode(APIWrapper::d6d7DcA66BBf5219(XUI::$rRequest['id']));

			break;

		case 'disable_line':
			echo json_encode(APIWrapper::disableLine(XUI::$rRequest['id']));

			break;

		case 'enable_line':
			echo json_encode(APIWrapper::enableLine(XUI::$rRequest['id']));

			break;

		case 'get_mag':
			echo json_encode(APIWrapper::filterRow(APIWrapper::cE5219A73Fa42510(XUI::$rRequest['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_mag':
			echo json_encode(APIWrapper::createMAG(XUI::$rRequest));

			break;

		case 'edit_mag':
			$a27e64cc6ce01033 = XUI::$rRequest;
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editMAG(XUI::$rRequest['id'], $a27e64cc6ce01033));

			break;

		case 'delete_mag':
			echo json_encode(APIWrapper::a5b26fba2af56eA0(XUI::$rRequest['id']));

			break;

		case 'disable_mag':
			echo json_encode(APIWrapper::disableMAG(XUI::$rRequest['id']));

			break;

		case 'enable_mag':
			echo json_encode(APIWrapper::enableMAG(XUI::$rRequest['id']));

			break;

		case 'convert_mag':
			echo json_encode(APIWrapper::convertMAG(XUI::$rRequest['id']));

			break;

		case 'get_enigma':
			echo json_encode(APIWrapper::filterRow(APIWrapper::C5E57969c08075a1(XUI::$rRequest['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_enigma':
			echo json_encode(APIWrapper::createEnigma(XUI::$rRequest));

			break;

		case 'edit_enigma':
			$a27e64cc6ce01033 = XUI::$rRequest;
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editEnigma(XUI::$rRequest['id'], $a27e64cc6ce01033));

			break;

		case 'delete_enigma':
			echo json_encode(APIWrapper::De6358ba78F3971D(XUI::$rRequest['id']));

			break;

		case 'disable_enigma':
			echo json_encode(APIWrapper::disableEnigma(XUI::$rRequest['id']));

			break;

		case 'enable_enigma':
			echo json_encode(APIWrapper::enableEnigma(XUI::$rRequest['id']));

			break;

		case 'convert_enigma':
			echo json_encode(APIWrapper::convertEnigma(XUI::$rRequest['id']));

			break;

		case 'get_user':
			if (in_array('password', $feb740b7803efea9)) {
			} else {
				$feb740b7803efea9[] = 'password';
			}

			echo json_encode(APIWrapper::filterRow(APIWrapper::CaF753Aeb829e1Dc($a27e64cc6ce01033['id']), $E19a3b45051e169e, $feb740b7803efea9));

			break;

		case 'create_user':
			echo json_encode(APIWrapper::createUser($a27e64cc6ce01033));

			break;

		case 'edit_user':
			$C3c8913edb801c35 = $a27e64cc6ce01033['id'];
			unset($a27e64cc6ce01033['id']);
			echo json_encode(APIWrapper::editUser($C3c8913edb801c35, $a27e64cc6ce01033));

			break;

		case 'delete_user':
			echo json_encode(APIWrapper::b764c5Db9B0c0680($a27e64cc6ce01033['id']));

			break;

		case 'disable_user':
			echo json_encode(APIWrapper::disableUser($a27e64cc6ce01033['id']));

			break;

		case 'enable_user':
			echo json_encode(APIWrapper::enableUser($a27e64cc6ce01033['id']));

			break;

		case 'adjust_credits':
			echo json_encode(APIWrapper::adjustCredits($a27e64cc6ce01033['id'], $a27e64cc6ce01033['credits'], ($a27e64cc6ce01033['note'] ?: '')));

			break;

		default:
			echo json_encode(array('status' => 'STATUS_FAILURE', 'error' => 'Invalid action.'));

			break;
	}
} else {
	echo json_encode(array('status' => 'STATUS_FAILURE', 'error' => 'Invalid API key.'));
}

class APIWrapper
{
	public static $db = null;
	public static $rKey = null;

	public static function filterRow($a27e64cc6ce01033, $C9e42207e95f03ed, $Be763c6c88600252, $a7d423ebcdb2f5a0 = false)
	{
		if ($C9e42207e95f03ed || $Be763c6c88600252) {
			if ($a7d423ebcdb2f5a0) {
				$C740da31596f24ef = $a27e64cc6ce01033;
			} else {
				$C740da31596f24ef = $a27e64cc6ce01033['data'];
			}

			$a85e1b7d42c346a0 = array();

			if (!$C740da31596f24ef) {
			} else {
				foreach (array_keys($C740da31596f24ef) as $D3fa098be3f297cd) {
					if ($C9e42207e95f03ed) {
						if (!in_array($D3fa098be3f297cd, $C9e42207e95f03ed)) {
						} else {
							$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
						}
					} else {
						if (!$Be763c6c88600252) {
						} else {
							if (in_array($D3fa098be3f297cd, $Be763c6c88600252)) {
							} else {
								$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
							}
						}
					}
				}
			}

			if ($a7d423ebcdb2f5a0) {
				return $a85e1b7d42c346a0;
			}

			$a27e64cc6ce01033['data'] = $a85e1b7d42c346a0;

			return $a27e64cc6ce01033;
		}

		return $a27e64cc6ce01033;
	}

	public static function filterRows($b3439582205053ea, $C9e42207e95f03ed, $Be763c6c88600252)
	{
		$a85e1b7d42c346a0 = array();

		if (!$b3439582205053ea['data']) {
		} else {
			foreach ($b3439582205053ea['data'] as $C740da31596f24ef) {
				$a85e1b7d42c346a0[] = self::filterRow($C740da31596f24ef, $C9e42207e95f03ed, $Be763c6c88600252, true);
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function TableAPI($C3c8913edb801c35, $D031c48a1422c07e = 0, $E400a3101514583e = 10, $a27e64cc6ce01033 = array(), $E19a3b45051e169e = array(), $feb740b7803efea9 = array())
	{
		$d8d87e2673758d96 = 'http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/' . trim(dirname($_SERVER['PHP_SELF']), '/') . '/table.php';
		$a27e64cc6ce01033['api_key'] = self::$rKey;
		$a27e64cc6ce01033['id'] = $C3c8913edb801c35;
		$a27e64cc6ce01033['start'] = $D031c48a1422c07e;
		$a27e64cc6ce01033['length'] = $E400a3101514583e;
		$a27e64cc6ce01033['show_columns'] = $E19a3b45051e169e;
		$a27e64cc6ce01033['hide_columns'] = $feb740b7803efea9;
		$c88afcbaf19918af = curl_init();
		curl_setopt($c88afcbaf19918af, CURLOPT_URL, $d8d87e2673758d96);
		curl_setopt($c88afcbaf19918af, CURLOPT_POST, 1);
		curl_setopt($c88afcbaf19918af, CURLOPT_POSTFIELDS, http_build_query($a27e64cc6ce01033));
		curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($c88afcbaf19918af, CURLOPT_HTTPHEADER, array('X-Requested-With: xmlhttprequest'));
		$a85e1b7d42c346a0 = json_decode(curl_exec($c88afcbaf19918af), true);
		curl_close($c88afcbaf19918af);

		return $a85e1b7d42c346a0;
	}

	public static function createSession()
	{
		global $D4253f9520627819;
		global $B2ff75c438fb3031;
		self::$db->query('SELECT * FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `api_key` = ? AND LENGTH(`api_key`) > 0 AND `is_reseller` = 1 AND `status` = 1;', self::$rKey);

		if (0 >= self::$db->num_rows()) {
			return false;
		}

		ResellerAPI::$db = &self::$db;
		ResellerAPI::init(self::$db->get_row()['id']);
		unset(ResellerAPI::$rUserInfo['password']);
		$D4253f9520627819 = ResellerAPI::$rUserInfo;
		$B2ff75c438fb3031 = ResellerAPI::$rPermissions;

		if (0 >= strlen($D4253f9520627819['timezone'])) {
		} else {
			date_default_timezone_set($D4253f9520627819['timezone']);
		}

		return true;
	}

	public static function d7ca435ac70E9a78()
	{
		global $D4253f9520627819;
		global $B2ff75c438fb3031;

		return array('status' => 'STATUS_SUCCESS', 'data' => $D4253f9520627819, 'permissions' => $B2ff75c438fb3031);
	}

	public static function F22bC4cB88adAfD4()
	{
		global $D4253f9520627819;

		if (!$D4253f9520627819) {
			return array('status' => 'STATUS_FAILURE');
		}

		$D57b432dc56eb885 = array();
		$B4a5141c87d1c427 = json_decode($D4253f9520627819['override_packages'], true);

		foreach (D19b453AC8e32C50($D4253f9520627819['member_group_id']) as $fe06d74291ffa213) {
			if (isset($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']) && 0 < strlen($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits'])) {
				$fe06d74291ffa213['official_credits'] = intval($B4a5141c87d1c427[$fe06d74291ffa213['id']]['official_credits']);
			} else {
				$fe06d74291ffa213['official_credits'] = intval($fe06d74291ffa213['official_credits']);
			}

			$D57b432dc56eb885[] = $fe06d74291ffa213;
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $D57b432dc56eb885);
	}

	public static function getLine($C3c8913edb801c35)
	{
		if (!(($Ff014d0ebd314fcd = b4036EF9A1dB8473($C3c8913edb801c35)) && aAcD47d8157a1A09('line', $C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $Ff014d0ebd314fcd);
	}

	public static function createLine($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::d4cDF8772e0d536b($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getLine($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editLine($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!B4036EF9a1Db8473($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;

		if (!isset($a27e64cc6ce01033['isp_clear'])) {
		} else {
			$a27e64cc6ce01033['isp_clear'] = '';
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::D4CDf8772e0d536B($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::getLine($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function D6D7dCa66BbF5219($C3c8913edb801c35)
	{
		if (!b4036Ef9A1DB8473($C3c8913edb801c35)) {
		} else {
			if (!f8e4778e49869d84($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableLine($C3c8913edb801c35)
	{
		if (!B4036Ef9a1DB8473($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableLine($C3c8913edb801c35)
	{
		if (!B4036eF9A1DB8473($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function ce5219a73fa42510($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = bFE9937c6D242a3d($C3c8913edb801c35))) {
		} else {
			if (!AAcD47D8157A1A09('line', $cdc93dae5ba3d206['user_id'])) {
			} else {
				return array('status' => 'STATUS_SUCCESS', 'data' => $cdc93dae5ba3d206);
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function createMAG($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::EB9eAD5b16D184F3($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::CE5219A73Fa42510($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editMAG($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!BFE9937c6d242A3d($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;

		if (!isset($a27e64cc6ce01033['isp_clear'])) {
		} else {
			$a27e64cc6ce01033['isp_clear'] = '';
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::eb9EAD5B16D184F3($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::CE5219a73fA42510($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function a5B26FBa2aF56ea0($C3c8913edb801c35)
	{
		if (!BFe9937C6D242A3D($C3c8913edb801c35)) {
		} else {
			if (!D8974B51B74c80eE($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableMAG($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = bFe9937C6d242a3d($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableMAG($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = BFE9937c6d242a3d($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function convertMAG($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = bfe9937C6D242a3d($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		D8974B51b74c80ee($C3c8913edb801c35, false, false, true);

		return array('status' => 'STATUS_SUCCESS', 'data' => b4036eF9A1dB8473($cdc93dae5ba3d206['user_id']));
	}

	public static function C5e57969C08075a1($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = BA960cab7FE0Cd93($C3c8913edb801c35))) {
		} else {
			if (!aacD47D8157a1A09('line', $cdc93dae5ba3d206['user_id'])) {
			} else {
				return array('status' => 'STATUS_SUCCESS', 'data' => $cdc93dae5ba3d206);
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function createEnigma($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::EcAF66b237906519($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::C5e57969C08075A1($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editEnigma($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!ba960CAB7FE0cD93($C3c8913edb801c35)) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;

		if (!isset($a27e64cc6ce01033['isp_clear'])) {
		} else {
			$a27e64cc6ce01033['isp_clear'] = '';
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::ECAf66B237906519($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::C5e57969C08075A1($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function De6358Ba78f3971D($C3c8913edb801c35)
	{
		if (!BA960cAB7FE0cD93($C3c8913edb801c35)) {
		} else {
			if (!A8cd7c1DF629A648($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableEnigma($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = bA960CaB7fe0Cd93($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 0 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableEnigma($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = bA960cAb7fe0CD93($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `lines` SET `enabled` = 1 WHERE `id` = ?;', $cdc93dae5ba3d206['user_id']);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function convertEnigma($C3c8913edb801c35)
	{
		if (!($cdc93dae5ba3d206 = ba960cAb7Fe0Cd93($C3c8913edb801c35))) {
			return array('status' => 'STATUS_FAILURE');
		}

		a8cD7c1df629A648($C3c8913edb801c35, false, false, true);

		return array('status' => 'STATUS_SUCCESS', 'data' => B4036EF9A1db8473($cdc93dae5ba3d206['user_id']));
	}

	public static function CAf753aEB829E1dC($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = fE76C4bCAF81BAa4($C3c8913edb801c35)) && aAcd47D8157A1a09('user', $d51e425eb7375255['id']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		return array('status' => 'STATUS_SUCCESS', 'data' => $d51e425eb7375255);
	}

	public static function createUser($a27e64cc6ce01033)
	{
		if (!isset($a27e64cc6ce01033['edit'])) {
		} else {
			unset($a27e64cc6ce01033['edit']);
		}

		$a85e1b7d42c346a0 = parseerror(ResellerAPI::e8eBe0d3e389584E($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::cAF753aEb829e1DC($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function editUser($C3c8913edb801c35, $a27e64cc6ce01033)
	{
		if (!(($d51e425eb7375255 = self::CAF753aeB829e1Dc($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		$a27e64cc6ce01033['edit'] = $C3c8913edb801c35;
		$a85e1b7d42c346a0 = parseerror(ResellerAPI::E8EBE0D3E389584e($a27e64cc6ce01033));

		if (!isset($a85e1b7d42c346a0['data']['insert_id'])) {
		} else {
			$a85e1b7d42c346a0['data'] = self::caF753AeB829E1dC($a85e1b7d42c346a0['data']['insert_id'])['data'];
		}

		return $a85e1b7d42c346a0;
	}

	public static function B764c5Db9B0C0680($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = self::CAF753AEb829e1dc($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
		} else {
			if (!e4c6429a95C776cF($C3c8913edb801c35)) {
			} else {
				return array('status' => 'STATUS_SUCCESS');
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}

	public static function disableUser($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = self::cAf753aeB829E1DC($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `users` SET `status` = 0 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function enableUser($C3c8913edb801c35)
	{
		if (!(($d51e425eb7375255 = self::cAF753aeb829e1DC($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
			return array('status' => 'STATUS_FAILURE');
		}

		self::$db->query('UPDATE `users` SET `status` = 1 WHERE `id` = ?;', $C3c8913edb801c35);

		return array('status' => 'STATUS_SUCCESS');
	}

	public static function adjustCredits($C3c8913edb801c35, $F17f20a56056dab3, $bcd983387c08c841)
	{
		global $D4253f9520627819;

		if (strlen($bcd983387c08c841) != 0) {
		} else {
			$bcd983387c08c841 = 'Reseller API Adjustment';
		}

		if (!(($d51e425eb7375255 = self::CaF753aeB829e1dC($C3c8913edb801c35)) && isset($d51e425eb7375255['data']))) {
		} else {
			if (!is_numeric($F17f20a56056dab3)) {
			} else {
				$fc8dba2b828b50f7 = intval($D4253f9520627819['credits']) - intval($F17f20a56056dab3);
				$Bf75a78bd3a0711d = intval($d51e425eb7375255['data']['credits']) + intval($F17f20a56056dab3);

				if (!(0 <= $Bf75a78bd3a0711d && 0 <= $fc8dba2b828b50f7)) {
				} else {
					self::$db->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $fc8dba2b828b50f7, $D4253f9520627819['id']);
					self::$db->query('UPDATE `users` SET `credits` = ? WHERE `id` = ?;', $Bf75a78bd3a0711d, $d51e425eb7375255['data']['id']);
					self::$db->query('INSERT INTO `users_credits_logs`(`target_id`, `admin_id`, `amount`, `date`, `reason`) VALUES(?, ?, ?, ?, ?);', $d51e425eb7375255['data']['id'], $D4253f9520627819['id'], $F17f20a56056dab3, time(), $bcd983387c08c841);
					self::$db->query("INSERT INTO `users_logs`(`owner`, `type`, `action`, `log_id`, `package_id`, `cost`, `credits_after`, `date`, `deleted_info`) VALUES(?, 'user', ?, ?, null, ?, ?, ?, ?);", $D4253f9520627819['id'], 'adjust_credits', $C3c8913edb801c35, intval($F17f20a56056dab3), $fc8dba2b828b50f7, time(), json_encode($d51e425eb7375255['data']));

					return array('status' => 'STATUS_SUCCESS');
				}
			}
		}

		return array('status' => 'STATUS_FAILURE');
	}
}

function parseError($d49041d5f05a9270)
{
	global $b6f6dd705fb93d5e;

	if (!(isset($d49041d5f05a9270['status']) && is_numeric($d49041d5f05a9270['status']))) {
	} else {
		$d49041d5f05a9270['status'] = $b6f6dd705fb93d5e[$d49041d5f05a9270['status']];
	}

	if ($d49041d5f05a9270) {
	} else {
		$d49041d5f05a9270['status'] = 'STATUS_NO_PERMISSIONS';
	}

	return $d49041d5f05a9270;
}
