<?php

session_start();
session_write_close();

if (file_exists('../www/init.php')) {
	require_once '../www/init.php';
} else {
	require_once '../../../www/init.php';
}

if (PHP_ERRORS) {
} else {
	if (!(empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest')) {
	} else {
		exit();
	}
}

$a85e1b7d42c346a0 = array('draw' => intval(XUI::$rRequest['draw']), 'recordsTotal' => 0, 'recordsFiltered' => 0, 'data' => array());
$B3f0f4a134021073 = false;

if (isset(XUI::$rRequest['api_key'])) {
	$a85e1b7d42c346a0 = array('status' => 'STATUS_SUCCESS', 'data' => array());
	$Fee0d5a474c96306->query('SELECT `id` FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` WHERE `api_key` = ? AND LENGTH(`api_key`) > 0 AND `is_reseller` = 1 AND `status` = 1;', XUI::$rRequest['api_key']);

	if ($Fee0d5a474c96306->num_rows() != 0) {
		$D78ff1d0edade5eb = $Fee0d5a474c96306->get_row()['id'];
		$B3f0f4a134021073 = true;
		require_once XUI_HOME . 'includes/admin.php';
		$D4253f9520627819 = fE76C4BcAf81baA4($D78ff1d0edade5eb);
		$B2ff75c438fb3031 = array_merge(F0Acf9dE3389b116($D4253f9520627819['member_group_id']), d29d7D4E98eA26da($D4253f9520627819['id']));

		if (0 >= strlen($D4253f9520627819['timezone'])) {
		} else {
			date_default_timezone_set($D4253f9520627819['timezone']);
		}
	} else {
		echo json_encode(array('status' => 'STATUS_FAILURE', 'error' => 'Invalid API key.'));

		exit();
	}
} else {
	if (isset($_SESSION['reseller'])) {
		include 'functions.php';
	} else {
		echo json_encode($a85e1b7d42c346a0);

		exit();
	}
}

if (!$D4253f9520627819['id']) {
	echo json_encode($a85e1b7d42c346a0);

	exit();
}

if (isset($D4253f9520627819['reports'])) {
	$E379394c7b1a273f = XUI::$rRequest['id'];
	$D031c48a1422c07e = intval(XUI::$rRequest['start']);
	$E400a3101514583e = intval(XUI::$rRequest['length']);

	if (!(1000 < $E400a3101514583e || $E400a3101514583e <= 0)) {
	} else {
		$E400a3101514583e = 1000;
	}

	if ($E379394c7b1a273f == 'lines') {
		if ($B2ff75c438fb3031['create_line']) {
			$c6c389b9adf3a40c = array('`lines`.`id`', '`lines`.`username`', '`lines`.`password`', '`users`.`username`', '`lines`.`enabled` - `lines`.`admin_enabled`', '`active_connections` > 0', '`lines`.`is_trial`', '`active_connections`', '`lines`.`max_connections`', '`lines`.`exp_date`', '`last_activity`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`lines`.`is_mag` = 0 AND `lines`.`is_e2` = 0';
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 6) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`lines`.`username` LIKE ? OR `lines`.`password` LIKE ? OR `users`.`username` LIKE ? OR FROM_UNIXTIME(`exp_date`) LIKE ? OR `lines`.`max_connections` LIKE ? OR `lines`.`reseller_notes` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`lines`.`admin_enabled` = 1 AND `lines`.`enabled` = 1 AND (`lines`.`exp_date` IS NULL OR `lines`.`exp_date` > UNIX_TIMESTAMP()))';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '`lines`.`enabled` = 0';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '`lines`.`admin_enabled` = 0';
						} else {
							if (XUI::$rRequest['filter'] == 4) {
								$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` <= UNIX_TIMESTAMP())';
							} else {
								if (XUI::$rRequest['filter'] != 5) {
								} else {
									$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
								}
							}
						}
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(`lines`.`id`) AS `count` FROM `lines` LEFT JOIN `users` ON `users`.`id` = `lines`.`member_id` ' . $ff9d21c7a9d310b1 . ';';

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `lines`.`id`, `lines`.`member_id`, `lines`.`last_activity`, `lines`.`last_activity_array`, `lines`.`username`, `lines`.`password`, `lines`.`exp_date`, `lines`.`admin_enabled`, `lines`.`is_restreamer`, `lines`.`enabled`, `lines`.`admin_notes`, `lines`.`reseller_notes`, `lines`.`max_connections`, `lines`.`is_trial`, (SELECT COUNT(*) AS `active_connections` FROM `lines_live` WHERE `user_id` = `lines`.`id` AND `hls_end` = 0) AS `active_connections` FROM `lines` LEFT JOIN `users` ON `users`.`id` = `lines`.`member_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$c189216dc4083b79 = $a4dd92d2bc66e08d = $Cde0ba71e2c62c4c = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$Cde0ba71e2c62c4c[] = intval($C740da31596f24ef['id']);
						$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])] = array('owner_name' => null, 'stream_display_name' => null, 'stream_id' => null, 'last_active' => null);

						if ($E5ae9288fdfb3b75 = json_decode($C740da31596f24ef['last_activity_array'], true)) {
							$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['stream_id'] = $E5ae9288fdfb3b75['stream_id'];
							$a4dd92d2bc66e08d[intval($C740da31596f24ef['id'])]['last_active'] = $E5ae9288fdfb3b75['date_end'];
						} else {
							if (!$C740da31596f24ef['last_activity']) {
							} else {
								$c189216dc4083b79[] = intval($C740da31596f24ef['last_activity']);
							}
						}
					}

					if (0 >= count($Cde0ba71e2c62c4c)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `users`.`username`, `lines`.`id` FROM `users` LEFT JOIN `lines` ON `lines`.`member_id` = `users`.`id` WHERE `lines`.`id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							$a4dd92d2bc66e08d[$C740da31596f24ef['id']]['owner_name'] = $C740da31596f24ef['username'];
						}

						if (XUI::$rSettings['redis_handler']) {
							$bde5957fb5fa9547 = array();
							$C7dc44e2b269673a = XUI::DE78b5E00A0718d6($Cde0ba71e2c62c4c, false);
							$Cdb85875fd50f459 = array();

							foreach ($C7dc44e2b269673a as $D78ff1d0edade5eb => $A90d77181715e38e) {
								foreach ($A90d77181715e38e as $e110a2ab6d3a4734) {
									if (in_array($e110a2ab6d3a4734['stream_id'], $Cdb85875fd50f459)) {
									} else {
										$Cdb85875fd50f459[] = intval($e110a2ab6d3a4734['stream_id']);
									}
								}
							}
							$F36bea2698ecb4fa = array();

							if (0 >= count($Cdb85875fd50f459)) {
							} else {
								$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

								foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
									$F36bea2698ecb4fa[$C740da31596f24ef['id']] = $C740da31596f24ef['stream_display_name'];
								}
							}

							foreach (array_keys($C7dc44e2b269673a) as $D78ff1d0edade5eb) {
								array_multisort(array_column($C7dc44e2b269673a[$D78ff1d0edade5eb], 'date_start'), SORT_DESC, $C7dc44e2b269673a[$D78ff1d0edade5eb]);
								$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_display_name'] = $F36bea2698ecb4fa[$C7dc44e2b269673a[$D78ff1d0edade5eb][0]['stream_id']];
								$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['stream_id'] = $C7dc44e2b269673a[$D78ff1d0edade5eb][0]['stream_id'];
								$a4dd92d2bc66e08d[$D78ff1d0edade5eb]['last_active'] = $C7dc44e2b269673a[$D78ff1d0edade5eb][0]['date_start'];
								$bde5957fb5fa9547[$D78ff1d0edade5eb] = count($C7dc44e2b269673a[$D78ff1d0edade5eb]);
							}
							unset($C7dc44e2b269673a);
						} else {
							$Fee0d5a474c96306->query('SELECT `lines_live`.`user_id`, `lines_live`.`stream_id`, `lines_live`.`date_start` AS `last_active`, `streams`.`stream_display_name` FROM `lines_live` LEFT JOIN `streams` ON `streams`.`id` = `lines_live`.`stream_id` INNER JOIN (SELECT `user_id`, MAX(`date_start`) AS `ts` FROM `lines_live` GROUP BY `user_id`) `maxt` ON (`lines_live`.`user_id` = `maxt`.`user_id` AND `lines_live`.`date_start` = `maxt`.`ts`) WHERE `lines_live`.`user_id` IN (' . implode(',', $Cde0ba71e2c62c4c) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_display_name'] = $C740da31596f24ef['stream_display_name'];
								$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
								$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
							}
						}
					}

					if (0 >= count($c189216dc4083b79)) {
					} else {
						$Fee0d5a474c96306->query('SELECT `user_id`, `stream_id`, `date_end` AS `last_active` FROM `lines_activity` WHERE `activity_id` IN (' . implode(',', $c189216dc4083b79) . ');');

						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (isset($a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'])) {
							} else {
								$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['stream_id'] = $C740da31596f24ef['stream_id'];
								$a4dd92d2bc66e08d[$C740da31596f24ef['user_id']]['last_active'] = $C740da31596f24ef['last_active'];
							}
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						$C740da31596f24ef = array_merge($C740da31596f24ef, $a4dd92d2bc66e08d[$C740da31596f24ef['id']]);

						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$C740da31596f24ef['active_connections'] = (isset($bde5957fb5fa9547[$C740da31596f24ef['id']]) ? $bde5957fb5fa9547[$C740da31596f24ef['id']] : 0);
						}

						if (!$B3f0f4a134021073) {
							if (!$C740da31596f24ef['admin_enabled']) {
								$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square tooltip" title="Banned"></i>';
							} else {
								if (!$C740da31596f24ef['enabled']) {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square tooltip" title="Disabled"></i>';
								} else {
									if ($C740da31596f24ef['exp_date'] && $C740da31596f24ef['exp_date'] < time()) {
										$Ba23222f3ed2dc08 = '<i class="text-warning far fa-square tooltip" title="Expired"></i>';
									} else {
										$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square tooltip" title="Active"></i>';
									}
								}
							}

							if (0 < $C740da31596f24ef['active_connections']) {
								$ccf88201f4394db1 = '<i class="text-success fas fa-square"></i>';
							} else {
								$ccf88201f4394db1 = '<i class="text-secondary far fa-square"></i>';
							}

							if ($C740da31596f24ef['is_trial']) {
								$Faa3eac96f7d5cc3 = '<i class="text-warning fas fa-square"></i>';
							} else {
								$Faa3eac96f7d5cc3 = '<i class="text-secondary far fa-square"></i>';
							}

							if ($C740da31596f24ef['exp_date']) {
								if ($C740da31596f24ef['exp_date'] < time()) {
									$e2b9f3089939b18c = '<span class="expired">' . date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . '<br/><small>' . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small></span>';
								} else {
									$e2b9f3089939b18c = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small>';
								}
							} else {
								$e2b9f3089939b18c = '&infin;';
							}

							if (0 < $C740da31596f24ef['active_connections']) {
								if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
									$D893e54c76761cd5 = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['active_connections'] . '</button></a>';
								} else {
									$D893e54c76761cd5 = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['active_connections'] . '</button>';
								}
							} else {
								$D893e54c76761cd5 = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
							}

							if ($C740da31596f24ef['max_connections'] == 0) {
								$B68ac2238b156add = "<button type='button' class='btn btn-dark text-white btn-xs waves-effect waves-light'>&infin;</button>";
							} else {
								$B68ac2238b156add = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>" . $C740da31596f24ef['max_connections'] . '</button>';
							}

							$ebab77ef4bee81e0 = '<div class="btn-group">';
							$Fe8647e101f37537 = '';

							if (0 >= strlen($C740da31596f24ef['reseller_notes'])) {
							} else {
								if (strlen($Fe8647e101f37537) == 0) {
								} else {
									$Fe8647e101f37537 .= "\n";
								}

								$Fe8647e101f37537 .= $C740da31596f24ef['reseller_notes'];
							}

							if (0 < strlen($Fe8647e101f37537)) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<a href="line?id=' . $C740da31596f24ef['id'] . '"><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>';

							if (!$B2ff75c438fb3031['allow_download']) {
							} else {
								$ebab77ef4bee81e0 .= "<button type=\"button\" title=\"Download Playlist\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"download('" . $C740da31596f24ef['username'] . "', '" . $C740da31596f24ef['password'] . "');\"><i class=\"mdi mdi-download\"></i></button>";
							}

							if (!$B2ff75c438fb3031['reseller_client_connection_logs']) {
							} else {
								if (0 < $C740da31596f24ef['active_connections']) {
									$ebab77ef4bee81e0 .= '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'kill_line');\"><i class=\"fas fa-hammer\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="fas fa-hammer"></i></button>';
								}
							}

							if (!$C740da31596f24ef['is_isplock']) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Reset ISP Lock" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'reset_isp');\"><i class=\"mdi mdi-lock-reset\"></i></button>";
							}

							if ($C740da31596f24ef['enabled']) {
								$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
							} else {
								$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
							$ebab77ef4bee81e0 .= '</div>';

							if ($C740da31596f24ef['active_connections'] && $C740da31596f24ef['last_active']) {
								$Fc75284164e5b696 = "<a href='stream_view?id=" . $C740da31596f24ef['stream_id'] . "'>" . $C740da31596f24ef['stream_display_name'] . "</a><br/><small class='text-secondary'>Online: " . XUI::F01C2e2CfC16141e(time() - $C740da31596f24ef['last_active']) . '</small>';
							} else {
								if ($C740da31596f24ef['last_active']) {
									$Fc75284164e5b696 = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['last_active']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['last_active']) . '</small>';
								} else {
									$Fc75284164e5b696 = 'Never';
								}
							}

							if (in_array($C740da31596f24ef['member_id'], array_merge($B2ff75c438fb3031['direct_reports'], array($D4253f9520627819['id'])))) {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['member_id']) . "'>" . $C740da31596f24ef['owner_name'] . '</a>';
							} else {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['member_id']) . "'>" . $C740da31596f24ef['owner_name'] . "<br/><small class='text-pink'>(indirect)</small></a>";
							}

							$a85e1b7d42c346a0['data'][] = array("<a href='line?id=" . $C740da31596f24ef['id'] . "'>" . $C740da31596f24ef['id'] . '</a>', "<a href='line?id=" . $C740da31596f24ef['id'] . "'>" . $C740da31596f24ef['username'] . '</a>', $C740da31596f24ef['password'], $Dbb9e190755fc819, $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $D893e54c76761cd5, $B68ac2238b156add, $e2b9f3089939b18c, $Fc75284164e5b696, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'mags') {
		if ($B2ff75c438fb3031['create_mag']) {
			$c6c389b9adf3a40c = array('`lines`.`id`', '`lines`.`username`', '`mag_devices`.`mac`', '`mag_devices`.`stb_type`', '`users`.`username`', '`lines`.`enabled`', '`active_connections`', '`lines`.`is_trial`', '`lines`.`exp_date`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 6) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`lines`.`username` LIKE ? OR `mag_devices`.`mac` LIKE ? OR `mag_devices`.`stb_type` LIKE ? OR `users`.`username` LIKE ? OR FROM_UNIXTIME(`exp_date`) LIKE ? OR `lines`.`reseller_notes` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`lines`.`admin_enabled` = 1 AND `lines`.`enabled` = 1 AND (`lines`.`exp_date` IS NULL OR `lines`.`exp_date` > UNIX_TIMESTAMP()))';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '`lines`.`enabled` = 0';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` <= UNIX_TIMESTAMP())';
						} else {
							if (XUI::$rRequest['filter'] != 4) {
							} else {
								$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
							}
						}
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(`lines`.`id`) AS `count` FROM `lines` LEFT JOIN `users` ON `users`.`id` = `lines`.`member_id` INNER JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `lines`.`id`, `lines`.`username`, `lines`.`member_id`, `lines`.`is_isplock`, `mag_devices`.`mac`, `mag_devices`.`stb_type`, `mag_devices`.`mag_id`, `lines`.`exp_date`, `lines`.`admin_enabled`, `lines`.`enabled`, `lines`.`reseller_notes`, `lines`.`max_connections`,  `lines`.`is_trial`, `users`.`username` AS `owner_name`, (SELECT count(*) FROM `lines_live` WHERE `lines`.`id` = `lines_live`.`user_id` AND `hls_end` = 0) AS `active_connections` FROM `lines` LEFT JOIN `users` ON `users`.`id` = `lines`.`member_id` INNER JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$Cde0ba71e2c62c4c = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!$C740da31596f24ef['id']) {
						} else {
							$Cde0ba71e2c62c4c[] = intval($C740da31596f24ef['id']);
						}
					}

					if (0 >= count($Cde0ba71e2c62c4c)) {
					} else {
						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$bde5957fb5fa9547 = array();
							$C7dc44e2b269673a = XUI::DE78b5E00a0718d6($Cde0ba71e2c62c4c, false);

							foreach (array_keys($C7dc44e2b269673a) as $D78ff1d0edade5eb) {
								$bde5957fb5fa9547[$D78ff1d0edade5eb] = count($C7dc44e2b269673a[$D78ff1d0edade5eb]);
							}
							unset($C7dc44e2b269673a);
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$C740da31596f24ef['active_connections'] = (isset($bde5957fb5fa9547[$C740da31596f24ef['id']]) ? $bde5957fb5fa9547[$C740da31596f24ef['id']] : 0);
						}

						if (!$B3f0f4a134021073) {
							if (!$C740da31596f24ef['admin_enabled']) {
								$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square"></i>';
							} else {
								if (!$C740da31596f24ef['enabled']) {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square"></i>';
								} else {
									if ($C740da31596f24ef['exp_date'] && $C740da31596f24ef['exp_date'] < time()) {
										$Ba23222f3ed2dc08 = '<i class="text-warning far fa-square"></i>';
									} else {
										$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square"></i>';
									}
								}
							}

							if (0 < $C740da31596f24ef['active_connections']) {
								$ccf88201f4394db1 = '<i class="text-success fas fa-square"></i>';
							} else {
								$ccf88201f4394db1 = '<i class="text-warning far fa-square"></i>';
							}

							if ($C740da31596f24ef['is_trial']) {
								$Faa3eac96f7d5cc3 = '<i class="text-warning fas fa-square"></i>';
							} else {
								$Faa3eac96f7d5cc3 = '<i class="text-secondary far fa-square"></i>';
							}

							if ($C740da31596f24ef['exp_date']) {
								if ($C740da31596f24ef['exp_date'] < time()) {
									$e2b9f3089939b18c = '<span class="expired">' . date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . '<br/><small>' . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small></span>';
								} else {
									$e2b9f3089939b18c = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small>';
								}
							} else {
								$e2b9f3089939b18c = '&infin;';
							}

							$ebab77ef4bee81e0 = '<div class="btn-group">';
							$Fe8647e101f37537 = '';

							if (0 >= strlen($C740da31596f24ef['reseller_notes'])) {
							} else {
								if (strlen($Fe8647e101f37537) == 0) {
								} else {
									$Fe8647e101f37537 .= "\n";
								}

								$Fe8647e101f37537 .= $C740da31596f24ef['reseller_notes'];
							}

							if (0 < strlen($Fe8647e101f37537)) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<button title="MAG Event" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="message(' . $C740da31596f24ef['mag_id'] . ", '" . $C740da31596f24ef['mac'] . "');\"><i class=\"mdi mdi-message-alert\"></i></button>";
							$ebab77ef4bee81e0 .= '<a href="mag?id=' . $C740da31596f24ef['mag_id'] . '"><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>';

							if (!$C740da31596f24ef['is_isplock']) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Reset ISP Lock" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'reset_isp');\"><i class=\"mdi mdi-lock-reset\"></i></button>";
							}

							if (!$B2ff75c438fb3031['create_line']) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Convert to User Line" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'convert');\"><i class=\"fas fa-retweet\"></i></button>";
							}

							if (!$B2ff75c438fb3031['reseller_client_connection_logs']) {
							} else {
								if (0 < $C740da31596f24ef['active_connections']) {
									$ebab77ef4bee81e0 .= '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'kill_line');\"><i class=\"fas fa-hammer\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="fas fa-hammer"></i></button>';
								}
							}

							if ($C740da31596f24ef['enabled'] == 1) {
								$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
							} else {
								$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['mag_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
							$ebab77ef4bee81e0 .= '</div>';

							if (in_array($C740da31596f24ef['member_id'], array_merge($B2ff75c438fb3031['direct_reports'], array($D4253f9520627819['id'])))) {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['member_id']) . "'>" . $C740da31596f24ef['owner_name'] . '</a>';
							} else {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['member_id']) . "'>" . $C740da31596f24ef['owner_name'] . "<br/><small class='text-pink'>(indirect)</small></a>";
							}

							$a85e1b7d42c346a0['data'][] = array("<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['mag_id'] . '</a>', $C740da31596f24ef['username'], "<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['mac'] . '</a>', $C740da31596f24ef['stb_type'], $Dbb9e190755fc819, $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $e2b9f3089939b18c, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'enigmas') {
		if ($B2ff75c438fb3031['create_enigma']) {
			$c6c389b9adf3a40c = array('`lines`.`id`', '`lines`.`username`', '`enigma2_devices`.`mac`', '`enigma2_devices`.`public_ip`', '`users`.`username`', '`lines`.`enabled`', '`active_connections`', '`lines`.`is_trial`', '`lines`.`exp_date`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 6) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`lines`.`username` LIKE ? OR `enigma2_devices`.`mac` LIKE ? OR `enigma2_devices`.`public_ip` LIKE ? OR `users`.`username` LIKE ? OR FROM_UNIXTIME(`exp_date`) LIKE ? OR `lines`.`reseller_notes` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['filter'])) {
			} else {
				if (XUI::$rRequest['filter'] == 1) {
					$f86e19bdb1e7dae8[] = '(`lines`.`admin_enabled` = 1 AND `lines`.`enabled` = 1 AND (`lines`.`exp_date` IS NULL OR `lines`.`exp_date` > UNIX_TIMESTAMP()))';
				} else {
					if (XUI::$rRequest['filter'] == 2) {
						$f86e19bdb1e7dae8[] = '`lines`.`enabled` = 0';
					} else {
						if (XUI::$rRequest['filter'] == 3) {
							$f86e19bdb1e7dae8[] = '(`lines`.`exp_date` IS NOT NULL AND `lines`.`exp_date` <= UNIX_TIMESTAMP())';
						} else {
							if (XUI::$rRequest['filter'] != 4) {
							} else {
								$f86e19bdb1e7dae8[] = '`lines`.`is_trial` = 1';
							}
						}
					}
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(`lines`.`id`) AS `count` FROM `lines` LEFT JOIN `users` ON `users`.`id` = `lines`.`member_id` INNER JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `lines`.`id`, `lines`.`username`, `lines`.`member_id`, `lines`.`is_isplock`, `enigma2_devices`.`mac`, `enigma2_devices`.`public_ip`, `enigma2_devices`.`device_id`, `lines`.`exp_date`, `lines`.`admin_enabled`, `lines`.`enabled`, `lines`.`reseller_notes`, `lines`.`max_connections`,  `lines`.`is_trial`, `users`.`username` AS `owner_name`, (SELECT count(*) FROM `lines_live` WHERE `lines`.`id` = `lines_live`.`user_id` AND `hls_end` = 0) AS `active_connections` FROM `lines` LEFT JOIN `users` ON `users`.`id` = `lines`.`member_id` INNER JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					$Cde0ba71e2c62c4c = array();

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!$C740da31596f24ef['id']) {
						} else {
							$Cde0ba71e2c62c4c[] = intval($C740da31596f24ef['id']);
						}
					}

					if (0 >= count($Cde0ba71e2c62c4c)) {
					} else {
						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$bde5957fb5fa9547 = array();
							$C7dc44e2b269673a = XUI::DE78b5e00a0718D6($Cde0ba71e2c62c4c, false);

							foreach (array_keys($C7dc44e2b269673a) as $D78ff1d0edade5eb) {
								$bde5957fb5fa9547[$D78ff1d0edade5eb] = count($C7dc44e2b269673a[$D78ff1d0edade5eb]);
							}
							unset($C7dc44e2b269673a);
						}
					}

					foreach ($b3439582205053ea as $C740da31596f24ef) {
						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$C740da31596f24ef['active_connections'] = (isset($bde5957fb5fa9547[$C740da31596f24ef['id']]) ? $bde5957fb5fa9547[$C740da31596f24ef['id']] : 0);
						}

						if (!$B3f0f4a134021073) {
							if (!$C740da31596f24ef['admin_enabled']) {
								$Ba23222f3ed2dc08 = '<i class="text-danger fas fa-square"></i>';
							} else {
								if (!$C740da31596f24ef['enabled']) {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square"></i>';
								} else {
									if ($C740da31596f24ef['exp_date'] && $C740da31596f24ef['exp_date'] < time()) {
										$Ba23222f3ed2dc08 = '<i class="text-warning far fa-square"></i>';
									} else {
										$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square"></i>';
									}
								}
							}

							if (0 < $C740da31596f24ef['active_connections']) {
								$ccf88201f4394db1 = '<i class="text-success fas fa-square"></i>';
							} else {
								$ccf88201f4394db1 = '<i class="text-warning far fa-square"></i>';
							}

							if ($C740da31596f24ef['is_trial']) {
								$Faa3eac96f7d5cc3 = '<i class="text-warning fas fa-square"></i>';
							} else {
								$Faa3eac96f7d5cc3 = '<i class="text-secondary far fa-square"></i>';
							}

							if ($C740da31596f24ef['exp_date']) {
								if ($C740da31596f24ef['exp_date'] < time()) {
									$e2b9f3089939b18c = '<span class="expired">' . date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . '<br/><small>' . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small></span>';
								} else {
									$e2b9f3089939b18c = date($F2d4d8f7981ac574['date_format'], $C740da31596f24ef['exp_date']) . "<br/><small class='text-secondary'>" . date('H:i:s', $C740da31596f24ef['exp_date']) . '</small>';
								}
							} else {
								$e2b9f3089939b18c = '&infin;';
							}

							$ebab77ef4bee81e0 = '<div class="btn-group">';
							$Fe8647e101f37537 = '';

							if (0 >= strlen($C740da31596f24ef['reseller_notes'])) {
							} else {
								if (strlen($Fe8647e101f37537) == 0) {
								} else {
									$Fe8647e101f37537 .= "\n";
								}

								$Fe8647e101f37537 .= $C740da31596f24ef['reseller_notes'];
							}

							if (0 < strlen($Fe8647e101f37537)) {
								$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $Fe8647e101f37537 . '"><i class="mdi mdi-note"></i></button>';
							} else {
								$ebab77ef4bee81e0 .= '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
							}

							$ebab77ef4bee81e0 .= '<a href="enigma?id=' . $C740da31596f24ef['device_id'] . '"><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>';

							if (!$C740da31596f24ef['is_isplock']) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Reset ISP Lock" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'reset_isp');\"><i class=\"mdi mdi-lock-reset\"></i></button>";
							}

							if (!$B2ff75c438fb3031['create_line']) {
							} else {
								$ebab77ef4bee81e0 .= '<button title="Convert to User Line" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'convert');\"><i class=\"fas fa-retweet\"></i></button>";
							}

							if (!$B2ff75c438fb3031['reseller_client_connection_logs']) {
							} else {
								if (0 < $C740da31596f24ef['active_connections']) {
									$ebab77ef4bee81e0 .= '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'kill_line');\"><i class=\"fas fa-hammer\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="fas fa-hammer"></i></button>';
								}
							}

							if ($C740da31596f24ef['enabled'] == 1) {
								$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
							} else {
								$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
							}

							$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['device_id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
							$ebab77ef4bee81e0 .= '</div>';

							if (in_array($C740da31596f24ef['member_id'], array_merge($B2ff75c438fb3031['direct_reports'], array($D4253f9520627819['id'])))) {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['member_id']) . "'>" . $C740da31596f24ef['owner_name'] . '</a>';
							} else {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['member_id']) . "'>" . $C740da31596f24ef['owner_name'] . "<br/><small class='text-pink'>(indirect)</small></a>";
							}

							$a85e1b7d42c346a0['data'][] = array("<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['device_id'] . '</a>', $C740da31596f24ef['username'], "<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['mac'] . '</a>', "<a onClick=\"whois('" . $C740da31596f24ef['public_ip'] . "');\" href='javascript: void(0);'>" . $C740da31596f24ef['public_ip'] . '</a>', $Dbb9e190755fc819, $Ba23222f3ed2dc08, $ccf88201f4394db1, $Faa3eac96f7d5cc3, $e2b9f3089939b18c, $ebab77ef4bee81e0);
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'streams') {
		if ($B2ff75c438fb3031['can_view_vod']) {
			$A5dcdeb6ecbbf6bd = CbE87e2A9a996111('live');
			$c6c389b9adf3a40c = array('`id`', false, '`stream_display_name`', '`category_id`', '`clients`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$Eabdab369bae73a8 = isset(XUI::$rRequest['created']);
			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 < count($B2ff75c438fb3031['stream_ids'])) {
				$f86e19bdb1e7dae8[] = '`streams`.`id` IN (' . implode(',', array_map('intval', $B2ff75c438fb3031['stream_ids'])) . ')';

				if ($Eabdab369bae73a8) {
					$f86e19bdb1e7dae8[] = '`type` = 3';
				} else {
					$f86e19bdb1e7dae8[] = '`type` = 1';
				}

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`id` LIKE ? OR `stream_display_name` LIKE ?)';
				}

				if (0 >= strlen(XUI::$rRequest['category'])) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category'];
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(`streams`.`id`) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `id`, `stream_icon`, `stream_display_name`, `tv_archive_duration`, `tv_archive_server_id`, `category_id`, (SELECT COUNT(*) FROM `lines_live` LEFT JOIN `lines` ON `lines`.`id` = `lines_live`.`user_id` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0 AND `lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')) AS `clients` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();

						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$bde5957fb5fa9547 = $F3a421506b1b5b24 = array();
							$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F3a421506b1b5b24[] = $C740da31596f24ef['id'];
							}

							if (0 >= count($F3a421506b1b5b24)) {
							} else {
								foreach (XUI::dE78b5e00a0718d6($F3a421506b1b5b24, false) as $D78ff1d0edade5eb => $A90d77181715e38e) {
									foreach ($A90d77181715e38e as $e110a2ab6d3a4734) {
										$bde5957fb5fa9547[$e110a2ab6d3a4734['stream_id']]++;
									}
								}
							}
						}

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							if (!XUI::$rSettings['redis_handler']) {
							} else {
								$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
							}

							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								if (!(0 < $C740da31596f24ef['tv_archive_duration'] && 0 < $C740da31596f24ef['tv_archive_server_id'])) {
								} else {
									$C740da31596f24ef['stream_display_name'] .= " <i class='text-danger mdi mdi-record'></i>";
								}

								if (0 < $C740da31596f24ef['clients']) {
									if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
										$ebab77ef4bee81e0 = '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'purge');\"><i class=\"mdi mdi-hammer\"></i></button>";
										$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button></a>';
									} else {
										$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
										$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button>';
									}
								} else {
									$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
								}

								if (0 < strlen($C740da31596f24ef['stream_icon'])) {
									$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['stream_icon'] . "'><img loading='lazy' src='resize?maxw=96&maxh=32&url=" . $C740da31596f24ef['stream_icon'] . "' /></a>";
								} else {
									$E9c8d08bfb6ef33c = '';
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $E9c8d08bfb6ef33c, $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ec5b28bb1cbf9f2d, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'radios') {
		if ($B2ff75c438fb3031['can_view_vod']) {
			$A5dcdeb6ecbbf6bd = CBe87E2A9a996111('radio');
			$c6c389b9adf3a40c = array('`id`', false, '`stream_display_name`', '`category_id`', '`clients`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$Eabdab369bae73a8 = isset(XUI::$rRequest['created']);
			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 < count($B2ff75c438fb3031['stream_ids'])) {
				$f86e19bdb1e7dae8[] = '`streams`.`id` IN (' . implode(',', array_map('intval', $B2ff75c438fb3031['stream_ids'])) . ')';
				$f86e19bdb1e7dae8[] = '`type` = 4';

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`id` LIKE ? OR `stream_display_name` LIKE ?)';
				}

				if (0 >= strlen(XUI::$rRequest['category'])) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category'];
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(`streams`.`id`) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `id`, `stream_icon`, `stream_display_name`, `category_id`, (SELECT COUNT(*) FROM `lines_live` LEFT JOIN `lines` ON `lines`.`id` = `lines_live`.`user_id` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0 AND `lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')) AS `clients` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();

						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$bde5957fb5fa9547 = $F3a421506b1b5b24 = array();
							$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F3a421506b1b5b24[] = $C740da31596f24ef['id'];
							}

							if (0 >= count($F3a421506b1b5b24)) {
							} else {
								foreach (XUI::De78B5e00a0718D6($F3a421506b1b5b24, false) as $D78ff1d0edade5eb => $A90d77181715e38e) {
									foreach ($A90d77181715e38e as $e110a2ab6d3a4734) {
										$bde5957fb5fa9547[$e110a2ab6d3a4734['stream_id']]++;
									}
								}
							}
						}

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							if (!XUI::$rSettings['redis_handler']) {
							} else {
								$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
							}

							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								if (0 < $C740da31596f24ef['clients']) {
									if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
										$ebab77ef4bee81e0 = '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'purge');\"><i class=\"mdi mdi-hammer\"></i></button>";
										$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button></a>';
									} else {
										$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
										$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button>';
									}
								} else {
									$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
								}

								if (0 < strlen($C740da31596f24ef['stream_icon'])) {
									$E9c8d08bfb6ef33c = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $C740da31596f24ef['stream_icon'] . "'><img loading='lazy' src='resize?maxw=96&maxh=32&url=" . $C740da31596f24ef['stream_icon'] . "' /></a>";
								} else {
									$E9c8d08bfb6ef33c = '';
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $E9c8d08bfb6ef33c, $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ec5b28bb1cbf9f2d, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'movies') {
		if ($B2ff75c438fb3031['can_view_vod']) {
			$A5dcdeb6ecbbf6bd = cBE87E2a9a996111('movie');
			$c6c389b9adf3a40c = array('`id`', false, '`stream_display_name`', '`category_id`', '`clients`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$Eabdab369bae73a8 = isset(XUI::$rRequest['created']);
			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 < count($B2ff75c438fb3031['stream_ids'])) {
				$f86e19bdb1e7dae8[] = '`streams`.`id` IN (' . implode(',', array_map('intval', $B2ff75c438fb3031['stream_ids'])) . ')';
				$f86e19bdb1e7dae8[] = '`type` = 2';

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 2) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`id` LIKE ? OR `stream_display_name` LIKE ?)';
				}

				if (0 >= strlen(XUI::$rRequest['category'])) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category'];
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(`streams`.`id`) AS `count` FROM `streams` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `id`, `stream_icon`, `stream_display_name`, `movie_properties`, `category_id`, (SELECT COUNT(*) FROM `lines_live` LEFT JOIN `lines` ON `lines`.`id` = `lines_live`.`user_id` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0 AND `lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')) AS `clients` FROM `streams` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();

						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$bde5957fb5fa9547 = $F3a421506b1b5b24 = array();
							$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F3a421506b1b5b24[] = $C740da31596f24ef['id'];
							}

							if (0 >= count($F3a421506b1b5b24)) {
							} else {
								foreach (XUI::DE78B5E00A0718D6($F3a421506b1b5b24, false) as $D78ff1d0edade5eb => $A90d77181715e38e) {
									foreach ($A90d77181715e38e as $e110a2ab6d3a4734) {
										$bde5957fb5fa9547[$e110a2ab6d3a4734['stream_id']]++;
									}
								}
							}
						}

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							if (!XUI::$rSettings['redis_handler']) {
							} else {
								$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
							}

							if (!$B3f0f4a134021073) {
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								if (0 < $C740da31596f24ef['clients']) {
									if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
										$ebab77ef4bee81e0 = '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'purge');\"><i class=\"mdi mdi-hammer\"></i></button>";
										$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button></a>';
									} else {
										$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
										$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button>';
									}
								} else {
									$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
								}

								$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);

								if (0 < strlen($D92b16dc36690ab9['movie_image'])) {
									$A639a7baefc720ee = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $D92b16dc36690ab9['movie_image'] . "'><img loading='lazy' src='resize?maxh=58&maxw=32&url=" . $D92b16dc36690ab9['movie_image'] . "' /></a>";
								} else {
									$A639a7baefc720ee = '';
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $A639a7baefc720ee, $C740da31596f24ef['stream_display_name'], $A1925ae53e9307eb, $ec5b28bb1cbf9f2d, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'episodes') {
		if ($B2ff75c438fb3031['can_view_vod']) {
			$A5dcdeb6ecbbf6bd = Cbe87E2a9a996111('series');
			$c6c389b9adf3a40c = array('`id`', false, '`stream_display_name`', '`category_id`', '`clients`', false);

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$Eabdab369bae73a8 = isset(XUI::$rRequest['created']);
			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();

			if (0 < count($B2ff75c438fb3031['stream_ids'])) {
				$f86e19bdb1e7dae8[] = '`streams`.`id` IN (' . implode(',', array_map('intval', $B2ff75c438fb3031['stream_ids'])) . ')';
				$f86e19bdb1e7dae8[] = '`type` = 5';

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 3) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`streams`.`id` LIKE ? OR `stream_display_name` LIKE ? OR `streams_series`.`title` LIKE ?)';
				}

				if (0 >= strlen(XUI::$rRequest['category'])) {
				} else {
					$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`streams_series`.`category_id`, ?, '\$')";
					$Df2582e36fdd6160[] = XUI::$rRequest['category'];
				}

				if (0 >= strlen(XUI::$rRequest['series'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`streams_series`.`id` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['series'];
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(`streams`.`id`) AS `count` FROM `streams` LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `streams`.`id`, `stream_icon`, `stream_display_name`, `movie_properties`, `streams_series`.`category_id`, `streams_series`.`title`, `streams_episodes`.`season_num`, (SELECT COUNT(*) FROM `lines_live` LEFT JOIN `lines` ON `lines`.`id` = `lines_live`.`user_id` WHERE `lines_live`.`stream_id` = `streams`.`id` AND `hls_end` = 0 AND `lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')) AS `clients` FROM `streams` LEFT JOIN `streams_episodes` ON `streams_episodes`.`stream_id` = `streams`.`id` LEFT JOIN `streams_series` ON `streams_series`.`id` = `streams_episodes`.`series_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();

						if (!XUI::$rSettings['redis_handler']) {
						} else {
							$bde5957fb5fa9547 = $F3a421506b1b5b24 = array();
							$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ');');

							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$F3a421506b1b5b24[] = $C740da31596f24ef['id'];
							}

							if (0 >= count($F3a421506b1b5b24)) {
							} else {
								foreach (XUI::dE78B5E00a0718D6($F3a421506b1b5b24, false) as $D78ff1d0edade5eb => $A90d77181715e38e) {
									foreach ($A90d77181715e38e as $e110a2ab6d3a4734) {
										$bde5957fb5fa9547[$e110a2ab6d3a4734['stream_id']]++;
									}
								}
							}
						}

						foreach ($b3439582205053ea as $C740da31596f24ef) {
							if (!XUI::$rSettings['redis_handler']) {
							} else {
								$C740da31596f24ef['clients'] = ($bde5957fb5fa9547[$C740da31596f24ef['id']] ?: 0);
							}

							if (!$B3f0f4a134021073) {
								$dc850cbc5eb6f918 = $C740da31596f24ef['title'] . ' - Season ' . $C740da31596f24ef['season_num'];
								$Ef28eaee0050d7a5 = '<b>' . $C740da31596f24ef['stream_display_name'] . "</b><br><span style='font-size:11px;'>" . $dc850cbc5eb6f918 . '</span>';
								$A38b42a281e3c3cf = json_decode($C740da31596f24ef['category_id'], true);

								if (0 < strlen(XUI::$rRequest['category'])) {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[intval(XUI::$rRequest['category'])]['category_name'] ?: 'No Category');
								} else {
									$A1925ae53e9307eb = ($A5dcdeb6ecbbf6bd[$A38b42a281e3c3cf[0]]['category_name'] ?: 'No Category');
								}

								if (1 >= count($A38b42a281e3c3cf)) {
								} else {
									$A1925ae53e9307eb .= ' (+' . (count($A38b42a281e3c3cf) - 1) . ' others)';
								}

								if (0 < $C740da31596f24ef['clients']) {
									if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
										$ebab77ef4bee81e0 = '<button title="Kill Connections" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'purge');\"><i class=\"mdi mdi-hammer\"></i></button>";
										$ec5b28bb1cbf9f2d = "<a href='javascript: void(0);' onClick='viewLiveConnections(" . intval($C740da31596f24ef['id']) . ");'><button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button></a>';
									} else {
										$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
										$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>" . $C740da31596f24ef['clients'] . '</button>';
									}
								} else {
									$ebab77ef4bee81e0 = '<button type="button" disabled class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-hammer"></i></button>';
									$ec5b28bb1cbf9f2d = "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light'>0</button>";
								}

								$D92b16dc36690ab9 = json_decode($C740da31596f24ef['movie_properties'], true);

								if (0 < strlen($D92b16dc36690ab9['movie_image'])) {
									$A639a7baefc720ee = "<a href='javascript: void(0);' onClick='openImage(this);' data-src='resize?maxw=512&maxh=512&url=" . $D92b16dc36690ab9['movie_image'] . "'><img loading='lazy' src='resize?maxh=58&maxw=32&url=" . $D92b16dc36690ab9['movie_image'] . "' /></a>";
								} else {
									$A639a7baefc720ee = '';
								}

								$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $A639a7baefc720ee, $Ef28eaee0050d7a5, $A1925ae53e9307eb, $ec5b28bb1cbf9f2d, $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'line_activity') {
		if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
			$c6c389b9adf3a40c = array('`username`', '`streams`.`stream_display_name`', '`lines_activity`.`user_agent`', '`lines_activity`.`isp`', '`lines_activity`.`user_ip`', '`lines_activity`.`date_start`', '`lines_activity`.`date_end`', '`lines_activity`.`date_end` - `lines_activity`.`date_start`', '`lines_activity`.`container`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 10) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`lines_activity`.`user_agent` LIKE ? OR `lines_activity`.`user_ip` LIKE ? OR `lines_activity`.`container` LIKE ? OR FROM_UNIXTIME(`lines_activity`.`date_start`) LIKE ? OR FROM_UNIXTIME(`lines_activity`.`date_end`) LIKE ? OR `lines_activity`.`geoip_country_code` LIKE ? OR `lines`.`username` LIKE ? OR `mag_devices`.`mac` LIKE ? OR `enigma2_devices`.`mac` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['range'])) {
			} else {
				$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
				$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

				if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
				} else {
					$a859a0996bb0f1ff = null;
				}

				if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
				} else {
					$B37c1f185be84c33 = null;
				}

				if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
				} else {
					$f86e19bdb1e7dae8[] = '(`lines_activity`.`date_start` >= ? AND `lines_activity`.`date_end` <= ?)';
					$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
					$Df2582e36fdd6160[] = $B37c1f185be84c33;
				}
			}

			if (0 >= strlen(XUI::$rRequest['stream'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines_activity`.`stream_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['stream'];
			}

			if (0 >= strlen(XUI::$rRequest['user'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['user'];
			}

			if (0 >= strlen(XUI::$rRequest['line'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`lines_activity`.`user_id` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['line'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines_activity` LEFT JOIN `lines` ON `lines_activity`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_activity`.`stream_id` = `streams`.`id` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines_activity`.`user_id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines_activity`.`user_id` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$A6d7047f2fda966c = 'SELECT `mag_devices`.`mag_id`, `enigma2_devices`.`device_id`, `lines`.`is_e2`, `lines`.`is_mag`, `lines_activity`.`activity_id`, `lines_activity`.`container`, `lines_activity`.`isp`, `lines_activity`.`user_id`, `lines_activity`.`stream_id`, `streams`.`series_no`, `lines_activity`.`server_id`, `lines_activity`.`user_agent`, `lines_activity`.`user_ip`, `lines_activity`.`container`, `lines_activity`.`date_start`, `lines_activity`.`date_end`, `lines_activity`.`geoip_country_code`, IF(`lines`.`is_mag`, `mag_devices`.`mac`, IF(`lines`.`is_e2`, `enigma2_devices`.`mac`, `lines`.`username`)) AS `username`, `streams`.`stream_display_name`, `streams`.`type`, `lines`.`is_restreamer` FROM `lines_activity` LEFT JOIN `lines` ON `lines_activity`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_activity`.`stream_id` = `streams`.`id` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines_activity`.`user_id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines_activity`.`user_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							if ($C740da31596f24ef['is_mag']) {
								$a71afc14d6cd090d = "<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
							} else {
								if ($C740da31596f24ef['is_e2']) {
									$a71afc14d6cd090d = "<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
								} else {
									$a71afc14d6cd090d = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
								}
							}

							$Fe753328765ad26c = $C740da31596f24ef['stream_display_name'];

							if (0 < strlen($C740da31596f24ef['geoip_country_code'])) {
								$D0281cc88d5d14fd = "<img loading='lazy' src='assets/images/countries/" . strtolower($C740da31596f24ef['geoip_country_code']) . ".png'></img> &nbsp;";
							} else {
								$D0281cc88d5d14fd = '';
							}

							if ($C740da31596f24ef['user_ip']) {
								$c59ec257c284c894 = $D0281cc88d5d14fd . "<a onClick=\"whois('" . $C740da31596f24ef['user_ip'] . "');\" href='javascript: void(0);'>" . $C740da31596f24ef['user_ip'] . '</a>';
							} else {
								$c59ec257c284c894 = '';
							}

							if ($C740da31596f24ef['date_start']) {
								$D031c48a1422c07e = date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date_start']);
							} else {
								$D031c48a1422c07e = '';
							}

							if ($C740da31596f24ef['date_end']) {
								$D00cf8fa3b1195d0 = date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date_end']);
							} else {
								$D00cf8fa3b1195d0 = '';
							}

							$cafddc0a05fb9f1f = trim(explode('(', $C740da31596f24ef['user_agent'])[0]);
							$C5034884ed44603a = $C740da31596f24ef['date_end'] - $C740da31596f24ef['date_start'];
							$Ac54397e06e8e862 = 'success';

							if (86400 <= $C5034884ed44603a) {
								$C5034884ed44603a = sprintf('%02dd %02dh', $C5034884ed44603a / 86400, ($C5034884ed44603a / 3600) % 24);
								$Ac54397e06e8e862 = 'danger';
							} else {
								if (3600 <= $C5034884ed44603a) {
									if (14400 < $C5034884ed44603a) {
										$Ac54397e06e8e862 = 'warning';
									} else {
										if (43200 >= $C5034884ed44603a) {
										} else {
											$Ac54397e06e8e862 = 'danger';
										}
									}

									$C5034884ed44603a = sprintf('%02dh %02dm', $C5034884ed44603a / 3600, ($C5034884ed44603a / 60) % 60);
								} else {
									$C5034884ed44603a = sprintf('%02dm %02ds', ($C5034884ed44603a / 60) % 60, $C5034884ed44603a % 60);
								}
							}

							$C5034884ed44603a = "<button type='button' class='btn btn-" . $Ac54397e06e8e862 . " btn-xs waves-effect waves-light btn-fixed'>" . $C5034884ed44603a . '</button>';
							$a85e1b7d42c346a0['data'][] = array($a71afc14d6cd090d, $Fe753328765ad26c, $cafddc0a05fb9f1f, $C740da31596f24ef['isp'], $c59ec257c284c894, $D031c48a1422c07e, $D00cf8fa3b1195d0, $C5034884ed44603a, strtoupper($C740da31596f24ef['container']));
						} else {
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		exit();
	}

	if ($E379394c7b1a273f == 'live_connections') {
		if ($B2ff75c438fb3031['reseller_client_connection_logs']) {
			$b3439582205053ea = array();

			if (XUI::$rSettings['redis_handler']) {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? false : true);
				$F3a421506b1b5b24 = array();
				$D78ff1d0edade5eb = (0 < intval(XUI::$rRequest['user']) ? intval(XUI::$rRequest['user']) : null);
				$F26087d31c2bbe4d = (0 < intval(XUI::$rRequest['stream_id']) ? intval(XUI::$rRequest['stream_id']) : null);

				if ($D78ff1d0edade5eb && in_array($D78ff1d0edade5eb, $D4253f9520627819['reports'])) {
					$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` = ?;', $D78ff1d0edade5eb);
				} else {
					$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ');');
				}

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$F3a421506b1b5b24[] = $C740da31596f24ef['id'];
				}
				$f16991461acd03bf = XUI::De78B5e00a0718d6($F3a421506b1b5b24, false, true);

				if (!$cb10faf5ade31619) {
				} else {
					$f16991461acd03bf = array_reverse($f16991461acd03bf);
				}

				$Ec475faf4d560253 = count($f16991461acd03bf);

				foreach (XUI::$redis->mGet($f16991461acd03bf) as $C740da31596f24ef) {
					$C740da31596f24ef = igbinary_unserialize($C740da31596f24ef);

					if (is_array($C740da31596f24ef)) {
						if ($f10b443055599d8b) {
						} else {
							if (!($F26087d31c2bbe4d && $F26087d31c2bbe4d != $C740da31596f24ef['stream_id'])) {
								if (in_array($C740da31596f24ef['user_id'], $F3a421506b1b5b24)) {
								} else {
									$Ec475faf4d560253--;
								}
							} else {
								$Ec475faf4d560253--;
							}
						}

						$C740da31596f24ef['activity_id'] = $C740da31596f24ef['uuid'];
						$C740da31596f24ef['identifier'] = ($C740da31596f24ef['user_id'] ?: $C740da31596f24ef['hmac_id'] . '_' . $C740da31596f24ef['hmac_identifier']);
						$C740da31596f24ef['active_time'] = time() - $C740da31596f24ef['date_start'];
						$C740da31596f24ef['server_name'] = (XUI::$rServers[$C740da31596f24ef['server_id']]['server_name'] ?: '');
						$b3439582205053ea[] = $C740da31596f24ef;
					} else {
						$Ec475faf4d560253--;
					}
				}
				$c6c389b9adf3a40c = array('uuid', 'divergence', 'identifier', 'stream_display_name', 'user_agent', 'isp', 'user_ip', 'active_time', 'container', null);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					array_multisort(array_column($b3439582205053ea, $c6c389b9adf3a40c[$C1633246b8426116]), ($cb10faf5ade31619 ? SORT_ASC : SORT_DESC), $b3439582205053ea);
				}

				$b3439582205053ea = array_slice($b3439582205053ea, $D031c48a1422c07e, $E400a3101514583e);
				$F805649379c06d30 = $Cdb85875fd50f459 = $b174976b99c4ec48 = array();

				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!$C740da31596f24ef['stream_id']) {
					} else {
						$Cdb85875fd50f459[] = intval($C740da31596f24ef['stream_id']);
					}

					if (!$C740da31596f24ef['user_id']) {
					} else {
						$b174976b99c4ec48[] = intval($C740da31596f24ef['user_id']);
					}

					if (!$C740da31596f24ef['uuid']) {
					} else {
						$F805649379c06d30[] = $C740da31596f24ef['uuid'];
					}
				}
				$c92aec5c90838930 = $A356f6810cb9be68 = $f9c1bb233c3eb615 = $dec4b1df9997c4d4 = array();

				if (0 >= count($b174976b99c4ec48)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `lines`.`id`, `lines`.`is_mag`, `lines`.`is_e2`, `lines`.`is_restreamer`, `lines`.`username`, `mag_devices`.`mag_id`, `enigma2_devices`.`device_id` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` WHERE `lines`.`id` IN (' . implode(',', $b174976b99c4ec48) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$D78ff1d0edade5eb = $C740da31596f24ef['id'];
						unset($C740da31596f24ef['id']);
						$dec4b1df9997c4d4[$D78ff1d0edade5eb] = $C740da31596f24ef;
					}
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$Fee0d5a474c96306->query('SELECT `stream_id`, `series_id` FROM `streams_episodes` WHERE `stream_id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$f9c1bb233c3eb615[$C740da31596f24ef['stream_id']] = $C740da31596f24ef['series_id'];
					}
					$Fee0d5a474c96306->query('SELECT `id`, `type`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$c92aec5c90838930[$C740da31596f24ef['id']] = array($C740da31596f24ef['stream_display_name'], $C740da31596f24ef['type']);
					}
				}

				if (0 >= count($F805649379c06d30)) {
				} else {
					$Fee0d5a474c96306->query("SELECT `uuid`, `divergence` FROM `lines_divergence` WHERE `uuid` IN ('" . implode("','", $F805649379c06d30) . "');");

					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						$A356f6810cb9be68[$C740da31596f24ef['uuid']] = $C740da31596f24ef['divergence'];
					}
				}

				$Ea22c4a9ab5b2176 = 0;

				while ($Ea22c4a9ab5b2176 < count($b3439582205053ea)) {
					$b3439582205053ea[$Ea22c4a9ab5b2176]['divergence'] = ($A356f6810cb9be68[$b3439582205053ea[$Ea22c4a9ab5b2176]['uuid']] ?: 0);
					$b3439582205053ea[$Ea22c4a9ab5b2176]['series_no'] = ($f9c1bb233c3eb615[$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_id']] ?: null);
					$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_display_name'] = ($c92aec5c90838930[$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_id']][0] ?: '');
					$b3439582205053ea[$Ea22c4a9ab5b2176]['type'] = ($c92aec5c90838930[$b3439582205053ea[$Ea22c4a9ab5b2176]['stream_id']][1] ?: 1);
					$b3439582205053ea[$Ea22c4a9ab5b2176] = array_merge($b3439582205053ea[$Ea22c4a9ab5b2176], ($dec4b1df9997c4d4[$b3439582205053ea[$Ea22c4a9ab5b2176]['user_id']] ?: array()));
					$Ea22c4a9ab5b2176++;
				}
				$a85e1b7d42c346a0['recordsTotal'] = $Ec475faf4d560253;
				$a85e1b7d42c346a0['recordsFiltered'] = ($B3f0f4a134021073 ? ($a85e1b7d42c346a0['recordsTotal'] < $E400a3101514583e ? $a85e1b7d42c346a0['recordsTotal'] : $E400a3101514583e) : $a85e1b7d42c346a0['recordsTotal']);
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$c6c389b9adf3a40c = array('`lines_live`.`activity_id`', '`lines_live`.`divergence`', '`username`', '`streams`.`stream_display_name`', '`lines_live`.`user_agent`', '`lines_live`.`isp`', '`lines_live`.`user_ip`', 'UNIX_TIMESTAMP() - `lines_live`.`date_start`', '`lines_live`.`container`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`hls_end` = 0';
				$f86e19bdb1e7dae8[] = '`lines`.`member_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 9) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`lines_live`.`user_agent` LIKE ? OR `lines_live`.`user_ip` LIKE ? OR `lines_live`.`container` LIKE ? OR FROM_UNIXTIME(`lines_live`.`date_start`) LIKE ? OR `lines_live`.`geoip_country_code` LIKE ? OR `lines`.`username` LIKE ? OR `mag_devices`.`mac` LIKE ? OR `enigma2_devices`.`mac` LIKE ? OR `streams`.`stream_display_name` LIKE ?)';
				}

				if (0 >= intval(XUI::$rRequest['stream'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`lines_live`.`stream_id` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['stream'];
				}

				if (0 >= intval(XUI::$rRequest['user'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`lines`.`member_id` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['user'];
				}

				if (0 >= intval(XUI::$rRequest['line'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`lines_live`.`user_id` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['line'];
				}

				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `lines_live` LEFT JOIN `lines` ON `lines_live`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_live`.`stream_id` = `streams`.`id` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines_live`.`user_id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines_live`.`user_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `mag_devices`.`mag_id`, `enigma2_devices`.`device_id`, `lines`.`is_e2`, `lines`.`is_mag`, `lines_live`.`activity_id`, `lines_live`.`divergence`, `lines_live`.`user_id`, `lines_live`.`stream_id`, `streams`.`series_no`, `lines`.`is_restreamer`, `lines_live`.`isp`, `lines_live`.`server_id`, `lines_live`.`user_agent`, `lines_live`.`user_ip`, `lines_live`.`container`, `lines_live`.`uuid`, `lines_live`.`date_start`, `lines_live`.`geoip_country_code`, IF(`lines`.`is_mag`, `mag_devices`.`mac`, IF(`lines`.`is_e2`, `enigma2_devices`.`mac`, `lines`.`username`)) AS `username`, `streams`.`stream_display_name`, `streams`.`type` FROM `lines_live` LEFT JOIN `lines` ON `lines_live`.`user_id` = `lines`.`id` LEFT JOIN `streams` ON `lines_live`.`stream_id` = `streams`.`id` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines_live`.`user_id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines_live`.`user_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						$b3439582205053ea = $Fee0d5a474c96306->get_rows();
					}
				}
			}

			if (0 >= count($b3439582205053ea)) {
			} else {
				foreach ($b3439582205053ea as $C740da31596f24ef) {
					if (!$B3f0f4a134021073) {
						if ($C740da31596f24ef['divergence'] <= 50) {
							$b25be5f9af7a0a91 = '<i class="text-success fas fa-square tooltip" title="' . intval(100 - $C740da31596f24ef['divergence']) . '%"></i>';
						} else {
							if ($C740da31596f24ef['divergence'] <= 80) {
								$b25be5f9af7a0a91 = '<i class="text-warning fas fa-square tooltip" title="' . intval(100 - $C740da31596f24ef['divergence']) . '%"></i>';
							} else {
								$b25be5f9af7a0a91 = '<i class="text-danger fas fa-square tooltip" title="' . intval(100 - $C740da31596f24ef['divergence']) . '%"></i>';
							}
						}

						if ($C740da31596f24ef['is_mag']) {
							$a71afc14d6cd090d = "<a href='mag?id=" . $C740da31596f24ef['mag_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
						} else {
							if ($C740da31596f24ef['is_e2']) {
								$a71afc14d6cd090d = "<a href='enigma?id=" . $C740da31596f24ef['device_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
							} else {
								$a71afc14d6cd090d = "<a href='line?id=" . $C740da31596f24ef['user_id'] . "'>" . $C740da31596f24ef['username'] . '</a>';
							}
						}

						$Fe753328765ad26c = $C740da31596f24ef['stream_display_name'];

						if (0 < strlen($C740da31596f24ef['geoip_country_code'])) {
							$D0281cc88d5d14fd = "<img loading='lazy' src='assets/images/countries/" . strtolower($C740da31596f24ef['geoip_country_code']) . ".png'></img> &nbsp;";
						} else {
							$D0281cc88d5d14fd = '';
						}

						if ($C740da31596f24ef['user_ip']) {
							$c59ec257c284c894 = $D0281cc88d5d14fd . "<a onClick=\"whois('" . $C740da31596f24ef['user_ip'] . "');\" href='javascript: void(0);'>" . $C740da31596f24ef['user_ip'] . '</a>';
						} else {
							$c59ec257c284c894 = '';
						}

						$cafddc0a05fb9f1f = trim(explode('(', $C740da31596f24ef['user_agent'])[0]);
						$C5034884ed44603a = intval(time()) - intval($C740da31596f24ef['date_start']);
						$Ac54397e06e8e862 = 'success';

						if (86400 <= $C5034884ed44603a) {
							$C5034884ed44603a = sprintf('%02dd %02dh', $C5034884ed44603a / 86400, ($C5034884ed44603a / 3600) % 24);
							$Ac54397e06e8e862 = 'danger';
						} else {
							if (3600 <= $C5034884ed44603a) {
								if (14400 < $C5034884ed44603a) {
									$Ac54397e06e8e862 = 'warning';
								} else {
									if (43200 >= $C5034884ed44603a) {
									} else {
										$Ac54397e06e8e862 = 'danger';
									}
								}

								$C5034884ed44603a = sprintf('%02dh %02dm', $C5034884ed44603a / 3600, ($C5034884ed44603a / 60) % 60);
							} else {
								$C5034884ed44603a = sprintf('%02dm %02ds', ($C5034884ed44603a / 60) % 60, $C5034884ed44603a % 60);
							}
						}

						$C5034884ed44603a = "<button type='button' class='btn btn-" . $Ac54397e06e8e862 . " btn-xs waves-effect waves-light btn-fixed'>" . $C5034884ed44603a . '</button>';
						$ebab77ef4bee81e0 = "<button title=\"Kill Connection\" type=\"button\" class=\"btn btn-light waves-effect waves-light btn-xs tooltip\" onClick=\"api('" . $C740da31596f24ef['uuid'] . "', 'kill');\"><i class=\"fas fa-hammer\"></i></button>";
						$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['activity_id'], $b25be5f9af7a0a91, $a71afc14d6cd090d, $Fe753328765ad26c, $cafddc0a05fb9f1f, $C740da31596f24ef['isp'], $c59ec257c284c894, $C5034884ed44603a, strtoupper($C740da31596f24ef['container']), $ebab77ef4bee81e0);
					} else {
						$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		} else {
			exit();
		}
	} else {
		if ($E379394c7b1a273f == 'reg_user_logs') {
			$c6c389b9adf3a40c = array('`users_logs`.`id`', '`users`.`username`', '`users_logs`.`log_id`', '`users_logs`.`type`, `users_logs`.`action`', '`users_logs`.`cost`', '`users_logs`.`credits_after`', '`users_logs`.`date`');

			if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
				$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
			} else {
				$C1633246b8426116 = 0;
			}

			$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
			$f86e19bdb1e7dae8[] = '`users_logs`.`owner` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

			if (0 >= strlen(XUI::$rRequest['search']['value'])) {
			} else {
				foreach (range(1, 3) as $b6f0b24a56fe41b6) {
					$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
				}
				$f86e19bdb1e7dae8[] = '(`users`.`username` LIKE ? OR `users_logs`.`type` LIKE ? OR `users_logs`.`action` LIKE ?)';
			}

			if (0 >= strlen(XUI::$rRequest['range'])) {
			} else {
				$a859a0996bb0f1ff = substr(XUI::$rRequest['range'], 0, 10);
				$B37c1f185be84c33 = substr(XUI::$rRequest['range'], strlen(XUI::$rRequest['range']) - 10, 10);

				if ($a859a0996bb0f1ff = strtotime($a859a0996bb0f1ff . ' 00:00:00')) {
				} else {
					$a859a0996bb0f1ff = null;
				}

				if ($B37c1f185be84c33 = strtotime($B37c1f185be84c33 . ' 23:59:59')) {
				} else {
					$B37c1f185be84c33 = null;
				}

				if (!($a859a0996bb0f1ff && $B37c1f185be84c33)) {
				} else {
					$f86e19bdb1e7dae8[] = '(`users_logs`.`date` >= ? AND `users_logs`.`date` <= ?)';
					$Df2582e36fdd6160[] = $a859a0996bb0f1ff;
					$Df2582e36fdd6160[] = $B37c1f185be84c33;
				}
			}

			if (0 >= strlen(XUI::$rRequest['reseller'])) {
			} else {
				$f86e19bdb1e7dae8[] = '`users_logs`.`owner` = ?';
				$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
			}

			if (0 < count($f86e19bdb1e7dae8)) {
				$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			} else {
				$ff9d21c7a9d310b1 = '';
			}

			if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
			} else {
				$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
				$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
			}

			$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `users_logs` LEFT JOIN `users` ON `users`.`id` = `users_logs`.`owner` ' . $ff9d21c7a9d310b1 . ';';
			$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

			if ($Fee0d5a474c96306->num_rows() == 1) {
				$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
			} else {
				$a85e1b7d42c346a0['recordsTotal'] = 0;
			}

			$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

			if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
			} else {
				$D57b432dc56eb885 = D19b453AC8e32C50();
				$A6d7047f2fda966c = 'SELECT `users`.`username`, `users_logs`.`id`, `users_logs`.`owner`, `users_logs`.`type`, `users_logs`.`action`, `users_logs`.`log_id`, `users_logs`.`package_id`, `users_logs`.`cost`, `users_logs`.`credits_after`, `users_logs`.`date`, `users_logs`.`deleted_info` FROM `users_logs` LEFT JOIN `users` ON `users`.`id` = `users_logs`.`owner` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
						if (!$B3f0f4a134021073) {
							if (in_array($C740da31596f24ef['owner'], array_merge($B2ff75c438fb3031['direct_reports'], array($D4253f9520627819['id'])))) {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['owner']) . "'>" . $C740da31596f24ef['username'] . '</a>';
							} else {
								$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['owner']) . "'>" . $C740da31596f24ef['username'] . "<br/><small class='text-pink'>(indirect)</small></a>";
							}

							$cdc93dae5ba3d206 = array('line' => 'User Line', 'mag' => 'MAG Device', 'enigma' => 'Enigma2 Device', 'user' => 'Reseller')[$C740da31596f24ef['type']];

							switch ($C740da31596f24ef['action']) {
								case 'new':
									if ($C740da31596f24ef['package_id']) {
										$Fa016cbf0b72bfdd = 'Created New ' . $cdc93dae5ba3d206 . ' with Package: ' . $D57b432dc56eb885[$C740da31596f24ef['package_id']]['package_name'];
									} else {
										$Fa016cbf0b72bfdd = 'Created New ' . $cdc93dae5ba3d206;
									}

									break;

								case 'extend':
									if ($C740da31596f24ef['package_id']) {
										$Fa016cbf0b72bfdd = 'Extended ' . $cdc93dae5ba3d206 . ' with Package: ' . $D57b432dc56eb885[$C740da31596f24ef['package_id']]['package_name'];
									} else {
										$Fa016cbf0b72bfdd = 'Extended ' . $cdc93dae5ba3d206;
									}

									break;

								case 'edit':
									$Fa016cbf0b72bfdd = 'Edited ' . $cdc93dae5ba3d206;

									break;

								case 'enable':
									$Fa016cbf0b72bfdd = 'Enabled ' . $cdc93dae5ba3d206;

									break;

								case 'disable':
									$Fa016cbf0b72bfdd = 'Disabled ' . $cdc93dae5ba3d206;

									break;

								case 'delete':
									$Fa016cbf0b72bfdd = 'Deleted ' . $cdc93dae5ba3d206;

									break;

								case 'send_event':
									$Fa016cbf0b72bfdd = 'Sent Event to ' . $cdc93dae5ba3d206;

									break;

								case 'adjust_credits':
									$Fa016cbf0b72bfdd = 'Adjusted Credits by ' . $C740da31596f24ef['cost'];

									break;
							}
							$a4dd92d2bc66e08d = null;

							switch ($C740da31596f24ef['type']) {
								case 'line':
									$Ff014d0ebd314fcd = B4036ef9a1Db8473($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='line?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['username'] . '</a>';
									}

									break;

								case 'user':
									$Ff014d0ebd314fcd = FE76c4BcaF81bAA4($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='user?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['username'] . '</a>';
									}

									break;

								case 'mag':
									$Ff014d0ebd314fcd = Bfe9937c6D242A3D($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='mag?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['mac'] . '</a>';
									}

									break;

								case 'enigma':
									$Ff014d0ebd314fcd = bA960cAB7FE0Cd93($C740da31596f24ef['log_id']);

									if (!$Ff014d0ebd314fcd) {
									} else {
										$a4dd92d2bc66e08d = "<a href='enigma?id=" . $C740da31596f24ef['log_id'] . "'>" . $Ff014d0ebd314fcd['mac'] . '</a>';
									}

									break;
							}

							if ($a4dd92d2bc66e08d) {
							} else {
								$eef2045a92fba631 = json_decode($C740da31596f24ef['deleted_info'], true);

								if (is_array($eef2045a92fba631)) {
									if (isset($eef2045a92fba631['mac'])) {
										$a4dd92d2bc66e08d = "<span class='text-secondary'>" . $eef2045a92fba631['mac'] . '</span>';
									} else {
										$a4dd92d2bc66e08d = "<span class='text-secondary'>" . $eef2045a92fba631['username'] . '</span>';
									}
								} else {
									$a4dd92d2bc66e08d = "<span class='text-secondary'>DELETED</span>";
								}
							}

							$a85e1b7d42c346a0['data'][] = array($C740da31596f24ef['id'], $Dbb9e190755fc819, $a4dd92d2bc66e08d, $Fa016cbf0b72bfdd, number_format($C740da31596f24ef['cost'], 0), number_format($C740da31596f24ef['credits_after'], 0), date($F2d4d8f7981ac574['datetime_format'], $C740da31596f24ef['date']));
						} else {
							unset($C740da31596f24ef['deleted_info']);
							$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
						}
					}
				}
			}

			echo json_encode($a85e1b7d42c346a0);

			exit();
		}

		if ($E379394c7b1a273f != 'reg_users') {
		} else {
			if ($B2ff75c438fb3031['create_sub_resellers']) {
				$c6c389b9adf3a40c = array('`users`.`id`', '`users`.`username`', '`r`.`username`', '`users`.`ip`', '`users`.`status`', '`users`.`credits`', '`user_count`', '`users`.`last_login`', false);

				if (isset(XUI::$rRequest['order']) && 0 < strlen(XUI::$rRequest['order'][0]['column'])) {
					$C1633246b8426116 = intval(XUI::$rRequest['order'][0]['column']);
				} else {
					$C1633246b8426116 = 0;
				}

				$f86e19bdb1e7dae8 = $Df2582e36fdd6160 = array();
				$f86e19bdb1e7dae8[] = '`users`.`owner_id` IN (' . implode(',', $D4253f9520627819['reports']) . ')';

				if (0 >= strlen(XUI::$rRequest['search']['value'])) {
				} else {
					foreach (range(1, 9) as $b6f0b24a56fe41b6) {
						$Df2582e36fdd6160[] = '%' . XUI::$rRequest['search']['value'] . '%';
					}
					$f86e19bdb1e7dae8[] = '(`users`.`id` LIKE ? OR `users`.`username` LIKE ? OR `users`.`notes` LIKE ? OR `r`.`username` LIKE ? OR FROM_UNIXTIME(`users`.`date_registered`) LIKE ? OR FROM_UNIXTIME(`users`.`last_login`) LIKE ? OR `users`.`email` LIKE ? OR `users`.`ip` LIKE ? OR `users_groups`.`group_name` LIKE ?)';
				}

				if (0 >= strlen(XUI::$rRequest['filter'])) {
				} else {
					if (XUI::$rRequest['filter'] == 1) {
						$f86e19bdb1e7dae8[] = '`users`.`status` = 1';
					} else {
						if (XUI::$rRequest['filter'] != 2) {
						} else {
							$f86e19bdb1e7dae8[] = '`users`.`status` = 0';
						}
					}
				}

				if (0 >= strlen(XUI::$rRequest['reseller'])) {
				} else {
					$f86e19bdb1e7dae8[] = '`users`.`owner_id` = ?';
					$Df2582e36fdd6160[] = XUI::$rRequest['reseller'];
				}

				if (0 < count($f86e19bdb1e7dae8)) {
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
				} else {
					$ff9d21c7a9d310b1 = '';
				}

				if (!$c6c389b9adf3a40c[$C1633246b8426116]) {
				} else {
					$cb10faf5ade31619 = (strtolower(XUI::$rRequest['order'][0]['dir']) === 'desc' ? 'desc' : 'asc');
					$Ccfe11bd7a796290 = 'ORDER BY ' . $c6c389b9adf3a40c[$C1633246b8426116] . ' ' . $cb10faf5ade31619;
				}

				$Fc3bbe383da3a3f3 = 'SELECT COUNT(*) AS `count` FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` LEFT JOIN `users` AS `r` on `r`.`id` = `users`.`owner_id` ' . $ff9d21c7a9d310b1 . ';';
				$Fee0d5a474c96306->query($Fc3bbe383da3a3f3, ...$Df2582e36fdd6160);

				if ($Fee0d5a474c96306->num_rows() == 1) {
					$a85e1b7d42c346a0['recordsTotal'] = $Fee0d5a474c96306->get_row()['count'];
				} else {
					$a85e1b7d42c346a0['recordsTotal'] = 0;
				}

				$a85e1b7d42c346a0['recordsFiltered'] = $a85e1b7d42c346a0['recordsTotal'];

				if (0 >= $a85e1b7d42c346a0['recordsTotal']) {
				} else {
					$A6d7047f2fda966c = 'SELECT `users`.`id`, `users`.`status`, `users_groups`.`is_reseller`, `users`.`notes`, `users`.`owner_id`, `users`.`credits`, `users`.`username`, `users`.`email`, `users`.`ip`, FROM_UNIXTIME(`users`.`date_registered`) AS `date_registered`, FROM_UNIXTIME(`users`.`last_login`) AS `last_login`, `r`.`username` as `owner_username`, `users_groups`.`group_name`, `users`.`status`, (SELECT COUNT(`id`) FROM `lines` WHERE `member_id` = `users`.`id`) AS `user_count` FROM `users` LEFT JOIN `users_groups` ON `users_groups`.`group_id` = `users`.`member_group_id` LEFT JOIN `users` AS `r` on `r`.`id` = `users`.`owner_id` ' . $ff9d21c7a9d310b1 . ' ' . $Ccfe11bd7a796290 . ' LIMIT ' . $D031c48a1422c07e . ', ' . $E400a3101514583e . ';';
					$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$Df2582e36fdd6160);

					if (0 >= $Fee0d5a474c96306->num_rows()) {
					} else {
						foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
							if (!$B3f0f4a134021073) {
								if ($C740da31596f24ef['status'] == 1) {
									$Ba23222f3ed2dc08 = '<i class="text-success fas fa-square"></i>';
								} else {
									$Ba23222f3ed2dc08 = '<i class="text-secondary fas fa-square"></i>';
								}

								if ($C740da31596f24ef['last_login']) {
								} else {
									$C740da31596f24ef['last_login'] = 'NEVER';
								}

								$ebab77ef4bee81e0 = '<div class="btn-group">';

								if (0 < strlen($C740da31596f24ef['notes'])) {
									$ebab77ef4bee81e0 .= '<button type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" title="' . $C740da31596f24ef['notes'] . '"><i class="mdi mdi-note"></i></button>';
								} else {
									$ebab77ef4bee81e0 .= '<button disabled type="button" class="btn btn-light waves-effect waves-light btn-xs"><i class="mdi mdi-note"></i></button>';
								}

								if (in_array($C740da31596f24ef['id'], array_merge($B2ff75c438fb3031['direct_reports'], array($D4253f9520627819['id'])))) {
									$ebab77ef4bee81e0 .= '<button title="Adjust Credits" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="addCredits(' . $C740da31596f24ef['id'] . ", '" . addslashes($C740da31596f24ef['username']) . "', " . intval($C740da31596f24ef['credits']) . ');"><i class="mdi mdi-coin"></i></button>';
									$a71afc14d6cd090d = "<a href='user?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['username'] . '</a>';
								} else {
									$ebab77ef4bee81e0 .= '<button title="Adjust Credits" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="addCredits(' . $C740da31596f24ef['id'] . ", '" . addslashes($C740da31596f24ef['username']) . "', " . intval($C740da31596f24ef['credits']) . ', true);"><i class="mdi mdi-coin"></i></button>';
									$a71afc14d6cd090d = "<a href='user?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['username'] . "<br/><small class='text-pink'>(indirect)</small></a>";
								}

								$ebab77ef4bee81e0 .= '<a href="user?id=' . $C740da31596f24ef['id'] . '"><button title="Edit" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip"><i class="mdi mdi-pencil-outline"></i></button></a>';

								if ($C740da31596f24ef['status'] == 1) {
									$ebab77ef4bee81e0 .= '<button title="Disable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'disable');\"><i class=\"mdi mdi-lock\"></i></button>";
								} else {
									$ebab77ef4bee81e0 .= '<button title="Enable" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'enable');\"><i class=\"mdi mdi-lock\"></i></button>";
								}

								if (!$B2ff75c438fb3031['delete_users']) {
								} else {
									$ebab77ef4bee81e0 .= '<button title="Delete" type="button" class="btn btn-light waves-effect waves-light btn-xs tooltip" onClick="api(' . $C740da31596f24ef['id'] . ", 'delete');\"><i class=\"mdi mdi-close\"></i></button>";
								}

								$ebab77ef4bee81e0 .= '</div>';

								if (0 < strlen($C740da31596f24ef['ip'])) {
									$c59ec257c284c894 = "<a onClick=\"whois('" . $C740da31596f24ef['ip'] . "');\" href='javascript: void(0);'>" . $C740da31596f24ef['ip'] . '</a>';
								} else {
									$c59ec257c284c894 = '';
								}

								if ($C740da31596f24ef['is_reseller']) {
									$F17f20a56056dab3 = '<button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['credits'], 0) . '</button>';
								} else {
									$F17f20a56056dab3 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">-</button>';
								}

								if (0 < $C740da31596f24ef['user_count']) {
									$c926828403592095 = '<button type="button" class="btn btn-info btn-xs waves-effect waves-light">' . number_format($C740da31596f24ef['user_count'], 0) . '</button>';
								} else {
									$c926828403592095 = '<button type="button" class="btn btn-secondary btn-xs waves-effect waves-light">0</button>';
								}

								if (in_array($C740da31596f24ef['owner_id'], array_merge($B2ff75c438fb3031['direct_reports'], array($D4253f9520627819['id'])))) {
									$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['owner_id']) . "'>" . $C740da31596f24ef['owner_username'] . '</a>';
								} else {
									$Dbb9e190755fc819 = "<a href='user?id=" . intval($C740da31596f24ef['owner_id']) . "'>" . $C740da31596f24ef['owner_username'] . "<br/><small class='text-pink'>(indirect)</small></a>";
								}

								$a85e1b7d42c346a0['data'][] = array("<a href='user?id=" . intval($C740da31596f24ef['id']) . "'>" . $C740da31596f24ef['id'] . '</a>', $a71afc14d6cd090d, $Dbb9e190755fc819, $c59ec257c284c894, $Ba23222f3ed2dc08, $F17f20a56056dab3, $c926828403592095, $C740da31596f24ef['last_login'], $ebab77ef4bee81e0);
							} else {
								$a85e1b7d42c346a0['data'][] = filterrow($C740da31596f24ef, XUI::$rRequest['show_columns'], XUI::$rRequest['hide_columns']);
							}
						}
					}
				}

				echo json_encode($a85e1b7d42c346a0);

				exit();
			}

			exit();
		}
	}
} else {
	echo json_encode($a85e1b7d42c346a0);

	exit();
}

function filterRow($C740da31596f24ef, $C9e42207e95f03ed, $Be763c6c88600252)
{
	if ($C9e42207e95f03ed || $Be763c6c88600252) {
		$a85e1b7d42c346a0 = array();

		foreach (array_keys($C740da31596f24ef) as $D3fa098be3f297cd) {
			if ($C9e42207e95f03ed) {
				if (!in_array($D3fa098be3f297cd, $C9e42207e95f03ed)) {
				} else {
					$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
				}
			} else {
				if (!$Be763c6c88600252) {
				} else {
					if (in_array($D3fa098be3f297cd, $Be763c6c88600252)) {
					} else {
						$a85e1b7d42c346a0[$D3fa098be3f297cd] = $C740da31596f24ef[$D3fa098be3f297cd];
					}
				}
			}
		}

		return $a85e1b7d42c346a0;
	} else {
		return $C740da31596f24ef;
	}
}
