<?php

if (Xui\Functions::verifyLicense()) {
} else {
	header('Location: license');
}

if (!(session_status() == PHP_SESSION_NONE && php_sapi_name() !== 'cli')) {
} else {
	$f0a0900c0afc1c32 = (session_get_cookie_params() ?: array());
	$f0a0900c0afc1c32['samesite'] = 'Strict';
	session_set_cookie_params($f0a0900c0afc1c32);
	session_start();
}
define('XUI_VERSION', '2.0.1');
define('STATUS_FAILURE', 0);
define('STATUS_SUCCESS', 1);
define('STATUS_SUCCESS_MULTI', 2);
define('STATUS_CODE_LENGTH', 3);
define('STATUS_NO_SOURCES', 4);
define('STATUS_DISABLED', 5);
define('STATUS_NOT_ADMIN', 6);
define('STATUS_INVALID_EMAIL', 7);
define('STATUS_INVALID_PASSWORD', 8);
define('STATUS_INVALID_IP', 9);
define('STATUS_INVALID_PLAYLIST', 10);
define('STATUS_INVALID_NAME', 11);
define('STATUS_INVALID_CAPTCHA', 12);
define('STATUS_INVALID_CODE', 13);
define('STATUS_INVALID_DATE', 14);
define('STATUS_INVALID_FILE', 15);
define('STATUS_INVALID_GROUP', 16);
define('STATUS_INVALID_DATA', 17);
define('STATUS_INVALID_DIR', 18);
define('STATUS_INVALID_MAC', 19);
define('STATUS_EXISTS_CODE', 20);
define('STATUS_EXISTS_NAME', 21);
define('STATUS_EXISTS_USERNAME', 22);
define('STATUS_EXISTS_MAC', 23);
define('STATUS_EXISTS_SOURCE', 24);
define('STATUS_EXISTS_IP', 25);
define('STATUS_EXISTS_DIR', 26);
define('STATUS_SUCCESS_REPLACE', 27);
define('STATUS_FLUSH', 28);
define('STATUS_TOO_MANY_RESULTS', 29);
define('STATUS_SPACE_ISSUE', 30);
define('STATUS_INVALID_USER', 31);
define('STATUS_CERTBOT', 32);
define('STATUS_CERTBOT_INVALID', 33);
define('STATUS_INVALID_INPUT', 34);
define('STATUS_NOT_RESELLER', 35);
define('STATUS_NO_TRIALS', 36);
define('STATUS_INSUFFICIENT_CREDITS', 37);
define('STATUS_INVALID_PACKAGE', 38);
define('STATUS_INVALID_TYPE', 39);
define('STATUS_INVALID_USERNAME', 40);
define('STATUS_INVALID_SUBRESELLER', 41);
define('STATUS_NO_DESCRIPTION', 42);
define('STATUS_NO_KEY', 43);
define('STATUS_EXISTS_HMAC', 44);
define('STATUS_CERTBOT_RUNNING', 45);
define('STATUS_RESERVED_CODE', 46);
define('STATUS_NO_TITLE', 47);
define('STATUS_NO_SOURCE', 48);
require_once '/home/xui/www/constants.php';
require_once INCLUDES_PATH . 'pdo.php';
require_once INCLUDES_PATH . 'xui.php';
require_once INCLUDES_PATH . 'libs/mobiledetect.php';
require_once INCLUDES_PATH . 'admin_api.php';
require_once INCLUDES_PATH . 'reseller_api.php';
register_shutdown_function('shutdown_admin');
$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
XUI::$db = &$Fee0d5a474c96306;
XUI::init();
API::$db = &$Fee0d5a474c96306;
API::init();
ResellerAPI::$db = &$Fee0d5a474c96306;
ResellerAPI::init();
XUI::BfA8B6fe314DeD7F();
define('SERVER_ID', intval(XUI::$rConfig['server_id']));
$D6b7c3fced70ccca = new Mobile_Detect();
$F61f585ee1fe12b7 = $D6b7c3fced70ccca->isMobile();
$cd2a4260ef308305 = 15;
$a154c63fbed143ac = 10;
set_time_limit($cd2a4260ef308305);
ini_set('mysql.connect_timeout', $a154c63fbed143ac);
ini_set('max_execution_time', $cd2a4260ef308305);
ini_set('default_socket_timeout', $cd2a4260ef308305);
$C6033ec178efa2ae = ace67c2bfe9adad5();
$a8bb73cba48fb7f6 = f6da964066f2f5e4();
$F2d4d8f7981ac574 = XUI::$rSettings;
$Fd8279be5302940a = a4338a704a6a7789();
$d205bd8d1407bcb1 = Xui\Functions::getLicense();
$D8d681f377d877d4 = ($d205bd8d1407bcb1[9] == 1 ?: 0);
$Ab5b854e25293d6b = ($d205bd8d1407bcb1[9] == 2 ?: 0);
uasort(
	$a8bb73cba48fb7f6,
	function($d7e6e8fcd8d94d98, $dbc1091ca2977adb) {
		return $d7e6e8fcd8d94d98['order'] - $dbc1091ca2977adb['order'];
	}
);

if (empty($d205bd8d1407bcb1[11]) || XUI::$rConfig['license'] == $d205bd8d1407bcb1[11]) {
	if (php_sapi_name() === 'cli' || empty($d205bd8d1407bcb1[10])) {
	} else {
		if (time() >= $d205bd8d1407bcb1[10]) {
		} else {
			exit('Please synchronise your system time with NTP as it seems to be incorrect.<br/><br/>This may help: timedatectl set-ntp 1');
		}
	}

	$_ = parse_ini_file(XUI_HOME . 'includes/langs/en.ini');
	$C9f67e53c9e22ebf = array('AuraHD', 'AuraHD2', 'AuraHD3', 'AuraHD4', 'AuraHD5', 'AuraHD6', 'AuraHD7', 'AuraHD8', 'AuraHD9', 'MAG200', 'MAG245', 'MAG245D', 'MAG250', 'MAG254', 'MAG255', 'MAG256', 'MAG257', 'MAG260', 'MAG270', 'MAG275', 'MAG322', 'MAG323', 'MAG324', 'MAG325', 'MAG349', 'MAG350', 'MAG351', 'MAG352', 'MAG420', 'WR320', 'TH100', 'MAG424', 'MAG424W3');
	$Deba92a26931982d = array('AF' => 'Afghanistan', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua and Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia (Plurinational State of)', 'BQ' => 'Bonaire, Sint Eustatius and Saba', 'BA' => 'Bosnia and Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'CV' => 'Cabo Verde', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CD' => 'Congo (the Democratic Republic of the)', 'CG' => 'Congo', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'HR' => 'Croatia', 'CU' => 'Cuba', 'CW' => 'Curaçao', 'CY' => 'Cyprus', 'CZ' => 'Czechia', 'CI' => "Côte d'Ivoire", 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'SZ' => 'Eswatini', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands [Malvinas]', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island and McDonald Islands', 'VA' => 'Holy See', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran (Islamic Republic of)', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KP' => "Korea (the Democratic People's Republic of)", 'KR' => 'Korea (the Republic of)', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => "Lao People's Democratic Republic", 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia (Federated States of)', 'MD' => 'Moldova (the Republic of)', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestine, State of', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'MK' => 'Republic of North Macedonia', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'RE' => 'Réunion', 'BL' => 'Saint Barthélemy', 'SH' => 'Saint Helena, Ascension and Tristan da Cunha', 'KN' => 'Saint Kitts and Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin (French part)', 'PM' => 'Saint Pierre and Miquelon', 'VC' => 'Saint Vincent and the Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome and Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SX' => 'Sint Maarten (Dutch part)', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia and the South Sandwich Islands', 'SS' => 'South Sudan', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard and Jan Mayen', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan (Province of China)', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania, United Republic of', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad and Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks and Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'UM' => 'United States Minor Outlying Islands', 'US' => 'United States of America', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela (Bolivarian Republic of)', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands (British)', 'VI' => 'Virgin Islands (U.S.)', 'WF' => 'Wallis and Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe', 'AX' => 'Åland Islands');
	$F4f693463e7962fc = array(array('id' => '', 'name' => 'Off'), array('id' => 'A1', 'name' => 'Anonymous Proxy'), array('id' => 'A2', 'name' => 'Satellite Provider'), array('id' => 'O1', 'name' => 'Other Country'), array('id' => 'AF', 'name' => 'Afghanistan'), array('id' => 'AX', 'name' => 'Aland Islands'), array('id' => 'AL', 'name' => 'Albania'), array('id' => 'DZ', 'name' => 'Algeria'), array('id' => 'AS', 'name' => 'American Samoa'), array('id' => 'AD', 'name' => 'Andorra'), array('id' => 'AO', 'name' => 'Angola'), array('id' => 'AI', 'name' => 'Anguilla'), array('id' => 'AQ', 'name' => 'Antarctica'), array('id' => 'AG', 'name' => 'Antigua And Barbuda'), array('id' => 'AR', 'name' => 'Argentina'), array('id' => 'AM', 'name' => 'Armenia'), array('id' => 'AW', 'name' => 'Aruba'), array('id' => 'AU', 'name' => 'Australia'), array('id' => 'AT', 'name' => 'Austria'), array('id' => 'AZ', 'name' => 'Azerbaijan'), array('id' => 'BS', 'name' => 'Bahamas'), array('id' => 'BH', 'name' => 'Bahrain'), array('id' => 'BD', 'name' => 'Bangladesh'), array('id' => 'BB', 'name' => 'Barbados'), array('id' => 'BY', 'name' => 'Belarus'), array('id' => 'BE', 'name' => 'Belgium'), array('id' => 'BZ', 'name' => 'Belize'), array('id' => 'BJ', 'name' => 'Benin'), array('id' => 'BM', 'name' => 'Bermuda'), array('id' => 'BT', 'name' => 'Bhutan'), array('id' => 'BO', 'name' => 'Bolivia'), array('id' => 'BA', 'name' => 'Bosnia And Herzegovina'), array('id' => 'BW', 'name' => 'Botswana'), array('id' => 'BV', 'name' => 'Bouvet Island'), array('id' => 'BR', 'name' => 'Brazil'), array('id' => 'IO', 'name' => 'British Indian Ocean Territory'), array('id' => 'BN', 'name' => 'Brunei Darussalam'), array('id' => 'BG', 'name' => 'Bulgaria'), array('id' => 'BF', 'name' => 'Burkina Faso'), array('id' => 'BI', 'name' => 'Burundi'), array('id' => 'KH', 'name' => 'Cambodia'), array('id' => 'CM', 'name' => 'Cameroon'), array('id' => 'CA', 'name' => 'Canada'), array('id' => 'CV', 'name' => 'Cape Verde'), array('id' => 'KY', 'name' => 'Cayman Islands'), array('id' => 'CF', 'name' => 'Central African Republic'), array('id' => 'TD', 'name' => 'Chad'), array('id' => 'CL', 'name' => 'Chile'), array('id' => 'CN', 'name' => 'China'), array('id' => 'CX', 'name' => 'Christmas Island'), array('id' => 'CC', 'name' => 'Cocos (Keeling) Islands'), array('id' => 'CO', 'name' => 'Colombia'), array('id' => 'KM', 'name' => 'Comoros'), array('id' => 'CG', 'name' => 'Congo'), array('id' => 'CD', 'name' => 'Congo, Democratic Republic'), array('id' => 'CK', 'name' => 'Cook Islands'), array('id' => 'CR', 'name' => 'Costa Rica'), array('id' => 'CI', 'name' => "Cote D'Ivoire"), array('id' => 'HR', 'name' => 'Croatia'), array('id' => 'CU', 'name' => 'Cuba'), array('id' => 'CY', 'name' => 'Cyprus'), array('id' => 'CZ', 'name' => 'Czech Republic'), array('id' => 'DK', 'name' => 'Denmark'), array('id' => 'DJ', 'name' => 'Djibouti'), array('id' => 'DM', 'name' => 'Dominica'), array('id' => 'DO', 'name' => 'Dominican Republic'), array('id' => 'EC', 'name' => 'Ecuador'), array('id' => 'EG', 'name' => 'Egypt'), array('id' => 'SV', 'name' => 'El Salvador'), array('id' => 'GQ', 'name' => 'Equatorial Guinea'), array('id' => 'ER', 'name' => 'Eritrea'), array('id' => 'EE', 'name' => 'Estonia'), array('id' => 'ET', 'name' => 'Ethiopia'), array('id' => 'FK', 'name' => 'Falkland Islands (Malvinas)'), array('id' => 'FO', 'name' => 'Faroe Islands'), array('id' => 'FJ', 'name' => 'Fiji'), array('id' => 'FI', 'name' => 'Finland'), array('id' => 'FR', 'name' => 'France'), array('id' => 'GF', 'name' => 'French Guiana'), array('id' => 'PF', 'name' => 'French Polynesia'), array('id' => 'TF', 'name' => 'French Southern Territories'), array('id' => 'MK', 'name' => 'Fyrom'), array('id' => 'GA', 'name' => 'Gabon'), array('id' => 'GM', 'name' => 'Gambia'), array('id' => 'GE', 'name' => 'Georgia'), array('id' => 'DE', 'name' => 'Germany'), array('id' => 'GH', 'name' => 'Ghana'), array('id' => 'GI', 'name' => 'Gibraltar'), array('id' => 'GR', 'name' => 'Greece'), array('id' => 'GL', 'name' => 'Greenland'), array('id' => 'GD', 'name' => 'Grenada'), array('id' => 'GP', 'name' => 'Guadeloupe'), array('id' => 'GU', 'name' => 'Guam'), array('id' => 'GT', 'name' => 'Guatemala'), array('id' => 'GG', 'name' => 'Guernsey'), array('id' => 'GN', 'name' => 'Guinea'), array('id' => 'GW', 'name' => 'Guinea-Bissau'), array('id' => 'GY', 'name' => 'Guyana'), array('id' => 'HT', 'name' => 'Haiti'), array('id' => 'HM', 'name' => 'Heard Island & Mcdonald Islands'), array('id' => 'VA', 'name' => 'Holy See (Vatican City State)'), array('id' => 'HN', 'name' => 'Honduras'), array('id' => 'HK', 'name' => 'Hong Kong'), array('id' => 'HU', 'name' => 'Hungary'), array('id' => 'IS', 'name' => 'Iceland'), array('id' => 'IN', 'name' => 'India'), array('id' => 'ID', 'name' => 'Indonesia'), array('id' => 'IR', 'name' => 'Iran, Islamic Republic Of'), array('id' => 'IQ', 'name' => 'Iraq'), array('id' => 'IE', 'name' => 'Ireland'), array('id' => 'IM', 'name' => 'Isle Of Man'), array('id' => 'IL', 'name' => 'Israel'), array('id' => 'IT', 'name' => 'Italy'), array('id' => 'JM', 'name' => 'Jamaica'), array('id' => 'JP', 'name' => 'Japan'), array('id' => 'JE', 'name' => 'Jersey'), array('id' => 'JO', 'name' => 'Jordan'), array('id' => 'KZ', 'name' => 'Kazakhstan'), array('id' => 'KE', 'name' => 'Kenya'), array('id' => 'KI', 'name' => 'Kiribati'), array('id' => 'KR', 'name' => 'Korea'), array('id' => 'KW', 'name' => 'Kuwait'), array('id' => 'KG', 'name' => 'Kyrgyzstan'), array('id' => 'LA', 'name' => "Lao People's Democratic Republic"), array('id' => 'LV', 'name' => 'Latvia'), array('id' => 'LB', 'name' => 'Lebanon'), array('id' => 'LS', 'name' => 'Lesotho'), array('id' => 'LR', 'name' => 'Liberia'), array('id' => 'LY', 'name' => 'Libyan Arab Jamahiriya'), array('id' => 'LI', 'name' => 'Liechtenstein'), array('id' => 'LT', 'name' => 'Lithuania'), array('id' => 'LU', 'name' => 'Luxembourg'), array('id' => 'MO', 'name' => 'Macao'), array('id' => 'MG', 'name' => 'Madagascar'), array('id' => 'MW', 'name' => 'Malawi'), array('id' => 'MY', 'name' => 'Malaysia'), array('id' => 'MV', 'name' => 'Maldives'), array('id' => 'ML', 'name' => 'Mali'), array('id' => 'MT', 'name' => 'Malta'), array('id' => 'MH', 'name' => 'Marshall Islands'), array('id' => 'MQ', 'name' => 'Martinique'), array('id' => 'MR', 'name' => 'Mauritania'), array('id' => 'MU', 'name' => 'Mauritius'), array('id' => 'YT', 'name' => 'Mayotte'), array('id' => 'MX', 'name' => 'Mexico'), array('id' => 'FM', 'name' => 'Micronesia, Federated States Of'), array('id' => 'MD', 'name' => 'Moldova'), array('id' => 'MC', 'name' => 'Monaco'), array('id' => 'MN', 'name' => 'Mongolia'), array('id' => 'ME', 'name' => 'Montenegro'), array('id' => 'MS', 'name' => 'Montserrat'), array('id' => 'MA', 'name' => 'Morocco'), array('id' => 'MZ', 'name' => 'Mozambique'), array('id' => 'MM', 'name' => 'Myanmar'), array('id' => 'NA', 'name' => 'Namibia'), array('id' => 'NR', 'name' => 'Nauru'), array('id' => 'NP', 'name' => 'Nepal'), array('id' => 'NL', 'name' => 'Netherlands'), array('id' => 'AN', 'name' => 'Netherlands Antilles'), array('id' => 'NC', 'name' => 'New Caledonia'), array('id' => 'NZ', 'name' => 'New Zealand'), array('id' => 'NI', 'name' => 'Nicaragua'), array('id' => 'NE', 'name' => 'Niger'), array('id' => 'NG', 'name' => 'Nigeria'), array('id' => 'NU', 'name' => 'Niue'), array('id' => 'NF', 'name' => 'Norfolk Island'), array('id' => 'MP', 'name' => 'Northern Mariana Islands'), array('id' => 'NO', 'name' => 'Norway'), array('id' => 'OM', 'name' => 'Oman'), array('id' => 'PK', 'name' => 'Pakistan'), array('id' => 'PW', 'name' => 'Palau'), array('id' => 'PS', 'name' => 'Palestinian Territory, Occupied'), array('id' => 'PA', 'name' => 'Panama'), array('id' => 'PG', 'name' => 'Papua New Guinea'), array('id' => 'PY', 'name' => 'Paraguay'), array('id' => 'PE', 'name' => 'Peru'), array('id' => 'PH', 'name' => 'Philippines'), array('id' => 'PN', 'name' => 'Pitcairn'), array('id' => 'PL', 'name' => 'Poland'), array('id' => 'PT', 'name' => 'Portugal'), array('id' => 'PR', 'name' => 'Puerto Rico'), array('id' => 'QA', 'name' => 'Qatar'), array('id' => 'RE', 'name' => 'Reunion'), array('id' => 'RO', 'name' => 'Romania'), array('id' => 'RU', 'name' => 'Russian Federation'), array('id' => 'RW', 'name' => 'Rwanda'), array('id' => 'BL', 'name' => 'Saint Barthelemy'), array('id' => 'SH', 'name' => 'Saint Helena'), array('id' => 'KN', 'name' => 'Saint Kitts And Nevis'), array('id' => 'LC', 'name' => 'Saint Lucia'), array('id' => 'MF', 'name' => 'Saint Martin'), array('id' => 'PM', 'name' => 'Saint Pierre And Miquelon'), array('id' => 'VC', 'name' => 'Saint Vincent And Grenadines'), array('id' => 'WS', 'name' => 'Samoa'), array('id' => 'SM', 'name' => 'San Marino'), array('id' => 'ST', 'name' => 'Sao Tome And Principe'), array('id' => 'SA', 'name' => 'Saudi Arabia'), array('id' => 'SN', 'name' => 'Senegal'), array('id' => 'RS', 'name' => 'Serbia'), array('id' => 'SC', 'name' => 'Seychelles'), array('id' => 'SL', 'name' => 'Sierra Leone'), array('id' => 'SG', 'name' => 'Singapore'), array('id' => 'SK', 'name' => 'Slovakia'), array('id' => 'SI', 'name' => 'Slovenia'), array('id' => 'SB', 'name' => 'Solomon Islands'), array('id' => 'SO', 'name' => 'Somalia'), array('id' => 'ZA', 'name' => 'South Africa'), array('id' => 'GS', 'name' => 'South Georgia And Sandwich Isl.'), array('id' => 'ES', 'name' => 'Spain'), array('id' => 'LK', 'name' => 'Sri Lanka'), array('id' => 'SD', 'name' => 'Sudan'), array('id' => 'SR', 'name' => 'Suriname'), array('id' => 'SJ', 'name' => 'Svalbard And Jan Mayen'), array('id' => 'SZ', 'name' => 'Swaziland'), array('id' => 'SE', 'name' => 'Sweden'), array('id' => 'CH', 'name' => 'Switzerland'), array('id' => 'SY', 'name' => 'Syrian Arab Republic'), array('id' => 'TW', 'name' => 'Taiwan'), array('id' => 'TJ', 'name' => 'Tajikistan'), array('id' => 'TZ', 'name' => 'Tanzania'), array('id' => 'TH', 'name' => 'Thailand'), array('id' => 'TL', 'name' => 'Timor-Leste'), array('id' => 'TG', 'name' => 'Togo'), array('id' => 'TK', 'name' => 'Tokelau'), array('id' => 'TO', 'name' => 'Tonga'), array('id' => 'TT', 'name' => 'Trinidad And Tobago'), array('id' => 'TN', 'name' => 'Tunisia'), array('id' => 'TR', 'name' => 'Turkey'), array('id' => 'TM', 'name' => 'Turkmenistan'), array('id' => 'TC', 'name' => 'Turks And Caicos Islands'), array('id' => 'TV', 'name' => 'Tuvalu'), array('id' => 'UG', 'name' => 'Uganda'), array('id' => 'UA', 'name' => 'Ukraine'), array('id' => 'AE', 'name' => 'United Arab Emirates'), array('id' => 'GB', 'name' => 'United Kingdom'), array('id' => 'US', 'name' => 'United States'), array('id' => 'UM', 'name' => 'United States Outlying Islands'), array('id' => 'UY', 'name' => 'Uruguay'), array('id' => 'UZ', 'name' => 'Uzbekistan'), array('id' => 'VU', 'name' => 'Vanuatu'), array('id' => 'VE', 'name' => 'Venezuela'), array('id' => 'VN', 'name' => 'Viet Nam'), array('id' => 'VG', 'name' => 'Virgin Islands, British'), array('id' => 'VI', 'name' => 'Virgin Islands, U.S.'), array('id' => 'WF', 'name' => 'Wallis And Futuna'), array('id' => 'EH', 'name' => 'Western Sahara'), array('id' => 'YE', 'name' => 'Yemen'), array('id' => 'ZM', 'name' => 'Zambia'), array('id' => 'ZW', 'name' => 'Zimbabwe'));
	$C6795112182c127d = array('ALL' => 'All Countries', 'A1' => 'Anonymous Proxy', 'A2' => 'Satellite Provider', 'O1' => 'Other Country', 'AF' => 'Afghanistan', 'AX' => 'Aland Islands', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua And Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia', 'BA' => 'Bosnia And Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'CV' => 'Cape Verde', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CG' => 'Congo', 'CD' => 'Congo, Democratic Republic', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'CI' => "Cote D'Ivoire", 'HR' => 'Croatia', 'CU' => 'Cuba', 'CY' => 'Cyprus', 'CZ' => 'Czech Republic', 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands (Malvinas)', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'MK' => 'Fyrom', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island & Mcdonald Islands', 'VA' => 'Holy See (Vatican City State)', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran, Islamic Republic Of', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle Of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KR' => 'Korea', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => "Lao People's Democratic Republic", 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libyan Arab Jamahiriya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia, Federated States Of', 'MD' => 'Moldova', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'AN' => 'Netherlands Antilles', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestinian Territory, Occupied', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'RE' => 'Reunion', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'BL' => 'Saint Barthelemy', 'SH' => 'Saint Helena', 'KN' => 'Saint Kitts And Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin', 'PM' => 'Saint Pierre And Miquelon', 'VC' => 'Saint Vincent And Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome And Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia And Sandwich Isl.', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard And Jan Mayen', 'SZ' => 'Swaziland', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad And Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks And Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'US' => 'United States', 'UM' => 'United States Outlying Islands', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands, British', 'VI' => 'Virgin Islands, U.S.', 'WF' => 'Wallis And Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe');
	$a0bf9d3bd74d9b1f = array('' => 'Default', 'primary' => 'Blue', 'info' => 'Light Blue', 'success' => 'Green', 'danger' => 'Red', 'warning' => 'Orange', 'purple' => 'Purple', 'pink' => 'Pink', 'dark' => 'Dark Grey', 'secondary' => 'Light Grey');
	$b2894c436f8a0966 = array('' => 'Default - EN', 'aa' => 'Afar', 'af' => 'Afrikaans', 'ak' => 'Akan', 'an' => 'Aragonese', 'as' => 'Assamese', 'av' => 'Avaric', 'ae' => 'Avestan', 'ay' => 'Aymara', 'az' => 'Azerbaijani', 'ba' => 'Bashkir', 'bm' => 'Bambara', 'bi' => 'Bislama', 'bo' => 'Tibetan', 'br' => 'Breton', 'ca' => 'Catalan', 'cs' => 'Czech', 'ce' => 'Chechen', 'cu' => 'Slavic', 'cv' => 'Chuvash', 'kw' => 'Cornish', 'co' => 'Corsican', 'cr' => 'Cree', 'cy' => 'Welsh', 'da' => 'Danish', 'de' => 'German', 'dv' => 'Divehi', 'dz' => 'Dzongkha', 'eo' => 'Esperanto', 'et' => 'Estonian', 'eu' => 'Basque', 'fo' => 'Faroese', 'fj' => 'Fijian', 'fi' => 'Finnish', 'fr' => 'French', 'fy' => 'Frisian', 'ff' => 'Fulah', 'gd' => 'Gaelic', 'ga' => 'Irish', 'gl' => 'Galician', 'gv' => 'Manx', 'gn' => 'Guarani', 'gu' => 'Gujarati', 'ht' => 'Haitian', 'ha' => 'Hausa', 'sh' => 'Serbo-Croatian', 'hz' => 'Herero', 'ho' => 'Hiri Motu', 'hr' => 'Croatian', 'hu' => 'Hungarian', 'ig' => 'Igbo', 'io' => 'Ido', 'ii' => 'Yi', 'iu' => 'Inuktitut', 'ie' => 'Interlingue', 'ia' => 'Interlingua', 'id' => 'Indonesian', 'ik' => 'Inupiaq', 'is' => 'Icelandic', 'it' => 'Italian', 'ja' => 'Japanese', 'kl' => 'Kalaallisut', 'kn' => 'Kannada', 'ks' => 'Kashmiri', 'kr' => 'Kanuri', 'kk' => 'Kazakh', 'km' => 'Khmer', 'ki' => 'Kikuyu', 'rw' => 'Kinyarwanda', 'ky' => 'Kirghiz', 'kv' => 'Komi', 'kg' => 'Kongo', 'ko' => 'Korean', 'kj' => 'Kuanyama', 'ku' => 'Kurdish', 'lo' => 'Lao', 'la' => 'Latin', 'lv' => 'Latvian', 'li' => 'Limburgish', 'ln' => 'Lingala', 'lt' => 'Lithuanian', 'lb' => 'Letzeburgesch', 'lu' => 'Luba-Katanga', 'lg' => 'Ganda', 'mh' => 'Marshall', 'ml' => 'Malayalam', 'mr' => 'Marathi', 'mg' => 'Malagasy', 'mt' => 'Maltese', 'mo' => 'Moldavian', 'mn' => 'Mongolian', 'mi' => 'Maori', 'ms' => 'Malay', 'my' => 'Burmese', 'na' => 'Nauru', 'nv' => 'Navajo', 'nr' => 'Ndebele', 'nd' => 'Ndebele', 'ng' => 'Ndonga', 'ne' => 'Nepali', 'nl' => 'Dutch', 'nn' => 'Norwegian Nynorsk', 'nb' => 'Norwegian Bokmal', 'no' => 'Norwegian', 'ny' => 'Chichewa', 'oc' => 'Occitan', 'oj' => 'Ojibwa', 'or' => 'Oriya', 'om' => 'Oromo', 'os' => 'Ossetian; Ossetic', 'pi' => 'Pali', 'pl' => 'Polish', 'pt' => 'Portuguese', 'pt-BR' => 'Portuguese - Brazil', 'qu' => 'Quechua', 'rm' => 'Raeto-Romance', 'ro' => 'Romanian', 'rn' => 'Rundi', 'ru' => 'Russian', 'sg' => 'Sango', 'sa' => 'Sanskrit', 'si' => 'Sinhalese', 'sk' => 'Slovak', 'sl' => 'Slovenian', 'se' => 'Northern Sami', 'sm' => 'Samoan', 'sn' => 'Shona', 'sd' => 'Sindhi', 'so' => 'Somali', 'st' => 'Sotho', 'es' => 'Spanish', 'sq' => 'Albanian', 'sc' => 'Sardinian', 'sr' => 'Serbian', 'ss' => 'Swati', 'su' => 'Sundanese', 'sw' => 'Swahili', 'sv' => 'Swedish', 'ty' => 'Tahitian', 'ta' => 'Tamil', 'tt' => 'Tatar', 'te' => 'Telugu', 'tg' => 'Tajik', 'tl' => 'Tagalog', 'th' => 'Thai', 'ti' => 'Tigrinya', 'to' => 'Tonga', 'tn' => 'Tswana', 'ts' => 'Tsonga', 'tk' => 'Turkmen', 'tr' => 'Turkish', 'tw' => 'Twi', 'ug' => 'Uighur', 'uk' => 'Ukrainian', 'ur' => 'Urdu', 'uz' => 'Uzbek', 've' => 'Venda', 'vi' => 'Vietnamese', 'vo' => 'Volapük', 'wa' => 'Walloon', 'wo' => 'Wolof', 'xh' => 'Xhosa', 'yi' => 'Yiddish', 'za' => 'Zhuang', 'zu' => 'Zulu', 'ab' => 'Abkhazian', 'zh' => 'Mandarin', 'ps' => 'Pushto', 'am' => 'Amharic', 'ar' => 'Arabic', 'bg' => 'Bulgarian', 'cn' => 'Cantonese', 'mk' => 'Macedonian', 'el' => 'Greek', 'fa' => 'Persian', 'he' => 'Hebrew', 'hi' => 'Hindi', 'hy' => 'Armenian', 'en' => 'English', 'ee' => 'Ewe', 'ka' => 'Georgian', 'pa' => 'Punjabi', 'bn' => 'Bengali', 'bs' => 'Bosnian', 'ch' => 'Chamorro', 'be' => 'Belarusian', 'yo' => 'Yoruba');
	$b8b5bf746554990b = array('Africa/Abidjan' => 'Africa/Abidjan [GMT  00:00]', 'Africa/Accra' => 'Africa/Accra [GMT  00:00]', 'Africa/Addis_Ababa' => 'Africa/Addis_Ababa [EAT +03:00]', 'Africa/Algiers' => 'Africa/Algiers [CET +01:00]', 'Africa/Asmara' => 'Africa/Asmara [EAT +03:00]', 'Africa/Bamako' => 'Africa/Bamako [GMT  00:00]', 'Africa/Bangui' => 'Africa/Bangui [WAT +01:00]', 'Africa/Banjul' => 'Africa/Banjul [GMT  00:00]', 'Africa/Bissau' => 'Africa/Bissau [GMT  00:00]', 'Africa/Blantyre' => 'Africa/Blantyre [CAT +02:00]', 'Africa/Brazzaville' => 'Africa/Brazzaville [WAT +01:00]', 'Africa/Bujumbura' => 'Africa/Bujumbura [CAT +02:00]', 'Africa/Cairo' => 'Africa/Cairo [EET +02:00]', 'Africa/Casablanca' => 'Africa/Casablanca [WEST +01:00]', 'Africa/Ceuta' => 'Africa/Ceuta [CEST +02:00]', 'Africa/Conakry' => 'Africa/Conakry [GMT  00:00]', 'Africa/Dakar' => 'Africa/Dakar [GMT  00:00]', 'Africa/Dar_es_Salaam' => 'Africa/Dar_es_Salaam [EAT +03:00]', 'Africa/Djibouti' => 'Africa/Djibouti [EAT +03:00]', 'Africa/Douala' => 'Africa/Douala [WAT +01:00]', 'Africa/El_Aaiun' => 'Africa/El_Aaiun [WEST +01:00]', 'Africa/Freetown' => 'Africa/Freetown [GMT  00:00]', 'Africa/Gaborone' => 'Africa/Gaborone [CAT +02:00]', 'Africa/Harare' => 'Africa/Harare [CAT +02:00]', 'Africa/Johannesburg' => 'Africa/Johannesburg [SAST +02:00]', 'Africa/Juba' => 'Africa/Juba [EAT +03:00]', 'Africa/Kampala' => 'Africa/Kampala [EAT +03:00]', 'Africa/Khartoum' => 'Africa/Khartoum [EAT +03:00]', 'Africa/Kigali' => 'Africa/Kigali [CAT +02:00]', 'Africa/Kinshasa' => 'Africa/Kinshasa [WAT +01:00]', 'Africa/Lagos' => 'Africa/Lagos [WAT +01:00]', 'Africa/Libreville' => 'Africa/Libreville [WAT +01:00]', 'Africa/Lome' => 'Africa/Lome [GMT  00:00]', 'Africa/Luanda' => 'Africa/Luanda [WAT +01:00]', 'Africa/Lubumbashi' => 'Africa/Lubumbashi [CAT +02:00]', 'Africa/Lusaka' => 'Africa/Lusaka [CAT +02:00]', 'Africa/Malabo' => 'Africa/Malabo [WAT +01:00]', 'Africa/Maputo' => 'Africa/Maputo [CAT +02:00]', 'Africa/Maseru' => 'Africa/Maseru [SAST +02:00]', 'Africa/Mbabane' => 'Africa/Mbabane [SAST +02:00]', 'Africa/Mogadishu' => 'Africa/Mogadishu [EAT +03:00]', 'Africa/Monrovia' => 'Africa/Monrovia [GMT  00:00]', 'Africa/Nairobi' => 'Africa/Nairobi [EAT +03:00]', 'Africa/Ndjamena' => 'Africa/Ndjamena [WAT +01:00]', 'Africa/Niamey' => 'Africa/Niamey [WAT +01:00]', 'Africa/Nouakchott' => 'Africa/Nouakchott [GMT  00:00]', 'Africa/Ouagadougou' => 'Africa/Ouagadougou [GMT  00:00]', 'Africa/Porto-Novo' => 'Africa/Porto-Novo [WAT +01:00]', 'Africa/Sao_Tome' => 'Africa/Sao_Tome [GMT  00:00]', 'Africa/Tripoli' => 'Africa/Tripoli [EET +02:00]', 'Africa/Tunis' => 'Africa/Tunis [CET +01:00]', 'Africa/Windhoek' => 'Africa/Windhoek [WAST +02:00]', 'America/Adak' => 'America/Adak [HADT -09:00]', 'America/Anchorage' => 'America/Anchorage [AKDT -08:00]', 'America/Anguilla' => 'America/Anguilla [AST -04:00]', 'America/Antigua' => 'America/Antigua [AST -04:00]', 'America/Araguaina' => 'America/Araguaina [BRT -03:00]', 'America/Argentina/Buenos_Aires' => 'America/Argentina/Buenos_Aires [ART -03:00]', 'America/Argentina/Catamarca' => 'America/Argentina/Catamarca [ART -03:00]', 'America/Argentina/Cordoba' => 'America/Argentina/Cordoba [ART -03:00]', 'America/Argentina/Jujuy' => 'America/Argentina/Jujuy [ART -03:00]', 'America/Argentina/La_Rioja' => 'America/Argentina/La_Rioja [ART -03:00]', 'America/Argentina/Mendoza' => 'America/Argentina/Mendoza [ART -03:00]', 'America/Argentina/Rio_Gallegos' => 'America/Argentina/Rio_Gallegos [ART -03:00]', 'America/Argentina/Salta' => 'America/Argentina/Salta [ART -03:00]', 'America/Argentina/San_Juan' => 'America/Argentina/San_Juan [ART -03:00]', 'America/Argentina/San_Luis' => 'America/Argentina/San_Luis [ART -03:00]', 'America/Argentina/Tucuman' => 'America/Argentina/Tucuman [ART -03:00]', 'America/Argentina/Ushuaia' => 'America/Argentina/Ushuaia [ART -03:00]', 'America/Aruba' => 'America/Aruba [AST -04:00]', 'America/Asuncion' => 'America/Asuncion [PYT -04:00]', 'America/Atikokan' => 'America/Atikokan [EST -05:00]', 'America/Bahia' => 'America/Bahia [BRT -03:00]', 'America/Bahia_Banderas' => 'America/Bahia_Banderas [CDT -05:00]', 'America/Barbados' => 'America/Barbados [AST -04:00]', 'America/Belem' => 'America/Belem [BRT -03:00]', 'America/Belize' => 'America/Belize [CST -06:00]', 'America/Blanc-Sablon' => 'America/Blanc-Sablon [AST -04:00]', 'America/Boa_Vista' => 'America/Boa_Vista [AMT -04:00]', 'America/Bogota' => 'America/Bogota [COT -05:00]', 'America/Boise' => 'America/Boise [MDT -06:00]', 'America/Cambridge_Bay' => 'America/Cambridge_Bay [MDT -06:00]', 'America/Campo_Grande' => 'America/Campo_Grande [AMT -04:00]', 'America/Cancun' => 'America/Cancun [CDT -05:00]', 'America/Caracas' => 'America/Caracas [VET -04:30]', 'America/Cayenne' => 'America/Cayenne [GFT -03:00]', 'America/Cayman' => 'America/Cayman [EST -05:00]', 'America/Chicago' => 'America/Chicago [CDT -05:00]', 'America/Chihuahua' => 'America/Chihuahua [MDT -06:00]', 'America/Costa_Rica' => 'America/Costa_Rica [CST -06:00]', 'America/Creston' => 'America/Creston [MST -07:00]', 'America/Cuiaba' => 'America/Cuiaba [AMT -04:00]', 'America/Curacao' => 'America/Curacao [AST -04:00]', 'America/Danmarkshavn' => 'America/Danmarkshavn [GMT  00:00]', 'America/Dawson' => 'America/Dawson [PDT -07:00]', 'America/Dawson_Creek' => 'America/Dawson_Creek [MST -07:00]', 'America/Denver' => 'America/Denver [MDT -06:00]', 'America/Detroit' => 'America/Detroit [EDT -04:00]', 'America/Dominica' => 'America/Dominica [AST -04:00]', 'America/Edmonton' => 'America/Edmonton [MDT -06:00]', 'America/Eirunepe' => 'America/Eirunepe [ACT -05:00]', 'America/El_Salvador' => 'America/El_Salvador [CST -06:00]', 'America/Fortaleza' => 'America/Fortaleza [BRT -03:00]', 'America/Glace_Bay' => 'America/Glace_Bay [ADT -03:00]', 'America/Godthab' => 'America/Godthab [WGST -02:00]', 'America/Goose_Bay' => 'America/Goose_Bay [ADT -03:00]', 'America/Grand_Turk' => 'America/Grand_Turk [AST -04:00]', 'America/Grenada' => 'America/Grenada [AST -04:00]', 'America/Guadeloupe' => 'America/Guadeloupe [AST -04:00]', 'America/Guatemala' => 'America/Guatemala [CST -06:00]', 'America/Guayaquil' => 'America/Guayaquil [ECT -05:00]', 'America/Guyana' => 'America/Guyana [GYT -04:00]', 'America/Halifax' => 'America/Halifax [ADT -03:00]', 'America/Havana' => 'America/Havana [CDT -04:00]', 'America/Hermosillo' => 'America/Hermosillo [MST -07:00]', 'America/Indiana/Indianapolis' => 'America/Indiana/Indianapolis [EDT -04:00]', 'America/Indiana/Knox' => 'America/Indiana/Knox [CDT -05:00]', 'America/Indiana/Marengo' => 'America/Indiana/Marengo [EDT -04:00]', 'America/Indiana/Petersburg' => 'America/Indiana/Petersburg [EDT -04:00]', 'America/Indiana/Tell_City' => 'America/Indiana/Tell_City [CDT -05:00]', 'America/Indiana/Vevay' => 'America/Indiana/Vevay [EDT -04:00]', 'America/Indiana/Vincennes' => 'America/Indiana/Vincennes [EDT -04:00]', 'America/Indiana/Winamac' => 'America/Indiana/Winamac [EDT -04:00]', 'America/Inuvik' => 'America/Inuvik [MDT -06:00]', 'America/Iqaluit' => 'America/Iqaluit [EDT -04:00]', 'America/Jamaica' => 'America/Jamaica [EST -05:00]', 'America/Juneau' => 'America/Juneau [AKDT -08:00]', 'America/Kentucky/Louisville' => 'America/Kentucky/Louisville [EDT -04:00]', 'America/Kentucky/Monticello' => 'America/Kentucky/Monticello [EDT -04:00]', 'America/Kralendijk' => 'America/Kralendijk [AST -04:00]', 'America/La_Paz' => 'America/La_Paz [BOT -04:00]', 'America/Lima' => 'America/Lima [PET -05:00]', 'America/Los_Angeles' => 'America/Los_Angeles [PDT -07:00]', 'America/Lower_Princes' => 'America/Lower_Princes [AST -04:00]', 'America/Maceio' => 'America/Maceio [BRT -03:00]', 'America/Managua' => 'America/Managua [CST -06:00]', 'America/Manaus' => 'America/Manaus [AMT -04:00]', 'America/Marigot' => 'America/Marigot [AST -04:00]', 'America/Martinique' => 'America/Martinique [AST -04:00]', 'America/Matamoros' => 'America/Matamoros [CDT -05:00]', 'America/Mazatlan' => 'America/Mazatlan [MDT -06:00]', 'America/Menominee' => 'America/Menominee [CDT -05:00]', 'America/Merida' => 'America/Merida [CDT -05:00]', 'America/Metlakatla' => 'America/Metlakatla [PST -08:00]', 'America/Mexico_City' => 'America/Mexico_City [CDT -05:00]', 'America/Miquelon' => 'America/Miquelon [PMDT -02:00]', 'America/Moncton' => 'America/Moncton [ADT -03:00]', 'America/Monterrey' => 'America/Monterrey [CDT -05:00]', 'America/Montevideo' => 'America/Montevideo [UYT -03:00]', 'America/Montserrat' => 'America/Montserrat [AST -04:00]', 'America/Nassau' => 'America/Nassau [EDT -04:00]', 'America/New_York' => 'America/New_York [EDT -04:00]', 'America/Nipigon' => 'America/Nipigon [EDT -04:00]', 'America/Nome' => 'America/Nome [AKDT -08:00]', 'America/Noronha' => 'America/Noronha [FNT -02:00]', 'America/North_Dakota/Beulah' => 'America/North_Dakota/Beulah [CDT -05:00]', 'America/North_Dakota/Center' => 'America/North_Dakota/Center [CDT -05:00]', 'America/North_Dakota/New_Salem' => 'America/North_Dakota/New_Salem [CDT -05:00]', 'America/Ojinaga' => 'America/Ojinaga [MDT -06:00]', 'America/Panama' => 'America/Panama [EST -05:00]', 'America/Pangnirtung' => 'America/Pangnirtung [EDT -04:00]', 'America/Paramaribo' => 'America/Paramaribo [SRT -03:00]', 'America/Phoenix' => 'America/Phoenix [MST -07:00]', 'America/Port-au-Prince' => 'America/Port-au-Prince [EDT -04:00]', 'America/Port_of_Spain' => 'America/Port_of_Spain [AST -04:00]', 'America/Porto_Velho' => 'America/Porto_Velho [AMT -04:00]', 'America/Puerto_Rico' => 'America/Puerto_Rico [AST -04:00]', 'America/Rainy_River' => 'America/Rainy_River [CDT -05:00]', 'America/Rankin_Inlet' => 'America/Rankin_Inlet [CDT -05:00]', 'America/Recife' => 'America/Recife [BRT -03:00]', 'America/Regina' => 'America/Regina [CST -06:00]', 'America/Resolute' => 'America/Resolute [CDT -05:00]', 'America/Rio_Branco' => 'America/Rio_Branco [ACT -05:00]', 'America/Santa_Isabel' => 'America/Santa_Isabel [PDT -07:00]', 'America/Santarem' => 'America/Santarem [BRT -03:00]', 'America/Santiago' => 'America/Santiago [CLST -03:00]', 'America/Santo_Domingo' => 'America/Santo_Domingo [AST -04:00]', 'America/Sao_Paulo' => 'America/Sao_Paulo [BRT -03:00]', 'America/Scoresbysund' => 'America/Scoresbysund [EGST  00:00]', 'America/Sitka' => 'America/Sitka [AKDT -08:00]', 'America/St_Barthelemy' => 'America/St_Barthelemy [AST -04:00]', 'America/St_Johns' => 'America/St_Johns [NDT -02:30]', 'America/St_Kitts' => 'America/St_Kitts [AST -04:00]', 'America/St_Lucia' => 'America/St_Lucia [AST -04:00]', 'America/St_Thomas' => 'America/St_Thomas [AST -04:00]', 'America/St_Vincent' => 'America/St_Vincent [AST -04:00]', 'America/Swift_Current' => 'America/Swift_Current [CST -06:00]', 'America/Tegucigalpa' => 'America/Tegucigalpa [CST -06:00]', 'America/Thule' => 'America/Thule [ADT -03:00]', 'America/Thunder_Bay' => 'America/Thunder_Bay [EDT -04:00]', 'America/Tijuana' => 'America/Tijuana [PDT -07:00]', 'America/Toronto' => 'America/Toronto [EDT -04:00]', 'America/Tortola' => 'America/Tortola [AST -04:00]', 'America/Vancouver' => 'America/Vancouver [PDT -07:00]', 'America/Whitehorse' => 'America/Whitehorse [PDT -07:00]', 'America/Winnipeg' => 'America/Winnipeg [CDT -05:00]', 'America/Yakutat' => 'America/Yakutat [AKDT -08:00]', 'America/Yellowknife' => 'America/Yellowknife [MDT -06:00]', 'Antarctica/Casey' => 'Antarctica/Casey [AWST +08:00]', 'Antarctica/Davis' => 'Antarctica/Davis [DAVT +07:00]', 'Antarctica/DumontDUrville' => 'Antarctica/DumontDUrville [DDUT +10:00]', 'Antarctica/Macquarie' => 'Antarctica/Macquarie [MIST +11:00]', 'Antarctica/Mawson' => 'Antarctica/Mawson [MAWT +05:00]', 'Antarctica/McMurdo' => 'Antarctica/McMurdo [NZDT +13:00]', 'Antarctica/Palmer' => 'Antarctica/Palmer [CLST -03:00]', 'Antarctica/Rothera' => 'Antarctica/Rothera [ROTT -03:00]', 'Antarctica/Syowa' => 'Antarctica/Syowa [SYOT +03:00]', 'Antarctica/Troll' => 'Antarctica/Troll [CEST +02:00]', 'Antarctica/Vostok' => 'Antarctica/Vostok [VOST +06:00]', 'Arctic/Longyearbyen' => 'Arctic/Longyearbyen [CEST +02:00]', 'Asia/Aden' => 'Asia/Aden [AST +03:00]', 'Asia/Almaty' => 'Asia/Almaty [ALMT +06:00]', 'Asia/Amman' => 'Asia/Amman [EEST +03:00]', 'Asia/Anadyr' => 'Asia/Anadyr [ANAT +12:00]', 'Asia/Aqtau' => 'Asia/Aqtau [AQTT +05:00]', 'Asia/Aqtobe' => 'Asia/Aqtobe [AQTT +05:00]', 'Asia/Ashgabat' => 'Asia/Ashgabat [TMT +05:00]', 'Asia/Baghdad' => 'Asia/Baghdad [AST +03:00]', 'Asia/Bahrain' => 'Asia/Bahrain [AST +03:00]', 'Asia/Baku' => 'Asia/Baku [AZST +05:00]', 'Asia/Bangkok' => 'Asia/Bangkok [ICT +07:00]', 'Asia/Beirut' => 'Asia/Beirut [EEST +03:00]', 'Asia/Bishkek' => 'Asia/Bishkek [KGT +06:00]', 'Asia/Brunei' => 'Asia/Brunei [BNT +08:00]', 'Asia/Chita' => 'Asia/Chita [IRKT +08:00]', 'Asia/Choibalsan' => 'Asia/Choibalsan [CHOT +08:00]', 'Asia/Colombo' => 'Asia/Colombo [IST +05:30]', 'Asia/Damascus' => 'Asia/Damascus [EEST +03:00]', 'Asia/Dhaka' => 'Asia/Dhaka [BDT +06:00]', 'Asia/Dili' => 'Asia/Dili [TLT +09:00]', 'Asia/Dubai' => 'Asia/Dubai [GST +04:00]', 'Asia/Dushanbe' => 'Asia/Dushanbe [TJT +05:00]', 'Asia/Gaza' => 'Asia/Gaza [EET +02:00]', 'Asia/Hebron' => 'Asia/Hebron [EET +02:00]', 'Asia/Ho_Chi_Minh' => 'Asia/Ho_Chi_Minh [ICT +07:00]', 'Asia/Hong_Kong' => 'Asia/Hong_Kong [HKT +08:00]', 'Asia/Hovd' => 'Asia/Hovd [HOVT +07:00]', 'Asia/Irkutsk' => 'Asia/Irkutsk [IRKT +08:00]', 'Asia/Jakarta' => 'Asia/Jakarta [WIB +07:00]', 'Asia/Jayapura' => 'Asia/Jayapura [WIT +09:00]', 'Asia/Jerusalem' => 'Asia/Jerusalem [IDT +03:00]', 'Asia/Kabul' => 'Asia/Kabul [AFT +04:30]', 'Asia/Kamchatka' => 'Asia/Kamchatka [PETT +12:00]', 'Asia/Karachi' => 'Asia/Karachi [PKT +05:00]', 'Asia/Kathmandu' => 'Asia/Kathmandu [NPT +05:45]', 'Asia/Khandyga' => 'Asia/Khandyga [YAKT +09:00]', 'Asia/Kolkata' => 'Asia/Kolkata [IST +05:30]', 'Asia/Krasnoyarsk' => 'Asia/Krasnoyarsk [KRAT +07:00]', 'Asia/Kuala_Lumpur' => 'Asia/Kuala_Lumpur [MYT +08:00]', 'Asia/Kuching' => 'Asia/Kuching [MYT +08:00]', 'Asia/Kuwait' => 'Asia/Kuwait [AST +03:00]', 'Asia/Macau' => 'Asia/Macau [CST +08:00]', 'Asia/Magadan' => 'Asia/Magadan [MAGT +10:00]', 'Asia/Makassar' => 'Asia/Makassar [WITA +08:00]', 'Asia/Manila' => 'Asia/Manila [PHT +08:00]', 'Asia/Muscat' => 'Asia/Muscat [GST +04:00]', 'Asia/Nicosia' => 'Asia/Nicosia [EEST +03:00]', 'Asia/Novokuznetsk' => 'Asia/Novokuznetsk [KRAT +07:00]', 'Asia/Novosibirsk' => 'Asia/Novosibirsk [NOVT +06:00]', 'Asia/Omsk' => 'Asia/Omsk [OMST +06:00]', 'Asia/Oral' => 'Asia/Oral [ORAT +05:00]', 'Asia/Phnom_Penh' => 'Asia/Phnom_Penh [ICT +07:00]', 'Asia/Pontianak' => 'Asia/Pontianak [WIB +07:00]', 'Asia/Pyongyang' => 'Asia/Pyongyang [KST +09:00]', 'Asia/Qatar' => 'Asia/Qatar [AST +03:00]', 'Asia/Qyzylorda' => 'Asia/Qyzylorda [QYZT +06:00]', 'Asia/Rangoon' => 'Asia/Rangoon [MMT +06:30]', 'Asia/Riyadh' => 'Asia/Riyadh [AST +03:00]', 'Asia/Sakhalin' => 'Asia/Sakhalin [SAKT +10:00]', 'Asia/Samarkand' => 'Asia/Samarkand [UZT +05:00]', 'Asia/Seoul' => 'Asia/Seoul [KST +09:00]', 'Asia/Shanghai' => 'Asia/Shanghai [CST +08:00]', 'Asia/Singapore' => 'Asia/Singapore [SGT +08:00]', 'Asia/Srednekolymsk' => 'Asia/Srednekolymsk [SRET +11:00]', 'Asia/Taipei' => 'Asia/Taipei [CST +08:00]', 'Asia/Tashkent' => 'Asia/Tashkent [UZT +05:00]', 'Asia/Tbilisi' => 'Asia/Tbilisi [GET +04:00]', 'Asia/Tehran' => 'Asia/Tehran [IRST +03:30]', 'Asia/Thimphu' => 'Asia/Thimphu [BTT +06:00]', 'Asia/Tokyo' => 'Asia/Tokyo [JST +09:00]', 'Asia/Ulaanbaatar' => 'Asia/Ulaanbaatar [ULAT +08:00]', 'Asia/Urumqi' => 'Asia/Urumqi [XJT +06:00]', 'Asia/Ust-Nera' => 'Asia/Ust-Nera [VLAT +10:00]', 'Asia/Vientiane' => 'Asia/Vientiane [ICT +07:00]', 'Asia/Vladivostok' => 'Asia/Vladivostok [VLAT +10:00]', 'Asia/Yakutsk' => 'Asia/Yakutsk [YAKT +09:00]', 'Asia/Yekaterinburg' => 'Asia/Yekaterinburg [YEKT +05:00]', 'Asia/Yerevan' => 'Asia/Yerevan [AMT +04:00]', 'Atlantic/Azores' => 'Atlantic/Azores [AZOST  00:00]', 'Atlantic/Bermuda' => 'Atlantic/Bermuda [ADT -03:00]', 'Atlantic/Canary' => 'Atlantic/Canary [WEST +01:00]', 'Atlantic/Cape_Verde' => 'Atlantic/Cape_Verde [CVT -01:00]', 'Atlantic/Faroe' => 'Atlantic/Faroe [WEST +01:00]', 'Atlantic/Madeira' => 'Atlantic/Madeira [WEST +01:00]', 'Atlantic/Reykjavik' => 'Atlantic/Reykjavik [GMT  00:00]', 'Atlantic/South_Georgia' => 'Atlantic/South_Georgia [GST -02:00]', 'Atlantic/St_Helena' => 'Atlantic/St_Helena [GMT  00:00]', 'Atlantic/Stanley' => 'Atlantic/Stanley [FKST -03:00]', 'Australia/Adelaide' => 'Australia/Adelaide [ACDT +10:30]', 'Australia/Brisbane' => 'Australia/Brisbane [AEST +10:00]', 'Australia/Broken_Hill' => 'Australia/Broken_Hill [ACDT +10:30]', 'Australia/Currie' => 'Australia/Currie [AEDT +11:00]', 'Australia/Darwin' => 'Australia/Darwin [ACST +09:30]', 'Australia/Eucla' => 'Australia/Eucla [ACWST +08:45]', 'Australia/Hobart' => 'Australia/Hobart [AEDT +11:00]', 'Australia/Lindeman' => 'Australia/Lindeman [AEST +10:00]', 'Australia/Lord_Howe' => 'Australia/Lord_Howe [LHDT +11:00]', 'Australia/Melbourne' => 'Australia/Melbourne [AEDT +11:00]', 'Australia/Perth' => 'Australia/Perth [AWST +08:00]', 'Australia/Sydney' => 'Australia/Sydney [AEDT +11:00]', 'Europe/Amsterdam' => 'Europe/Amsterdam [CEST +02:00]', 'Europe/Andorra' => 'Europe/Andorra [CEST +02:00]', 'Europe/Athens' => 'Europe/Athens [EEST +03:00]', 'Europe/Belgrade' => 'Europe/Belgrade [CEST +02:00]', 'Europe/Berlin' => 'Europe/Berlin [CEST +02:00]', 'Europe/Bratislava' => 'Europe/Bratislava [CEST +02:00]', 'Europe/Brussels' => 'Europe/Brussels [CEST +02:00]', 'Europe/Bucharest' => 'Europe/Bucharest [EEST +03:00]', 'Europe/Budapest' => 'Europe/Budapest [CEST +02:00]', 'Europe/Busingen' => 'Europe/Busingen [CEST +02:00]', 'Europe/Chisinau' => 'Europe/Chisinau [EEST +03:00]', 'Europe/Copenhagen' => 'Europe/Copenhagen [CEST +02:00]', 'Europe/Dublin' => 'Europe/Dublin [IST +01:00]', 'Europe/Gibraltar' => 'Europe/Gibraltar [CEST +02:00]', 'Europe/Guernsey' => 'Europe/Guernsey [BST +01:00]', 'Europe/Helsinki' => 'Europe/Helsinki [EEST +03:00]', 'Europe/Isle_of_Man' => 'Europe/Isle_of_Man [BST +01:00]', 'Europe/Istanbul' => 'Europe/Istanbul [EEST +03:00]', 'Europe/Jersey' => 'Europe/Jersey [BST +01:00]', 'Europe/Kaliningrad' => 'Europe/Kaliningrad [EET +02:00]', 'Europe/Kiev' => 'Europe/Kiev [EEST +03:00]', 'Europe/Lisbon' => 'Europe/Lisbon [WEST +01:00]', 'Europe/Ljubljana' => 'Europe/Ljubljana [CEST +02:00]', 'Europe/London' => 'Europe/London [BST +01:00]', 'Europe/Luxembourg' => 'Europe/Luxembourg [CEST +02:00]', 'Europe/Madrid' => 'Europe/Madrid [CEST +02:00]', 'Europe/Malta' => 'Europe/Malta [CEST +02:00]', 'Europe/Mariehamn' => 'Europe/Mariehamn [EEST +03:00]', 'Europe/Minsk' => 'Europe/Minsk [MSK +03:00]', 'Europe/Monaco' => 'Europe/Monaco [CEST +02:00]', 'Europe/Moscow' => 'Europe/Moscow [MSK +03:00]', 'Europe/Oslo' => 'Europe/Oslo [CEST +02:00]', 'Europe/Paris' => 'Europe/Paris [CEST +02:00]', 'Europe/Podgorica' => 'Europe/Podgorica [CEST +02:00]', 'Europe/Prague' => 'Europe/Prague [CEST +02:00]', 'Europe/Riga' => 'Europe/Riga [EEST +03:00]', 'Europe/Rome' => 'Europe/Rome [CEST +02:00]', 'Europe/Samara' => 'Europe/Samara [SAMT +04:00]', 'Europe/San_Marino' => 'Europe/San_Marino [CEST +02:00]', 'Europe/Sarajevo' => 'Europe/Sarajevo [CEST +02:00]', 'Europe/Simferopol' => 'Europe/Simferopol [MSK +03:00]', 'Europe/Skopje' => 'Europe/Skopje [CEST +02:00]', 'Europe/Sofia' => 'Europe/Sofia [EEST +03:00]', 'Europe/Stockholm' => 'Europe/Stockholm [CEST +02:00]', 'Europe/Tallinn' => 'Europe/Tallinn [EEST +03:00]', 'Europe/Tirane' => 'Europe/Tirane [CEST +02:00]', 'Europe/Uzhgorod' => 'Europe/Uzhgorod [EEST +03:00]', 'Europe/Vaduz' => 'Europe/Vaduz [CEST +02:00]', 'Europe/Vatican' => 'Europe/Vatican [CEST +02:00]', 'Europe/Vienna' => 'Europe/Vienna [CEST +02:00]', 'Europe/Vilnius' => 'Europe/Vilnius [EEST +03:00]', 'Europe/Volgograd' => 'Europe/Volgograd [MSK +03:00]', 'Europe/Warsaw' => 'Europe/Warsaw [CEST +02:00]', 'Europe/Zagreb' => 'Europe/Zagreb [CEST +02:00]', 'Europe/Zaporozhye' => 'Europe/Zaporozhye [EEST +03:00]', 'Europe/Zurich' => 'Europe/Zurich [CEST +02:00]', 'Indian/Antananarivo' => 'Indian/Antananarivo [EAT +03:00]', 'Indian/Chagos' => 'Indian/Chagos [IOT +06:00]', 'Indian/Christmas' => 'Indian/Christmas [CXT +07:00]', 'Indian/Cocos' => 'Indian/Cocos [CCT +06:30]', 'Indian/Comoro' => 'Indian/Comoro [EAT +03:00]', 'Indian/Kerguelen' => 'Indian/Kerguelen [TFT +05:00]', 'Indian/Mahe' => 'Indian/Mahe [SCT +04:00]', 'Indian/Maldives' => 'Indian/Maldives [MVT +05:00]', 'Indian/Mauritius' => 'Indian/Mauritius [MUT +04:00]', 'Indian/Mayotte' => 'Indian/Mayotte [EAT +03:00]', 'Indian/Reunion' => 'Indian/Reunion [RET +04:00]', 'Pacific/Apia' => 'Pacific/Apia [WSDT +14:00]', 'Pacific/Auckland' => 'Pacific/Auckland [NZDT +13:00]', 'Pacific/Bougainville' => 'Pacific/Bougainville [BST +11:00]', 'Pacific/Chatham' => 'Pacific/Chatham [CHADT +13:45]', 'Pacific/Chuuk' => 'Pacific/Chuuk [CHUT +10:00]', 'Pacific/Easter' => 'Pacific/Easter [EASST -05:00]', 'Pacific/Efate' => 'Pacific/Efate [VUT +11:00]', 'Pacific/Enderbury' => 'Pacific/Enderbury [PHOT +13:00]', 'Pacific/Fakaofo' => 'Pacific/Fakaofo [TKT +13:00]', 'Pacific/Fiji' => 'Pacific/Fiji [FJT +12:00]', 'Pacific/Funafuti' => 'Pacific/Funafuti [TVT +12:00]', 'Pacific/Galapagos' => 'Pacific/Galapagos [GALT -06:00]', 'Pacific/Gambier' => 'Pacific/Gambier [GAMT -09:00]', 'Pacific/Guadalcanal' => 'Pacific/Guadalcanal [SBT +11:00]', 'Pacific/Guam' => 'Pacific/Guam [ChST +10:00]', 'Pacific/Honolulu' => 'Pacific/Honolulu [HST -10:00]', 'Pacific/Johnston' => 'Pacific/Johnston [HST -10:00]', 'Pacific/Kiritimati' => 'Pacific/Kiritimati [LINT +14:00]', 'Pacific/Kosrae' => 'Pacific/Kosrae [KOST +11:00]', 'Pacific/Kwajalein' => 'Pacific/Kwajalein [MHT +12:00]', 'Pacific/Majuro' => 'Pacific/Majuro [MHT +12:00]', 'Pacific/Marquesas' => 'Pacific/Marquesas [MART -09:30]', 'Pacific/Midway' => 'Pacific/Midway [SST -11:00]', 'Pacific/Nauru' => 'Pacific/Nauru [NRT +12:00]', 'Pacific/Niue' => 'Pacific/Niue [NUT -11:00]', 'Pacific/Norfolk' => 'Pacific/Norfolk [NFT +11:30]', 'Pacific/Noumea' => 'Pacific/Noumea [NCT +11:00]', 'Pacific/Pago_Pago' => 'Pacific/Pago_Pago [SST -11:00]', 'Pacific/Palau' => 'Pacific/Palau [PWT +09:00]', 'Pacific/Pitcairn' => 'Pacific/Pitcairn [PST -08:00]', 'Pacific/Pohnpei' => 'Pacific/Pohnpei [PONT +11:00]', 'Pacific/Port_Moresby' => 'Pacific/Port_Moresby [PGT +10:00]', 'Pacific/Rarotonga' => 'Pacific/Rarotonga [CKT -10:00]', 'Pacific/Saipan' => 'Pacific/Saipan [ChST +10:00]', 'Pacific/Tahiti' => 'Pacific/Tahiti [TAHT -10:00]', 'Pacific/Tarawa' => 'Pacific/Tarawa [GILT +12:00]', 'Pacific/Tongatapu' => 'Pacific/Tongatapu [TOT +13:00]', 'Pacific/Wake' => 'Pacific/Wake [WAKT +12:00]', 'Pacific/Wallis' => 'Pacific/Wallis [WFT +12:00]', 'UTC' => 'UTC [UTC  00:00]');
	$a5ca433431d8f2f2 = array('new' => 'Create', 'extend' => 'Extend', 'convert' => 'Convert', 'edit' => 'Edit', 'enable' => 'Enable', 'disable' => 'Disable', 'delete' => 'Delete', 'send_event' => 'MAG Event', 'adjust_credits' => 'Adjust Credits');
	$b9d8a76ab5848022 = array('LB_TOKEN_INVALID' => 'Token Failure', 'NOT_IN_BOUQUET' => 'Not in Bouquet', 'BLOCKED_ASN' => 'Blocked ASN', 'ISP_LOCK_FAILED' => 'ISP Lock Failed', 'USER_DISALLOW_EXT' => 'Extension Disallowed', 'AUTH_FAILED' => 'Authentication Failed', 'USER_EXPIRED' => 'User Expired', 'USER_DISABLED' => 'User Disabled', 'USER_BAN' => 'User Banned', 'MAG_TOKEN_INVALID' => 'MAG Token Invalid', 'STALKER_CHANNEL_MISMATCH' => 'Stalker Channel Mismatch', 'STALKER_IP_MISMATCH' => 'Stalker IP Mismatch', 'STALKER_KEY_EXPIRED' => 'Stalker Key Expired', 'STALKER_DECRYPT_FAILED' => 'Stalker Decrypt Failed', 'EMPTY_UA' => 'Empty User-Agent', 'IP_BAN' => 'IP Banned', 'COUNTRY_DISALLOW' => 'Country Disallowed', 'USER_AGENT_BAN' => 'User-Agent Disallowed', 'USER_ALREADY_CONNECTED' => 'IP Limit Reached', 'RESTREAM_DETECT' => 'Restream Detected', 'PROXY_DETECT' => 'Proxy / VPN Detected', 'HOSTING_DETECT' => 'Hosting Server Detected', 'LINE_CREATE_FAIL' => 'Connection Failed', 'CONNECTION_LOOP' => 'Connection Loop', 'TOKEN_EXPIRED' => 'Token Expired', 'IP_MISMATCH' => 'IP Mismatch');
	$F8b5842eeedab682 = array(-1 => "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xl'>NO SERVERS</button>", 0 => "<button type='button' class='btn btn-dark btn-xs waves-effect waves-light btn-fixed-xl'>STOPPED</button>", 1 => "<button type='button' class='btn btn-success btn-xs waves-effect waves-light btn-fixed-xl'>ONLINE</button>", 2 => "<button type='button' class='btn btn-warning btn-xs waves-effect waves-light btn-fixed'>STARTING</button>", 3 => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light btn-fixed'>DOWN</button>", 4 => "<button type='button' class='btn btn-info btn-xs waves-effect waves-light btn-fixed-xl'>ON DEMAND</button>", 5 => "<button type='button' class='btn btn-purple btn-xs waves-effect waves-light btn-fixed-xl'>DIRECT SOURCE</button>", 6 => "<button type='button' class='btn btn-primary btn-xs waves-effect waves-light btn-fixed-xl'>CREATING...</button>", 7 => "<button type='button' class='btn btn-purple btn-xs waves-effect waves-light btn-fixed-xl'>DIRECT STREAM</button>");
	$Fb789833d0ff5a8b = array(-1 => "<button type='button' class='btn bg-animate-secondary btn-xs waves-effect waves-light no-border btn-fixed-xl'>NO SERVERS</button>", 0 => "<button type='button' class='btn bg-animate-dark btn-xs waves-effect waves-light no-border btn-fixed-xl'>STOPPED</button>", "<button type='button' class='btn bg-animate-warning btn-xs waves-effect waves-light no-border btn-fixed-xl'>STARTING</button>", "<button type='button' class='btn bg-animate-danger btn-xs waves-effect waves-light no-border btn-fixed-xl'>DOWN</button>", "<button type='button' class='btn bg-animate-success btn-xs waves-effect waves-light no-border btn-fixed-xl'>ON DEMAND</button>", "<button type='button' class='btn bg-animate-purple btn-xs waves-effect waves-light no-border btn-fixed-xl'>DIRECT</button>", 7 => "<button type='button' class='btn bg-animate-warning btn-xs waves-effect waves-light no-border btn-fixed-xl'>ENCODING</button>", 8 => "<button type='button' class='btn bg-animate-dark btn-xs waves-effect waves-light no-border btn-fixed-xl'>NOT ENCODED</button>", 9 => "<button type='button' class='btn bg-animate-info btn-xs waves-effect waves-light no-border btn-fixed-xl'>ENCODED</button>", 10 => "<button type='button' class='btn bg-animate-danger btn-xs waves-effect waves-light no-border btn-fixed-xl'>BROKEN</button>");
	$f45f1268c76ac2a3 = array(-1 => "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light tooltip' title='No Server Selected'><i class='text-white mdi mdi-triangle'></i></button>", 0 => "<button type='button' class='btn btn-dark btn-xs waves-effect waves-light tooltip' title='Not Encoded'><i class='text-white mdi mdi-checkbox-blank-circle'></i></button>", 1 => "<button type='button' class='btn btn-success btn-xs waves-effect waves-light tooltip' title='Encoded'><i class='text-white mdi mdi-check-circle'></i></button>", 2 => "<button type='button' class='btn btn-warning btn-xs waves-effect waves-light tooltip' title='Encoding'><i class='text-white mdi mdi-checkbox-blank-circle'></i></button>", 3 => "<button type='button' class='btn btn-primary btn-xs waves-effect waves-light tooltip' title='Direct Source'><i class='text-white mdi mdi mdi-web'></i></button>", 4 => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light tooltip' title='Down'><i class='text-white mdi mdi-triangle'></i></button>", 5 => "<button type='button' class='btn btn-info btn-xs waves-effect waves-light tooltip' title='Direct Stream'><i class='text-white mdi mdi mdi-web'></i></button>");
	$b24ad57311c6310c = array(1 => "<button type='button' class='btn btn-success btn-xs waves-effect waves-light'>ADDED</button>", 2 => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light'>SQL FAILED</button>", 3 => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light'>NO CATEGORY</button>", 4 => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light'>NO TMDb MATCH</button>", 5 => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light'>INVALID FILE</button>", 6 => "<button type='button' class='btn btn-info btn-xs waves-effect waves-light'>UPGRADED</button>");
	$e5ca16bbec7e5c54 = array('STREAM_STOP' => "<button type='button' class='btn btn-secondary btn-xs waves-effect waves-light btn-fixed-xl'>STOPPED</button>", 'STREAM_START_FAIL' => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light btn-fixed-xl'>START FAILED</button>", 'STREAM_START' => "<button type='button' class='btn btn-success btn-xs waves-effect waves-light btn-fixed-xl'>STARTED</button>", 'STREAM_RESTART' => "<button type='button' class='btn btn-info btn-xs waves-effect waves-light btn-fixed-xl'>RESTARTED</button>", 'STREAM_FAILED' => "<button type='button' class='btn btn-danger btn-xs waves-effect waves-light btn-fixed-xl'>STREAM FAILED</button>");
	$C14aaca15fa57b1f = array('STREAM_FAILED' => 'Stream Failed', 'STREAM_START' => 'Stream Started', 'STREAM_RESTART' => 'Stream Restarted', 'STREAM_STOP' => 'Stream Stopped', 'FORCE_SOURCE' => 'Force Change Source', 'AUTO_RESTART' => 'Timed Auto Restart', 'AUDIO_LOSS' => 'Audio Lost', 'PRIORITY_SWITCH' => 'Priority Switch', 'DELAY_START' => 'Delay Started', 'FFMPEG_ERROR' => 'FFMPEG Error');
	$Dde20813a43b39a3 = array(array('name' => 'Light', 'dark' => false, 'image' => null), array('name' => 'Dark', 'dark' => true, 'image' => null));
	$f9b96fb8199bfd3a = array(array('add_rtmp', $_['permission_add_rtmp'], $_['permission_add_rtmp_text']), array('add_bouquet', $_['permission_add_bouquet'], $_['permission_add_bouquet_text']), array('add_cat', $_['permission_add_cat'], $_['permission_add_cat_text']), array('add_e2', $_['permission_add_e2'], $_['permission_add_e2_text']), array('add_epg', $_['permission_add_epg'], $_['permission_add_epg_text']), array('add_episode', $_['permission_add_episode'], $_['permission_add_episode_text']), array('add_group', $_['permission_add_group'], $_['permission_add_group_text']), array('add_mag', $_['permission_add_mag'], $_['permission_add_mag_text']), array('add_movie', $_['permission_add_movie'], $_['permission_add_movie_text']), array('add_packages', $_['permission_add_packages'], $_['permission_add_packages_text']), array('add_radio', $_['permission_add_radio'], $_['permission_add_radio_text']), array('add_reguser', $_['permission_add_reguser'], $_['permission_add_reguser_text']), array('add_server', $_['permission_add_server'], $_['permission_add_server_text']), array('add_stream', $_['permission_add_stream'], $_['permission_add_stream_text']), array('tprofile', $_['permission_tprofile'], $_['permission_tprofile_text']), array('add_series', $_['permission_add_series'], $_['permission_add_series_text']), array('add_user', $_['permission_add_user'], $_['permission_add_user_text']), array('block_ips', $_['permission_block_ips'], $_['permission_block_ips_text']), array('block_isps', $_['permission_block_isps'], $_['permission_block_isps_text']), array('block_uas', $_['permission_block_uas'], $_['permission_block_uas_text']), array('create_channel', $_['permission_create_channel'], $_['permission_create_channel_text']), array('edit_bouquet', $_['permission_edit_bouquet'], $_['permission_edit_bouquet_text']), array('edit_cat', $_['permission_edit_cat'], $_['permission_edit_cat_text']), array('channel_order', $_['permission_channel_order'], $_['permission_channel_order_text']), array('edit_cchannel', $_['permission_edit_cchannel'], $_['permission_edit_cchannel_text']), array('edit_e2', $_['permission_edit_e2'], $_['permission_edit_e2_text']), array('epg_edit', $_['permission_epg_edit'], $_['permission_epg_edit_text']), array('edit_episode', $_['permission_edit_episode'], $_['permission_edit_episode_text']), array('folder_watch_settings', $_['permission_folder_watch_settings'], $_['permission_folder_watch_settings_text']), array('settings', $_['permission_settings'], $_['permission_settings_text']), array('edit_group', $_['permission_edit_group'], $_['permission_edit_group_text']), array('edit_mag', $_['permission_edit_mag'], $_['permission_edit_mag_text']), array('edit_movie', $_['permission_edit_movie'], $_['permission_edit_movie_text']), array('edit_package', $_['permission_edit_package'], $_['permission_edit_package_text']), array('edit_radio', $_['permission_edit_radio'], $_['permission_edit_radio_text']), array('edit_reguser', $_['permission_edit_reguser'], $_['permission_edit_reguser_text']), array('edit_server', $_['permission_edit_server'], $_['permission_edit_server_text']), array('edit_stream', $_['permission_edit_stream'], $_['permission_edit_stream_text']), array('edit_series', $_['permission_edit_series'], $_['permission_edit_series_text']), array('edit_user', $_['permission_edit_user'], $_['permission_edit_user_text']), array('fingerprint', $_['permission_fingerprint'], $_['permission_fingerprint_text']), array('import_episodes', $_['permission_import_episodes'], $_['permission_import_episodes_text']), array('import_movies', $_['permission_import_movies'], $_['permission_import_movies_text']), array('import_streams', $_['permission_import_streams'], $_['permission_import_streams_text']), array('database', $_['permission_database'], $_['permission_database_text']), array('mass_delete', $_['permission_mass_delete'], $_['permission_mass_delete_text']), array('mass_sedits_vod', $_['permission_mass_sedits_vod'], $_['permission_mass_sedits_vod_text']), array('mass_sedits', $_['permission_mass_sedits'], $_['permission_mass_sedits_text']), array('mass_edit_users', $_['permission_mass_edit_users'], $_['permission_mass_edit_users_text']), array('mass_edit_lines', $_['permission_mass_edit_lines'], $_['permission_mass_edit_lines_text']), array('mass_edit_mags', $_['permission_mass_edit_mags'], $_['permission_mass_edit_mags_text']), array('mass_edit_enigmas', $_['permission_mass_edit_enigmas'], $_['permission_mass_edit_enigmas_text']), array('mass_edit_streams', $_['permission_mass_edit_streams'], $_['permission_mass_edit_streams_text']), array('mass_edit_radio', $_['permission_mass_edit_radio'], $_['permission_mass_edit_radio_text']), array('mass_edit_reguser', $_['permission_mass_edit_reguser'], $_['permission_mass_edit_reguser_text']), array('ticket', $_['permission_ticket'], $_['permission_ticket_text']), array('subreseller', $_['permission_subreseller'], $_['permission_subreseller_text']), array('stream_tools', $_['permission_stream_tools'], $_['permission_stream_tools_text']), array('bouquets', $_['permission_bouquets'], $_['permission_bouquets_text']), array('categories', $_['permission_categories'], $_['permission_categories_text']), array('client_request_log', $_['permission_client_request_log'], $_['permission_client_request_log_text']), array('connection_logs', $_['permission_connection_logs'], $_['permission_connection_logs_text']), array('manage_cchannels', $_['permission_manage_cchannels'], $_['permission_manage_cchannels_text']), array('credits_log', $_['permission_credits_log'], $_['permission_credits_log_text']), array('index', $_['permission_index'], $_['permission_index_text']), array('manage_e2', $_['permission_manage_e2'], $_['permission_manage_e2_text']), array('epg', $_['permission_epg'], $_['permission_epg_text']), array('folder_watch', $_['permission_folder_watch'], $_['permission_folder_watch_text']), array('folder_watch_output', $_['permission_folder_watch_output'], $_['permission_folder_watch_output_text']), array('mng_groups', $_['permission_mng_groups'], $_['permission_mng_groups_text']), array('live_connections', $_['permission_live_connections'], $_['permission_live_connections_text']), array('login_logs', $_['permission_login_logs'], $_['permission_login_logs_text']), array('manage_mag', $_['permission_manage_mag'], $_['permission_manage_mag_text']), array('manage_events', $_['permission_manage_events'], $_['permission_manage_events_text']), array('movies', $_['permission_movies'], $_['permission_movies_text']), array('mng_packages', $_['permission_mng_packages'], $_['permission_mng_packages_text']), array('player', $_['permission_player'], $_['permission_player_text']), array('process_monitor', $_['permission_process_monitor'], $_['permission_process_monitor_text']), array('radio', $_['permission_radio'], $_['permission_radio_text']), array('mng_regusers', $_['permission_mng_regusers'], $_['permission_mng_regusers_text']), array('reg_userlog', $_['permission_reg_userlog'], $_['permission_reg_userlog_text']), array('rtmp', $_['permission_rtmp'], $_['permission_rtmp_text']), array('servers', $_['permission_servers'], $_['permission_servers_text']), array('stream_errors', $_['permission_stream_errors'], $_['permission_stream_errors_text']), array('streams', $_['permission_streams'], $_['permission_streams_text']), array('subresellers', $_['permission_subresellers'], $_['permission_subresellers_text']), array('manage_tickets', $_['permission_manage_tickets'], $_['permission_manage_tickets_text']), array('tprofiles', $_['permission_tprofiles'], $_['permission_tprofiles_text']), array('series', $_['permission_series'], $_['permission_series_text']), array('users', $_['permission_users'], $_['permission_users_text']), array('episodes', $_['permission_episodes'], $_['permission_episodes_text']), array('edit_tprofile', $_['permission_edit_tprofile'], $_['permission_edit_tprofile_text']), array('folder_watch_add', $_['permission_folder_watch_add'], $_['permission_folder_watch_add_text']), array('add_code', $_['permission_add_code'], $_['permission_add_code_text']), array('add_hmac', $_['permission_add_hmac'], $_['permission_add_hmac_text']), array('block_asns', $_['permission_block_asns'], $_['permission_block_asns_text']), array('license', $_['permission_license'], $_['permission_license_text']), array('panel_logs', $_['permission_panel_logs'], $_['permission_panel_logs_text']), array('quick_tools', $_['permission_quick_tools'], $_['permission_quick_tools_text']), array('restream_logs', $_['permission_restream_logs'], $_['permission_restream_logs_text']));
} else {
	exit('Your license key does not match the license file.<br/><br/>Please generate a new license using the CLI command:<br/>/home/xui/status');
}

function D3f333592a08Eb86($a71afc14d6cd090d, $d5249dad8e8411b7)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id`, `username`, `password`, `member_group_id`, `status` FROM `users` WHERE `username` = ? LIMIT 1;', $a71afc14d6cd090d);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		$C740da31596f24ef = $Fee0d5a474c96306->get_row();

		if (Df65d36beA77aE8C($d5249dad8e8411b7, $C740da31596f24ef['password']) != $C740da31596f24ef['password']) {
		} else {
			return $C740da31596f24ef;
		}
	}
}

function cf37729B794b4Be3()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `id`, `title` FROM `streams_series` ORDER BY `title` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function d6afF54EF17EcfDB($bbb95f208fd96d2d)
{
	$cf15ef99eb9c71b4 = 60;
	$F3936dc241ba377c = 60 * $cf15ef99eb9c71b4;
	$d44d7a81eab9b8c2 = 24 * $F3936dc241ba377c;
	$d02dcb7d9a70c91d = floor($bbb95f208fd96d2d / $d44d7a81eab9b8c2);
	$f9218de0477cb5e0 = $bbb95f208fd96d2d % $d44d7a81eab9b8c2;
	$f75eddfa15f282b7 = floor($f9218de0477cb5e0 / $F3936dc241ba377c);
	$ca456b943814f828 = $f9218de0477cb5e0 % $F3936dc241ba377c;
	$a67fb5f5e96572ff = floor($ca456b943814f828 / $cf15ef99eb9c71b4);
	$B37a7c7f801a52fc = $ca456b943814f828 % $cf15ef99eb9c71b4;
	$e8d790208feded39 = ceil($B37a7c7f801a52fc);

	return array('d' => (int) $d02dcb7d9a70c91d, 'h' => (int) $f75eddfa15f282b7, 'm' => (int) $a67fb5f5e96572ff, 's' => (int) $e8d790208feded39);
}

function FcBE229Ba43Ff4b8($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	require_once XUI_HOME . 'includes/libs/tmdb.php';
	$Fee0d5a474c96306->query('SELECT `tmdb_id`, `tmdb_language` FROM `streams_series` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		$C740da31596f24ef = $Fee0d5a474c96306->get_row();
		$Ddb572d71804d3a6 = $C740da31596f24ef['tmdb_id'];

		if (0 >= strlen($Ddb572d71804d3a6)) {
		} else {
			if (0 < strlen($C740da31596f24ef['tmdb_language'])) {
				$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], $C740da31596f24ef['tmdb_language']);
			} else {
				if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
					$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
				} else {
					$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
				}
			}

			$a85e1b7d42c346a0 = array();
			$Dac6e8d3df73a8d8 = json_decode($a69d576081840514->getTVShow($Ddb572d71804d3a6)->getJSON(), true)['seasons'];

			foreach ($Dac6e8d3df73a8d8 as $b550d8eef0f542ec) {
				$b550d8eef0f542ec['cover'] = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $b550d8eef0f542ec['poster_path'];

				if (!XUI::$rSettings['download_images']) {
				} else {
					$b550d8eef0f542ec['cover'] = XUI::B2068Ce8B339BF70($b550d8eef0f542ec['cover']);
				}

				$b550d8eef0f542ec['cover_big'] = $b550d8eef0f542ec['cover'];
				unset($b550d8eef0f542ec['poster_path']);
				$a85e1b7d42c346a0[] = $b550d8eef0f542ec;
			}
			$Fee0d5a474c96306->query('UPDATE `streams_series` SET `seasons` = ? WHERE `id` = ?;', json_encode($a85e1b7d42c346a0, JSON_UNESCAPED_UNICODE), $C3c8913edb801c35);
		}
	}
}

function FFa086A148acF057($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('INSERT INTO `watch_refresh`(`type`, `stream_id`, `status`) VALUES(4, ?, 0);', $C3c8913edb801c35);
}

function ddE0B761098ca92F($Da967f0a787f6b51)
{
	$Bab76ac20d8e4000 = explode('/', $Da967f0a787f6b51);
	$c59ec257c284c894 = $Bab76ac20d8e4000[0];
	$Dbaafe63125ac9a4 = null;

	if (count($Bab76ac20d8e4000) != 2) {
	} else {
		$Dbaafe63125ac9a4 = intval($Bab76ac20d8e4000[1]);

		if ($Dbaafe63125ac9a4 >= 0) {
		} else {
			return false;
		}
	}

	if (!filter_var($c59ec257c284c894, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
		if (!filter_var($c59ec257c284c894, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
			return false;
		}

		return (is_null($Dbaafe63125ac9a4) ? true : $Dbaafe63125ac9a4 <= 128);
	}

	return (is_null($Dbaafe63125ac9a4) ? true : $Dbaafe63125ac9a4 <= 32);
}

function b4167cFcA7fE90F8($d58b4f8653a391d8)
{
	$a85e1b7d42c346a0 = array();
	$f2cc0807b1dc8948 = json_decode(a200986BBAe4b322($d58b4f8653a391d8, array('action' => 'get_free_space')), true);
	array_shift($f2cc0807b1dc8948);

	foreach ($f2cc0807b1dc8948 as $Ff014d0ebd314fcd) {
		$B211d7401e6242f3 = explode(' ', preg_replace('!\\s+!', ' ', trim($Ff014d0ebd314fcd)));

		if (!(0 < strlen($B211d7401e6242f3[0]) && strpos($B211d7401e6242f3[5], 'xui') !== false || $B211d7401e6242f3[5] == '/')) {
		} else {
			$a85e1b7d42c346a0[] = array('filesystem' => $B211d7401e6242f3[0], 'size' => $B211d7401e6242f3[1], 'used' => $B211d7401e6242f3[2], 'avail' => $B211d7401e6242f3[3], 'percentage' => $B211d7401e6242f3[4], 'mount' => implode(' ', array_slice($B211d7401e6242f3, 5, count($B211d7401e6242f3) - 5)));
		}
	}

	return $a85e1b7d42c346a0;
}

function getStreamsRamdisk($d58b4f8653a391d8)
{
	$a85e1b7d42c346a0 = json_decode(A200986bBAE4B322($d58b4f8653a391d8, array('action' => 'streams_ramdisk')), true);

	if (!$a85e1b7d42c346a0['result']) {
		return array();
	}

	return $a85e1b7d42c346a0['streams'];
}

function killPID($d58b4f8653a391d8, $f9b07d216a168dcc)
{
	A200986BBAe4B322($d58b4f8653a391d8, array('action' => 'kill_pid', 'pid' => $f9b07d216a168dcc));
}

function f628024A69e60b02($d58b4f8653a391d8)
{
	return json_decode(A200986bBAE4B322($d58b4f8653a391d8, array('action' => 'rtmp_stats')), true);
}

function ccE66f113d4f4390()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `streams_arguments` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['argument_key']] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function Efe0ce577fb769Bc()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `profiles` ORDER BY `profile_id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A4Cc632f26dF90Dd($E379394c7b1a273f = null)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	if ($E379394c7b1a273f) {
		$Fee0d5a474c96306->query("SELECT * FROM `watch_folders` WHERE `type` = ? AND `type` <> 'plex' ORDER BY `id` ASC;", $E379394c7b1a273f);
	} else {
		$Fee0d5a474c96306->query("SELECT * FROM `watch_folders` WHERE `type` <> 'plex' ORDER BY `id` ASC;");
	}

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function getPlexServers()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query("SELECT * FROM `watch_folders` WHERE `type` = 'plex' ORDER BY `id` ASC;");

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function c91BF2e51C65BEBC($E379394c7b1a273f = null)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	if ($E379394c7b1a273f) {
		$Fee0d5a474c96306->query('SELECT * FROM `watch_categories` WHERE `type` = ? ORDER BY `genre_id` ASC;', $E379394c7b1a273f);
	} else {
		$Fee0d5a474c96306->query('SELECT * FROM `watch_categories` ORDER BY `genre_id` ASC;');
	}

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['genre_id']] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function a85a61D6f165008a($D78ff1d0edade5eb, $Bcb41d44b619234f = null)
{
	global $Fee0d5a474c96306;
	$d51e425eb7375255 = b4036eF9a1DB8473($D78ff1d0edade5eb);

	if (!$d51e425eb7375255) {
	} else {
		unset($d51e425eb7375255['id']);

		if ($Bcb41d44b619234f) {
			$Fee0d5a474c96306->query('SELECT * FROM `lines` WHERE `id` = (SELECT `user_id` FROM `mag_devices` WHERE `mag_id` = ?);', $Bcb41d44b619234f);
		} else {
			$Fee0d5a474c96306->query('SELECT * FROM `lines` WHERE `pair_id` = ?;', $D78ff1d0edade5eb);
		}

		foreach ($Fee0d5a474c96306->get_rows() as $cdc93dae5ba3d206) {
			$Ce3cb1baf0a76292 = $d51e425eb7375255;
			$Ce3cb1baf0a76292['pair_id'] = intval($D78ff1d0edade5eb);
			$Ce3cb1baf0a76292['play_token'] = '';

			foreach (array('id', 'is_mag', 'is_e2', 'is_restreamer', 'max_connections', 'created_at', 'username', 'password', 'admin_notes', 'reseller_notes') as $D3fa098be3f297cd) {
				$Ce3cb1baf0a76292[$D3fa098be3f297cd] = $cdc93dae5ba3d206[$D3fa098be3f297cd];
			}

			if (!isset($Ce3cb1baf0a76292['id'])) {
			} else {
				$acd0eb2c8a975903 = f4817dC607D9981D($Ce3cb1baf0a76292);
				$A6d7047f2fda966c = 'REPLACE INTO `lines`(' . $acd0eb2c8a975903['columns'] . ') VALUES(' . $acd0eb2c8a975903['placeholder'] . ');';
				$Fee0d5a474c96306->query($A6d7047f2fda966c, ...$acd0eb2c8a975903['data']);
				XUI::Bc77eDC4169F1BaA($Ce3cb1baf0a76292['id']);
			}
		}
	}
}

function CD4C14B3eaAb5b17($C740da31596f24ef)
{
	foreach ($C740da31596f24ef as $D3fa098be3f297cd => $b6842cb20051e925) {
		if (!is_array($b6842cb20051e925)) {
		} else {
			$C740da31596f24ef[$D3fa098be3f297cd] = json_encode($b6842cb20051e925, JSON_UNESCAPED_UNICODE);
		}
	}

	return $C740da31596f24ef;
}

function B7b42FfAfF30bb02($d9ee1cc8e0f43f6e = null)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	if ($d9ee1cc8e0f43f6e) {
		$Fee0d5a474c96306->query('SELECT `callSign`, `bcastLangs`, `name`, `picon` FROM `epg_api` WHERE SOUNDEX(`name`) = SOUNDEX(?) ORDER BY `name` ASC, `eng` DESC;', $d9ee1cc8e0f43f6e);
	} else {
		$Fee0d5a474c96306->query('SELECT `callSign`, `bcastLangs`, `name`, `picon` FROM `epg_api` ORDER BY `name` ASC, `eng` DESC;');
	}

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function Fb92B7C2049D8467($d58b4f8653a391d8, $F26087d31c2bbe4d)
{
	return json_decode(A200986BbaE4b322($d58b4f8653a391d8, array('action' => 'get_archive_files', 'stream_id' => $F26087d31c2bbe4d)), true)['data'];
}

function E695e82DD6B72236($F26087d31c2bbe4d)
{
	$a85e1b7d42c346a0 = array();
	$f523e362fb81d6c8 = E5eCeB32F67D5e70($F26087d31c2bbe4d);
	$d8a1409105424710 = cfaec500A6B51C40($F26087d31c2bbe4d, true);
	$b93e6a2691d72853 = fb92b7c2049d8467($f523e362fb81d6c8['tv_archive_server_id'], $F26087d31c2bbe4d);

	if (!(0 < count($b93e6a2691d72853) && 0 < count($d8a1409105424710))) {
	} else {
		foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
			$bc2874292e0d9ece = pathinfo($e2f848a82a80c113)['filename'];
			$e0d8bd4d04af5371 = strtotime(explode(':', $bc2874292e0d9ece)[0] . 'T' . implode(':', explode('-', explode(':', $bc2874292e0d9ece)[1])) . ':00Z ' . str_replace(':', '', gmdate('P')));
			$b68956643e52e9b7 = null;
			$af207a8c4c307772 = 0;

			foreach ($d8a1409105424710 as $cfe5858b37d01860) {
				if (!filter_var($e0d8bd4d04af5371, FILTER_VALIDATE_INT, array('options' => array('min_range' => $cfe5858b37d01860['start'], 'max_range' => $cfe5858b37d01860['end'] - 1)))) {
					$af207a8c4c307772++;
				} else {
					$b68956643e52e9b7 = $af207a8c4c307772;

					break;
				}
			}

			if (!$b68956643e52e9b7) {
			} else {
				if (isset($a85e1b7d42c346a0[$b68956643e52e9b7])) {
				} else {
					$a85e1b7d42c346a0[$b68956643e52e9b7] = $d8a1409105424710[$b68956643e52e9b7];
					$a85e1b7d42c346a0[$b68956643e52e9b7]['archive_stop'] = null;
					$a85e1b7d42c346a0[$b68956643e52e9b7]['archive_start'] = $a85e1b7d42c346a0[$b68956643e52e9b7]['archive_stop'];
				}

				if ($e0d8bd4d04af5371 - 60 >= $a85e1b7d42c346a0[$b68956643e52e9b7]['archive_start'] && $a85e1b7d42c346a0[$b68956643e52e9b7]['archive_start']) {
				} else {
					$a85e1b7d42c346a0[$b68956643e52e9b7]['archive_start'] = $e0d8bd4d04af5371 - 60;
				}

				if ($a85e1b7d42c346a0[$b68956643e52e9b7]['archive_stop'] >= $e0d8bd4d04af5371 && $a85e1b7d42c346a0[$b68956643e52e9b7]['archive_stop']) {
				} else {
					$a85e1b7d42c346a0[$b68956643e52e9b7]['archive_stop'] = $e0d8bd4d04af5371;
				}
			}
		}
	}

	foreach ($a85e1b7d42c346a0 as $D3fa098be3f297cd => $bb2621204e39e62d) {
		if (time() < $bb2621204e39e62d['end']) {
			$a85e1b7d42c346a0[$D3fa098be3f297cd]['in_progress'] = true;
		} else {
			$a85e1b7d42c346a0[$D3fa098be3f297cd]['in_progress'] = false;
		}

		if (!$a85e1b7d42c346a0[$D3fa098be3f297cd]['in_progress'] && filter_var($bb2621204e39e62d['start'], FILTER_VALIDATE_INT, array('options' => array('min_range' => $bb2621204e39e62d['archive_start'] - 60, 'max_range' => $bb2621204e39e62d['archive_start'] + 60))) && filter_var($bb2621204e39e62d['end'], FILTER_VALIDATE_INT, array('options' => array('min_range' => $bb2621204e39e62d['archive_stop'] - 60, 'max_range' => $bb2621204e39e62d['archive_stop'] + 60)))) {
			$a85e1b7d42c346a0[$D3fa098be3f297cd]['complete'] = true;
		} else {
			$a85e1b7d42c346a0[$D3fa098be3f297cd]['complete'] = false;
		}
	}

	return $a85e1b7d42c346a0;
}

function getPlexLogin($a71afc14d6cd090d, $d5249dad8e8411b7)
{
	$Ae2b613e51651b56 = array('Content-Type: application/xml; charset=utf-8', 'X-Plex-Client-Identifier: 526e163c-8dbd-11eb-8dcd-0242ac130003', 'X-Plex-Product: XUI', 'X-Plex-Version: v' . XUI_VERSION);
	$a0eb8eb80ccd233b = curl_init('https://plex.tv/users/sign_in.json');
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_HTTPHEADER, $Ae2b613e51651b56);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_HEADER, 0);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_USERPWD, $a71afc14d6cd090d . ':' . $d5249dad8e8411b7);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_TIMEOUT, 30);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_POST, 1);
	curl_setopt($a0eb8eb80ccd233b, CURLOPT_RETURNTRANSFER, true);

	return json_decode(curl_exec($a0eb8eb80ccd233b), true);
}

function getPlexSections($c59ec257c284c894, $b87b2986f8f49da8, $ea5296071288c730)
{
	$F8fc019bd5a71db2 = json_decode(json_encode(simplexml_load_string(file_get_contents('http://' . $c59ec257c284c894 . ':' . $b87b2986f8f49da8 . '/library/sections?X-Plex-Token=' . $ea5296071288c730))), true);

	if (!isset($F8fc019bd5a71db2['Directory'])) {
		return array();
	}

	if (!isset($F8fc019bd5a71db2['Directory']['@attributes'])) {
	} else {
		$F8fc019bd5a71db2['Directory'] = array($F8fc019bd5a71db2['Directory']);
	}

	return $F8fc019bd5a71db2['Directory'];
}

function getMovieTMDB($C3c8913edb801c35)
{
	require_once XUI_HOME . 'includes/libs/tmdb.php';

	if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
	} else {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
	}

	return ($a69d576081840514->getMovie($C3c8913edb801c35) ?: null);
}

function getSeriesTMDB($C3c8913edb801c35)
{
	require_once XUI_HOME . 'includes/libs/tmdb.php';

	if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
	} else {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
	}

	return (json_decode($a69d576081840514->getTVShow($C3c8913edb801c35)->getJSON(), true) ?: null);
}

function getSeasonTMDB($C3c8913edb801c35, $b550d8eef0f542ec)
{
	require_once XUI_HOME . 'includes/libs/tmdb.php';

	if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
	} else {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
	}

	return json_decode($a69d576081840514->getSeason($C3c8913edb801c35, intval($b550d8eef0f542ec))->getJSON(), true);
}

function getResellers($Dbb9e190755fc819, $E8d403a4062baa68 = true)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	if ($E8d403a4062baa68) {
		$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `users` WHERE `owner_id` = ? OR `id` = ? ORDER BY `username` ASC;', $Dbb9e190755fc819, $Dbb9e190755fc819);
	} else {
		$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `users` WHERE `owner_id` = ? ORDER BY `username` ASC;', $Dbb9e190755fc819);
	}

	return $Fee0d5a474c96306->get_rows(true, 'id');
}

function E0f4D0435B5DD679($E8d403a4062baa68 = true)
{
	global $Fee0d5a474c96306;
	global $B2ff75c438fb3031;
	global $D4253f9520627819;
	$b174976b99c4ec48 = $B2ff75c438fb3031['direct_reports'];

	if (!$E8d403a4062baa68) {
	} else {
		$b174976b99c4ec48[] = $D4253f9520627819['id'];
	}

	$a85e1b7d42c346a0 = array();

	if (0 >= count($b174976b99c4ec48)) {
	} else {
		$Fee0d5a474c96306->query('SELECT * FROM `users` WHERE `owner_id` IN (' . implode(',', array_map('intval', $b174976b99c4ec48)) . ') ORDER BY `username` ASC;');

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function FFC8abe77784751D($E379394c7b1a273f)
{
	global $B2ff75c438fb3031;

	return $B2ff75c438fb3031[$E379394c7b1a273f];
}

function aaCd47D8157a1a09($E379394c7b1a273f, $C3c8913edb801c35)
{
	global $D4253f9520627819;
	global $Fee0d5a474c96306;
	global $B2ff75c438fb3031;

	if (isset($D4253f9520627819) && isset($B2ff75c438fb3031)) {
		if ($E379394c7b1a273f == 'user') {
			$F3a421506b1b5b24 = array_map('intval', array_merge(array($D4253f9520627819['id']), $B2ff75c438fb3031['all_reports']));

			if (0 < count($F3a421506b1b5b24)) {
				$Fee0d5a474c96306->query('SELECT `id` FROM `users` WHERE `id` = ? AND (`owner_id` IN (' . implode(',', $F3a421506b1b5b24) . ') OR `id` = ?);', $C3c8913edb801c35, $D4253f9520627819['id']);

				return 0 < $Fee0d5a474c96306->num_rows();
			}

			return false;
		}

		if ($E379394c7b1a273f == 'line') {
			$F3a421506b1b5b24 = array_map('intval', array_merge(array($D4253f9520627819['id']), $B2ff75c438fb3031['all_reports']));

			if (0 < count($F3a421506b1b5b24)) {
				$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `id` = ? AND `member_id` IN (' . implode(',', $F3a421506b1b5b24) . ');', $C3c8913edb801c35);

				return 0 < $Fee0d5a474c96306->num_rows();
			}

			return false;
		}

		if (!($E379394c7b1a273f == 'adv' && $B2ff75c438fb3031['is_admin'])) {
			return false;
		}

		if (0 < count($B2ff75c438fb3031['advanced']) && $D4253f9520627819['member_group_id'] != 1) {
			return in_array($C3c8913edb801c35, ($B2ff75c438fb3031['advanced'] ?: array()));
		}

		return true;
	}

	return false;
}

function Ba348b5700ee9Ff3()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `users_groups` ORDER BY `group_id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['group_id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function e0E0B33ec3E01E79()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `hmac_keys` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A69C1563c73e6d19($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `hmac_keys` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function B805779562e68625()
{
	$fc8f82b0f51a85f2 = array();
	$b93e6a2691d72853 = scandir(XUI_HOME . 'bin/nginx/conf/codes/');

	foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
		$d953b066e19239c1 = pathinfo($e2f848a82a80c113);
		$C6a7103a3e51b098 = $d953b066e19239c1['extension'];

		if (!($C6a7103a3e51b098 == 'conf' && $d953b066e19239c1['filename'] != 'default')) {
		} else {
			$fc8f82b0f51a85f2[] = $d953b066e19239c1['filename'];
		}
	}

	return $fc8f82b0f51a85f2;
}

function b3c0272304a383cC()
{
	$C9521a97067b23d1 = file_get_contents(XUI_HOME . 'bin/nginx/conf/codes/template');
	shell_exec('rm -f ' . XUI_HOME . 'bin/nginx/conf/codes/*.conf');

	foreach (b0492AE58018ce29() as $c47b624a230c406a) {
		if (!$c47b624a230c406a['enabled']) {
		} else {
			$cbe9ad9189545479 = array();

			foreach (json_decode($c47b624a230c406a['whitelist'], true) as $c59ec257c284c894) {
				if (!filter_var($c59ec257c284c894, FILTER_VALIDATE_IP)) {
				} else {
					$cbe9ad9189545479[] = 'allow ' . $c59ec257c284c894 . ';';
				}
			}

			if (0 >= count($cbe9ad9189545479)) {
			} else {
				$cbe9ad9189545479[] = 'deny all;';
			}

			$E379394c7b1a273f = array('admin', 'reseller', 'ministra', 'includes/api/admin', 'includes/api/reseller', 'ministra/new', 'player')[$c47b624a230c406a['type']];
			$ea42f014704911a3 = array(500, 50, 50, 1000, 1000, 50, 500)[$c47b624a230c406a['type']];

			if (4 <= strlen($c47b624a230c406a['code'])) {
				file_put_contents(XUI_HOME . 'bin/nginx/conf/codes/' . $c47b624a230c406a['code'] . '.conf', str_replace(array('#WHITELIST#', '#CODE#', '#TYPE#', '#BURST#'), array(implode(' ', $cbe9ad9189545479), $c47b624a230c406a['code'], $E379394c7b1a273f, $ea42f014704911a3), $C9521a97067b23d1));
			} else {
				file_put_contents(XUI_HOME . 'bin/nginx/conf/codes/' . $c47b624a230c406a['code'] . '.conf', str_replace(array('#WHITELIST#', '#CODE#', '#TYPE#', '#BURST#'), array(implode(' ', $cbe9ad9189545479), $c47b624a230c406a['code'] . '/', $E379394c7b1a273f . '/', $ea42f014704911a3), $C9521a97067b23d1));
			}
		}
	}

	if (count(b805779562e68625()) == 0) {
		if (file_exists(XUI_HOME . 'bin/nginx/conf/codes/default.conf')) {
		} else {
			file_put_contents(XUI_HOME . 'bin/nginx/conf/codes/default.conf', str_replace(array('alias ', '#WHITELIST#', '#CODE#', '#TYPE#'), array('root ', '', '', 'admin'), $C9521a97067b23d1));
		}
	} else {
		if (!file_exists(XUI_HOME . 'bin/nginx/conf/codes/default.conf')) {
		} else {
			unlink(XUI_HOME . 'bin/nginx/conf/codes/default.conf');
		}
	}

	F079A768b4aaC7e1(SERVER_ID);
}

function E787d2298dBDA85d($Eea1b980ebbe2a33 = false)
{
	if ($Eea1b980ebbe2a33) {
		global $Fee0d5a474c96306;
		$Fee0d5a474c96306->query('SELECT * FROM `access_codes` WHERE `code` = ?;', basename(dirname($_SERVER['PHP_SELF'])));

		if ($Fee0d5a474c96306->num_rows() == 1) {
			return $Fee0d5a474c96306->get_row();
		}

		return null;
	}

	return basename(dirname($_SERVER['PHP_SELF']));
}

function EBDAAfc1C10F9506($a27e64cc6ce01033, $aada6b4a73d4f74e, $fc34939e2e489277 = array())
{
	foreach ($aada6b4a73d4f74e as $D3fa098be3f297cd => $b6842cb20051e925) {
		if (!array_key_exists($D3fa098be3f297cd, $a27e64cc6ce01033) || in_array($D3fa098be3f297cd, $fc34939e2e489277)) {
		} else {
			if (empty($b6842cb20051e925) && is_null($a27e64cc6ce01033[$D3fa098be3f297cd])) {
				$a27e64cc6ce01033[$D3fa098be3f297cd] = null;
			} else {
				$a27e64cc6ce01033[$D3fa098be3f297cd] = $b6842cb20051e925;
			}
		}
	}

	return $a27e64cc6ce01033;
}

function b9Da5d708fc1C079($B1a1e80ba9ae29c7, $a27e64cc6ce01033 = array(), $fcc4f0f10efcef42 = false)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `column_name`, `column_default`, `is_nullable`, `data_type` FROM `information_schema`.`columns` WHERE `table_schema` = (SELECT DATABASE()) AND `table_name` = ? ORDER BY `ordinal_position`;', $B1a1e80ba9ae29c7);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($C740da31596f24ef['column_default'] != 'NULL') {
		} else {
			$C740da31596f24ef['column_default'] = null;
		}

		$f2373ceca1685f65 = false;

		if ($C740da31596f24ef['is_nullable'] != 'NO' || $C740da31596f24ef['column_default']) {
		} else {
			if (in_array($C740da31596f24ef['data_type'], array('int', 'float', 'tinyint', 'double', 'decimal', 'smallint', 'mediumint', 'bigint', 'bit'))) {
				$C740da31596f24ef['column_default'] = 0;
			} else {
				$C740da31596f24ef['column_default'] = '';
			}

			$f2373ceca1685f65 = true;
		}

		if (array_key_exists($C740da31596f24ef['column_name'], $a27e64cc6ce01033)) {
			if (empty($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && !is_numeric($a27e64cc6ce01033[$C740da31596f24ef['column_name']]) && is_null($C740da31596f24ef['column_default'])) {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = ($f2373ceca1685f65 ? $C740da31596f24ef['column_default'] : null);
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $a27e64cc6ce01033[$C740da31596f24ef['column_name']];
			}
		} else {
			if ($fcc4f0f10efcef42) {
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['column_name']] = $C740da31596f24ef['column_default'];
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function C4a6F6f0dEBd5F57($b6842cb20051e925)
{
	return strtolower(preg_replace('/[^a-z0-9_]+/i', '', $b6842cb20051e925));
}

function f4817dC607d9981d($d49041d5f05a9270)
{
	$D480255818428bfd = $F02c388243a378a7 = $C0ad72b730f8eea3 = $a27e64cc6ce01033 = array();

	foreach (array_keys($d49041d5f05a9270) as $D3fa098be3f297cd) {
		$F02c388243a378a7[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '`';
		$D480255818428bfd[] = '`' . c4a6f6f0debd5f57($D3fa098be3f297cd) . '` = ?';
	}

	foreach (array_values($d49041d5f05a9270) as $b6842cb20051e925) {
		if (is_array($b6842cb20051e925)) {
			$b6842cb20051e925 = json_encode($b6842cb20051e925, JSON_UNESCAPED_UNICODE);
		} else {
			if (!(is_null($b6842cb20051e925) || strtolower($b6842cb20051e925) == 'null')) {
			} else {
				$b6842cb20051e925 = null;
			}
		}

		$C0ad72b730f8eea3[] = '?';
		$a27e64cc6ce01033[] = $b6842cb20051e925;
	}

	return array('placeholder' => implode(',', $C0ad72b730f8eea3), 'columns' => implode(',', $F02c388243a378a7), 'data' => $a27e64cc6ce01033, 'update' => implode(',', $D480255818428bfd));
}

function D83f89aB0B71b235($C4afe46ee5612bc9, $A6a37007ba60a87b = true)
{
	$C700a2b357e5ed65 = d451dBAdaa63fD18();

	if (0 >= count($C4afe46ee5612bc9)) {
	} else {
		$C700a2b357e5ed65 .= '?' . http_build_query($C4afe46ee5612bc9);

		if (!$A6a37007ba60a87b) {
		} else {
			foreach ($C4afe46ee5612bc9 as $D3fa098be3f297cd => $b6842cb20051e925) {
				XUI::$rRequest[$D3fa098be3f297cd] = $b6842cb20051e925;
			}
		}
	}

	return "<script>history.replaceState({},'','" . $C700a2b357e5ed65 . "');</script>";
}

function e179fCD4E3F4CFBd($C3c8913edb801c35)
{
	global $B2ff75c438fb3031;
	global $D4253f9520627819;

	if (!isset($B2ff75c438fb3031['users'][$C3c8913edb801c35]['parent']) || $B2ff75c438fb3031['users'][$C3c8913edb801c35]['parent'] == 0 || $B2ff75c438fb3031['users'][$C3c8913edb801c35]['parent'] == $D4253f9520627819['id']) {
		return $C3c8913edb801c35;
	}

	return e179fCD4e3f4cfBd($B2ff75c438fb3031['users'][$C3c8913edb801c35]['parent']);
}

function D51d8bc0921F91F7($d51e425eb7375255)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `id`, `username` FROM `users` WHERE `owner_id` = ?;', $d51e425eb7375255);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$a85e1b7d42c346a0[$C740da31596f24ef['id']] = array('username' => $C740da31596f24ef['username'], 'parent' => $d51e425eb7375255);

		foreach (D51d8Bc0921f91f7($C740da31596f24ef['id']) as $D78ff1d0edade5eb => $E3adbdd9acf7f4a3) {
			$a85e1b7d42c346a0[$D78ff1d0edade5eb] = $E3adbdd9acf7f4a3;
		}
	}

	return $a85e1b7d42c346a0;
}

function FfEd6f696e23F060($C700a2b357e5ed65, $D8e1dc68b81d5702, $ea69abb4ad0055aa)
{
	list($F9452a7efafa1aba) = explode('.', strtolower(pathinfo($C700a2b357e5ed65)['extension']));
	$cff016622381f6ab = IMAGES_PATH . 'admin/' . md5($C700a2b357e5ed65) . '_' . $D8e1dc68b81d5702 . '_' . $ea69abb4ad0055aa . '.' . $F9452a7efafa1aba;

	if (file_exists($cff016622381f6ab)) {
		$Caecf2bcd39a1efe = (empty(XUI::$rServers[SERVER_ID]['domain_name']) ? XUI::$rServers[SERVER_ID]['server_ip'] : explode(',', XUI::$rServers[SERVER_ID]['domain_name'])[0]);

		return XUI::$rServers[SERVER_ID]['server_protocol'] . '://' . $Caecf2bcd39a1efe . ':' . XUI::$rServers[SERVER_ID]['request_port'] . '/images/admin/' . md5($C700a2b357e5ed65) . '_' . $D8e1dc68b81d5702 . '_' . $ea69abb4ad0055aa . '.' . $F9452a7efafa1aba;
	}

	return XUI::B8f3dEf724810918($C700a2b357e5ed65);
}

function CC5fAb790EAf9d0D($F26087d31c2bbe4d, $A67e498ebd577908 = 250)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM (SELECT MAX(`date`) AS `date`, `error` FROM `streams_errors` WHERE `stream_id` = ? GROUP BY `error`) AS `output` ORDER BY `date` DESC LIMIT ' . intval($A67e498ebd577908) . ';', $F26087d31c2bbe4d);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$a85e1b7d42c346a0[] = $C740da31596f24ef;
	}

	return $a85e1b7d42c346a0;
}

function getPageFromURL($C700a2b357e5ed65)
{
	if ($C700a2b357e5ed65) {
		return strtolower(basename(ltrim(parse_url($C700a2b357e5ed65)['path'], '/'), '.php'));
	}

	return null;
}

function CAba5e6Dd35c779d()
{
	global $D4253f9520627819;

	if (isset($D4253f9520627819)) {
		$ef288259a1681f9b = e787d2298dbda85d(true);

		if (in_array($D4253f9520627819['member_group_id'], json_decode($ef288259a1681f9b['groups'], true)) || count(b805779562e68625()) == 0) {
			if (isset($_SESSION['code']) && $_SESSION['code'] != $ef288259a1681f9b['code']) {
				return false;
			}

			return true;
		}

		return false;
	}

	return false;
}

function DeE5ef17195EC0cf($b847427c74689f7f, $a5cbf8a0668cece1)
{
	$C81f5f7d4b192c6d = null;

	foreach ($b847427c74689f7f as $D45382ad8061de32) {
		if (!($C81f5f7d4b192c6d === null || abs($D45382ad8061de32 - $a5cbf8a0668cece1) < abs($a5cbf8a0668cece1 - $C81f5f7d4b192c6d))) {
		} else {
			$C81f5f7d4b192c6d = $D45382ad8061de32;
		}
	}

	return $C81f5f7d4b192c6d;
}

function B97281528fc4b07c()
{
	return substr(md5(XUI::$rSettings['live_streaming_pass']), 0, 15);
}

function aA5550E4A234CbE6($B1a1e80ba9ae29c7, $f8d6610081a97651, $b6842cb20051e925, $Abe24edd9c02cebf = null, $b3b5fc701a29cbf4 = null)
{
	global $Fee0d5a474c96306;

	if ($Abe24edd9c02cebf && $b3b5fc701a29cbf4) {
		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `' . c4a6f6f0debd5f57($B1a1e80ba9ae29c7) . '` WHERE `' . c4a6f6f0debd5f57($f8d6610081a97651) . '` = ? AND `' . c4a6f6f0debd5f57($Abe24edd9c02cebf) . '` <> ?;', $b6842cb20051e925, $b3b5fc701a29cbf4);
	} else {
		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `' . c4a6f6f0debd5f57($B1a1e80ba9ae29c7) . '` WHERE `' . c4a6f6f0debd5f57($f8d6610081a97651) . '` = ?;', $b6842cb20051e925);
	}

	return 0 < $Fee0d5a474c96306->get_row()['count'];
}

function bEA20353771f9ba3($a27e64cc6ce01033, $e2f848a82a80c113 = true)
{
	require_once INCLUDES_PATH . 'libs/m3u.php';
	$ba03c5ab4f26fb8f = new M3uParser();
	$ba03c5ab4f26fb8f->addDefaultTags();

	if ($e2f848a82a80c113) {
		return $ba03c5ab4f26fb8f->parseFile($a27e64cc6ce01033);
	}

	return $ba03c5ab4f26fb8f->parse($a27e64cc6ce01033);
}

function deleteLines($Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmIDs($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
		return false;
	}

	XUI::deleteLines($Aa8c918a2a91966f);
	$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `lines_logs` WHERE `user_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `user_id` = 0 WHERE `user_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$B8905a8ba7673cc5 = array();
	$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `pair_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if (0 >= $C740da31596f24ef['id'] || in_array($C740da31596f24ef['id'], $B8905a8ba7673cc5)) {
		} else {
			$B8905a8ba7673cc5[] = $C740da31596f24ef['id'];
		}
	}

	if (0 >= count($B8905a8ba7673cc5)) {
	} else {
		$Fee0d5a474c96306->query('UPDATE `lines` SET `pair_id` = null WHERE `id` = (' . implode(',', $B8905a8ba7673cc5) . ');');
		XUI::updateLines($B8905a8ba7673cc5);
	}

	return true;
}

function d8974B51B74c80ee($C3c8913edb801c35, $E88779bc08699291 = false, $f0076b9bca9390cb = true, $E676669e60e7ee50 = false)
{
	global $Fee0d5a474c96306;
	$C65b954f50137019 = BFe9937c6D242a3D($C3c8913edb801c35);

	if (!$C65b954f50137019) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `mag_devices` WHERE `mag_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `mag_claims` WHERE `mag_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `mag_events` WHERE `mag_device_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `mag_logs` WHERE `mag_id` = ?;', $C3c8913edb801c35);

	if (!$C65b954f50137019['user']) {
	} else {
		if ($E676669e60e7ee50) {
			$Fee0d5a474c96306->query('UPDATE `lines` SET `is_mag` = 0 WHERE `id` = ?;', $C65b954f50137019['user']['id']);
			XUI::Bc77EDc4169f1BAA($C65b954f50137019['user']['id']);
		} else {
			$Aa8d8af3d37ca869 = 0;
			$Fee0d5a474c96306->query('SELECT `mag_id` FROM `mag_devices` WHERE `user_id` = ?;', $C65b954f50137019['user']['id']);
			$Aa8d8af3d37ca869 += $Fee0d5a474c96306->num_rows();
			$Fee0d5a474c96306->query('SELECT `device_id` FROM `enigma2_devices` WHERE `user_id` = ?;', $C65b954f50137019['user']['id']);
			$Aa8d8af3d37ca869 += $Fee0d5a474c96306->num_rows();

			if ($Aa8d8af3d37ca869 != 0) {
			} else {
				f8E4778e49869D84($C65b954f50137019['user']['id'], $E88779bc08699291, $f0076b9bca9390cb);
			}
		}
	}

	return true;
}

function deleteMAGs($Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmIDs($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
		return false;
	}

	$b174976b99c4ec48 = array();
	$Fee0d5a474c96306->query('SELECT `user_id` FROM `mag_devices` WHERE `mag_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$b174976b99c4ec48[] = $C740da31596f24ef['user_id'];
	}
	$Fee0d5a474c96306->query('DELETE FROM `mag_devices` WHERE `mag_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `mag_claims` WHERE `mag_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `mag_events` WHERE `mag_device_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `mag_logs` WHERE `mag_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	if (0 >= count($b174976b99c4ec48)) {
	} else {
		deletelines($b174976b99c4ec48);
	}

	return true;
}

function a8cD7C1dF629A648($C3c8913edb801c35, $E88779bc08699291 = false, $f0076b9bca9390cb = true, $E676669e60e7ee50 = false)
{
	global $Fee0d5a474c96306;
	$e2ac750d88db0255 = Ba960CAb7fE0CD93($C3c8913edb801c35);

	if (!$e2ac750d88db0255) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `enigma2_devices` WHERE `device_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `enigma2_actions` WHERE `device_id` = ?;', $C3c8913edb801c35);

	if (!$e2ac750d88db0255['user']) {
	} else {
		if ($E676669e60e7ee50) {
			$Fee0d5a474c96306->query('UPDATE `lines` SET `is_e2` = 0 WHERE `id` = ?;', $e2ac750d88db0255['user']['id']);
			XUI::BC77edC4169F1BAa($e2ac750d88db0255['user']['id']);
		} else {
			$Aa8d8af3d37ca869 = 0;
			$Fee0d5a474c96306->query('SELECT `mag_id` FROM `mag_devices` WHERE `user_id` = ?;', $e2ac750d88db0255['user']['id']);
			$Aa8d8af3d37ca869 += $Fee0d5a474c96306->num_rows();
			$Fee0d5a474c96306->query('SELECT `device_id` FROM `enigma2_devices` WHERE `user_id` = ?;', $e2ac750d88db0255['user']['id']);
			$Aa8d8af3d37ca869 += $Fee0d5a474c96306->num_rows();

			if ($Aa8d8af3d37ca869 != 0) {
			} else {
				f8e4778e49869D84($e2ac750d88db0255['user']['id'], $E88779bc08699291, $f0076b9bca9390cb);
			}
		}
	}

	return true;
}

function deleteEnigmas($Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmIDs($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
		return false;
	}

	$b174976b99c4ec48 = array();
	$Fee0d5a474c96306->query('SELECT `user_id` FROM `enigma2_devices` WHERE `device_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$b174976b99c4ec48[] = $C740da31596f24ef['user_id'];
	}
	$Fee0d5a474c96306->query('DELETE FROM `enigma2_devices` WHERE `device_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `enigma2_actions` WHERE `device_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	if (0 >= count($b174976b99c4ec48)) {
	} else {
		deletelines($b174976b99c4ec48);
	}

	return true;
}

function Bc3DfBAA6322045E($C3c8913edb801c35, $Ab3c1ec7e2add5a3 = true)
{
	global $Fee0d5a474c96306;
	$bbc84f53c534450d = ffd24E407AbB46eB($C3c8913edb801c35);

	if (!$bbc84f53c534450d) {
		return false;
	}

	$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_episodes` WHERE `series_id` = ?;', $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		d13C1A44a4495B05($C740da31596f24ef['stream_id'], -1, $Ab3c1ec7e2add5a3);
	}
	$Fee0d5a474c96306->query('DELETE FROM `streams_episodes` WHERE `series_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `streams_series` WHERE `id` = ?;', $C3c8913edb801c35);
	D4724EC36C96198E();

	return true;
}

function deleteSeriesMass($Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmIDs($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
		return false;
	}

	$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_episodes` WHERE `series_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$Cdb85875fd50f459[] = $C740da31596f24ef['stream_id'];
	}
	$Fee0d5a474c96306->query('DELETE FROM `streams_episodes` WHERE `series_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `streams_series` WHERE `id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	if (0 >= count($Cdb85875fd50f459)) {
	} else {
		deleteStreams($Cdb85875fd50f459, true);
	}

	D4724EC36C96198e();

	return true;
}

function Dc08ddCe27705eCf($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$ddf0508b312dbfb8 = C8AdB574f9477F84($C3c8913edb801c35);

	if (!$ddf0508b312dbfb8) {
		return false;
	}

	$Fee0d5a474c96306->query("SELECT `id`, `bouquet` FROM `lines` WHERE JSON_CONTAINS(`bouquet`, ?, '\$');", $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$C740da31596f24ef['bouquet'] = json_decode($C740da31596f24ef['bouquet'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['bouquet'])) === false) {
		} else {
			unset($C740da31596f24ef['bouquet'][$D3fa098be3f297cd]);
		}

		$Fee0d5a474c96306->query("UPDATE `lines` SET `bouquet` = '[" . implode(',', array_map('intval', $C740da31596f24ef['bouquet'])) . "]' WHERE `id` = ?;", $C740da31596f24ef['id']);
		XUI::Bc77eDC4169F1baa($C740da31596f24ef['id']);
	}
	$Fee0d5a474c96306->query("SELECT `id`, `bouquets` FROM `users_packages` WHERE JSON_CONTAINS(`bouquets`, ?, '\$');", $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$C740da31596f24ef['bouquets'] = json_decode($C740da31596f24ef['bouquets'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['bouquets'])) === false) {
		} else {
			unset($C740da31596f24ef['bouquets'][$D3fa098be3f297cd]);
		}

		$Fee0d5a474c96306->query("UPDATE `users_packages` SET `bouquets` = '[" . implode(',', array_map('intval', $C740da31596f24ef['bouquets'])) . "]' WHERE `id` = ?;", $C740da31596f24ef['id']);
	}
	$Fee0d5a474c96306->query("SELECT `id`, `bouquets` FROM `watch_folders` WHERE JSON_CONTAINS(`bouquets`, ?, '\$') OR JSON_CONTAINS(`fb_bouquets`, ?, '\$');", $C3c8913edb801c35, $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$C740da31596f24ef['bouquets'] = json_decode($C740da31596f24ef['bouquets'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['bouquets'])) === false) {
		} else {
			unset($C740da31596f24ef['bouquets'][$D3fa098be3f297cd]);
		}

		$C740da31596f24ef['fb_bouquets'] = json_decode($C740da31596f24ef['fb_bouquets'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['fb_bouquets'])) === false) {
		} else {
			unset($C740da31596f24ef['fb_bouquets'][$D3fa098be3f297cd]);
		}

		$Fee0d5a474c96306->query("UPDATE `watch_folders` SET `bouquets` = '[" . implode(',', array_map('intval', $C740da31596f24ef['bouquets'])) . "]', `fb_bouquets` = '[" . implode(',', array_map('intval', $C740da31596f24ef['fb_bouquets'])) . "]' WHERE `id` = ?;", $C740da31596f24ef['id']);
	}
	$Fee0d5a474c96306->query('DELETE FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);
	d4724ec36C96198e();

	return true;
}

function dBc1BC20914d084b($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$A1925ae53e9307eb = e0e9955e91FA6027($C3c8913edb801c35);

	if (!$A1925ae53e9307eb) {
		return false;
	}

	$Fee0d5a474c96306->query("SELECT `id`, `category_id` FROM `streams` WHERE JSON_CONTAINS(`category_id`, ?, '\$');", $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$C740da31596f24ef['category_id'] = json_decode($C740da31596f24ef['category_id'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['category_id'])) === false) {
		} else {
			unset($C740da31596f24ef['category_id'][$D3fa098be3f297cd]);
		}

		$Fee0d5a474c96306->query("UPDATE `streams` SET `category_id` = '[" . implode(',', array_map('intval', $C740da31596f24ef['category_id'])) . "]' WHERE `id` = ?;", $C740da31596f24ef['id']);
	}
	$Fee0d5a474c96306->query("SELECT `id`, `category_id` FROM `streams_series` WHERE JSON_CONTAINS(`category_id`, ?, '\$');", $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$C740da31596f24ef['category_id'] = json_decode($C740da31596f24ef['category_id'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['category_id'])) === false) {
		} else {
			unset($C740da31596f24ef['category_id'][$D3fa098be3f297cd]);
		}

		$Fee0d5a474c96306->query("UPDATE `streams_series` SET `category_id` = '[" . implode(',', array_map('intval', $C740da31596f24ef['category_id'])) . "]' WHERE `id` = ?;", $C740da31596f24ef['id']);
	}
	$Fee0d5a474c96306->query('DELETE FROM `streams_categories` WHERE `id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('UPDATE `watch_folders` SET `category_id` = null WHERE `category_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('UPDATE `watch_folders` SET `fb_category_id` = null WHERE `fb_category_id` = ?;', $C3c8913edb801c35);

	return true;
}

function e35e424Dd2C18A18($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$b8a339227222357b = cBC22956B573E5Cc($C3c8913edb801c35);

	if (!$b8a339227222357b) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `profiles` WHERE `profile_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('UPDATE `streams` SET `transcode_profile_id` = 0 WHERE `transcode_profile_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('UPDATE `watch_folders` SET `transcode_profile_id` = 0 WHERE `transcode_profile_id` = ?;', $C3c8913edb801c35);

	return true;
}

function A8eD5BC26ea63263($E708d4730d21125b, $a27e64cc6ce01033)
{
	$ce2460e0c52a99da = array();

	foreach ($E708d4730d21125b as $d58b4f8653a391d8) {
		if (!XUI::$rServers[$d58b4f8653a391d8]['server_online']) {
		} else {
			$ce2460e0c52a99da[$d58b4f8653a391d8] = array('url' => XUI::$rServers[$d58b4f8653a391d8]['api_url'], 'postdata' => $a27e64cc6ce01033);
		}
	}
	XUI::EfB9E3c68A59b340($ce2460e0c52a99da);

	return array('result' => true);
}

function B5f175e537cDef60($d58b4f8653a391d8, $E379394c7b1a273f, $fe4e3e8ff0a114f6, $Daf7ceacf972be2c = false)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $d58b4f8653a391d8, time(), json_encode(array('action' => 'set_port', 'type' => intval($E379394c7b1a273f), 'ports' => $fe4e3e8ff0a114f6, 'reload' => $Daf7ceacf972be2c)));
}

function f455c4FA1194F818($d58b4f8653a391d8, $b0386bfef3742291, $Daf7ceacf972be2c = true)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $d58b4f8653a391d8, time(), json_encode(array('action' => 'set_services', 'count' => intval($b0386bfef3742291), 'reload' => $Daf7ceacf972be2c)));
}

function setGovernor($d58b4f8653a391d8, $Effc9e9fab787acc)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $d58b4f8653a391d8, time(), json_encode(array('action' => 'set_governor', 'data' => $Effc9e9fab787acc)));
}

function setSysctl($d58b4f8653a391d8, $B753706f1970d2b5)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $d58b4f8653a391d8, time(), json_encode(array('action' => 'set_sysctl', 'data' => $B753706f1970d2b5)));
}

function F59F57F8317ab8bE($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query("UPDATE `mag_devices` SET `ip` = '', `ver` = '', `image_version` = '', `stb_type` = '', `sn` = '', `device_id` = '', `device_id2` = '', `hw_version` = '', `token` = '' WHERE `mag_id` = ?;", $C3c8913edb801c35);
}

function B8e27EC7c94b1Bc0($fad73125a2cca3ed)
{
	if (86400 <= $fad73125a2cca3ed) {
		$fad73125a2cca3ed = sprintf('%02dd %02dh %02dm', $fad73125a2cca3ed / 86400, ($fad73125a2cca3ed / 3600) % 24, ($fad73125a2cca3ed / 60) % 60);
	} else {
		$fad73125a2cca3ed = sprintf('%02dh %02dm %02ds', $fad73125a2cca3ed / 3600, ($fad73125a2cca3ed / 60) % 60, $fad73125a2cca3ed % 60);
	}

	return $fad73125a2cca3ed;
}

function A5Fc308345057E29()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `settings` LIMIT 1;');

	return $Fee0d5a474c96306->get_row();
}

function e36EC1583e223bF6($a27e64cc6ce01033, $cd2a4260ef308305 = 5)
{
	ini_set('default_socket_timeout', $cd2a4260ef308305);
	$c85ed032f7e37367 = 'http://127.0.0.1:' . intval(XUI::$rServers[SERVER_ID]['http_broadcast_port']) . '/admin/api';

	if (empty(XUI::$rSettings['api_pass'])) {
	} else {
		$a27e64cc6ce01033['api_pass'] = XUI::$rSettings['api_pass'];
	}

	$E330444f58f09645 = http_build_query($a27e64cc6ce01033);
	$c88afcbaf19918af = curl_init();
	curl_setopt($c88afcbaf19918af, CURLOPT_URL, $c85ed032f7e37367);
	curl_setopt($c88afcbaf19918af, CURLOPT_POST, true);
	curl_setopt($c88afcbaf19918af, CURLOPT_POSTFIELDS, $E330444f58f09645);
	curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($c88afcbaf19918af, CURLOPT_CONNECTTIMEOUT, $cd2a4260ef308305);
	curl_setopt($c88afcbaf19918af, CURLOPT_TIMEOUT, $cd2a4260ef308305);

	return curl_exec($c88afcbaf19918af);
}

function a200986bBae4B322($d58b4f8653a391d8, $a27e64cc6ce01033, $cd2a4260ef308305 = 5)
{
	ini_set('default_socket_timeout', $cd2a4260ef308305);

	if (XUI::$rServers[$d58b4f8653a391d8]['server_online']) {
		$c85ed032f7e37367 = 'http://' . XUI::$rServers[intval($d58b4f8653a391d8)]['server_ip'] . ':' . XUI::$rServers[intval($d58b4f8653a391d8)]['http_broadcast_port'] . '/api';
		$a27e64cc6ce01033['password'] = XUI::$rSettings['live_streaming_pass'];
		$E330444f58f09645 = http_build_query($a27e64cc6ce01033);
		$c88afcbaf19918af = curl_init();
		curl_setopt($c88afcbaf19918af, CURLOPT_URL, $c85ed032f7e37367);
		curl_setopt($c88afcbaf19918af, CURLOPT_POST, true);
		curl_setopt($c88afcbaf19918af, CURLOPT_POSTFIELDS, $E330444f58f09645);
		curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($c88afcbaf19918af, CURLOPT_CONNECTTIMEOUT, $cd2a4260ef308305);
		curl_setopt($c88afcbaf19918af, CURLOPT_TIMEOUT, $cd2a4260ef308305);

		return curl_exec($c88afcbaf19918af);
	}

	return null;
}

function e6E296Dd0051114B($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `watch_folders` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function F1E2F32DcCfd29A4($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `tmdb_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function DB69D33c1707E715()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `streams_series` ORDER BY `title` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function ffD24E407aBb46eb($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function E6d2aED48f58352c($Ddb572d71804d3a6, $rLanguage = null)
{
	$C700a2b357e5ed65 = 'https://api.themoviedb.org/3/tv/' . intval($Ddb572d71804d3a6) . '/videos?api_key=' . urlencode(XUI::$rSettings['tmdb_api_key']);

	if ($rLanguage) {
		$C700a2b357e5ed65 .= '&language=' . urlencode($rLanguage);
	} else {
		if (0 >= strlen(XUI::$rSettings['tmdb_language'])) {
		} else {
			$C700a2b357e5ed65 .= '&language=' . urlencode(XUI::$rSettings['tmdb_language']);
		}
	}

	$Bec25219bd671a85 = json_decode(file_get_contents($C700a2b357e5ed65), true);

	foreach ($Bec25219bd671a85['results'] as $ddf29a8b9c0c6f4f) {
		if (!(strtolower($ddf29a8b9c0c6f4f['type']) == 'trailer' && strtolower($ddf29a8b9c0c6f4f['site']) == 'youtube')) {
		} else {
			return $ddf29a8b9c0c6f4f['key'];
		}
	}

	return '';
}

function C8adb574f9477F84($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `bouquets` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function be15e41e7c4a62ab()
{
	return array();
}

function D7e7f81F646193B2($E379394c7b1a273f, $C52c0b6b0f74407b, $Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;

	if (is_array($Aa8c918a2a91966f)) {
	} else {
		$Aa8c918a2a91966f = array($Aa8c918a2a91966f);
	}

	$ddf0508b312dbfb8 = c8adb574f9477f84($C52c0b6b0f74407b);

	if (!$ddf0508b312dbfb8) {
	} else {
		if ($E379394c7b1a273f == 'stream') {
			$f8d6610081a97651 = 'bouquet_channels';
		} else {
			if ($E379394c7b1a273f == 'movie') {
				$f8d6610081a97651 = 'bouquet_movies';
			} else {
				if ($E379394c7b1a273f == 'radio') {
					$f8d6610081a97651 = 'bouquet_radios';
				} else {
					$f8d6610081a97651 = 'bouquet_series';
				}
			}
		}

		$b8802f4e086a776a = false;
		$f46da30a01f7b2d7 = confirmIDs(json_decode($ddf0508b312dbfb8[$f8d6610081a97651], true));

		foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
			if (0 >= intval($C3c8913edb801c35) || in_array($C3c8913edb801c35, $f46da30a01f7b2d7)) {
			} else {
				$f46da30a01f7b2d7[] = $C3c8913edb801c35;
				$b8802f4e086a776a = true;
			}
		}

		if (!$b8802f4e086a776a) {
		} else {
			$Fee0d5a474c96306->query('UPDATE `bouquets` SET `' . $f8d6610081a97651 . '` = ? WHERE `id` = ?;', '[' . implode(',', array_map('intval', $f46da30a01f7b2d7)) . ']', $C52c0b6b0f74407b);
		}
	}
}

function D83CfF66bcDbee05($E379394c7b1a273f, $C52c0b6b0f74407b, $Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;

	if (is_array($Aa8c918a2a91966f)) {
	} else {
		$Aa8c918a2a91966f = array($Aa8c918a2a91966f);
	}

	$ddf0508b312dbfb8 = c8adb574f9477f84($C52c0b6b0f74407b);

	if (!$ddf0508b312dbfb8) {
	} else {
		if ($E379394c7b1a273f == 'stream') {
			$f8d6610081a97651 = 'bouquet_channels';
		} else {
			if ($E379394c7b1a273f == 'movie') {
				$f8d6610081a97651 = 'bouquet_movies';
			} else {
				if ($E379394c7b1a273f == 'radio') {
					$f8d6610081a97651 = 'bouquet_radios';
				} else {
					$f8d6610081a97651 = 'bouquet_series';
				}
			}
		}

		$b8802f4e086a776a = false;
		$f46da30a01f7b2d7 = confirmIDs(json_decode($ddf0508b312dbfb8[$f8d6610081a97651], true));

		foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
			if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $f46da30a01f7b2d7)) === false) {
			} else {
				unset($f46da30a01f7b2d7[$D3fa098be3f297cd]);
				$b8802f4e086a776a = true;
			}
		}

		if (!$b8802f4e086a776a) {
		} else {
			$Fee0d5a474c96306->query('UPDATE `bouquets` SET `' . $f8d6610081a97651 . '` = ? WHERE `id` = ?;', '[' . implode(',', array_map('intval', $f46da30a01f7b2d7)) . ']', $C52c0b6b0f74407b);
		}
	}
}

function confirmIDs($Aa8c918a2a91966f)
{
	$a85e1b7d42c346a0 = array();

	foreach ($Aa8c918a2a91966f as $C3c8913edb801c35) {
		if (0 >= intval($C3c8913edb801c35)) {
		} else {
			$a85e1b7d42c346a0[] = $C3c8913edb801c35;
		}
	}

	return array_unique($a85e1b7d42c346a0);
}

function e401f74f56E9367f($Bc16cc77a681d1ed, $bc2874292e0d9ece)
{
	require_once XUI_HOME . 'includes/libs/Dropbox.php';
	$C426358e96a98000 = new DropboxClient();

	try {
		$C426358e96a98000->SetBearerToken(array('t' => XUI::$rSettings['dropbox_token']));
		$C426358e96a98000->F55057020733f3bA($Bc16cc77a681d1ed, $bc2874292e0d9ece);

		return true;
	} catch (exception $c34ae71903f0d920) {
		return false;
	}
}

function fc9601411D1d90e4($Bc16cc77a681d1ed)
{
	require_once XUI_HOME . 'includes/libs/Dropbox.php';
	$C426358e96a98000 = new DropboxClient();

	try {
		$C426358e96a98000->SetBearerToken(array('t' => XUI::$rSettings['dropbox_token']));
		$C426358e96a98000->Delete($Bc16cc77a681d1ed);

		return true;
	} catch (exception $c34ae71903f0d920) {
		return false;
	}
}

function e6C35233ad4e96CD($fab84a7bc25d47ab)
{
	if (XUI::$rSettings['parse_type'] == 'guessit') {
		$cf1c389bda3e30fd = XUI_HOME . 'bin/guess ' . escapeshellarg(pathinfo($fab84a7bc25d47ab)['filename'] . '.mkv');
	} else {
		$cf1c389bda3e30fd = '/usr/bin/python3 ' . XUI_HOME . 'includes/python/release.py ' . escapeshellarg(pathinfo(str_replace('-', '_', $fab84a7bc25d47ab))['filename']);
	}

	return json_decode(shell_exec($cf1c389bda3e30fd), true);
}

function F101C1503ABa095b($d58b4f8653a391d8, $aba46ae86a79ad10, $E3b8f15bd840a0df = null)
{
	return json_decode(a200986bbae4b322($d58b4f8653a391d8, array('action' => 'scandir_recursive', 'dir' => $aba46ae86a79ad10, 'allowed' => implode('|', $E3b8f15bd840a0df))), true);
}

function a2c50E6040039E78($d58b4f8653a391d8, $aba46ae86a79ad10, $E3b8f15bd840a0df = null)
{
	return json_decode(a200986bbae4b322($d58b4f8653a391d8, array('action' => 'scandir', 'dir' => $aba46ae86a79ad10, 'allowed' => implode('|', $E3b8f15bd840a0df))), true);
}

function Aa1526517e33A365($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id`, `ip` FROM `blocked_ips` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$C740da31596f24ef = $Fee0d5a474c96306->get_row();
	$Fee0d5a474c96306->query('DELETE FROM `blocked_ips` WHERE `id` = ?;', $C3c8913edb801c35);

	if (!file_exists(FLOOD_TMP_PATH . 'block_' . $C740da31596f24ef['ip'])) {
	} else {
		unlink(FLOOD_TMP_PATH . 'block_' . $C740da31596f24ef['ip']);
	}

	return true;
}

function bc0ec13f813C4Ec5($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `blocked_isps` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `blocked_isps` WHERE `id` = ?;', $C3c8913edb801c35);

	return true;
}

function a67f300C600b609B($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `blocked_uas` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `blocked_uas` WHERE `id` = ?;', $C3c8913edb801c35);

	return true;
}

function CeA678961006676d($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `access_codes` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `access_codes` WHERE `id` = ?;', $C3c8913edb801c35);
	b3c0272304a383cc();

	return true;
}

function ce67E6ac1132A14C($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `hmac_keys` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `hmac_keys` WHERE `id` = ?;', $C3c8913edb801c35);

	return true;
}

function f93bA975A803776F($Ddb572d71804d3a6, $b550d8eef0f542ec, $Bd43537fab08ca31)
{
	$C700a2b357e5ed65 = 'https://api.themoviedb.org/3/tv/' . intval($Ddb572d71804d3a6) . '/season/' . intval($b550d8eef0f542ec) . '/episode/' . intval($Bd43537fab08ca31) . '/images?api_key=' . urlencode(XUI::$rSettings['tmdb_api_key']);

	if (0 >= strlen(XUI::$rSettings['tmdb_language'])) {
	} else {
		$C700a2b357e5ed65 .= '&language=' . urlencode(XUI::$rSettings['tmdb_language']);
	}

	return json_decode(file_get_contents($C700a2b357e5ed65), true);
}

function eEe159FeE39eD442()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `blocked_uas` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function F37b535a34F45ff6()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `blocked_isps` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function getStreamProviders()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `providers` ORDER BY `last_changed` DESC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function getStreamProvider($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `providers` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function e9C60A402F4675e4($E400a3101514583e = 2419200)
{
	global $Fee0d5a474c96306;
	global $D4253f9520627819;
	global $B2ff75c438fb3031;
	$a85e1b7d42c346a0 = array();
	$F3a421506b1b5b24 = array_map('intval', array_merge(array($D4253f9520627819['id']), $B2ff75c438fb3031['all_reports']));

	if (0 >= count($F3a421506b1b5b24)) {
	} else {
		$Fee0d5a474c96306->query('SELECT `is_mag`, `is_e2`, `lines`.`id` AS `line_id`, `lines`.`reseller_notes`, `mag_devices`.`mag_id`, `enigma2_devices`.`device_id` AS `e2_id`, `member_id`, `username`, `password`, `exp_date`, `mag_devices`.`mac` AS `mag_mac`, `enigma2_devices`.`mac` AS `e2_mac` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` LEFT JOIN `enigma2_devices` ON `enigma2_devices`.`user_id` = `lines`.`id` WHERE `member_id` IN (' . implode(',', $F3a421506b1b5b24) . ') AND `exp_date` IS NOT NULL AND `exp_date` >= ? AND `exp_date` < ? ORDER BY `exp_date` ASC LIMIT 250;', time(), time() + $E400a3101514583e);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function a5e3DfEb5FEe1bE6($C3c8913edb801c35 = null, $a19335aa049798c9 = false)
{
	global $Fee0d5a474c96306;
	global $D4253f9520627819;
	global $B2ff75c438fb3031;
	$a85e1b7d42c346a0 = array();

	if ($C3c8913edb801c35) {
		if ($a19335aa049798c9) {
			$Fee0d5a474c96306->query('SELECT `tickets`.`id`, `tickets`.`member_id`, `tickets`.`title`, `tickets`.`status`, `tickets`.`admin_read`, `tickets`.`user_read`, `users`.`username` FROM `tickets`, `users` WHERE `member_id` IN (SELECT `id` FROM `users` WHERE `owner_id` = ?) AND `users`.`id` = `tickets`.`member_id` ORDER BY `id` DESC;', $C3c8913edb801c35);
		} else {
			$Fee0d5a474c96306->query('SELECT `tickets`.`id`, `tickets`.`member_id`, `tickets`.`title`, `tickets`.`status`, `tickets`.`admin_read`, `tickets`.`user_read`, `users`.`username` FROM `tickets`, `users` WHERE `member_id` IN (' . implode(',', array_map('intval', array_merge(array($D4253f9520627819['id']), $B2ff75c438fb3031['all_reports']))) . ') AND `users`.`id` = `tickets`.`member_id` ORDER BY `id` DESC;');
		}
	} else {
		$Fee0d5a474c96306->query('SELECT `tickets`.`id`, `tickets`.`member_id`, `tickets`.`title`, `tickets`.`status`, `tickets`.`admin_read`, `tickets`.`user_read`, `users`.`username` FROM `tickets`, `users` WHERE `users`.`id` = `tickets`.`member_id` ORDER BY `id` DESC;');
	}

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$Fee0d5a474c96306->query('SELECT MIN(`date`) AS `date` FROM `tickets_replies` WHERE `ticket_id` = ?;', $C740da31596f24ef['id']);

			if ($c94b497359f8aed9 = $Fee0d5a474c96306->get_row()['date']) {
				$C740da31596f24ef['created'] = date('Y-m-d H:i', $c94b497359f8aed9);
			} else {
				$C740da31596f24ef['created'] = '';
			}

			$Fee0d5a474c96306->query('SELECT * FROM `tickets_replies` WHERE `ticket_id` = ? ORDER BY `id` DESC LIMIT 1;', $C740da31596f24ef['id']);
			$e030e3553f1aeb5d = $Fee0d5a474c96306->get_row();
			$C740da31596f24ef['last_reply'] = date('Y-m-d H:i', $e030e3553f1aeb5d['date']);

			if ($C740da31596f24ef['member_id'] == $C3c8913edb801c35) {
				if ($C740da31596f24ef['status'] == 0) {
				} else {
					if ($e030e3553f1aeb5d['admin_reply']) {
						if ($C740da31596f24ef['user_read'] == 1) {
							$C740da31596f24ef['status'] = 3;
						} else {
							$C740da31596f24ef['status'] = 4;
						}
					} else {
						if ($C740da31596f24ef['admin_read'] == 1) {
							$C740da31596f24ef['status'] = 5;
						} else {
							$C740da31596f24ef['status'] = 2;
						}
					}
				}
			} else {
				if ($C740da31596f24ef['status'] == 0) {
				} else {
					if ($e030e3553f1aeb5d['admin_reply']) {
						if ($C740da31596f24ef['user_read'] == 1) {
							$C740da31596f24ef['status'] = 6;
						} else {
							$C740da31596f24ef['status'] = 2;
						}
					} else {
						if ($C740da31596f24ef['admin_read'] == 1) {
							$C740da31596f24ef['status'] = 5;
						} else {
							$C740da31596f24ef['status'] = 4;
						}
					}
				}
			}

			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function Df65d36BEA77Ae8c($d5249dad8e8411b7, $Daed747d70ffc570 = 'xui', $c08e855bc87efeb9 = 20000)
{
	if ($Daed747d70ffc570 != '') {
	} else {
		$Daed747d70ffc570 = substr(bin2hex(openssl_random_pseudo_bytes(16)), 0, 16);
	}

	if (stripos($Daed747d70ffc570, 'rounds=')) {
	} else {
		$Daed747d70ffc570 = sprintf('$6$rounds=%d$%s$', $c08e855bc87efeb9, $Daed747d70ffc570);
	}

	return crypt($d5249dad8e8411b7, $Daed747d70ffc570);
}

function C7AfD69EDc2a2940()
{
	return XUI::a9BC416Fa6FA55C3();
}

function F0acf9DE3389b116($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `users_groups` WHERE `group_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		$C740da31596f24ef = $Fee0d5a474c96306->get_row();
		$C740da31596f24ef['subresellers'] = json_decode($C740da31596f24ef['subresellers'], true);

		if (count($C740da31596f24ef['subresellers']) != 0) {
		} else {
			$C740da31596f24ef['create_sub_resellers'] = 0;
		}

		return $C740da31596f24ef;
	}
}

function bC6A5B2af3Da765D($E379394c7b1a273f = 'admin')
{
	global $_SESSION;
	$f16991461acd03bf = array('admin' => array('hash', 'ip', 'code', 'verify', 'last_activity'), 'reseller' => array('reseller', 'rip', 'rcode', 'rverify', 'rlast_activity'), 'player' => array('phash', 'pverify'));

	foreach ($f16991461acd03bf[$E379394c7b1a273f] as $D3fa098be3f297cd) {
		if (!isset($_SESSION[$D3fa098be3f297cd])) {
		} else {
			unset($_SESSION[$D3fa098be3f297cd]);
		}
	}
}

function ac2512AeE1365A60($bbfc9bd8432031f5)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	foreach ($bbfc9bd8432031f5 as $c8d91fcd2309e48a) {
		$Fee0d5a474c96306->query("SELECT `id` FROM `streams` WHERE `type` IN (2,5) AND `stream_source` LIKE ? ESCAPE '|' LIMIT 1;", '%' . str_replace('/', '\\/', $c8d91fcd2309e48a) . '"%');

		if ($Fee0d5a474c96306->num_rows() != 1) {
		} else {
			$a85e1b7d42c346a0[] = intval($Fee0d5a474c96306->get_row()['id']);
		}
	}

	return $a85e1b7d42c346a0;
}

function f4E14f6fe7A86D2c()
{
	$f592b55eda404013 = array();

	foreach (scandir(XUI_HOME . 'backups/') as $db13ebf912ff273c) {
		$Eea1b980ebbe2a33 = pathinfo(XUI_HOME . 'backups/' . $db13ebf912ff273c);

		if ($Eea1b980ebbe2a33['extension'] != 'sql') {
		} else {
			$f592b55eda404013[] = array('filename' => $db13ebf912ff273c, 'timestamp' => filemtime(XUI_HOME . 'backups/' . $db13ebf912ff273c), 'date' => date('Y-m-d H:i:s', filemtime(XUI_HOME . 'backups/' . $db13ebf912ff273c)), 'filesize' => filesize(XUI_HOME . 'backups/' . $db13ebf912ff273c));
		}
	}
	usort(
		$f592b55eda404013,
		function($d7e6e8fcd8d94d98, $dbc1091ca2977adb) {
			return $d7e6e8fcd8d94d98['timestamp'];
		}
	);

	return $f592b55eda404013;
}

function cc4F1891921C3857()
{
	require_once XUI_HOME . 'includes/libs/Dropbox.php';

	try {
		$C426358e96a98000 = new DropboxClient();
		$C426358e96a98000->SetBearerToken(array('t' => XUI::$rSettings['dropbox_token']));
		$C426358e96a98000->GetFiles();

		return true;
	} catch (exception $c34ae71903f0d920) {
		return false;
	}
}

function c643339B29c504e4()
{
	require_once XUI_HOME . 'includes/libs/Dropbox.php';

	try {
		$C426358e96a98000 = new DropboxClient();
		$C426358e96a98000->SetBearerToken(array('t' => XUI::$rSettings['dropbox_token']));
		$b93e6a2691d72853 = $C426358e96a98000->GetFiles();
	} catch (exception $c34ae71903f0d920) {
		$b93e6a2691d72853 = array();
	}
	$f592b55eda404013 = array();

	foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
		try {
			if (!(!$e2f848a82a80c113->isDir && strtolower(pathinfo($e2f848a82a80c113->name)['extension']) == 'sql' && 0 < $e2f848a82a80c113->size)) {
			} else {
				$Bec25219bd671a85 = json_decode(json_encode($e2f848a82a80c113, JSON_UNESCAPED_UNICODE), true);
				$Bec25219bd671a85['time'] = strtotime($e2f848a82a80c113->server_modified);
				$f592b55eda404013[] = $Bec25219bd671a85;
			}
		} catch (exception $c34ae71903f0d920) {
		}
	}
	array_multisort(array_column($f592b55eda404013, 'time'), SORT_ASC, $f592b55eda404013);

	return $f592b55eda404013;
}

function D01567dd21366868($Bc16cc77a681d1ed, $bc2874292e0d9ece, $aada6b4a73d4f74e = true)
{
	require_once XUI_HOME . 'includes/libs/Dropbox.php';
	$C426358e96a98000 = new DropboxClient();

	try {
		$C426358e96a98000->SetBearerToken(array('t' => XUI::$rSettings['dropbox_token']));

		return $C426358e96a98000->UploadFile($bc2874292e0d9ece, $Bc16cc77a681d1ed, $aada6b4a73d4f74e);
	} catch (exception $c34ae71903f0d920) {
		return (object) array('error' => $c34ae71903f0d920);
	}
}

function restoreImages()
{
	global $Fee0d5a474c96306;

	foreach (array_keys(XUI::$rServers) as $d58b4f8653a391d8) {
		if (!XUI::$rServers[$d58b4f8653a391d8]['server_online']) {
		} else {
			a200986bbae4b322($d58b4f8653a391d8, array('action' => 'restore_images'));
		}
	}

	return true;
}

function C807Fa5b46e2de60()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query("SELECT DISTINCT(`server_id`) AS `server_id` FROM `watch_folders` WHERE `active` = 11 AND `type` <> 'plex';");

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if (!XUI::$rServers[$C740da31596f24ef['server_id']]['server_online']) {
		} else {
			a200986bbae4b322($C740da31596f24ef['server_id'], array('action' => 'kill_watch'));
		}
	}

	return true;
}

function e6699420777697c4()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query("SELECT DISTINCT(`server_id`) AS `server_id` FROM `watch_folders` WHERE `active` = 1 AND `type` = 'plex';");

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if (!XUI::$rServers[$C740da31596f24ef['server_id']]['server_online']) {
		} else {
			a200986bbae4b322($C740da31596f24ef['server_id'], array('action' => 'kill_plex'));
		}
	}

	return true;
}

function A384500bAd4447A8($d58b4f8653a391d8)
{
	$a85e1b7d42c346a0 = array();
	$D238fb37ea40fafb = json_decode(a200986bbae4b322($d58b4f8653a391d8, array('action' => 'get_pids')), true);
	array_shift($D238fb37ea40fafb);

	foreach ($D238fb37ea40fafb as $Df1e7eea7d843145) {
		$B211d7401e6242f3 = explode(' ', preg_replace('!\\s+!', ' ', trim($Df1e7eea7d843145)));

		if ($B211d7401e6242f3[0] != 'xui') {
		} else {
			$a77daf9df0093a16 = array(0, 0, 0);
			$b474f9b1144a5e0e = explode('-', $B211d7401e6242f3[9]);

			if (1 < count($b474f9b1144a5e0e)) {
				$cd539c9a539b9f0a = intval($b474f9b1144a5e0e[0]);
				$C4af185e24cf9086 = $b474f9b1144a5e0e[1];
			} else {
				$cd539c9a539b9f0a = 0;
				$C4af185e24cf9086 = $b474f9b1144a5e0e[0];
			}

			$C4af185e24cf9086 = explode(':', $C4af185e24cf9086);

			if (count($C4af185e24cf9086 == 3)) {
				$eff3c5536b319f0b = intval($C4af185e24cf9086[0]) * 3600 + intval($C4af185e24cf9086[1]) * 60 + intval($C4af185e24cf9086[2]);
			} else {
				if (count($C4af185e24cf9086) == 2) {
					$eff3c5536b319f0b = intval($C4af185e24cf9086[0]) * 60 + intval($C4af185e24cf9086[1]);
				} else {
					$eff3c5536b319f0b = intval($C4af185e24cf9086[2]);
				}
			}

			$a77daf9df0093a16[0] = $eff3c5536b319f0b + $cd539c9a539b9f0a * 86400;
			$b474f9b1144a5e0e = explode('-', $B211d7401e6242f3[8]);

			if (1 < count($b474f9b1144a5e0e)) {
				$cd539c9a539b9f0a = intval($b474f9b1144a5e0e[0]);
				$C4af185e24cf9086 = $b474f9b1144a5e0e[1];
			} else {
				$cd539c9a539b9f0a = 0;
				$C4af185e24cf9086 = $b474f9b1144a5e0e[0];
			}

			$C4af185e24cf9086 = explode(':', $C4af185e24cf9086);

			if (count($C4af185e24cf9086 == 3)) {
				$eff3c5536b319f0b = intval($C4af185e24cf9086[0]) * 3600 + intval($C4af185e24cf9086[1]) * 60 + intval($C4af185e24cf9086[2]);
			} else {
				if (count($C4af185e24cf9086) == 2) {
					$eff3c5536b319f0b = intval($C4af185e24cf9086[0]) * 60 + intval($C4af185e24cf9086[1]);
				} else {
					$eff3c5536b319f0b = intval($C4af185e24cf9086[2]);
				}
			}

			$a77daf9df0093a16[1] = $eff3c5536b319f0b + $cd539c9a539b9f0a * 86400;
			$a77daf9df0093a16[2] = $a77daf9df0093a16[1] / $a77daf9df0093a16[0] * 100;
			$a85e1b7d42c346a0[] = array('user' => $B211d7401e6242f3[0], 'pid' => $B211d7401e6242f3[1], 'cpu' => $B211d7401e6242f3[2], 'mem' => $B211d7401e6242f3[3], 'vsz' => $B211d7401e6242f3[4], 'rss' => $B211d7401e6242f3[5], 'tty' => $B211d7401e6242f3[6], 'stat' => $B211d7401e6242f3[7], 'time' => $a77daf9df0093a16[1], 'etime' => $a77daf9df0093a16[0], 'load_average' => $a77daf9df0093a16[2], 'command' => implode(' ', array_splice($B211d7401e6242f3, 10, count($B211d7401e6242f3) - 10)));
		}
	}

	return $a85e1b7d42c346a0;
}

function DF627deA2E5cD3Cb()
{
	unlink(CACHE_TMP_PATH . 'settings');
}

function e4C6429A95c776cF($C3c8913edb801c35, $Cf5f3c0db413b320 = false, $e7eaa7d8c78413f1 = false, $d481bdda1eae677a = null)
{
	global $Fee0d5a474c96306;
	$d51e425eb7375255 = fe76C4bCAF81Baa4($C3c8913edb801c35);

	if (!$d51e425eb7375255) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `users` WHERE `id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `users_credits_logs` WHERE `admin_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `users_logs` WHERE `owner` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `tickets_replies` WHERE `ticket_id` IN (SELECT `id` FROM `tickets` WHERE `member_id` = ?);', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `tickets` WHERE `member_id` = ?;', $C3c8913edb801c35);

	if ($Cf5f3c0db413b320) {
		$Fee0d5a474c96306->query('SELECT `id` FROM `users` WHERE `owner_id` = ?;', $C3c8913edb801c35);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			e4C6429a95C776CF($C740da31596f24ef['id'], $Cf5f3c0db413b320, $e7eaa7d8c78413f1, $d481bdda1eae677a);
		}
	} else {
		$Fee0d5a474c96306->query('UPDATE `users` SET `owner_id` = ? WHERE `owner_id` = ?;', $d481bdda1eae677a, $C3c8913edb801c35);
	}

	if ($e7eaa7d8c78413f1) {
		$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `member_id` = ?;', $C3c8913edb801c35);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			f8e4778e49869D84($C740da31596f24ef['id']);
		}
	} else {
		$Fee0d5a474c96306->query('UPDATE `lines` SET `member_id` = ? WHERE `member_id` = ?;', $d481bdda1eae677a, $C3c8913edb801c35);
	}

	return true;
}

function deleteUsers($Aa8c918a2a91966f)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmids($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `users` WHERE `id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `users_credits_logs` WHERE `admin_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `users_logs` WHERE `owner` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('DELETE FROM `tickets_replies` WHERE `ticket_id` IN (SELECT `id` FROM `tickets` WHERE `member_id` IN (' . implode(',', $Aa8c918a2a91966f) . '));');
	$Fee0d5a474c96306->query('DELETE FROM `tickets` WHERE `member_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('UPDATE `users` SET `owner_id` = NULL WHERE `owner_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
	$Fee0d5a474c96306->query('UPDATE `lines` SET `member_id` = NULL WHERE `member_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');

	return true;
}

function d13c1A44A4495b05($C3c8913edb801c35, $d58b4f8653a391d8 = -1, $Ab3c1ec7e2add5a3 = true, $f2d619cb38696890 = true)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id`, `type` FROM `streams` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$E379394c7b1a273f = $Fee0d5a474c96306->get_row()['type'];
	$c9cdf5b680dc2a9a = 0;

	if ($d58b4f8653a391d8 == -1) {
	} else {
		$Fee0d5a474c96306->query('SELECT `server_stream_id` FROM `streams_servers` WHERE `stream_id` = ? AND `server_id` <> ?;', $C3c8913edb801c35, $d58b4f8653a391d8);
		$c9cdf5b680dc2a9a = $Fee0d5a474c96306->num_rows();
	}

	if ($c9cdf5b680dc2a9a == 0 && $f2d619cb38696890) {
		$Fee0d5a474c96306->query('DELETE FROM `lines_logs` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `mag_claims` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `streams` WHERE `id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `streams_episodes` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `streams_errors` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `streams_logs` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `streams_options` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `streams_stats` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `watch_refresh` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('DELETE FROM `recordings` WHERE `created_id` = ? OR `stream_id` = ?;', $C3c8913edb801c35, $C3c8913edb801c35);
		$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `stream_id` = 0 WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$Fee0d5a474c96306->query('SELECT `server_id` FROM `streams_servers` WHERE `stream_id` = ?;', $C3c8913edb801c35);
		$E708d4730d21125b = array();

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$E708d4730d21125b[] = $C740da31596f24ef['server_id'];
		}

		if (!($Ab3c1ec7e2add5a3 && 0 < count($E708d4730d21125b) && in_array($E379394c7b1a273f, array(2, 5)))) {
		} else {
			FF7f5b67c85bDD34($E708d4730d21125b, $C3c8913edb801c35);
		}

		$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `stream_id` = ?;', $C3c8913edb801c35);
	} else {
		$E708d4730d21125b = array($d58b4f8653a391d8);
		$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `stream_id` = ? AND `server_id` = ?;', $C3c8913edb801c35, $d58b4f8653a391d8);

		if (!($Ab3c1ec7e2add5a3 && in_array($E379394c7b1a273f, array(2, 5)))) {
		} else {
			fF7F5b67c85Bdd34(array($d58b4f8653a391d8), $C3c8913edb801c35);
		}
	}

	$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `parent_id` IS NOT NULL AND `parent_id` > 0 AND `parent_id` NOT IN (SELECT `id` FROM `servers` WHERE `server_type` = 0);');
	XUI::AFa0f3FFb001B9BE($C3c8913edb801c35);
	d4724Ec36C96198E();

	return true;
}

function deleteStreams($Aa8c918a2a91966f, $Ab3c1ec7e2add5a3 = false)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmids($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
	} else {
		$Fee0d5a474c96306->query('DELETE FROM `lines_logs` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `mag_claims` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams` WHERE `id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_episodes` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_errors` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_logs` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_options` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_stats` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `watch_refresh` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `watch_logs` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `lines_live` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `recordings` WHERE `created_id` IN (' . implode(',', $Aa8c918a2a91966f) . ') OR `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `stream_id` = 0 WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('SELECT `server_id` FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');');
		$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `parent_id` IS NOT NULL AND `parent_id` > 0 AND `parent_id` NOT IN (SELECT `id` FROM `servers` WHERE `server_type` = 0);');
		$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `cache`, `time`, `custom_data`) VALUES(?, 1, ?, ?);', SERVER_ID, time(), json_encode(array('type' => 'update_streams', 'id' => $Aa8c918a2a91966f)));

		if (!$Ab3c1ec7e2add5a3) {
		} else {
			foreach (array_keys(XUI::$rServers) as $d58b4f8653a391d8) {
				$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`, `cache`) VALUES(?, ?, ?, 1);', $d58b4f8653a391d8, time(), json_encode(array('type' => 'delete_vods', 'id' => $Aa8c918a2a91966f)));
			}
		}

		D4724EC36c96198E();
	}

	return true;
}

function deleteStreamsByServer($Aa8c918a2a91966f, $d58b4f8653a391d8, $Ab3c1ec7e2add5a3 = false)
{
	global $Fee0d5a474c96306;
	$Aa8c918a2a91966f = confirmids($Aa8c918a2a91966f);

	if (0 >= count($Aa8c918a2a91966f)) {
	} else {
		$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `server_id` = ? AND `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');', $d58b4f8653a391d8);
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `parent_id` = NULL WHERE `parent_id` = ? AND `stream_id` IN (' . implode(',', $Aa8c918a2a91966f) . ');', $d58b4f8653a391d8);

		if (!$Ab3c1ec7e2add5a3) {
		} else {
			$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`, `cache`) VALUES(?, ?, ?, 1);', $d58b4f8653a391d8, time(), json_encode(array('type' => 'delete_vods', 'id' => $Aa8c918a2a91966f)));
		}

		D4724Ec36C96198e();
	}

	return true;
}

function Fa3A80ba9EFF25da()
{
	global $Fee0d5a474c96306;
	global $a8bb73cba48fb7f6;
	global $Fd8279be5302940a;
	$Fee0d5a474c96306->query('TRUNCATE `blocked_ips`;');
	shell_exec('rm ' . FLOOD_TMP_PATH . 'block_*');

	foreach ($a8bb73cba48fb7f6 as $e81220b4451f37c9) {
		$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $e81220b4451f37c9['id'], time(), json_encode(array('action' => 'flush')));
	}

	foreach ($Fd8279be5302940a as $e81220b4451f37c9) {
		$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`) VALUES(?, ?, ?);', $e81220b4451f37c9['id'], time(), json_encode(array('action' => 'flush')));
	}

	return true;
}

function Df16d99A5B990A34()
{
	global $Fee0d5a474c96306;
	require_once XUI_HOME . 'includes/libs/tmdb.php';

	if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
	} else {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
	}

	$f56d34a8caa2dccc = array(1 => array(), 2 => array());
	$Fee0d5a474c96306->query('SELECT `id`, `type`, `genre_id` FROM `watch_categories`;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if (!in_array($C740da31596f24ef['genre_id'], $f56d34a8caa2dccc[$C740da31596f24ef['type']])) {
			} else {
				$Fee0d5a474c96306->query('DELETE FROM `watch_categories` WHERE `id` = ?;', $C740da31596f24ef['id']);
			}

			$f56d34a8caa2dccc[$C740da31596f24ef['type']][] = $C740da31596f24ef['genre_id'];
		}
	}

	$fd346b3fd55156a4 = $a69d576081840514->getMovieGenres();

	foreach ($fd346b3fd55156a4 as $Bb916d50f20b8faf) {
		if (in_array($Bb916d50f20b8faf->getID(), $f56d34a8caa2dccc[1])) {
		} else {
			$Fee0d5a474c96306->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(1, ?, ?, 0, '[]');", $Bb916d50f20b8faf->getID(), $Bb916d50f20b8faf->getName());
		}

		if (in_array($Bb916d50f20b8faf->getID(), $f56d34a8caa2dccc[2])) {
		} else {
			$Fee0d5a474c96306->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(2, ?, ?, 0, '[]');", $Bb916d50f20b8faf->getID(), $Bb916d50f20b8faf->getName());
		}
	}
	$Fd574e524cb90955 = $a69d576081840514->getTVGenres();

	foreach ($Fd574e524cb90955 as $d131b243fc2ad8ea) {
		if (in_array($d131b243fc2ad8ea->getID(), $f56d34a8caa2dccc[1])) {
		} else {
			$Fee0d5a474c96306->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(1, ?, ?, 0, '[]');", $d131b243fc2ad8ea->getID(), $d131b243fc2ad8ea->getName());
		}

		if (in_array($d131b243fc2ad8ea->getID(), $f56d34a8caa2dccc[2])) {
		} else {
			$Fee0d5a474c96306->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(2, ?, ?, 0, '[]');", $d131b243fc2ad8ea->getID(), $d131b243fc2ad8ea->getName());
		}
	}
}

function B46f5dd76f3C7421()
{
	header('Location: dashboard');

	exit();
}

function fb8be7718A40980e($ddf21fc658e95052 = null)
{
	global $B2ff75c438fb3031;

	if ($ddf21fc658e95052) {
	} else {
		$ddf21fc658e95052 = strtolower(basename($_SERVER['SCRIPT_FILENAME'], '.php'));
	}

	switch ($ddf21fc658e95052) {
		case 'user':
		case 'users':
			return $B2ff75c438fb3031['create_sub_resellers'];

		case 'line':
		case 'lines':
			return $B2ff75c438fb3031['create_line'];

		case 'mag':
		case 'mags':
			return $B2ff75c438fb3031['create_mag'];

		case 'enigma':
		case 'enigmas':
			return $B2ff75c438fb3031['create_enigma'];

		case 'epg_view':
		case 'streams':
		case 'created_channels':
		case 'movies':
		case 'episodes':
		case 'radios':
			return $B2ff75c438fb3031['can_view_vod'];

		case 'live_connections':
		case 'line_activity':
			return $B2ff75c438fb3031['reseller_client_connection_logs'];
	}

	return true;
}

function B1882dF698b44754($ddf21fc658e95052 = null)
{
	if ($ddf21fc658e95052) {
	} else {
		$ddf21fc658e95052 = strtolower(basename($_SERVER['SCRIPT_FILENAME'], '.php'));
	}

	switch ($ddf21fc658e95052) {
		case 'isps':
		case 'isp':
		case 'asns':
			return aacd47d8157a1a09('adv', 'block_isps');

		case 'bouquet':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_bouquet')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_bouquet')) {
			} else {
				return true;
			}

			// no break
		case 'bouquet_order':
		case 'bouquet_sort':
			return aacd47d8157a1a09('adv', 'edit_bouquet');

		case 'bouquets':
			return aacd47d8157a1a09('adv', 'bouquets');

		case 'channel_order':
			return aacd47d8157a1a09('adv', 'channel_order');

		case 'client_logs':
			return aacd47d8157a1a09('adv', 'client_request_log');

		case 'created_channel':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_cchannel')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'create_channel')) {
			} else {
				return true;
			}

			// no break
		case 'code':
		case 'codes':
			return aacd47d8157a1a09('adv', 'add_code');

		case 'hmac':
		case 'hmacs':
			return aacd47d8157a1a09('adv', 'add_hmac');

		case 'credit_logs':
			return aacd47d8157a1a09('adv', 'credits_log');

		case 'enigmas':
			return aacd47d8157a1a09('adv', 'manage_e2');

		case 'epg':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'epg_edit')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_epg')) {
			} else {
				return true;
			}

			// no break
		case 'epgs':
			return aacd47d8157a1a09('adv', 'epg');

		case 'episode':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_episode')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_episode')) {
			} else {
				return true;
			}

			// no break
		case 'episodes':
			return aacd47d8157a1a09('adv', 'episodes');

		case 'series_mass':
		case 'episodes_mass':
			return aacd47d8157a1a09('adv', 'mass_sedits');

		case 'fingerprint':
			return aacd47d8157a1a09('adv', 'fingerprint');

		case 'group':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_group')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_group')) {
			} else {
				return true;
			}

			// no break
		case 'groups':
			return aacd47d8157a1a09('adv', 'mng_groups');

		case 'ip':
		case 'ips':
			return aacd47d8157a1a09('adv', 'block_ips');

		case 'live_connections':
			return aacd47d8157a1a09('adv', 'live_connections');

		case 'mag':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_mag')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_mag')) {
				break;
			}

			return true;

		case 'mag_events':
			return aacd47d8157a1a09('adv', 'manage_events');

		case 'mags':
			return aacd47d8157a1a09('adv', 'manage_mag');

		case 'mass_delete':
			return aacd47d8157a1a09('adv', 'mass_delete');

		case 'record':
			return aacd47d8157a1a09('adv', 'add_movie');

		case 'recordings':
			return aacd47d8157a1a09('adv', 'movies');

		case 'queue':
			return aacd47d8157a1a09('adv', 'streams') || aacd47d8157a1a09('adv', 'episodes') || aacd47d8157a1a09('adv', 'series');

		case 'movie':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_movie')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_movie')) {
			} else {
				if (isset(XUI::$rRequest['import']) && !aacd47d8157a1a09('adv', 'import_movies')) {
				} else {
					return true;
				}
			}

			break;

		case 'movie_mass':
			return aacd47d8157a1a09('adv', 'mass_sedits_vod');

		case 'movies':
			return aacd47d8157a1a09('adv', 'movies');

		case 'package':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_package')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_packages')) {
				break;
			}

			return true;

		case 'packages':
		case 'addons':
			return aacd47d8157a1a09('adv', 'mng_packages');

		case 'player':
			return aacd47d8157a1a09('adv', 'player');

		case 'process_monitor':
			return aacd47d8157a1a09('adv', 'process_monitor');

		case 'profile':
			return aacd47d8157a1a09('adv', 'tprofile');

		case 'profiles':
			return aacd47d8157a1a09('adv', 'tprofiles');

		case 'radio':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_radio')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_radio')) {
				break;
			}

			return true;

		case 'radio_mass':
			return aacd47d8157a1a09('adv', 'mass_edit_radio');

		case 'radios':
			return aacd47d8157a1a09('adv', 'radio');

		case 'user':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_reguser')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_reguser')) {
				break;
			}

			return true;

		case 'user_logs':
			return aacd47d8157a1a09('adv', 'reg_userlog');

		case 'users':
			return aacd47d8157a1a09('adv', 'mng_regusers');

		case 'rtmp_ip':
			return aacd47d8157a1a09('adv', 'add_rtmp');

		case 'rtmp_ips':
		case 'rtmp_monitor':
			return aacd47d8157a1a09('adv', 'rtmp');

		case 'serie':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_series')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_series')) {
				break;
			}

			return true;

		case 'series':
			return aacd47d8157a1a09('adv', 'series');

		case 'series_order':
			return aacd47d8157a1a09('adv', 'edit_series');

		case 'server':
		case 'proxy':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_server')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_server')) {
				break;
			}

			return true;

		case 'server_install':
			return aacd47d8157a1a09('adv', 'add_server');

		case 'servers':
		case 'server_view':
		case 'server_order':
		case 'proxies':
			return aacd47d8157a1a09('adv', 'servers');

		case 'settings':
			return aacd47d8157a1a09('adv', 'settings');

		case 'license_info':
			return aacd47d8157a1a09('adv', 'license');

		case 'backups':
		case 'cache':
		case 'setup':
			return aacd47d8157a1a09('adv', 'database');

		case 'settings_watch':
		case 'settings_plex':
			return aacd47d8157a1a09('adv', 'folder_watch_settings');

		case 'stream':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_stream')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_stream')) {
			} else {
				if (isset(XUI::$rRequest['import']) && !aacd47d8157a1a09('adv', 'import_streams')) {
				} else {
					return true;
				}
			}

			break;

		case 'review':
			return aacd47d8157a1a09('adv', 'import_streams');

		case 'mass_edit_streams':
			return aacd47d8157a1a09('adv', 'edit_stream');

		case 'stream_categories':
			return aacd47d8157a1a09('adv', 'categories');

		case 'stream_category':
			return aacd47d8157a1a09('adv', 'add_cat');

		case 'stream_errors':
			return aacd47d8157a1a09('adv', 'stream_errors');

		case 'created_channel_mass':
		case 'stream_mass':
			return aacd47d8157a1a09('adv', 'mass_edit_streams');

		case 'user_mass':
			return aacd47d8157a1a09('adv', 'mass_edit_users');

		case 'mag_mass':
			return aacd47d8157a1a09('adv', 'mass_edit_mags');

		case 'enigma_mass':
			return aacd47d8157a1a09('adv', 'mass_edit_enigmas');

		case 'quick_tools':
			return aacd47d8157a1a09('adv', 'quick_tools');

		case 'stream_tools':
			return aacd47d8157a1a09('adv', 'stream_tools');

		case 'stream_view':
		case 'provider':
		case 'providers':
		case 'streams':
		case 'epg_view':
		case 'created_channels':
		case 'stream_rank':
		case 'archive':
			return aacd47d8157a1a09('adv', 'streams');

		case 'ticket':
			return aacd47d8157a1a09('adv', 'ticket');

		case 'ticket_view':
		case 'tickets':
			return aacd47d8157a1a09('adv', 'manage_tickets');

		case 'line':
			if (isset(XUI::$rRequest['id']) && aacd47d8157a1a09('adv', 'edit_user')) {
				return true;
			}

			if (isset(XUI::$rRequest['id']) || !aacd47d8157a1a09('adv', 'add_user')) {
				break;
			}

			return true;

		case 'line_activity':
		case 'theft_detection':
		case 'line_ips':
			return aacd47d8157a1a09('adv', 'connection_logs');

		case 'line_mass':
			return aacd47d8157a1a09('adv', 'mass_edit_lines');

		case 'useragents':
		case 'useragent':
			return aacd47d8157a1a09('adv', 'block_uas');

		case 'lines':
			return aacd47d8157a1a09('adv', 'users');

		case 'plex':
		case 'watch':
			return aacd47d8157a1a09('adv', 'folder_watch');

		case 'plex_add':
		case 'watch_add':
			return aacd47d8157a1a09('adv', 'folder_watch_add');

		case 'watch_output':
			return aacd47d8157a1a09('adv', 'folder_watch_output');

		case 'mysql_syslog':
		case 'panel_logs':
			return aacd47d8157a1a09('adv', 'panel_logs');

		case 'login_logs':
			return aacd47d8157a1a09('adv', 'login_logs');

		case 'restream_logs':
			return aacd47d8157a1a09('adv', 'restream_logs');

		default:
			return true;
	}
}

function D19B453Ac8e32C50($D307572f7986a746 = null, $E379394c7b1a273f = null)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `users_packages` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if (isset($D307572f7986a746) && !in_array(intval($D307572f7986a746), json_decode($C740da31596f24ef['groups'], true))) {
			} else {
				if ($E379394c7b1a273f && !$C740da31596f24ef['is_' . $E379394c7b1a273f]) {
				} else {
					$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
				}
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function C26E8c91D782c235($db46a98adf9534ea, $e1aa7f3d1b897ca9)
{
	$C698278a8409bc2d = f0AcAb09E248Fc13($db46a98adf9534ea);
	$cff95abd7404b9ff = f0ACAb09E248fc13($e1aa7f3d1b897ca9);
	$f03f005ea6f01679 = true;

	if (!($C698278a8409bc2d && $cff95abd7404b9ff)) {
	} else {
		foreach (array('bouquets', 'output_formats') as $D3fa098be3f297cd) {
			if (json_decode($C698278a8409bc2d[$D3fa098be3f297cd], true) == json_decode($cff95abd7404b9ff[$D3fa098be3f297cd], true)) {
			} else {
				$f03f005ea6f01679 = false;
			}
		}

		foreach (array('is_restreamer', 'is_isplock', 'max_connections', 'force_server_id', 'forced_country', 'lock_device') as $D3fa098be3f297cd) {
			if ($C698278a8409bc2d[$D3fa098be3f297cd] == $cff95abd7404b9ff[$D3fa098be3f297cd]) {
			} else {
				$f03f005ea6f01679 = false;
			}
		}
	}

	return $f03f005ea6f01679;
}

function f0AcAB09e248FC13($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `users_packages` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function b0492aE58018CE29($E379394c7b1a273f = null)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	if (!is_null($E379394c7b1a273f)) {
		$Fee0d5a474c96306->query('SELECT * FROM `access_codes` WHERE `type` = ? ORDER BY `id` ASC;', $E379394c7b1a273f);
	} else {
		$Fee0d5a474c96306->query('SELECT * FROM `access_codes` ORDER BY `id` ASC;');
	}

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function b49a6A53aBB5a42b($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `access_codes` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function C1613A7a31d0c372($d58b4f8653a391d8, $E45885a3d47bc07e)
{
	return a200986bbae4b322($d58b4f8653a391d8, array('action' => 'closeConnection', 'activity_id' => intval($E45885a3d47bc07e)));
}

function a6F6570155dc361d($d58b4f8653a391d8)
{
	return a200986bbae4b322($d58b4f8653a391d8, array('action' => 'get_certificate_info'));
}

function d14a0C6CA02fCe17($b6f0b24a56fe41b6)
{
	if (75 <= $b6f0b24a56fe41b6) {
		return 'bg-danger';
	}

	if (50 <= $b6f0b24a56fe41b6) {
		return 'bg-warning';
	}

	return 'bg-success';
}

function b170d5239F724AC6($d58b4f8653a391d8)
{
	global $Fee0d5a474c96306;
	$D238fb37ea40fafb = array();
	$e81220b4451f37c9 = eecb64fD7d6b8430($d58b4f8653a391d8);
	$E6268540ff97678a = json_decode($e81220b4451f37c9['gpu_info'], true);

	if (!is_array($E6268540ff97678a)) {
	} else {
		foreach ($E6268540ff97678a['gpus'] as $d5aa7e5e1de00526) {
			foreach ($d5aa7e5e1de00526['processes'] as $Df1e7eea7d843145) {
				$d49041d5f05a9270 = array('pid' => $Df1e7eea7d843145['pid'], 'memory' => $Df1e7eea7d843145['memory'], 'stream_id' => null);
				$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_servers` WHERE `pid` = ? AND `server_id` = ?;', $Df1e7eea7d843145['pid'], $d58b4f8653a391d8);

				if (0 >= $Fee0d5a474c96306->num_rows()) {
				} else {
					$d49041d5f05a9270['stream_id'] = $Fee0d5a474c96306->get_row()['stream_id'];
				}

				$D238fb37ea40fafb[] = $d49041d5f05a9270;
			}
		}
	}

	return $D238fb37ea40fafb;
}

function f8E4778e49869D84($C3c8913edb801c35, $E88779bc08699291 = false, $f0076b9bca9390cb = true)
{
	global $Fee0d5a474c96306;
	$Ff014d0ebd314fcd = B4036EF9a1DB8473($C3c8913edb801c35);

	if (!$Ff014d0ebd314fcd) {
		return false;
	}

	XUI::d6D7dcA66bbF5219($C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `lines` WHERE `id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `lines_logs` WHERE `user_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `user_id` = 0 WHERE `user_id` = ?;', $C3c8913edb801c35);

	if (!$f0076b9bca9390cb) {
	} else {
		if (XUI::$rSettings['redis_handler']) {
			foreach (XUI::d92DE48c36cF9438($C3c8913edb801c35, null, null, true, false, false) as $e110a2ab6d3a4734) {
				XUI::E8e9D6B2b107D8ae($e110a2ab6d3a4734);
			}
		} else {
			$Fee0d5a474c96306->query('SELECT * FROM `lines_live` WHERE `user_id` = ?;', $C3c8913edb801c35);

			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				XUI::e8E9d6b2b107D8AE($C740da31596f24ef);
			}
		}
	}

	$Fee0d5a474c96306->query('SELECT `id` FROM `lines` WHERE `pair_id` = ?;', $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		if ($E88779bc08699291) {
			F8e4778e49869d84($C740da31596f24ef['id'], true, $f0076b9bca9390cb);
		} else {
			$Fee0d5a474c96306->query('UPDATE `lines` SET `pair_id` = null WHERE `id` = ?;', $C740da31596f24ef['id']);
			XUI::bc77EdC4169F1BAa($C740da31596f24ef['id']);
		}
	}

	return true;
}

function bAbdbAe2BE721c62($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `rtmp_ips` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `rtmp_ips` WHERE `id` = ?;', $C3c8913edb801c35);

	return true;
}

function EeC455FA54E2999d($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `watch_folders` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `watch_folders` WHERE `id` = ?;', $C3c8913edb801c35);

	return true;
}

function D920C9a4b3D6d84E($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id` FROM `tickets` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `tickets` WHERE `id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `tickets_replies` WHERE `ticket_id` = ?;', $C3c8913edb801c35);

	return true;
}

function A820b9E9f53E0924($D78ff1d0edade5eb)
{
	global $Fee0d5a474c96306;
	global $F2d4d8f7981ac574;
	$d51e425eb7375255 = fE76c4BCaF81BAa4($D78ff1d0edade5eb);
	$B2ff75c438fb3031 = f0acf9de3389b116($d51e425eb7375255['member_group_id']);

	if ($F2d4d8f7981ac574['disable_trial']) {
		return false;
	}

	if (floatval($d51e425eb7375255['credits']) < floatval($B2ff75c438fb3031['minimum_trial_credits'])) {
		return false;
	}

	$Db02e1f7181c07ed = $B2ff75c438fb3031['total_allowed_gen_trials'];

	if (0 >= $Db02e1f7181c07ed) {
		return false;
	}

	$B82a4ed54a9e97d7 = $B2ff75c438fb3031['total_allowed_gen_in'];

	if ($B82a4ed54a9e97d7 == 'hours') {
		$C4af185e24cf9086 = time() - intval($Db02e1f7181c07ed) * 3600;
	} else {
		$C4af185e24cf9086 = time() - intval($Db02e1f7181c07ed) * 3600 * 24;
	}

	$Fee0d5a474c96306->query('SELECT COUNT(`id`) AS `count` FROM `lines` WHERE `member_id` = ? AND `created_at` >= ? AND `is_trial` = 1;', $d51e425eb7375255['id'], $C4af185e24cf9086);

	return $Fee0d5a474c96306->get_row()['count'] < $Db02e1f7181c07ed;
}

function D29D7d4E98EA26da($D78ff1d0edade5eb, $A2b85ede89f9df0c = true, $B963b5d49ca08acf = true)
{
	global $Fee0d5a474c96306;
	$D031c48a1422c07e = round(microtime(true) * 1000);
	$a85e1b7d42c346a0 = array('create_line' => false, 'create_mag' => false, 'create_enigma' => false, 'stream_ids' => array(), 'series_ids' => array(), 'category_ids' => array(), 'users' => array(), 'direct_reports' => array(), 'all_reports' => array(), 'report_map' => array());
	$d51e425eb7375255 = fE76C4BCaF81baa4($D78ff1d0edade5eb);

	if (!$d51e425eb7375255) {
	} else {
		if (!file_exists(CACHE_TMP_PATH . 'permissions_' . intval($d51e425eb7375255['member_group_id']))) {
		} else {
			$a85e1b7d42c346a0 = array_merge($a85e1b7d42c346a0, igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'permissions_' . intval($d51e425eb7375255['member_group_id']))));
		}

		$Fee0d5a474c96306->query("SELECT * FROM `users_packages` WHERE JSON_CONTAINS(`groups`, ?, '\$');", $d51e425eb7375255['member_group_id']);

		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if (!$C740da31596f24ef['is_line']) {
			} else {
				$a85e1b7d42c346a0['create_line'] = true;
			}

			if (!$C740da31596f24ef['is_mag']) {
			} else {
				$a85e1b7d42c346a0['create_mag'] = true;
			}

			if (!$C740da31596f24ef['is_e2']) {
			} else {
				$a85e1b7d42c346a0['create_enigma'] = true;
			}
		}

		if (!$B963b5d49ca08acf) {
		} else {
			$a85e1b7d42c346a0['users'] = d51d8bc0921f91f7($d51e425eb7375255['id']);

			foreach ($a85e1b7d42c346a0['users'] as $D78ff1d0edade5eb => $E3adbdd9acf7f4a3) {
				if ($d51e425eb7375255['id'] != $E3adbdd9acf7f4a3['parent']) {
				} else {
					$a85e1b7d42c346a0['direct_reports'][] = $D78ff1d0edade5eb;
				}

				$a85e1b7d42c346a0['all_reports'][] = $D78ff1d0edade5eb;
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function f079a768B4aAc7e1($d58b4f8653a391d8)
{
	a200986bbae4b322($d58b4f8653a391d8, array('action' => 'reload_nginx'));
}

function getFPMStatus($d58b4f8653a391d8)
{
	return a200986bbae4b322($d58b4f8653a391d8, array('action' => 'fpm_status'));
}

function fCf52f24c866C872()
{
	global $a8bb73cba48fb7f6;

	foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8 => $fcdd8fd7a8500c08) {
		Xui\Functions::grantPrivileges('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', $fcdd8fd7a8500c08['server_ip']);
	}
}

function Cbc22956B573E5Cc($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `profiles` WHERE `profile_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function b24A2f16afe7FaAF($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `blocked_uas` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function E0e9955E91Fa6027($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams_categories` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return false;
	}

	return $Fee0d5a474c96306->get_row();
}

function bfE9937C6d242a3d($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `mag_devices` WHERE `mag_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return array();
	}

	$C740da31596f24ef = $Fee0d5a474c96306->get_row();
	$C740da31596f24ef['user'] = B4036Ef9a1Db8473($C740da31596f24ef['user_id']);
	$Fee0d5a474c96306->query('SELECT `pair_id` FROM `lines` WHERE `id` = ?;', $C740da31596f24ef['user_id']);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		$C740da31596f24ef['paired'] = b4036EF9a1db8473($C740da31596f24ef['user']['pair_id']);
	}

	return $C740da31596f24ef;
}

function bA960caB7FE0CD93($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `enigma2_devices` WHERE `device_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return array();
	}

	$C740da31596f24ef = $Fee0d5a474c96306->get_row();
	$C740da31596f24ef['user'] = b4036EF9A1DB8473($C740da31596f24ef['user_id']);
	$Fee0d5a474c96306->query('SELECT `pair_id` FROM `lines` WHERE `id` = ?;', $C740da31596f24ef['user_id']);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		$C740da31596f24ef['paired'] = B4036Ef9A1dB8473($C740da31596f24ef['user']['pair_id']);
	}

	return $C740da31596f24ef;
}

function f072264502B66a62($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `enigma2_devices` WHERE `user_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return '';
	}

	return $Fee0d5a474c96306->get_row();
}

function D42eDD31c6ef0655($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `tickets` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		$C740da31596f24ef = $Fee0d5a474c96306->get_row();
		$C740da31596f24ef['replies'] = array();
		$C740da31596f24ef['title'] = htmlspecialchars($C740da31596f24ef['title']);
		$Fee0d5a474c96306->query('SELECT * FROM `tickets_replies` WHERE `ticket_id` = ? ORDER BY `date` ASC;', $C3c8913edb801c35);

		foreach ($Fee0d5a474c96306->get_rows() as $C9e90f3f7130c9af) {
			$C9e90f3f7130c9af['message'] = htmlspecialchars($C9e90f3f7130c9af['message']);

			if (strlen($C9e90f3f7130c9af['message']) >= 80) {
			} else {
				$C9e90f3f7130c9af['message'] .= str_repeat('&nbsp; ', 80 - strlen($C9e90f3f7130c9af['message']));
			}

			$C740da31596f24ef['replies'][] = $C9e90f3f7130c9af;
		}
		$C740da31596f24ef['user'] = Fe76C4bCaF81baa4($C740da31596f24ef['member_id']);

		return $C740da31596f24ef;
	}
}

function E7DA8338649cD1ca($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `blocked_isps` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function ae44475ca4238899($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `rtmp_ips` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function BAEA42B3f8E1780c()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `epg` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function B68fC023C6196ffe($E379394c7b1a273f = 'live')
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `streams_categories` WHERE `category_type` = ? ORDER BY `cat_order` ASC;', $E379394c7b1a273f);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A28903A04191748A($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return false;
	}

	return $Fee0d5a474c96306->get_row();
}

function Eecb64FD7D6b8430($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `servers` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return false;
	}

	return $Fee0d5a474c96306->get_row();
}

function BeEB53575450629a($d58b4f8653a391d8, $Fa288895c003c519 = false)
{
	global $Fee0d5a474c96306;

	if (XUI::$rSettings['redis_handler']) {
		$Aa8d8af3d37ca869 = 0;

		if ($Fa288895c003c519) {
			$f96fcd481c5c5bb2 = XUI::$rServers[$d58b4f8653a391d8]['parent_id'];

			foreach ($f96fcd481c5c5bb2 as $fcae8575b94f8564) {
				foreach (XUI::D92dE48C36cf9438(null, $fcae8575b94f8564, null, true, false, false) as $e110a2ab6d3a4734) {
					if ($e110a2ab6d3a4734['proxy_id'] != $d58b4f8653a391d8) {
					} else {
						$Aa8d8af3d37ca869++;
					}
				}
			}
		} else {
			list($Aa8d8af3d37ca869) = XUI::D92dE48c36cF9438(null, $d58b4f8653a391d8, null, true, true, false);
		}

		return $Aa8d8af3d37ca869;
	} else {
		if ($Fa288895c003c519) {
			$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `proxy_id` = ? AND `hls_end` = 0;', $d58b4f8653a391d8);
		} else {
			$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `server_id` = ? AND `hls_end` = 0;', $d58b4f8653a391d8);
		}

		return $Fee0d5a474c96306->get_row()['count'];
	}
}

function EaA3b74e26a5b8dc()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `epg`;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['id']] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function cbe87e2a9a996111($E379394c7b1a273f = 'live')
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();

	if ($E379394c7b1a273f) {
		$Fee0d5a474c96306->query('SELECT * FROM `streams_categories` WHERE `category_type` = ? ORDER BY `cat_order` ASC;', $E379394c7b1a273f);
	} else {
		$Fee0d5a474c96306->query('SELECT * FROM `streams_categories` ORDER BY `cat_order` ASC;');
	}

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A1d06cA5A4835cFA($Cd393596c43dd45a)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `id`, `data` FROM `epg`;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			foreach (json_decode($C740da31596f24ef['data'], true) as $F8c99b2741720390 => $Db855a676405656d) {
				if ($F8c99b2741720390 != $Cd393596c43dd45a) {
				} else {
					if (0 < count($Db855a676405656d['langs'])) {
						$ab84908c720bf94d = $Db855a676405656d['langs'][0];
					} else {
						$ab84908c720bf94d = '';
					}

					return array('channel_id' => $F8c99b2741720390, 'epg_lang' => $ab84908c720bf94d, 'epg_id' => intval($C740da31596f24ef['id']));
				}
			}
		}
	}
}

function b7E0f83fC2bFC30B($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$D307572f7986a746 = a7685E0565a15403($C3c8913edb801c35);

	if (!($D307572f7986a746 && $D307572f7986a746['can_delete'])) {
		return false;
	}

	$Fee0d5a474c96306->query("SELECT `id`, `groups` FROM `users_packages` WHERE JSON_CONTAINS(`groups`, ?, '\$');", $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$C740da31596f24ef['groups'] = json_decode($C740da31596f24ef['groups'], true);

		if (($D3fa098be3f297cd = array_search($C3c8913edb801c35, $C740da31596f24ef['groups'])) === false) {
		} else {
			unset($C740da31596f24ef['groups'][$D3fa098be3f297cd]);
		}

		$Fee0d5a474c96306->query("UPDATE `users_packages` SET `groups` = '[" . implode(',', array_map('intval', $C740da31596f24ef['groups'])) . "]' WHERE `id` = ?;", $C740da31596f24ef['id']);
	}
	$Fee0d5a474c96306->query('UPDATE `users` SET `member_group_id` = 0 WHERE `member_group_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `users_groups` WHERE `group_id` = ?;', $C3c8913edb801c35);

	return true;
}

function C6084D728c503734($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$fe06d74291ffa213 = f0acab09e248fc13($C3c8913edb801c35);

	if (!$fe06d74291ffa213) {
		return false;
	}

	$Fee0d5a474c96306->query('UPDATE `lines` SET `package_id` = null WHERE `package_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `users_packages` WHERE `id` = ?;', $C3c8913edb801c35);

	return true;
}

function deleteProvider($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Ad973fd3103e20dc = getstreamprovider($C3c8913edb801c35);

	if (!$Ad973fd3103e20dc) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `providers` WHERE `id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `providers_streams` WHERE `provider_id` = ?;', $C3c8913edb801c35);

	return true;
}

function F62970F78A40Cd4C($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$d8a1409105424710 = getEPG($C3c8913edb801c35);

	if (!$d8a1409105424710) {
		return false;
	}

	$Fee0d5a474c96306->query('DELETE FROM `epg` WHERE `id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `epg_channels` WHERE `epg_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('UPDATE `streams` SET `epg_id` = null, `channel_id` = null, `epg_lang` = null WHERE `epg_id` = ?;', $C3c8913edb801c35);

	return true;
}

function c234ae70B52d65a2($C3c8913edb801c35, $d481bdda1eae677a = null)
{
	global $Fee0d5a474c96306;
	$e81220b4451f37c9 = eecb64fd7d6b8430($C3c8913edb801c35);

	if (!$e81220b4451f37c9 || $e81220b4451f37c9['is_main']) {
		return false;
	}

	if ($d481bdda1eae677a) {
		$Fee0d5a474c96306->query('UPDATE `streams_servers` SET `server_id` = ? WHERE `server_id` = ?;', $d481bdda1eae677a, $C3c8913edb801c35);

		if (XUI::$rSettings['redis_handler']) {
		} else {
			$Fee0d5a474c96306->query('UPDATE `lines_live` SET `server_id` = ? WHERE `server_id` = ?;', $d481bdda1eae677a, $C3c8913edb801c35);
		}

		$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `server_id` = ? WHERE `server_id` = ?;', $d481bdda1eae677a, $C3c8913edb801c35);
	} else {
		$Fee0d5a474c96306->query('DELETE FROM `streams_servers` WHERE `server_id` = ?;', $C3c8913edb801c35);

		if (XUI::$rSettings['redis_handler']) {
		} else {
			$Fee0d5a474c96306->query('DELETE FROM `lines_live` WHERE `server_id` = ?;', $C3c8913edb801c35);
		}

		$Fee0d5a474c96306->query('UPDATE `lines_activity` SET `server_id` = 0 WHERE `server_id` = ?;', $C3c8913edb801c35);
	}

	$Fee0d5a474c96306->query('UPDATE `servers` SET `parent_id` = NULL, `enabled` = 0 WHERE `server_type` = 1 AND `parent_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `servers_stats` WHERE `server_id` = ?;', $C3c8913edb801c35);
	$Fee0d5a474c96306->query('DELETE FROM `servers` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($e81220b4451f37c9['server_type'] != 0) {
	} else {
		Xui\Functions::revokePrivileges('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0', $e81220b4451f37c9['server_ip']);
	}

	return true;
}

function C7B251c6B45aBe4f($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Db09f9628b0daff0 = array();
	$Fee0d5a474c96306->query('SELECT `server_id`, `error` FROM `streams_errors` WHERE `stream_id` = ?;', $C3c8913edb801c35);

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$Db09f9628b0daff0[intval($C740da31596f24ef['server_id'])] = $C740da31596f24ef['error'];
	}

	return $Db09f9628b0daff0;
}

function deleteRecording($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT `created_id`, `source_id` FROM `recordings` WHERE `id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		$Cd5e2972309f8a29 = $Fee0d5a474c96306->get_row();

		if (!$Cd5e2972309f8a29['created_id']) {
		} else {
			d13c1a44a4495b05($Cd5e2972309f8a29['created_id'], $Cd5e2972309f8a29['source_id'], true, true);
		}

		shell_exec("kill -9 `ps -ef | grep 'Record\\[" . intval($C3c8913edb801c35) . "\\]' | grep -v grep | awk '{print \$2}'`;");
		$Fee0d5a474c96306->query('DELETE FROM `recordings` WHERE `id` = ?;', $C3c8913edb801c35);
	}
}

function getRecordings()
{
	global $Fee0d5a474c96306;
	$adab610984c5d7df = array();
	$Fee0d5a474c96306->query('SELECT * FROM `recordings` ORDER BY `id` DESC;');

	foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
		$adab610984c5d7df[] = $C740da31596f24ef;
	}

	return $adab610984c5d7df;
}

function B1D9852FCeb75E78()
{
	return !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443;
}

function ace67c2BFe9ADaD5()
{
	if (b1d9852fceb75e78()) {
		return 'https';
	}

	return 'http';
}

function FF7f5B67c85BDd34($E708d4730d21125b, $C3c8913edb801c35)
{
	global $Fee0d5a474c96306;

	if (is_array($E708d4730d21125b)) {
	} else {
		$E708d4730d21125b = array($E708d4730d21125b);
	}

	foreach ($E708d4730d21125b as $d58b4f8653a391d8) {
		$Fee0d5a474c96306->query('INSERT INTO `signals`(`server_id`, `time`, `custom_data`, `cache`) VALUES(?, ?, ?, 1);', $d58b4f8653a391d8, time(), json_encode(array('type' => 'delete_vod', 'id' => $C3c8913edb801c35)));
	}

	return true;
}

function d7445B70978659BA($c5592e918b1d7066 = 10)
{
	$E2f8ff669a75b772 = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ';
	$a1a4b7aee201c1a7 = strlen($E2f8ff669a75b772);
	$cafdfedfe83f84a0 = '';

	for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < $c5592e918b1d7066; $Ea22c4a9ab5b2176++) {
		$F1dbe923a645053c = $E2f8ff669a75b772[mt_rand(0, $a1a4b7aee201c1a7 - 1)];
		$cafdfedfe83f84a0 .= $F1dbe923a645053c;
	}

	return $cafdfedfe83f84a0;
}

function f6dA964066f2F5E4($F148ac2342eb3b2b = false)
{
	global $Fee0d5a474c96306;
	global $B2ff75c438fb3031;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `servers` WHERE `server_type` = 0 ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if (!$B2ff75c438fb3031['is_reseller']) {
			} else {
				$C740da31596f24ef['server_name'] = 'Server #' . $C740da31596f24ef['id'];
			}

			$C740da31596f24ef['server_online'] = in_array($C740da31596f24ef['status'], array(1, 3)) && time() - $C740da31596f24ef['last_check_ago'] <= 90 || $C740da31596f24ef['is_main'];

			if (!$C740da31596f24ef['server_online'] && $F148ac2342eb3b2b) {
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['id']] = $C740da31596f24ef;
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function B53315A5667Ef8FF()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `servers` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['id']] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A4338A704a6a7789($F148ac2342eb3b2b = false)
{
	global $Fee0d5a474c96306;
	global $B2ff75c438fb3031;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `servers` WHERE `server_type` = 1 ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if (!$B2ff75c438fb3031['is_reseller']) {
			} else {
				$C740da31596f24ef['server_name'] = 'Proxy #' . $C740da31596f24ef['id'];
			}

			$C740da31596f24ef['server_online'] = in_array($C740da31596f24ef['status'], array(1, 3)) && time() - $C740da31596f24ef['last_check_ago'] <= 90 || $C740da31596f24ef['is_main'];

			if (!$C740da31596f24ef['server_online'] && $F148ac2342eb3b2b) {
			} else {
				$a85e1b7d42c346a0[$C740da31596f24ef['id']] = $C740da31596f24ef;
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function a569Fe109782304d($d58b4f8653a391d8)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`type`, `streams_servers`.`pid`, `streams_servers`.`monitor_pid`, `streams_servers`.`delay_pid` FROM `streams_servers` LEFT JOIN `streams` ON `streams`.`id` = `streams_servers`.`stream_id` WHERE `streams_servers`.`server_id` = ?;', $d58b4f8653a391d8);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			foreach (array('pid', 'monitor_pid', 'delay_pid') as $e4392d5fd4387215) {
				if (!$C740da31596f24ef[$e4392d5fd4387215]) {
				} else {
					$a85e1b7d42c346a0[$C740da31596f24ef[$e4392d5fd4387215]] = array('id' => $C740da31596f24ef['id'], 'title' => $C740da31596f24ef['stream_display_name'], 'type' => $C740da31596f24ef['type'], 'pid_type' => $e4392d5fd4387215);
				}
			}
		}
	}

	$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name`, `type`, `tv_archive_pid` FROM `streams` WHERE `tv_archive_server_id` = ?;', $d58b4f8653a391d8);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['tv_archive_pid']] = array('id' => $C740da31596f24ef['id'], 'title' => $C740da31596f24ef['stream_display_name'], 'type' => $C740da31596f24ef['type'], 'pid_type' => 'timeshift');
		}
	}

	$Fee0d5a474c96306->query('SELECT `id`, `stream_display_name`, `type`, `vframes_pid` FROM `streams` WHERE `vframes_server_id` = ?;', $d58b4f8653a391d8);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['vframes_pid']] = array('id' => $C740da31596f24ef['id'], 'title' => $C740da31596f24ef['stream_display_name'], 'type' => $C740da31596f24ef['type'], 'pid_type' => 'vframes');
		}
	}

	if (XUI::$rSettings['redis_handler']) {
		$Cdb85875fd50f459 = $F36bea2698ecb4fa = array();
		$A90d77181715e38e = XUI::d92de48c36CF9438(null, $d58b4f8653a391d8, null, true, false, false);

		foreach ($A90d77181715e38e as $e110a2ab6d3a4734) {
			if (in_array($e110a2ab6d3a4734['stream_id'], $Cdb85875fd50f459)) {
			} else {
				$Cdb85875fd50f459[] = intval($e110a2ab6d3a4734['stream_id']);
			}
		}

		if (0 >= count($Cdb85875fd50f459)) {
		} else {
			$Fee0d5a474c96306->query('SELECT `id`, `type`, `stream_display_name` FROM `streams` WHERE `id` IN (' . implode(',', $Cdb85875fd50f459) . ');');

			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$F36bea2698ecb4fa[$C740da31596f24ef['id']] = array($C740da31596f24ef['stream_display_name'], $C740da31596f24ef['type']);
			}
		}

		foreach ($A90d77181715e38e as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['pid']] = array('id' => $C740da31596f24ef['stream_id'], 'title' => $F36bea2698ecb4fa[$C740da31596f24ef['stream_id']][0], 'type' => $F36bea2698ecb4fa[$C740da31596f24ef['stream_id']][1], 'pid_type' => 'activity');
		}
	} else {
		$Fee0d5a474c96306->query('SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`type`, `lines_live`.`pid` FROM `lines_live` LEFT JOIN `streams` ON `streams`.`id` = `lines_live`.`stream_id` WHERE `lines_live`.`server_id` = ?;', $d58b4f8653a391d8);

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$a85e1b7d42c346a0[$C740da31596f24ef['pid']] = array('id' => $C740da31596f24ef['id'], 'title' => $C740da31596f24ef['stream_display_name'], 'type' => $C740da31596f24ef['type'], 'pid_type' => 'activity');
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function BAeB48317196f323($f9e01cfdcc3d0081, $b2db2d0561ace513 = 5)
{
	return round(($f9e01cfdcc3d0081 + $b2db2d0561ace513 / 2) / $b2db2d0561ace513) * $b2db2d0561ace513;
}

function BbDBe7aD31018a97($d58b4f8653a391d8, $bc2874292e0d9ece)
{
	$c85ed032f7e37367 = XUI::$rServers[intval($d58b4f8653a391d8)]['api_url_ip'] . '&action=getFile&filename=' . urlencode($bc2874292e0d9ece);
	$cf1c389bda3e30fd = 'timeout 10 ' . XUI::$rFFPROBE . ' -user_agent "Mozilla/5.0" -show_streams -v quiet "' . $c85ed032f7e37367 . '" -of json';

	return json_decode(shell_exec($cf1c389bda3e30fd), true);
}

function C88AD690Ab268114($d58b4f8653a391d8)
{
	$c85ed032f7e37367 = XUI::$rServers[intval($d58b4f8653a391d8)]['api_url_ip'] . '&action=getFile&filename=' . urlencode(BIN_PATH . 'certbot/logs/xui.log');

	return json_decode(file_get_contents($c85ed032f7e37367), true);
}

function BF7791Bd46BeC674($C3c8913edb801c35, $E400a3101514583e = 86400)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `servers_stats` WHERE `server_id` = ? AND UNIX_TIMESTAMP() - `time` <= ? ORDER BY `time` DESC;', $C3c8913edb801c35, $E400a3101514583e);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A7685E0565a15403($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `users_groups` WHERE `group_id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function a1432200fC8fEab7()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `output_formats` ORDER BY `access_output_id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A7526A151f645414()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `id`, `bouquet` FROM `lines` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function D7a15e0c2D9bEcE1()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `bouquets` ORDER BY `bouquet_order` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function A53403FC10f556Be()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `bouquets` ORDER BY `bouquet_order` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function Dd18Cd7b718CD0f2()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `blocked_ips` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function b504eDC146895dbd()
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `rtmp_ips` ORDER BY `id` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function e5eceB32f67D5E70($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `streams` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function B4036eF9A1Db8473($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `lines` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function Fe76C4bCaF81BaA4($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `users` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function d451dbAdAA63FD18()
{
	return strtolower(basename(get_included_files()[0], '.php'));
}

function sortArrayByArray($d49041d5f05a9270, $C506f7e1a1b97909)
{
	if (!(empty($d49041d5f05a9270) || empty($C506f7e1a1b97909))) {
		$D38042213c4415a7 = array();

		foreach ($C506f7e1a1b97909 as $b6842cb20051e925) {
			if (($D3fa098be3f297cd = array_search($b6842cb20051e925, $d49041d5f05a9270)) === false) {
			} else {
				$D38042213c4415a7[] = $b6842cb20051e925;
				unset($d49041d5f05a9270[$D3fa098be3f297cd]);
			}
		}

		return $D38042213c4415a7 + $d49041d5f05a9270;
	} else {
		return array();
	}
}

function f6Bc4fAeB7538A4e($b6842cb20051e925)
{
	if ($b6842cb20051e925 != '') {
		$b6842cb20051e925 = str_replace('&#032;', ' ', stripslashes($b6842cb20051e925));
		$b6842cb20051e925 = str_replace(array("\r\n", "\n\r", "\r"), "\n", $b6842cb20051e925);
		$b6842cb20051e925 = str_replace('<!--', '&#60;&#33;--', $b6842cb20051e925);
		$b6842cb20051e925 = str_replace('-->', '--&#62;', $b6842cb20051e925);
		$b6842cb20051e925 = str_ireplace('<script', '&#60;script', $b6842cb20051e925);
		$b6842cb20051e925 = preg_replace('/&amp;#([0-9]+);/s', '&#\\1;', $b6842cb20051e925);
		$b6842cb20051e925 = preg_replace('/&#(\\d+?)([^\\d;])/i', '&#\\1;\\2', $b6842cb20051e925);

		return trim($b6842cb20051e925);
	}

	return '';
}

function d48690ee48E36D75($F26087d31c2bbe4d)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `streams_stats` WHERE `stream_id` = ?;', $F26087d31c2bbe4d);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[$C740da31596f24ef['type']] = $C740da31596f24ef;
		}
	}

	foreach (array('today', 'week', 'month', 'all') as $E379394c7b1a273f) {
		if (isset($a85e1b7d42c346a0[$E379394c7b1a273f])) {
		} else {
			$a85e1b7d42c346a0[$E379394c7b1a273f] = array('rank' => 0, 'users' => 0, 'connections' => 0, 'time' => 0);
		}
	}

	return $a85e1b7d42c346a0;
}

function getSimilarMovies($C3c8913edb801c35, $ddf21fc658e95052 = 1)
{
	require_once XUI_HOME . 'includes/libs/tmdb.php';

	if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
	} else {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
	}

	return json_decode(json_encode($a69d576081840514->getSimilarMovies($C3c8913edb801c35, $ddf21fc658e95052)), true);
}

function getSimilarSeries($C3c8913edb801c35, $ddf21fc658e95052 = 1)
{
	require_once XUI_HOME . 'includes/libs/tmdb.php';

	if (0 < strlen(XUI::$rSettings['tmdb_language'])) {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key'], XUI::$rSettings['tmdb_language']);
	} else {
		$a69d576081840514 = new TMDB(XUI::$rSettings['tmdb_api_key']);
	}

	return json_decode(json_encode($a69d576081840514->getSimilarSeries($C3c8913edb801c35, $ddf21fc658e95052)), true);
}

function generateReport($C700a2b357e5ed65, $f0a0900c0afc1c32)
{
	$E330444f58f09645 = http_build_query($f0a0900c0afc1c32);
	$c88afcbaf19918af = curl_init();
	curl_setopt($c88afcbaf19918af, CURLOPT_URL, $C700a2b357e5ed65);
	curl_setopt($c88afcbaf19918af, CURLOPT_POST, true);
	curl_setopt($c88afcbaf19918af, CURLOPT_POSTFIELDS, $E330444f58f09645);
	curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($c88afcbaf19918af, CURLOPT_CONNECTTIMEOUT, 5);
	curl_setopt($c88afcbaf19918af, CURLOPT_TIMEOUT, 300);

	return curl_exec($c88afcbaf19918af);
}

function convertToCSV($a27e64cc6ce01033)
{
	$Eb5dde5d027876ce = false;
	$bc2874292e0d9ece = TMP_PATH . d7445b70978659ba(32) . '.csv';
	$e2f848a82a80c113 = fopen($bc2874292e0d9ece, 'w');

	foreach ($a27e64cc6ce01033 as $C740da31596f24ef) {
		if (!empty($Eb5dde5d027876ce)) {
		} else {
			$Eb5dde5d027876ce = array_keys($C740da31596f24ef);
			fputcsv($e2f848a82a80c113, $Eb5dde5d027876ce);
			$Eb5dde5d027876ce = array_flip($Eb5dde5d027876ce);
		}

		fputcsv($e2f848a82a80c113, array_merge($Eb5dde5d027876ce, $C740da31596f24ef));
	}
	fclose($e2f848a82a80c113);

	return $bc2874292e0d9ece;
}

function processEPGAPI($F26087d31c2bbe4d, $F8c99b2741720390)
{
	shell_exec(PHP_BIN . ' ' . CRON_PATH . 'epg.php ' . intval($F26087d31c2bbe4d) . ' ' . escapeshellarg($F8c99b2741720390) . ' > /dev/null 2>/dev/null &');

	return true;
}

function forceWatch($d58b4f8653a391d8, $cd473a824b02afdd)
{
	a200986bbae4b322($d58b4f8653a391d8, array('action' => 'watch_force', 'id' => $cd473a824b02afdd));
}

function forcePlex($d58b4f8653a391d8, $C167873ff203aefe)
{
	a200986bbae4b322($d58b4f8653a391d8, array('action' => 'plex_force', 'id' => $C167873ff203aefe));
}

function B8e493b5DBDb3D7a($d58b4f8653a391d8)
{
	a200986bbae4b322($d58b4f8653a391d8, array('action' => 'free_temp'));
}

function c00aB7DA6173eBB1($d58b4f8653a391d8)
{
	a200986bbae4b322($d58b4f8653a391d8, array('action' => 'free_streams'));
}

function probeSource($d58b4f8653a391d8, $C700a2b357e5ed65, $b3374866087774a1 = null, $Fa288895c003c519 = null, $F889719ffba297d4 = null, $Ae2b613e51651b56 = null)
{
	return json_decode(a200986bbae4b322($d58b4f8653a391d8, array('action' => 'probe', 'url' => $C700a2b357e5ed65, 'user_agent' => $b3374866087774a1, 'http_proxy' => $Fa288895c003c519, 'cookies' => $F889719ffba297d4, 'headers' => $Ae2b613e51651b56), 30), true);
}

function CFaEC500A6B51c40($F26087d31c2bbe4d, $f665b8e041442d05 = false)
{
	global $Fee0d5a474c96306;
	$f523e362fb81d6c8 = e5eceb32f67d5e70($F26087d31c2bbe4d);

	if (!$f523e362fb81d6c8['channel_id']) {
		return array();
	}

	if ($f665b8e041442d05) {
		return XUI::getEPG($F26087d31c2bbe4d, time() - $f523e362fb81d6c8['tv_archive_duration'] * 86400, time());
	}

	return XUI::getEPG($F26087d31c2bbe4d, time(), time() + 1209600);
}

function getEPG($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT * FROM `epg` WHERE `id` = ?;', $C3c8913edb801c35);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		return $Fee0d5a474c96306->get_row();
	}
}

function cb4fCda8E433B44E($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `streams_options` WHERE `stream_id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['argument_id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function BB9fe2fDE295E476($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `streams_servers` WHERE `stream_id` = ?;', $C3c8913edb801c35);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[intval($C740da31596f24ef['server_id'])] = $C740da31596f24ef;
		}
	}

	return $a85e1b7d42c346a0;
}

function f2Bb404082898F83($Dbb9e190755fc819 = null, $E8d403a4062baa68 = true)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT * FROM `users` ORDER BY `username` ASC;');

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			if (!(!$Dbb9e190755fc819 || $C740da31596f24ef['owner_id'] == $Dbb9e190755fc819 || $C740da31596f24ef['id'] == $Dbb9e190755fc819 && $E8d403a4062baa68)) {
			} else {
				$a85e1b7d42c346a0[intval($C740da31596f24ef['id'])] = $C740da31596f24ef;
			}
		}
	}

	if (count($a85e1b7d42c346a0) != 0) {
	} else {
		$a85e1b7d42c346a0[-1] = array();
	}

	return $a85e1b7d42c346a0;
}

function E6FadaEB37704cBf()
{
	return "&copy; 2025 <img height='20px' style='padding-left: 10px; padding-right: 10px; margin-top: -2px;' class='whiteout' src='./assets/images/logo-dragon-shield.png' /> v" . XUI_VERSION;
}

function d4724EC36c96198e()
{
	shell_exec(PHP_BIN . ' ' . CLI_PATH . 'tools.php "bouquets" > /dev/null 2>/dev/null &');
}

function B47820f6E3a74994($C3c8913edb801c35)
{
	global $Fee0d5a474c96306;
	$ddf0508b312dbfb8 = c8adb574f9477f84($C3c8913edb801c35);

	if (!$ddf0508b312dbfb8) {
	} else {
		$Cdb85875fd50f459 = array(array(), array());
		$Fee0d5a474c96306->query('SELECT `id` FROM `streams`;');

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$Cdb85875fd50f459[0][] = intval($C740da31596f24ef['id']);
			}
		}

		$Fee0d5a474c96306->query('SELECT `id` FROM `streams_series`;');

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$Cdb85875fd50f459[1][] = intval($C740da31596f24ef['id']);
			}
		}

		$D480255818428bfd = array(array(), array(), array(), array());

		foreach (json_decode($ddf0508b312dbfb8['bouquet_channels'], true) as $C3c8913edb801c35) {
			if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[0]))) {
			} else {
				$D480255818428bfd[0][] = intval($C3c8913edb801c35);
			}
		}

		foreach (json_decode($ddf0508b312dbfb8['bouquet_movies'], true) as $C3c8913edb801c35) {
			if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[0]))) {
			} else {
				$D480255818428bfd[1][] = intval($C3c8913edb801c35);
			}
		}

		foreach (json_decode($ddf0508b312dbfb8['bouquet_radios'], true) as $C3c8913edb801c35) {
			if (!(0 < intval($C3c8913edb801c35) && in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[0]))) {
			} else {
				$D480255818428bfd[2][] = intval($C3c8913edb801c35);
			}
		}

		foreach (json_decode($ddf0508b312dbfb8['bouquet_series'], true) as $C3c8913edb801c35) {
			if (!in_array(intval($C3c8913edb801c35), $Cdb85875fd50f459[1])) {
			} else {
				$D480255818428bfd[3][] = intval($C3c8913edb801c35);
			}
		}
		$Fee0d5a474c96306->query("UPDATE `bouquets` SET `bouquet_channels` = '[" . implode(',', array_map('intval', $D480255818428bfd[0])) . "]', `bouquet_movies` = '[" . implode(',', array_map('intval', $D480255818428bfd[1])) . "]', `bouquet_radios` = '[" . implode(',', array_map('intval', $D480255818428bfd[2])) . "]', `bouquet_series` = '[" . implode(',', array_map('intval', $D480255818428bfd[3])) . "]' WHERE `id` = ?;", $ddf0508b312dbfb8['id']);
	}
}

function dc95637C2dA3B543()
{
	global $Fee0d5a474c96306;
	$Fee0d5a474c96306->query('SELECT MAX(`order`) AS `order` FROM `streams`;');

	if ($Fee0d5a474c96306->num_rows() != 1) {
		return 0;
	}

	return intval($Fee0d5a474c96306->get_row()['order']) + 1;
}

function a239FF4055Faa462($C9316481c17d1c3a)
{
	global $Fee0d5a474c96306;
	$a85e1b7d42c346a0 = array();
	$Fee0d5a474c96306->query('SELECT `stream_id` FROM `streams_episodes` WHERE `series_id` = ? ORDER BY `season_num` ASC, `episode_num` ASC;', $C9316481c17d1c3a);

	if (0 >= $Fee0d5a474c96306->num_rows()) {
	} else {
		foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
			$Fee0d5a474c96306->query('SELECT `stream_source` FROM `streams` WHERE `id` = ?;', $C740da31596f24ef['stream_id']);

			if (0 >= $Fee0d5a474c96306->num_rows()) {
			} else {
				list($c8d91fcd2309e48a) = json_decode($Fee0d5a474c96306->get_row()['stream_source'], true);
				$a85e1b7d42c346a0[] = $c8d91fcd2309e48a;
			}
		}
	}

	return $a85e1b7d42c346a0;
}

function shutdown_admin()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
