<?php

class Database
{
	public $result = null;
	public $last_query = null;
	protected $key = null;
	public $dbh = null;
	public $connected = false;

	public function __construct($Ea7db7f7a51d5edd = null, $e37e63f99f39eaba = false)
	{
		$this->dbh = false;

		if (!$Ea7db7f7a51d5edd) {
		} else {
			$this->key = $Ea7db7f7a51d5edd;
			$this->db_connect($e37e63f99f39eaba);
		}
	}

	public function close_mysql()
	{
		if (!$this->connected) {
		} else {
			$this->connected = false;
			$this->dbh = null;
		}

		return true;
	}

	public function __destruct()
	{
		$this->close_mysql();
	}

	public function ping()
	{
		try {
			$this->dbh->query('SELECT 1');
		} catch (Exception $c34ae71903f0d920) {
			return false;
		}

		return true;
	}

	public function db_connect($e37e63f99f39eaba = false)
	{
		try {
			$this->dbh = Xui\Functions::connect($this->key, $e37e63f99f39eaba);

			if ($this->dbh) {
			} else {
				if (!$e37e63f99f39eaba) {
					exit(json_encode(array('error' => 'MySQL: Cannot connect to database! Please check credentials.')));
				}

				return false;
			}
		} catch (PDOException $c34ae71903f0d920) {
			exit(json_encode(array('error' => 'MySQL: ' . $c34ae71903f0d920->getMessage())));
		}
		$this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$this->connected = true;

		return true;
	}

	public function db_explicit_connect($baba170ab02ca0bd, $b87b2986f8f49da8, $E9ff1197d3f1304b, $a71afc14d6cd090d, $d5249dad8e8411b7)
	{
		try {
			$this->dbh = new PDO('mysql:host=' . $baba170ab02ca0bd . ';port=' . $b87b2986f8f49da8 . ';dbname=' . $E9ff1197d3f1304b, $a71afc14d6cd090d, $d5249dad8e8411b7);

			if ($this->dbh) {
			} else {
				return false;
			}
		} catch (PDOException $c34ae71903f0d920) {
			return false;
		}
		$this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$this->connected = true;

		return true;
	}

	public function debugString($D1801c8143184552)
	{
		ob_start();
		$D1801c8143184552->debugDumpParams();
		$D61c8910682a1d8c = ob_get_contents();
		ob_end_clean();

		return $D61c8910682a1d8c;
	}

	public function query($A2833f35d8d7e939, $d45254c57e70b972 = false)
	{
		if (!$this->dbh) {
			return false;
		}

		$d5d75f0e3efc5b42 = func_num_args();
		$C782698ae2e41f7f = func_get_args();
		$A8c046797d86d788 = array();
		$Ea22c4a9ab5b2176 = 1;

		while ($Ea22c4a9ab5b2176 < $d5d75f0e3efc5b42) {
			if (is_null($C782698ae2e41f7f[$Ea22c4a9ab5b2176]) || strtolower($C782698ae2e41f7f[$Ea22c4a9ab5b2176]) == 'null') {
				$A8c046797d86d788[] = null;
			} else {
				$A8c046797d86d788[] = $C782698ae2e41f7f[$Ea22c4a9ab5b2176];
			}

			$Ea22c4a9ab5b2176++;
		}

		if ($d45254c57e70b972 !== true) {
		} else {
			$this->dbh->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
		}

		try {
			$this->result = $this->dbh->prepare($A2833f35d8d7e939);
			$this->result->execute($A8c046797d86d788);
		} catch (Exception $c34ae71903f0d920) {
			$Fa4c2ad32d697a6b = trim(explode("\n", explode('Sent SQL:', $this->debugString($this->result))[1])[0]);

			if (strlen($Fa4c2ad32d697a6b) != 0) {
			} else {
				$Fa4c2ad32d697a6b = $A2833f35d8d7e939;
			}

			if (!class_exists('XUI')) {
			} else {
				XUI::E22bC2FFbb9818Ea('pdo', $c34ae71903f0d920->getMessage(), $Fa4c2ad32d697a6b);
			}

			return false;
		}

		return true;
	}

	public function simple_query($A2833f35d8d7e939)
	{
		try {
			$this->result = $this->dbh->query($A2833f35d8d7e939);
		} catch (Exception $c34ae71903f0d920) {
			if (!class_exists('XUI')) {
			} else {
				XUI::E22Bc2FFbb9818Ea('pdo', $c34ae71903f0d920->getMessage(), $A2833f35d8d7e939);
			}

			return false;
		}

		return true;
	}

	public function get_rows($d510b6620611d0d6 = false, $f15fddf2afad2554 = '', $cf14f1997596f1c7 = true, $b7547fc9e664473d = '')
	{
		if (!($this->dbh && $this->result)) {
			return false;
		}

		$daa1e4fbd7ec92ba = array();

		if (0 >= $this->result->rowCount()) {
		} else {
			foreach ($this->result->fetchAll(PDO::FETCH_ASSOC) as $c84a4809984cf9fa) {
				if ($d510b6620611d0d6 && array_key_exists($f15fddf2afad2554, $c84a4809984cf9fa)) {
					if (isset($daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]])) {
					} else {
						$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]] = array();
					}

					if (!$cf14f1997596f1c7) {
						if (!empty($b7547fc9e664473d) && array_key_exists($b7547fc9e664473d, $c84a4809984cf9fa)) {
							$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]][$c84a4809984cf9fa[$b7547fc9e664473d]] = $this->clean_row($c84a4809984cf9fa);
						} else {
							$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]][] = $this->clean_row($c84a4809984cf9fa);
						}
					} else {
						$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]] = $this->clean_row($c84a4809984cf9fa);
					}
				} else {
					$daa1e4fbd7ec92ba[] = $this->clean_row($c84a4809984cf9fa);
				}
			}
		}

		$this->result = null;

		return $daa1e4fbd7ec92ba;
	}

	public function get_row()
	{
		if (!($this->dbh && $this->result)) {
			return false;
		}

		$c84a4809984cf9fa = array();

		if (0 >= $this->result->rowCount()) {
		} else {
			$c84a4809984cf9fa = $this->result->fetch(PDO::FETCH_ASSOC);
		}

		$this->result = null;

		return $this->clean_row($c84a4809984cf9fa);
	}

	public function get_col()
	{
		if (!($this->dbh && $this->result)) {
			return false;
		}

		$c84a4809984cf9fa = false;

		if (0 >= $this->result->rowCount()) {
		} else {
			$c84a4809984cf9fa = $this->result->fetch();
			$c84a4809984cf9fa = $c84a4809984cf9fa[0];
		}

		$this->result = null;

		return $c84a4809984cf9fa;
	}

	public function escape($C9425e927984f356)
	{
		if (!$this->dbh) {
		} else {
			return $this->dbh->quote($C9425e927984f356);
		}
	}

	public function num_fields()
	{
		if (!($this->dbh && $this->result)) {
			return 0;
		}

		$d1f68d011f8458ee = $this->result->columnCount();

		return (empty($d1f68d011f8458ee) ? 0 : $d1f68d011f8458ee);
	}

	public function last_insert_id()
	{
		if (!$this->dbh) {
		} else {
			$fca1773cd263c51b = $this->dbh->lastInsertId();

			return (empty($fca1773cd263c51b) ? 0 : $fca1773cd263c51b);
		}
	}

	public function num_rows()
	{
		if (!($this->dbh && $this->result)) {
			return 0;
		}

		$A88a8b854513b7e0 = $this->result->rowCount();

		return (empty($A88a8b854513b7e0) ? 0 : $A88a8b854513b7e0);
	}

	public static function A48C65Aa888CD29a($b6842cb20051e925)
	{
		if ($b6842cb20051e925 != '') {
			$b6842cb20051e925 = str_replace(array("\r\n", "\n\r", "\r"), "\n", $b6842cb20051e925);
			$b6842cb20051e925 = str_replace('<', '&lt;', str_replace('>', '&gt;', $b6842cb20051e925));
			$b6842cb20051e925 = str_replace('<!--', '&#60;&#33;--', $b6842cb20051e925);
			$b6842cb20051e925 = str_replace('-->', '--&#62;', $b6842cb20051e925);
			$b6842cb20051e925 = str_ireplace('<script', '&#60;script', $b6842cb20051e925);
			$b6842cb20051e925 = preg_replace('/&amp;#([0-9]+);/s', '&#\\1;', $b6842cb20051e925);
			$b6842cb20051e925 = preg_replace('/&#(\\d+?)([^\\d;])/i', '&#\\1;\\2', $b6842cb20051e925);

			return trim($b6842cb20051e925);
		}

		return '';
	}

	public function clean_row($c84a4809984cf9fa)
	{
		foreach ($c84a4809984cf9fa as $Ea7db7f7a51d5edd => $F85a6116a4ebf0e5) {
			if (!$F85a6116a4ebf0e5) {
			} else {
				$c84a4809984cf9fa[$Ea7db7f7a51d5edd] = self::A48C65AA888cd29a($F85a6116a4ebf0e5);
			}
		}

		return $c84a4809984cf9fa;
	}
}
