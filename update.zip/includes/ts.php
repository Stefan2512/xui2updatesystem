<?php

class TS
{
	public static $rBuffer = null;
	public static $rPosition = null;
	public static $rByte = null;
	public static $rIndex = null;

	public function setPacket($b9f3f039ea3bf5ca)
	{
		self::$rBuffer = $b9f3f039ea3bf5ca;
		self::$rPosition = 7;
		list(self::$rByte) = array_values(unpack('C', self::$rBuffer[0]));
		self::$rIndex = 1;
	}

	public function getBits($Aad82ca21a37a3be)
	{
		$F80ea1676db4f3fe = 0;
		$C268c3a5ffbb5ba6 = 1 << self::$rPosition;

		while (0 < $Aad82ca21a37a3be) {
			$Aad82ca21a37a3be -= 1;
			$F80ea1676db4f3fe <<= 1;

			if (!(self::$rByte & $C268c3a5ffbb5ba6)) {
				$C268c3a5ffbb5ba6 >>= 1;
				self::$rPosition -= 1;

				if (self::$rPosition < 0) {
					self::$rPosition = 7;
					$C268c3a5ffbb5ba6 = 1 << self::$rPosition;

					if (self::$rIndex < strlen(self::$rBuffer)) {
						list(self::$rByte) = array_values(unpack('C', self::$rBuffer[self::$rIndex]));
					} else {
						self::$rByte = 0;
					}
				}
			} else {
				$F80ea1676db4f3fe |= 1;
			}

			self::$rIndex += 1;
		}

		return $F80ea1676db4f3fe;
	}

	public function parsePacket()
	{
		$a85e1b7d42c346a0 = array('sync_byte' => self::getBits(8), 'transport_error_indicator' => self::getBits(1), 'payload_unit_start_indicator' => self::getBits(1), 'transport_priority' => self::getBits(1), 'pid' => self::getBits(13), 'scrambling_control' => self::getBits(2), 'adaptation_field_exist' => self::getBits(2), 'continuity_counter' => self::getBits(4));

		if (($a85e1b7d42c346a0['adaptation_field_exist'] || $a85e1b7d42c346a0['adaptation_field_exist'] == 3)) {
			$ea611e7d2fd36911 = self::$rIndex;
			$a85e1b7d42c346a0['adaptation_field_length'] = self::getBits(8);

			if ($a85e1b7d42c346a0['adaptation_field_length'] == 7) {
				$a85e1b7d42c346a0 = array_merge($a85e1b7d42c346a0, array('discontinuity_indicator' => self::getBits(1), 'random_access_indicator' => self::getBits(1), 'priority_indicator' => self::getBits(1), 'pcr_flag' => self::getBits(1), 'opcr_flag' => self::getBits(1), 'splicing_point_flag' => self::getBits(1), 'transport_private_data_flag' => self::getBits(1), 'adaptation_field_extension_flag' => self::getBits(1)));

				if ($a85e1b7d42c346a0['pcr_flag']) {
					$a85e1b7d42c346a0 = array_merge($a85e1b7d42c346a0, array('program_clock_reference_base' => self::getBits(33), 'reserved_pcr' => self::getBits(6), 'program_clock_reference_extension' => self::getBits(9)));
					$a85e1b7d42c346a0['pcr'] = ($a85e1b7d42c346a0['program_clock_reference_base'] * 300 + $a85e1b7d42c346a0['program_clock_reference_extension']) / 27000000;
				}

				if ($a85e1b7d42c346a0['opcr_flag']) {
					$a85e1b7d42c346a0 = array_merge($a85e1b7d42c346a0, array('original_program_clock_reference_base' => self::getBits(33), 'reserved_opcr' => self::getBits(6), 'original_program_clock_reference_extension' => self::getBits(9)));
					$a85e1b7d42c346a0['opcr'] = ($a85e1b7d42c346a0['original_program_clock_reference_base'] * 300 + $a85e1b7d42c346a0['original_program_clock_reference_extension']) / 27000000;
				}

				if ($a85e1b7d42c346a0['splicing_point_flag']) {
					$a85e1b7d42c346a0['splice_countdown'] = self::getBits(8);
				}

				if ($a85e1b7d42c346a0['transport_private_data_flag']) {
					$a85e1b7d42c346a0['transport_private_data_length'] = self::getBits(8);
					self::stepBytes($a85e1b7d42c346a0['transport_private_data_length']);
				}
			} else {
				unset($a85e1b7d42c346a0['adaptation_field_length']);
			}
		}

		if ($a85e1b7d42c346a0['pid'] == 0) {
			$a85e1b7d42c346a0['pointer_field'] = self::getBits(8);

			if ($a85e1b7d42c346a0['pointer_field']) {
				self::stepBytes($a85e1b7d42c346a0['pointer_field']);
			}

			$a85e1b7d42c346a0 = array_merge($a85e1b7d42c346a0, array('type' => 'pat', 'table_id' => self::getBits(8), 'section_syntax_indicator' => self::getBits(1), 'marker' => self::getBits(1), 'reserved_1' => self::getBits(2), 'section_length' => self::getBits(12), 'transport_stream_id' => self::getBits(16), 'reserved_2' => self::getBits(2), 'version_number' => self::getBits(5), 'current_next_indicator' => self::getBits(1), 'section_number' => self::getBits(8), 'last_section_number' => self::getBits(8)));
		} else {
			if ($a85e1b7d42c346a0['payload_unit_start_indicator']) {
				self::$rBuffer = substr(self::$rBuffer, self::$rIndex, 188);
				self::$rIndex = 0;
				$a85e1b7d42c346a0 = array_merge($a85e1b7d42c346a0, array('type' => 'pes', 'packet_start_prefix' => self::getBits(24), 'stream_id' => self::getBits(8), 'pes_packet_length' => self::getBits(16), 'marker_bits' => self::getBits(2), 'scrambling_control' => self::getBits(2), 'priority' => self::getBits(1), 'data_alignment_indicator' => self::getBits(1), 'copyright' => self::getBits(1), 'original_or_copy' => self::getBits(1), 'pts_dts_indicator' => self::getBits(2), 'escr_flag' => self::getBits(1), 'es_rate_flag' => self::getBits(1), 'dsm_trick_mode_flag' => self::getBits(1), 'additional_copy_info_flag' => self::getBits(1), 'crc_flag' => self::getBits(1), 'extension_flag' => self::getBits(1), 'pes_header_length' => self::getBits(8)));

				if (($a85e1b7d42c346a0['pts_dts_indicator'] == 2 || $a85e1b7d42c346a0['pts_dts_indicator'] == 3)) {
					self::getBits(4);
					$f10e7581f67188ae = self::getBits(3);
					self::getBits(1);
					$d5e2a33ff6d8e5d2 = self::getBits(15);
					self::getBits(1);
					$c82bc65e4f0b4556 = self::getBits(15);
					self::getBits(1);
					$a85e1b7d42c346a0['pts'] = ($f10e7581f67188ae << 30) + ($d5e2a33ff6d8e5d2 << 15) + $c82bc65e4f0b4556;
				}

				if ($a85e1b7d42c346a0['pts_dts_indicator'] == 3) {
					self::getBits(4);
					$Ae315a17127f37fb = self::getBits(3);
					self::getBits(1);
					$C14118b3988e948c = self::getBits(15);
					self::getBits(1);
					$Baf45fecfb56e28e = self::getBits(15);
					self::getBits(1);
					$a85e1b7d42c346a0['dts'] = ($Ae315a17127f37fb << 30) + ($C14118b3988e948c << 15) + $Baf45fecfb56e28e;
				}
			}
		}

		return $a85e1b7d42c346a0;
	}

	public function stepBytes($B1e64f338fac8781)
	{
		$a27e64cc6ce01033 = substr(self::$rBuffer, self::$rIndex - 1, $B1e64f338fac8781);

		foreach (range(0, $B1e64f338fac8781) as $Ea22c4a9ab5b2176) {
			self::getBits(8);
		}

		return $a27e64cc6ce01033;
	}
}
