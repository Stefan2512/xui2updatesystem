<?php

if (!class_exists('Database')) {
	class Database
	{
		public $result = null;
		public $dbh = null;
		public $connected = false;

		public function __construct($A50bdc318bc06ab5 = true)
		{
			$this->dbh = false;

			if (!$A50bdc318bc06ab5) {
			} else {
				$this->db_connect();
			}
		}

		public function close_mysql()
		{
			if (!$this->connected) {
			} else {
				$this->connected = false;
				$this->dbh = null;
			}

			return true;
		}

		public function __destruct()
		{
			$this->close_mysql();
		}

		public function ping()
		{
			try {
				$this->dbh->query('SELECT 1');
			} catch (Exception $c34ae71903f0d920) {
				return false;
			}

			return true;
		}

		public function db_connect()
		{
			try {
				$this->dbh = Xui\Functions::connect('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');

				if ($this->dbh) {
				} else {
					exit(json_encode(array('error' => 'MySQL: Cannot connect to database! Please check credentials.')));
				}
			} catch (PDOException $c34ae71903f0d920) {
				exit(json_encode(array('error' => 'MySQL: ' . $c34ae71903f0d920->getMessage())));
			}
			$this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->connected = true;

			return true;
		}

		public function query($A2833f35d8d7e939, $d45254c57e70b972 = false)
		{
			if (!$this->dbh) {
				return false;
			}

			$d5d75f0e3efc5b42 = func_num_args();
			$C782698ae2e41f7f = func_get_args();
			$A8c046797d86d788 = array();

			for ($Ea22c4a9ab5b2176 = 1; $Ea22c4a9ab5b2176 < $d5d75f0e3efc5b42; $Ea22c4a9ab5b2176++) {
				if (is_null($C782698ae2e41f7f[$Ea22c4a9ab5b2176]) || strtolower($C782698ae2e41f7f[$Ea22c4a9ab5b2176]) == 'null') {
					$A8c046797d86d788[] = null;
				} else {
					$A8c046797d86d788[] = $C782698ae2e41f7f[$Ea22c4a9ab5b2176];
				}
			}

			if ($d45254c57e70b972 !== true) {
			} else {
				$this->dbh->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
			}

			try {
				$this->result = $this->dbh->prepare($A2833f35d8d7e939);
				$this->result->execute($A8c046797d86d788);
			} catch (Exception $c34ae71903f0d920) {
				return false;
			}

			return true;
		}

		public function simple_query($A2833f35d8d7e939)
		{
			try {
				$this->result = $this->dbh->query($A2833f35d8d7e939);
			} catch (Exception $c34ae71903f0d920) {
				return false;
			}

			return true;
		}

		public function get_rows($d510b6620611d0d6 = false, $f15fddf2afad2554 = '', $cf14f1997596f1c7 = true, $b7547fc9e664473d = '')
		{
			if (!($this->dbh && $this->result)) {
				return false;
			}

			$daa1e4fbd7ec92ba = array();

			if (0 >= $this->result->rowCount()) {
			} else {
				foreach ($this->result->fetchAll(PDO::FETCH_ASSOC) as $c84a4809984cf9fa) {
					if ($d510b6620611d0d6 && array_key_exists($f15fddf2afad2554, $c84a4809984cf9fa)) {
						if (isset($daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]])) {
						} else {
							$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]] = array();
						}

						if (!$cf14f1997596f1c7) {
							if (!empty($b7547fc9e664473d) && array_key_exists($b7547fc9e664473d, $c84a4809984cf9fa)) {
								$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]][$c84a4809984cf9fa[$b7547fc9e664473d]] = $c84a4809984cf9fa;
							} else {
								$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]][] = $c84a4809984cf9fa;
							}
						} else {
							$daa1e4fbd7ec92ba[$c84a4809984cf9fa[$f15fddf2afad2554]] = $c84a4809984cf9fa;
						}
					} else {
						$daa1e4fbd7ec92ba[] = $c84a4809984cf9fa;
					}
				}
			}

			$this->result = null;

			return $daa1e4fbd7ec92ba;
		}

		public function get_row()
		{
			if (!($this->dbh && $this->result)) {
				return false;
			}

			$c84a4809984cf9fa = array();

			if (0 >= $this->result->rowCount()) {
			} else {
				$c84a4809984cf9fa = $this->result->fetch(PDO::FETCH_ASSOC);
			}

			$this->result = null;

			return $c84a4809984cf9fa;
		}

		public function get_col()
		{
			if (!($this->dbh && $this->result)) {
				return false;
			}

			$c84a4809984cf9fa = false;

			if (0 >= $this->result->rowCount()) {
			} else {
				$c84a4809984cf9fa = $this->result->fetch();
				$c84a4809984cf9fa = $c84a4809984cf9fa[0];
			}

			$this->result = null;

			return $c84a4809984cf9fa;
		}

		public function escape($C9425e927984f356)
		{
			if (!$this->dbh) {
			} else {
				return $this->dbh->quote($C9425e927984f356);
			}
		}

		public function num_fields()
		{
			if (!($this->dbh && $this->result)) {
				return 0;
			}

			$d1f68d011f8458ee = $this->result->columnCount();

			return (empty($d1f68d011f8458ee) ? 0 : $d1f68d011f8458ee);
		}

		public function last_insert_id()
		{
			if (!$this->dbh) {
			} else {
				$fca1773cd263c51b = $this->dbh->lastInsertId();

				return (empty($fca1773cd263c51b) ? 0 : $fca1773cd263c51b);
			}
		}

		public function num_rows()
		{
			if (!($this->dbh && $this->result)) {
				return 0;
			}

			$A88a8b854513b7e0 = $this->result->rowCount();

			return (empty($A88a8b854513b7e0) ? 0 : $A88a8b854513b7e0);
		}
	}
}

class XUI
{
	public static $db = null;
	public static $redis = null;
	public static $rRequest = array();
	public static $rConfig = array();
	public static $rSettings = array();
	public static $rBouquets = array();
	public static $rServers = array();
	public static $rSegmentSettings = array();
	public static $rBlockedUA = array();
	public static $rBlockedISP = array();
	public static $rBlockedIPs = array();
	public static $rBlockedServers = array();
	public static $rAllowedIPs = array();
	public static $rCategories = array();
	public static $rProxies = array();
	public static $rFFMPEG_CPU = null;
	public static $rFFMPEG_GPU = null;
	public static $rCached = null;
	public static $rAccess = null;

	public static function init($E9ff1197d3f1304b = false)
	{
		if (!empty($_GET)) {
			self::eE2659ae23E1E78c($_GET);
		}

		if (!empty($_POST)) {
			self::ee2659aE23E1E78C($_POST);
		}

		if (!empty($_SESSION)) {
			self::Ee2659AE23E1E78C($_SESSION);
		}

		if (!empty($_COOKIE)) {
			self::eE2659AE23E1e78c($_COOKIE);
		}
		$a68b12348744a7ff = @self::c13491863979fcF0($_GET, array());
		self::$rRequest = @self::C13491863979fcF0($_POST, $a68b12348744a7ff);
		self::$rConfig = parse_ini_file(
			CONFIG_PATH . 'config.ini'
		);

		if (!defined('SERVER_ID')) {
			define(
				'SERVER_ID',
				intval(self::$rConfig['server_id'])
			);
		}

		if (!self::$rSettings) {
			self::$rSettings = self::ABB674425a8b1B0d(
				'settings'
			);
		}

		if (!empty(self::$rSettings['default_timezone'])) {
			date_default_timezone_set(
				self::$rSettings[
					'default_timezone'
				]
			);
		}

		if ((self::$rSettings['on_demand_wait_time'] == 0)) {
			self::$rSettings[
				'on_demand_wait_time'
			] = 15;
		}

		switch (self::$rSettings['ffmpeg_cpu']) {
			case '4.4':
				self::$rFFMPEG_CPU = FFMPEG_BIN_44;

				break;

			case '4.3':
				self::$rFFMPEG_CPU = FFMPEG_BIN_43;

				break;

			default:
				self::$rFFMPEG_CPU = FFMPEG_BIN_40;

				break;
		}
		self::$rFFMPEG_GPU = FFMPEG_BIN_40;
		self::$rCached = self::A996a3Eb6998fca4();
		self::$rServers = self::aBb674425A8b1B0d(
			'servers'
		);
		self::$rBlockedUA = self::abb674425A8B1B0d(
			'blocked_ua'
		);
		self::$rBlockedISP = self::Abb674425a8B1b0D(
			'blocked_isp'
		);
		self::$rBlockedIPs = self::ABb674425a8b1b0D(
			'blocked_ips'
		);
		self::$rBlockedServers = self::Abb674425A8B1B0d(
			'blocked_servers'
		);
		self::$rAllowedIPs = self::AbB674425a8B1B0D(
			'allowed_ips'
		);
		self::$rProxies = self::ABb674425A8b1B0D(
			'proxy_servers'
		);
		self::$rSegmentSettings = array(
			'seg_time' => intval(
				self::$rSettings['seg_time']
			),
			'seg_list_size' => intval(
				self::$rSettings[
					'seg_list_size'
				]
			),
		);
		self::AD0a56Be17E95E81($E9ff1197d3f1304b);
	}

	public static function A996a3EB6998fCa4()
	{
		if (!self::$rSettings['enable_cache']) {
			return false;
		}

		return file_exists(CACHE_TMP_PATH . 'cache_complete');
	}

	public static function AD0a56bE17e95e81($c67112a71ee18532 = true)
	{
		self::$db = new Database($c67112a71ee18532);
	}

	public static function F6cc02011179dFc7()
	{
		if (!self::$db) {
		} else {
			self::$db->close_mysql();
			self::$db = null;
		}
	}

	public static function ABb674425a8B1B0d($Eace02ff35917268)
	{
		$a27e64cc6ce01033 = (file_get_contents(CACHE_TMP_PATH . $Eace02ff35917268) ?: null);

		return igbinary_unserialize($a27e64cc6ce01033);
	}

	public static function bA0a47B17B7E0F65($a27e64cc6ce01033, $D3fa098be3f297cd)
	{
		$a27e64cc6ce01033 = explode('|', $a27e64cc6ce01033 . '|');
		$d156d70a98f8b08c = base64_decode($a27e64cc6ce01033[0]);
		$e7ae92f8387d5936 = base64_decode($a27e64cc6ce01033[1]);

		if (strlen($e7ae92f8387d5936) === mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC)) {
			$D3fa098be3f297cd = pack('H*', $D3fa098be3f297cd);
			$e0c0d6359f5bd8d6 = trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $D3fa098be3f297cd, $d156d70a98f8b08c, MCRYPT_MODE_CBC, $e7ae92f8387d5936));
			$C3cdd40816db3399 = substr($e0c0d6359f5bd8d6, -64);
			$e0c0d6359f5bd8d6 = substr($e0c0d6359f5bd8d6, 0, -64);
			$Eebc577f200c5584 = hash_hmac('sha256', $e0c0d6359f5bd8d6, substr(bin2hex($D3fa098be3f297cd), -32));

			if ($Eebc577f200c5584 === $C3cdd40816db3399) {
				$e0c0d6359f5bd8d6 = unserialize($e0c0d6359f5bd8d6);

				return $e0c0d6359f5bd8d6;
			}

			return false;
		}

		return false;
	}

	public static function Ee2659AE23E1e78c(&$a27e64cc6ce01033, $Bb3e51c7e44e9edc = 0)
	{
		if (10 > $Bb3e51c7e44e9edc) {
			foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
				if (is_array($b6842cb20051e925)) {
					self::Ee2659ae23e1e78c($a27e64cc6ce01033[$D3fa098be3f297cd], ++$Bb3e51c7e44e9edc);
				} else {
					$b6842cb20051e925 = str_replace(chr('0'), '', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace("\x0", '', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace("\x0", '', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace('../', '&#46;&#46;/', $b6842cb20051e925);
					$b6842cb20051e925 = str_replace('&#8238;', '', $b6842cb20051e925);
					$a27e64cc6ce01033[$D3fa098be3f297cd] = $b6842cb20051e925;
				}
			}
		} else {
			return null;
		}
	}

	public static function c13491863979fcF0(&$a27e64cc6ce01033, $a68b12348744a7ff = array(), $Bb3e51c7e44e9edc = 0)
	{
		if (20 > $Bb3e51c7e44e9edc) {
			if (is_array($a27e64cc6ce01033)) {
				foreach ($a27e64cc6ce01033 as $D3fa098be3f297cd => $b6842cb20051e925) {
					if (is_array($b6842cb20051e925)) {
						$a68b12348744a7ff[$D3fa098be3f297cd] = self::c13491863979fCf0($a27e64cc6ce01033[$D3fa098be3f297cd], array(), $Bb3e51c7e44e9edc + 1);
					} else {
						$D3fa098be3f297cd = self::Ee07012de438c358($D3fa098be3f297cd);
						$b6842cb20051e925 = self::A48C65Aa888cD29A($b6842cb20051e925);
						$a68b12348744a7ff[$D3fa098be3f297cd] = $b6842cb20051e925;
					}
				}

				return $a68b12348744a7ff;
			} else {
				return $a68b12348744a7ff;
			}
		} else {
			return $a68b12348744a7ff;
		}
	}

	public static function EE07012DE438c358($D3fa098be3f297cd)
	{
		if ($D3fa098be3f297cd !== '') {
			$D3fa098be3f297cd = htmlspecialchars(urldecode($D3fa098be3f297cd));
			$D3fa098be3f297cd = str_replace('..', '', $D3fa098be3f297cd);
			$D3fa098be3f297cd = preg_replace('/\\_\\_(.+?)\\_\\_/', '', $D3fa098be3f297cd);
			$D3fa098be3f297cd = preg_replace('/^([\\w\\.\\-\\_]+)$/', '$1', $D3fa098be3f297cd);

			return $D3fa098be3f297cd;
		}

		return '';
	}

	public static function a48C65aa888cd29A($b6842cb20051e925)
	{
		if ($b6842cb20051e925 != '') {
			$b6842cb20051e925 = str_replace(array("\r\n", "\n\r", "\r"), "\n", $b6842cb20051e925);
			$b6842cb20051e925 = str_replace('<!--', '&#60;&#33;--', $b6842cb20051e925);
			$b6842cb20051e925 = str_replace('-->', '--&#62;', $b6842cb20051e925);
			$b6842cb20051e925 = str_ireplace('<script', '&#60;script', $b6842cb20051e925);
			$b6842cb20051e925 = preg_replace('/&amp;#([0-9]+);/s', '&#\\1;', $b6842cb20051e925);
			$b6842cb20051e925 = preg_replace('/&#(\\d+?)([^\\d;])/i', '&#\\1;\\2', $b6842cb20051e925);

			return trim($b6842cb20051e925);
		}

		return '';
	}

	public static function fc8474658ec80360($c59ec257c284c894 = null)
	{
		if (self::$rSettings['flood_limit'] != 0) {
			if ($c59ec257c284c894) {
			} else {
				$c59ec257c284c894 = self::A9Bc416fa6Fa55c3();
			}

			if (!(empty($c59ec257c284c894) || in_array($c59ec257c284c894, self::$rAllowedIPs))) {
				$D4a9631cb1db6a7b = array_filter(array_unique(explode(',', self::$rSettings['flood_ips_exclude'])));

				if (!in_array($c59ec257c284c894, $D4a9631cb1db6a7b)) {
					$b784c383b47a49fd = FLOOD_TMP_PATH . $c59ec257c284c894;

					if (file_exists($b784c383b47a49fd)) {
						$A707ccd39fee7276 = json_decode(file_get_contents($b784c383b47a49fd), true);
						$be54debae5869cd3 = self::$rSettings['flood_seconds'];
						$A96a38e6b91953f2 = self::$rSettings['flood_limit'];

						if (time() - $A707ccd39fee7276['last_request'] <= $be54debae5869cd3) {
							$A707ccd39fee7276['requests']++;

							if ($A96a38e6b91953f2 > $A707ccd39fee7276['requests']) {
								$A707ccd39fee7276['last_request'] = time();
								file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
							} else {
								if (in_array($c59ec257c284c894, self::$rBlockedIPs)) {
								} else {
									if (self::$rCached) {
										self::cF592C234Dcd0b19('flood_attack/' . $c59ec257c284c894, 1);
									} else {
										self::$db->query('INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES(?,?,?)', $c59ec257c284c894, 'FLOOD ATTACK', time());
									}

									touch(FLOOD_TMP_PATH . 'block_' . $c59ec257c284c894);
								}

								unlink($b784c383b47a49fd);

								return null;
							}
						} else {
							$A707ccd39fee7276['requests'] = 0;
							$A707ccd39fee7276['last_request'] = time();
							file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
						}
					} else {
						file_put_contents($b784c383b47a49fd, json_encode(array('requests' => 0, 'last_request' => time())), LOCK_EX);
					}
				} else {
					return null;
				}
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function B6f740fAbC7265bF($c59ec257c284c894 = null, $C3cdd40816db3399 = null, $a71afc14d6cd090d = null)
	{
		if ($C3cdd40816db3399 || $a71afc14d6cd090d) {
			if (!($C3cdd40816db3399 && self::$rSettings['bruteforce_mac_attempts'] == 0)) {
				if (!($a71afc14d6cd090d && self::$rSettings['bruteforce_username_attempts'] == 0)) {
					if ($c59ec257c284c894) {
					} else {
						$c59ec257c284c894 = self::A9bC416FA6fA55C3();
					}

					if (!(empty($c59ec257c284c894) || in_array($c59ec257c284c894, self::$rAllowedIPs))) {
						$D4a9631cb1db6a7b = array_filter(array_unique(explode(',', self::$rSettings['flood_ips_exclude'])));

						if (!in_array($c59ec257c284c894, $D4a9631cb1db6a7b)) {
							$b9dd61c40657d13d = (!is_null($C3cdd40816db3399) ? 'mac' : 'user');
							$Be47c94a460069d8 = (!is_null($C3cdd40816db3399) ? $C3cdd40816db3399 : $a71afc14d6cd090d);
							$b784c383b47a49fd = FLOOD_TMP_PATH . $c59ec257c284c894 . '_' . $b9dd61c40657d13d;

							if (file_exists($b784c383b47a49fd)) {
								$A707ccd39fee7276 = json_decode(file_get_contents($b784c383b47a49fd), true);
								$be54debae5869cd3 = intval(self::$rSettings['bruteforce_frequency']);
								$A96a38e6b91953f2 = intval(self::$rSettings[array('mac' => 'bruteforce_mac_attempts', 'user' => 'bruteforce_username_attempts')[$b9dd61c40657d13d]]);
								$A707ccd39fee7276['attempts'] = self::c7d4656747098c59($A707ccd39fee7276['attempts'], $be54debae5869cd3);

								if (in_array($Be47c94a460069d8, array_keys($A707ccd39fee7276['attempts']))) {
								} else {
									$A707ccd39fee7276['attempts'][$Be47c94a460069d8] = time();

									if ($A96a38e6b91953f2 > count($A707ccd39fee7276['attempts'])) {
										file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
									} else {
										if (in_array($c59ec257c284c894, self::$rBlockedIPs)) {
										} else {
											if (self::$rCached) {
												self::CF592c234dCD0B19('bruteforce_attack/' . $c59ec257c284c894, 1);
											} else {
												self::$db->query('INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES(?,?,?)', $c59ec257c284c894, 'BRUTEFORCE ' . strtoupper($b9dd61c40657d13d) . ' ATTACK', time());
											}

											touch(FLOOD_TMP_PATH . 'block_' . $c59ec257c284c894);
										}

										unlink($b784c383b47a49fd);

										return null;
									}
								}
							} else {
								$A707ccd39fee7276 = array('attempts' => array($Be47c94a460069d8 => time()));
								file_put_contents($b784c383b47a49fd, json_encode($A707ccd39fee7276), LOCK_EX);
							}
						} else {
							return null;
						}
					} else {
						return null;
					}
				} else {
					return null;
				}
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function d3e665B5427479Fe($d51e425eb7375255, $c59ec257c284c894 = null)
	{
		if (self::$rSettings['auth_flood_limit'] != 0) {
			if (!$d51e425eb7375255['is_restreamer']) {
				if ($c59ec257c284c894) {
				} else {
					$c59ec257c284c894 = self::a9bc416FA6fa55c3();
				}

				if (!(empty($c59ec257c284c894) || in_array($c59ec257c284c894, self::$rAllowedIPs))) {
					$D4a9631cb1db6a7b = array_filter(array_unique(explode(',', self::$rSettings['flood_ips_exclude'])));

					if (!in_array($c59ec257c284c894, $D4a9631cb1db6a7b)) {
						$C3aa51e8b5c8bdc2 = FLOOD_TMP_PATH . intval($d51e425eb7375255['id']) . '_' . $c59ec257c284c894;

						if (file_exists($C3aa51e8b5c8bdc2)) {
							$A707ccd39fee7276 = json_decode(file_get_contents($C3aa51e8b5c8bdc2), true);

							if (!(isset($A707ccd39fee7276['block_until']) && time() < $A707ccd39fee7276['block_until'])) {
							} else {
								sleep(intval(self::$rSettings['auth_flood_sleep']));
							}

							$be54debae5869cd3 = self::$rSettings['auth_flood_seconds'];
							$A96a38e6b91953f2 = self::$rSettings['auth_flood_limit'];
							$A707ccd39fee7276['attempts'] = self::C7D4656747098c59($A707ccd39fee7276['attempts'], $be54debae5869cd3, true);

							if ($A96a38e6b91953f2 > count($A707ccd39fee7276['attempts'])) {
							} else {
								$A707ccd39fee7276['block_until'] = time() + intval(self::$rSettings['auth_flood_seconds']);
							}

							$A707ccd39fee7276['attempts'][] = time();
							file_put_contents($C3aa51e8b5c8bdc2, json_encode($A707ccd39fee7276), LOCK_EX);
						} else {
							file_put_contents($C3aa51e8b5c8bdc2, json_encode(array('attempts' => array(time()))), LOCK_EX);
						}
					} else {
						return null;
					}
				} else {
					return null;
				}
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static function isProxied($d58b4f8653a391d8)
	{
		return self::$rServers[$d58b4f8653a391d8]['enable_proxy'];
	}

	public static function BB41388445081a3D($c59ec257c284c894)
	{
		if (!isset(self::$rProxies[$c59ec257c284c894])) {
		} else {
			return self::$rProxies[$c59ec257c284c894];
		}
	}

	public static function c7d4656747098c59($ed4c668b21748203, $Dea739940867923b, $A2334a366640c078 = false)
	{
		$A11bd3dafa3511e9 = array();
		$C4af185e24cf9086 = time();

		if ($A2334a366640c078) {
			foreach ($ed4c668b21748203 as $C402db0b1e917573) {
				if ($C4af185e24cf9086 - $C402db0b1e917573 > $Dea739940867923b) {
				} else {
					$A11bd3dafa3511e9[] = $C402db0b1e917573;
				}
			}
		} else {
			foreach ($ed4c668b21748203 as $fa682959477a699f => $C402db0b1e917573) {
				if ($C4af185e24cf9086 - $C402db0b1e917573 > $Dea739940867923b) {
				} else {
					$A11bd3dafa3511e9[$fa682959477a699f] = $C402db0b1e917573;
				}
			}
		}

		return $A11bd3dafa3511e9;
	}

	public static function Cdd1bc14d819BE74($Fa288895c003c519 = false)
	{
		return json_decode(file_get_contents(CACHE_TMP_PATH . (($Fa288895c003c519 ? 'proxy_capacity' : 'servers_capacity'))), true);
	}

	public static function B3Ed925e7969F61a($F26087d31c2bbe4d, $F9452a7efafa1aba, $D4253f9520627819, $efc0f8f3059e4104, $f72bad5bd13565f1 = '', $E379394c7b1a273f = '')
	{
		if (self::$rCached) {
			$f523e362fb81d6c8 = (igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . $F26087d31c2bbe4d)) ?: null);
			$f523e362fb81d6c8['bouquets'] = self::getBouquetMap($F26087d31c2bbe4d);
		} else {
			$f523e362fb81d6c8 = self::AD41Bf0664804fa8($F26087d31c2bbe4d);
		}

		if ($f523e362fb81d6c8) {
			$f523e362fb81d6c8['info']['bouquets'] = $f523e362fb81d6c8['bouquets'];
			$c43b488500f8fab7 = array();

			if ($E379394c7b1a273f == 'archive') {
				if (!(0 < $f523e362fb81d6c8['info']['tv_archive_duration'] && 0 < $f523e362fb81d6c8['info']['tv_archive_server_id'] && array_key_exists($f523e362fb81d6c8['info']['tv_archive_server_id'], self::$rServers))) {
				} else {
					$c43b488500f8fab7 = array($f523e362fb81d6c8['info']['tv_archive_server_id']);
				}
			} else {
				if (!($f523e362fb81d6c8['info']['direct_source'] == 1 && $f523e362fb81d6c8['info']['direct_proxy'] == 0)) {
					foreach (self::$rServers as $d58b4f8653a391d8 => $cc5f26dd881329b7) {
						if (!(!array_key_exists($d58b4f8653a391d8, $f523e362fb81d6c8['servers']) || !$cc5f26dd881329b7['server_online'] || $cc5f26dd881329b7['server_type'] != 0)) {
							if (!isset($f523e362fb81d6c8['servers'][$d58b4f8653a391d8])) {
							} else {
								if ($E379394c7b1a273f == 'movie') {
									if (!((!empty($f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['pid']) && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['to_analyze'] == 0 && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['stream_status'] == 0 || $f523e362fb81d6c8['info']['direct_source'] == 1 && $f523e362fb81d6c8['info']['direct_proxy'] == 1) && ($f523e362fb81d6c8['info']['target_container'] == $F9452a7efafa1aba || ($F9452a7efafa1aba = 'srt')) && $cc5f26dd881329b7['timeshift_only'] == 0)) {
									} else {
										$c43b488500f8fab7[] = $d58b4f8653a391d8;
									}
								} else {
									if (!(($f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['on_demand'] == 1 && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['stream_status'] != 1 || 0 < $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['pid'] && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['stream_status'] == 0) && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['to_analyze'] == 0 && (int) $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['delay_available_at'] <= time() && $cc5f26dd881329b7['timeshift_only'] == 0 || $f523e362fb81d6c8['info']['direct_source'] == 1 && $f523e362fb81d6c8['info']['direct_proxy'] == 1)) {
									} else {
										$c43b488500f8fab7[] = $d58b4f8653a391d8;
									}
								}
							}
						}
					}
				} else {
					header('Location: ' . str_replace(' ', '%20', json_decode($f523e362fb81d6c8['info']['stream_source'], true)[0]));

					exit();
				}
			}

			if (!empty($c43b488500f8fab7)) {
				shuffle($c43b488500f8fab7);
				$a9d38d288d6824ad = self::cdd1Bc14d819bE74();
				$e1d30a1d66778eaf = array();

				foreach ($c43b488500f8fab7 as $d58b4f8653a391d8) {
					$c9a044772607fb06 = (isset($a9d38d288d6824ad[$d58b4f8653a391d8]['online_clients']) ? $a9d38d288d6824ad[$d58b4f8653a391d8]['online_clients'] : 0);

					if ($c9a044772607fb06 != 0) {
					} else {
						$a9d38d288d6824ad[$d58b4f8653a391d8]['capacity'] = 0;
					}

					$e1d30a1d66778eaf[$d58b4f8653a391d8] = (0 < self::$rServers[$d58b4f8653a391d8]['total_clients'] && $c9a044772607fb06 < self::$rServers[$d58b4f8653a391d8]['total_clients'] ? $a9d38d288d6824ad[$d58b4f8653a391d8]['capacity'] : false);
				}
				$e1d30a1d66778eaf = array_filter($e1d30a1d66778eaf, 'is_numeric');

				if (empty($e1d30a1d66778eaf)) {
					if ($E379394c7b1a273f == 'archive') {
						return null;
					}

					return array();
				}

				$f16991461acd03bf = array_keys($e1d30a1d66778eaf);
				$E287c1867f711629 = array_values($e1d30a1d66778eaf);
				array_multisort($E287c1867f711629, SORT_ASC, $f16991461acd03bf, SORT_ASC);
				$e1d30a1d66778eaf = array_combine($f16991461acd03bf, $E287c1867f711629);

				if ($F9452a7efafa1aba == 'rtmp' && array_key_exists(SERVER_ID, $e1d30a1d66778eaf)) {
					$B5f1fb70f197b910 = SERVER_ID;
				} else {
					if (isset($D4253f9520627819) && $D4253f9520627819['force_server_id'] != 0 && array_key_exists($D4253f9520627819['force_server_id'], $e1d30a1d66778eaf)) {
						$B5f1fb70f197b910 = $D4253f9520627819['force_server_id'];
					} else {
						$ceb41d1730714460 = array();

						foreach (array_keys($e1d30a1d66778eaf) as $d58b4f8653a391d8) {
							if (self::$rServers[$d58b4f8653a391d8]['enable_geoip'] == 1) {
								if (in_array($efc0f8f3059e4104, self::$rServers[$d58b4f8653a391d8]['geoip_countries'])) {
									$B5f1fb70f197b910 = $d58b4f8653a391d8;

									break;
								}

								if (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'strict') {
									unset($e1d30a1d66778eaf[$d58b4f8653a391d8]);
								} else {
									if (isset($f523e362fb81d6c8) && !self::$rSettings['ondemand_balance_equal'] && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['on_demand']) {
										$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'low_priority' ? 3 : 2);
									} else {
										$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'low_priority' ? 2 : 1);
									}
								}
							} else {
								if (self::$rServers[$d58b4f8653a391d8]['enable_isp'] == 1) {
									if (in_array(strtolower(trim(preg_replace('/[^A-Za-z0-9 ]/', '', $f72bad5bd13565f1))), self::$rServers[$d58b4f8653a391d8]['isp_names'])) {
										$B5f1fb70f197b910 = $d58b4f8653a391d8;

										break;
									}

									if (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'strict') {
										unset($e1d30a1d66778eaf[$d58b4f8653a391d8]);
									} else {
										if (isset($f523e362fb81d6c8) && !self::$rSettings['ondemand_balance_equal'] && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['on_demand']) {
											$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'low_priority' ? 3 : 2);
										} else {
											$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'low_priority' ? 2 : 1);
										}
									}
								} else {
									if (isset($f523e362fb81d6c8) && !self::$rSettings['ondemand_balance_equal'] && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['on_demand']) {
										$ceb41d1730714460[$d58b4f8653a391d8] = 2;
									} else {
										$ceb41d1730714460[$d58b4f8653a391d8] = 1;
									}
								}
							}
						}

						if (!(empty($ceb41d1730714460) && empty($B5f1fb70f197b910))) {
							$B5f1fb70f197b910 = (empty($B5f1fb70f197b910) ? array_search(min($ceb41d1730714460), $ceb41d1730714460) : $B5f1fb70f197b910);
						} else {
							return false;
						}
					}
				}

				if ($E379394c7b1a273f == 'archive') {
					return $B5f1fb70f197b910;
				}

				$f523e362fb81d6c8['info']['redirect_id'] = $B5f1fb70f197b910;
				$fc4c58c5d1cd68d1 = $B5f1fb70f197b910;

				return array_merge($f523e362fb81d6c8['info'], $f523e362fb81d6c8['servers'][$fc4c58c5d1cd68d1]);
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public static function B97D7ACBCf7c7A5e($Fd50c63671da34f8)
	{
		if (!(isset(self::$rSettings[$Fd50c63671da34f8]) && 0 < strlen(self::$rSettings[$Fd50c63671da34f8]))) {
			switch ($Fd50c63671da34f8) {
				case 'connected_video_path':
					if (!file_exists(VIDEO_PATH . 'connected.ts')) {
						break;
					}

					return VIDEO_PATH . 'connected.ts';

				case 'expired_video_path':
					if (!file_exists(VIDEO_PATH . 'expired.ts')) {
						break;
					}

					return VIDEO_PATH . 'expired.ts';

				case 'banned_video_path':
					if (!file_exists(VIDEO_PATH . 'banned.ts')) {
						break;
					}

					return VIDEO_PATH . 'banned.ts';

				case 'not_on_air_video_path':
					if (!file_exists(VIDEO_PATH . 'offline.ts')) {
						break;
					}

					return VIDEO_PATH . 'offline.ts';

				case 'expiring_video_path':
					if (!file_exists(VIDEO_PATH . 'expiring.ts')) {
						break;
					}

					return VIDEO_PATH . 'expiring.ts';
			}
		} else {
			return self::$rSettings[$Fd50c63671da34f8];
		}
	}

	public static function Ad5765C0FD1ABb43($Fca476d6a870416e, $Fd50c63671da34f8, $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $Fbe730b7a1211b54, $d58b4f8653a391d8 = null, $b2a9243e8304033d = null)
	{
		$Fd50c63671da34f8 = self::B97D7AcBCF7C7A5e($Fd50c63671da34f8);

		if (!(!$D4253f9520627819['is_restreamer'] && self::$rSettings[$Fca476d6a870416e] && 0 < strlen($Fd50c63671da34f8))) {
			switch ($Fca476d6a870416e) {
				case 'show_expired_video':
					generateError('EXPIRED');

					break;

				case 'show_banned_video':
					generateError('BANNED');

					break;

				case 'show_not_on_air_video':
					generateError('STREAM_OFFLINE');

					break;

				default:
					Db709Ed65AE02245();

					break;
			}
		} else {
			if ($d58b4f8653a391d8) {
			} else {
				$d58b4f8653a391d8 = self::F4221e28760b623E($D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $Fbe730b7a1211b54);
			}

			if ($d58b4f8653a391d8) {
			} else {
				$d58b4f8653a391d8 = SERVER_ID;
			}

			$a70eaa0ab42179dd = null;

			if (!(self::isProxied($d58b4f8653a391d8) && (!$D4253f9520627819['is_restreamer'] || !self::$rSettings['restreamer_bypass_proxy']))) {
			} else {
				$c08f7f5177a44d91 = self::getProxies($d58b4f8653a391d8);
				$b2a9243e8304033d = self::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

				if ($b2a9243e8304033d) {
				} else {
					dB709Ed65ae02245();
				}

				$a70eaa0ab42179dd = $d58b4f8653a391d8;
				$d58b4f8653a391d8 = $b2a9243e8304033d;
			}

			if (self::$rServers[$d58b4f8653a391d8]['random_ip'] && 0 < count(self::$rServers[$d58b4f8653a391d8]['domains']['urls'])) {
				$C700a2b357e5ed65 = self::$rServers[$d58b4f8653a391d8]['domains']['protocol'] . '://' . self::$rServers[$d58b4f8653a391d8]['domains']['urls'][array_rand(self::$rServers[$d58b4f8653a391d8]['domains']['urls'])] . ':' . self::$rServers[$d58b4f8653a391d8]['domains']['port'];
			} else {
				$C700a2b357e5ed65 = rtrim(self::$rServers[$d58b4f8653a391d8]['site_url'], '/');
			}

			if (!$a70eaa0ab42179dd || self::$rServers[$a70eaa0ab42179dd]['is_main']) {
			} else {
				$C700a2b357e5ed65 .= '/' . md5($d58b4f8653a391d8 . '_' . $a70eaa0ab42179dd . '_' . OPENSSL_EXTRA);
			}

			$F64d974c429d80be = array('expires' => time() + 10, 'video_path' => $Fd50c63671da34f8);
			$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

			if ($F9452a7efafa1aba == 'm3u8') {
				$dc05e2bb97d4635d = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-ALLOW-CACHE:YES\n#EXT-X-TARGETDURATION:10\n#EXTINF:10.0,\n" . $C700a2b357e5ed65 . '/auth/' . $ea5296071288c730 . "\n#EXT-X-ENDLIST";
				header('Content-Type: application/x-mpegurl');
				header('Content-Length: ' . strlen($dc05e2bb97d4635d));
				echo $dc05e2bb97d4635d;

				exit();
			}

			header('Location: ' . $C700a2b357e5ed65 . '/auth/' . $ea5296071288c730);

			exit();
		}
	}

	public static function F4221e28760B623E($D4253f9520627819, $c2a965773885730d, $efc0f8f3059e4104, $f72bad5bd13565f1 = '')
	{
		$c43b488500f8fab7 = array();

		foreach (self::$rServers as $d58b4f8653a391d8 => $cc5f26dd881329b7) {
			if ($cc5f26dd881329b7['server_online'] && $cc5f26dd881329b7['server_type'] == 0) {
				$c43b488500f8fab7[] = $d58b4f8653a391d8;
			}
		}

		if (!empty($c43b488500f8fab7)) {
			shuffle($c43b488500f8fab7);
			$a9d38d288d6824ad = self::CDd1bc14D819be74();
			$e1d30a1d66778eaf = array();

			foreach ($c43b488500f8fab7 as $d58b4f8653a391d8) {
				$c9a044772607fb06 = (isset($a9d38d288d6824ad[$d58b4f8653a391d8]['online_clients']) ? $a9d38d288d6824ad[$d58b4f8653a391d8]['online_clients'] : 0);

				if ($c9a044772607fb06 != 0) {
				} else {
					$a9d38d288d6824ad[$d58b4f8653a391d8]['capacity'] = 0;
				}

				$e1d30a1d66778eaf[$d58b4f8653a391d8] = (0 < self::$rServers[$d58b4f8653a391d8]['total_clients'] && $c9a044772607fb06 < self::$rServers[$d58b4f8653a391d8]['total_clients'] ? $a9d38d288d6824ad[$d58b4f8653a391d8]['capacity'] : false);
			}
			$e1d30a1d66778eaf = array_filter($e1d30a1d66778eaf, 'is_numeric');

			if (empty($e1d30a1d66778eaf)) {
				return false;
			}

			$f16991461acd03bf = array_keys($e1d30a1d66778eaf);
			$E287c1867f711629 = array_values($e1d30a1d66778eaf);
			array_multisort($E287c1867f711629, SORT_ASC, $f16991461acd03bf, SORT_ASC);
			$e1d30a1d66778eaf = array_combine($f16991461acd03bf, $E287c1867f711629);

			if ($D4253f9520627819['force_server_id'] != 0 && array_key_exists($D4253f9520627819['force_server_id'], $e1d30a1d66778eaf)) {
				$B5f1fb70f197b910 = $D4253f9520627819['force_server_id'];
			} else {
				$ceb41d1730714460 = array();

				foreach (array_keys($e1d30a1d66778eaf) as $d58b4f8653a391d8) {
					if (self::$rServers[$d58b4f8653a391d8]['enable_geoip'] == 1) {
						if (in_array($efc0f8f3059e4104, self::$rServers[$d58b4f8653a391d8]['geoip_countries'])) {
							$B5f1fb70f197b910 = $d58b4f8653a391d8;

							break;
						}

						if (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'strict') {
							unset($e1d30a1d66778eaf[$d58b4f8653a391d8]);
						} else {
							$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'low_priority' ? 1 : 2);
						}
					} else {
						if (self::$rServers[$d58b4f8653a391d8]['enable_isp'] == 1) {
							if (in_array($f72bad5bd13565f1, self::$rServers[$d58b4f8653a391d8]['isp_names'])) {
								$B5f1fb70f197b910 = $d58b4f8653a391d8;

								break;
							}

							if (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'strict') {
								unset($e1d30a1d66778eaf[$d58b4f8653a391d8]);
							} else {
								$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'low_priority' ? 1 : 2);
							}
						} else {
							$ceb41d1730714460[$d58b4f8653a391d8] = 1;
						}
					}
				}

				if (!(empty($ceb41d1730714460) && empty($B5f1fb70f197b910))) {
					$B5f1fb70f197b910 = (empty($B5f1fb70f197b910) ? array_search(min($ceb41d1730714460), $ceb41d1730714460) : $B5f1fb70f197b910);
				} else {
					return false;
				}
			}

			return $B5f1fb70f197b910;
		} else {
			return false;
		}
	}

	public static function availableProxy($c08f7f5177a44d91, $efc0f8f3059e4104, $f72bad5bd13565f1 = '')
	{
		if (!empty($c08f7f5177a44d91)) {
			$a9d38d288d6824ad = self::cDd1bC14D819bE74(true);
			$e1d30a1d66778eaf = array();

			foreach ($c08f7f5177a44d91 as $d58b4f8653a391d8) {
				$c9a044772607fb06 = (isset($a9d38d288d6824ad[$d58b4f8653a391d8]['online_clients']) ? $a9d38d288d6824ad[$d58b4f8653a391d8]['online_clients'] : 0);

				if ($c9a044772607fb06 != 0) {
				} else {
					$a9d38d288d6824ad[$d58b4f8653a391d8]['capacity'] = 0;
				}

				$e1d30a1d66778eaf[$d58b4f8653a391d8] = (0 < self::$rServers[$d58b4f8653a391d8]['total_clients'] && $c9a044772607fb06 < self::$rServers[$d58b4f8653a391d8]['total_clients'] ? $a9d38d288d6824ad[$d58b4f8653a391d8]['capacity'] : false);
			}
			$e1d30a1d66778eaf = array_filter($e1d30a1d66778eaf, 'is_numeric');

			if (empty($e1d30a1d66778eaf)) {
				return null;
			}

			$f16991461acd03bf = array_keys($e1d30a1d66778eaf);
			$E287c1867f711629 = array_values($e1d30a1d66778eaf);
			array_multisort($E287c1867f711629, SORT_ASC, $f16991461acd03bf, SORT_ASC);
			$e1d30a1d66778eaf = array_combine($f16991461acd03bf, $E287c1867f711629);
			$ceb41d1730714460 = array();

			foreach (array_keys($e1d30a1d66778eaf) as $d58b4f8653a391d8) {
				if (self::$rServers[$d58b4f8653a391d8]['enable_geoip'] == 1) {
					if (in_array($efc0f8f3059e4104, self::$rServers[$d58b4f8653a391d8]['geoip_countries'])) {
						$B5f1fb70f197b910 = $d58b4f8653a391d8;

						break;
					}

					if (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'strict') {
						unset($e1d30a1d66778eaf[$d58b4f8653a391d8]);
					} else {
						$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['geoip_type'] == 'low_priority' ? 1 : 2);
					}
				} else {
					if (self::$rServers[$d58b4f8653a391d8]['enable_isp'] == 1) {
						if (in_array($f72bad5bd13565f1, self::$rServers[$d58b4f8653a391d8]['isp_names'])) {
							$B5f1fb70f197b910 = $d58b4f8653a391d8;

							break;
						}

						if (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'strict') {
							unset($e1d30a1d66778eaf[$d58b4f8653a391d8]);
						} else {
							$ceb41d1730714460[$d58b4f8653a391d8] = (self::$rServers[$d58b4f8653a391d8]['isp_type'] == 'low_priority' ? 1 : 2);
						}
					} else {
						$ceb41d1730714460[$d58b4f8653a391d8] = 1;
					}
				}
			}

			if (!(empty($ceb41d1730714460) && empty($B5f1fb70f197b910))) {
				$B5f1fb70f197b910 = (empty($B5f1fb70f197b910) ? array_search(min($ceb41d1730714460), $ceb41d1730714460) : $B5f1fb70f197b910);

				return $B5f1fb70f197b910;
			}

			return null;
		} else {
			return null;
		}
	}

	public static function D2985c63279Ea4cD($D78ff1d0edade5eb, $B68ac2238b156add, $B08e7d3cd339391a = null, $E18c40e895ee55c2 = '', $c59ec257c284c894 = null, $b3374866087774a1 = null)
	{
		if (self::$rSettings['redis_handler']) {
			$A90d77181715e38e = array();
			$f16991461acd03bf = self::Bc23764Ed0732f3f($D78ff1d0edade5eb, true, true);
			$de110edaf0f89eae = count($f16991461acd03bf) - $B68ac2238b156add;

			if ($de110edaf0f89eae > 0) {
				foreach (array_map('igbinary_unserialize', self::$redis->mGet($f16991461acd03bf)) as $e110a2ab6d3a4734) {
					if (!is_array($e110a2ab6d3a4734)) {
					} else {
						$A90d77181715e38e[] = $e110a2ab6d3a4734;
					}
				}
				unset($f16991461acd03bf);
				$c94b497359f8aed9 = array_column($A90d77181715e38e, 'date_start');
				array_multisort($c94b497359f8aed9, SORT_ASC, $A90d77181715e38e);
			} else {
				return null;
			}
		} else {
			if ($B08e7d3cd339391a) {
				self::$db->query('SELECT `lines_live`.*, `on_demand` FROM `lines_live` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `lines_live`.`stream_id` AND `streams_servers`.`server_id` = `lines_live`.`server_id` WHERE `lines_live`.`hmac_id` = ? AND `lines_live`.`hls_end` = 0 AND `lines_live`.`hmac_identifier` = ? ORDER BY `lines_live`.`activity_id` ASC', $B08e7d3cd339391a, $E18c40e895ee55c2);
			} else {
				self::$db->query('SELECT `lines_live`.*, `on_demand` FROM `lines_live` LEFT JOIN `streams_servers` ON `streams_servers`.`stream_id` = `lines_live`.`stream_id` AND `streams_servers`.`server_id` = `lines_live`.`server_id` WHERE `lines_live`.`user_id` = ? AND `lines_live`.`hls_end` = 0 ORDER BY `lines_live`.`activity_id` ASC', $D78ff1d0edade5eb);
			}

			$bde5957fb5fa9547 = self::$db->num_rows();
			$de110edaf0f89eae = $bde5957fb5fa9547 - $B68ac2238b156add;

			if ($de110edaf0f89eae > 0) {
				$A90d77181715e38e = self::$db->get_rows();
			} else {
				return null;
			}
		}

		$c59ec257c284c894 = self::a9bC416FA6FA55C3();
		$e3d2d1505b87d99c = 0;
		$D4526c7bd7f852cc = $aeefef3bed8a0a90 = $Aa8c918a2a91966f = array();

		if ($c59ec257c284c894 && $b3374866087774a1) {
			$d90ef785aae39e04 = array(2, 1, 0);
		} else {
			if ($c59ec257c284c894) {
				$d90ef785aae39e04 = array(1, 0);
			} else {
				$d90ef785aae39e04 = array(0);
			}
		}

		foreach ($d90ef785aae39e04 as $af379d1083bf17b4) {
			$Ea22c4a9ab5b2176 = 0;

			while ($Ea22c4a9ab5b2176 < count($A90d77181715e38e) && $e3d2d1505b87d99c < $de110edaf0f89eae) {
				if ($e3d2d1505b87d99c != $de110edaf0f89eae) {
					if ($A90d77181715e38e[$Ea22c4a9ab5b2176]['pid'] != getmypid()) {
						if (!($A90d77181715e38e[$Ea22c4a9ab5b2176]['user_ip'] == $c59ec257c284c894 && $A90d77181715e38e[$Ea22c4a9ab5b2176]['user_agent'] == $b3374866087774a1 && $af379d1083bf17b4 == 2 || $A90d77181715e38e[$Ea22c4a9ab5b2176]['user_ip'] == $c59ec257c284c894 && $af379d1083bf17b4 == 1 || $af379d1083bf17b4 == 0)) {
						} else {
							if (!self::e8E9D6b2B107d8AE($A90d77181715e38e[$Ea22c4a9ab5b2176])) {
							} else {
								$e3d2d1505b87d99c++;

								if ($A90d77181715e38e[$Ea22c4a9ab5b2176]['container'] == 'hls') {
								} else {
									if (self::$rSettings['redis_handler']) {
										$Aa8c918a2a91966f[] = $A90d77181715e38e[$Ea22c4a9ab5b2176];
									} else {
										$Aa8c918a2a91966f[] = intval($A90d77181715e38e[$Ea22c4a9ab5b2176]['activity_id']);
									}

									$aeefef3bed8a0a90[] = $A90d77181715e38e[$Ea22c4a9ab5b2176]['uuid'];
									$D4526c7bd7f852cc[$A90d77181715e38e[$Ea22c4a9ab5b2176]['stream_id']][] = $aeefef3bed8a0a90;
								}

								if (!($A90d77181715e38e[$Ea22c4a9ab5b2176]['on_demand'] && $A90d77181715e38e[$Ea22c4a9ab5b2176]['server_id'] == SERVER_ID && self::$rSettings['on_demand_instant_off'])) {
								} else {
									self::CA490CE3385c630E($A90d77181715e38e[$Ea22c4a9ab5b2176]['stream_id'], $A90d77181715e38e[$Ea22c4a9ab5b2176]['pid']);
								}
							}
						}
					}

					$Ea22c4a9ab5b2176++;
				} else {
					break;
				}
			}
		}

		if (empty($Aa8c918a2a91966f)) {
		} else {
			if (self::$rSettings['redis_handler']) {
				$F805649379c06d30 = array();
				$F42a951cf0a3370a = self::$redis->multi();

				foreach ($Aa8c918a2a91966f as $e110a2ab6d3a4734) {
					$F42a951cf0a3370a->zRem('LINE#' . $e110a2ab6d3a4734['identity'], $e110a2ab6d3a4734['uuid']);
					$F42a951cf0a3370a->zRem('LINE_ALL#' . $e110a2ab6d3a4734['identity'], $e110a2ab6d3a4734['uuid']);
					$F42a951cf0a3370a->zRem('STREAM#' . $e110a2ab6d3a4734['stream_id'], $e110a2ab6d3a4734['uuid']);
					$F42a951cf0a3370a->zRem('SERVER#' . $e110a2ab6d3a4734['server_id'], $e110a2ab6d3a4734['uuid']);

					if (!$e110a2ab6d3a4734['user_id']) {
					} else {
						$F42a951cf0a3370a->zRem('SERVER_LINES#' . $e110a2ab6d3a4734['server_id'], $e110a2ab6d3a4734['uuid']);
					}

					if (!$e110a2ab6d3a4734['proxy_id']) {
					} else {
						$F42a951cf0a3370a->zRem('PROXY#' . $e110a2ab6d3a4734['proxy_id'], $e110a2ab6d3a4734['uuid']);
					}

					$F42a951cf0a3370a->del($e110a2ab6d3a4734['uuid']);
					$F805649379c06d30[] = $e110a2ab6d3a4734['uuid'];
				}
				$F42a951cf0a3370a->zRem('CONNECTIONS', ...$F805649379c06d30);
				$F42a951cf0a3370a->zRem('LIVE', ...$F805649379c06d30);
				$F42a951cf0a3370a->sRem('ENDED', ...$F805649379c06d30);
				$F42a951cf0a3370a->exec();
			} else {
				self::$db->query('DELETE FROM `lines_live` WHERE `activity_id` IN (' . implode(',', array_map('intval', $Aa8c918a2a91966f)) . ')');
			}

			foreach ($aeefef3bed8a0a90 as $B08b62d9f7870287) {
				@unlink(CONS_TMP_PATH . $B08b62d9f7870287);
			}

			foreach ($D4526c7bd7f852cc as $F26087d31c2bbe4d => $F805649379c06d30) {
				foreach ($F805649379c06d30 as $B08b62d9f7870287) {
					@unlink(CONS_TMP_PATH . $F26087d31c2bbe4d . '/' . $B08b62d9f7870287);
				}
			}
		}

		return $e3d2d1505b87d99c;
	}

	public static function E8e9D6B2b107D8AE($A9d34c0517e4c2a9)
	{
		if (!empty($A9d34c0517e4c2a9)) {
			if (is_array($A9d34c0517e4c2a9)) {
			} else {
				if (!self::$rSettings['redis_handler']) {
					if (strlen(strval($A9d34c0517e4c2a9)) == 32) {
						self::$db->query('SELECT * FROM `lines_live` WHERE `uuid` = ?', $A9d34c0517e4c2a9);
					} else {
						self::$db->query('SELECT * FROM `lines_live` WHERE `activity_id` = ?', $A9d34c0517e4c2a9);
					}

					$A9d34c0517e4c2a9 = self::$db->get_row();
				} else {
					$A9d34c0517e4c2a9 = igbinary_unserialize(self::$redis->get($A9d34c0517e4c2a9));
				}
			}

			if (is_array($A9d34c0517e4c2a9)) {
				if ($A9d34c0517e4c2a9['container'] == 'rtmp') {
					if ($A9d34c0517e4c2a9['server_id'] == SERVER_ID) {
						shell_exec('wget --timeout=2 -O /dev/null -o /dev/null "' . self::$rServers[SERVER_ID]['rtmp_mport_url'] . 'control/drop/client?clientid=' . intval($A9d34c0517e4c2a9['pid']) . '" >/dev/null 2>/dev/null &');
					} else {
						if (self::$rSettings['redis_handler']) {
							self::aA941Cf79c4F48CF($A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id'], 1);
						} else {
							self::$db->query('INSERT INTO `signals` (`pid`,`server_id`,`rtmp`,`time`) VALUES(?,?,?,UNIX_TIMESTAMP())', $A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id'], 1);
						}
					}
				} else {
					if ($A9d34c0517e4c2a9['container'] == 'hls') {
						if (self::$rSettings['redis_handler']) {
							self::e3484f74d3C8b5a7($A9d34c0517e4c2a9, array(), 'close');
						} else {
							self::$db->query('UPDATE `lines_live` SET `hls_end` = 1 WHERE `activity_id` = ?', $A9d34c0517e4c2a9['activity_id']);
						}
					} else {
						if ($A9d34c0517e4c2a9['server_id'] == SERVER_ID) {
							if (!($A9d34c0517e4c2a9['pid'] != getmypid() && is_numeric($A9d34c0517e4c2a9['pid']) && 0 < $A9d34c0517e4c2a9['pid'])) {
							} else {
								posix_kill(intval($A9d34c0517e4c2a9['pid']), 9);
							}
						} else {
							if (self::$rSettings['redis_handler']) {
								self::Aa941Cf79C4F48cf($A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id'], 0);
							} else {
								self::$db->query('INSERT INTO `signals` (`pid`,`server_id`,`time`) VALUES(?,?,UNIX_TIMESTAMP())', $A9d34c0517e4c2a9['pid'], $A9d34c0517e4c2a9['server_id']);
							}
						}
					}
				}

				self::DCFCfa5D9D05DF5a($A9d34c0517e4c2a9['server_id'], $A9d34c0517e4c2a9['proxy_id'], $A9d34c0517e4c2a9['user_id'], $A9d34c0517e4c2a9['stream_id'], $A9d34c0517e4c2a9['date_start'], $A9d34c0517e4c2a9['user_agent'], $A9d34c0517e4c2a9['user_ip'], $A9d34c0517e4c2a9['container'], $A9d34c0517e4c2a9['geoip_country_code'], $A9d34c0517e4c2a9['isp'], $A9d34c0517e4c2a9['external_device'], $A9d34c0517e4c2a9['divergence'], $A9d34c0517e4c2a9['hmac_id'], $A9d34c0517e4c2a9['hmac_identifier']);

				return true;
			}

			return false;
		}

		return false;
	}

	public static function F01D5Fe0Aec79d52($f9b07d216a168dcc)
	{
		if (!empty($f9b07d216a168dcc)) {
			self::$db->query("SELECT * FROM `lines_live` WHERE `container` = 'rtmp' AND `pid` = ? AND `server_id` = ?", $f9b07d216a168dcc, SERVER_ID);

			if (0 >= self::$db->num_rows()) {
				return false;
			}

			$A9d34c0517e4c2a9 = self::$db->get_row();
			self::$db->query('DELETE FROM `lines_live` WHERE `activity_id` = ?', $A9d34c0517e4c2a9['activity_id']);
			self::dcFCFA5d9D05Df5a($A9d34c0517e4c2a9['server_id'], $A9d34c0517e4c2a9['proxy_id'], $A9d34c0517e4c2a9['user_id'], $A9d34c0517e4c2a9['stream_id'], $A9d34c0517e4c2a9['date_start'], $A9d34c0517e4c2a9['user_agent'], $A9d34c0517e4c2a9['user_ip'], $A9d34c0517e4c2a9['container'], $A9d34c0517e4c2a9['geoip_country_code'], $A9d34c0517e4c2a9['isp'], $A9d34c0517e4c2a9['external_device'], $A9d34c0517e4c2a9['divergence'], $A9d34c0517e4c2a9['hmac_id'], $A9d34c0517e4c2a9['hmac_identifier']);

			return true;
		}

		return false;
	}

	public static function DCfCFA5d9d05DF5a($d58b4f8653a391d8, $b2a9243e8304033d, $D78ff1d0edade5eb, $F26087d31c2bbe4d, $D031c48a1422c07e, $b3374866087774a1, $c59ec257c284c894, $F9452a7efafa1aba, $C4a76d9a69ca8231, $Fbe730b7a1211b54, $d080620e03289080 = '', $b25be5f9af7a0a91 = 0, $B08e7d3cd339391a = null, $E18c40e895ee55c2 = '')
	{
		if (self::$rSettings['save_closed_connection'] != 0) {
			if (!($d58b4f8653a391d8 && $D78ff1d0edade5eb && $F26087d31c2bbe4d)) {
			} else {
				$A9d34c0517e4c2a9 = array('user_id' => intval($D78ff1d0edade5eb), 'stream_id' => intval($F26087d31c2bbe4d), 'server_id' => intval($d58b4f8653a391d8), 'proxy_id' => intval($b2a9243e8304033d), 'date_start' => intval($D031c48a1422c07e), 'user_agent' => $b3374866087774a1, 'user_ip' => htmlentities($c59ec257c284c894), 'date_end' => time(), 'container' => $F9452a7efafa1aba, 'geoip_country_code' => $C4a76d9a69ca8231, 'isp' => $Fbe730b7a1211b54, 'external_device' => htmlentities($d080620e03289080), 'divergence' => intval($b25be5f9af7a0a91), 'hmac_id' => $B08e7d3cd339391a, 'hmac_identifier' => $E18c40e895ee55c2);
				file_put_contents(LOGS_TMP_PATH . 'activity', base64_encode(json_encode($A9d34c0517e4c2a9)) . "\n", FILE_APPEND | LOCK_EX);
			}
		} else {
			return null;
		}
	}

	public static function D7aC04307F564FA4()
	{
		$a85e1b7d42c346a0 = array();
		self::$db->query('SELECT `ip`, `password`, `push`, `pull` FROM `rtmp_ips`');

		foreach (self::$db->get_rows() as $C740da31596f24ef) {
			$a85e1b7d42c346a0[gethostbyname($C740da31596f24ef['ip'])] = array('password' => $C740da31596f24ef['password'], 'push' => boolval($C740da31596f24ef['push']), 'pull' => boolval($C740da31596f24ef['pull']));
		}

		return $a85e1b7d42c346a0;
	}

	public static function aEbd9e41165629f6($F26087d31c2bbe4d, $Aa8c918a2a91966f = array(), $E379394c7b1a273f = 'movie')
	{
		if ($E379394c7b1a273f == 'movie') {
			return in_array($F26087d31c2bbe4d, $Aa8c918a2a91966f);
		}

		if ($E379394c7b1a273f != 'series') {
		} else {
			if (self::$rCached) {
				$bbc84f53c534450d = igbinary_unserialize(file_get_contents(SERIES_TMP_PATH . 'series_map'));

				return in_array($bbc84f53c534450d[$F26087d31c2bbe4d], $Aa8c918a2a91966f);
			}

			self::$db->query('SELECT series_id FROM `streams_episodes` WHERE `stream_id` = ? LIMIT 1', $F26087d31c2bbe4d);

			if (0 >= self::$db->num_rows()) {
			} else {
				return in_array(self::$db->get_col(), $Aa8c918a2a91966f);
			}
		}

		return false;
	}

	public static function D7Ca435Ac70e9a78($D78ff1d0edade5eb = null, $a71afc14d6cd090d = null, $d5249dad8e8411b7 = null, $f741fb10659d3472 = false, $E7654bf2f4eff2fe = false, $c59ec257c284c894 = '')
	{
		$D4253f9520627819 = null;

		if (self::$rCached) {
			if (empty($d5249dad8e8411b7) && empty($D78ff1d0edade5eb) && strlen($a71afc14d6cd090d) == 32) {
				if (self::$rSettings['case_sensitive_line']) {
					$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_t_' . $a71afc14d6cd090d));
				} else {
					$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_t_' . strtolower($a71afc14d6cd090d)));
				}
			} else {
				if (!empty($a71afc14d6cd090d) && !empty($d5249dad8e8411b7)) {
					if (self::$rSettings['case_sensitive_line']) {
						$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_c_' . $a71afc14d6cd090d . '_' . $d5249dad8e8411b7));
					} else {
						$D78ff1d0edade5eb = intval(file_get_contents(LINES_TMP_PATH . 'line_c_' . strtolower($a71afc14d6cd090d) . '_' . strtolower($d5249dad8e8411b7)));
					}
				} else {
					if (!empty($D78ff1d0edade5eb)) {
					} else {
						return false;
					}
				}
			}

			if (!$D78ff1d0edade5eb) {
			} else {
				$D4253f9520627819 = igbinary_unserialize(file_get_contents(LINES_TMP_PATH . 'line_i_' . $D78ff1d0edade5eb));
			}
		} else {
			if (empty($d5249dad8e8411b7) && empty($D78ff1d0edade5eb) && strlen($a71afc14d6cd090d) == 32) {
				self::$db->query('SELECT * FROM `lines` WHERE `is_mag` = 0 AND `is_e2` = 0 AND `access_token` = ? AND LENGTH(`access_token`) = 32', $a71afc14d6cd090d);
			} else {
				if (!empty($a71afc14d6cd090d) && !empty($d5249dad8e8411b7)) {
					self::$db->query('SELECT `lines`.*, `mag_devices`.`token` AS `mag_token` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` WHERE `username` = ? AND `password` = ? LIMIT 1', $a71afc14d6cd090d, $d5249dad8e8411b7);
				} else {
					if (!empty($D78ff1d0edade5eb)) {
						self::$db->query('SELECT `lines`.*, `mag_devices`.`token` AS `mag_token` FROM `lines` LEFT JOIN `mag_devices` ON `mag_devices`.`user_id` = `lines`.`id` WHERE `id` = ?', $D78ff1d0edade5eb);
					} else {
						return false;
					}
				}
			}

			if (0 >= self::$db->num_rows()) {
			} else {
				$D4253f9520627819 = self::$db->get_row();
			}
		}

		if (!$D4253f9520627819) {
			return false;
		}

		if (!self::$rCached) {
		} else {
			if (empty($d5249dad8e8411b7) && empty($D78ff1d0edade5eb) && strlen($a71afc14d6cd090d) == 32) {
				if ($a71afc14d6cd090d == $D4253f9520627819['access_token']) {
				} else {
					return false;
				}
			} else {
				if (empty($a71afc14d6cd090d) || empty($d5249dad8e8411b7)) {
				} else {
					if (!($a71afc14d6cd090d != $D4253f9520627819['username'] || $d5249dad8e8411b7 != $D4253f9520627819['password'])) {
					} else {
						return false;
					}
				}
			}
		}

		if (!(self::$rSettings['county_override_1st'] == 1 && empty($D4253f9520627819['forced_country']) && !empty($c59ec257c284c894) && $D4253f9520627819['max_connections'] == 1)) {
		} else {
			$D4253f9520627819['forced_country'] = self::b74F652C92cEc688($c59ec257c284c894)['registered_country']['iso_code'];

			if (self::$rCached) {
				self::Cf592c234dcd0b19('forced_country/' . $D4253f9520627819['id'], $D4253f9520627819['forced_country']);
			} else {
				self::$db->query('UPDATE `lines` SET `forced_country` = ? WHERE `id` = ?', $D4253f9520627819['forced_country'], $D4253f9520627819['id']);
			}
		}

		$D4253f9520627819['bouquet'] = json_decode($D4253f9520627819['bouquet'], true);
		$D4253f9520627819['allowed_ips'] = @array_filter(@array_map('trim', @json_decode($D4253f9520627819['allowed_ips'], true)));
		$D4253f9520627819['allowed_ua'] = @array_filter(@array_map('trim', @json_decode($D4253f9520627819['allowed_ua'], true)));
		$D4253f9520627819['allowed_outputs'] = array_map('intval', json_decode($D4253f9520627819['allowed_outputs'], true));
		$D4253f9520627819['output_formats'] = array();

		if (self::$rCached) {
			foreach (igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'output_formats')) as $C740da31596f24ef) {
				if (!in_array(intval($C740da31596f24ef['access_output_id']), $D4253f9520627819['allowed_outputs'])) {
				} else {
					$D4253f9520627819['output_formats'][] = $C740da31596f24ef['output_key'];
				}
			}
		} else {
			self::$db->query('SELECT `access_output_id`, `output_key` FROM `output_formats`;');

			foreach (self::$db->get_rows() as $C740da31596f24ef) {
				if (!in_array(intval($C740da31596f24ef['access_output_id']), $D4253f9520627819['allowed_outputs'])) {
				} else {
					$D4253f9520627819['output_formats'][] = $C740da31596f24ef['output_key'];
				}
			}
		}

		$D4253f9520627819['con_isp_name'] = null;
		$D4253f9520627819['isp_violate'] = 0;
		$D4253f9520627819['isp_is_server'] = 0;

		if (self::$rSettings['show_isps'] != 1 || empty($c59ec257c284c894)) {
		} else {
			$da7f3c43bffc92dd = self::ee2D851924a79E53($c59ec257c284c894);

			if (!is_array($da7f3c43bffc92dd)) {
			} else {
				if (empty($da7f3c43bffc92dd['isp'])) {
				} else {
					$D4253f9520627819['con_isp_name'] = $da7f3c43bffc92dd['isp'];
					$D4253f9520627819['isp_asn'] = $da7f3c43bffc92dd['autonomous_system_number'];
					$D4253f9520627819['isp_violate'] = self::e38AfbCF35978bE3($D4253f9520627819['con_isp_name']);

					if (self::$rSettings['block_svp'] != 1) {
					} else {
						$D4253f9520627819['isp_is_server'] = intval(self::Ace0eacBDE53512c($D4253f9520627819['isp_asn']));
					}
				}
			}

			if (!(!empty($D4253f9520627819['con_isp_name']) && self::$rSettings['enable_isp_lock'] == 1 && $D4253f9520627819['is_stalker'] == 0 && $D4253f9520627819['is_isplock'] == 1 && !empty($D4253f9520627819['isp_desc']) && strtolower($D4253f9520627819['con_isp_name']) != strtolower($D4253f9520627819['isp_desc']))) {
			} else {
				$D4253f9520627819['isp_violate'] = 1;
			}

			if (!($D4253f9520627819['isp_violate'] == 0 && strtolower($D4253f9520627819['con_isp_name']) != strtolower($D4253f9520627819['isp_desc']))) {
			} else {
				if (self::$rCached) {
					self::Cf592c234Dcd0b19('isp/' . $D4253f9520627819['id'], json_encode(array($D4253f9520627819['con_isp_name'], $D4253f9520627819['isp_asn'])));
				} else {
					self::$db->query('UPDATE `lines` SET `isp_desc` = ?, `as_number` = ? WHERE `id` = ?', $D4253f9520627819['con_isp_name'], $D4253f9520627819['isp_asn'], $D4253f9520627819['id']);
				}
			}
		}

		if (!$f741fb10659d3472) {
		} else {
			$e3f5a327db5b3930 = $c07a93bf577a961d = $d04121afcfd82dc3 = $A38b42a281e3c3cf = $B2fdaed180cd0049 = $b58b71142a808858 = array();

			foreach ($D4253f9520627819['bouquet'] as $C3c8913edb801c35) {
				if (!isset(self::$rBouquets[$C3c8913edb801c35]['streams'])) {
				} else {
					$B2fdaed180cd0049 = array_merge($B2fdaed180cd0049, self::$rBouquets[$C3c8913edb801c35]['streams']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['series'])) {
				} else {
					$b58b71142a808858 = array_merge($b58b71142a808858, self::$rBouquets[$C3c8913edb801c35]['series']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['channels'])) {
				} else {
					$e3f5a327db5b3930 = array_merge($e3f5a327db5b3930, self::$rBouquets[$C3c8913edb801c35]['channels']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['movies'])) {
				} else {
					$c07a93bf577a961d = array_merge($c07a93bf577a961d, self::$rBouquets[$C3c8913edb801c35]['movies']);
				}

				if (!isset(self::$rBouquets[$C3c8913edb801c35]['radios'])) {
				} else {
					$d04121afcfd82dc3 = array_merge($d04121afcfd82dc3, self::$rBouquets[$C3c8913edb801c35]['radios']);
				}
			}
			$D4253f9520627819['channel_ids'] = array_map('intval', array_unique($B2fdaed180cd0049));
			$D4253f9520627819['series_ids'] = array_map('intval', array_unique($b58b71142a808858));
			$D4253f9520627819['vod_ids'] = array_map('intval', array_unique($c07a93bf577a961d));
			$D4253f9520627819['live_ids'] = array_map('intval', array_unique($e3f5a327db5b3930));
			$D4253f9520627819['radio_ids'] = array_map('intval', array_unique($d04121afcfd82dc3));
		}

		$C150dcc8bd89c268 = array();
		$a0ab7ba3516bce7d = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'category_map'));

		foreach ($D4253f9520627819['bouquet'] as $C3c8913edb801c35) {
			$C150dcc8bd89c268 = array_merge($C150dcc8bd89c268, ($a0ab7ba3516bce7d[$C3c8913edb801c35] ?: array()));
		}
		$D4253f9520627819['category_ids'] = array_values(array_unique($C150dcc8bd89c268));

		return $D4253f9520627819;
	}

	public static function cF592C234DCd0B19($D3fa098be3f297cd, $a27e64cc6ce01033)
	{
		file_put_contents(SIGNALS_TMP_PATH . 'cache_' . md5($D3fa098be3f297cd), json_encode(array($D3fa098be3f297cd, $a27e64cc6ce01033)));
	}

	public static function a7bE375c7E1508D7($Dca433951d41a5c8, $F029d0a6c29fd5a2, $F26087d31c2bbe4d, $F9452a7efafa1aba, $c59ec257c284c894 = '', $D46306ed3d96e171 = '', $E18c40e895ee55c2 = '', $B68ac2238b156add = 0)
	{
		if (!(0 < strlen($c59ec257c284c894) && 0 < strlen($D46306ed3d96e171))) {
		} else {
			if ($c59ec257c284c894 == $D46306ed3d96e171) {
			} else {
				return null;
			}
		}

		$D5e1c8f29b0bfb9c = null;

		if (self::$rCached) {
			$f16991461acd03bf = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'hmac_keys'));
		} else {
			$f16991461acd03bf = array();
			self::$db->query('SELECT `id`, `key` FROM `hmac_keys` WHERE `enabled` = 1;');

			foreach (self::$db->get_rows() as $D3fa098be3f297cd) {
				$f16991461acd03bf[] = $D3fa098be3f297cd;
			}
		}

		foreach ($f16991461acd03bf as $D3fa098be3f297cd) {
			$B59c127fecf35c15 = hash_hmac('sha256', (string) $F26087d31c2bbe4d . '##' . $F9452a7efafa1aba . '##' . $F029d0a6c29fd5a2 . '##' . $D46306ed3d96e171 . '##' . $E18c40e895ee55c2 . '##' . $B68ac2238b156add, Xui\Functions::decrypt($D3fa098be3f297cd['key'], OPENSSL_EXTRA));

			if (md5($B59c127fecf35c15) != md5($Dca433951d41a5c8)) {
			} else {
				$D5e1c8f29b0bfb9c = $D3fa098be3f297cd['id'];

				break;
			}
		}

		return $D5e1c8f29b0bfb9c;
	}

	public static function EA6c9a31F15A7B61($F26087d31c2bbe4d, $D78ff1d0edade5eb, $fa7da6c202358e0c, $c59ec257c284c894, $a27e64cc6ce01033 = '', $f158ea34ade8ece4 = false)
	{
		if (self::$rSettings['client_logs_save'] != 0 || $f158ea34ade8ece4) {
			$b3374866087774a1 = (!empty($_SERVER['HTTP_USER_AGENT']) ? htmlentities($_SERVER['HTTP_USER_AGENT']) : '');
			$a27e64cc6ce01033 = array('user_id' => $D78ff1d0edade5eb, 'stream_id' => $F26087d31c2bbe4d, 'action' => $fa7da6c202358e0c, 'query_string' => htmlentities($_SERVER['QUERY_STRING']), 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'time' => time(), 'extra_data' => $a27e64cc6ce01033);
			file_put_contents(LOGS_TMP_PATH . 'client_request.log', base64_encode(json_encode($a27e64cc6ce01033)) . "\n", FILE_APPEND);
		} else {
			return null;
		}
	}

	public static function e416910Ca4da4695($b3374866087774a1, $a85e1b7d42c346a0 = false)
	{
		$b3374866087774a1 = strtolower($b3374866087774a1);

		foreach (self::$rBlockedUA as $D3fa098be3f297cd => $cda44bf16c8f250e) {
			if ($cda44bf16c8f250e['exact_match'] == 1) {
				if ($cda44bf16c8f250e['blocked_ua'] != $b3374866087774a1) {
				} else {
					return true;
				}
			} else {
				if (!stristr($b3374866087774a1, $cda44bf16c8f250e['blocked_ua'])) {
				} else {
					return true;
				}
			}
		}

		return false;
	}

	public static function EA4a2063e98bAEF8($f9b07d216a168dcc, $F26087d31c2bbe4d, $acd3b41bac740313 = PHP_BIN)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($acd3b41bac740313)) === 0)) {
			} else {
				$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

				if (!($cf1c389bda3e30fd == 'XUI[' . $F26087d31c2bbe4d . ']' || $cf1c389bda3e30fd == 'XUIProxy[' . $F26087d31c2bbe4d . ']')) {
				} else {
					return true;
				}
			}

			return false;
		}

		return false;
	}

	public static function f74FA4748b081619($f9b07d216a168dcc, $F26087d31c2bbe4d)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe'))) {
			} else {
				if (strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), 'ffmpeg') === 0) {
					$cf1c389bda3e30fd = trim(file_get_contents('/proc/' . $f9b07d216a168dcc . '/cmdline'));

					if (!(stristr($cf1c389bda3e30fd, '/' . $F26087d31c2bbe4d . '_.m3u8') || stristr($cf1c389bda3e30fd, '/' . $F26087d31c2bbe4d . '_%d.ts'))) {
					} else {
						return true;
					}
				} else {
					if (strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), 'php') !== 0) {
					} else {
						return true;
					}
				}
			}

			return false;
		}

		return false;
	}

	public static function dD714ee89c59Fbf2($f9b07d216a168dcc, $acd3b41bac740313)
	{
		if (!empty($f9b07d216a168dcc)) {
			clearstatcache(true);

			if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($acd3b41bac740313)) === 0)) {
				return false;
			}

			return true;
		}

		return false;
	}

	public static function dAC4d82F05378662($F26087d31c2bbe4d, $d81f27c553f73ff4 = 0)
	{
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'monitor.php ' . intval($F26087d31c2bbe4d) . ' ' . intval($d81f27c553f73ff4) . ' >/dev/null 2>/dev/null &');

		return true;
	}

	public static function startProxy($F26087d31c2bbe4d)
	{
		shell_exec(PHP_BIN . ' ' . CLI_PATH . 'proxy.php ' . intval($F26087d31c2bbe4d) . ' >/dev/null 2>/dev/null &');

		return true;
	}

	public static function bc69aFfE50D85273($add193137cabeea7, $E8601dd191bcdbba, $A387578f69b4c724 = 'h264', $a85e1b7d42c346a0 = false)
	{
		if (empty($add193137cabeea7['xy_offset'])) {
			$b2db2d0561ace513 = rand(150, 380);
			$E2431f134bf1c17e = rand(110, 250);
		} else {
			list($b2db2d0561ace513, $E2431f134bf1c17e) = explode('x', $add193137cabeea7['xy_offset']);
		}

		if ($a85e1b7d42c346a0) {
			$f433193a3297ffde = SIGNALS_TMP_PATH . $add193137cabeea7['activity_id'] . '_' . $E8601dd191bcdbba;
			shell_exec(self::$rFFMPEG_CPU . ' -copyts -vsync 0 -nostats -nostdin -hide_banner -loglevel quiet -y -i ' . escapeshellarg(STREAMS_PATH . $E8601dd191bcdbba) . ' -filter_complex "drawtext=fontfile=' . FFMPEG_FONT . ":text='" . escapeshellcmd($add193137cabeea7['message']) . "':fontsize=" . escapeshellcmd($add193137cabeea7['font_size']) . ':x=' . intval($b2db2d0561ace513) . ':y=' . intval($E2431f134bf1c17e) . ':fontcolor=' . escapeshellcmd($add193137cabeea7['font_color']) . '" -map 0 -vcodec ' . $A387578f69b4c724 . ' -preset ultrafast -acodec copy -scodec copy -mpegts_flags +initial_discontinuity -mpegts_copyts 1 -f mpegts ' . escapeshellarg($f433193a3297ffde));
			$a27e64cc6ce01033 = file_get_contents($f433193a3297ffde);
			unlink($f433193a3297ffde);

			return $a27e64cc6ce01033;
		}

		passthru(self::$rFFMPEG_CPU . ' -copyts -vsync 0 -nostats -nostdin -hide_banner -loglevel quiet -y -i ' . escapeshellarg(STREAMS_PATH . $E8601dd191bcdbba) . ' -filter_complex "drawtext=fontfile=' . FFMPEG_FONT . ":text='" . escapeshellcmd($add193137cabeea7['message']) . "':fontsize=" . escapeshellcmd($add193137cabeea7['font_size']) . ':x=' . intval($b2db2d0561ace513) . ':y=' . intval($E2431f134bf1c17e) . ':fontcolor=' . escapeshellcmd($add193137cabeea7['font_color']) . '" -map 0 -vcodec ' . $A387578f69b4c724 . ' -preset ultrafast -acodec copy -scodec copy -mpegts_flags +initial_discontinuity -mpegts_copyts 1 -f mpegts -');

		return true;
	}

	public static function a9Bc416FA6FA55c3()
	{
		return $_SERVER['REMOTE_ADDR'];
	}

	public static function Ee2d851924A79E53($c59ec257c284c894)
	{
		if (!empty($c59ec257c284c894)) {
			$c7488e8420e934e2 = (file_exists(CONS_TMP_PATH . md5($c59ec257c284c894) . '_isp') ? json_decode(file_get_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_isp'), true) : null);

			if (is_array($c7488e8420e934e2)) {
			} else {
				$C4a76d9a69ca8231 = new MaxMind\Db\Reader(GEOISP_BIN);
				$c7488e8420e934e2 = $C4a76d9a69ca8231->get($c59ec257c284c894);
				$C4a76d9a69ca8231->close();

				if (!is_array($c7488e8420e934e2)) {
				} else {
					file_put_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_isp', json_encode($c7488e8420e934e2));
				}
			}

			return $c7488e8420e934e2;
		}

		return false;
	}

	public static function e38aFBCF35978be3($e11e06c11ab94fe2)
	{
		foreach (self::$rBlockedISP as $Fbe730b7a1211b54) {
			if (strtolower($e11e06c11ab94fe2) != strtolower($Fbe730b7a1211b54['isp'])) {
			} else {
				return intval($Fbe730b7a1211b54['blocked']);
			}
		}

		return 0;
	}

	public static function ACE0EAcbDE53512c($Fcd691b0388768ab)
	{
		return in_array($Fcd691b0388768ab, self::$rBlockedServers);
	}

	public static function b74F652c92Cec688($c59ec257c284c894)
	{
		if (!empty($c59ec257c284c894)) {
			if (!file_exists(CONS_TMP_PATH . md5($c59ec257c284c894) . '_geo2')) {
				$C4a76d9a69ca8231 = new MaxMind\Db\Reader(GEOLITE2_BIN);
				$c7488e8420e934e2 = $C4a76d9a69ca8231->get($c59ec257c284c894);
				$C4a76d9a69ca8231->close();

				if (!$c7488e8420e934e2) {
				} else {
					file_put_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_geo2', json_encode($c7488e8420e934e2));
				}

				return $c7488e8420e934e2;
			}

			return json_decode(file_get_contents(CONS_TMP_PATH . md5($c59ec257c284c894) . '_geo2'), true);
		}

		return false;
	}

	public static function b8f3DeF724810918($C700a2b357e5ed65, $e739adf85c8ac121 = null)
	{
		if (substr($C700a2b357e5ed65, 0, 2) == 's:') {
			$B211d7401e6242f3 = explode(':', $C700a2b357e5ed65, 3);
			$f4116b9928c8b494 = self::CA8708baE84a9148(intval($B211d7401e6242f3[1]), $e739adf85c8ac121);

			if ($f4116b9928c8b494) {
				return $f4116b9928c8b494 . 'images/' . basename($C700a2b357e5ed65);
			}

			return '';
		}

		return $C700a2b357e5ed65;
	}

	public static function cae8387edC1BF201()
	{
		$b9e33ce83162666c = 0;
		exec('ps -fp $(pgrep -u xui)', $f433193a3297ffde, $E072e4fd80a065b3);

		foreach ($f433193a3297ffde as $Df1e7eea7d843145) {
			$B211d7401e6242f3 = explode(' ', preg_replace('!\\s+!', ' ', trim($Df1e7eea7d843145)));

			if (!($B211d7401e6242f3[8] == 'nginx:' && $B211d7401e6242f3[9] == 'master')) {
			} else {
				$b9e33ce83162666c++;
			}
		}

		return 0 < $b9e33ce83162666c;
	}

	public static function ca8708BaE84a9148($d58b4f8653a391d8 = null, $e739adf85c8ac121 = null)
	{
		$a70eaa0ab42179dd = null;

		if (isset($d58b4f8653a391d8)) {
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		if ($e739adf85c8ac121) {
			$C6033ec178efa2ae = $e739adf85c8ac121;
		} else {
			if (isset($_SERVER['SERVER_PORT']) && self::$rSettings['keep_protocol']) {
				$C6033ec178efa2ae = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443 ? 'https' : 'http');
			} else {
				$C6033ec178efa2ae = self::$rServers[$d58b4f8653a391d8]['server_protocol'];
			}
		}

		if (!self::$rServers[$d58b4f8653a391d8]) {
		} else {
			if (!self::$rServers[$d58b4f8653a391d8]['enable_proxy']) {
			} else {
				$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8));

				if (count($Da9a40906d3d1c5f) != 0) {
				} else {
					$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8, false));
				}

				if (count($Da9a40906d3d1c5f) != 0) {
					$a70eaa0ab42179dd = $d58b4f8653a391d8;
					$d58b4f8653a391d8 = $Da9a40906d3d1c5f[array_rand($Da9a40906d3d1c5f)];
				} else {
					return '';
				}
			}

			$baba170ab02ca0bd = (defined('host') ? HOST : null);

			if ($baba170ab02ca0bd && in_array(strtolower($baba170ab02ca0bd), array_map('strtolower', self::$rServers[$d58b4f8653a391d8]['domains']['urls']))) {
				$Caecf2bcd39a1efe = $baba170ab02ca0bd;
			} else {
				$Caecf2bcd39a1efe = (empty(self::$rServers[$d58b4f8653a391d8]['domain_name']) ? self::$rServers[$d58b4f8653a391d8]['server_ip'] : explode(',', self::$rServers[$d58b4f8653a391d8]['domain_name'])[0]);
			}

			$f4116b9928c8b494 = $C6033ec178efa2ae . '://' . $Caecf2bcd39a1efe . ':' . self::$rServers[$d58b4f8653a391d8][$C6033ec178efa2ae . '_broadcast_port'] . '/';

			if (!(self::$rServers[$d58b4f8653a391d8]['server_type'] == 1 && $a70eaa0ab42179dd && self::$rServers[$a70eaa0ab42179dd]['is_main'] == 0)) {
			} else {
				$f4116b9928c8b494 .= md5($d58b4f8653a391d8 . '_' . $a70eaa0ab42179dd . '_' . OPENSSL_EXTRA) . '/';
			}

			return $f4116b9928c8b494;
		}
	}

	public static function c7BABcBEc16C28ED($E379394c7b1a273f = null)
	{
		$a85e1b7d42c346a0 = array();

		foreach (self::$rCategories as $A1925ae53e9307eb) {
			if ($A1925ae53e9307eb['category_type'] != $E379394c7b1a273f && $E379394c7b1a273f) {
			} else {
				$a85e1b7d42c346a0[] = $A1925ae53e9307eb;
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function a54586eadeA94ee6($Fcd691b0388768ab, $c59ec257c284c894)
	{
		if (!file_exists(CIDR_TMP_PATH . $Fcd691b0388768ab)) {
		} else {
			$D25e7c9f6776261b = json_decode(file_get_contents(CIDR_TMP_PATH . $Fcd691b0388768ab), true);

			foreach ($D25e7c9f6776261b as $Da967f0a787f6b51 => $a27e64cc6ce01033) {
				if (!(ip2long($a27e64cc6ce01033[1]) <= ip2long($c59ec257c284c894) && ip2long($c59ec257c284c894) <= ip2long($a27e64cc6ce01033[2]))) {
				} else {
					return $a27e64cc6ce01033;
				}
			}
		}
	}

	public static function getLLODSegments($F26087d31c2bbe4d, $bb62005ea7eb8380, $e1034511e63f0e9e = 1)
	{
		$e1034511e63f0e9e++;
		$Bffc17a99eb14fd6 = $ed560e114da67dbd = array();

		if (!file_exists($bb62005ea7eb8380)) {
		} else {
			$c8d91fcd2309e48a = file_get_contents($bb62005ea7eb8380);

			if (!preg_match_all('/(.*?).ts((#\\w+)+|#?)/', $c8d91fcd2309e48a, $b85ce31cd1118ad2)) {
			} else {
				if (0 >= count($b85ce31cd1118ad2[1])) {
				} else {
					$b3f6223bb51e59ed = null;

					for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($b85ce31cd1118ad2[1]); $Ea22c4a9ab5b2176++) {
						$bc2874292e0d9ece = $b85ce31cd1118ad2[1][$Ea22c4a9ab5b2176];
						list($e154835c9fa166f7, $B1c1aa7e8b5b4849) = explode('_', $bc2874292e0d9ece);

						if (empty($b85ce31cd1118ad2[2][$Ea22c4a9ab5b2176])) {
						} else {
							$ed560e114da67dbd[$B1c1aa7e8b5b4849] = array();
							$b3f6223bb51e59ed = $B1c1aa7e8b5b4849;
						}

						if (!$b3f6223bb51e59ed) {
						} else {
							$ed560e114da67dbd[$b3f6223bb51e59ed][] = $B1c1aa7e8b5b4849;
						}
					}
				}
			}

			$ed560e114da67dbd = array_slice($ed560e114da67dbd, count($ed560e114da67dbd) - $e1034511e63f0e9e, $e1034511e63f0e9e, true);

			foreach ($ed560e114da67dbd as $ec35e63ebbf4ef26 => $Badf64d265e8e752) {
				foreach ($Badf64d265e8e752 as $B1c1aa7e8b5b4849) {
					$Bffc17a99eb14fd6[] = $F26087d31c2bbe4d . '_' . $B1c1aa7e8b5b4849 . '.ts';
				}
			}
		}

		return (!empty($Bffc17a99eb14fd6) ? $Bffc17a99eb14fd6 : null);
	}

	public static function d076F5A2cC104c49($bb62005ea7eb8380, $e1034511e63f0e9e = 0, $Ce2588e350bd2724 = 10)
	{
		if (!file_exists($bb62005ea7eb8380)) {
		} else {
			$c8d91fcd2309e48a = file_get_contents($bb62005ea7eb8380);

			if (!preg_match_all('/(.*?).ts/', $c8d91fcd2309e48a, $b85ce31cd1118ad2)) {
			} else {
				if (0 < $e1034511e63f0e9e) {
					$cef7095c03f82513 = intval($e1034511e63f0e9e / $Ce2588e350bd2724);

					if ($cef7095c03f82513) {
					} else {
						$cef7095c03f82513 = 1;
					}

					return array_slice($b85ce31cd1118ad2[0], 0 - $cef7095c03f82513);
				}

				if ($e1034511e63f0e9e == -1) {
					return $b85ce31cd1118ad2[0];
				}

				preg_match('/_(.*)\\./', array_pop($b85ce31cd1118ad2[0]), $E415df512cb68430);

				return $E415df512cb68430[1];
			}
		}
	}

	public static function c0F542BDF7351C78($dc05e2bb97d4635d, $a71afc14d6cd090d, $d5249dad8e8411b7, $F26087d31c2bbe4d, $B08b62d9f7870287, $c59ec257c284c894, $B08e7d3cd339391a = null, $E18c40e895ee55c2 = '', $F2735dad02d30e84 = 'h264', $Beb96c2a189d2e62 = 0, $d58b4f8653a391d8 = null, $b2a9243e8304033d = null)
	{
		if (!file_exists($dc05e2bb97d4635d)) {
		} else {
			$c8d91fcd2309e48a = file_get_contents($dc05e2bb97d4635d);

			if (!self::$rSettings['encrypt_hls'] || $Beb96c2a189d2e62) {
			} else {
				$Ebd6fd2f4db95bcb = Xui\Functions::encrypt($c59ec257c284c894 . '/' . $F26087d31c2bbe4d, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
				$c8d91fcd2309e48a = "#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"" . (($b2a9243e8304033d ? '/' . md5($b2a9243e8304033d . '_' . $d58b4f8653a391d8 . '_' . OPENSSL_EXTRA) : '')) . '/key/' . $Ebd6fd2f4db95bcb . '",IV=0x' . bin2hex(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.iv')) . "\n" . substr($c8d91fcd2309e48a, 8, strlen($c8d91fcd2309e48a) - 8);
			}

			if (!preg_match_all('/(.*?)\\.ts/', $c8d91fcd2309e48a, $b85ce31cd1118ad2)) {
			} else {
				foreach ($b85ce31cd1118ad2[0] as $dbc0f67b4f0fdee0) {
					if ($B08e7d3cd339391a) {
						$ea5296071288c730 = Xui\Functions::encrypt('HMAC#' . $B08e7d3cd339391a . '/' . $E18c40e895ee55c2 . '/' . $c59ec257c284c894 . '/' . $F26087d31c2bbe4d . '/' . $dbc0f67b4f0fdee0 . '/' . $B08b62d9f7870287 . '/' . SERVER_ID . '/' . $F2735dad02d30e84 . '/' . $Beb96c2a189d2e62, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
					} else {
						$ea5296071288c730 = Xui\Functions::encrypt($a71afc14d6cd090d . '/' . $d5249dad8e8411b7 . '/' . $c59ec257c284c894 . '/' . $F26087d31c2bbe4d . '/' . $dbc0f67b4f0fdee0 . '/' . $B08b62d9f7870287 . '/' . SERVER_ID . '/' . $F2735dad02d30e84 . '/' . $Beb96c2a189d2e62, self::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
					}

					if (self::$rSettings['allow_cdn_access']) {
						$c8d91fcd2309e48a = str_replace($dbc0f67b4f0fdee0, (($b2a9243e8304033d ? '/' . md5($b2a9243e8304033d . '_' . $d58b4f8653a391d8 . '_' . OPENSSL_EXTRA) : '')) . '/hls/' . $dbc0f67b4f0fdee0 . '?token=' . $ea5296071288c730, $c8d91fcd2309e48a);
					} else {
						$c8d91fcd2309e48a = str_replace($dbc0f67b4f0fdee0, (($b2a9243e8304033d ? '/' . md5($b2a9243e8304033d . '_' . $d58b4f8653a391d8 . '_' . OPENSSL_EXTRA) : '')) . '/hls/' . $ea5296071288c730, $c8d91fcd2309e48a);
					}
				}

				return $c8d91fcd2309e48a;
			}
		}

		return false;
	}

	public static function de9E9E0D836B5D86($D4253f9520627819, $B08e7d3cd339391a = false, $E18c40e895ee55c2 = '', $c59ec257c284c894 = null, $b3374866087774a1 = null)
	{
		if ($D4253f9520627819['max_connections'] == 0) {
		} else {
			if (!$B08e7d3cd339391a) {
				if (empty($D4253f9520627819['pair_id'])) {
				} else {
					self::D2985c63279EA4cd($D4253f9520627819['pair_id'], $D4253f9520627819['max_connections'], null, '', $c59ec257c284c894, $b3374866087774a1);
				}

				self::D2985C63279ea4cd($D4253f9520627819['id'], $D4253f9520627819['max_connections'], null, '', $c59ec257c284c894, $b3374866087774a1);
			} else {
				self::D2985c63279EA4cD(null, $D4253f9520627819['max_connections'], $B08e7d3cd339391a, $E18c40e895ee55c2, $c59ec257c284c894, $b3374866087774a1);
			}
		}
	}

	public static function getBouquetMap($F26087d31c2bbe4d)
	{
		$B7c4b912a2afc994 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'bouquet_map'));
		$a85e1b7d42c346a0 = ($B7c4b912a2afc994[$F26087d31c2bbe4d] ?: array());
		unset($B7c4b912a2afc994);

		return $a85e1b7d42c346a0;
	}

	public static function AD41BF0664804fA8($F26087d31c2bbe4d)
	{
		$f433193a3297ffde = array();
		self::$db->query('SELECT * FROM `streams` t1 LEFT JOIN `streams_types` t2 ON t2.type_id = t1.type WHERE t1.`id` = ?', $F26087d31c2bbe4d);

		if (0 >= self::$db->num_rows()) {
		} else {
			$bb0071da5a239b0c = self::$db->get_row();
			$a8bb73cba48fb7f6 = array();

			if (!($bb0071da5a239b0c['direct_source'] == 0 || $bb0071da5a239b0c['direct_proxy'] == 1)) {
			} else {
				self::$db->query('SELECT * FROM `streams_servers` WHERE `stream_id` = ?', $F26087d31c2bbe4d);

				if (0 >= self::$db->num_rows()) {
				} else {
					$a8bb73cba48fb7f6 = self::$db->get_rows(true, 'server_id');
				}
			}

			$f433193a3297ffde['bouquets'] = self::getBouquetMap($F26087d31c2bbe4d);
			$f433193a3297ffde['info'] = $bb0071da5a239b0c;
			$f433193a3297ffde['servers'] = $a8bb73cba48fb7f6;
		}

		return (!empty($f433193a3297ffde) ? $f433193a3297ffde : false);
	}

	public static function cB50F783B960a4EF()
	{
		foreach (self::$rServers as $d58b4f8653a391d8 => $e81220b4451f37c9) {
			if (!$e81220b4451f37c9['is_main']) {
			} else {
				return $d58b4f8653a391d8;
			}
		}
	}

	public static function a2aa2B94d2D97a7f($F26087d31c2bbe4d, $e91e92047b92eb25)
	{
		$d919bf727d78c4ca = $c078f3ed0fe7b4fa = array();

		if (!file_exists(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) {
		} else {
			$c078f3ed0fe7b4fa = igbinary_unserialize(file_get_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d)));
		}

		foreach ($c078f3ed0fe7b4fa as $f9b07d216a168dcc) {
			if (!self::dd714eE89C59Fbf2($f9b07d216a168dcc, 'php-fpm')) {
			} else {
				$d919bf727d78c4ca[] = $f9b07d216a168dcc;
			}
		}

		if (in_array($d919bf727d78c4ca, $e91e92047b92eb25)) {
		} else {
			$d919bf727d78c4ca[] = $e91e92047b92eb25;
		}

		file_put_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d), igbinary_serialize($d919bf727d78c4ca));
	}

	public static function CA490cE3385C630E($F26087d31c2bbe4d, $f9b07d216a168dcc)
	{
		$d919bf727d78c4ca = array();

		foreach ((igbinary_unserialize(file_get_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d))) ?: array()) as $adbe9b306d12ef6b) {
			if (!(self::Dd714EE89C59FBf2($adbe9b306d12ef6b, 'php-fpm') && $f9b07d216a168dcc != $adbe9b306d12ef6b)) {
			} else {
				$d919bf727d78c4ca[] = $adbe9b306d12ef6b;
			}
		}

		if (0 < count($d919bf727d78c4ca)) {
			file_put_contents(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d), igbinary_serialize($d919bf727d78c4ca));
		} else {
			unlink(SIGNALS_TMP_PATH . 'queue_' . intval($F26087d31c2bbe4d));
		}
	}

	public static function Bb7f1b0eD6C4b87D($f0434521ea9d1547 = 10)
	{
		$b5808391c52eb3a3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789qwertyuiopasdfghjklzxcvbnm';
		$Faf50feea3df4ce1 = '';
		$ad13d88d0f09412f = strlen($b5808391c52eb3a3) - 1;
		$Ea22c4a9ab5b2176 = 0;

		while ($Ea22c4a9ab5b2176 < $f0434521ea9d1547) {
			$Faf50feea3df4ce1 .= $b5808391c52eb3a3[rand(0, $ad13d88d0f09412f)];
			$Ea22c4a9ab5b2176++;
		}

		return $Faf50feea3df4ce1;
	}

	public static function AE6bb580Baa323C2($c608db3e24256b76, $A02729c83b6cd395)
	{
		if (!(is_numeric($A02729c83b6cd395) && 1900 <= $A02729c83b6cd395 && $A02729c83b6cd395 <= intval(date('Y') + 1))) {
		} else {
			if (self::$rSettings['movie_year_append'] == 0) {
				return trim($c608db3e24256b76) . ' (' . $A02729c83b6cd395 . ')';
			}

			if (self::$rSettings['movie_year_append'] != 0) {
			} else {
				return trim($c608db3e24256b76) . ' - ' . $A02729c83b6cd395;
			}
		}

		return $c608db3e24256b76;
	}

	public static function E43cb741aA22a6d8($f46da30a01f7b2d7)
	{
		if (!(0 < count($f46da30a01f7b2d7) && file_exists(CACHE_TMP_PATH . 'channel_order') && self::$rSettings['channel_number_type'] != 'bouquet')) {
		} else {
			$c6c389b9adf3a40c = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'channel_order'));
			$f46da30a01f7b2d7 = array_flip($f46da30a01f7b2d7);
			$F8dd9a1b55d9bf0b = array();

			foreach ($c6c389b9adf3a40c as $C3c8913edb801c35) {
				if (!isset($f46da30a01f7b2d7[$C3c8913edb801c35])) {
				} else {
					$F8dd9a1b55d9bf0b[] = $C3c8913edb801c35;
				}
			}

			if (0 >= count($F8dd9a1b55d9bf0b)) {
			} else {
				return $F8dd9a1b55d9bf0b;
			}
		}

		return $f46da30a01f7b2d7;
	}

	public static function sortSeries($bbc84f53c534450d)
	{
		if (!(0 < count($bbc84f53c534450d) && file_exists(CACHE_TMP_PATH . 'series_order'))) {
		} else {
			$c6c389b9adf3a40c = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'series_order'));
			$bbc84f53c534450d = array_flip($bbc84f53c534450d);
			$F8dd9a1b55d9bf0b = array();

			foreach ($c6c389b9adf3a40c as $C3c8913edb801c35) {
				if (!isset($bbc84f53c534450d[$C3c8913edb801c35])) {
				} else {
					$F8dd9a1b55d9bf0b[] = $C3c8913edb801c35;
				}
			}

			if (0 >= count($F8dd9a1b55d9bf0b)) {
			} else {
				return $F8dd9a1b55d9bf0b;
			}
		}

		return $bbc84f53c534450d;
	}

	public static function CbfCf0c8CE3D62B9($f338147e1f8d2e97)
	{
		$c07026622e355713 = new DateTime('UTC', new DateTimeZone(date_default_timezone_get()));
		$af336dce58c6bd50 = new DateTime('UTC', new DateTimeZone($f338147e1f8d2e97));

		return $af336dce58c6bd50->getTimestamp() - $c07026622e355713->getTimestamp();
	}

	public static function CC61dBEfe4F00951()
	{
		$a85e1b7d42c346a0 = array();

		foreach (self::$rCategories as $A1925ae53e9307eb) {
			if (!$A1925ae53e9307eb['is_adult']) {
			} else {
				$a85e1b7d42c346a0[] = intval($A1925ae53e9307eb['id']);
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function bfa8B6FE314deD7F()
	{
		if (is_object(self::$redis)) {
		} else {
			try {
				self::$redis = new Redis();
				self::$redis->connect(self::$rConfig['hostname'], 6379);
				self::$redis->auth(self::$rSettings['redis_password']);
			} catch (Exception $c34ae71903f0d920) {
				self::$redis = null;

				return false;
			}
		}

		return true;
	}

	public static function b0b419A0354a0297()
	{
		if (!is_object(self::$redis)) {
		} else {
			self::$redis->close();
			self::$redis = null;
		}

		return true;
	}

	public static function b85cCcef157fB67B($B08b62d9f7870287)
	{
		if (is_object(self::$redis)) {
		} else {
			self::bfA8b6fe314deD7f();
		}

		return igbinary_unserialize(self::$redis->get($B08b62d9f7870287));
	}

	public static function E0C928A3a83F24e9($a27e64cc6ce01033)
	{
		if (is_object(self::$redis)) {
		} else {
			self::BFA8b6Fe314ded7f();
		}

		$F42a951cf0a3370a = self::$redis->multi();
		$F42a951cf0a3370a->zAdd('LINE#' . $a27e64cc6ce01033['identity'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
		$F42a951cf0a3370a->zAdd('LINE_ALL#' . $a27e64cc6ce01033['identity'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
		$F42a951cf0a3370a->zAdd('STREAM#' . $a27e64cc6ce01033['stream_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
		$F42a951cf0a3370a->zAdd('SERVER#' . $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);

		if (!$a27e64cc6ce01033['user_id']) {
		} else {
			$F42a951cf0a3370a->zAdd('SERVER_LINES#' . $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['user_id'], $a27e64cc6ce01033['uuid']);
		}

		if (!$a27e64cc6ce01033['proxy_id']) {
		} else {
			$F42a951cf0a3370a->zAdd('PROXY#' . $a27e64cc6ce01033['proxy_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
		}

		$F42a951cf0a3370a->zAdd('CONNECTIONS', $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
		$F42a951cf0a3370a->zAdd('LIVE', $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
		$F42a951cf0a3370a->set($a27e64cc6ce01033['uuid'], igbinary_serialize($a27e64cc6ce01033));

		return $F42a951cf0a3370a->exec();
	}

	public static function e3484F74d3c8B5a7($a27e64cc6ce01033, $a6b40128767dfe4f = array(), $ec42cf0557b72e6f = null)
	{
		if (is_object(self::$redis)) {
		} else {
			self::Bfa8B6FE314DeD7F();
		}

		$d9b341c05baed5be = $a27e64cc6ce01033;

		foreach ($a6b40128767dfe4f as $D3fa098be3f297cd => $b6842cb20051e925) {
			$a27e64cc6ce01033[$D3fa098be3f297cd] = $b6842cb20051e925;
		}
		$F42a951cf0a3370a = self::$redis->multi();

		if ($ec42cf0557b72e6f == 'open') {
			$F42a951cf0a3370a->sRem('ENDED', $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('LIVE', $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('LINE#' . $a27e64cc6ce01033['identity'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('STREAM#' . $a27e64cc6ce01033['stream_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			$F42a951cf0a3370a->zAdd('SERVER#' . $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);

			if (!$a27e64cc6ce01033['proxy_id']) {
			} else {
				$F42a951cf0a3370a->zAdd('PROXY#' . $a27e64cc6ce01033['proxy_id'], $a27e64cc6ce01033['date_start'], $a27e64cc6ce01033['uuid']);
			}

			if ($a27e64cc6ce01033['hls_end'] != 1) {
			} else {
				$a27e64cc6ce01033['hls_end'] = 0;

				if (!$a27e64cc6ce01033['user_id']) {
				} else {
					$F42a951cf0a3370a->zAdd('SERVER_LINES#' . $a27e64cc6ce01033['server_id'], $a27e64cc6ce01033['user_id'], $a27e64cc6ce01033['uuid']);
				}
			}
		} else {
			if ($ec42cf0557b72e6f != 'close') {
			} else {
				$F42a951cf0a3370a->sAdd('ENDED', $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('LIVE', $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('LINE#' . $d9b341c05baed5be['identity'], $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('STREAM#' . $d9b341c05baed5be['stream_id'], $a27e64cc6ce01033['uuid']);
				$F42a951cf0a3370a->zRem('SERVER#' . $d9b341c05baed5be['server_id'], $a27e64cc6ce01033['uuid']);

				if (!$a27e64cc6ce01033['proxy_id']) {
				} else {
					$F42a951cf0a3370a->zRem('PROXY#' . $d9b341c05baed5be['proxy_id'], $a27e64cc6ce01033['uuid']);
				}

				if ($a27e64cc6ce01033['hls_end'] != 0) {
				} else {
					$a27e64cc6ce01033['hls_end'] = 1;

					if (!$a27e64cc6ce01033['user_id']) {
					} else {
						$F42a951cf0a3370a->zRem('SERVER_LINES#' . $d9b341c05baed5be['server_id'], $a27e64cc6ce01033['uuid']);
					}
				}
			}
		}

		$F42a951cf0a3370a->set($a27e64cc6ce01033['uuid'], igbinary_serialize($a27e64cc6ce01033));

		if ($F42a951cf0a3370a->exec()) {
			return $a27e64cc6ce01033;
		}
	}

	public static function BC23764Ed0732f3F($D78ff1d0edade5eb, $ccf88201f4394db1 = false, $f16991461acd03bf = false)
	{
		if (is_object(self::$redis)) {
		} else {
			self::BFa8B6fE314DEd7f();
		}

		$f16991461acd03bf = self::$redis->zRangeByScore((($ccf88201f4394db1 ? 'LINE#' : 'LINE_ALL#')) . $D78ff1d0edade5eb, '-inf', '+inf');

		if ($f16991461acd03bf) {
			return $f16991461acd03bf;
		}

		if (0 >= count($f16991461acd03bf)) {
			return array();
		}

		return array_map('igbinary_unserialize', self::$redis->mGet($f16991461acd03bf));
	}

	public static function aA941cF79C4f48cf($f9b07d216a168dcc, $d58b4f8653a391d8, $C2897f488ae9e7fe, $Bccc89fc1174404a = null)
	{
		if (is_object(self::$redis)) {
		} else {
			self::BFA8B6fe314dEd7f();
		}

		$D3fa098be3f297cd = 'SIGNAL#' . md5($d58b4f8653a391d8 . '#' . $f9b07d216a168dcc . '#' . $C2897f488ae9e7fe);
		$a27e64cc6ce01033 = array('pid' => $f9b07d216a168dcc, 'server_id' => $d58b4f8653a391d8, 'rtmp' => $C2897f488ae9e7fe, 'time' => time(), 'custom_data' => $Bccc89fc1174404a, 'key' => $D3fa098be3f297cd);

		return self::$redis->multi()->sAdd('SIGNALS#' . $d58b4f8653a391d8, $D3fa098be3f297cd)->set($D3fa098be3f297cd, igbinary_serialize($a27e64cc6ce01033))->exec();
	}

	public static function CCedfAEA1d970310($bbf487337b8f5211, $d49041d5f05a9270)
	{
		$fcddc626f9cf5c18 = null;

		foreach ($d49041d5f05a9270 as $bb2621204e39e62d) {
			if (!($fcddc626f9cf5c18 === null || abs($bb2621204e39e62d - $bbf487337b8f5211) < abs($bbf487337b8f5211 - $fcddc626f9cf5c18))) {
			} else {
				$fcddc626f9cf5c18 = $bb2621204e39e62d;
			}
		}

		return $fcddc626f9cf5c18;
	}

	public static function D55A1D8acD201840($bdd1eae90d142462 = false)
	{
		$a70eaa0ab42179dd = null;
		$d58b4f8653a391d8 = SERVER_ID;

		if ($bdd1eae90d142462) {
			$C6033ec178efa2ae = 'https';
		} else {
			if (isset($_SERVER['SERVER_PORT']) && self::$rSettings['keep_protocol']) {
				$C6033ec178efa2ae = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443 ? 'https' : 'http');
			} else {
				$C6033ec178efa2ae = self::$rServers[$d58b4f8653a391d8]['server_protocol'];
			}
		}

		$A1fe548fd94fcef3 = self::$rServers[$d58b4f8653a391d8]['enable_proxy'];

		if (!$A1fe548fd94fcef3) {
		} else {
			$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8));

			if (count($Da9a40906d3d1c5f) != 0) {
			} else {
				$Da9a40906d3d1c5f = array_keys(self::getProxies($d58b4f8653a391d8, false));
			}

			if (count($Da9a40906d3d1c5f) != 0) {
				$a70eaa0ab42179dd = $d58b4f8653a391d8;
				$d58b4f8653a391d8 = $Da9a40906d3d1c5f[array_rand($Da9a40906d3d1c5f)];
			} else {
				return '';
			}
		}

		list($Caecf2bcd39a1efe, $dc7aa3c286c6a885) = explode(':', $_SERVER['HTTP_HOST']);

		if (!($A1fe548fd94fcef3 || self::$rSettings['use_mdomain_in_lists'] == 1)) {
		} else {
			if (in_array(strtolower($Caecf2bcd39a1efe), (self::aBb674425a8b1b0D('reseller_domains') ?: array()))) {
			} else {
				if (empty(self::$rServers[$d58b4f8653a391d8]['domain_name'])) {
					$Caecf2bcd39a1efe = escapeshellcmd(self::$rServers[$d58b4f8653a391d8]['server_ip']);
				} else {
					$Caecf2bcd39a1efe = str_replace(array('http://', '/', 'https://'), '', escapeshellcmd(explode(',', self::$rServers[$d58b4f8653a391d8]['domain_name'])[0]));
				}
			}
		}

		$f4116b9928c8b494 = $C6033ec178efa2ae . '://' . $Caecf2bcd39a1efe . ':' . self::$rServers[$d58b4f8653a391d8][$C6033ec178efa2ae . '_broadcast_port'] . '/';

		if (!(self::$rServers[$d58b4f8653a391d8]['server_type'] == 1 && $a70eaa0ab42179dd && self::$rServers[$a70eaa0ab42179dd]['is_main'] == 0)) {
		} else {
			$f4116b9928c8b494 .= md5($d58b4f8653a391d8 . '_' . $a70eaa0ab42179dd . '_' . OPENSSL_EXTRA) . '/';
		}

		return $f4116b9928c8b494;
	}

	public static function getProxies($d58b4f8653a391d8, $F148ac2342eb3b2b = true)
	{
		$a85e1b7d42c346a0 = array();

		foreach (self::$rServers as $b2a9243e8304033d => $cc5f26dd881329b7) {
			if (!($cc5f26dd881329b7['server_type'] == 1 && in_array($d58b4f8653a391d8, $cc5f26dd881329b7['parent_id']) && ($cc5f26dd881329b7['server_online'] || !$F148ac2342eb3b2b))) {
			} else {
				$a85e1b7d42c346a0[$b2a9243e8304033d] = $cc5f26dd881329b7;
			}
		}

		return $a85e1b7d42c346a0;
	}

	public static function getStreamingURL($d58b4f8653a391d8 = null, $a70eaa0ab42179dd = null, $Acfdd9e81f0cf9d5 = false)
	{
		if (isset($d58b4f8653a391d8)) {
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		if ($Acfdd9e81f0cf9d5) {
			$C6033ec178efa2ae = 'http';
		} else {
			if (self::$rSettings['keep_protocol']) {
				$C6033ec178efa2ae = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443 ? 'https' : 'http');
			} else {
				$C6033ec178efa2ae = self::$rServers[$d58b4f8653a391d8]['server_protocol'];
			}
		}

		$Caecf2bcd39a1efe = null;

		if (0 < strlen(HOST) && in_array(strtolower(HOST), array_map('strtolower', self::$rServers[$d58b4f8653a391d8]['domains']['urls']))) {
			$Caecf2bcd39a1efe = HOST;
		} else {
			if (!(self::$rServers[$d58b4f8653a391d8]['random_ip'] && 0 < count(self::$rServers[$d58b4f8653a391d8]['domains']['urls']))) {
			} else {
				$Caecf2bcd39a1efe = self::$rServers[$d58b4f8653a391d8]['domains']['urls'][array_rand(self::$rServers[$d58b4f8653a391d8]['domains']['urls'])];
			}
		}

		if ($Caecf2bcd39a1efe) {
			$C700a2b357e5ed65 = $C6033ec178efa2ae . '://' . $Caecf2bcd39a1efe . ':' . self::$rServers[$d58b4f8653a391d8][$C6033ec178efa2ae . '_broadcast_port'];
		} else {
			$C700a2b357e5ed65 = rtrim(self::$rServers[$d58b4f8653a391d8][$C6033ec178efa2ae . '_url'], '/');
		}

		if (!(self::$rServers[$d58b4f8653a391d8]['server_type'] == 1 && $a70eaa0ab42179dd && self::$rServers[$a70eaa0ab42179dd]['is_main'] == 0)) {
		} else {
			$C700a2b357e5ed65 .= '/' . md5($d58b4f8653a391d8 . '_' . $a70eaa0ab42179dd . '_' . OPENSSL_EXTRA);
		}

		return $C700a2b357e5ed65;
	}
}
