<?php

require_once 'constants.php';
require_once INCLUDES_PATH . 'xui.php';
require_once INCLUDES_PATH . 'pdo.php';

if (!function_exists('getallheaders')) {
	function getallheaders()
	{
		$Ae2b613e51651b56 = array();

		foreach ($_SERVER as $d9ee1cc8e0f43f6e => $b6842cb20051e925) {
			if (substr($d9ee1cc8e0f43f6e, 0, 5) != 'HTTP_') {
			} else {
				$Ae2b613e51651b56[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($d9ee1cc8e0f43f6e, 5)))))] = $b6842cb20051e925;
			}
		}

		return $Ae2b613e51651b56;
	}
}

if (basename(__FILE__) != basename($_SERVER['SCRIPT_FILENAME'])) {
} else {
	DB709ed65aE02245();
}

$bc2874292e0d9ece = strtolower(basename(get_included_files()[0], '.php'));

if (!in_array($bc2874292e0d9ece, array('enigma2', 'epg', 'playlist', 'api', 'xplugin', 'live', 'proxy_api', 'thumb', 'timeshift', 'vod')) || $argc) {
	$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
	XUI::$db = &$Fee0d5a474c96306;
	XUI::init();
} else {
	$Fee0d5a474c96306 = new Database(null);
	XUI::$db = &$Fee0d5a474c96306;
	XUI::init(true);

	if (XUI::$rCached) {
	} else {
		$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
		XUI::$db = &$Fee0d5a474c96306;
	}
}
