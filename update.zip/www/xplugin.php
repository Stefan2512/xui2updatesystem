<?php

register_shutdown_function('shutdown');
require 'init.php';
$Dab081f66facd7a3 = true;

if (!XUI::$rSettings['disable_enigma2']) {
} else {
	$Dab081f66facd7a3 = false;
	generateError('E2_DISABLED');
}

$c59ec257c284c894 = $_SERVER['REMOTE_ADDR'];
$b3374866087774a1 = trim($_SERVER['HTTP_USER_AGENT']);

if (empty(XUI::$rRequest['action']) || XUI::$rRequest['action'] != 'gen_mac' || empty(XUI::$rRequest['pversion'])) {
	$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
	XUI::$db = &$Fee0d5a474c96306;

	if (empty(XUI::$rRequest['action']) || XUI::$rRequest['action'] != 'auth') {
	} else {
		$C3cdd40816db3399 = (isset(XUI::$rRequest['mac']) ? htmlentities(XUI::$rRequest['mac']) : '');
		$c8249d7128b58044 = (isset(XUI::$rRequest['mmac']) ? htmlentities(XUI::$rRequest['mmac']) : '');
		$cad9696c9fffb7bc = (isset(XUI::$rRequest['ip']) ? htmlentities(XUI::$rRequest['ip']) : '');
		$b954cd2fc008a63a = (isset(XUI::$rRequest['version']) ? htmlentities(XUI::$rRequest['version']) : '');
		$A5f9aca3132df579 = (isset(XUI::$rRequest['type']) ? htmlentities(XUI::$rRequest['type']) : '');
		$a791428828fc242f = (isset(XUI::$rRequest['pversion']) ? htmlentities(XUI::$rRequest['pversion']) : '');
		$D8d45ff422d575dd = (isset(XUI::$rRequest['lversion']) ? base64_decode(XUI::$rRequest['lversion']) : '');
		$f9f734f8d09d6e40 = (!empty(XUI::$rRequest['dn']) ? htmlentities(XUI::$rRequest['dn']) : '-');
		$A14c5f87716fea6c = (!empty(XUI::$rRequest['cmac']) ? htmlentities(strtoupper(XUI::$rRequest['cmac'])) : '');
		$daf75594e6c4d51c = array();

		if ($cdc93dae5ba3d206 = XUI::fc10B2257ED1989A(array('device_id' => null, 'mac' => strtoupper($C3cdd40816db3399)))) {
			$Dab081f66facd7a3 = false;

			if ($cdc93dae5ba3d206['enigma2']['lock_device'] != 1) {
			} else {
				if (empty($cdc93dae5ba3d206['enigma2']['modem_mac']) || $cdc93dae5ba3d206['enigma2']['modem_mac'] === $c8249d7128b58044) {
				} else {
					XUI::B6f740FaBc7265bF(null, strtoupper($C3cdd40816db3399));
					generateError('E2_DEVICE_LOCK_FAILED');
				}
			}

			$ea5296071288c730 = strtoupper(md5(uniqid(rand(), true)));
			$cd2a4260ef308305 = mt_rand(60, 70);
			$Fee0d5a474c96306->query('UPDATE `enigma2_devices` SET `original_mac` = ?,`dns` = ?,`key_auth` = ?,`lversion` = ?,`watchdog_timeout` = ?,`modem_mac` = ?,`local_ip` = ?,`public_ip` = ?,`enigma_version` = ?,`cpu` = ?,`version` = ?,`token` = ?,`last_updated` = ? WHERE `device_id` = ?', $A14c5f87716fea6c, $f9f734f8d09d6e40, $b3374866087774a1, $D8d45ff422d575dd, $cd2a4260ef308305, $c8249d7128b58044, $cad9696c9fffb7bc, $c59ec257c284c894, $b954cd2fc008a63a, $A5f9aca3132df579, $a791428828fc242f, $ea5296071288c730, time(), $cdc93dae5ba3d206['enigma2']['device_id']);
			$daf75594e6c4d51c['details'] = array();
			$daf75594e6c4d51c['details']['token'] = $ea5296071288c730;
			$daf75594e6c4d51c['details']['username'] = $cdc93dae5ba3d206['user_info']['username'];
			$daf75594e6c4d51c['details']['password'] = $cdc93dae5ba3d206['user_info']['password'];
			$daf75594e6c4d51c['details']['watchdog_seconds'] = $cd2a4260ef308305;
			header('Content-Type: application/json');
			echo json_encode($daf75594e6c4d51c);

			exit();
		}

		XUI::b6F740fAbC7265BF(null, strtoupper($C3cdd40816db3399));
		generateError('INVALID_CREDENTIALS');
	}

	if (!empty(XUI::$rRequest['token'])) {
	} else {
		generateError('E2_NO_TOKEN');
	}

	$ea5296071288c730 = XUI::$rRequest['token'];
	$Fee0d5a474c96306->query('SELECT * FROM enigma2_devices WHERE `token` = ? AND `public_ip` = ? AND `key_auth` = ? LIMIT 1;', $ea5296071288c730, $c59ec257c284c894, $b3374866087774a1);

	if ($Fee0d5a474c96306->num_rows() > 0) {
	} else {
		generateError('E2_TOKEN_DOESNT_MATCH');
	}

	$Dab081f66facd7a3 = false;
	$Fdc8e0fc5edb3ca8 = $Fee0d5a474c96306->get_row();

	if ($Fdc8e0fc5edb3ca8['watchdog_timeout'] + 20 >= time() - $Fdc8e0fc5edb3ca8['last_updated']) {
	} else {
		generateError('E2_WATCHDOG_TIMEOUT');
	}

	$ddf21fc658e95052 = (isset(XUI::$rRequest['page']) ? XUI::$rRequest['page'] : '');

	if (empty($ddf21fc658e95052)) {
		$Fee0d5a474c96306->query('UPDATE `enigma2_devices` SET `last_updated` = ?,`rc` = ? WHERE `device_id` = ?;', time(), XUI::$rRequest['rc'], $Fdc8e0fc5edb3ca8['device_id']);
		$Fee0d5a474c96306->query('SELECT * FROM `enigma2_actions` WHERE `device_id` = ?;', $Fdc8e0fc5edb3ca8['device_id']);
		$B59c127fecf35c15 = array();

		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			$Ee415a632c5c0dcd = $Fee0d5a474c96306->get_row();

			if ($Ee415a632c5c0dcd['key'] == 'message') {
				$B59c127fecf35c15['message'] = array();
				$B59c127fecf35c15['message']['title'] = $Ee415a632c5c0dcd['command2'];
				$B59c127fecf35c15['message']['message'] = $Ee415a632c5c0dcd['command'];
			} else {
				if ($Ee415a632c5c0dcd['key'] == 'ssh') {
					$B59c127fecf35c15['ssh'] = $Ee415a632c5c0dcd['command'];
				} else {
					if ($Ee415a632c5c0dcd['key'] == 'screen') {
						$B59c127fecf35c15['screen'] = '1';
					} else {
						if ($Ee415a632c5c0dcd['key'] == 'reboot_gui') {
							$B59c127fecf35c15['reboot_gui'] = 1;
						} else {
							if ($Ee415a632c5c0dcd['key'] == 'reboot') {
								$B59c127fecf35c15['reboot'] = 1;
							} else {
								if ($Ee415a632c5c0dcd['key'] == 'update') {
									$B59c127fecf35c15['update'] = $Ee415a632c5c0dcd['command'];
								} else {
									if ($Ee415a632c5c0dcd['key'] == 'block_ssh') {
										$B59c127fecf35c15['block_ssh'] = (int) $Ee415a632c5c0dcd['type'];
									} else {
										if ($Ee415a632c5c0dcd['key'] == 'block_telnet') {
											$B59c127fecf35c15['block_telnet'] = (int) $Ee415a632c5c0dcd['type'];
										} else {
											if ($Ee415a632c5c0dcd['key'] == 'block_ftp') {
												$B59c127fecf35c15['block_ftp'] = (int) $Ee415a632c5c0dcd['type'];
											} else {
												if ($Ee415a632c5c0dcd['key'] == 'block_all') {
													$B59c127fecf35c15['block_all'] = (int) $Ee415a632c5c0dcd['type'];
												} else {
													if ($Ee415a632c5c0dcd['key'] != 'block_plugin') {
													} else {
														$B59c127fecf35c15['block_plugin'] = (int) $Ee415a632c5c0dcd['type'];
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			$Fee0d5a474c96306->query('DELETE FROM `enigma2_actions` WHERE `id` = ?;', $Ee415a632c5c0dcd['id']);
		}

		header('Content-Type: application/json');

		exit(json_encode(array('valid' => true, 'data' => $B59c127fecf35c15)));
	}

	if ($ddf21fc658e95052 != 'file') {
	} else {
		if (empty($_FILES['f']['name'])) {
		} else {
			if ($_FILES['f']['error'] != 0) {
			} else {
				$Ac2ef3d1af0020dc = strtolower($_FILES['f']['tmp_name']);
				$E379394c7b1a273f = XUI::$rRequest['t'];

				switch ($E379394c7b1a273f) {
					case 'screen':
						$Eea1b980ebbe2a33 = getimagesize($_FILES['f']['tmp_name']);

						if (!($Eea1b980ebbe2a33 && $Eea1b980ebbe2a33[2] == 'IMAGETYPE_JPEG')) {
						} else {
							move_uploaded_file($_FILES['f']['tmp_name'], E2_IMAGES_PATH . $Fdc8e0fc5edb3ca8['device_id'] . '_screen_' . time() . '_' . uniqid() . '.jpg');
						}

						break;
				}
			}
		}
	}
} else {
	$Dab081f66facd7a3 = false;

	if (XUI::$rRequest['pversion'] == '0.0.1') {
	} else {
		echo json_encode(strtoupper(implode(':', str_split(substr(md5(mt_rand()), 0, 12), 2))));
	}

	exit();
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $Dab081f66facd7a3;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::fC8474658Ec80360();
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
