<?php

register_shutdown_function('shutdown');
require 'init.php';
set_time_limit(0);
header('Access-Control-Allow-Origin: *');
$Dab081f66facd7a3 = true;

if (strtolower(explode('.', ltrim(parse_url($_SERVER['REQUEST_URI'])['path'], '/'))[0]) != 'xmltv' || XUI::$rSettings['legacy_xmltv']) {
} else {
	$Dab081f66facd7a3 = false;
	generateError('LEGACY_EPG_DISABLED');
}

$F4a4cac9883825e6 = false;
$c59ec257c284c894 = XUI::A9Bc416Fa6FA55c3();
$efc0f8f3059e4104 = XUI::b74f652C92cEC688($c59ec257c284c894)['country']['iso_code'];
$b3374866087774a1 = (empty($_SERVER['HTTP_USER_AGENT']) ? '' : htmlentities(trim($_SERVER['HTTP_USER_AGENT'])));
$a71afc14d6cd090d = XUI::$rRequest['username'];
$d5249dad8e8411b7 = XUI::$rRequest['password'];
$a9a887b249900f55 = !empty(XUI::$rRequest['gzip']) && intval(XUI::$rRequest['gzip']) == 1;

if (isset(XUI::$rRequest['username']) && isset(XUI::$rRequest['password'])) {
	$a71afc14d6cd090d = XUI::$rRequest['username'];
	$d5249dad8e8411b7 = XUI::$rRequest['password'];

	if (!(empty($a71afc14d6cd090d) || empty($d5249dad8e8411b7))) {
	} else {
		generateError('NO_CREDENTIALS');
	}

	$D4253f9520627819 = XUI::D7ca435Ac70E9A78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, false, false, $c59ec257c284c894);
} else {
	if (isset(XUI::$rRequest['token'])) {
		$ea5296071288c730 = XUI::$rRequest['token'];

		if (!empty($ea5296071288c730)) {
		} else {
			generateError('NO_CREDENTIALS');
		}

		$D4253f9520627819 = XUI::d7ca435Ac70E9a78(null, $ea5296071288c730, null, false, false, $c59ec257c284c894);
	} else {
		generateError('NO_CREDENTIALS');
	}
}

ini_set('memory_limit', -1);

if ($D4253f9520627819) {
	$Dab081f66facd7a3 = false;

	if ($D4253f9520627819['is_restreamer'] || !XUI::$rSettings['disable_xmltv']) {
	} else {
		generateError('EPG_DISABLED');
	}

	if (!($D4253f9520627819['is_restreamer'] && XUI::$rSettings['disable_xmltv_restreamer'])) {
	} else {
		generateError('EPG_DISABLED');
	}

	if ($D4253f9520627819['bypass_ua'] != 0) {
	} else {
		if (!XUI::E416910Ca4DA4695($b3374866087774a1, true)) {
		} else {
			generateError('BLOCKED_USER_AGENT');
		}
	}

	if (is_null($D4253f9520627819['exp_date']) || $D4253f9520627819['exp_date'] > time()) {
	} else {
		generateError('EXPIRED');
	}

	if (!($D4253f9520627819['is_mag'] || $D4253f9520627819['is_e2'])) {
	} else {
		generateError('DEVICE_NOT_ALLOWED');
	}

	if ($D4253f9520627819['admin_enabled']) {
	} else {
		generateError('BANNED');
	}

	if ($D4253f9520627819['enabled']) {
	} else {
		generateError('DISABLED');
	}

	if (!XUI::$rSettings['restrict_playlists']) {
	} else {
		if (!(empty($b3374866087774a1) && XUI::$rSettings['disallow_empty_user_agents'] == 1)) {
		} else {
			generateError('EMPTY_USER_AGENT');
		}

		if (empty($D4253f9520627819['allowed_ips']) || in_array($c59ec257c284c894, array_map('gethostbyname', $D4253f9520627819['allowed_ips']))) {
		} else {
			generateError('NOT_IN_ALLOWED_IPS');
		}

		if (empty($efc0f8f3059e4104)) {
		} else {
			$ac720430e021c8c0 = !empty($D4253f9520627819['forced_country']);

			if (!($ac720430e021c8c0 && $D4253f9520627819['forced_country'] != 'ALL' && $efc0f8f3059e4104 != $D4253f9520627819['forced_country'])) {
			} else {
				generateError('FORCED_COUNTRY_INVALID');
			}

			if ($ac720430e021c8c0 || in_array('ALL', XUI::$rSettings['allow_countries']) || in_array($efc0f8f3059e4104, XUI::$rSettings['allow_countries'])) {
			} else {
				generateError('NOT_IN_ALLOWED_COUNTRY');
			}
		}

		if (empty($D4253f9520627819['allowed_ua']) || in_array($b3374866087774a1, $D4253f9520627819['allowed_ua'])) {
		} else {
			generateError('NOT_IN_ALLOWED_UAS');
		}

		if ($D4253f9520627819['isp_violate'] != 1) {
		} else {
			generateError('ISP_BLOCKED');
		}

		if ($D4253f9520627819['isp_is_server'] != 1 || $D4253f9520627819['is_restreamer']) {
		} else {
			generateError('ASN_BLOCKED');
		}
	}

	$cb498e4dcaac05cc = array();

	foreach ($D4253f9520627819['bouquet'] as $C52c0b6b0f74407b) {
		if (!in_array($C52c0b6b0f74407b, array_keys(XUI::$rBouquets))) {
		} else {
			$cb498e4dcaac05cc[] = $C52c0b6b0f74407b;
		}
	}
	sort($cb498e4dcaac05cc);
	$Fbab458e55d8faad = md5(implode('_', $cb498e4dcaac05cc));

	if (file_exists(EPG_PATH . 'epg_' . $Fbab458e55d8faad . '.xml')) {
		$e2f848a82a80c113 = EPG_PATH . 'epg_' . $Fbab458e55d8faad . '.xml';
	} else {
		$e2f848a82a80c113 = EPG_PATH . 'epg_all.xml';
	}

	$bc2874292e0d9ece = 'epg.xml';

	if (!$a9a887b249900f55) {
	} else {
		$e2f848a82a80c113 .= '.gz';
		$bc2874292e0d9ece .= '.gz';
	}

	if (file_exists($e2f848a82a80c113)) {
		if (XUI::a93caB970d8d7916('epg', $D4253f9520627819, getmypid())) {
			$F4a4cac9883825e6 = true;
			header('Content-disposition: attachment; filename="' . $bc2874292e0d9ece . '"');

			if ($a9a887b249900f55) {
				header('Content-Type: application/octet-stream');
				header('Content-Transfer-Encoding: Binary');
			} else {
				header('Content-Type: application/xml; charset=utf-8');
			}

			readchunked($e2f848a82a80c113);
		} else {
			generateError('DOWNLOAD_LIMIT_REACHED', false);
			http_response_code(429);

			exit();
		}
	} else {
		generateError('EPG_FILE_MISSING');
	}

	exit();
} else {
	XUI::b6F740fabc7265BF(null, null, $a71afc14d6cd090d);
	generateError('INVALID_CREDENTIALS');
}

function readChunked($bc2874292e0d9ece)
{
	$a8f3762d489787d6 = fopen($bc2874292e0d9ece, 'rb');

	if ($a8f3762d489787d6 !== false) {
		while (!feof($a8f3762d489787d6)) {
			$b9f3f039ea3bf5ca = fread($a8f3762d489787d6, 1048576);
			echo $b9f3f039ea3bf5ca;
			ob_flush();
			flush();
		}

		return fclose($a8f3762d489787d6);
	}

	return false;
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $Dab081f66facd7a3;
	global $D4253f9520627819;
	global $F4a4cac9883825e6;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::FC8474658Ec80360();
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}

	if (!$F4a4cac9883825e6) {
	} else {
		XUI::cD81a6DF500dCFFD('epg', $D4253f9520627819, getmypid());
	}
}
