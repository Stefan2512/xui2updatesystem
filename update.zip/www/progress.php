<?php

ignore_user_abort(true);
require 'constants.php';
$E330444f58f09645 = trim(file_get_contents('php://input'));

if (!($_SERVER['REMOTE_ADDR'] != '127.0.0.1' || empty($_GET['stream_id']) || empty($E330444f58f09645))) {
} else {
	dB709eD65aE02245();
}

$F26087d31c2bbe4d = intval($_GET['stream_id']);
$a27e64cc6ce01033 = array_filter(array_map('trim', explode("\n", $E330444f58f09645)));
$f433193a3297ffde = array();

foreach ($a27e64cc6ce01033 as $C740da31596f24ef) {
	list($D3fa098be3f297cd, $b6842cb20051e925) = explode('=', $C740da31596f24ef);
	$f433193a3297ffde[trim($D3fa098be3f297cd)] = trim($b6842cb20051e925);
}
file_put_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.progress', json_encode($f433193a3297ffde));
