<?php

register_shutdown_function('shutdown');
header('Access-Control-Allow-Origin: *');
set_time_limit(0);
require '../init.php';
$c59ec257c284c894 = XUI::a9Bc416FA6FA55c3();

if (!empty(XUI::$rRequest['uitoken'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['uitoken'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);
	XUI::$rRequest['stream'] = $F64d974c429d80be['stream_id'];
	$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $F64d974c429d80be['ip']), 0, -1)) == implode('.', array_slice(explode('.', XUI::A9Bc416fA6Fa55c3()), 0, -1)) : $F64d974c429d80be['ip'] == XUI::a9bC416fA6FA55c3());

	if ($F64d974c429d80be['expires'] >= time() && $ee7553b0caebc8c4) {
	} else {
		dB709ed65ae02245();
	}
} else {
	db709Ed65Ae02245();
}

$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
XUI::$db = &$Fee0d5a474c96306;
$F26087d31c2bbe4d = intval(XUI::$rRequest['stream']);
$f523e362fb81d6c8 = array();
$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type AND t2.live = 1 LEFT JOIN `profiles` t4 ON t1.transcode_profile_id = t4.profile_id WHERE t1.direct_source = 0 AND t1.id = ?', $F26087d31c2bbe4d);

if ($Fee0d5a474c96306->num_rows() > 0) {
} else {
	db709ED65AE02245();
}

$f523e362fb81d6c8 = $Fee0d5a474c96306->get_row();

if (SERVER_ID == $f523e362fb81d6c8['vframes_server_id']) {
	if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg') && time() - filemtime(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg') < 60) {
		header('Age: ' . intval(time() - filemtime(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg')));
		header('Content-type: image/jpg');
		echo file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg');

		exit();
	}

	Db709ED65Ae02245();
} else {
	$C700a2b357e5ed65 = XUI::$rServers[$f523e362fb81d6c8['vframes_server_id']]['site_url'];
	header('Location: ' . $C700a2b357e5ed65 . 'admin/thumb?stream=' . $F26087d31c2bbe4d . '&aid=' . intval(XUI::$rRequest['aid']) . '&uitoken=' . urlencode(XUI::$rRequest['uitoken']) . '&expires=' . intval(XUI::$rRequest['expires']));

	exit();
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
