<?php

register_shutdown_function('shutdown');
header('Access-Control-Allow-Origin: *');
set_time_limit(0);
require '../init.php';
$c59ec257c284c894 = XUI::A9BC416fA6fa55c3();

if (XUI::$rSettings['use_buffer'] != 0) {
} else {
	header('X-Accel-Buffering: no');
}

if (!empty(XUI::$rRequest['uitoken'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['uitoken'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);
	XUI::$rRequest['stream'] = $F64d974c429d80be['stream_id'];
	XUI::$rRequest['extension'] = 'm3u8';

	if (!isset($F64d974c429d80be['start'])) {
	} else {
		XUI::$rRequest['start'] = $F64d974c429d80be['start'];
	}

	if (!isset($F64d974c429d80be['duration'])) {
	} else {
		XUI::$rRequest['duration'] = $F64d974c429d80be['duration'];
	}

	$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $F64d974c429d80be['ip']), 0, -1)) == implode('.', array_slice(explode('.', XUI::a9bC416FA6fA55C3()), 0, -1)) : $F64d974c429d80be['ip'] == XUI::A9Bc416fa6Fa55C3());

	if ($F64d974c429d80be['expires'] >= time() && $ee7553b0caebc8c4) {
	} else {
		Db709Ed65AE02245();
	}
} else {
	if (!in_array($c59ec257c284c894, XUI::c5931Cd0269d0a3d())) {
		DB709eD65Ae02245();
	} else {
		if (!(empty(XUI::$rRequest['password']) || XUI::$rSettings['live_streaming_pass'] != XUI::$rRequest['password'])) {
		} else {
			db709ed65AE02245();
		}
	}
}

$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
XUI::$db = &$Fee0d5a474c96306;
$d5249dad8e8411b7 = XUI::$rSettings['live_streaming_pass'];
$F26087d31c2bbe4d = intval(XUI::$rRequest['stream']);
$F9452a7efafa1aba = XUI::$rRequest['extension'];

if (!empty(XUI::$rRequest['segment'])) {
} else {
	$a63ba41c5c63ce14 = XUI::$rRequest['start'];
	$C5034884ed44603a = XUI::$rRequest['duration'];

	if (!is_numeric($a63ba41c5c63ce14)) {
		if (substr_count($a63ba41c5c63ce14, '-') == 1) {
			list($c94b497359f8aed9, $C4af185e24cf9086) = explode('-', $a63ba41c5c63ce14);
			$A02729c83b6cd395 = substr($c94b497359f8aed9, 0, 4);
			$f01ae1008c6933f7 = substr($c94b497359f8aed9, 4, 2);
			$d20afc15ac839efc = substr($c94b497359f8aed9, 6, 2);
			$D1b34eaa5eef40cc = 0;
			$d08bd3f46de523f4 = $C4af185e24cf9086;
		} else {
			list($c94b497359f8aed9, $C4af185e24cf9086) = explode(':', $a63ba41c5c63ce14);
			list($A02729c83b6cd395, $f01ae1008c6933f7, $d20afc15ac839efc) = explode('-', $c94b497359f8aed9);
			list($d08bd3f46de523f4, $D1b34eaa5eef40cc) = explode('-', $C4af185e24cf9086);
		}

		$e0d8bd4d04af5371 = mktime($d08bd3f46de523f4, $D1b34eaa5eef40cc, 0, $f01ae1008c6933f7, $d20afc15ac839efc, $A02729c83b6cd395);
	} else {
		$e0d8bd4d04af5371 = $a63ba41c5c63ce14;
	}
}

$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.server_id = ? WHERE t1.`id` = ?', SERVER_ID, $F26087d31c2bbe4d);

if (0 < $Fee0d5a474c96306->num_rows()) {
	$fca7edf85daa1695 = $Fee0d5a474c96306->get_row();
	$Fee0d5a474c96306->close_mysql();

	if (!empty(XUI::$rRequest['segment'])) {
	} else {
		$a9b7f153dce9637a = array();
		$e2f848a82a80c113 = ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . date('Y-m-d:H-i', $e0d8bd4d04af5371) . '.ts';

		if (!(empty($F26087d31c2bbe4d) || empty($e0d8bd4d04af5371) || empty($C5034884ed44603a))) {
		} else {
			Db709eD65ae02245();
		}

		if (file_exists($e2f848a82a80c113) && is_readable($e2f848a82a80c113)) {
		} else {
			db709eD65AE02245();
		}

		$a9b7f153dce9637a = array();
		$Ea22c4a9ab5b2176 = 0;

		while ($Ea22c4a9ab5b2176 < $C5034884ed44603a) {
			$e2f848a82a80c113 = ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . date('Y-m-d:H-i', $e0d8bd4d04af5371 + $Ea22c4a9ab5b2176 * 60) . '.ts';

			if (!file_exists($e2f848a82a80c113)) {
			} else {
				$a9b7f153dce9637a[] = array('filename' => $e2f848a82a80c113, 'filesize' => filesize($e2f848a82a80c113));
			}

			$Ea22c4a9ab5b2176++;
		}

		if (count($a9b7f153dce9637a) != 0) {
		} else {
			dB709eD65Ae02245();
		}
	}

	switch ($F9452a7efafa1aba) {
		case 'm3u8':
			if (empty(XUI::$rRequest['segment'])) {
				$f433193a3297ffde = '#EXTM3U' . "\n";
				$f433193a3297ffde .= '#EXT-X-VERSION:3' . "\n";
				$f433193a3297ffde .= '#EXT-X-TARGETDURATION:60' . "\n";
				$f433193a3297ffde .= '#EXT-X-MEDIA-SEQUENCE:0' . "\n";
				$f433193a3297ffde .= '#EXT-X-PLAYLIST-TYPE:VOD' . "\n";

				foreach ($a9b7f153dce9637a as $D3fa098be3f297cd => $bb2621204e39e62d) {
					$f433193a3297ffde .= '#EXTINF:60.0,' . "\n";

					if (!empty(XUI::$rRequest['uitoken'])) {
						$f433193a3297ffde .= '/admin/timeshift?extension=m3u8&segment=' . basename($bb2621204e39e62d['filename']) . '&uitoken=' . XUI::$rRequest['uitoken'] . "\n";
					} else {
						$f433193a3297ffde .= '/admin/timeshift?extension=m3u8&stream=' . $F26087d31c2bbe4d . '&segment=' . basename($bb2621204e39e62d['filename']) . '&password=' . $d5249dad8e8411b7 . "\n";
					}
				}
				$f433193a3297ffde .= '#EXT-X-ENDLIST';
				ob_end_clean();
				header('Content-Type: application/x-mpegurl');
				header('Content-Length: ' . strlen($f433193a3297ffde));
				echo $f433193a3297ffde;

				exit();
			} else {
				$d55bf693d0ece21c = ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . str_replace(array('\\', '/'), '', urldecode(XUI::$rRequest['segment']));

				if (file_exists($d55bf693d0ece21c)) {
					$B1e64f338fac8781 = filesize($d55bf693d0ece21c);
					header('Content-Length: ' . $B1e64f338fac8781);
					header('Content-Type: video/mp2t');
					readfile($d55bf693d0ece21c);
				} else {
					Db709ed65ae02245();
				}
			}

				break;

		case 'ts':
			header('Content-Type: video/mp2t');
			$f0434521ea9d1547 = $b6c1b012e942c0b8 = getlength($a9b7f153dce9637a);
			header('Accept-Ranges: 0-' . $f0434521ea9d1547);
			$D031c48a1422c07e = 0;
			$ae0b1e2a40cbc62a = $b6c1b012e942c0b8 - 1;

			if (!isset($_SERVER['HTTP_RANGE'])) {
			} else {
				$f52aa5b1fe06dc56 = $D031c48a1422c07e;
				$e151114d7468d71c = $ae0b1e2a40cbc62a;
				list(, $c049b11cb92e6052) = explode('=', $_SERVER['HTTP_RANGE'], 2);

				if (strpos($c049b11cb92e6052, ',') === false) {
					if ($c049b11cb92e6052 == '-') {
						$f52aa5b1fe06dc56 = $b6c1b012e942c0b8 - substr($c049b11cb92e6052, 1);
					} else {
						$c049b11cb92e6052 = explode('-', $c049b11cb92e6052);
						$f52aa5b1fe06dc56 = $c049b11cb92e6052[0];
						$e151114d7468d71c = (isset($c049b11cb92e6052[1]) && is_numeric($c049b11cb92e6052[1]) ? $c049b11cb92e6052[1] : $b6c1b012e942c0b8);
					}

					$e151114d7468d71c = ($ae0b1e2a40cbc62a < $e151114d7468d71c ? $ae0b1e2a40cbc62a : $e151114d7468d71c);

					if (!($e151114d7468d71c < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 - 1 < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 <= $e151114d7468d71c)) {
						$D031c48a1422c07e = $f52aa5b1fe06dc56;
						$ae0b1e2a40cbc62a = $e151114d7468d71c;
						$f0434521ea9d1547 = $ae0b1e2a40cbc62a - $D031c48a1422c07e + 1;
						header('HTTP/1.1 206 Partial Content');
					} else {
						header('HTTP/1.1 416 Requested Range Not Satisfiable');
						header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

						exit();
					}
				} else {
					header('HTTP/1.1 416 Requested Range Not Satisfiable');
					header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

					exit();
				}
			}

			header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);
			header('Content-Length: ' . $f0434521ea9d1547);
			$D8be9e037fb79e63 = 0;

			if (0 >= $D031c48a1422c07e) {
			} else {
				$D8be9e037fb79e63 = floor($D031c48a1422c07e / ($b6c1b012e942c0b8 / count($a9b7f153dce9637a)));
			}

			$A3b0fac4071c183f = false;
			$fa03594b77e16dca = 0;
			$e18610440a2e11c3 = 0;
			$b9f3f039ea3bf5ca = XUI::$rSettings['read_buffer_size'];

			foreach ($a9b7f153dce9637a as $D3fa098be3f297cd => $bb2621204e39e62d) {
				$e18610440a2e11c3 += $bb2621204e39e62d['filesize'];

				if ($A3b0fac4071c183f || 0 >= $D8be9e037fb79e63) {
				} else {
					if ($D3fa098be3f297cd < $D8be9e037fb79e63) {
					} else {
						$A3b0fac4071c183f = true;
						$fa03594b77e16dca = $D031c48a1422c07e - $e18610440a2e11c3;
					}
				}

				$e1644d67f855686d = fopen($bb2621204e39e62d['filename'], 'rb');
				fseek($e1644d67f855686d, $fa03594b77e16dca);

				while (!feof($e1644d67f855686d)) {
					$Dfa7f7fd6a9f18a8 = ftell($e1644d67f855686d);
					$c7488e8420e934e2 = stream_get_line($e1644d67f855686d, $b9f3f039ea3bf5ca);
					echo $c7488e8420e934e2;
				}

				if (!is_resource($e1644d67f855686d)) {
				} else {
					fclose($e1644d67f855686d);
				}

				$fa03594b77e16dca = 0;
			}

			break;
	}
} else {
	DB709ed65Ae02245();
}

function getLength($a9b7f153dce9637a)
{
	$f0434521ea9d1547 = 0;

	foreach ($a9b7f153dce9637a as $D45382ad8061de32) {
		$f0434521ea9d1547 += $D45382ad8061de32['filesize'];
	}

	return $f0434521ea9d1547;
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
