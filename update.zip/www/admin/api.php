<?php

register_shutdown_function('shutdown');
set_time_limit(0);
require '../init.php';
$c59ec257c284c894 = XUI::A9bc416FA6Fa55C3();

if (in_array($c59ec257c284c894, XUI::C5931Cd0269D0a3d()) || in_array($c59ec257c284c894, XUI::$rSettings['api_ips'])) {
} else {
	db709Ed65aE02245();
}

if (empty(XUI::$rSettings['api_pass']) || XUI::$rRequest['api_pass'] == XUI::$rSettings['api_pass']) {
} else {
	db709ED65AE02245();
}

$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
XUI::$db = &$Fee0d5a474c96306;
$fa7da6c202358e0c = (!empty(XUI::$rRequest['action']) ? XUI::$rRequest['action'] : '');
$c9e6a5e338f9246b = (!empty(XUI::$rRequest['sub']) ? XUI::$rRequest['sub'] : '');

switch ($fa7da6c202358e0c) {
	case 'server':
		switch ($c9e6a5e338f9246b) {
			case 'list':
				$f433193a3297ffde = array();

				foreach (XUI::$rServers as $d58b4f8653a391d8 => $cc5f26dd881329b7) {
					$f433193a3297ffde[] = array('id' => $d58b4f8653a391d8, 'server_name' => $cc5f26dd881329b7['server_name'], 'online' => $cc5f26dd881329b7['server_online'], 'info' => json_decode($cc5f26dd881329b7['server_hardware'], true));
				}
				echo json_encode($f433193a3297ffde);

				break;
		}

		break;

	case 'vod':
		switch ($c9e6a5e338f9246b) {
			case 'start':
				$Cdb85875fd50f459 = array_map('intval', XUI::$rRequest['stream_ids']);
				$b91591a6218018bb = (XUI::$rRequest['force'] ?: false);
				$a8bb73cba48fb7f6 = (empty(XUI::$rRequest['servers']) ? array_keys(XUI::$rServers) : array_map('intval', XUI::$rRequest['servers']));
				$ce2460e0c52a99da = array();

				foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
					$ce2460e0c52a99da[$d58b4f8653a391d8] = array('url' => XUI::$rServers[$d58b4f8653a391d8]['api_url_ip'] . '&action=vod', 'postdata' => array('function' => $c9e6a5e338f9246b, 'stream_ids' => $Cdb85875fd50f459, 'force' => $b91591a6218018bb));
				}
				XUI::efB9e3C68A59b340($ce2460e0c52a99da);
				echo json_encode(array('result' => true));

				exit();

			case 'stop':
				$Cdb85875fd50f459 = array_map('intval', XUI::$rRequest['stream_ids']);
				$a8bb73cba48fb7f6 = (empty(XUI::$rRequest['servers']) ? array_keys(XUI::$rServers) : array_map('intval', XUI::$rRequest['servers']));
				$ce2460e0c52a99da = array();

				foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
					$ce2460e0c52a99da[$d58b4f8653a391d8] = array('url' => XUI::$rServers[$d58b4f8653a391d8]['api_url_ip'] . '&action=vod', 'postdata' => array('function' => $c9e6a5e338f9246b, 'stream_ids' => $Cdb85875fd50f459));
				}
				XUI::EFB9E3c68a59B340($ce2460e0c52a99da);
				echo json_encode(array('result' => true));

				exit();
		}

		break;

	case 'stream':
		switch ($c9e6a5e338f9246b) {
			case 'start':
				$Cdb85875fd50f459 = array_map('intval', XUI::$rRequest['stream_ids']);
				$a8bb73cba48fb7f6 = (empty(XUI::$rRequest['servers']) ? array_keys(XUI::$rServers) : array_map('intval', XUI::$rRequest['servers']));
				$ce2460e0c52a99da = array();

				foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
					$ce2460e0c52a99da[$d58b4f8653a391d8] = array('url' => XUI::$rServers[$d58b4f8653a391d8]['api_url_ip'] . '&action=stream', 'postdata' => array('function' => $c9e6a5e338f9246b, 'stream_ids' => $Cdb85875fd50f459));
				}
				XUI::efb9e3c68A59B340($ce2460e0c52a99da);
				echo json_encode(array('result' => true));

				exit();

			case 'stop':
				$Cdb85875fd50f459 = array_map('intval', XUI::$rRequest['stream_ids']);
				$a8bb73cba48fb7f6 = (empty(XUI::$rRequest['servers']) ? array_keys(XUI::$rServers) : array_map('intval', XUI::$rRequest['servers']));
				$ce2460e0c52a99da = array();

				foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8) {
					$ce2460e0c52a99da[$d58b4f8653a391d8] = array('url' => XUI::$rServers[$d58b4f8653a391d8]['api_url_ip'] . '&action=stream', 'postdata' => array('function' => $c9e6a5e338f9246b, 'stream_ids' => $Cdb85875fd50f459));
				}
				XUI::EFB9E3C68a59b340($ce2460e0c52a99da);
				echo json_encode(array('result' => true));

				exit();

			case 'list':
				$f433193a3297ffde = array();
				$Fee0d5a474c96306->query('SELECT id,stream_display_name FROM `streams` WHERE type <> 2');

				foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
					$f433193a3297ffde[] = array('id' => $C740da31596f24ef['id'], 'stream_name' => $C740da31596f24ef['stream_display_name']);
				}
				echo json_encode($f433193a3297ffde);

				break;

			case 'offline':
				$Fee0d5a474c96306->query('SELECT t1.stream_status,t1.server_id,t1.stream_id  FROM `streams_servers` t1 INNER JOIN `streams` t2 ON t2.id = t1.stream_id AND t2.type <> 2 WHERE t1.stream_status <> 0');
				$A2b85ede89f9df0c = $Fee0d5a474c96306->get_rows(true, 'stream_id', false, 'server_id');
				$f433193a3297ffde = array();

				foreach ($A2b85ede89f9df0c as $F26087d31c2bbe4d => $a8bb73cba48fb7f6) {
					$f433193a3297ffde[$F26087d31c2bbe4d] = array_keys($a8bb73cba48fb7f6);
				}
				echo json_encode($f433193a3297ffde);

				break;

			case 'online':
				$Fee0d5a474c96306->query('SELECT t1.stream_status,t1.server_id,t1.stream_id FROM `streams_servers` t1 INNER JOIN `streams` t2 ON t2.id = t1.stream_id AND t2.type <> 2 WHERE t1.pid > 0 AND t1.stream_status = 0');
				$A2b85ede89f9df0c = $Fee0d5a474c96306->get_rows(true, 'stream_id', false, 'server_id');
				$f433193a3297ffde = array();

				foreach ($A2b85ede89f9df0c as $F26087d31c2bbe4d => $a8bb73cba48fb7f6) {
					$f433193a3297ffde[$F26087d31c2bbe4d] = array_keys($a8bb73cba48fb7f6);
				}
				echo json_encode($f433193a3297ffde);

				break;
		}

		break;

	case 'line':
		switch ($c9e6a5e338f9246b) {
			case 'info':
				if (!empty(XUI::$rRequest['username']) && !empty(XUI::$rRequest['password'])) {
					$a71afc14d6cd090d = XUI::$rRequest['username'];
					$d5249dad8e8411b7 = XUI::$rRequest['password'];
					$D4253f9520627819 = XUI::d7cA435ac70e9A78(false, $a71afc14d6cd090d, $d5249dad8e8411b7, true, true);

					if (!empty($D4253f9520627819)) {
						echo json_encode(array('result' => true, 'user_info' => $D4253f9520627819));
					} else {
						echo json_encode(array('result' => false, 'error' => 'NOT EXISTS'));
					}
				} else {
					echo json_encode(array('result' => false, 'error' => 'PARAMETER ERROR (user/pass)'));
				}

				break;
		}

		break;

	case 'reg_user':
		switch ($c9e6a5e338f9246b) {
			case 'list':
				$Fee0d5a474c96306->query('SELECT id,username,credits,group_id,group_name,last_login,date_registered,email,ip,status FROM `users` t1 INNER JOIN `users_groups` t2 ON t1.member_group_id = t2.group_id');
				$c15d5b523e931f51 = $Fee0d5a474c96306->get_rows();
				echo json_encode($c15d5b523e931f51);

				break;
		}

		break;

	default:
		break;
}
function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
