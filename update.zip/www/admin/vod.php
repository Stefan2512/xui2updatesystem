<?php

register_shutdown_function('shutdown');
header('Access-Control-Allow-Origin: *');
set_time_limit(0);
require '../init.php';
$c59ec257c284c894 = XUI::A9bc416fa6Fa55C3();

if (!empty(XUI::$rRequest['uitoken'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['uitoken'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);
	XUI::$rRequest['stream'] = $F64d974c429d80be['stream_id'] . '.' . $F64d974c429d80be['container'];
	$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $F64d974c429d80be['ip']), 0, -1)) == implode('.', array_slice(explode('.', XUI::a9bc416Fa6fA55c3()), 0, -1)) : $F64d974c429d80be['ip'] == XUI::a9bC416fA6fa55C3());

	if ($F64d974c429d80be['expires'] >= time() && $ee7553b0caebc8c4) {
	} else {
		DB709Ed65AE02245();
	}
} else {
	if (!in_array($c59ec257c284c894, XUI::c5931Cd0269d0a3D())) {
		DB709Ed65aE02245();
	} else {
		if (!(empty(XUI::$rRequest['password']) || XUI::$rSettings['live_streaming_pass'] != XUI::$rRequest['password'])) {
		} else {
			db709eD65Ae02245();
		}
	}
}

if (!empty(XUI::$rRequest['stream'])) {
} else {
	Db709ed65Ae02245();
}

$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
XUI::$db = &$Fee0d5a474c96306;
$f523e362fb81d6c8 = pathinfo(XUI::$rRequest['stream']);
$F26087d31c2bbe4d = intval($f523e362fb81d6c8['filename']);
$F9452a7efafa1aba = $f523e362fb81d6c8['extension'];
$Fee0d5a474c96306->query("SELECT t1.* FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.pid IS NOT NULL AND t2.server_id = ? INNER JOIN `streams_types` t3 ON t3.type_id = t1.type AND t3.type_key IN ('movie', 'series') WHERE t1.`id` = ?", SERVER_ID, $F26087d31c2bbe4d);

if (XUI::$rSettings['use_buffer'] != 0) {
} else {
	header('X-Accel-Buffering: no');
}

if (0 >= $Fee0d5a474c96306->num_rows()) {
} else {
	$Eea1b980ebbe2a33 = $Fee0d5a474c96306->get_row();
	$Fee0d5a474c96306->close_mysql();
	$F7b9e954f715ab5e = VOD_PATH . $F26087d31c2bbe4d . '.' . $F9452a7efafa1aba;

	if (!file_exists($F7b9e954f715ab5e)) {
	} else {
		switch ($Eea1b980ebbe2a33['target_container']) {
			case 'mp4':
				header('Content-type: video/mp4');

				break;

			case 'mkv':
				header('Content-type: video/x-matroska');

				break;

			case 'avi':
				header('Content-type: video/x-msvideo');

				break;

			case '3gp':
				header('Content-type: video/3gpp');

				break;

			case 'flv':
				header('Content-type: video/x-flv');

				break;

			case 'wmv':
				header('Content-type: video/x-ms-wmv');

				break;

			case 'mov':
				header('Content-type: video/quicktime');

				break;

			case 'ts':
				header('Content-type: video/mp2t');

				break;

			default:
				header('Content-Type: application/octet-stream');
		}
		$e2f848a82a80c113 = @fopen($F7b9e954f715ab5e, 'rb');
		$b6c1b012e942c0b8 = filesize($F7b9e954f715ab5e);
		$f0434521ea9d1547 = $b6c1b012e942c0b8;
		$D031c48a1422c07e = 0;
		$ae0b1e2a40cbc62a = $b6c1b012e942c0b8 - 1;
		header('Accept-Ranges: 0-' . $f0434521ea9d1547);

		if (!isset($_SERVER['HTTP_RANGE'])) {
		} else {
			$f52aa5b1fe06dc56 = $D031c48a1422c07e;
			$e151114d7468d71c = $ae0b1e2a40cbc62a;
			list(, $a01518a8cbe0506b) = explode('=', $_SERVER['HTTP_RANGE'], 2);

			if (strpos($a01518a8cbe0506b, ',') === false) {
				if ($a01518a8cbe0506b == '-') {
					$f52aa5b1fe06dc56 = $b6c1b012e942c0b8 - substr($a01518a8cbe0506b, 1);
				} else {
					$a01518a8cbe0506b = explode('-', $a01518a8cbe0506b);
					$f52aa5b1fe06dc56 = $a01518a8cbe0506b[0];
					$e151114d7468d71c = (isset($a01518a8cbe0506b[1]) && is_numeric($a01518a8cbe0506b[1]) ? $a01518a8cbe0506b[1] : $b6c1b012e942c0b8);
				}

				$e151114d7468d71c = ($ae0b1e2a40cbc62a < $e151114d7468d71c ? $ae0b1e2a40cbc62a : $e151114d7468d71c);

				if (!($e151114d7468d71c < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 - 1 < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 <= $e151114d7468d71c)) {
					$D031c48a1422c07e = $f52aa5b1fe06dc56;
					$ae0b1e2a40cbc62a = $e151114d7468d71c;
					$f0434521ea9d1547 = $ae0b1e2a40cbc62a - $D031c48a1422c07e + 1;
					fseek($e2f848a82a80c113, $D031c48a1422c07e);
					header('HTTP/1.1 206 Partial Content');
				} else {
					header('HTTP/1.1 416 Requested Range Not Satisfiable');
					header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

					exit();
				}
			} else {
				header('HTTP/1.1 416 Requested Range Not Satisfiable');
				header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

				exit();
			}
		}

		header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);
		header('Content-Length: ' . $f0434521ea9d1547);
		$b9f3f039ea3bf5ca = 8192;

		while (!feof($e2f848a82a80c113) && ($c5f42eb7bf40a43a = ftell($e2f848a82a80c113)) <= $ae0b1e2a40cbc62a) {
			$c7488e8420e934e2 = stream_get_line($e2f848a82a80c113, $b9f3f039ea3bf5ca);
			echo $c7488e8420e934e2;
		}
		fclose($e2f848a82a80c113);

		exit();
	}
}

function shutdown()
{
	global $Fee0d5a474c96306;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
