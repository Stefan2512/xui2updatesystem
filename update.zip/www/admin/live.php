<?php

register_shutdown_function('shutdown');
header('Access-Control-Allow-Origin: *');
set_time_limit(0);
require '../init.php';
$c59ec257c284c894 = XUI::A9BC416fa6fa55c3();
$f9b07d216a168dcc = getmypid();

if (XUI::$rSettings['use_buffer'] != 0) {
} else {
	header('X-Accel-Buffering: no');
}

if (!empty(XUI::$rRequest['uitoken'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['uitoken'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);
	XUI::$rRequest['stream'] = $F64d974c429d80be['stream_id'];
	XUI::$rRequest['extension'] = 'm3u8';
	$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $F64d974c429d80be['ip']), 0, -1)) == implode('.', array_slice(explode('.', XUI::A9BC416FA6fa55C3()), 0, -1)) : $F64d974c429d80be['ip'] == XUI::a9BC416Fa6fa55c3());

	if ($F64d974c429d80be['expires'] >= time() && $ee7553b0caebc8c4) {
	} else {
		DB709eD65ae02245();
	}

	$e1034511e63f0e9e = XUI::$rSegmentSettings['seg_time'];
} else {
	if (empty(XUI::$rRequest['password']) || XUI::$rSettings['live_streaming_pass'] != XUI::$rRequest['password']) {
		db709ED65ae02245();
	} else {
		if (!in_array($c59ec257c284c894, XUI::c5931Cd0269d0a3d())) {
			Db709eD65ae02245();
		} else {
			$e1034511e63f0e9e = (isset(XUI::$rRequest['prebuffer']) ? XUI::$rSegmentSettings['seg_time'] : 0);

			foreach (getallheaders() as $D3fa098be3f297cd => $b6842cb20051e925) {
				if (strtoupper($D3fa098be3f297cd) != 'X-XUI-PREBUFFER') {
				} else {
					$e1034511e63f0e9e = XUI::$rSegmentSettings['seg_time'];
				}
			}
		}
	}
}

$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
XUI::$db = &$Fee0d5a474c96306;
$d5249dad8e8411b7 = XUI::$rSettings['live_streaming_pass'];
$F26087d31c2bbe4d = intval(XUI::$rRequest['stream']);
$F9452a7efafa1aba = XUI::$rRequest['extension'];
$Eacc1d801b71027a = 20;
$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.server_id = ? WHERE t1.`id` = ?', SERVER_ID, $F26087d31c2bbe4d);

if (0 < $Fee0d5a474c96306->num_rows()) {
	touch(SIGNALS_TMP_PATH . 'admin_' . intval($F26087d31c2bbe4d));
	$fca7edf85daa1695 = $Fee0d5a474c96306->get_row();
	$Fee0d5a474c96306->close_mysql();

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
	} else {
		$fca7edf85daa1695['pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
	}

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
	} else {
		$fca7edf85daa1695['monitor_pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
	}

	if (!(XUI::$rSettings['on_demand_instant_off'] && $fca7edf85daa1695['on_demand'] == 1)) {
	} else {
		XUI::A2aa2B94d2D97A7F($F26087d31c2bbe4d, $f9b07d216a168dcc);
	}

	if (XUI::F74Fa4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
	} else {
		$fca7edf85daa1695['pid'] = null;

		if ($fca7edf85daa1695['on_demand'] == 1) {
			if (XUI::EA4A2063e98BAEF8($fca7edf85daa1695['monitor_pid'], $F26087d31c2bbe4d)) {
			} else {
				XUI::dAC4d82F05378662($F26087d31c2bbe4d);

				for ($B9cc3064fe62da37 = 0; !file_exists(STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.monitor') && $B9cc3064fe62da37 < 300; $B9cc3064fe62da37++) {
					usleep(10000);
				}
				$fca7edf85daa1695['monitor_pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
			}
		} else {
			db709ed65aE02245();
		}
	}

	$B9cc3064fe62da37 = 0;
	$bb62005ea7eb8380 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8';

	if ($F9452a7efafa1aba == 'ts') {
		if (file_exists($bb62005ea7eb8380)) {
		} else {
			$Cd8fd79b62884002 = STREAMS_PATH . $F26087d31c2bbe4d . '_0.ts';
			$e1644d67f855686d = null;

			while ($B9cc3064fe62da37 < intval($Eacc1d801b71027a) * 100) {
				if (!file_exists($Cd8fd79b62884002) || $e1644d67f855686d) {
				} else {
					$e1644d67f855686d = fopen($Cd8fd79b62884002, 'r');
				}

				if (!($e1644d67f855686d && fread($e1644d67f855686d, 1))) {
					usleep(10000);
					$B9cc3064fe62da37++;

					break;
				}
			}

			if (!$e1644d67f855686d) {
			} else {
				fclose($e1644d67f855686d);
			}
		}
	} else {
		$Cd8fd79b62884002 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8';

		while (!file_exists($bb62005ea7eb8380) && !file_exists($Cd8fd79b62884002) && $B9cc3064fe62da37 < intval($Eacc1d801b71027a) * 100) {
			usleep(10000);
			$B9cc3064fe62da37++;
		}
	}

	if ($B9cc3064fe62da37 == intval($Eacc1d801b71027a) * 10) {
		if (isset(XUI::$rRequest['odstart'])) {
			echo '0';

			exit();
		}

		Db709ED65aE02245();
	} else {
		if (!isset(XUI::$rRequest['odstart'])) {
		} else {
			echo '1';

			exit();
		}
	}

	if ($fca7edf85daa1695['pid']) {
	} else {
		$fca7edf85daa1695['pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
	}

	switch ($F9452a7efafa1aba) {
		case 'm3u8':
			if (!XUI::a82b635b748c0318($bb62005ea7eb8380, $fca7edf85daa1695['pid'])) {
			} else {
				if (empty(XUI::$rRequest['segment'])) {
					if (!($c8d91fcd2309e48a = XUI::f116d0b6a51d41cF($bb62005ea7eb8380, $d5249dad8e8411b7, $F26087d31c2bbe4d, XUI::$rRequest['uitoken']))) {
					} else {
						header('Content-Type: application/vnd.apple.mpegurl');
						header('Content-Length: ' . strlen($c8d91fcd2309e48a));
						ob_end_flush();
						echo $c8d91fcd2309e48a;

						exit();
					}
				} else {
					$d55bf693d0ece21c = STREAMS_PATH . str_replace(array('\\', '/'), '', urldecode(XUI::$rRequest['segment']));

					if (!file_exists($d55bf693d0ece21c)) {
					} else {
						$B1e64f338fac8781 = filesize($d55bf693d0ece21c);
						header('Content-Length: ' . $B1e64f338fac8781);
						header('Content-Type: video/mp2t');
						readfile($d55bf693d0ece21c);

						exit();
					}
				}
			}

			break;

		default:
			header('Content-Type: video/mp2t');

			if (file_exists($bb62005ea7eb8380)) {
				if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur')) {
				} else {
					$C5034884ed44603a = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur'));

					if (XUI::$rSegmentSettings['seg_time'] >= $C5034884ed44603a) {
					} else {
						XUI::$rSegmentSettings['seg_time'] = $C5034884ed44603a;
					}
				}

				$Bffc17a99eb14fd6 = XUI::d076F5a2CC104C49($bb62005ea7eb8380, $e1034511e63f0e9e, XUI::$rSegmentSettings['seg_time']);
			} else {
				$Bffc17a99eb14fd6 = null;
			}

			if (!is_null($Bffc17a99eb14fd6)) {
				if (is_array($Bffc17a99eb14fd6)) {
					$B1e64f338fac8781 = 0;
					$a859a0996bb0f1ff = time();

					foreach ($Bffc17a99eb14fd6 as $d55bf693d0ece21c) {
						if (file_exists(STREAMS_PATH . $d55bf693d0ece21c)) {
							$B1e64f338fac8781 += readfile(STREAMS_PATH . $d55bf693d0ece21c);
						} else {
							exit();
						}
					}
					preg_match('/_(.*)\\./', array_pop($Bffc17a99eb14fd6), $E415df512cb68430);
					$ce8f0c719e170c50 = $E415df512cb68430[1];
				} else {
					$ce8f0c719e170c50 = $Bffc17a99eb14fd6;
				}
			} else {
				if (!file_exists($bb62005ea7eb8380)) {
					$ce8f0c719e170c50 = -1;
				} else {
					exit();
				}
			}

			$d5e40c7f6fdf5643 = 0;
			$bce4fc6e727309d8 = XUI::$rSegmentSettings['seg_time'] * 2;

			if (!(($bce4fc6e727309d8 < intval(XUI::$rSettings['segment_wait_time']) ?: 20))) {
			} else {
				$bce4fc6e727309d8 = (intval(XUI::$rSettings['segment_wait_time']) ?: 20);
			}

			if (true) {
				$E8601dd191bcdbba = sprintf('%d_%d.ts', $F26087d31c2bbe4d, $ce8f0c719e170c50 + 1);
				$E4c630709fd1c356 = sprintf('%d_%d.ts', $F26087d31c2bbe4d, $ce8f0c719e170c50 + 2);
				$Aae09861fbc788ec = 0;

				while (!file_exists(STREAMS_PATH . $E8601dd191bcdbba) && $Aae09861fbc788ec <= $bce4fc6e727309d8 * 10) {
					usleep(100000);
					$Aae09861fbc788ec++;
				}

				if (file_exists(STREAMS_PATH . $E8601dd191bcdbba)) {
					if (!(empty($fca7edf85daa1695['pid']) && file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'))) {
					} else {
						$fca7edf85daa1695['pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
					}

					$d5e40c7f6fdf5643 = 0;
					$B03be4d52f9e9b56 = time();
					$e1644d67f855686d = fopen(STREAMS_PATH . $E8601dd191bcdbba, 'r');

					while ($d5e40c7f6fdf5643 <= $bce4fc6e727309d8 && !file_exists(STREAMS_PATH . $E4c630709fd1c356)) {
						$a27e64cc6ce01033 = stream_get_line($e1644d67f855686d, XUI::$rSettings['read_buffer_size']);

						if (!empty($a27e64cc6ce01033)) {
							echo $a27e64cc6ce01033;
							$a27e64cc6ce01033 = '';
							$d5e40c7f6fdf5643 = 0;

							break;
						}

						if (XUI::F74fA4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
							sleep(1);
							$d5e40c7f6fdf5643++;
						}
					}

					if (XUI::f74fa4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d) && $d5e40c7f6fdf5643 <= $bce4fc6e727309d8 && file_exists(STREAMS_PATH . $E8601dd191bcdbba) && is_resource($e1644d67f855686d)) {
						$da9e8cb22ec468a6 = filesize(STREAMS_PATH . $E8601dd191bcdbba);
					} else {
						exit();
					}
				} else {
					exit();
				}
			}
	}
	$E4e6bf32b967d5f2 = $da9e8cb22ec468a6 - ftell($e1644d67f855686d);

	if (0 >= $E4e6bf32b967d5f2) {
	} else {
		echo stream_get_line($e1644d67f855686d, $E4e6bf32b967d5f2);
	}

	fclose($e1644d67f855686d);
	$d5e40c7f6fdf5643 = 0;
	$ce8f0c719e170c50++;
} else {
	dB709Ed65Ae02245();
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $fca7edf85daa1695;
	global $f9b07d216a168dcc;
	global $F26087d31c2bbe4d;

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}

	if (!(XUI::$rSettings['on_demand_instant_off'] && $fca7edf85daa1695['on_demand'] == 1)) {
	} else {
		XUI::cA490cE3385C630E($F26087d31c2bbe4d, $f9b07d216a168dcc);
	}
}
