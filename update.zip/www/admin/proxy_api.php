<?php

set_time_limit(0);
require '../init.php';
$fc8236a28ea7ebdd = array();

if (XUI::Bb41388445081A3d($_SERVER['REMOTE_ADDR'])) {
	$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
	XUI::$db = &$Fee0d5a474c96306;
	$d58b4f8653a391d8 = intval($_POST['server_id']);
	$e19876d9ba369ed1 = $_POST['stats'];
	$Fee0d5a474c96306->query('SELECT `bytes_sent_total`, `bytes_received_total`, `time` FROM `servers_stats` WHERE `server_id` = ? ORDER BY `id` DESC LIMIT 1;', $d58b4f8653a391d8);

	if ($Fee0d5a474c96306->num_rows() != 1) {
	} else {
		$C740da31596f24ef = $Fee0d5a474c96306->get_row();
		$b47a0fb491dcc3cc = time() - $C740da31596f24ef['time'];
		$e19876d9ba369ed1['bytes_sent'] = ($e19876d9ba369ed1['bytes_sent_total'] - $C740da31596f24ef['bytes_sent_total']) / $b47a0fb491dcc3cc;
		$e19876d9ba369ed1['bytes_received'] = ($e19876d9ba369ed1['bytes_received_total'] - $C740da31596f24ef['bytes_received_total']) / $b47a0fb491dcc3cc;
	}

	$Cec7eb8a067db8d7 = $_POST['addresses'];
	$bcb3f47290b55c82 = array('total_ram' => $e19876d9ba369ed1['total_mem'], 'total_used' => $e19876d9ba369ed1['total_mem_used'], 'cores' => $e19876d9ba369ed1['cpu_cores'], 'threads' => $e19876d9ba369ed1['cpu_cores'], 'kernel' => $e19876d9ba369ed1['kernel'], 'total_running_streams' => $e19876d9ba369ed1['total_running_streams'], 'cpu_name' => $e19876d9ba369ed1['cpu_name'], 'cpu_usage' => $e19876d9ba369ed1['cpu'], 'network_speed' => $e19876d9ba369ed1['network_speed'], 'bytes_sent' => $e19876d9ba369ed1['bytes_sent'], 'bytes_received' => $e19876d9ba369ed1['bytes_received']);
	$b04df0592474c247 = (pingserver($a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_ip'], $a8bb73cba48fb7f6[$d58b4f8653a391d8]['http_broadcast_port']) ?: 0);

	if ($b04df0592474c247 >= 0) {
	} else {
		$b04df0592474c247 = 0;
	}

	if (XUI::$rSettings['redis_handler']) {
		$A90d77181715e38e = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['connections'];
		$B963b5d49ca08acf = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['users'];
		$dea226c73020272f = 0;

		foreach (array_keys($a8bb73cba48fb7f6) as $d58b4f8653a391d8) {
			if (!$a8bb73cba48fb7f6[$d58b4f8653a391d8]['server_online']) {
			} else {
				$dea226c73020272f += $a8bb73cba48fb7f6[$d58b4f8653a391d8]['users'];
			}
		}
	} else {
		$Fee0d5a474c96306->query('SELECT COUNT(*) AS `count` FROM `lines_live` WHERE `proxy_id` = ? AND `hls_end` = 0;', $d58b4f8653a391d8);
		$A90d77181715e38e = intval($Fee0d5a474c96306->get_row()['count']);
		$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `proxy_id` = ? AND `hls_end` = 0 GROUP BY `user_id`;', $d58b4f8653a391d8);
		$B963b5d49ca08acf = intval($Fee0d5a474c96306->num_rows());
		$Fee0d5a474c96306->query('SELECT `activity_id` FROM `lines_live` WHERE `hls_end` = 0 GROUP BY `user_id`;');
		$dea226c73020272f = intval($Fee0d5a474c96306->num_rows());
	}

	$Fee0d5a474c96306->query('INSERT INTO `servers_stats`(`server_id`, `cpu`, `cpu_cores`, `cpu_avg`, `total_mem`, `total_mem_free`, `total_mem_used`, `total_mem_used_percent`, `total_disk_space`, `uptime`, `total_running_streams`, `bytes_sent`, `bytes_received`, `bytes_sent_total`, `bytes_received_total`, `cpu_load_average`, `connections`, `total_users`, `users`, `time`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);', $d58b4f8653a391d8, $e19876d9ba369ed1['cpu'], $e19876d9ba369ed1['cpu_cores'], $e19876d9ba369ed1['cpu_avg'], $e19876d9ba369ed1['total_mem'], $e19876d9ba369ed1['total_mem_free'], $e19876d9ba369ed1['total_mem_used'], $e19876d9ba369ed1['total_mem_used_percent'], $e19876d9ba369ed1['total_disk_space'], $e19876d9ba369ed1['uptime'], $e19876d9ba369ed1['total_running_streams'], $e19876d9ba369ed1['bytes_sent'], $e19876d9ba369ed1['bytes_received'], $e19876d9ba369ed1['bytes_sent_total'], $e19876d9ba369ed1['bytes_received_total'], $e19876d9ba369ed1['cpu_load_average'], $A90d77181715e38e, $dea226c73020272f, $B963b5d49ca08acf, time());
	$Fee0d5a474c96306->query('UPDATE `servers` SET `connections` = ?, `users` = ?, `ping` = ?,`server_hardware` = ?,`whitelist_ips` = ?, `interfaces` = ?, `watchdog_data` = ?, `last_check_ago` = ? WHERE `id` = ?', $A90d77181715e38e, $B963b5d49ca08acf, $b04df0592474c247, json_encode($bcb3f47290b55c82), json_encode($Cec7eb8a067db8d7), json_encode($e19876d9ba369ed1['interfaces']), json_encode($e19876d9ba369ed1, JSON_PARTIAL_OUTPUT_ON_ERROR), time(), $d58b4f8653a391d8);

	if ($Fee0d5a474c96306->query("SELECT `signal_id`, `custom_data` FROM `signals` WHERE `server_id` = ? AND `custom_data` <> '' ORDER BY signal_id ASC;", $d58b4f8653a391d8)) {
		if (0 >= $Fee0d5a474c96306->num_rows()) {
		} else {
			foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
				$a27e64cc6ce01033 = json_decode($C740da31596f24ef['custom_data'], true);
				$Fee0d5a474c96306->query('DELETE FROM `signals` WHERE `signal_id` = ?;', $C740da31596f24ef['signal_id']);
				$fc8236a28ea7ebdd[] = $a27e64cc6ce01033;
			}
		}

		echo json_encode($fc8236a28ea7ebdd);

		exit();
	}

	exit();
} else {
	db709eD65aE02245();
}

function pingServer($c59ec257c284c894, $b87b2986f8f49da8)
{
	$a859a0996bb0f1ff = microtime(true);
	$Cae0f755f512a801 = fsockopen($c59ec257c284c894, $b87b2986f8f49da8, $D260010af7683f8c, $d8a02b8a51820940, 3);
	$dbdef2481f1c1a6c = microtime(true);

	if (!$Cae0f755f512a801) {
		$Ba23222f3ed2dc08 = -1;
	} else {
		fclose($Cae0f755f512a801);
		$Ba23222f3ed2dc08 = floor(($dbdef2481f1c1a6c - $a859a0996bb0f1ff) * 1000);
	}

	return $Ba23222f3ed2dc08;
}
