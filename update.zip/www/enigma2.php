<?php

register_shutdown_function('shutdown');
require './init.php';
$Dab081f66facd7a3 = true;

if (!XUI::$rSettings['disable_enigma2']) {
} else {
	$Dab081f66facd7a3 = false;
	generateError('E2_DISABLED');
}

$a71afc14d6cd090d = XUI::$rRequest['username'];
$d5249dad8e8411b7 = XUI::$rRequest['password'];
$E379394c7b1a273f = (!empty(XUI::$rRequest['type']) ? XUI::$rRequest['type'] : null);
$a8d4f49e3337c3e5 = (!empty(XUI::$rRequest['cat_id']) ? intval(XUI::$rRequest['cat_id']) : null);
$b9fa93f8c1cd5ce3 = (!empty(XUI::$rRequest['scat_id']) ? intval(XUI::$rRequest['scat_id']) : null);
$A2d65843292b5c59 = (!empty(XUI::$rRequest['series_id']) ? intval(XUI::$rRequest['series_id']) : null);
$b550d8eef0f542ec = (!empty(XUI::$rRequest['season']) ? intval(XUI::$rRequest['season']) : null);
$C6033ec178efa2ae = (stripos($_SERVER['SERVER_PROTOCOL'], 'https') === 0 ? 'https://' : 'http://');
$C700a2b357e5ed65 = (!empty($_SERVER['HTTP_HOST']) ? $C6033ec178efa2ae . $_SERVER['HTTP_HOST'] . '/' : XUI::$rServers[SERVER_ID]['site_url']);
ini_set('memory_limit', -1);

if (!(empty($a71afc14d6cd090d) || empty($d5249dad8e8411b7))) {
} else {
	generateError('NO_CREDENTIALS');
}

if ($D4253f9520627819 = XUI::D7CA435ac70e9A78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, true, false)) {
	$Dab081f66facd7a3 = false;
	$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
	XUI::$db = &$Fee0d5a474c96306;
	XUI::d3E665b5427479FE($D4253f9520627819);
	$e6260d36d9fc675e = XUI::c7BabcBeC16C28ed('live');
	$c03c2f6cdc8a3820 = XUI::c7BaBcBEc16C28ed('movie');
	$f20ff2fe05992cec = XUI::c7BAbcbEc16c28eD('series');
	$D9476a2ebc0516a2 = array();
	$ef63f09fd8837a72 = array();

	if (XUI::$rCached) {
		$f46da30a01f7b2d7 = $D4253f9520627819['channel_ids'];
	} else {
		$f46da30a01f7b2d7 = array();

		if (0 >= count($D4253f9520627819['channel_ids'])) {
		} else {
			$Df2582e36fdd6160 = $f86e19bdb1e7dae8 = array();
			$f86e19bdb1e7dae8[] = '`id` IN (' . implode(',', $D4253f9520627819['channel_ids']) . ')';
			$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);
			$c6c389b9adf3a40c = 'FIELD(id,' . implode(',', $D4253f9520627819['channel_ids']) . ')';
			XUI::$db->query('SELECT t1.id,t1.epg_id,t1.added,t1.allow_record,t1.year,t1.channel_id,t1.movie_properties,t1.stream_source,t1.tv_archive_server_id,t1.vframes_server_id,t1.tv_archive_duration,t1.stream_icon,t1.custom_sid,t1.category_id,t1.stream_display_name,t1.series_no,t1.direct_source,t2.type_output,t1.target_container,t2.live,t1.rtmp_output,t1.order,t2.type_key FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type ' . $ff9d21c7a9d310b1 . ' ORDER BY ' . $c6c389b9adf3a40c . ';', ...$Df2582e36fdd6160);
			$f46da30a01f7b2d7 = XUI::$db->get_rows();
		}
	}

	$D4253f9520627819['channel_ids'] = XUI::e43cB741AA22A6D8($D4253f9520627819['channel_ids']);

	foreach ($f46da30a01f7b2d7 as $Fe753328765ad26c) {
		if (!XUI::$rCached) {
		} else {
			$Fe753328765ad26c = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($Fe753328765ad26c)))['info'];
		}

		if ($Fe753328765ad26c['live'] == 0) {
			$ef63f09fd8837a72[] = $Fe753328765ad26c;
		} else {
			$D9476a2ebc0516a2[] = $Fe753328765ad26c;
		}
	}
	unset($f46da30a01f7b2d7);

	switch ($E379394c7b1a273f) {
		case 'get_live_categories':
			$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
			$cd4d474fc2ee8031->addChild('playlist_name', 'Live [ ' . XUI::$rSettings['server_name'] . ' ]');
			$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
			$A1925ae53e9307eb->addChild('category_id', 1);
			$A1925ae53e9307eb->addChild('category_title', 'Live [ ' . XUI::$rSettings['server_name'] . ' ]');
			$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
			$f46da30a01f7b2d7->addChild('title', base64_encode('All'));
			$f46da30a01f7b2d7->addChild('description', base64_encode('Live Streams Category [ ALL ]'));
			$f46da30a01f7b2d7->addChild('category_id', 0);
			$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
			$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_live_streams&cat_id=0' . $A1925ae53e9307eb['id']);

			foreach ($e6260d36d9fc675e as $Be965cdd996d4520 => $A1925ae53e9307eb) {
				$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
				$f46da30a01f7b2d7->addChild('title', base64_encode($A1925ae53e9307eb['category_name']));
				$f46da30a01f7b2d7->addChild('description', base64_encode('Live Streams Category'));
				$f46da30a01f7b2d7->addChild('category_id', $A1925ae53e9307eb['id']);
				$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
				$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_live_streams&cat_id=' . $A1925ae53e9307eb['id']);
			}
			header('Content-Type: application/xml; charset=utf-8');
			echo $cd4d474fc2ee8031->asXML();

			break;

		case 'get_vod_categories':
			$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
			$cd4d474fc2ee8031->addChild('playlist_name', 'Movie [ ' . XUI::$rSettings['server_name'] . ' ]');
			$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
			$A1925ae53e9307eb->addChild('category_id', 1);
			$A1925ae53e9307eb->addChild('category_title', 'Movie [ ' . XUI::$rSettings['server_name'] . ' ]');
			$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
			$f46da30a01f7b2d7->addChild('title', base64_encode('All'));
			$f46da30a01f7b2d7->addChild('description', base64_encode('Movie Streams Category [ ALL ]'));
			$f46da30a01f7b2d7->addChild('category_id', 0);
			$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
			$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_vod_streams&cat_id=0' . $A1925ae53e9307eb['id']);

			foreach ($c03c2f6cdc8a3820 as $Cd9e74cd77b8005c => $A1925ae53e9307eb) {
				$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
				$f46da30a01f7b2d7->addChild('title', base64_encode($A1925ae53e9307eb['category_name']));
				$f46da30a01f7b2d7->addChild('description', base64_encode('Movie Streams Category'));
				$f46da30a01f7b2d7->addChild('category_id', $A1925ae53e9307eb['id']);
				$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
				$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_vod_streams&cat_id=' . $A1925ae53e9307eb['id']);
			}
			header('Content-Type: application/xml; charset=utf-8');
			echo $cd4d474fc2ee8031->asXML();

			break;

		case 'get_series_categories':
			$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
			$cd4d474fc2ee8031->addChild('playlist_name', 'SubCategory [ ' . XUI::$rSettings['server_name'] . ' ]');
			$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
			$A1925ae53e9307eb->addChild('category_id', 1);
			$A1925ae53e9307eb->addChild('category_title', 'SubCategory [ ' . XUI::$rSettings['server_name'] . ' ]');
			$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
			$f46da30a01f7b2d7->addChild('title', base64_encode('All'));
			$f46da30a01f7b2d7->addChild('description', base64_encode('TV Series Category [ ALL ]'));
			$f46da30a01f7b2d7->addChild('category_id', 0);
			$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
			$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_series&cat_id=0' . $A1925ae53e9307eb['id']);

			foreach ($f20ff2fe05992cec as $Cd9e74cd77b8005c => $A1925ae53e9307eb) {
				$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
				$f46da30a01f7b2d7->addChild('title', base64_encode($A1925ae53e9307eb['category_name']));
				$f46da30a01f7b2d7->addChild('description', base64_encode('TV Series Category'));
				$f46da30a01f7b2d7->addChild('category_id', $A1925ae53e9307eb['id']);
				$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
				$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_series&cat_id=' . $A1925ae53e9307eb['id']);
			}
			header('Content-Type: application/xml; charset=utf-8');
			echo $cd4d474fc2ee8031->asXML();

			break;

		case 'get_series':
			if (!(isset($a8d4f49e3337c3e5) || is_null($a8d4f49e3337c3e5) || isset($b9fa93f8c1cd5ce3) || is_null($b9fa93f8c1cd5ce3))) {
			} else {
				$Be965cdd996d4520 = (is_null($a8d4f49e3337c3e5) ? null : $a8d4f49e3337c3e5);

				if (!is_null($Be965cdd996d4520)) {
				} else {
					$Be965cdd996d4520 = (is_null($b9fa93f8c1cd5ce3) ? null : $b9fa93f8c1cd5ce3);
					$a8d4f49e3337c3e5 = $b9fa93f8c1cd5ce3;
				}

				$Ca57870f4d8a7b11 = (!empty($f20ff2fe05992cec[$a8d4f49e3337c3e5]) ? $f20ff2fe05992cec[$a8d4f49e3337c3e5]['category_name'] : 'ALL');
				$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
				$cd4d474fc2ee8031->addChild('playlist_name', 'TV Series [ ' . $Ca57870f4d8a7b11 . ' ]');
				$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
				$A1925ae53e9307eb->addChild('category_id', 1);
				$A1925ae53e9307eb->addChild('category_title', 'TV Series [ ' . $Ca57870f4d8a7b11 . ' ]');

				if (0 >= count($D4253f9520627819['series_ids'])) {
				} else {
					if (XUI::$rSettings['vod_sort_newest']) {
						$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` IN (' . implode(',', array_map('intval', $D4253f9520627819['series_ids'])) . ') ORDER BY `last_modified` DESC;');
					} else {
						$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` IN (' . implode(',', array_map('intval', $D4253f9520627819['series_ids'])) . ') ORDER BY FIELD(`id`,' . implode(',', $D4253f9520627819['series_ids']) . ') ASC;');
					}

					$bbc84f53c534450d = $Fee0d5a474c96306->get_rows(true, 'id');

					foreach ($bbc84f53c534450d as $A2d65843292b5c59 => $Be8acff8875eca91) {
						foreach (json_decode($Be8acff8875eca91['category_id'], true) as $B750c9b908ca927c) {
							if ($Be965cdd996d4520 && $Be965cdd996d4520 != $B750c9b908ca927c) {
							} else {
								$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
								$f46da30a01f7b2d7->addChild('title', base64_encode($Be8acff8875eca91['title']));
								$f46da30a01f7b2d7->addChild('description', '');
								$f46da30a01f7b2d7->addChild('category_id', $A2d65843292b5c59);
								$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
								$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_seasons&series_id=' . $A2d65843292b5c59);
							}

							if ($Be965cdd996d4520) {
							} else {
								break;
							}
						}
					}
				}

				header('Content-Type: application/xml; charset=utf-8');
				echo $cd4d474fc2ee8031->asXML();
			}

			break;

		case 'get_seasons':
			if (!isset($A2d65843292b5c59)) {
			} else {
				$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` = ?', $A2d65843292b5c59);
				$Be8acff8875eca91 = $Fee0d5a474c96306->get_row();
				$Ca57870f4d8a7b11 = $Be8acff8875eca91['title'];
				$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
				$cd4d474fc2ee8031->addChild('playlist_name', 'TV Series [ ' . $Ca57870f4d8a7b11 . ' ]');
				$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
				$A1925ae53e9307eb->addChild('category_id', 1);
				$A1925ae53e9307eb->addChild('category_title', 'TV Series [ ' . $Ca57870f4d8a7b11 . ' ]');
				$Fee0d5a474c96306->query('SELECT * FROM `streams_episodes` t1 INNER JOIN `streams` t2 ON t2.id=t1.stream_id WHERE t1.series_id = ? ORDER BY t1.season_num ASC, t1.episode_num ASC', $A2d65843292b5c59);
				$b3439582205053ea = $Fee0d5a474c96306->get_rows(true, 'season_num', false);

				foreach (array_keys($b3439582205053ea) as $A519b6e41bcb1b27) {
					$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
					$f46da30a01f7b2d7->addChild('title', base64_encode('Season ' . $A519b6e41bcb1b27));
					$f46da30a01f7b2d7->addChild('description', '');
					$f46da30a01f7b2d7->addChild('category_id', $A519b6e41bcb1b27);
					$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
					$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_series_streams&series_id=' . $A2d65843292b5c59 . '&season=' . $A519b6e41bcb1b27);
				}
				header('Content-Type: application/xml; charset=utf-8');
				echo $cd4d474fc2ee8031->asXML();
			}

			break;

		case 'get_series_streams':
			if (!(isset($A2d65843292b5c59) && isset($b550d8eef0f542ec))) {
			} else {
				$Fee0d5a474c96306->query('SELECT * FROM `streams_series` WHERE `id` = ?', $A2d65843292b5c59);
				$Be8acff8875eca91 = $Fee0d5a474c96306->get_row();
				$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
				$cd4d474fc2ee8031->addChild('playlist_name', 'TV Series [ ' . $Be8acff8875eca91['title'] . ' Season ' . $b550d8eef0f542ec . ' ]');
				$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
				$A1925ae53e9307eb->addChild('category_id', 1);
				$A1925ae53e9307eb->addChild('category_title', 'TV Series [ ' . $Be8acff8875eca91['title'] . ' Season ' . $b550d8eef0f542ec . ' ]');
				$Fee0d5a474c96306->query('SELECT t2.direct_source,t2.stream_source,t2.target_container,t2.id,t1.series_id,t1.season_num FROM `streams_episodes` t1 INNER JOIN `streams` t2 ON t2.id=t1.stream_id WHERE t1.series_id = ? AND t1.season_num = ? ORDER BY  t1.episode_num ASC', $A2d65843292b5c59, $b550d8eef0f542ec);
				$A9c7f0cd94ef2cf0 = $Fee0d5a474c96306->get_rows();
				$f47cdad37b8ee743 = 0;

				foreach ($A9c7f0cd94ef2cf0 as $Bd43537fab08ca31) {
					$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
					$f46da30a01f7b2d7->addChild('title', base64_encode('Episode ' . sprintf('%02d', ++$f47cdad37b8ee743)));
					$adc29d01cab8fb90 = '';
					$accc0f5f27231d0c = $f46da30a01f7b2d7->addChild('desc_image');
					$accc0f5f27231d0c->addCData(XUI::B8f3dEf724810918($Be8acff8875eca91['cover']));
					$f46da30a01f7b2d7->addChild('description', base64_encode($adc29d01cab8fb90));
					$f46da30a01f7b2d7->addChild('category_id', $a8d4f49e3337c3e5);
					$ca7742d819803810 = $f46da30a01f7b2d7->addChild('stream_url');
					$b1a9a67f7480d1f6 = 'movie/' . $a71afc14d6cd090d . '/' . $d5249dad8e8411b7 . '/' . $Bd43537fab08ca31['id'] . '/' . $Bd43537fab08ca31['target_container'];
					$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
					$c8d91fcd2309e48a = $C700a2b357e5ed65 . 'play/' . $ea5296071288c730;
					$ca7742d819803810->addCData($c8d91fcd2309e48a);
				}
				header('Content-Type: application/xml; charset=utf-8');
				echo $cd4d474fc2ee8031->asXML();
			}

			break;

		case 'get_live_streams':
			if (!(isset($a8d4f49e3337c3e5) || is_null($a8d4f49e3337c3e5))) {
			} else {
				$Be965cdd996d4520 = (is_null($a8d4f49e3337c3e5) ? null : $a8d4f49e3337c3e5);
				$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
				$cd4d474fc2ee8031->addChild('playlist_name', 'Live [ ' . XUI::$rSettings['server_name'] . ' ]');
				$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
				$A1925ae53e9307eb->addChild('category_id', 1);
				$A1925ae53e9307eb->addChild('category_title', 'Live [ ' . XUI::$rSettings['server_name'] . ' ]');

				foreach ($D9476a2ebc0516a2 as $f523e362fb81d6c8) {
					if ($Be965cdd996d4520 && !in_array($Be965cdd996d4520, json_decode($f523e362fb81d6c8['category_id'], true))) {
					} else {
						$Bf4dc80cbc51ef81 = array();

						if (!file_exists(EPG_PATH . 'stream_' . intval($f523e362fb81d6c8['id']))) {
						} else {
							foreach (igbinary_unserialize(file_get_contents(EPG_PATH . 'stream_' . $f523e362fb81d6c8['id'])) as $C740da31596f24ef) {
								if ($C740da31596f24ef['end'] >= time()) {
									$Bf4dc80cbc51ef81[] = $C740da31596f24ef;

									if (2 > count($Bf4dc80cbc51ef81)) {
									} else {
										break;
									}
								}
							}
						}

						$adc29d01cab8fb90 = '';
						$ac521e55791e17b5 = '';
						$Ea22c4a9ab5b2176 = 0;

						foreach ($Bf4dc80cbc51ef81 as $C740da31596f24ef) {
							$adc29d01cab8fb90 .= '[' . date('H:i', $C740da31596f24ef['start']) . '] ' . $C740da31596f24ef['title'] . "\n" . '( ' . $C740da31596f24ef['description'] . ')' . "\n";

							if ($Ea22c4a9ab5b2176 != 0) {
							} else {
								$ac521e55791e17b5 = '[' . date('H:i', $C740da31596f24ef['start']) . ' - ' . date('H:i', $C740da31596f24ef['end']) . '] + ' . round(($C740da31596f24ef['end'] - time()) / 60, 1) . ' min   ' . $C740da31596f24ef['title'];
								$Ea22c4a9ab5b2176++;
							}
						}
					}

					foreach (json_decode($f523e362fb81d6c8['category_id'], true) as $B750c9b908ca927c) {
						if ($Be965cdd996d4520 && $Be965cdd996d4520 != $B750c9b908ca927c) {
						} else {
							$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
							$f46da30a01f7b2d7->addChild('title', base64_encode($f523e362fb81d6c8['stream_display_name'] . ' ' . $ac521e55791e17b5));
							$f46da30a01f7b2d7->addChild('description', base64_encode($adc29d01cab8fb90));
							$accc0f5f27231d0c = $f46da30a01f7b2d7->addChild('desc_image');
							$accc0f5f27231d0c->addCData(XUI::b8f3dEf724810918($f523e362fb81d6c8['stream_icon']));
							$f46da30a01f7b2d7->addChild('category_id', $B750c9b908ca927c);
							$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('stream_url');
							$b1a9a67f7480d1f6 = 'live/' . $a71afc14d6cd090d . '/' . $d5249dad8e8411b7 . '/' . $f523e362fb81d6c8['id'];
							$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
							$c8d91fcd2309e48a = $C700a2b357e5ed65 . 'play/' . $ea5296071288c730;
							$Ad43d50030943890->addCData($c8d91fcd2309e48a);
						}

						if ($Be965cdd996d4520) {
						} else {
							break;
						}
					}
				}
				header('Content-Type: application/xml; charset=utf-8');
				echo $cd4d474fc2ee8031->asXML();
			}

			break;

		case 'get_vod_streams':
			if (!(isset($a8d4f49e3337c3e5) || is_null($a8d4f49e3337c3e5))) {
			} else {
				$Be965cdd996d4520 = (is_null($a8d4f49e3337c3e5) ? null : $a8d4f49e3337c3e5);
				$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
				$cd4d474fc2ee8031->addChild('playlist_name', 'Movie [ ' . XUI::$rSettings['server_name'] . ' ]');
				$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
				$A1925ae53e9307eb->addChild('category_id', 1);
				$A1925ae53e9307eb->addChild('category_title', 'Movie [ ' . XUI::$rSettings['server_name'] . ' ]');

				foreach ($ef63f09fd8837a72 as $f523e362fb81d6c8) {
					foreach (json_decode($f523e362fb81d6c8['category_id'], true) as $B750c9b908ca927c) {
						if ($Be965cdd996d4520 && $Be965cdd996d4520 != $B750c9b908ca927c) {
						} else {
							$D92b16dc36690ab9 = json_decode($f523e362fb81d6c8['movie_properties'], true);
							$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
							$f46da30a01f7b2d7->addChild('title', base64_encode($f523e362fb81d6c8['stream_display_name']));
							$adc29d01cab8fb90 = '';

							if (!$D92b16dc36690ab9) {
							} else {
								foreach ($D92b16dc36690ab9 as $D3fa098be3f297cd => $Ddad45b350372457) {
									if ($D3fa098be3f297cd != 'movie_image') {
										$adc29d01cab8fb90 .= strtoupper($D3fa098be3f297cd) . ': ' . $Ddad45b350372457 . "\n";
									}
								}
							}

							$accc0f5f27231d0c = $f46da30a01f7b2d7->addChild('desc_image');
							$accc0f5f27231d0c->addCData(XUI::b8f3def724810918($D92b16dc36690ab9['movie_image']));
							$f46da30a01f7b2d7->addChild('description', base64_encode($adc29d01cab8fb90));
							$f46da30a01f7b2d7->addChild('category_id', $B750c9b908ca927c);
							$ca7742d819803810 = $f46da30a01f7b2d7->addChild('stream_url');
							$b1a9a67f7480d1f6 = 'movie/' . $a71afc14d6cd090d . '/' . $d5249dad8e8411b7 . '/' . $f523e362fb81d6c8['id'] . '/' . $f523e362fb81d6c8['target_container'];
							$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
							$c8d91fcd2309e48a = $C700a2b357e5ed65 . 'play/' . $ea5296071288c730;
							$ca7742d819803810->addCData($c8d91fcd2309e48a);
						}

						if ($Be965cdd996d4520) {
						} else {
							break;
						}
					}
				}
				header('Content-Type: application/xml; charset=utf-8');
				echo $cd4d474fc2ee8031->asXML();
			}

			break;

		default:
			$cd4d474fc2ee8031 = new SimpleXMLExtended('<items/>');
			$cd4d474fc2ee8031->addChild('playlist_name', XUI::$rSettings['server_name']);
			$A1925ae53e9307eb = $cd4d474fc2ee8031->addChild('category');
			$A1925ae53e9307eb->addChild('category_id', 1);
			$A1925ae53e9307eb->addChild('category_title', XUI::$rSettings['server_name']);

			if (empty($D9476a2ebc0516a2)) {
			} else {
				class SimpleXMLExtended extends SimpleXMLElement
				{
					public function addCData($Ad43d50030943890)
					{
						$d55fd8a75e7eaba1 = dom_import_simplexml($this);
						$B9f42be8c783da91 = $d55fd8a75e7eaba1->ownerDocument;
						$d55fd8a75e7eaba1->appendChild($B9f42be8c783da91->createCDATASection($Ad43d50030943890));
					}
				}

				$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
				$f46da30a01f7b2d7->addChild('title', base64_encode('Live Streams'));
				$f46da30a01f7b2d7->addChild('description', base64_encode('Live Streams Category'));
				$f46da30a01f7b2d7->addChild('category_id', 0);
				$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
				$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_live_categories');
			}

			if (empty($ef63f09fd8837a72)) {
			} else {
				$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
				$f46da30a01f7b2d7->addChild('title', base64_encode('VOD'));
				$f46da30a01f7b2d7->addChild('description', base64_encode('Video On Demand Category'));
				$f46da30a01f7b2d7->addChild('category_id', 1);
				$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
				$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_vod_categories');
			}

			$f46da30a01f7b2d7 = $cd4d474fc2ee8031->addChild('channel');
			$f46da30a01f7b2d7->addChild('title', base64_encode('TV Series'));
			$f46da30a01f7b2d7->addChild('description', base64_encode('TV Series Category'));
			$f46da30a01f7b2d7->addChild('category_id', 2);
	}
	$Ad43d50030943890 = $f46da30a01f7b2d7->addChild('playlist_url');
	$Ad43d50030943890->addCData($C700a2b357e5ed65 . 'enigma2?username=' . $a71afc14d6cd090d . '&password=' . $d5249dad8e8411b7 . '&type=get_series_categories');
	header('Content-Type: application/xml; charset=utf-8');
	echo $cd4d474fc2ee8031->asXML();
} else {
	XUI::B6F740fABc7265bF(null, null, $a71afc14d6cd090d);
	generateError('INVALID_CREDENTIALS');
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $Dab081f66facd7a3;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::fC8474658Ec80360();
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
