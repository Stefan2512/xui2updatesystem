<?php

register_shutdown_function('shutdown');
set_time_limit(0);
require_once 'init.php';
unset(XUI::$rSettings['watchdog_data'], XUI::$rSettings['server_hardware']);

header('Access-Control-Allow-Origin: *');

if (empty(XUI::$rSettings['send_server_header'])) {
} else {
	header('Server: ' . XUI::$rSettings['send_server_header']);
}

if (!XUI::$rSettings['send_protection_headers']) {
} else {
	header('X-XSS-Protection: 0');
	header('X-Content-Type-Options: nosniff');
}

if (!XUI::$rSettings['send_altsvc_header']) {
} else {
	header('Alt-Svc: h3-29=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-T051=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q050=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q046=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q043=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,quic=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000; v="46,43"');
}

if (!empty(XUI::$rSettings['send_unique_header_domain']) || filter_var(HOST, FILTER_VALIDATE_IP)) {
} else {
	XUI::$rSettings['send_unique_header_domain'] = '.' . HOST;
}

if (empty(XUI::$rSettings['send_unique_header'])) {
} else {
	$bae85948a6f4b7de = new DateTime('+6 months', new DateTimeZone('GMT'));
	header('Set-Cookie: ' . XUI::$rSettings['send_unique_header'] . '=' . XUI::bB7f1b0ED6c4B87d(11) . '; Domain=' . XUI::$rSettings['send_unique_header_domain'] . '; Expires=' . $bae85948a6f4b7de->format(DATE_RFC2822) . '; Path=/; Secure; HttpOnly; SameSite=none');
}

$D7102b1e2b296e66 = (XUI::$rSettings['create_expiration'] ?: 5);
$b2a9243e8304033d = null;
$c59ec257c284c894 = XUI::a9BC416FA6fA55c3();
$b3374866087774a1 = (empty($_SERVER['HTTP_USER_AGENT']) ? '' : htmlentities(trim($_SERVER['HTTP_USER_AGENT'])));
$f2d1c7bb81b31b19 = null;
$b25be5f9af7a0a91 = 0;
$Df5a05fb37ec64f1 = false;
$f9b07d216a168dcc = getmypid();
$a859a0996bb0f1ff = time();
$F2735dad02d30e84 = null;

if (isset(XUI::$rRequest['token'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['token'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);

	if (is_array($F64d974c429d80be)) {
	} else {
		XUI::eA6C9a31F15A7b61(0, 0, 'LB_TOKEN_INVALID', $c59ec257c284c894);
		generateError('LB_TOKEN_INVALID');
	}

	if (!(isset($F64d974c429d80be['expires']) && $F64d974c429d80be['expires'] < time() - intval(XUI::$rServers[SERVER_ID]['time_offset']))) {
	} else {
		generateError('TOKEN_EXPIRED');
	}

	if (!isset($F64d974c429d80be['video_path'])) {
		if (isset($F64d974c429d80be['hmac_id'])) {
			$B08e7d3cd339391a = $F64d974c429d80be['hmac_id'];
			$E18c40e895ee55c2 = $F64d974c429d80be['identifier'];
		} else {
			$a71afc14d6cd090d = $F64d974c429d80be['username'];
			$d5249dad8e8411b7 = $F64d974c429d80be['password'];
		}

		$F26087d31c2bbe4d = intval($F64d974c429d80be['stream_id']);
		$F9452a7efafa1aba = $F64d974c429d80be['extension'];
		$fca7edf85daa1695 = $F64d974c429d80be['channel_info'];
		$D4253f9520627819 = $F64d974c429d80be['user_info'];
		$ffc0436d3fdc5100 = $F64d974c429d80be['activity_start'];
		$d080620e03289080 = $F64d974c429d80be['external_device'];
		$F2735dad02d30e84 = $F64d974c429d80be['video_codec'];
		$efc0f8f3059e4104 = $F64d974c429d80be['country_code'];
	} else {
		header('Content-Type: video/mp2t');
		readfile($F64d974c429d80be['video_path']);

		exit();
	}
} else {
	generateError('NO_TOKEN_SPECIFIED');
}

if (in_array($F9452a7efafa1aba, array('ts', 'm3u8'))) {
} else {
	$F9452a7efafa1aba = XUI::$rSettings['api_container'];
}

if (!($fca7edf85daa1695['proxy'] && $F9452a7efafa1aba != 'ts')) {
} else {
	generateError('USER_DISALLOW_EXT');
}

if (XUI::$rSettings['use_buffer'] != 0) {
} else {
	header('X-Accel-Buffering: no');
}

if ($fca7edf85daa1695) {
	if ($fca7edf85daa1695['originator_id']) {
		$d58b4f8653a391d8 = $fca7edf85daa1695['originator_id'];
		$b2a9243e8304033d = $fca7edf85daa1695['redirect_id'];
	} else {
		$d58b4f8653a391d8 = ($fca7edf85daa1695['redirect_id'] ?: SERVER_ID);
		$b2a9243e8304033d = null;
	}

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
	} else {
		$fca7edf85daa1695['pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
	}

	if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) {
	} else {
		$fca7edf85daa1695['monitor_pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
	}

	if (!(XUI::$rSettings['on_demand_instant_off'] && $fca7edf85daa1695['on_demand'] == 1)) {
	} else {
		XUI::A2aa2b94d2d97A7F($F26087d31c2bbe4d, $f9b07d216a168dcc);
	}

	if (XUI::f74FA4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
	} else {
		$fca7edf85daa1695['pid'] = null;

		if ($fca7edf85daa1695['on_demand'] == 1) {
			if (XUI::EA4a2063E98baEf8($fca7edf85daa1695['monitor_pid'], $F26087d31c2bbe4d)) {
			} else {
				if (($ffc0436d3fdc5100 + $D7102b1e2b296e66) - intval(XUI::$rServers[SERVER_ID]['time_offset']) >= time()) {
				} else {
					generateError('TOKEN_EXPIRED');
				}

				XUI::daC4D82f05378662($F26087d31c2bbe4d);
				$B9cc3064fe62da37 = 0;

				while (!file_exists(STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.monitor') && $B9cc3064fe62da37 < 300) {
					usleep(10000);
					$B9cc3064fe62da37++;
				}
				$fca7edf85daa1695['monitor_pid'] = (intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor')) ?: null);
			}

			if ($fca7edf85daa1695['monitor_pid']) {
			} else {
				XUI::aD5765C0fd1AbB43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
			}

			for ($B9cc3064fe62da37 = 0; !file_exists(STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.pid') && $B9cc3064fe62da37 < 300; $B9cc3064fe62da37++) {
				usleep(10000);
			}
			$fca7edf85daa1695['pid'] = (intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) ?: null);

			if ($fca7edf85daa1695['pid']) {
			} else {
				XUI::Ad5765c0fd1ABB43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
			}
		} else {
			if ($fca7edf85daa1695['proxy']) {
				if ($fca7edf85daa1695['monitor_pid'] && XUI::ea4A2063E98bAeF8($fca7edf85daa1695['monitor_pid'], $F26087d31c2bbe4d)) {
				} else {
					@unlink(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid');
					XUI::startProxy($F26087d31c2bbe4d);

					for ($B9cc3064fe62da37 = 0; !file_exists(STREAMS_PATH . intval($F26087d31c2bbe4d) . '_.monitor') && $B9cc3064fe62da37 < 300; $B9cc3064fe62da37++) {
						usleep(10000);
					}
					$fca7edf85daa1695['monitor_pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.monitor'));
				}

				if ($fca7edf85daa1695['monitor_pid']) {
				} else {
					XUI::AD5765c0Fd1aBB43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
				}

				$fca7edf85daa1695['pid'] = $fca7edf85daa1695['monitor_pid'];
			} else {
				XUI::ad5765C0FD1aBB43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
			}
		}
	}

	if ($fca7edf85daa1695['proxy']) {
	} else {
		$B9cc3064fe62da37 = 0;
		$bb62005ea7eb8380 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8';

		if ($F9452a7efafa1aba == 'ts') {
			if (file_exists($bb62005ea7eb8380)) {
			} else {
				$Cd8fd79b62884002 = STREAMS_PATH . $F26087d31c2bbe4d . '_0.ts';
				$e1644d67f855686d = null;

				while ($B9cc3064fe62da37 < intval(XUI::$rSettings['on_demand_wait_time']) * 10) {
					if (!file_exists($Cd8fd79b62884002) || $e1644d67f855686d) {
					} else {
						$e1644d67f855686d = fopen($Cd8fd79b62884002, 'r');
					}

					if (XUI::EA4A2063E98BaEf8($fca7edf85daa1695['monitor_pid'], $F26087d31c2bbe4d) && XUI::F74fa4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
					} else {
						XUI::ad5765c0fd1Abb43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
					}

					if (!($e1644d67f855686d && fread($e1644d67f855686d, 1))) {
						usleep(100000);
						$B9cc3064fe62da37++;

						break;
					}
				}

				if (!$e1644d67f855686d) {
				} else {
					fclose($e1644d67f855686d);
				}
			}
		} else {
			for ($Cd8fd79b62884002 = STREAMS_PATH . $F26087d31c2bbe4d . '_.m3u8'; !file_exists($bb62005ea7eb8380) && !file_exists($Cd8fd79b62884002) && $B9cc3064fe62da37 < intval(XUI::$rSettings['on_demand_wait_time']) * 10; $B9cc3064fe62da37++) {
				usleep(100000);
			}
		}

		if ($B9cc3064fe62da37 != intval(XUI::$rSettings['on_demand_wait_time']) * 10) {
		} else {
			generateError('WAIT_TIME_EXPIRED');
		}

		if ($fca7edf85daa1695['pid']) {
		} else {
			$fca7edf85daa1695['pid'] = (intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) ?: null);
		}
	}

	$b39786a7617f8375 = time() - $a859a0996bb0f1ff;
	$Cf4fcafdb62b7bc7 = ($ffc0436d3fdc5100 + $D7102b1e2b296e66 + $b39786a7617f8375) - intval(XUI::$rServers[SERVER_ID]['time_offset']);

	if (XUI::$rSettings['redis_handler']) {
		XUI::bfa8b6fe314deD7F();
	} else {
		XUI::Ad0A56BE17E95e81();
	}

	if (!(XUI::$rSettings['disallow_2nd_ip_con'] && !$D4253f9520627819['is_restreamer'] && ($D4253f9520627819['max_connections'] <= XUI::$rSettings['disallow_2nd_ip_max'] && 0 < $D4253f9520627819['max_connections'] || XUI::$rSettings['disallow_2nd_ip_max'] == 0))) {
	} else {
		$F4cfe63a20313b9d = null;

		if (XUI::$rSettings['redis_handler']) {
			$A90d77181715e38e = XUI::Bc23764ED0732f3F($D4253f9520627819['id'], true);

			if (0 >= count($A90d77181715e38e)) {
			} else {
				$c94b497359f8aed9 = array_column($A90d77181715e38e, 'date_start');
				array_multisort($c94b497359f8aed9, SORT_ASC, $A90d77181715e38e);
				$F4cfe63a20313b9d = $A90d77181715e38e[0]['user_ip'];
			}
		} else {
			XUI::$db->query('SELECT `user_ip` FROM `lines_live` WHERE `user_id` = ? AND `hls_end` = 0 ORDER BY `activity_id` DESC LIMIT 1;', $D4253f9520627819['id']);

			if (XUI::$db->num_rows() != 1) {
			} else {
				$F4cfe63a20313b9d = XUI::$db->get_row()['user_ip'];
			}
		}

		$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $F4cfe63a20313b9d), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $F4cfe63a20313b9d == $c59ec257c284c894);

		if (!$F4cfe63a20313b9d || $ee7553b0caebc8c4) {
		} else {
			XUI::eA6c9a31F15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_ALREADY_CONNECTED', $c59ec257c284c894);
			XUI::Ad5765c0FD1abb43('show_connected_video', 'connected_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
		}
	}

	switch ($F9452a7efafa1aba) {
		case 'm3u8':
			if (XUI::$rSettings['redis_handler']) {
				$e110a2ab6d3a4734 = XUI::B85Cccef157fB67b($F64d974c429d80be['uuid']);
			} else {
				if (isset($F64d974c429d80be['adaptive'])) {
					XUI::$db->query("SELECT `activity_id`, `user_ip` FROM `lines_live` WHERE `uuid` = ? AND `user_id` = ? AND `container` = 'hls' AND `hls_end` = 0", $F64d974c429d80be['uuid'], $D4253f9520627819['id']);
				} else {
					if (!$B08e7d3cd339391a) {
						XUI::$db->query("SELECT `activity_id`, `user_ip` FROM `lines_live` WHERE `uuid` = ? AND `user_id` = ? AND `server_id` = ? AND `container` = 'hls' AND `stream_id` = ? AND `hls_end` = 0", $F64d974c429d80be['uuid'], $D4253f9520627819['id'], $d58b4f8653a391d8, $F26087d31c2bbe4d);
					} else {
						XUI::$db->query("SELECT `activity_id`, `user_ip` FROM `lines_live` WHERE `uuid` = ? AND `hmac_id` = ? AND `hmac_identifier` = ? AND `server_id` = ? AND `container` = 'hls' AND `stream_id` = ? AND `hls_end` = 0", $F64d974c429d80be['uuid'], $B08e7d3cd339391a, $E18c40e895ee55c2, $d58b4f8653a391d8, $F26087d31c2bbe4d);
					}
				}

				if (0 >= XUI::$db->num_rows()) {
				} else {
					$e110a2ab6d3a4734 = XUI::$db->get_row();
				}
			}

			if (!$e110a2ab6d3a4734) {
				if ($Cf4fcafdb62b7bc7 >= time()) {
				} else {
					generateError('TOKEN_EXPIRED');
				}

				if (!$B08e7d3cd339391a) {
					if (XUI::$rSettings['redis_handler']) {
						$Fc9594978cb1834f = array('user_id' => $D4253f9520627819['id'], 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => 'hls', 'pid' => null, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => $d080620e03289080, 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => $fca7edf85daa1695['on_demand'], 'identity' => $D4253f9520627819['id'], 'uuid' => $F64d974c429d80be['uuid']);
						$B59c127fecf35c15 = XUI::e0C928A3A83F24E9($Fc9594978cb1834f);
					} else {
						$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`user_id`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`,`hls_last_read`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?);', $D4253f9520627819['id'], $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, 'hls', null, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d080620e03289080, time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));
					}
				} else {
					if (XUI::$rSettings['redis_handler']) {
						$Fc9594978cb1834f = array('hmac_id' => $B08e7d3cd339391a, 'hmac_identifier' => $E18c40e895ee55c2, 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => 'hls', 'pid' => null, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => $d080620e03289080, 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => $fca7edf85daa1695['on_demand'], 'identity' => $B08e7d3cd339391a . '_' . $E18c40e895ee55c2, 'uuid' => $F64d974c429d80be['uuid']);
						$B59c127fecf35c15 = XUI::E0C928A3A83f24e9($Fc9594978cb1834f);
					} else {
						$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`hmac_id`,`hmac_identifier`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`,`hls_last_read`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);', $B08e7d3cd339391a, $E18c40e895ee55c2, $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, 'hls', null, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d080620e03289080, time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));
					}
				}
			} else {
				$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $e110a2ab6d3a4734['user_ip']), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $e110a2ab6d3a4734['user_ip'] == $c59ec257c284c894);

				if ($ee7553b0caebc8c4 || !XUI::$rSettings['restrict_same_ip']) {
				} else {
					XUI::ea6C9A31f15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_MISMATCH', $c59ec257c284c894);
					generateError('IP_MISMATCH');
				}

				if (XUI::$rSettings['redis_handler']) {
					$a6b40128767dfe4f = array('server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));

					if ($e110a2ab6d3a4734 = XUI::E3484F74d3c8B5a7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'open')) {
						$B59c127fecf35c15 = true;
					} else {
						$B59c127fecf35c15 = false;
					}
				} else {
					$B59c127fecf35c15 = XUI::$db->query('UPDATE `lines_live` SET `hls_last_read` = ?, `hls_end` = 0, `server_id` = ?, `proxy_id` = ? WHERE `activity_id` = ?', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), $d58b4f8653a391d8, $b2a9243e8304033d, $e110a2ab6d3a4734['activity_id']);
				}
			}

			if ($B59c127fecf35c15) {
			} else {
				XUI::ea6C9A31F15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'LINE_CREATE_FAIL', $c59ec257c284c894);
				generateError('LINE_CREATE_FAIL');
			}

			XUI::DE9e9e0d836b5d86($D4253f9520627819, $B08e7d3cd339391a, $E18c40e895ee55c2, $c59ec257c284c894, $b3374866087774a1);

			if (XUI::$rSettings['redis_handler']) {
				XUI::b0b419A0354a0297();
			} else {
				XUI::f6cc02011179Dfc7();
			}

			$a1ca7d888fba44a6 = XUI::C0f542bdF7351c78($bb62005ea7eb8380, (isset($a71afc14d6cd090d) ? $a71afc14d6cd090d : null), (isset($d5249dad8e8411b7) ? $d5249dad8e8411b7 : null), $F26087d31c2bbe4d, $F64d974c429d80be['uuid'], $c59ec257c284c894, $B08e7d3cd339391a, $E18c40e895ee55c2, $F2735dad02d30e84, intval($fca7edf85daa1695['on_demand']), $d58b4f8653a391d8, $b2a9243e8304033d);

			if ($a1ca7d888fba44a6) {
				touch(CONS_TMP_PATH . $F64d974c429d80be['uuid']);
				ob_end_clean();
				header('Content-Type: application/x-mpegurl');
				header('Content-Length: ' . strlen($a1ca7d888fba44a6));
				header('Cache-Control: no-store, no-cache, must-revalidate');
				echo $a1ca7d888fba44a6;
			} else {
				XUI::AD5765C0Fd1ABB43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
			}

			exit();

		default:
			if (XUI::$rSettings['redis_handler']) {
				$e110a2ab6d3a4734 = XUI::B85CCCEF157fb67B($F64d974c429d80be['uuid']);
			} else {
				if (!$B08e7d3cd339391a) {
					XUI::$db->query('SELECT `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `uuid` = ? AND `user_id` = ? AND `server_id` = ? AND `container` = ? AND `stream_id` = ?;', $F64d974c429d80be['uuid'], $D4253f9520627819['id'], $d58b4f8653a391d8, $F9452a7efafa1aba, $F26087d31c2bbe4d);
				} else {
					XUI::$db->query('SELECT `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `uuid` = ? AND `hmac_id` = ? AND `hmac_identifier` = ? AND `server_id` = ? AND `container` = ? AND `stream_id` = ?;', $F64d974c429d80be['uuid'], $B08e7d3cd339391a, $E18c40e895ee55c2, $d58b4f8653a391d8, $F9452a7efafa1aba, $F26087d31c2bbe4d);
				}

				if (0 >= XUI::$db->num_rows()) {
				} else {
					$e110a2ab6d3a4734 = XUI::$db->get_row();
				}
			}

			if (!$e110a2ab6d3a4734) {
				if ($Cf4fcafdb62b7bc7 >= time()) {
				} else {
					generateError('TOKEN_EXPIRED');
				}

				if (!$B08e7d3cd339391a) {
					if (XUI::$rSettings['redis_handler']) {
						$Fc9594978cb1834f = array('user_id' => $D4253f9520627819['id'], 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => $d080620e03289080, 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => $fca7edf85daa1695['on_demand'], 'identity' => $D4253f9520627819['id'], 'uuid' => $F64d974c429d80be['uuid']);
						$B59c127fecf35c15 = XUI::e0c928A3a83F24e9($Fc9594978cb1834f);
					} else {
						$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`user_id`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', $D4253f9520627819['id'], $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, $F9452a7efafa1aba, $f9b07d216a168dcc, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d080620e03289080);
					}
				} else {
					if (XUI::$rSettings['redis_handler']) {
						$Fc9594978cb1834f = array('hmac_id' => $B08e7d3cd339391a, 'hmac_identifier' => $E18c40e895ee55c2, 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => $d080620e03289080, 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => $fca7edf85daa1695['on_demand'], 'identity' => $B08e7d3cd339391a . '_' . $E18c40e895ee55c2, 'uuid' => $F64d974c429d80be['uuid']);
						$B59c127fecf35c15 = XUI::e0C928a3A83F24e9($Fc9594978cb1834f);
					} else {
						$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`hmac_id`,`hmac_identifier`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)', $B08e7d3cd339391a, $E18c40e895ee55c2, $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, $F9452a7efafa1aba, $f9b07d216a168dcc, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d080620e03289080);
					}
				}
			} else {
				$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $e110a2ab6d3a4734['user_ip']), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $e110a2ab6d3a4734['user_ip'] == $c59ec257c284c894);

				if ($ee7553b0caebc8c4 || !XUI::$rSettings['restrict_same_ip']) {
				} else {
					XUI::eA6C9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_MISMATCH', $c59ec257c284c894);
					generateError('IP_MISMATCH');
				}

				if (!(XUI::dD714ee89C59FbF2($e110a2ab6d3a4734['pid'], 'php-fpm') && $f9b07d216a168dcc != $e110a2ab6d3a4734['pid'] && is_numeric($e110a2ab6d3a4734['pid']) && 0 < $e110a2ab6d3a4734['pid'])) {
				} else {
					posix_kill(intval($e110a2ab6d3a4734['pid']), 9);
				}

				if (XUI::$rSettings['redis_handler']) {
					$a6b40128767dfe4f = array('pid' => $f9b07d216a168dcc, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));

					if ($e110a2ab6d3a4734 = XUI::e3484F74d3c8B5A7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'open')) {
						$B59c127fecf35c15 = true;
					} else {
						$B59c127fecf35c15 = false;
					}
				} else {
					$B59c127fecf35c15 = XUI::$db->query('UPDATE `lines_live` SET `hls_end` = 0, `hls_last_read` = ?, `pid` = ? WHERE `activity_id` = ?;', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), $f9b07d216a168dcc, $e110a2ab6d3a4734['activity_id']);
				}
			}

			if ($B59c127fecf35c15) {
			} else {
				XUI::Ea6C9a31f15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'LINE_CREATE_FAIL', $c59ec257c284c894);
				generateError('LINE_CREATE_FAIL');
			}

			XUI::DE9E9e0D836B5d86($D4253f9520627819, $B08e7d3cd339391a, $E18c40e895ee55c2, $c59ec257c284c894, $b3374866087774a1);

			if (XUI::$rSettings['redis_handler']) {
				XUI::B0b419a0354A0297();
			} else {
				XUI::F6cc02011179DFC7();
			}

			$Df5a05fb37ec64f1 = true;

			if (!XUI::$rSettings['monitor_connection_status']) {
			} else {
				ob_implicit_flush(true);

				while (ob_get_level()) {
					ob_end_clean();
				}
			}

			touch(CONS_TMP_PATH . $F64d974c429d80be['uuid']);

			if (!$fca7edf85daa1695['proxy']) {
				header('Content-Type: video/mp2t');
				$f2d1c7bb81b31b19 = DIVERGENCE_TMP_PATH . $F64d974c429d80be['uuid'];

				if (file_exists($bb62005ea7eb8380)) {
					if ($D4253f9520627819['is_restreamer']) {
						if ($F64d974c429d80be['prebuffer']) {
							$e1034511e63f0e9e = XUI::$rSegmentSettings['seg_time'];
						} else {
							$e1034511e63f0e9e = XUI::$rSettings['restreamer_prebuffer'];
						}
					} else {
						$e1034511e63f0e9e = XUI::$rSettings['client_prebuffer'];
					}

					if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur')) {
					} else {
						$C5034884ed44603a = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur'));

						if (XUI::$rSegmentSettings['seg_time'] >= $C5034884ed44603a) {
						} else {
							XUI::$rSegmentSettings['seg_time'] = $C5034884ed44603a;
						}
					}

					$Bffc17a99eb14fd6 = XUI::D076F5A2Cc104C49($bb62005ea7eb8380, $e1034511e63f0e9e, XUI::$rSegmentSettings['seg_time']);
				} else {
					$Bffc17a99eb14fd6 = null;
				}

				if (!is_null($Bffc17a99eb14fd6)) {
					if (is_array($Bffc17a99eb14fd6)) {
						$B1e64f338fac8781 = 0;
						$a859a0996bb0f1ff = time();

						foreach ($Bffc17a99eb14fd6 as $d55bf693d0ece21c) {
							if (file_exists(STREAMS_PATH . $d55bf693d0ece21c)) {
								$B1e64f338fac8781 += readfile(STREAMS_PATH . $d55bf693d0ece21c);
							} else {
								exit();
							}
						}
						$Fc7df854d7e896b2 = time() - $a859a0996bb0f1ff;

						if ($Fc7df854d7e896b2 != 0) {
						} else {
							$Fc7df854d7e896b2 = 0.1;
						}

						$b25be5f9af7a0a91 = intval($B1e64f338fac8781 / $Fc7df854d7e896b2 / 1024);
						file_put_contents($f2d1c7bb81b31b19, $b25be5f9af7a0a91);
						preg_match('/_(.*)\\./', array_pop($Bffc17a99eb14fd6), $E415df512cb68430);
						$ce8f0c719e170c50 = $E415df512cb68430[1];
					} else {
						$ce8f0c719e170c50 = $Bffc17a99eb14fd6;
					}
				} else {
					if (!file_exists($bb62005ea7eb8380)) {
						$ce8f0c719e170c50 = -1;
					} else {
						exit();
					}
				}

				$d5e40c7f6fdf5643 = 0;
				$bce4fc6e727309d8 = XUI::$rSegmentSettings['seg_time'] * 2;

				if (!(($bce4fc6e727309d8 < intval(XUI::$rSettings['segment_wait_time']) ?: 20))) {
				} else {
					$bce4fc6e727309d8 = (intval(XUI::$rSettings['segment_wait_time']) ?: 20);
				}

				$cf09ed95034dc108 = $Af547236269d8f66 = time();

				while (true) {
					$E8601dd191bcdbba = sprintf('%d_%d.ts', $fca7edf85daa1695['stream_id'], $ce8f0c719e170c50 + 1);
					$E4c630709fd1c356 = sprintf('%d_%d.ts', $fca7edf85daa1695['stream_id'], $ce8f0c719e170c50 + 2);

					for ($Aae09861fbc788ec = 0; !file_exists(STREAMS_PATH . $E8601dd191bcdbba) && $Aae09861fbc788ec <= $bce4fc6e727309d8; $Aae09861fbc788ec++) {
						sleep(1);
					}

					if (file_exists(STREAMS_PATH . $E8601dd191bcdbba)) {
						if (!file_exists(SIGNALS_PATH . $F64d974c429d80be['uuid'])) {
						} else {
							$add193137cabeea7 = json_decode(file_get_contents(SIGNALS_PATH . $F64d974c429d80be['uuid']), true);

							if ($add193137cabeea7['type'] != 'signal') {
							} else {
								for ($Aae09861fbc788ec = 0; !file_exists(STREAMS_PATH . $E4c630709fd1c356) && $Aae09861fbc788ec <= $bce4fc6e727309d8; $Aae09861fbc788ec++) {
									sleep(1);
								}
								XUI::bc69AfFe50d85273($add193137cabeea7, $E8601dd191bcdbba, ($F2735dad02d30e84 ?: 'h264'));
								unlink(SIGNALS_PATH . $F64d974c429d80be['uuid']);
								$ce8f0c719e170c50++;
							}
						}

						$d5e40c7f6fdf5643 = 0;
						$B03be4d52f9e9b56 = time();
						$e1644d67f855686d = fopen(STREAMS_PATH . $E8601dd191bcdbba, 'r');

						while ($d5e40c7f6fdf5643 <= $bce4fc6e727309d8 && !file_exists(STREAMS_PATH . $E4c630709fd1c356)) {
							$a27e64cc6ce01033 = stream_get_line($e1644d67f855686d, XUI::$rSettings['read_buffer_size']);

							if (!empty($a27e64cc6ce01033)) {
								echo $a27e64cc6ce01033;
								$a27e64cc6ce01033 = '';
								$d5e40c7f6fdf5643 = 0;

								break;
							}

							if (XUI::F74fa4748B081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
								sleep(1);
								$d5e40c7f6fdf5643++;
							}
						}

						if (XUI::F74fa4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d) && $d5e40c7f6fdf5643 <= $bce4fc6e727309d8 && file_exists(STREAMS_PATH . $E8601dd191bcdbba) && is_resource($e1644d67f855686d)) {
							$da9e8cb22ec468a6 = filesize(STREAMS_PATH . $E8601dd191bcdbba);
							$E4e6bf32b967d5f2 = $da9e8cb22ec468a6 - ftell($e1644d67f855686d);

							if (0 >= $E4e6bf32b967d5f2) {
							} else {
								echo stream_get_line($e1644d67f855686d, $E4e6bf32b967d5f2);
							}

							$Fc7df854d7e896b2 = time() - $B03be4d52f9e9b56;

							if ($Fc7df854d7e896b2 > 0) {
							} else {
								$Fc7df854d7e896b2 = 0.1;
							}

							file_put_contents($f2d1c7bb81b31b19, intval($da9e8cb22ec468a6 / 1024 / $Fc7df854d7e896b2));
						} else {
							if (!($D4253f9520627819['is_restreamer'] == 1 || $bce4fc6e727309d8 < $d5e40c7f6fdf5643)) {
								for ($Aae09861fbc788ec = 0; $Aae09861fbc788ec <= XUI::$rSegmentSettings['seg_time'] && !XUI::f74fA4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d); $Aae09861fbc788ec++) {
									if (!file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid')) {
									} else {
										$fca7edf85daa1695['pid'] = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.pid'));
									}
								}
								sleep(1);

								if (XUI::$rSegmentSettings['seg_time'] >= $Aae09861fbc788ec && XUI::f74FA4748b081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
									if (file_exists(STREAMS_PATH . $E4c630709fd1c356)) {
									} else {
										$ce8f0c719e170c50 = -2;
									}
								} else {
									exit();
								}
							} else {
								exit();
							}
						}

						fclose($e1644d67f855686d);
						$d5e40c7f6fdf5643 = 0;
						$ce8f0c719e170c50++;

						if (!(XUI::$rSettings['monitor_connection_status'] && 5 <= time() - $cf09ed95034dc108)) {
						} else {
							if (connection_status() == CONNECTION_NORMAL) {
								$cf09ed95034dc108 = time();
							} else {
								exit();
							}
						}

						if (300 > time() - $Af547236269d8f66) {
						} else {
							$Af547236269d8f66 = time();
							$e110a2ab6d3a4734 = null;
							XUI::$rSettings = XUI::AbB674425A8B1b0d('settings');

							if (XUI::$rSettings['redis_handler']) {
								XUI::bfA8B6FE314dEd7F();
								$e110a2ab6d3a4734 = XUI::b85cccEF157FB67b($F64d974c429d80be['uuid']);
								XUI::b0B419a0354a0297();
							} else {
								XUI::Ad0A56bE17e95e81();
								XUI::$db->query('SELECT `pid`, `hls_end` FROM `lines_live` WHERE `uuid` = ?', $F64d974c429d80be['uuid']);

								if (XUI::$db->num_rows() != 1) {
								} else {
									$e110a2ab6d3a4734 = XUI::$db->get_row();
								}

								XUI::f6cc02011179DfC7();
							}

							if (!(!is_array($e110a2ab6d3a4734) || $e110a2ab6d3a4734['hls_end'] != 0 || $e110a2ab6d3a4734['pid'] != $f9b07d216a168dcc)) {
							} else {
								exit();
							}
						}
					} else {
						exit();
					}
				}
			} else {
				header('Content-type: video/mp2t');

				if (file_exists(CONS_TMP_PATH . $F26087d31c2bbe4d . '/')) {
				} else {
					mkdir(CONS_TMP_PATH . $F26087d31c2bbe4d);
				}

				$Df7149ba3185b924 = CONS_TMP_PATH . $F26087d31c2bbe4d . '/' . $F64d974c429d80be['uuid'];
				$Cae0f755f512a801 = socket_create(AF_UNIX, SOCK_DGRAM, 0);
				@unlink($Df7149ba3185b924);
				socket_bind($Cae0f755f512a801, $Df7149ba3185b924);
				socket_set_option($Cae0f755f512a801, SOL_SOCKET, SO_RCVTIMEO, array('sec' => 20, 'usec' => 0));
				socket_set_nonblock($Cae0f755f512a801);
				$bce4fc6e727309d8 = 200;
				$d5e40c7f6fdf5643 = 0;

				while ($d5e40c7f6fdf5643 <= $bce4fc6e727309d8) {
					$b9f3f039ea3bf5ca = socket_read($Cae0f755f512a801, 188 * 64);

					if (!empty($b9f3f039ea3bf5ca)) {
						$d5e40c7f6fdf5643 = 0;
						echo $b9f3f039ea3bf5ca;
					} else {
						$d5e40c7f6fdf5643++;
						usleep(100000);
					}
				}
				socket_close($Cae0f755f512a801);
				@unlink($Df7149ba3185b924);
			}
	}
} else {
	XUI::AD5765c0FD1aBb43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d58b4f8653a391d8, $b2a9243e8304033d);
}

function shutdown()
{
	global $Df5a05fb37ec64f1;
	global $F64d974c429d80be;
	global $f9b07d216a168dcc;
	global $fca7edf85daa1695;
	global $F26087d31c2bbe4d;
	XUI::$rSettings = XUI::AbB674425a8b1B0d('settings');

	if (!$Df5a05fb37ec64f1) {
	} else {
		if (XUI::$rSettings['redis_handler']) {
			if (is_object(XUI::$redis)) {
			} else {
				XUI::bFa8b6fE314DEd7F();
			}

			$e110a2ab6d3a4734 = XUI::b85CCcEf157Fb67B($F64d974c429d80be['uuid']);

			if (!($e110a2ab6d3a4734 && $e110a2ab6d3a4734['pid'] == $f9b07d216a168dcc)) {
			} else {
				$a6b40128767dfe4f = array('hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));
				XUI::E3484F74d3C8B5A7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'close');
			}
		} else {
			if (is_object(XUI::$db)) {
			} else {
				XUI::aD0A56Be17e95e81();
			}

			XUI::$db->query('UPDATE `lines_live` SET `hls_end` = 1, `hls_last_read` = ? WHERE `uuid` = ? AND `pid` = ?;', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), $F64d974c429d80be['uuid'], $f9b07d216a168dcc);
		}

		@unlink(CONS_TMP_PATH . $F64d974c429d80be['uuid']);
		@unlink(CONS_TMP_PATH . $F26087d31c2bbe4d . '/' . $F64d974c429d80be['uuid']);
	}

	if (!(XUI::$rSettings['on_demand_instant_off'] && $fca7edf85daa1695['on_demand'] == 1)) {
	} else {
		XUI::ca490ce3385C630e($F26087d31c2bbe4d, $f9b07d216a168dcc);
	}

	if (!XUI::$rSettings['redis_handler'] && is_object(XUI::$db)) {
		XUI::F6cC02011179Dfc7();
	} else {
		if (!(XUI::$rSettings['redis_handler'] && is_object(XUI::$redis))) {
		} else {
			XUI::b0b419a0354A0297();
		}
	}
}
