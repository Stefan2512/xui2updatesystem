<?php

header('Access-Control-Allow-Origin: *');
require_once 'init.php';
$F2d4d8f7981ac574 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'settings'));
$a8bb73cba48fb7f6 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'servers'));
$Df06db369f6b9832 = parse_ini_file(CONFIG_PATH . 'config.ini');
define('SERVER_ID', intval($Df06db369f6b9832['server_id']));

if (!empty($F2d4d8f7981ac574['live_streaming_pass'])) {
} else {
	DB709ED65ae02245();
}

if (!isset($_GET['token'])) {
} else {
	$c59ec257c284c894 = c29c46a45e7a2107();
	$Cc5f933d7da183ba = explode('/', Xui\Functions::decrypt($_GET['token'], $F2d4d8f7981ac574['live_streaming_pass'], OPENSSL_EXTRA));
	$ee7553b0caebc8c4 = ($F2d4d8f7981ac574['ip_subnet_match'] ? implode('.', array_slice(explode('.', $Cc5f933d7da183ba[0]), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $Cc5f933d7da183ba[0] == $c59ec257c284c894);

	if (!(is_array($Cc5f933d7da183ba) && ($ee7553b0caebc8c4 || !$F2d4d8f7981ac574['restrict_same_ip']))) {
	} else {
		echo file_get_contents(STREAMS_PATH . intval($Cc5f933d7da183ba[1]) . '_.key');

		exit();
	}
}

DB709eD65aE02245();
function c29C46a45e7A2107()
{
	return $_SERVER['REMOTE_ADDR'];
}
