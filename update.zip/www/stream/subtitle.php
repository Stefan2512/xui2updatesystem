<?php

require_once 'init.php';
header('Access-Control-Allow-Origin: *');

if (empty(XUI::$rSettings['send_server_header'])) {
} else {
	header('Server: ' . XUI::$rSettings['send_server_header']);
}

if (!XUI::$rSettings['send_protection_headers']) {
} else {
	header('X-XSS-Protection: 0');
	header('X-Content-Type-Options: nosniff');
}

if (!XUI::$rSettings['send_altsvc_header']) {
} else {
	header('Alt-Svc: h3-29=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-T051=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q050=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q046=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q043=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,quic=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000; v="46,43"');
}

if (!empty(XUI::$rSettings['send_unique_header_domain']) || filter_var(HOST, FILTER_VALIDATE_IP)) {
} else {
	XUI::$rSettings['send_unique_header_domain'] = '.' . HOST;
}

if (empty(XUI::$rSettings['send_unique_header'])) {
} else {
	$bae85948a6f4b7de = new DateTime('+6 months', new DateTimeZone('GMT'));
	header('Set-Cookie: ' . XUI::$rSettings['send_unique_header'] . '=' . XUI::BB7F1b0Ed6C4b87D(11) . '; Domain=' . XUI::$rSettings['send_unique_header_domain'] . '; Expires=' . $bae85948a6f4b7de->format(DATE_RFC2822) . '; Path=/; Secure; HttpOnly; SameSite=none');
}

$F26087d31c2bbe4d = null;
$ffce443a1a53dcc4 = 0;

if (!isset(XUI::$rRequest['token'])) {
} else {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['token'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);

	if (is_array($F64d974c429d80be) && !(isset($F64d974c429d80be['expires']) && $F64d974c429d80be['expires'] < time() - intval(XUI::$rServers[SERVER_ID]['time_offset']))) {
	} else {
		generateError('TOKEN_EXPIRED');
	}

	$F26087d31c2bbe4d = $F64d974c429d80be['stream_id'];
	$ffce443a1a53dcc4 = (intval($F64d974c429d80be['sub_id']) ?: 0);
	$f759a775274c9d21 = (intval($F64d974c429d80be['webvtt']) ?: 0);
}

if ($F26087d31c2bbe4d && file_exists(VOD_PATH . $F26087d31c2bbe4d . '_' . $ffce443a1a53dcc4 . '.srt')) {
	header('Content-Description: File Transfer');
	header('Content-type: application/octet-stream');
	header('Content-Disposition: attachment; filename="' . $F26087d31c2bbe4d . '_' . $ffce443a1a53dcc4 . '.' . (($f759a775274c9d21 ? 'vtt' : 'srt')) . '"');
	$f433193a3297ffde = file_get_contents(VOD_PATH . $F26087d31c2bbe4d . '_' . $ffce443a1a53dcc4 . '.srt');

	if (!$f759a775274c9d21) {
	} else {
		$f433193a3297ffde = convertVTT($f433193a3297ffde);
	}

	header('Content-Length: ' . strlen($f433193a3297ffde));
	echo $f433193a3297ffde;

	exit();
}

generateError('THUMBNAIL_DOESNT_EXIST');
function convertVTT($F1769d8572d6356d)
{
	$f2cc0807b1dc8948 = explode("\n", $F1769d8572d6356d);
	$f0434521ea9d1547 = count($f2cc0807b1dc8948);

	for ($Fa5e35208ccf3528 = 1; $Fa5e35208ccf3528 < $f0434521ea9d1547; $Fa5e35208ccf3528++) {
		if (!($Fa5e35208ccf3528 === 1 || trim($f2cc0807b1dc8948[$Fa5e35208ccf3528 - 2]) === '')) {
		} else {
			$f2cc0807b1dc8948[$Fa5e35208ccf3528] = str_replace(',', '.', $f2cc0807b1dc8948[$Fa5e35208ccf3528]);
		}
	}
	$Eb5dde5d027876ce = "WEBVTT\n\n";

	return $Eb5dde5d027876ce . implode("\n", $f2cc0807b1dc8948);
}
