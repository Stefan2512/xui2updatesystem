<?php

header('Access-Control-Allow-Origin: *');
set_time_limit(0);
require_once 'init.php';
$F2d4d8f7981ac574 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'settings'));
$a8bb73cba48fb7f6 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'servers'));
$Df06db369f6b9832 = parse_ini_file(CONFIG_PATH . 'config.ini');

if (defined('SERVER_ID')) {
} else {
	define('SERVER_ID', intval($Df06db369f6b9832['server_id']));
}

if (!empty($F2d4d8f7981ac574['live_streaming_pass'])) {
} else {
	db709Ed65ae02245();
}

if (empty($F2d4d8f7981ac574['send_server_header'])) {
} else {
	header('Server: ' . $F2d4d8f7981ac574['send_server_header']);
}

if (!$F2d4d8f7981ac574['send_protection_headers']) {
} else {
	header('X-XSS-Protection: 0');
	header('X-Content-Type-Options: nosniff');
}

if (!$F2d4d8f7981ac574['send_altsvc_header']) {
} else {
	header('Alt-Svc: h3-29=":' . $a8bb73cba48fb7f6[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-T051=":' . $a8bb73cba48fb7f6[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q050=":' . $a8bb73cba48fb7f6[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q046=":' . $a8bb73cba48fb7f6[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q043=":' . $a8bb73cba48fb7f6[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,quic=":' . $a8bb73cba48fb7f6[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000; v="46,43"');
}

if (!empty($F2d4d8f7981ac574['send_unique_header_domain']) || filter_var(HOST, FILTER_VALIDATE_IP)) {
} else {
	$F2d4d8f7981ac574['send_unique_header_domain'] = '.' . HOST;
}

$F2735dad02d30e84 = 'h264';
$B08e7d3cd339391a = null;

if (!isset($_GET['token'])) {
} else {
	$db752e19806388c2 = 0;
	$Cc5f933d7da183ba = explode('/', Xui\Functions::decrypt($_GET['token'], $F2d4d8f7981ac574['live_streaming_pass'], OPENSSL_EXTRA));

	if (6 > count($Cc5f933d7da183ba)) {
	} else {
		if ($Cc5f933d7da183ba[0] == 'TS') {
			$d58b4f8653a391d8 = $Cc5f933d7da183ba[8];
		} else {
			$d58b4f8653a391d8 = $Cc5f933d7da183ba[6];
		}

		if ($d58b4f8653a391d8 == SERVER_ID) {
			if ($Cc5f933d7da183ba[0] == 'TS') {
				$E379394c7b1a273f = 'ARCHIVE';
				list(, $a71afc14d6cd090d, $d5249dad8e8411b7, $c2a965773885730d, $C5034884ed44603a, $a63ba41c5c63ce14, $bc945723c41af777, $B08b62d9f7870287) = $Cc5f933d7da183ba;
				list($F26087d31c2bbe4d, $B1c1aa7e8b5b4849, $db752e19806388c2) = explode('_', $bc945723c41af777);
				$F26087d31c2bbe4d = intval($F26087d31c2bbe4d);
				$d55bf693d0ece21c = ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . $B1c1aa7e8b5b4849;

				if (file_exists($d55bf693d0ece21c)) {
				} else {
					DB709ed65Ae02245();
				}
			} else {
				$E379394c7b1a273f = 'LIVE';

				if (substr($Cc5f933d7da183ba[0], 0, 5) == 'HMAC#') {
					$B08e7d3cd339391a = intval(explode('#', $Cc5f933d7da183ba[0])[1]);
					$E18c40e895ee55c2 = $Cc5f933d7da183ba[1];
				} else {
					list($a71afc14d6cd090d, $d5249dad8e8411b7) = $Cc5f933d7da183ba;
				}

				$c2a965773885730d = $Cc5f933d7da183ba[2];
				$F26087d31c2bbe4d = intval($Cc5f933d7da183ba[3]);
				$B1c1aa7e8b5b4849 = basename($Cc5f933d7da183ba[4]);
				$B08b62d9f7870287 = $Cc5f933d7da183ba[5];
				$F2735dad02d30e84 = ($Cc5f933d7da183ba[7] ?: 'h264');
				$Beb96c2a189d2e62 = ($Cc5f933d7da183ba[8] ?: 0);
				$d55bf693d0ece21c = STREAMS_PATH . $B1c1aa7e8b5b4849;
				$bc945723c41af777 = explode('_', $B1c1aa7e8b5b4849);

				if (file_exists($d55bf693d0ece21c) && $bc945723c41af777[0] == $F26087d31c2bbe4d) {
				} else {
					db709ed65Ae02245();
				}
			}

			if (file_exists(CONS_TMP_PATH . $B08b62d9f7870287)) {
			} else {
				dB709eD65aE02245();
			}

			$F0d235f3dbb503a5 = filesize($d55bf693d0ece21c);
			$ee7553b0caebc8c4 = ($F2d4d8f7981ac574['ip_subnet_match'] ? implode('.', array_slice(explode('.', $c2a965773885730d), 0, -1)) == implode('.', array_slice(explode('.', c29c46a45e7a2107()), 0, -1)) : $c2a965773885730d == c29C46a45e7a2107());

			if ($ee7553b0caebc8c4 || !$F2d4d8f7981ac574['restrict_same_ip']) {
			} else {
				Db709ED65aE02245();
			}

			header('Access-Control-Allow-Origin: *');
			header('Content-Type: video/mp2t');

			if ($E379394c7b1a273f == 'LIVE') {
				if (!$Beb96c2a189d2e62) {
				} else {
					$F2d4d8f7981ac574['encrypt_hls'] = false;
				}

				if (!file_exists(SIGNALS_PATH . $B08b62d9f7870287)) {
				} else {
					$add193137cabeea7 = json_decode(file_get_contents(SIGNALS_PATH . $B08b62d9f7870287), true);

					if ($add193137cabeea7['type'] != 'signal') {
					} else {
						require_once INCLUDES_PATH . 'streaming.php';
						XUI::init(false);

						if ($F2d4d8f7981ac574['encrypt_hls']) {
							$D3fa098be3f297cd = file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.key');
							$e7ae92f8387d5936 = file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.iv');
							$a27e64cc6ce01033 = XUI::bC69afFE50d85273($add193137cabeea7, basename($d55bf693d0ece21c), $F2735dad02d30e84, true);
							echo openssl_encrypt($a27e64cc6ce01033, 'aes-128-cbc', $D3fa098be3f297cd, OPENSSL_RAW_DATA, $e7ae92f8387d5936);
						} else {
							XUI::BC69AfFe50D85273($add193137cabeea7, basename($d55bf693d0ece21c), $F2735dad02d30e84);
						}

						unlink(SIGNALS_PATH . $B08b62d9f7870287);

						exit();
					}
				}

				if ($F2d4d8f7981ac574['encrypt_hls']) {
					$bc945723c41af777 = explode('_', pathinfo($B1c1aa7e8b5b4849)['filename']);

					if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_' . $bc945723c41af777[1] . '.ts')) {
					} else {
						dB709ED65Ae02245();
					}

					if (file_exists($d55bf693d0ece21c . '.enc_write')) {
						$Aae09861fbc788ec = 0;

						if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur')) {
							$b73e9a5cd67eae9b = intval(file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.dur')) * 2;
						} else {
							$b73e9a5cd67eae9b = $F2d4d8f7981ac574['seg_time'] * 2;
						}

						while (file_exists($d55bf693d0ece21c . '.enc_write') && !file_exists($d55bf693d0ece21c . '.enc') && $Aae09861fbc788ec <= $b73e9a5cd67eae9b * 10) {
							usleep(100000);
							$Aae09861fbc788ec++;
						}
					} else {
						ignore_user_abort(true);
						touch($d55bf693d0ece21c . '.enc_write');
						$D3fa098be3f297cd = file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.key');
						$e7ae92f8387d5936 = file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.iv');
						$a27e64cc6ce01033 = openssl_encrypt(file_get_contents($d55bf693d0ece21c), 'aes-128-cbc', $D3fa098be3f297cd, OPENSSL_RAW_DATA, $e7ae92f8387d5936);
						file_put_contents($d55bf693d0ece21c . '.enc', $a27e64cc6ce01033);
						unset($a27e64cc6ce01033);
						unlink($d55bf693d0ece21c . '.enc_write');
						ignore_user_abort(false);
					}

					if (file_exists($d55bf693d0ece21c . '.enc')) {
						header('Content-Length: ' . filesize($d55bf693d0ece21c . '.enc'));
						readfile($d55bf693d0ece21c . '.enc');
					} else {
						dB709ED65ae02245();
					}
				} else {
					header('Content-Length: ' . $F0d235f3dbb503a5);
					readfile($d55bf693d0ece21c);
				}
			} else {
				if (0 < $db752e19806388c2) {
					header('Content-Length: ' . ($F0d235f3dbb503a5 - $db752e19806388c2));
					$e1644d67f855686d = @fopen($d55bf693d0ece21c, 'rb');

					if (!$e1644d67f855686d) {
					} else {
						fseek($e1644d67f855686d, $db752e19806388c2);

						while (!feof($e1644d67f855686d)) {
							echo stream_get_line($e1644d67f855686d, $F2d4d8f7981ac574['read_buffer_size']);
						}
						fclose($e1644d67f855686d);
					}
				} else {
					header('Content-Length: ' . $F0d235f3dbb503a5);
					readfile($d55bf693d0ece21c);
				}
			}

			exit();
		}

		if ($a8bb73cba48fb7f6[$d58b4f8653a391d8]['random_ip'] && 0 < count($a8bb73cba48fb7f6[$d58b4f8653a391d8]['domains']['urls'])) {
			$C700a2b357e5ed65 = $a8bb73cba48fb7f6[$d58b4f8653a391d8]['domains']['protocol'] . '://' . $a8bb73cba48fb7f6[$d58b4f8653a391d8]['domains']['urls'][array_rand($a8bb73cba48fb7f6[$d58b4f8653a391d8]['domains']['urls'])] . ':' . $a8bb73cba48fb7f6[$d58b4f8653a391d8]['domains']['port'];
		} else {
			$C700a2b357e5ed65 = rtrim($a8bb73cba48fb7f6[$d58b4f8653a391d8]['site_url'], '/');
		}

		header('Location: ' . $C700a2b357e5ed65 . '/hls/' . $_GET['token']);

		exit();
	}
}

DB709Ed65AE02245();
function c29c46A45e7A2107()
{
	return $_SERVER['REMOTE_ADDR'];
}
