<?php

require_once 'init.php';
header('Access-Control-Allow-Origin: *');

if (empty(XUI::$rSettings['send_server_header'])) {
} else {
	header('Server: ' . XUI::$rSettings['send_server_header']);
}

if (!XUI::$rSettings['send_protection_headers']) {
} else {
	header('X-XSS-Protection: 0');
	header('X-Content-Type-Options: nosniff');
}

if (!XUI::$rSettings['send_altsvc_header']) {
} else {
	header('Alt-Svc: h3-29=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-T051=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q050=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q046=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q043=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,quic=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000; v="46,43"');
}

if (!empty(XUI::$rSettings['send_unique_header_domain']) || filter_var(HOST, FILTER_VALIDATE_IP)) {
} else {
	XUI::$rSettings['send_unique_header_domain'] = '.' . HOST;
}

if (empty(XUI::$rSettings['send_unique_header'])) {
} else {
	$bae85948a6f4b7de = new DateTime('+6 months', new DateTimeZone('GMT'));
	header('Set-Cookie: ' . XUI::$rSettings['send_unique_header'] . '=' . XUI::bB7f1b0eD6c4B87D(11) . '; Domain=' . XUI::$rSettings['send_unique_header_domain'] . '; Expires=' . $bae85948a6f4b7de->format(DATE_RFC2822) . '; Path=/; Secure; HttpOnly; SameSite=none');
}

$F26087d31c2bbe4d = null;

if (!isset(XUI::$rRequest['token'])) {
} else {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['token'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);

	if (is_array($F64d974c429d80be) && !(isset($F64d974c429d80be['expires']) && $F64d974c429d80be['expires'] < time() - intval(XUI::$rServers[SERVER_ID]['time_offset']))) {
	} else {
		generateError('TOKEN_EXPIRED');
	}

	$F26087d31c2bbe4d = $F64d974c429d80be['stream'];
}

if ($F26087d31c2bbe4d && file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg') && time() - filemtime(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg') < 60) {
	header('Age: ' . intval(time() - filemtime(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg')));
	header('Content-type: image/jpg');
	echo file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.jpg');

	exit();
}

generateError('THUMBNAIL_DOESNT_EXIST');
