<?php

register_shutdown_function('shutdown');
set_time_limit(0);
require_once 'init.php';
unset(XUI::$rSettings['watchdog_data'], XUI::$rSettings['server_hardware']);

header('Access-Control-Allow-Origin: *');

if (empty(XUI::$rSettings['send_server_header'])) {
} else {
	header('Server: ' . XUI::$rSettings['send_server_header']);
}

if (!XUI::$rSettings['send_protection_headers']) {
} else {
	header('X-XSS-Protection: 0');
	header('X-Content-Type-Options: nosniff');
}

if (!XUI::$rSettings['send_altsvc_header']) {
} else {
	header('Alt-Svc: h3-29=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-T051=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q050=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q046=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q043=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,quic=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000; v="46,43"');
}

if (!empty(XUI::$rSettings['send_unique_header_domain']) || filter_var(HOST, FILTER_VALIDATE_IP)) {
} else {
	XUI::$rSettings['send_unique_header_domain'] = '.' . HOST;
}

if (empty(XUI::$rSettings['send_unique_header'])) {
} else {
	$bae85948a6f4b7de = new DateTime('+6 months', new DateTimeZone('GMT'));
	header('Set-Cookie: ' . XUI::$rSettings['send_unique_header'] . '=' . XUI::bb7f1B0ed6C4b87D(11) . '; Domain=' . XUI::$rSettings['send_unique_header_domain'] . '; Expires=' . $bae85948a6f4b7de->format(DATE_RFC2822) . '; Path=/; Secure; HttpOnly; SameSite=none');
}

$D7102b1e2b296e66 = 60;
$b2a9243e8304033d = null;
$c59ec257c284c894 = XUI::A9Bc416fa6fa55c3();
$b3374866087774a1 = (empty($_SERVER['HTTP_USER_AGENT']) ? '' : htmlentities(trim($_SERVER['HTTP_USER_AGENT'])));
$f2d1c7bb81b31b19 = null;
$b25be5f9af7a0a91 = 0;
$Df5a05fb37ec64f1 = false;
$f9b07d216a168dcc = getmypid();
$D78b6d56a11571aa = false;

if (isset(XUI::$rRequest['token'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['token'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);

	if (is_array($F64d974c429d80be)) {
	} else {
		XUI::ea6c9A31F15a7B61(0, 0, 'LB_TOKEN_INVALID', $c59ec257c284c894);
		generateError('LB_TOKEN_INVALID');
	}

	if (!(isset($F64d974c429d80be['expires']) && $F64d974c429d80be['expires'] < time() - intval(XUI::$rServers[SERVER_ID]['time_offset']))) {
	} else {
		generateError('TOKEN_EXPIRED');
	}

	if (isset($F64d974c429d80be['hmac_id'])) {
		$B08e7d3cd339391a = $F64d974c429d80be['hmac_id'];
		$E18c40e895ee55c2 = $F64d974c429d80be['identifier'];
	} else {
		$a71afc14d6cd090d = $F64d974c429d80be['username'];
		$d5249dad8e8411b7 = $F64d974c429d80be['password'];
	}

	$F26087d31c2bbe4d = intval($F64d974c429d80be['stream_id']);
	$F9452a7efafa1aba = $F64d974c429d80be['extension'];
	$E379394c7b1a273f = $F64d974c429d80be['type'];
	$fca7edf85daa1695 = $F64d974c429d80be['channel_info'];
	$D4253f9520627819 = $F64d974c429d80be['user_info'];
	$ffc0436d3fdc5100 = $F64d974c429d80be['activity_start'];
	$efc0f8f3059e4104 = $F64d974c429d80be['country_code'];
	$D78b6d56a11571aa = $F64d974c429d80be['is_mag'];
	$f3a168862191a4af = ($fca7edf85daa1695['proxy'] ?: null);

	if (empty($F64d974c429d80be['http_range']) || isset($_SERVER['HTTP_RANGE'])) {
	} else {
		$_SERVER['HTTP_RANGE'] = $F64d974c429d80be['http_range'];
	}
} else {
	generateError('NO_TOKEN_SPECIFIED');
}

$F7b9e954f715ab5e = VOD_PATH . $F26087d31c2bbe4d . '.' . $F9452a7efafa1aba;

if (file_exists($F7b9e954f715ab5e) || $f3a168862191a4af) {
} else {
	generateError('VOD_DOESNT_EXIST');
}

if (XUI::$rSettings['use_buffer'] != 0) {
} else {
	header('X-Accel-Buffering: no');
}

if ($fca7edf85daa1695) {
	if ($fca7edf85daa1695['originator_id']) {
		$d58b4f8653a391d8 = $fca7edf85daa1695['originator_id'];
		$b2a9243e8304033d = $fca7edf85daa1695['redirect_id'];
	} else {
		$d58b4f8653a391d8 = ($fca7edf85daa1695['redirect_id'] ?: SERVER_ID);
		$b2a9243e8304033d = null;
	}

	if (XUI::$rSettings['redis_handler']) {
		XUI::BfA8b6FE314dED7F();
	} else {
		XUI::aD0a56bE17E95e81();
	}

	if (XUI::$rSettings['redis_handler']) {
		$e110a2ab6d3a4734 = XUI::B85CCceF157fB67B($F64d974c429d80be['uuid']);
	} else {
		XUI::$db->query('SELECT `server_id`, `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `uuid` = ?;', $F64d974c429d80be['uuid']);

		if (0 < XUI::$db->num_rows()) {
			$e110a2ab6d3a4734 = XUI::$db->get_row();
		} else {
			if (empty($_SERVER['HTTP_RANGE'])) {
			} else {
				if (!$B08e7d3cd339391a) {
					XUI::$db->query('SELECT `server_id`, `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `user_id` = ? AND `container` = ? AND `user_agent` = ? AND `stream_id` = ?;', $D4253f9520627819['id'], 'VOD', $b3374866087774a1, $F26087d31c2bbe4d);
				} else {
					XUI::$db->query('SELECT `server_id`, `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `hmac_id` = ? AND `hmac_identifier` = ? AND `container` = ? AND `user_agent` = ? AND `stream_id` = ?;', $B08e7d3cd339391a, $E18c40e895ee55c2, 'VOD', $b3374866087774a1, $F26087d31c2bbe4d);
				}

				if (0 >= XUI::$db->num_rows()) {
				} else {
					$e110a2ab6d3a4734 = XUI::$db->get_row();
				}
			}
		}
	}

	if (!$e110a2ab6d3a4734) {
		if (file_exists(CONS_TMP_PATH . $F64d974c429d80be['uuid']) || ($ffc0436d3fdc5100 + $D7102b1e2b296e66) - intval(XUI::$rServers[SERVER_ID]['time_offset']) >= time()) {
		} else {
			generateError('TOKEN_EXPIRED');
		}

		if (!$B08e7d3cd339391a) {
			if (XUI::$rSettings['redis_handler']) {
				$Fc9594978cb1834f = array('user_id' => $D4253f9520627819['id'], 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => 'VOD', 'pid' => $f9b07d216a168dcc, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => '', 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => 0, 'identity' => $D4253f9520627819['id'], 'uuid' => $F64d974c429d80be['uuid']);
				$B59c127fecf35c15 = XUI::e0c928a3a83f24E9($Fc9594978cb1834f);
			} else {
				$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`user_id`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?);', $D4253f9520627819['id'], $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, 'VOD', $f9b07d216a168dcc, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);
			}
		} else {
			if (XUI::$rSettings['redis_handler']) {
				$Fc9594978cb1834f = array('hmac_id' => $B08e7d3cd339391a, 'hmac_identifier' => $E18c40e895ee55c2, 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => 'VOD', 'pid' => $f9b07d216a168dcc, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => '', 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => 0, 'identity' => $B08e7d3cd339391a . '_' . $E18c40e895ee55c2, 'uuid' => $F64d974c429d80be['uuid']);
				$B59c127fecf35c15 = XUI::E0C928A3A83f24E9($Fc9594978cb1834f);
			} else {
				$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`hmac_id`,`hmac_identifier`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', $B08e7d3cd339391a, $E18c40e895ee55c2, $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, 'VOD', $f9b07d216a168dcc, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);
			}
		}
	} else {
		$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $e110a2ab6d3a4734['user_ip']), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $e110a2ab6d3a4734['user_ip'] == $c59ec257c284c894);

		if ($ee7553b0caebc8c4 || !XUI::$rSettings['restrict_same_ip']) {
		} else {
			XUI::ea6C9A31F15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_MISMATCH', $c59ec257c284c894);
			generateError('IP_MISMATCH');
		}

		if (!(XUI::DD714Ee89C59fBf2($e110a2ab6d3a4734['pid'], 'php-fpm') && $f9b07d216a168dcc != $e110a2ab6d3a4734['pid'] && is_numeric($e110a2ab6d3a4734['pid']) && 0 < $e110a2ab6d3a4734['pid'])) {
		} else {
			if ($e110a2ab6d3a4734['server_id'] == SERVER_ID) {
				posix_kill(intval($e110a2ab6d3a4734['pid']), 9);
			} else {
				XUI::$db->query('INSERT INTO `signals` (`pid`,`server_id`,`time`) VALUES(?,?,UNIX_TIMESTAMP())', $e110a2ab6d3a4734['pid'], $e110a2ab6d3a4734['server_id']);
			}
		}

		if (XUI::$rSettings['redis_handler']) {
			$a6b40128767dfe4f = array('pid' => $f9b07d216a168dcc, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));

			if ($e110a2ab6d3a4734 = XUI::e3484f74D3c8b5a7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'open')) {
				$B59c127fecf35c15 = true;
			} else {
				$B59c127fecf35c15 = false;
			}
		} else {
			$B59c127fecf35c15 = XUI::$db->query('UPDATE `lines_live` SET `hls_end` = 0, `pid` = ? WHERE `activity_id` = ?;', $f9b07d216a168dcc, $e110a2ab6d3a4734['activity_id']);
		}
	}

	if ($B59c127fecf35c15) {
	} else {
		XUI::EA6C9a31F15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'LINE_CREATE_FAIL', $c59ec257c284c894);
		generateError('LINE_CREATE_FAIL');
	}

	XUI::De9e9e0d836b5d86($D4253f9520627819, $B08e7d3cd339391a, $E18c40e895ee55c2, $c59ec257c284c894, $b3374866087774a1);

	if (XUI::$rSettings['redis_handler']) {
		XUI::b0B419a0354a0297();
	} else {
		XUI::f6cC02011179DfC7();
	}

	$Df5a05fb37ec64f1 = true;

	if (!XUI::$rSettings['monitor_connection_status']) {
	} else {
		ob_implicit_flush(true);

		while (ob_get_level()) {
			ob_end_clean();
		}
	}

	touch(CONS_TMP_PATH . $F64d974c429d80be['uuid']);

	if (!$f3a168862191a4af) {
		$f2d1c7bb81b31b19 = DIVERGENCE_TMP_PATH . $F64d974c429d80be['uuid'];

		switch ($fca7edf85daa1695['target_container']) {
			case 'mp4':
			case 'm4v':
				header('Content-type: video/mp4');

				break;

			case 'mkv':
				header('Content-type: video/x-matroska');

				break;

			case 'avi':
				header('Content-type: video/x-msvideo');

				break;

			case '3gp':
				header('Content-type: video/3gpp');

				break;

			case 'flv':
				header('Content-type: video/x-flv');

				break;

			case 'wmv':
				header('Content-type: video/x-ms-wmv');

				break;

			case 'mov':
				header('Content-type: video/quicktime');

				break;

			case 'ts':
				header('Content-type: video/mp2t');

				break;

			case 'mpg':
			case 'mpeg':
				header('Content-Type: video/mpeg');

				break;

			default:
				header('Content-Type: application/octet-stream');
		}
		$F47a81e1c4194642 = (!empty($fca7edf85daa1695['bitrate']) ? $fca7edf85daa1695['bitrate'] * 125 : 0);
		$F47a81e1c4194642 += $F47a81e1c4194642 * XUI::$rSettings['vod_bitrate_plus'] * 0.01;
		$F7b9e954f715ab5e = VOD_PATH . $F26087d31c2bbe4d . '.' . $F9452a7efafa1aba;

		if (!file_exists($F7b9e954f715ab5e)) {
		} else {
			$e1644d67f855686d = @fopen($F7b9e954f715ab5e, 'rb');
			$b6c1b012e942c0b8 = filesize($F7b9e954f715ab5e);
			$f0434521ea9d1547 = $b6c1b012e942c0b8;
			$D031c48a1422c07e = 0;
			$ae0b1e2a40cbc62a = $b6c1b012e942c0b8 - 1;
			header('Accept-Ranges: 0-' . $f0434521ea9d1547);

			if (empty($_SERVER['HTTP_RANGE'])) {
			} else {
				$f52aa5b1fe06dc56 = $D031c48a1422c07e;
				$e151114d7468d71c = $ae0b1e2a40cbc62a;
				list(, $c049b11cb92e6052) = explode('=', $_SERVER['HTTP_RANGE'], 2);

				if (strpos($c049b11cb92e6052, ',') === false) {
					if ($c049b11cb92e6052 == '-') {
						$f52aa5b1fe06dc56 = $b6c1b012e942c0b8 - substr($c049b11cb92e6052, 1);
					} else {
						$c049b11cb92e6052 = explode('-', $c049b11cb92e6052);
						$f52aa5b1fe06dc56 = $c049b11cb92e6052[0];
						$e151114d7468d71c = (isset($c049b11cb92e6052[1]) && is_numeric($c049b11cb92e6052[1]) ? $c049b11cb92e6052[1] : $b6c1b012e942c0b8);
					}

					$e151114d7468d71c = ($ae0b1e2a40cbc62a < $e151114d7468d71c ? $ae0b1e2a40cbc62a : $e151114d7468d71c);

					if (!($e151114d7468d71c < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 - 1 < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 <= $e151114d7468d71c)) {
						$D031c48a1422c07e = $f52aa5b1fe06dc56;
						$ae0b1e2a40cbc62a = $e151114d7468d71c;
						$f0434521ea9d1547 = $ae0b1e2a40cbc62a - $D031c48a1422c07e + 1;
						fseek($e1644d67f855686d, $D031c48a1422c07e);
						header('HTTP/1.1 206 Partial Content');
					} else {
						header('HTTP/1.1 416 Requested Range Not Satisfiable');
						header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

						exit();
					}
				} else {
					header('HTTP/1.1 416 Requested Range Not Satisfiable');
					header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

					exit();
				}
			}

			header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);
			header('Content-Length: ' . $f0434521ea9d1547);
			$Af547236269d8f66 = $B03be4d52f9e9b56 = $fc5ed655689a77b9 = time();
			$A327a54e7e10cd21 = 0;
			$b9f3f039ea3bf5ca = XUI::$rSettings['read_buffer_size'];
			$Ea22c4a9ab5b2176 = 0;
			$B75243d4c517712f = 0;

			if (0 < XUI::$rSettings['vod_limit_perc'] && !$D4253f9520627819['is_restreamer']) {
				$bd349a495a615ef5 = intval($f0434521ea9d1547 * floatval(XUI::$rSettings['vod_limit_perc'] / 100));
			} else {
				$bd349a495a615ef5 = $f0434521ea9d1547;
			}

			$c8d3b0fbe810a1c6 = false;

			while (!feof($e1644d67f855686d) && ($c5f42eb7bf40a43a = ftell($e1644d67f855686d)) <= $ae0b1e2a40cbc62a) {
				$c7488e8420e934e2 = stream_get_line($e1644d67f855686d, $b9f3f039ea3bf5ca);
				$Ea22c4a9ab5b2176++;

				if (!$c8d3b0fbe810a1c6 && $bd349a495a615ef5 <= $B75243d4c517712f * $b9f3f039ea3bf5ca) {
					$c8d3b0fbe810a1c6 = true;
				} else {
					$B75243d4c517712f++;
				}

				echo $c7488e8420e934e2;
				$A327a54e7e10cd21 += strlen($c7488e8420e934e2);

				if (30 > time() - $B03be4d52f9e9b56) {
				} else {
					file_put_contents($f2d1c7bb81b31b19, intval($A327a54e7e10cd21 / 1024 / 30));
					$B03be4d52f9e9b56 = time();
					$A327a54e7e10cd21 = 0;
				}

				if (!(0 < $F47a81e1c4194642 && $c8d3b0fbe810a1c6 && ceil($F47a81e1c4194642 / $b9f3f039ea3bf5ca) <= $Ea22c4a9ab5b2176)) {
				} else {
					sleep(1);
					$Ea22c4a9ab5b2176 = 0;
				}

				if (!(XUI::$rSettings['monitor_connection_status'] && 5 <= time() - $fc5ed655689a77b9)) {
				} else {
					if (connection_status() == CONNECTION_NORMAL) {
						$fc5ed655689a77b9 = time();
					} else {
						exit();
					}
				}

				if (300 > time() - $Af547236269d8f66) {
				} else {
					$Af547236269d8f66 = time();
					$e110a2ab6d3a4734 = null;
					XUI::$rSettings = XUI::AbB674425a8B1B0d('settings');

					if (XUI::$rSettings['redis_handler']) {
						XUI::BfA8b6FE314DeD7f();
						$e110a2ab6d3a4734 = XUI::B85cCCeF157fb67b($F64d974c429d80be['uuid']);
						XUI::b0B419A0354a0297();
					} else {
						XUI::aD0a56bE17E95E81();
						XUI::$db->query('SELECT `pid`, `hls_end` FROM `lines_live` WHERE `uuid` = ?', $F64d974c429d80be['uuid']);

						if (XUI::$db->num_rows() != 1) {
						} else {
							$e110a2ab6d3a4734 = XUI::$db->get_row();
						}

						XUI::f6cC02011179DFc7();
					}

					if (!(!is_array($e110a2ab6d3a4734) || $e110a2ab6d3a4734['hls_end'] != 0 || $e110a2ab6d3a4734['pid'] != $f9b07d216a168dcc)) {
					} else {
						exit();
					}
				}
			}
			fclose($e1644d67f855686d);

			exit();
		}
	} else {
		$Ae2b613e51651b56 = get_headers($f3a168862191a4af, 1);
		$c196718c8d49a297 = (is_array($Ae2b613e51651b56['Content-Type']) ? $Ae2b613e51651b56['Content-Type'][count($Ae2b613e51651b56['Content-Type']) - 1] : $Ae2b613e51651b56['Content-Type']);
		$b6c1b012e942c0b8 = $f0434521ea9d1547 = $Ae2b613e51651b56['Content-Length'];

		if (0 < $f0434521ea9d1547 && in_array($c196718c8d49a297, array('video/mp4', 'video/x-matroska', 'video/x-msvideo', 'video/3gpp', 'video/x-flv', 'video/x-ms-wmv', 'video/quicktime', 'video/mp2t', 'video/mpeg', 'application/octet-stream'))) {
			if (!$Ae2b613e51651b56['Location']) {
			} else {
				$f3a168862191a4af = $Ae2b613e51651b56['Location'];
			}

			header('Content-Type: ' . $c196718c8d49a297);
			header('Accept-Ranges: bytes');
			$D031c48a1422c07e = 0;
			$ae0b1e2a40cbc62a = $b6c1b012e942c0b8 - 1;

			if (empty($_SERVER['HTTP_RANGE'])) {
			} else {
				$f52aa5b1fe06dc56 = $D031c48a1422c07e;
				$e151114d7468d71c = $ae0b1e2a40cbc62a;
				list(, $c049b11cb92e6052) = explode('=', $_SERVER['HTTP_RANGE'], 2);

				if (strpos($c049b11cb92e6052, ',') === false) {
					if ($c049b11cb92e6052 == '-') {
						$f52aa5b1fe06dc56 = $b6c1b012e942c0b8 - substr($c049b11cb92e6052, 1);
					} else {
						$c049b11cb92e6052 = explode('-', $c049b11cb92e6052);
						$f52aa5b1fe06dc56 = $c049b11cb92e6052[0];
						$e151114d7468d71c = (isset($c049b11cb92e6052[1]) && is_numeric($c049b11cb92e6052[1]) ? $c049b11cb92e6052[1] : $b6c1b012e942c0b8);
					}

					$e151114d7468d71c = ($ae0b1e2a40cbc62a < $e151114d7468d71c ? $ae0b1e2a40cbc62a : $e151114d7468d71c);

					if (!($e151114d7468d71c < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 - 1 < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 <= $e151114d7468d71c)) {
						$D031c48a1422c07e = $f52aa5b1fe06dc56;
						$ae0b1e2a40cbc62a = $e151114d7468d71c;
						$f0434521ea9d1547 = $ae0b1e2a40cbc62a - $D031c48a1422c07e + 1;
						header('HTTP/1.1 206 Partial Content');
					} else {
						header('HTTP/1.1 416 Requested Range Not Satisfiable');
						header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

						exit();
					}
				} else {
					header('HTTP/1.1 416 Requested Range Not Satisfiable');
					header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

					exit();
				}
			}

			header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);
			header('Content-Length: ' . $f0434521ea9d1547);
			$c88afcbaf19918af = curl_init();

			if (!isset($_SERVER['HTTP_RANGE'])) {
			} else {
				preg_match('/bytes=(\\d+)-(\\d+)?/', $_SERVER['HTTP_RANGE'], $b85ce31cd1118ad2);
				$db752e19806388c2 = intval($b85ce31cd1118ad2[1]);
				$f0434521ea9d1547 = $b6c1b012e942c0b8 - $db752e19806388c2 - 1;
				$Ae2b613e51651b56 = array('Range: bytes=' . $db752e19806388c2 . '-' . ($db752e19806388c2 + $f0434521ea9d1547));
				curl_setopt($c88afcbaf19918af, CURLOPT_HTTPHEADER, $Ae2b613e51651b56);
			}

			if (512 * 1024 * 1024 >= $b6c1b012e942c0b8) {
			} else {
				$bb01f60a0bafcfc7 = (!empty($fca7edf85daa1695['bitrate']) ? ($b6c1b012e942c0b8 * 0.008) / $fca7edf85daa1695['bitrate'] * 125 * 3 : 20 * 1024 * 1024);

				if ($bb01f60a0bafcfc7 >= 1 * 1024 * 1024) {
				} else {
					$bb01f60a0bafcfc7 = 1 * 1024 * 1024;
				}

				curl_setopt($c88afcbaf19918af, CURLOPT_MAX_RECV_SPEED_LARGE, intval($bb01f60a0bafcfc7));
			}

			curl_setopt($c88afcbaf19918af, CURLOPT_BUFFERSIZE, 10 * 1024 * 1024);
			curl_setopt($c88afcbaf19918af, CURLOPT_VERBOSE, 1);
			curl_setopt($c88afcbaf19918af, CURLOPT_TIMEOUT, 0);
			curl_setopt($c88afcbaf19918af, CURLOPT_URL, $f3a168862191a4af);
			curl_setopt($c88afcbaf19918af, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($c88afcbaf19918af, CURLOPT_HEADER, false);
			curl_setopt($c88afcbaf19918af, CURLOPT_FRESH_CONNECT, true);
			curl_setopt($c88afcbaf19918af, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($c88afcbaf19918af, CURLOPT_NOBODY, false);
			curl_setopt($c88afcbaf19918af, CURLOPT_RETURNTRANSFER, false);
			curl_exec($c88afcbaf19918af);

			exit();
		}

		generateError('VOD_DOESNT_EXIST');
	}
} else {
	generateError('TOKEN_ERROR');
}

function shutdown()
{
	global $Df5a05fb37ec64f1;
	global $F64d974c429d80be;
	global $f9b07d216a168dcc;
	XUI::$rSettings = XUI::AbB674425A8B1b0D('settings');

	if (!$Df5a05fb37ec64f1) {
	} else {
		if (XUI::$rSettings['redis_handler']) {
			if (is_object(XUI::$redis)) {
			} else {
				XUI::BfA8b6fE314dED7F();
			}

			$e110a2ab6d3a4734 = XUI::B85ccCef157fb67B($F64d974c429d80be['uuid']);

			if (!($e110a2ab6d3a4734 && $e110a2ab6d3a4734['pid'] == $f9b07d216a168dcc)) {
			} else {
				$a6b40128767dfe4f = array('hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));
				XUI::e3484F74D3C8B5a7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'close');
			}
		} else {
			if (is_object(XUI::$db)) {
			} else {
				XUI::aD0a56be17e95E81();
			}

			XUI::$db->query('UPDATE `lines_live` SET `hls_end` = 1, `hls_last_read` = ? WHERE `uuid` = ? AND `pid` = ?;', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), $F64d974c429d80be['uuid'], $f9b07d216a168dcc);
		}
	}

	if (!XUI::$rSettings['redis_handler'] && is_object(XUI::$db)) {
		XUI::F6Cc02011179dFC7();
	} else {
		if (!(XUI::$rSettings['redis_handler'] && is_object(XUI::$redis))) {
		} else {
			XUI::b0b419a0354a0297();
		}
	}
}
