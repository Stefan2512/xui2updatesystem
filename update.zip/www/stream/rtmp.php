<?php

if (!($_GET['addr'] == '127.0.0.1' && $_GET['call'] == 'publish')) {
	register_shutdown_function('shutdown');
	set_time_limit(0);
	require_once 'init.php';
	error_reporting(0);
	ini_set('display_errors', 0);
	$E3b8f15bd840a0df = XUI::D7ac04307F564Fa4();
	$Dab081f66facd7a3 = true;

	if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1') {
	} else {
		dB709ed65ae02245();
	}

	$c59ec257c284c894 = XUI::$rRequest['addr'];
	$F26087d31c2bbe4d = intval(XUI::$rRequest['name']);
	$eea4d80c225a9119 = false;

	foreach (getallheaders() as $D3fa098be3f297cd => $b6842cb20051e925) {
		if (strtoupper($D3fa098be3f297cd) != 'X-XUI-DETECT') {
		} else {
			$eea4d80c225a9119 = true;
		}
	}

	if (XUI::$rRequest['call'] != 'publish') {
		if (XUI::$rRequest['call'] != 'play_done') {
			if (!(XUI::$rRequest['password'] == XUI::$rSettings['live_streaming_pass'] || isset($E3b8f15bd840a0df[$c59ec257c284c894]) && $E3b8f15bd840a0df[$c59ec257c284c894]['pull'] && ($E3b8f15bd840a0df[$c59ec257c284c894]['password'] == XUI::$rRequest['password'] || !$E3b8f15bd840a0df[$c59ec257c284c894]['password']))) {
				if (isset(XUI::$rRequest['tcurl']) && isset(XUI::$rRequest['app'])) {
					if (isset(XUI::$rRequest['token'])) {
						if (!ctype_xdigit(XUI::$rRequest['token'])) {
							$F64d974c429d80be = explode('/', Xui\Functions::decrypt(XUI::$rRequest['token'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA));
							list($a71afc14d6cd090d, $d5249dad8e8411b7) = $F64d974c429d80be;
							$D4253f9520627819 = XUI::d7cA435AC70e9A78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, true, false, $c59ec257c284c894);
						} else {
							$F2eeef4457c0cddc = XUI::$rRequest['token'];
							$D4253f9520627819 = XUI::d7CA435aC70E9A78(null, $F2eeef4457c0cddc, null, true, false, $c59ec257c284c894);
						}
					} else {
						$a71afc14d6cd090d = XUI::$rRequest['username'];
						$d5249dad8e8411b7 = XUI::$rRequest['password'];
						$D4253f9520627819 = XUI::D7ca435ac70e9A78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, true, false, $c59ec257c284c894);
					}

					$F9452a7efafa1aba = 'rtmp';
					$d080620e03289080 = '';

					if ($D4253f9520627819) {
						$Dab081f66facd7a3 = false;

						if (is_null($D4253f9520627819['exp_date']) || $D4253f9520627819['exp_date'] > time()) {
							if ($D4253f9520627819['admin_enabled'] != 0) {
								if ($D4253f9520627819['enabled'] != 0) {
									if (empty($D4253f9520627819['allowed_ips']) || in_array($c59ec257c284c894, array_map('gethostbyname', $D4253f9520627819['allowed_ips']))) {
										$efc0f8f3059e4104 = XUI::b74f652C92Cec688($c59ec257c284c894)['country']['iso_code'];

										if (empty($efc0f8f3059e4104)) {
										} else {
											$ac720430e021c8c0 = !empty($D4253f9520627819['forced_country']);

											if (!($ac720430e021c8c0 && $D4253f9520627819['forced_country'] != 'ALL' && $efc0f8f3059e4104 != $D4253f9520627819['forced_country'])) {
												if ($ac720430e021c8c0 || in_array('ALL', XUI::$rSettings['allow_countries']) || in_array($efc0f8f3059e4104, XUI::$rSettings['allow_countries'])) {
												} else {
													XUI::eA6c9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'COUNTRY_DISALLOW', $c59ec257c284c894);
													http_response_code(404);

													exit();
												}
											} else {
												XUI::Ea6C9a31F15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'COUNTRY_DISALLOW', $c59ec257c284c894);
												http_response_code(404);

												exit();
											}
										}

										if (!isset($D4253f9520627819['ip_limit_reached'])) {
											if (in_array($F9452a7efafa1aba, $D4253f9520627819['output_formats'])) {
												if (in_array($F26087d31c2bbe4d, $D4253f9520627819['channel_ids'])) {
													if ($D4253f9520627819['isp_violate'] != 1) {
														if ($D4253f9520627819['isp_is_server'] != 1 || $D4253f9520627819['is_restreamer']) {
															if (!$eea4d80c225a9119 || $D4253f9520627819['is_restreamer']) {
																if (!($fca7edf85daa1695 = XUI::B3eD925e7969F61A($F26087d31c2bbe4d, $F9452a7efafa1aba, $D4253f9520627819, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], 'live'))) {
																} else {
																	if (!$fca7edf85daa1695['redirect_id'] || $fca7edf85daa1695['redirect_id'] == SERVER_ID) {
																		if (XUI::f74fA4748B081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
																		} else {
																			if ($fca7edf85daa1695['on_demand'] == 1) {
																				if (XUI::Ea4A2063e98bAef8($fca7edf85daa1695['monitor_pid'], $F26087d31c2bbe4d)) {
																				} else {
																					XUI::dAC4d82F05378662($F26087d31c2bbe4d);
																					sleep(5);
																				}
																			} else {
																				http_response_code(404);

																				exit();
																			}
																		}

																		if (XUI::$rSettings['redis_handler']) {
																			XUI::BfA8B6fe314DEd7f();
																			$Fc9594978cb1834f = array('user_id' => $D4253f9520627819['id'], 'stream_id' => $F26087d31c2bbe4d, 'server_id' => SERVER_ID, 'proxy_id' => 0, 'user_agent' => '', 'user_ip' => $c59ec257c284c894, 'container' => $F9452a7efafa1aba, 'pid' => XUI::$rRequest['clientid'], 'date_start' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => $d080620e03289080, 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => $fca7edf85daa1695['on_demand'], 'identity' => $D4253f9520627819['id'], 'uuid' => md5(XUI::$rRequest['clientid']));
																			$B59c127fecf35c15 = XUI::e0c928A3a83f24E9($Fc9594978cb1834f);
																		} else {
																			$B59c127fecf35c15 = $Fee0d5a474c96306->query('INSERT INTO `lines_live` (`user_id`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', $D4253f9520627819['id'], $F26087d31c2bbe4d, SERVER_ID, 0, '', $c59ec257c284c894, $F9452a7efafa1aba, XUI::$rRequest['clientid'], md5(XUI::$rRequest['clientid']), time(), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], $d080620e03289080);
																		}

																		if ($B59c127fecf35c15) {
																			XUI::de9e9E0d836b5d86($D4253f9520627819, false, '', $c59ec257c284c894, null);
																			http_response_code(200);

																			exit();
																		}

																		XUI::EA6c9a31f15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'LINE_CREATE_FAIL', $c59ec257c284c894);
																		http_response_code(404);

																		exit();
																	}

																	http_response_code(404);

																	exit();
																}
															} else {
																if (!XUI::$rSettings['detect_restream_block_user']) {
																} else {
																	$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $D4253f9520627819['id']);
																}

																XUI::Ea6c9A31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'RESTREAM_DETECT', $c59ec257c284c894);
																http_response_code(404);

																exit();
															}
														} else {
															XUI::EA6C9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'BLOCKED_ASN', $c59ec257c284c894, json_encode(array('user_agent' => '', 'isp' => $D4253f9520627819['con_isp_name'], 'asn' => $D4253f9520627819['isp_asn'])), true);
															http_response_code(404);

															exit();
														}
													} else {
														XUI::ea6C9A31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'ISP_LOCK_FAILED', $c59ec257c284c894, json_encode(array('old' => $D4253f9520627819['isp_desc'], 'new' => $D4253f9520627819['con_isp_name'])));
														http_response_code(404);

														exit();
													}
												} else {
													XUI::ea6C9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'NOT_IN_BOUQUET', $c59ec257c284c894);
													http_response_code(404);

													exit();
												}
											} else {
												XUI::Ea6C9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_DISALLOW_EXT', $c59ec257c284c894);
												http_response_code(404);

												exit();
											}
										} else {
											XUI::ea6c9a31f15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_ALREADY_CONNECTED', $c59ec257c284c894);
											http_response_code(404);

											exit();
										}
									} else {
										XUI::eA6C9A31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_BAN', $c59ec257c284c894);
										http_response_code(404);

										exit();
									}
								} else {
									XUI::eA6c9a31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_DISABLED', $c59ec257c284c894);
									http_response_code(404);

									exit();
								}
							} else {
								XUI::Ea6c9a31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_BAN', $c59ec257c284c894);
								http_response_code(404);

								exit();
							}
						} else {
							XUI::ea6c9A31F15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_EXPIRED', $c59ec257c284c894);
							http_response_code(404);

							exit();
						}
					} else {
						if (!isset($a71afc14d6cd090d)) {
						} else {
							XUI::B6F740fabC7265bf($c59ec257c284c894, null, $a71afc14d6cd090d);
						}

						XUI::EA6C9A31f15A7b61($F26087d31c2bbe4d, 0, 'AUTH_FAILED', $c59ec257c284c894);
					}

					http_response_code(404);

					exit();
				}

				http_response_code(404);

				exit();
			}

			$Dab081f66facd7a3 = false;
			$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_servers` t2 ON t2.stream_id = t1.id AND t2.server_id = ? WHERE t1.`id` = ?', SERVER_ID, $F26087d31c2bbe4d);
			$fca7edf85daa1695 = $Fee0d5a474c96306->get_row();

			if ($fca7edf85daa1695) {
				if (XUI::f74FA4748B081619($fca7edf85daa1695['pid'], $F26087d31c2bbe4d)) {
				} else {
					if ($fca7edf85daa1695['on_demand'] == 1) {
						if (XUI::EA4a2063e98BaEf8($fca7edf85daa1695['monitor_pid'], $F26087d31c2bbe4d)) {
						} else {
							XUI::dAC4d82F05378662($F26087d31c2bbe4d);
							sleep(5);
						}
					} else {
						http_response_code(404);

						exit();
					}
				}

				http_response_code(200);

				exit();
			}

			http_response_code(200);

			exit();
		}

		$Dab081f66facd7a3 = false;

		if (XUI::$rSettings['redis_handler']) {
			XUI::E8e9d6B2b107d8aE(md5(XUI::$rRequest['clientid']));
		} else {
			XUI::f01d5FE0aEC79d52(XUI::$rRequest['clientid']);
		}

		http_response_code(200);

		exit();
	}

	if (XUI::$rRequest['password'] == XUI::$rSettings['live_streaming_pass'] || isset($E3b8f15bd840a0df[$c59ec257c284c894]) && $E3b8f15bd840a0df[$c59ec257c284c894]['push'] && ($E3b8f15bd840a0df[$c59ec257c284c894]['password'] == XUI::$rRequest['password'] || !$E3b8f15bd840a0df[$c59ec257c284c894]['password'])) {
		$Dab081f66facd7a3 = false;
		http_response_code(200);

		exit();
	}

	http_response_code(404);

	exit();
} else {
	http_response_code(200);

	exit();
}

function shutdown()
{
	global $Dab081f66facd7a3;
	global $c59ec257c284c894;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::fC8474658EC80360($c59ec257c284c894);
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
