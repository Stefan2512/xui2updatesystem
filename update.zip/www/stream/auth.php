<?php

header('Cache-Control: no-store, no-cache, must-revalidate');
require_once 'init.php';

if (($F2d4d8f7981ac574['enable_cache'] && !file_exists(CACHE_TMP_PATH . 'cache_complete') || empty($F2d4d8f7981ac574['live_streaming_pass']))) {
	generateError('CACHE_INCOMPLETE');
}

$D78b6d56a11571aa = false;
$Aeadc6eca40ba3fd = null;

if (isset($_GET['token']) && !ctype_xdigit($_GET['token'])) {
	$a27e64cc6ce01033 = explode('/', Xui\Functions::decrypt($_GET['token'], $F2d4d8f7981ac574['live_streaming_pass'], OPENSSL_EXTRA));
	$_GET['type'] = $a27e64cc6ce01033[0];
	$E77573c0f7f19bf9 = explode('::', $_GET['type']);

	if (count($E77573c0f7f19bf9) == 2) {
		$_GET['type'] = $E77573c0f7f19bf9[1];
		$D78b6d56a11571aa = true;
	}

	if ($_GET['type'] == 'timeshift') {
		list(, $_GET['username'], $_GET['password'], $_GET['duration'], $_GET['start'], $_GET['stream']) = $a27e64cc6ce01033;

		if ($D78b6d56a11571aa) {
			$Aeadc6eca40ba3fd = $a27e64cc6ce01033[6];
		}

		$_GET['extension'] = 'ts';
	} else {
		list(, $_GET['username'], $_GET['password'], $_GET['stream']) = $a27e64cc6ce01033;

		if (5 <= count($a27e64cc6ce01033)) {
			$_GET['extension'] = $a27e64cc6ce01033[4];
		}

		if (count($a27e64cc6ce01033) == 6) {
			if ($D78b6d56a11571aa) {
				$Aeadc6eca40ba3fd = $a27e64cc6ce01033[5];
			} else {
				$F029d0a6c29fd5a2 = $a27e64cc6ce01033[5];
			}
		}

		if (!isset($_GET['extension'])) {
			$_GET['extension'] = 'ts';
		}
	}

	unset($_GET['token'], $a27e64cc6ce01033);
}

if (isset($_GET['utc'])) {
	$_GET['type'] = 'timeshift';
	$_GET['start'] = $_GET['utc'];
	$_GET['duration'] = 3600 * 6;
	unset($_GET['utc']);
}

$E379394c7b1a273f = (isset($_GET['type']) ? $_GET['type'] : 'live');
$F26087d31c2bbe4d = intval($_GET['stream']);
$F9452a7efafa1aba = (isset($_GET['extension']) ? strtolower(preg_replace('/[^A-Za-z0-9 ]/', '', trim($_GET['extension']))) : null);

if (!$F9452a7efafa1aba && in_array($E379394c7b1a273f, array('movie', 'series', 'subtitle'))) {
	$f523e362fb81d6c8 = pathinfo($_GET['stream']);
	$F26087d31c2bbe4d = intval($f523e362fb81d6c8['filename']);
	$F9452a7efafa1aba = strtolower(preg_replace('/[^A-Za-z0-9 ]/', '', trim($f523e362fb81d6c8['extension'])));
}

if ($F9452a7efafa1aba) {
	if (!($F26087d31c2bbe4d && (!$F2d4d8f7981ac574['enable_cache'] || file_exists(STREAMS_TMP_PATH . 'stream_' . $F26087d31c2bbe4d)))) {
		generateError('INVALID_STREAM_ID');
	}

	if (($F2d4d8f7981ac574['ignore_invalid_users'] && $F2d4d8f7981ac574['enable_cache'])) {
		if (isset($_GET['token'])) {
			if (!file_exists(LINES_TMP_PATH . 'line_t_' . $_GET['token'])) {
				generateError('INVALID_CREDENTIALS');
			}
		} else {
			if ((isset($_GET['username']) && isset($_GET['password']))) {
				if ($F2d4d8f7981ac574['case_sensitive_line']) {
					$Bc16cc77a681d1ed = LINES_TMP_PATH . 'line_c_' . $_GET['username'] . '_' . $_GET['password'];
				} else {
					$Bc16cc77a681d1ed = LINES_TMP_PATH . 'line_c_' . strtolower($_GET['username']) . '_' . strtolower($_GET['password']);
				}

				if (!file_exists($Bc16cc77a681d1ed)) {
					generateError('INVALID_CREDENTIALS');
				}
			}
		}
	}

	if (($F2d4d8f7981ac574['enable_cache'] && !$F2d4d8f7981ac574['show_not_on_air_video'] && file_exists(CACHE_TMP_PATH . 'servers'))) {
		$a8bb73cba48fb7f6 = igbinary_unserialize(file_get_contents(CACHE_TMP_PATH . 'servers'));
		$f523e362fb81d6c8 = (igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . $F26087d31c2bbe4d)) ?: null);
		$c43b488500f8fab7 = array();

		if ($E379394c7b1a273f == 'archive') {
			if ((0 < $f523e362fb81d6c8['info']['tv_archive_duration'] && 0 < $f523e362fb81d6c8['info']['tv_archive_server_id'] && array_key_exists($f523e362fb81d6c8['info']['tv_archive_server_id'], $a8bb73cba48fb7f6) && $a8bb73cba48fb7f6[rStream['info']['tv_archive_server_id']]['server_online'])) {
				$c43b488500f8fab7[] = array($f523e362fb81d6c8['info']['tv_archive_server_id']);
			}
		} else {
			if (($f523e362fb81d6c8['info']['direct_source'] == 1 && $f523e362fb81d6c8['info']['direct_proxy'] == 0)) {
				$c43b488500f8fab7[] = $d58b4f8653a391d8;
			}

			foreach ($a8bb73cba48fb7f6 as $d58b4f8653a391d8 => $cc5f26dd881329b7) {
				if (!(!array_key_exists($d58b4f8653a391d8, $f523e362fb81d6c8['servers']) || !$cc5f26dd881329b7['server_online'] || $cc5f26dd881329b7['server_type'] != 0)) {
					if (isset($f523e362fb81d6c8['servers'][$d58b4f8653a391d8])) {
						if ($E379394c7b1a273f == 'movie') {
							if (((!empty($f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['pid']) && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['to_analyze'] == 0 && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['stream_status'] == 0 || $f523e362fb81d6c8['info']['direct_source'] == 1 && $f523e362fb81d6c8['info']['direct_proxy'] == 1) && ($f523e362fb81d6c8['info']['target_container'] == $F9452a7efafa1aba || ($F9452a7efafa1aba = 'srt')) && $cc5f26dd881329b7['timeshift_only'] == 0)) {
								$c43b488500f8fab7[] = $d58b4f8653a391d8;
							}
						} else {
							if ((($f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['on_demand'] == 1 && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['stream_status'] != 1 || 0 < $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['pid'] && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['stream_status'] == 0) && $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['to_analyze'] == 0 && (int) $f523e362fb81d6c8['servers'][$d58b4f8653a391d8]['delay_available_at'] <= time() && $cc5f26dd881329b7['timeshift_only'] == 0 || $f523e362fb81d6c8['info']['direct_source'] == 1 && $f523e362fb81d6c8['info']['direct_proxy'] == 1)) {
								$c43b488500f8fab7[] = $d58b4f8653a391d8;
							}
						}
					}
				}
			}
		}

		if (count($c43b488500f8fab7) == 0) {
			XUI::AD5765c0Fd1abb43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
		}
	}

	require_once INCLUDES_PATH . 'streaming.php';
	XUI::$rAccess = 'auth';
	XUI::$rSettings = $F2d4d8f7981ac574;
	XUI::init(false);

	if (!XUI::$rCached) {
		XUI::Ad0A56bE17e95e81();
		$Fee0d5a474c96306 = &XUI::$db;
	}

	header('Access-Control-Allow-Origin: *');
	register_shutdown_function('shutdown');
	$eea4d80c225a9119 = false;
	$e1034511e63f0e9e = isset(XUI::$rRequest['prebuffer']);

	foreach (getallheaders() as $D3fa098be3f297cd => $b6842cb20051e925) {
		if (strtoupper($D3fa098be3f297cd) == 'X-XUI-DETECT') {
			$eea4d80c225a9119 = true;
		} else {
			if (strtoupper($D3fa098be3f297cd) == 'X-XUI-PREBUFFER') {
				$e1034511e63f0e9e = true;
			}
		}
	}
	$B662f9c27b24b5de = false;
	$D4253f9520627819 = null;
	$B08e7d3cd339391a = null;
	$E18c40e895ee55c2 = '';
	$f9b07d216a168dcc = getmypid();
	$B08b62d9f7870287 = md5(uniqid());
	$c59ec257c284c894 = XUI::A9bC416fa6fa55C3();
	$efc0f8f3059e4104 = XUI::b74F652c92cEc688($c59ec257c284c894)['country']['iso_code'];
	$b3374866087774a1 = (empty($_SERVER['HTTP_USER_AGENT']) ? '' : htmlentities(trim($_SERVER['HTTP_USER_AGENT'])));
	$Dab081f66facd7a3 = true;
	$d080620e03289080 = null;
	$ffc0436d3fdc5100 = time();

	if (!isset($F029d0a6c29fd5a2)) {
		$F029d0a6c29fd5a2 = null;
	}

	if (isset(XUI::$rRequest['token'])) {
		$F2eeef4457c0cddc = XUI::$rRequest['token'];
		$D4253f9520627819 = XUI::D7Ca435ac70E9a78(null, $F2eeef4457c0cddc, null, false, false, $c59ec257c284c894);
	} else {
		if (isset(XUI::$rRequest['hmac'])) {
			if (!in_array($E379394c7b1a273f, array('live', 'movie', 'series'))) {
				$Dab081f66facd7a3 = false;
				generateError('INVALID_TYPE_TOKEN');
			}

			$E18c40e895ee55c2 = (empty(XUI::$rRequest['identifier']) ? '' : XUI::$rRequest['identifier']);
			$B0b073b942c74b98 = (empty(XUI::$rRequest['ip']) ? '' : XUI::$rRequest['ip']);
			$B68ac2238b156add = (isset(XUI::$rRequest['max']) ? intval(XUI::$rRequest['max']) : 0);
			$F029d0a6c29fd5a2 = (isset(XUI::$rRequest['expiry']) ? XUI::$rRequest['expiry'] : null);

			if (($F029d0a6c29fd5a2 && $F029d0a6c29fd5a2 < time())) {
				$Dab081f66facd7a3 = false;
				generateError('TOKEN_EXPIRED');
			}

			$B08e7d3cd339391a = XUI::a7BE375C7e1508D7(XUI::$rRequest['hmac'], $F029d0a6c29fd5a2, $F26087d31c2bbe4d, $F9452a7efafa1aba, $c59ec257c284c894, $B0b073b942c74b98, $E18c40e895ee55c2, $B68ac2238b156add);

			if ($B08e7d3cd339391a) {
				$D4253f9520627819 = array('id' => null, 'is_restreamer' => 0, 'force_server_id' => 0, 'con_isp_name' => null, 'max_connections' => $B68ac2238b156add);

				if (XUI::$rSettings['show_isps']) {
					$da7f3c43bffc92dd = XUI::eE2d851924a79E53($c59ec257c284c894);

					if (is_array($da7f3c43bffc92dd)) {
						$D4253f9520627819['con_isp_name'] = $da7f3c43bffc92dd['isp'];
					}
				}
			}
		} else {
			$a71afc14d6cd090d = XUI::$rRequest['username'];
			$d5249dad8e8411b7 = XUI::$rRequest['password'];
			$D4253f9520627819 = XUI::d7Ca435ac70e9A78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, false, false, $c59ec257c284c894);
		}
	}

	if ($D4253f9520627819 || $B08e7d3cd339391a) {
		$Dab081f66facd7a3 = false;
		XUI::d3E665b5427479FE($D4253f9520627819, $c59ec257c284c894);

		if ((XUI::$rServers[SERVER_ID]['enable_proxy'] && !XUI::Bb41388445081a3d($_SERVER['HTTP_X_IP']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
			generateError('PROXY_ACCESS_DENIED');
		}

		if ($D4253f9520627819['is_e2']) {
			$B662f9c27b24b5de = true;
		}

		if (isset($F2eeef4457c0cddc)) {
			$a71afc14d6cd090d = $D4253f9520627819['username'];
			$d5249dad8e8411b7 = $D4253f9520627819['password'];
		}

		if (!$B08e7d3cd339391a) {
			if (!(is_null($D4253f9520627819['exp_date']) || $D4253f9520627819['exp_date'] > time())) {
				XUI::ea6c9a31F15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_EXPIRED', $c59ec257c284c894);

				if (in_array($E379394c7b1a273f, array('live', 'timeshift'))) {
					XUI::AD5765C0fd1ABb43('show_expired_video', 'expired_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
				} else {
					if (in_array($E379394c7b1a273f, array('movie', 'series'))) {
						XUI::ad5765C0fd1abb43('show_expired_video', 'expired_video_path', 'ts', $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
					} else {
						generateError('EXPIRED');
					}
				}
			}

			if ($D4253f9520627819['admin_enabled'] == 0) {
				XUI::EA6C9A31F15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_BAN', $c59ec257c284c894);

				if (in_array($E379394c7b1a273f, array('live', 'timeshift'))) {
					XUI::aD5765c0FD1Abb43('show_banned_video', 'banned_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
				} else {
					if (in_array($E379394c7b1a273f, array('movie', 'series'))) {
						XUI::aD5765C0FD1ABb43('show_banned_video', 'banned_video_path', 'ts', $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
					} else {
						generateError('BANNED');
					}
				}
			}

			if ($D4253f9520627819['enabled'] == 0) {
				XUI::EA6c9A31f15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_DISABLED', $c59ec257c284c894);

				if (in_array($E379394c7b1a273f, array('live', 'timeshift'))) {
					XUI::aD5765c0Fd1AbB43('show_banned_video', 'banned_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
				} else {
					if (in_array($E379394c7b1a273f, array('movie', 'series'))) {
						XUI::Ad5765C0fD1ABB43('show_banned_video', 'banned_video_path', 'ts', $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
					} else {
						generateError('DISABLED');
					}
				}
			}

			if ($E379394c7b1a273f != 'subtitle') {
				if ($D4253f9520627819['bypass_ua'] == 0) {
					if (XUI::e416910CA4da4695($b3374866087774a1)) {
						generateError('BLOCKED_USER_AGENT');
					}
				}

				if ((empty($b3374866087774a1) && XUI::$rSettings['disallow_empty_user_agents'])) {
					XUI::eA6c9a31F15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'EMPTY_UA', $c59ec257c284c894);
					generateError('EMPTY_USER_AGENT');
				}

				if (!(empty($D4253f9520627819['allowed_ips']) || in_array($c59ec257c284c894, array_map('gethostbyname', $D4253f9520627819['allowed_ips'])))) {
					XUI::EA6C9a31F15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_BAN', $c59ec257c284c894);
					generateError('NOT_IN_ALLOWED_IPS');
				}

				if (!empty($efc0f8f3059e4104)) {
					$ac720430e021c8c0 = !empty($D4253f9520627819['forced_country']);

					if (($ac720430e021c8c0 && $D4253f9520627819['forced_country'] != 'ALL' && $efc0f8f3059e4104 != $D4253f9520627819['forced_country'])) {
						XUI::EA6C9A31F15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'COUNTRY_DISALLOW', $c59ec257c284c894);
						generateError('FORCED_COUNTRY_INVALID');
					}

					if (!($ac720430e021c8c0 || in_array('ALL', XUI::$rSettings['allow_countries']) || in_array($efc0f8f3059e4104, XUI::$rSettings['allow_countries']))) {
						XUI::Ea6C9a31f15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'COUNTRY_DISALLOW', $c59ec257c284c894);
						generateError('NOT_IN_ALLOWED_COUNTRY');
					}
				}

				if (!(empty($D4253f9520627819['allowed_ua']) || in_array($b3374866087774a1, $D4253f9520627819['allowed_ua']))) {
					XUI::eA6C9a31f15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_AGENT_BAN', $c59ec257c284c894);
					generateError('NOT_IN_ALLOWED_UAS');
				}

				if ($D4253f9520627819['isp_violate']) {
					XUI::ea6C9a31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'ISP_LOCK_FAILED', $c59ec257c284c894, json_encode(array('old' => $D4253f9520627819['isp_desc'], 'new' => $D4253f9520627819['con_isp_name'])));
					generateError('ISP_BLOCKED');
				}

				if ($D4253f9520627819['isp_is_server'] && !$D4253f9520627819['is_restreamer']) {
					XUI::ea6C9a31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'BLOCKED_ASN', $c59ec257c284c894, json_encode(array('user_agent' => $b3374866087774a1, 'isp' => $D4253f9520627819['con_isp_name'], 'asn' => $D4253f9520627819['isp_asn'])), true);
					generateError('ASN_BLOCKED');
				}

				if ($D4253f9520627819['is_mag'] && !$D78b6d56a11571aa) {
					generateError('DEVICE_NOT_ALLOWED');
				} else {
					if ($D78b6d56a11571aa && !XUI::$rSettings['disable_mag_token'] && (!$Aeadc6eca40ba3fd || $Aeadc6eca40ba3fd != $D4253f9520627819['mag_token'])) {
						generateError('TOKEN_EXPIRED');
					} else {
						if (($F029d0a6c29fd5a2 && $F029d0a6c29fd5a2 < time())) {
							XUI::EA6C9a31f15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'TOKEN_EXPIRED', $c59ec257c284c894);
							generateError('TOKEN_EXPIRED');
						}
					}
				}
			}

			if (($D4253f9520627819['is_stalker'] && in_array($E379394c7b1a273f, array('live', 'movie', 'series', 'timeshift')))) {
				if ((empty(XUI::$rRequest['stalker_key']) || $F9452a7efafa1aba != 'ts')) {
					generateError('STALKER_INVALID_KEY');
				}

				$Bce177641b9f99f3 = base64_decode(urldecode(XUI::$rRequest['stalker_key']));

				if ($e1a3c6332faa66a6 = XUI::BA0A47b17B7e0f65($Bce177641b9f99f3, md5(XUI::$rSettings['live_streaming_pass']))) {
					$C762aad9b830fb1b = explode('=', $e1a3c6332faa66a6);

					if ($C762aad9b830fb1b[2] != $F26087d31c2bbe4d) {
						XUI::EA6C9A31f15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'STALKER_CHANNEL_MISMATCH', $c59ec257c284c894);
						generateError('STALKER_CHANNEL_MISMATCH');
					}

					$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $C762aad9b830fb1b[1]), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $C762aad9b830fb1b[1] == $c59ec257c284c894);

					if (!$ee7553b0caebc8c4 && XUI::$rSettings['restrict_same_ip']) {
						XUI::ea6C9a31F15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'STALKER_IP_MISMATCH', $c59ec257c284c894);
						generateError('STALKER_IP_MISMATCH');
					}

					$D7102b1e2b296e66 = (XUI::$rSettings['create_expiration'] ?: 5);

					if ($C762aad9b830fb1b[3] < time() - $D7102b1e2b296e66) {
						XUI::eA6c9A31F15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'STALKER_KEY_EXPIRED', $c59ec257c284c894);
						generateError('STALKER_KEY_EXPIRED');
					}

					$d080620e03289080 = $C762aad9b830fb1b[0];
				} else {
					XUI::EA6c9A31f15A7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'STALKER_DECRYPT_FAILED', $c59ec257c284c894);
					generateError('STALKER_DECRYPT_FAILED');
				}
			}

			if (!in_array($E379394c7b1a273f, array('thumb', 'subtitle'))) {
				if (!($D4253f9520627819['is_restreamer'] || in_array($c59ec257c284c894, XUI::$rAllowedIPs))) {
					if ((XUI::$rSettings['block_streaming_servers'] || XUI::$rSettings['block_proxies'])) {
						$Da967f0a787f6b51 = XUI::a54586EADEA94EE6($D4253f9520627819['isp_asn'], $c59ec257c284c894);

						if ($Da967f0a787f6b51) {
							if ((XUI::$rSettings['block_streaming_servers'] && $Da967f0a787f6b51[3]) && !$Da967f0a787f6b51[4]) {
								XUI::ea6C9A31f15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'HOSTING_DETECT', $c59ec257c284c894, json_encode(array('user_agent' => $b3374866087774a1, 'isp' => $D4253f9520627819['con_isp_name'], 'asn' => $D4253f9520627819['isp_asn'])), true);
								generateError('HOSTING_DETECT');
							}

							if ((XUI::$rSettings['block_proxies'] && $Da967f0a787f6b51[4])) {
								XUI::Ea6C9A31f15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'PROXY_DETECT', $c59ec257c284c894, json_encode(array('user_agent' => $b3374866087774a1, 'isp' => $D4253f9520627819['con_isp_name'], 'asn' => $D4253f9520627819['isp_asn'])), true);
								generateError('PROXY_DETECT');
							}
						}
					}

					if ($eea4d80c225a9119) {
						if (XUI::$rSettings['detect_restream_block_user']) {
							if (XUI::$rCached) {
								XUI::Cf592c234DcD0b19('restream_block_user/' . $D4253f9520627819['id'] . '/' . $F26087d31c2bbe4d . '/' . $c59ec257c284c894, 1);
							} else {
								$Fee0d5a474c96306->query('UPDATE `lines` SET `admin_enabled` = 0 WHERE `id` = ?;', $D4253f9520627819['id']);
							}
						}

						if ((XUI::$rSettings['restream_deny_unauthorised'] || XUI::$rSettings['detect_restream_block_user'])) {
							XUI::Ea6C9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'RESTREAM_DETECT', $c59ec257c284c894, json_encode(array('user_agent' => $b3374866087774a1, 'isp' => $D4253f9520627819['con_isp_name'], 'asn' => $D4253f9520627819['isp_asn'])), true);
							generateError('RESTREAM_DETECT');
						}
					}
				}
			}

			if ($E379394c7b1a273f == 'live') {
				if (!in_array($F9452a7efafa1aba, $D4253f9520627819['output_formats'])) {
					XUI::EA6C9A31f15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'USER_DISALLOW_EXT', $c59ec257c284c894);
					generateError('USER_DISALLOW_EXT');
				}
			}

			if (($E379394c7b1a273f == 'live' && XUI::$rSettings['show_expiring_video'] && !$D4253f9520627819['is_trial'] && !is_null($D4253f9520627819['exp_date']) && $D4253f9520627819['exp_date'] - 86400 * 7 <= time() && (86400 <= time() - $D4253f9520627819['last_expiration_video'] || !$D4253f9520627819['last_expiration_video']))) {
				if (XUI::$rCached) {
					XUI::Cf592c234DcD0b19('expiring/' . $D4253f9520627819['id'], time());
				} else {
					$Fee0d5a474c96306->query('UPDATE `lines` SET `last_expiration_video` = ? WHERE `id` = ?;', time(), $D4253f9520627819['id']);
				}

				XUI::aD5765C0FD1Abb43('show_expiring_video', 'expiring_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
			}
		}
	} else {
		XUI::b6f740FABc7265bf($c59ec257c284c894, null, $a71afc14d6cd090d);
		XUI::EA6C9a31F15A7b61($F26087d31c2bbe4d, 0, 'AUTH_FAILED', $c59ec257c284c894);
		generateError('INVALID_CREDENTIALS');
	}

	if ($D78b6d56a11571aa) {
		$Acfdd9e81f0cf9d5 = XUI::$rSettings['mag_disable_ssl'];
	} else {
		if ($B662f9c27b24b5de) {
			$Acfdd9e81f0cf9d5 = true;
		} else {
			$Acfdd9e81f0cf9d5 = false;
		}
	}

	switch ($E379394c7b1a273f) {
		case 'live':
			$fca7edf85daa1695 = XUI::b3ED925E7969f61A($F26087d31c2bbe4d, $F9452a7efafa1aba, $D4253f9520627819, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], 'live');

			if (is_array($fca7edf85daa1695)) {
				if (count(array_keys($fca7edf85daa1695)) == 0) {
					generateError('NO_SERVERS_AVAILABLE');
				}

				if (!array_intersect($D4253f9520627819['bouquet'], $fca7edf85daa1695['bouquets'])) {
					generateError('NOT_IN_BOUQUET');
				}

				if ((XUI::isProxied($fca7edf85daa1695['redirect_id']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
					$c08f7f5177a44d91 = XUI::getProxies($fca7edf85daa1695['redirect_id']);
					$b2a9243e8304033d = XUI::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

					if (!$b2a9243e8304033d) {
						generateError('NO_SERVERS_AVAILABLE');
					}

					$fca7edf85daa1695['originator_id'] = $fca7edf85daa1695['redirect_id'];
					$fca7edf85daa1695['redirect_id'] = $b2a9243e8304033d;
				}

				$C700a2b357e5ed65 = XUI::getStreamingURL($fca7edf85daa1695['redirect_id'], ($fca7edf85daa1695['originator_id'] ?: null), $Acfdd9e81f0cf9d5);
				$bb0071da5a239b0c = json_decode($fca7edf85daa1695['stream_info'], true);
				$F2735dad02d30e84 = ($bb0071da5a239b0c['codecs']['video']['codec_name'] ?: 'h264');

				switch ($F9452a7efafa1aba) {
					case 'm3u8':
						if ((XUI::$rSettings['disable_hls'] && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['disable_hls_allow_restream']))) {
							generateError('HLS_DISABLED');
						}

						if ($fca7edf85daa1695['direct_proxy']) {
							generateError('HLS_DISABLED');
						}

						$d5b3c619fc252d2e = json_decode($fca7edf85daa1695['adaptive_link'], true);

						if (!$B08e7d3cd339391a && is_array($d5b3c619fc252d2e) && 0 < count($d5b3c619fc252d2e)) {
							$Bab76ac20d8e4000 = array();

							foreach (array_merge(array($F26087d31c2bbe4d), $d5b3c619fc252d2e) as $ba78a3ba07e942ec) {
								if ($ba78a3ba07e942ec != $F26087d31c2bbe4d) {
									$C437018de91c0402 = XUI::B3eD925e7969f61a($ba78a3ba07e942ec, $F9452a7efafa1aba, $D4253f9520627819, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], 'live');

									if ((XUI::isProxied($C437018de91c0402['redirect_id']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
										$c08f7f5177a44d91 = XUI::getProxies($C437018de91c0402['redirect_id']);
										$b2a9243e8304033d = XUI::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

										if (!$b2a9243e8304033d) {
											generateError('NO_SERVERS_AVAILABLE');
										}

										$C437018de91c0402['originator_id'] = $C437018de91c0402['redirect_id'];
										$C437018de91c0402['redirect_id'] = $b2a9243e8304033d;
									}

									$C700a2b357e5ed65 = XUI::getStreamingURL($C437018de91c0402['redirect_id'], ($C437018de91c0402['originator_id'] ?: null), $Acfdd9e81f0cf9d5);
								} else {
									$C437018de91c0402 = $fca7edf85daa1695;
								}

								$bb0071da5a239b0c = json_decode($C437018de91c0402['stream_info'], true);
								$aa2e54fde620d6b3 = ($bb0071da5a239b0c['bitrate'] ?: 0);
								$c29dfa683545802c = ($bb0071da5a239b0c['codecs']['video']['width'] ?: 0);
								$d30b6b589a9a7ff6 = ($bb0071da5a239b0c['codecs']['video']['height'] ?: 0);

								if ((0 < $aa2e54fde620d6b3 && 0 < $d30b6b589a9a7ff6 && 0 < $c29dfa683545802c)) {
									$F64d974c429d80be = array('stream_id' => $ba78a3ba07e942ec, 'username' => $D4253f9520627819['username'], 'password' => $D4253f9520627819['password'], 'extension' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'channel_info' => array('redirect_id' => $C437018de91c0402['redirect_id'], 'originator_id' => ($C437018de91c0402['originator_id'] ?: null), 'pid' => $C437018de91c0402['pid'], 'on_demand' => $C437018de91c0402['on_demand'], 'monitor_pid' => $C437018de91c0402['monitor_pid']), 'user_info' => array('id' => $D4253f9520627819['id'], 'max_connections' => $D4253f9520627819['max_connections'], 'pair_id' => $D4253f9520627819['pair_id'], 'con_isp_name' => $D4253f9520627819['con_isp_name'], 'is_restreamer' => $D4253f9520627819['is_restreamer']), 'external_device' => $d080620e03289080, 'activity_start' => $ffc0436d3fdc5100, 'country_code' => $efc0f8f3059e4104, 'video_codec' => ($bb0071da5a239b0c['codecs']['video']['codec_name'] ?: 'h264'), 'uuid' => $B08b62d9f7870287, 'adaptive' => array($fca7edf85daa1695['redirect_id'], $F26087d31c2bbe4d));
									$Eb6eccfbed89f039 = (string) $C700a2b357e5ed65 . '/auth/' . Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
									$Bab76ac20d8e4000[$aa2e54fde620d6b3] = '#EXT-X-STREAM-INF:BANDWIDTH=' . $aa2e54fde620d6b3 . ',RESOLUTION=' . $c29dfa683545802c . 'x' . $d30b6b589a9a7ff6 . "\n" . $Eb6eccfbed89f039;
								}
							}

							if (0 < count($Bab76ac20d8e4000)) {
								krsort($Bab76ac20d8e4000);
								$dc05e2bb97d4635d = "#EXTM3U\n" . implode("\n", array_values($Bab76ac20d8e4000));
								ob_end_clean();
								header('Content-Type: application/x-mpegurl');
								header('Content-Length: ' . strlen($dc05e2bb97d4635d));
								echo $dc05e2bb97d4635d;

								exit();
							}

							XUI::ad5765C0fD1ABB43('show_not_on_air_video', 'not_on_air_video_path', 'ts', $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], ($fca7edf85daa1695['originator_id'] ?: $fca7edf85daa1695['redirect_id']), ($fca7edf85daa1695['originator_id'] ? $fca7edf85daa1695['redirect_id'] : null));

							exit();
						} else {
							if (!$B08e7d3cd339391a) {
								$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'username' => $D4253f9520627819['username'], 'password' => $D4253f9520627819['password'], 'extension' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'channel_info' => array('redirect_id' => $fca7edf85daa1695['redirect_id'], 'originator_id' => ($fca7edf85daa1695['originator_id'] ?: null), 'pid' => $fca7edf85daa1695['pid'], 'on_demand' => $fca7edf85daa1695['on_demand'], 'llod' => $fca7edf85daa1695['llod'], 'monitor_pid' => $fca7edf85daa1695['monitor_pid']), 'user_info' => array('id' => $D4253f9520627819['id'], 'max_connections' => $D4253f9520627819['max_connections'], 'pair_id' => $D4253f9520627819['pair_id'], 'con_isp_name' => $D4253f9520627819['con_isp_name'], 'is_restreamer' => $D4253f9520627819['is_restreamer']), 'external_device' => $d080620e03289080, 'activity_start' => $ffc0436d3fdc5100, 'country_code' => $efc0f8f3059e4104, 'video_codec' => $F2735dad02d30e84, 'uuid' => $B08b62d9f7870287);
							} else {
								$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'hmac_hash' => XUI::$rRequest['hmac'], 'hmac_id' => $B08e7d3cd339391a, 'identifier' => $E18c40e895ee55c2, 'extension' => $F9452a7efafa1aba, 'channel_info' => array('redirect_id' => $fca7edf85daa1695['redirect_id'], 'originator_id' => ($fca7edf85daa1695['originator_id'] ?: null), 'pid' => $fca7edf85daa1695['pid'], 'on_demand' => $fca7edf85daa1695['on_demand'], 'llod' => $fca7edf85daa1695['llod'], 'monitor_pid' => $fca7edf85daa1695['monitor_pid']), 'user_info' => $D4253f9520627819, 'pid' => $f9b07d216a168dcc, 'external_device' => $d080620e03289080, 'activity_start' => $ffc0436d3fdc5100, 'country_code' => $efc0f8f3059e4104, 'video_codec' => $F2735dad02d30e84, 'uuid' => $B08b62d9f7870287);
							}

							$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

							if (XUI::$rSettings['allow_cdn_access']) {
								header('Location: ' . $C700a2b357e5ed65 . '/auth/' . $F26087d31c2bbe4d . '.m3u8?token=' . $ea5296071288c730);

								exit();
							}

							header('Location: ' . $C700a2b357e5ed65 . '/auth/' . $ea5296071288c730);

							exit();
						}

						// no break
					case 'ts':
						if ((XUI::$rSettings['disable_ts'] && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['disable_ts_allow_restream']))) {
							generateError('TS_DISABLED');
						}

						if (!$B08e7d3cd339391a) {
							$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'username' => $D4253f9520627819['username'], 'password' => $D4253f9520627819['password'], 'extension' => $F9452a7efafa1aba, 'channel_info' => array('stream_id' => $fca7edf85daa1695['stream_id'], 'redirect_id' => ($fca7edf85daa1695['redirect_id'] ?: null), 'originator_id' => ($fca7edf85daa1695['originator_id'] ?: null), 'pid' => $fca7edf85daa1695['pid'], 'on_demand' => $fca7edf85daa1695['on_demand'], 'llod' => $fca7edf85daa1695['llod'], 'monitor_pid' => $fca7edf85daa1695['monitor_pid'], 'proxy' => $fca7edf85daa1695['direct_proxy']), 'user_info' => array('id' => $D4253f9520627819['id'], 'max_connections' => $D4253f9520627819['max_connections'], 'pair_id' => $D4253f9520627819['pair_id'], 'con_isp_name' => $D4253f9520627819['con_isp_name'], 'is_restreamer' => $D4253f9520627819['is_restreamer']), 'pid' => $f9b07d216a168dcc, 'prebuffer' => $e1034511e63f0e9e, 'country_code' => $efc0f8f3059e4104, 'activity_start' => $ffc0436d3fdc5100, 'external_device' => $d080620e03289080, 'video_codec' => $F2735dad02d30e84, 'uuid' => $B08b62d9f7870287);
						} else {
							$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'hmac_hash' => XUI::$rRequest['hmac'], 'hmac_id' => $B08e7d3cd339391a, 'identifier' => $E18c40e895ee55c2, 'extension' => $F9452a7efafa1aba, 'channel_info' => array('stream_id' => $fca7edf85daa1695['stream_id'], 'redirect_id' => ($fca7edf85daa1695['redirect_id'] ?: null), 'originator_id' => ($fca7edf85daa1695['originator_id'] ?: null), 'pid' => $fca7edf85daa1695['pid'], 'on_demand' => $fca7edf85daa1695['on_demand'], 'llod' => $fca7edf85daa1695['llod'], 'monitor_pid' => $fca7edf85daa1695['monitor_pid'], 'proxy' => $fca7edf85daa1695['direct_proxy']), 'user_info' => $D4253f9520627819, 'pid' => $f9b07d216a168dcc, 'prebuffer' => $e1034511e63f0e9e, 'country_code' => $efc0f8f3059e4104, 'activity_start' => $ffc0436d3fdc5100, 'external_device' => $d080620e03289080, 'video_codec' => $F2735dad02d30e84, 'uuid' => $B08b62d9f7870287);
						}

						$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

						if (XUI::$rSettings['allow_cdn_access']) {
							header('Location: ' . $C700a2b357e5ed65 . '/auth/' . $F26087d31c2bbe4d . '.ts?token=' . $ea5296071288c730);

							exit();
						}

						header('Location: ' . $C700a2b357e5ed65 . '/auth/' . $ea5296071288c730);

						exit();
				}
			} else {
				XUI::aD5765C0Fd1Abb43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);
			}

			break;

		case 'movie':
		case 'series':
			$fca7edf85daa1695 = XUI::b3ed925e7969f61A($F26087d31c2bbe4d, $F9452a7efafa1aba, $D4253f9520627819, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], 'movie');

			if ($fca7edf85daa1695) {
				if ((XUI::isProxied($fca7edf85daa1695['redirect_id']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
					$c08f7f5177a44d91 = XUI::getProxies($fca7edf85daa1695['redirect_id']);
					$b2a9243e8304033d = XUI::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

					if (!$b2a9243e8304033d) {
						generateError('NO_SERVERS_AVAILABLE');
					}

					$fca7edf85daa1695['originator_id'] = $fca7edf85daa1695['redirect_id'];
					$fca7edf85daa1695['redirect_id'] = $b2a9243e8304033d;
				}

				$C700a2b357e5ed65 = XUI::getStreamingURL($fca7edf85daa1695['redirect_id'], ($fca7edf85daa1695['originator_id'] ?: null), $Acfdd9e81f0cf9d5);

				if ($fca7edf85daa1695['direct_proxy']) {
					$fca7edf85daa1695['bitrate'] = (json_decode($fca7edf85daa1695['movie_properties'], true)['duration_secs'] ?: 0);
				}

				if (!$B08e7d3cd339391a) {
					$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'username' => $D4253f9520627819['username'], 'password' => $D4253f9520627819['password'], 'extension' => $F9452a7efafa1aba, 'type' => $E379394c7b1a273f, 'pid' => $f9b07d216a168dcc, 'channel_info' => array('stream_id' => $fca7edf85daa1695['stream_id'], 'bitrate' => $fca7edf85daa1695['bitrate'], 'target_container' => $fca7edf85daa1695['target_container'], 'redirect_id' => $fca7edf85daa1695['redirect_id'], 'originator_id' => ($fca7edf85daa1695['originator_id'] ?: null), 'pid' => $fca7edf85daa1695['pid'], 'proxy' => ($fca7edf85daa1695['direct_proxy'] ? json_decode($fca7edf85daa1695['stream_source'], true)[0] : null)), 'user_info' => array('id' => $D4253f9520627819['id'], 'max_connections' => $D4253f9520627819['max_connections'], 'pair_id' => $D4253f9520627819['pair_id'], 'con_isp_name' => $D4253f9520627819['con_isp_name'], 'is_restreamer' => $D4253f9520627819['is_restreamer']), 'country_code' => $efc0f8f3059e4104, 'activity_start' => $ffc0436d3fdc5100, 'is_mag' => $D78b6d56a11571aa, 'uuid' => $B08b62d9f7870287, 'http_range' => (isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : null));
				} else {
					$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'hmac_hash' => XUI::$rRequest['hmac'], 'hmac_id' => $B08e7d3cd339391a, 'identifier' => $E18c40e895ee55c2, 'extension' => $F9452a7efafa1aba, 'type' => $E379394c7b1a273f, 'pid' => $f9b07d216a168dcc, 'channel_info' => array('stream_id' => $fca7edf85daa1695['stream_id'], 'bitrate' => $fca7edf85daa1695['bitrate'], 'target_container' => $fca7edf85daa1695['target_container'], 'redirect_id' => $fca7edf85daa1695['redirect_id'], 'originator_id' => ($fca7edf85daa1695['originator_id'] ?: null), 'pid' => $fca7edf85daa1695['pid'], 'proxy_source' => ($fca7edf85daa1695['direct_proxy'] ? json_decode($fca7edf85daa1695['stream_source'], true)[0] : null)), 'user_info' => $D4253f9520627819, 'country_code' => $efc0f8f3059e4104, 'activity_start' => $ffc0436d3fdc5100, 'is_mag' => $D78b6d56a11571aa, 'uuid' => $B08b62d9f7870287, 'http_range' => (isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : null));
				}

				$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

				if (XUI::$rSettings['allow_cdn_access']) {
					header('Location: ' . $C700a2b357e5ed65 . '/vauth/' . $F26087d31c2bbe4d . '.' . $F9452a7efafa1aba . '?token=' . $ea5296071288c730);

					exit();
				}

				header('Location: ' . $C700a2b357e5ed65 . '/vauth/' . $ea5296071288c730);

				exit();
			}

			XUI::AD5765c0fD1ABB43('show_not_on_air_video', 'not_on_air_video_path', 'ts', $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);

			break;

		case 'timeshift':
			$a70eaa0ab42179dd = null;
			$B5f1fb70f197b910 = XUI::b3Ed925E7969f61A($F26087d31c2bbe4d, $F9452a7efafa1aba, $D4253f9520627819, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], 'archive');

			if (!$B5f1fb70f197b910) {
				XUI::aD5765C0Fd1AbB43('show_not_on_air_video', 'not_on_air_video_path', $F9452a7efafa1aba, $D4253f9520627819, $c59ec257c284c894, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], SERVER_ID);

				break;
			}

			if ((XUI::isProxied($fca7edf85daa1695['redirect_id']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
				$c08f7f5177a44d91 = XUI::getProxies($fca7edf85daa1695['redirect_id']);
				$b2a9243e8304033d = XUI::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

				if (!$b2a9243e8304033d) {
					generateError('NO_SERVERS_AVAILABLE');
				}

				$a70eaa0ab42179dd = $fca7edf85daa1695['redirect_id'];
				$B5f1fb70f197b910 = $b2a9243e8304033d;
			}

			$C700a2b357e5ed65 = XUI::getStreamingURL($B5f1fb70f197b910, ($a70eaa0ab42179dd ?: null), $Acfdd9e81f0cf9d5);
			$a63ba41c5c63ce14 = XUI::$rRequest['start'];
			$C5034884ed44603a = intval(XUI::$rRequest['duration']);

			switch ($F9452a7efafa1aba) {
				case 'm3u8':
					if ((XUI::$rSettings['disable_hls'] && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['disable_hls_allow_restream']))) {
						generateError('HLS_DISABLED');
					}

					$F64d974c429d80be = array('stream' => $F26087d31c2bbe4d, 'username' => $D4253f9520627819['username'], 'password' => $D4253f9520627819['password'], 'extension' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'start' => $a63ba41c5c63ce14, 'duration' => $C5034884ed44603a, 'redirect_id' => $B5f1fb70f197b910, 'originator_id' => $a70eaa0ab42179dd, 'user_info' => array('id' => $D4253f9520627819['id'], 'max_connections' => $D4253f9520627819['max_connections'], 'pair_line_info' => $D4253f9520627819['pair_line_info'], 'pair_id' => $D4253f9520627819['pair_id'], 'active_cons' => $D4253f9520627819['active_cons'], 'con_isp_name' => $D4253f9520627819['con_isp_name'], 'is_restreamer' => $D4253f9520627819['is_restreamer']), 'country_code' => $efc0f8f3059e4104, 'activity_start' => $ffc0436d3fdc5100, 'uuid' => $B08b62d9f7870287, 'http_range' => (isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : null));
					$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

					if (XUI::$rSettings['allow_cdn_access']) {
						header('Location: ' . $C700a2b357e5ed65 . '/tsauth/' . $F26087d31c2bbe4d . '_' . $a63ba41c5c63ce14 . '_' . $C5034884ed44603a . '.m3u8?token=' . $ea5296071288c730);

						exit();
					}

					header('Location: ' . $C700a2b357e5ed65 . '/tsauth/' . $ea5296071288c730);

					exit();

				default:
					if ((XUI::$rSettings['disable_ts'] && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['disable_ts_allow_restream']))) {
						generateError('TS_DISABLED');
					}

					$ffc0436d3fdc5100 = time();
					$F64d974c429d80be = array('stream' => $F26087d31c2bbe4d, 'username' => $D4253f9520627819['username'], 'password' => $D4253f9520627819['password'], 'extension' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'start' => $a63ba41c5c63ce14, 'duration' => $C5034884ed44603a, 'redirect_id' => $B5f1fb70f197b910, 'originator_id' => $a70eaa0ab42179dd, 'user_info' => array('id' => $D4253f9520627819['id'], 'max_connections' => $D4253f9520627819['max_connections'], 'pair_line_info' => $D4253f9520627819['pair_line_info'], 'pair_id' => $D4253f9520627819['pair_id'], 'active_cons' => $D4253f9520627819['active_cons'], 'con_isp_name' => $D4253f9520627819['con_isp_name'], 'is_restreamer' => $D4253f9520627819['is_restreamer']), 'country_code' => $efc0f8f3059e4104, 'activity_start' => $ffc0436d3fdc5100, 'uuid' => $B08b62d9f7870287, 'http_range' => (isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : null));
					$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

					if (XUI::$rSettings['allow_cdn_access']) {
						header('Location: ' . $C700a2b357e5ed65 . '/tsauth/' . $F26087d31c2bbe4d . '_' . $a63ba41c5c63ce14 . '_' . $C5034884ed44603a . '.ts?token=' . $ea5296071288c730);

						exit();
					}

					header('Location: ' . $C700a2b357e5ed65 . '/tsauth/' . $ea5296071288c730);

					exit();
			}
			// no break
		case 'thumb':
			$bb0071da5a239b0c = null;

			if (XUI::$rCached) {
				$bb0071da5a239b0c = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . $F26087d31c2bbe4d));
			} else {
				$Fee0d5a474c96306->query('SELECT * FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type AND t2.live = 1 LEFT JOIN `profiles` t4 ON t1.transcode_profile_id = t4.profile_id WHERE t1.direct_source = 0 AND t1.id = ?', $F26087d31c2bbe4d);

				if (0 < $Fee0d5a474c96306->num_rows()) {
					$bb0071da5a239b0c = array('info' => $Fee0d5a474c96306->get_row());
				}
			}

			if (!$bb0071da5a239b0c) {
				generateError('INVALID_STREAM_ID');
			}

			if ($bb0071da5a239b0c['info']['vframes_server_id'] == 0) {
				generateError('THUMBNAILS_NOT_ENABLED');
			}

			$F64d974c429d80be = array('stream' => $F26087d31c2bbe4d, 'expires' => time() + 5);
			$a70eaa0ab42179dd = null;

			if ((XUI::isProxied($bb0071da5a239b0c['info']['vframes_server_id']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
				$c08f7f5177a44d91 = XUI::getProxies($bb0071da5a239b0c['info']['vframes_server_id']);
				$b2a9243e8304033d = XUI::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

				if (!$b2a9243e8304033d) {
					generateError('THUMBNAILS_NOT_ENABLED');
				}

				$a70eaa0ab42179dd = $bb0071da5a239b0c['info']['vframes_server_id'];
				$bb0071da5a239b0c['info']['vframes_server_id'] = $b2a9243e8304033d;
			}

			$C700a2b357e5ed65 = XUI::getStreamingURL($bb0071da5a239b0c['info']['vframes_server_id'], $a70eaa0ab42179dd, $Acfdd9e81f0cf9d5);
			$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
			header('Location: ' . $C700a2b357e5ed65 . '/thauth/' . $ea5296071288c730);

			exit();

		case 'subtitle':
			$fca7edf85daa1695 = XUI::B3Ed925E7969f61A($F26087d31c2bbe4d, 'srt', $D4253f9520627819, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], 'movie');

			if ($fca7edf85daa1695) {
				if ((XUI::isProxied($fca7edf85daa1695['redirect_id']) && (!$D4253f9520627819['is_restreamer'] || !XUI::$rSettings['restreamer_bypass_proxy']))) {
					$c08f7f5177a44d91 = XUI::getProxies($fca7edf85daa1695['redirect_id']);
					$b2a9243e8304033d = XUI::availableProxy(array_keys($c08f7f5177a44d91), $efc0f8f3059e4104, $D4253f9520627819['con_isp_name']);

					if (!$b2a9243e8304033d) {
						generateError('NO_SERVERS_AVAILABLE');
					}

					$fca7edf85daa1695['originator_id'] = $fca7edf85daa1695['redirect_id'];
					$fca7edf85daa1695['redirect_id'] = $b2a9243e8304033d;
				}

				$C700a2b357e5ed65 = XUI::getStreamingURL($fca7edf85daa1695['redirect_id'], ($fca7edf85daa1695['originator_id'] ?: null), $Acfdd9e81f0cf9d5);
				$F64d974c429d80be = array('stream_id' => $F26087d31c2bbe4d, 'sub_id' => (intval(XUI::$rRequest['sid']) ?: 0), 'webvtt' => (intval(XUI::$rRequest['webvtt']) ?: 0), 'expires' => time() + 5);
				$ea5296071288c730 = Xui\Functions::encrypt(json_encode($F64d974c429d80be), XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
				header('Location: ' . $C700a2b357e5ed65 . '/subauth/' . $ea5296071288c730);

				exit();
			}

			generateError('INVALID_STREAM_ID');

			break;
	}
} else {
	switch ($E379394c7b1a273f) {
		case 'timeshift':
		case 'live':
			$F9452a7efafa1aba = 'ts';

			break;

		case 'series':
		case 'movie':
			$F9452a7efafa1aba = 'mp4';

			break;
	}
}

function shutdown()
{
	global $Dab081f66facd7a3;
	global $Fee0d5a474c96306;

	if ($Dab081f66facd7a3) {
		XUI::fC8474658Ec80360();
	}

	if (is_object($Fee0d5a474c96306)) {
		$Fee0d5a474c96306->close_mysql();
	}
}
