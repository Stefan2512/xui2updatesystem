<?php

register_shutdown_function('shutdown');
set_time_limit(0);
require_once 'init.php';
unset(XUI::$rSettings['watchdog_data'], XUI::$rSettings['server_hardware']);

header('Access-Control-Allow-Origin: *');

if (empty(XUI::$rSettings['send_server_header'])) {
} else {
	header('Server: ' . XUI::$rSettings['send_server_header']);
}

if (!XUI::$rSettings['send_protection_headers']) {
} else {
	header('X-XSS-Protection: 0');
	header('X-Content-Type-Options: nosniff');
}

if (!XUI::$rSettings['send_altsvc_header']) {
} else {
	header('Alt-Svc: h3-29=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-T051=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q050=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q046=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,h3-Q043=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000,quic=":' . XUI::$rServers[SERVER_ID]['https_broadcast_port'] . '"; ma=2592000; v="46,43"');
}

if (!empty(XUI::$rSettings['send_unique_header_domain']) || filter_var(HOST, FILTER_VALIDATE_IP)) {
} else {
	XUI::$rSettings['send_unique_header_domain'] = '.' . HOST;
}

if (empty(XUI::$rSettings['send_unique_header'])) {
} else {
	$bae85948a6f4b7de = new DateTime('+6 months', new DateTimeZone('GMT'));
	header('Set-Cookie: ' . XUI::$rSettings['send_unique_header'] . '=' . XUI::bb7f1b0ed6C4b87D(11) . '; Domain=' . XUI::$rSettings['send_unique_header_domain'] . '; Expires=' . $bae85948a6f4b7de->format(DATE_RFC2822) . '; Path=/; Secure; HttpOnly; SameSite=none');
}

$D7102b1e2b296e66 = 60;
$b2a9243e8304033d = null;
$c59ec257c284c894 = XUI::a9bC416fA6fa55C3();
$b3374866087774a1 = (empty($_SERVER['HTTP_USER_AGENT']) ? '' : htmlentities(trim($_SERVER['HTTP_USER_AGENT'])));
$f2d1c7bb81b31b19 = null;
$b25be5f9af7a0a91 = 0;
$Df5a05fb37ec64f1 = false;
$f9b07d216a168dcc = getmypid();
$a859a0996bb0f1ff = time();

if (isset(XUI::$rRequest['token'])) {
	$F64d974c429d80be = json_decode(Xui\Functions::decrypt(XUI::$rRequest['token'], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);

	if (is_array($F64d974c429d80be)) {
	} else {
		XUI::eA6C9A31F15a7b61(0, 0, 'LB_TOKEN_INVALID', $c59ec257c284c894);
		generateError('LB_TOKEN_INVALID');
	}

	if (!(isset($F64d974c429d80be['expires']) && $F64d974c429d80be['expires'] < time() - intval(XUI::$rServers[SERVER_ID]['time_offset']))) {
	} else {
		generateError('TOKEN_EXPIRED');
	}

	$a71afc14d6cd090d = $F64d974c429d80be['username'];
	$d5249dad8e8411b7 = $F64d974c429d80be['password'];
	$F26087d31c2bbe4d = $F64d974c429d80be['stream'];
	$F9452a7efafa1aba = $F64d974c429d80be['extension'];
	$a63ba41c5c63ce14 = $F64d974c429d80be['start'];
	$C5034884ed44603a = $F64d974c429d80be['duration'];
	$B5f1fb70f197b910 = $F64d974c429d80be['redirect_id'];
	$a70eaa0ab42179dd = ($F64d974c429d80be['originator_id'] ?: null);
	$D4253f9520627819 = $F64d974c429d80be['user_info'];
	$ffc0436d3fdc5100 = $F64d974c429d80be['activity_start'];
	$efc0f8f3059e4104 = $F64d974c429d80be['country_code'];

	if (empty($F64d974c429d80be['http_range']) || isset($_SERVER['HTTP_RANGE'])) {
	} else {
		$_SERVER['HTTP_RANGE'] = $F64d974c429d80be['http_range'];
	}
} else {
	generateError('NO_TOKEN_SPECIFIED');
}

if (XUI::$rSettings['use_buffer'] != 0) {
} else {
	header('X-Accel-Buffering: no');
}

if (!is_numeric($a63ba41c5c63ce14)) {
	if (substr_count($a63ba41c5c63ce14, '-') == 1) {
		list($c94b497359f8aed9, $C4af185e24cf9086) = explode('-', $a63ba41c5c63ce14);
		$A02729c83b6cd395 = substr($c94b497359f8aed9, 0, 4);
		$f01ae1008c6933f7 = substr($c94b497359f8aed9, 4, 2);
		$d20afc15ac839efc = substr($c94b497359f8aed9, 6, 2);
		$D1b34eaa5eef40cc = 0;
		$d08bd3f46de523f4 = $C4af185e24cf9086;
	} else {
		list($c94b497359f8aed9, $C4af185e24cf9086) = explode(':', $a63ba41c5c63ce14);
		list($A02729c83b6cd395, $f01ae1008c6933f7, $d20afc15ac839efc) = explode('-', $c94b497359f8aed9);
		list($d08bd3f46de523f4, $D1b34eaa5eef40cc) = explode('-', $C4af185e24cf9086);
	}

	$e0d8bd4d04af5371 = mktime($d08bd3f46de523f4, $D1b34eaa5eef40cc, 0, $f01ae1008c6933f7, $d20afc15ac839efc, $A02729c83b6cd395);
} else {
	$e0d8bd4d04af5371 = $a63ba41c5c63ce14;
}

$e2f848a82a80c113 = ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . gmdate('Y-m-d:H-i', $e0d8bd4d04af5371) . '.ts';

if (!(empty($F26087d31c2bbe4d) || empty($e0d8bd4d04af5371) || empty($C5034884ed44603a))) {
} else {
	generateError('NO_TIMESTAMP');
}

if (file_exists($e2f848a82a80c113) && is_readable($e2f848a82a80c113)) {
} else {
	generateError('ARCHIVE_DOESNT_EXIST');
}

$a9b7f153dce9637a = array();

for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < $C5034884ed44603a; $Ea22c4a9ab5b2176++) {
	$e2f848a82a80c113 = ARCHIVE_PATH . $F26087d31c2bbe4d . '/' . gmdate('Y-m-d:H-i', $e0d8bd4d04af5371 + $Ea22c4a9ab5b2176 * 60) . '.ts';

	if (!file_exists($e2f848a82a80c113)) {
	} else {
		$a9b7f153dce9637a[] = array('filename' => $e2f848a82a80c113, 'filesize' => filesize($e2f848a82a80c113));
	}
}

if (count($a9b7f153dce9637a) != 0) {
} else {
	generateError('ARCHIVE_DOESNT_EXIST');
}

if ($D4253f9520627819) {
	$db752e19806388c2 = (file_exists($a9b7f153dce9637a[0]['filename'] . '.offset') ? intval(file_get_contents($a9b7f153dce9637a[0]['filename'] . '.offset')) : 0);

	if ($a70eaa0ab42179dd) {
		$d58b4f8653a391d8 = $a70eaa0ab42179dd;
		$b2a9243e8304033d = $B5f1fb70f197b910;
	} else {
		$b2a9243e8304033d = null;
		$d58b4f8653a391d8 = ($B5f1fb70f197b910 ?: SERVER_ID);
	}

	if (XUI::$rSettings['redis_handler']) {
		XUI::BfA8B6fe314DED7f();
	} else {
		XUI::aD0a56BE17E95E81();
	}

	switch ($F9452a7efafa1aba) {
		case 'm3u8':
			if (XUI::$rSettings['redis_handler']) {
				$e110a2ab6d3a4734 = XUI::b85CCCEF157Fb67b($F64d974c429d80be['uuid']);
			} else {
				XUI::$db->query('SELECT `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `uuid` = ?;', $F64d974c429d80be['uuid']);

				if (0 >= XUI::$db->num_rows()) {
				} else {
					$e110a2ab6d3a4734 = XUI::$db->get_row();
				}
			}

			if (!$e110a2ab6d3a4734) {
				if (file_exists(CONS_TMP_PATH . $F64d974c429d80be['uuid']) || ($ffc0436d3fdc5100 + $D7102b1e2b296e66) - intval(XUI::$rServers[SERVER_ID]['time_offset']) >= time()) {
				} else {
					generateError('TOKEN_EXPIRED');
				}

				if (XUI::$rSettings['redis_handler']) {
					$Fc9594978cb1834f = array('user_id' => $D4253f9520627819['id'], 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => 'hls', 'pid' => null, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => '', 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => 0, 'identity' => $D4253f9520627819['id'], 'uuid' => $F64d974c429d80be['uuid']);
					$B59c127fecf35c15 = XUI::E0C928a3a83F24E9($Fc9594978cb1834f);
				} else {
					$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`user_id`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`,`hls_last_read`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?);', $D4253f9520627819['id'], $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, 'hls', null, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], '', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));
				}
			} else {
				$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $e110a2ab6d3a4734['user_ip']), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $e110a2ab6d3a4734['user_ip'] == $c59ec257c284c894);

				if ($ee7553b0caebc8c4 || !XUI::$rSettings['restrict_same_ip']) {
				} else {
					XUI::EA6C9A31f15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_MISMATCH', $c59ec257c284c894);
					generateError('IP_MISMATCH');
				}

				if (XUI::$rSettings['redis_handler']) {
					$a6b40128767dfe4f = array('hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));

					if ($e110a2ab6d3a4734 = XUI::e3484F74d3C8b5A7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'open')) {
						$B59c127fecf35c15 = true;
					} else {
						$B59c127fecf35c15 = false;
					}
				} else {
					$B59c127fecf35c15 = XUI::$db->query('UPDATE `lines_live` SET `hls_last_read` = ?, `hls_end` = 0 WHERE `activity_id` = ?', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), $e110a2ab6d3a4734['activity_id']);
				}
			}

			if ($B59c127fecf35c15) {
			} else {
				XUI::eA6C9A31F15a7b61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'LINE_CREATE_FAIL', $c59ec257c284c894);
				generateError('LINE_CREATE_FAIL');
			}

			XUI::dE9e9e0d836B5D86($D4253f9520627819, null, null, $c59ec257c284c894, $b3374866087774a1);

			if (XUI::$rSettings['redis_handler']) {
				XUI::B0B419a0354A0297();
			} else {
				XUI::f6CC02011179DfC7();
			}

			touch(CONS_TMP_PATH . $F64d974c429d80be['uuid']);
			$f433193a3297ffde = "#EXTM3U\n";
			$f433193a3297ffde .= "#EXT-X-VERSION:3\n";
			$f433193a3297ffde .= "#EXT-X-TARGETDURATION:60\n";
			$f433193a3297ffde .= "#EXT-X-MEDIA-SEQUENCE:0\n";
			$f433193a3297ffde .= "#EXT-X-PLAYLIST-TYPE:VOD\n";

			for ($Ea22c4a9ab5b2176 = 0; $Ea22c4a9ab5b2176 < count($a9b7f153dce9637a); $Ea22c4a9ab5b2176++) {
				$f433193a3297ffde .= "#EXTINF:60.0,\n";
				$f433193a3297ffde .= (($b2a9243e8304033d ? '/' . md5($b2a9243e8304033d . '_' . $d58b4f8653a391d8 . '_' . OPENSSL_EXTRA) : '')) . '/hls/' . Xui\Functions::encrypt('TS/' . $a71afc14d6cd090d . '/' . $d5249dad8e8411b7 . '/' . $c59ec257c284c894 . '/' . $C5034884ed44603a . '/' . $a63ba41c5c63ce14 . '/' . $F26087d31c2bbe4d . '_' . basename($a9b7f153dce9637a[$Ea22c4a9ab5b2176]['filename']) . '_' . (($Ea22c4a9ab5b2176 == 0 ? $db752e19806388c2 : 0)) . '/' . $F64d974c429d80be['uuid'] . '/' . $d58b4f8653a391d8, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA) . "\n";
			}
			$f433193a3297ffde .= '#EXT-X-ENDLIST';
			touch(CONS_TMP_PATH . $F64d974c429d80be['uuid']);
			ob_end_clean();
			header('Content-Type: application/x-mpegurl');
			header('Content-Length: ' . strlen($f433193a3297ffde));
			echo $f433193a3297ffde;

			exit();

		default:
			if (XUI::$rSettings['redis_handler']) {
				$e110a2ab6d3a4734 = XUI::b85CcCEF157FB67B($F64d974c429d80be['uuid']);
			} else {
				XUI::$db->query('SELECT `server_id`, `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `uuid` = ?;', $F64d974c429d80be['uuid']);

				if (0 < XUI::$db->num_rows()) {
					$e110a2ab6d3a4734 = XUI::$db->get_row();
				} else {
					if (empty($_SERVER['HTTP_RANGE'])) {
					} else {
						XUI::$db->query('SELECT `server_id`, `activity_id`, `pid`, `user_ip` FROM `lines_live` WHERE `hmac_id` = ? AND `hmac_identifier` = ? AND `container` = ? AND `user_agent` = ? AND `stream_id` = ?;', $B08e7d3cd339391a, $E18c40e895ee55c2, 'hls', $b3374866087774a1, $F26087d31c2bbe4d);

						if (0 >= XUI::$db->num_rows()) {
						} else {
							$e110a2ab6d3a4734 = XUI::$db->get_row();
						}
					}
				}
			}

			if (!$e110a2ab6d3a4734) {
				if (file_exists(CONS_TMP_PATH . $F64d974c429d80be['uuid']) || ($ffc0436d3fdc5100 + $D7102b1e2b296e66) - intval(XUI::$rServers[SERVER_ID]['time_offset']) >= time()) {
				} else {
					generateError('TOKEN_EXPIRED');
				}

				if (XUI::$rSettings['redis_handler']) {
					$Fc9594978cb1834f = array('user_id' => $D4253f9520627819['id'], 'stream_id' => $F26087d31c2bbe4d, 'server_id' => $d58b4f8653a391d8, 'proxy_id' => $b2a9243e8304033d, 'user_agent' => $b3374866087774a1, 'user_ip' => $c59ec257c284c894, 'container' => $F9452a7efafa1aba, 'pid' => $f9b07d216a168dcc, 'date_start' => $ffc0436d3fdc5100, 'geoip_country_code' => $efc0f8f3059e4104, 'isp' => $D4253f9520627819['con_isp_name'], 'external_device' => '', 'hls_end' => 0, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), 'on_demand' => 0, 'identity' => $D4253f9520627819['id'], 'uuid' => $F64d974c429d80be['uuid']);
					$B59c127fecf35c15 = XUI::e0C928A3a83F24e9($Fc9594978cb1834f);
				} else {
					$B59c127fecf35c15 = XUI::$db->query('INSERT INTO `lines_live` (`user_id`,`stream_id`,`server_id`,`proxy_id`,`user_agent`,`user_ip`,`container`,`pid`,`uuid`,`date_start`,`geoip_country_code`,`isp`,`external_device`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', $D4253f9520627819['id'], $F26087d31c2bbe4d, $d58b4f8653a391d8, $b2a9243e8304033d, $b3374866087774a1, $c59ec257c284c894, $F9452a7efafa1aba, $f9b07d216a168dcc, $F64d974c429d80be['uuid'], $ffc0436d3fdc5100, $efc0f8f3059e4104, $D4253f9520627819['con_isp_name'], '');
				}
			} else {
				$ee7553b0caebc8c4 = (XUI::$rSettings['ip_subnet_match'] ? implode('.', array_slice(explode('.', $e110a2ab6d3a4734['user_ip']), 0, -1)) == implode('.', array_slice(explode('.', $c59ec257c284c894), 0, -1)) : $e110a2ab6d3a4734['user_ip'] == $c59ec257c284c894);

				if ($ee7553b0caebc8c4 || !XUI::$rSettings['restrict_same_ip']) {
				} else {
					XUI::eA6C9a31F15a7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'IP_MISMATCH', $c59ec257c284c894);
					generateError('IP_MISMATCH');
				}

				if (!(XUI::dd714EE89c59fbF2($e110a2ab6d3a4734['pid'], 'php-fpm') && $f9b07d216a168dcc != $e110a2ab6d3a4734['pid'] && is_numeric($e110a2ab6d3a4734['pid']) && 0 < $e110a2ab6d3a4734['pid'])) {
				} else {
					if ($e110a2ab6d3a4734['server_id'] == SERVER_ID) {
						posix_kill(intval($e110a2ab6d3a4734['pid']), 9);
					} else {
						XUI::$db->query('INSERT INTO `signals` (`pid`,`server_id`,`time`) VALUES(?,?,UNIX_TIMESTAMP())', $e110a2ab6d3a4734['pid'], $e110a2ab6d3a4734['server_id']);
					}
				}

				if (XUI::$rSettings['redis_handler']) {
					$a6b40128767dfe4f = array('pid' => $f9b07d216a168dcc, 'hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));

					if ($e110a2ab6d3a4734 = XUI::E3484F74D3C8b5A7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'open')) {
						$B59c127fecf35c15 = true;
					} else {
						$B59c127fecf35c15 = false;
					}
				} else {
					$B59c127fecf35c15 = XUI::$db->query('UPDATE `lines_live` SET `hls_end` = 0, `pid` = ? WHERE `activity_id` = ?;', $f9b07d216a168dcc, $e110a2ab6d3a4734['activity_id']);
				}
			}

			if ($B59c127fecf35c15) {
			} else {
				XUI::EA6c9a31F15A7B61($F26087d31c2bbe4d, $D4253f9520627819['id'], 'LINE_CREATE_FAIL', $c59ec257c284c894);
				generateError('LINE_CREATE_FAIL');
			}

			XUI::DE9E9e0D836b5D86($D4253f9520627819, null, null, $c59ec257c284c894, $b3374866087774a1);

			if (XUI::$rSettings['redis_handler']) {
				XUI::B0b419A0354a0297();
			} else {
				XUI::F6cc02011179DfC7();
			}

			$Df5a05fb37ec64f1 = true;

			if (!XUI::$rSettings['monitor_connection_status']) {
			} else {
				ob_implicit_flush(true);

				while (ob_get_level()) {
					ob_end_clean();
				}
			}

			touch(CONS_TMP_PATH . $F64d974c429d80be['uuid']);
			header('Content-Type: video/mp2t');
			$f2d1c7bb81b31b19 = DIVERGENCE_TMP_PATH . $F64d974c429d80be['uuid'];
			$f0434521ea9d1547 = $b6c1b012e942c0b8 = getLength($a9b7f153dce9637a) - $db752e19806388c2;
			$aa2e54fde620d6b3 = ($b6c1b012e942c0b8 * 0.008) / ($C5034884ed44603a * 60);
			header('Accept-Ranges: 0-' . $f0434521ea9d1547);
			$D031c48a1422c07e = 0;
			$ae0b1e2a40cbc62a = $b6c1b012e942c0b8 - 1;

			if (empty($_SERVER['HTTP_RANGE'])) {
			} else {
				$f52aa5b1fe06dc56 = $D031c48a1422c07e;
				$e151114d7468d71c = $ae0b1e2a40cbc62a;
				list(, $c049b11cb92e6052) = explode('=', $_SERVER['HTTP_RANGE'], 2);

				if (strpos($c049b11cb92e6052, ',') === false) {
					if ($c049b11cb92e6052 == '-') {
						$f52aa5b1fe06dc56 = $b6c1b012e942c0b8 - substr($c049b11cb92e6052, 1);
					} else {
						$c049b11cb92e6052 = explode('-', $c049b11cb92e6052);
						$f52aa5b1fe06dc56 = $c049b11cb92e6052[0];
						$e151114d7468d71c = (isset($c049b11cb92e6052[1]) && is_numeric($c049b11cb92e6052[1]) ? $c049b11cb92e6052[1] : $b6c1b012e942c0b8);
					}

					$e151114d7468d71c = ($ae0b1e2a40cbc62a < $e151114d7468d71c ? $ae0b1e2a40cbc62a : $e151114d7468d71c);

					if (!($e151114d7468d71c < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 - 1 < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 <= $e151114d7468d71c)) {
						$D031c48a1422c07e = $f52aa5b1fe06dc56;
						$ae0b1e2a40cbc62a = $e151114d7468d71c;
						$f0434521ea9d1547 = $ae0b1e2a40cbc62a - $D031c48a1422c07e + 1;
						header('HTTP/1.1 206 Partial Content');
					} else {
						header('HTTP/1.1 416 Requested Range Not Satisfiable');
						header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

						exit();
					}
				} else {
					header('HTTP/1.1 416 Requested Range Not Satisfiable');
					header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

					exit();
				}
			}

			header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);
			header('Content-Length: ' . $f0434521ea9d1547);
			$D8be9e037fb79e63 = 0;

			if (0 >= $D031c48a1422c07e) {
			} else {
				$D8be9e037fb79e63 = floor($D031c48a1422c07e / ($b6c1b012e942c0b8 / count($a9b7f153dce9637a)));
			}

			$A3b0fac4071c183f = false;
			$fa03594b77e16dca = 0;
			$e18610440a2e11c3 = 0;
			$F47a81e1c4194642 = $aa2e54fde620d6b3 * 125;
			$F47a81e1c4194642 += $F47a81e1c4194642 * XUI::$rSettings['vod_bitrate_plus'] * 0.01;
			$Af547236269d8f66 = $fc5ed655689a77b9 = $B03be4d52f9e9b56 = time();
			$A327a54e7e10cd21 = 0;
			$b9f3f039ea3bf5ca = XUI::$rSettings['read_buffer_size'];
			$Ea22c4a9ab5b2176 = 0;
			$B75243d4c517712f = 0;

			if (0 < XUI::$rSettings['vod_limit_perc'] && !$D4253f9520627819['is_restreamer']) {
				$bd349a495a615ef5 = intval($f0434521ea9d1547 * floatval(XUI::$rSettings['vod_limit_perc'] / 100));
			} else {
				$bd349a495a615ef5 = $f0434521ea9d1547;
			}

			$c8d3b0fbe810a1c6 = false;

			foreach ($a9b7f153dce9637a as $D3fa098be3f297cd => $bb2621204e39e62d) {
				$e18610440a2e11c3 += $bb2621204e39e62d['filesize'];

				if ($A3b0fac4071c183f || 0 >= $D8be9e037fb79e63) {
				} else {
					if ($D3fa098be3f297cd < $D8be9e037fb79e63) {
					} else {
						$A3b0fac4071c183f = true;
						$fa03594b77e16dca = $D031c48a1422c07e - $e18610440a2e11c3;
					}
				}

				$e1644d67f855686d = fopen($bb2621204e39e62d['filename'], 'rb');
				fseek($e1644d67f855686d, $fa03594b77e16dca + $db752e19806388c2);
				$db752e19806388c2 = 0;

				while (!feof($e1644d67f855686d)) {
					$Dfa7f7fd6a9f18a8 = ftell($e1644d67f855686d);
					$c7488e8420e934e2 = stream_get_line($e1644d67f855686d, $b9f3f039ea3bf5ca);
					echo $c7488e8420e934e2;
					$A327a54e7e10cd21 += strlen($c7488e8420e934e2);
					$Ea22c4a9ab5b2176++;

					if (!$c8d3b0fbe810a1c6 && $bd349a495a615ef5 <= $B75243d4c517712f * $b9f3f039ea3bf5ca) {
						$c8d3b0fbe810a1c6 = true;
					} else {
						$B75243d4c517712f++;
					}

					if (!(0 < $F47a81e1c4194642 && $c8d3b0fbe810a1c6 && ceil($F47a81e1c4194642 / $b9f3f039ea3bf5ca) <= $Ea22c4a9ab5b2176)) {
					} else {
						sleep(1);
						$Ea22c4a9ab5b2176 = 0;
					}

					if (30 > time() - $B03be4d52f9e9b56) {
					} else {
						file_put_contents($f2d1c7bb81b31b19, intval($A327a54e7e10cd21 / 1024 / 30));
						$B03be4d52f9e9b56 = time();
						$A327a54e7e10cd21 = 0;
					}

					if (!(XUI::$rSettings['monitor_connection_status'] && 5 <= time() - $fc5ed655689a77b9)) {
					} else {
						if (connection_status() == CONNECTION_NORMAL) {
							$fc5ed655689a77b9 = time();
						} else {
							exit();
						}
					}

					if (300 > time() - $Af547236269d8f66) {
					} else {
						$Af547236269d8f66 = time();
						$e110a2ab6d3a4734 = null;
						XUI::$rSettings = XUI::aBb674425a8B1b0d('settings');

						if (XUI::$rSettings['redis_handler']) {
							XUI::bFa8b6FE314ded7f();
							$e110a2ab6d3a4734 = XUI::b85cccef157fB67B($F64d974c429d80be['uuid']);
							XUI::B0b419a0354A0297();
						} else {
							XUI::ad0a56be17E95e81();
							XUI::$db->query('SELECT `pid`, `hls_end` FROM `lines_live` WHERE `uuid` = ?', $F64d974c429d80be['uuid']);

							if (XUI::$db->num_rows() != 1) {
							} else {
								$e110a2ab6d3a4734 = XUI::$db->get_row();
							}

							XUI::F6Cc02011179DFC7();
						}

						if (!(!is_array($e110a2ab6d3a4734) || $e110a2ab6d3a4734['hls_end'] != 0 || $e110a2ab6d3a4734['pid'] != $f9b07d216a168dcc)) {
						} else {
							exit();
						}
					}
				}

				if (!is_resource($e1644d67f855686d)) {
				} else {
					fclose($e1644d67f855686d);
				}

				$fa03594b77e16dca = 0;
			}
	}
} else {
	generateError('TOKEN_ERROR');
}

function getLength($a9b7f153dce9637a)
{
	$f0434521ea9d1547 = 0;

	foreach ($a9b7f153dce9637a as $bb2621204e39e62d) {
		$f0434521ea9d1547 += $bb2621204e39e62d['filesize'];
	}

	return $f0434521ea9d1547;
}

function shutdown()
{
	global $Df5a05fb37ec64f1;
	global $F64d974c429d80be;
	global $f9b07d216a168dcc;
	XUI::$rSettings = XUI::aBB674425A8b1B0d('settings');

	if (!$Df5a05fb37ec64f1) {
	} else {
		if (XUI::$rSettings['redis_handler']) {
			if (is_object(XUI::$redis)) {
			} else {
				XUI::Bfa8b6fE314ded7f();
			}

			$e110a2ab6d3a4734 = XUI::B85CcCef157Fb67B($F64d974c429d80be['uuid']);

			if (!($e110a2ab6d3a4734 && $e110a2ab6d3a4734['pid'] == $f9b07d216a168dcc)) {
			} else {
				$a6b40128767dfe4f = array('hls_last_read' => time() - intval(XUI::$rServers[SERVER_ID]['time_offset']));
				XUI::e3484F74D3c8B5A7($e110a2ab6d3a4734, $a6b40128767dfe4f, 'close');
			}
		} else {
			if (is_object(XUI::$db)) {
			} else {
				XUI::AD0A56BE17e95E81();
			}

			XUI::$db->query('UPDATE `lines_live` SET `hls_end` = 1, `hls_last_read` = ? WHERE `uuid` = ? AND `pid` = ?;', time() - intval(XUI::$rServers[SERVER_ID]['time_offset']), $F64d974c429d80be['uuid'], $f9b07d216a168dcc);
		}
	}

	if (!XUI::$rSettings['redis_handler'] && is_object(XUI::$db)) {
		XUI::F6Cc02011179dFC7();
	} else {
		if (!(XUI::$rSettings['redis_handler'] && is_object(XUI::$redis))) {
		} else {
			XUI::b0B419a0354a0297();
		}
	}
}
