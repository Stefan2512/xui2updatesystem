<?php

register_shutdown_function('shutdown');
set_time_limit(0);
require 'init.php';
$Dab081f66facd7a3 = true;
a44e33f783474e1c();
function A44e33F783474E1C()
{
	global $Dab081f66facd7a3;

	if (empty(XUI::$rRequest['status'])) {
	} else {
		if (!($Ba23222f3ed2dc08 = Xui\Functions::checkStatus(XUI::$rRequest['data']))) {
		} else {
			exit($Ba23222f3ed2dc08);
		}
	}

	if (!(empty(XUI::$rRequest['password']) || XUI::$rRequest['password'] != XUI::$rSettings['live_streaming_pass'])) {
	} else {
		generateError('INVALID_API_PASSWORD');
	}

	unset(XUI::$rRequest['password']);
	$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
	XUI::$db = &$Fee0d5a474c96306;

	if (in_array($c59ec257c284c894, XUI::C5931CD0269D0a3D())) {
	} else {
		generateError('API_IP_NOT_ALLOWED');
	}

	header('Access-Control-Allow-Origin: *');
	$fa7da6c202358e0c = (!empty(XUI::$rRequest['action']) ? XUI::$rRequest['action'] : '');
	$Dab081f66facd7a3 = false;

	switch ($fa7da6c202358e0c) {
		case 'view_log':
			if (empty(XUI::$rRequest['stream_id'])) {
				break;
			}

			$F26087d31c2bbe4d = intval(XUI::$rRequest['stream_id']);

			if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '.errors')) {
				echo file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '.errors');
			} else {
				if (!file_exists(VOD_PATH . $F26087d31c2bbe4d . '.errors')) {
				} else {
					echo file_get_contents(VOD_PATH . $F26087d31c2bbe4d . '.errors');
				}
			}

			exit();

		case 'fpm_status':
			echo file_get_contents('http://127.0.0.1:' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/status');

			break;

		case 'reload_epg':
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'epg.php >/dev/null 2>/dev/null &');

			break;

		case 'restore_images':
			shell_exec(PHP_BIN . ' ' . INCLUDES_PATH . 'cli/tools.php "images" >/dev/null 2>/dev/null &');

			break;

		case 'reload_nginx':
			shell_exec(BIN_PATH . 'nginx_rtmp/sbin/nginx_rtmp -s reload');
			shell_exec(BIN_PATH . 'nginx/sbin/nginx -s reload');

			break;

		case 'streams_ramdisk':
			set_time_limit(30);
			$a85e1b7d42c346a0 = array('result' => true, 'streams' => array());
			exec('ls -l ' . STREAMS_PATH, $b93e6a2691d72853);

			foreach ($b93e6a2691d72853 as $e2f848a82a80c113) {
				$B211d7401e6242f3 = explode(' ', preg_replace('!\\s+!', ' ', $e2f848a82a80c113));
				$E8918b18298ad4a9 = explode('_', $B211d7401e6242f3[count($B211d7401e6242f3) - 1]);

				if (count($E8918b18298ad4a9) != 2) {
				} else {
					$F26087d31c2bbe4d = intval($E8918b18298ad4a9[0]);
					$d5e02507ff0f10b3 = intval($B211d7401e6242f3[4]);

					if (!(0 < $F26087d31c2bbe4d & 0 < $d5e02507ff0f10b3)) {
					} else {
						$a85e1b7d42c346a0['streams'][$F26087d31c2bbe4d] += $d5e02507ff0f10b3;
					}
				}
			}
			echo json_encode($a85e1b7d42c346a0);

			exit();

		case 'vod':
			if (empty(XUI::$rRequest['stream_ids']) || empty(XUI::$rRequest['function'])) {
			} else {
				$Cdb85875fd50f459 = array_map('intval', XUI::$rRequest['stream_ids']);
				$e06ef1381864ef21 = XUI::$rRequest['function'];

				switch ($e06ef1381864ef21) {
					case 'start':
						foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
							XUI::ce7106285C19A01a($F26087d31c2bbe4d, true);

							if (isset(XUI::$rRequest['force']) && XUI::$rRequest['force']) {
								XUI::eD56A02053a7dD1F($F26087d31c2bbe4d);
							} else {
								XUI::queueMovie($F26087d31c2bbe4d);
							}
						}
						echo json_encode(array('result' => true));

						exit();

					case 'stop':
						foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
							XUI::CE7106285c19a01a($F26087d31c2bbe4d);
						}
						echo json_encode(array('result' => true));

						exit();
				}
			}

			// no break
		case 'rtmp_stats':
			echo json_encode(XUI::cb312596ce3652d6());

			break;

		case 'kill_pid':
			$f9b07d216a168dcc = intval(XUI::$rRequest['pid']);

			if (0 < $f9b07d216a168dcc) {
				posix_kill($f9b07d216a168dcc, 9);
				echo json_encode(array('result' => true));
			} else {
				echo json_encode(array('result' => false));
			}

			break;

		case 'rtmp_kill':
			$d9ee1cc8e0f43f6e = XUI::$rRequest['name'];
			shell_exec('wget --timeout=2 -O /dev/null -o /dev/null "' . XUI::$rServers[SERVER_ID]['rtmp_mport_url'] . 'control/drop/publisher?app=live&name=' . escapeshellcmd($d9ee1cc8e0f43f6e) . '" >/dev/null 2>/dev/null &');
			echo json_encode(array('result' => true));

			exit();

		case 'stream':
			if (empty(XUI::$rRequest['stream_ids']) || empty(XUI::$rRequest['function'])) {
			} else {
				$Cdb85875fd50f459 = array_map('intval', XUI::$rRequest['stream_ids']);
				$e06ef1381864ef21 = XUI::$rRequest['function'];

				switch ($e06ef1381864ef21) {
					case 'start':
						foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
							if (XUI::dac4D82f05378662($F26087d31c2bbe4d, true)) {
								usleep(50000);
							} else {
								echo json_encode(array('result' => false));

								exit();
							}
						}
						echo json_encode(array('result' => true));

						exit();

					case 'stop':
						foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
							XUI::A52ea4c1eAD81DE2($F26087d31c2bbe4d, true);
						}
						echo json_encode(array('result' => true));

						exit();

					default:
						break;
				}
			}

			// no break
		case 'stats':
			echo json_encode(XUI::F4148D7dFAEE2F14());

			exit();

		case 'force_stream':
			$F26087d31c2bbe4d = intval(XUI::$rRequest['stream_id']);
			$Cc34cb9d37801a94 = intval(XUI::$rRequest['force_id']);

			if (0 >= $F26087d31c2bbe4d) {
			} else {
				file_put_contents(SIGNALS_TMP_PATH . $F26087d31c2bbe4d . '.force', $Cc34cb9d37801a94);
			}

			exit(json_encode(array('result' => true)));

		case 'closeConnection':
			XUI::E8e9D6b2b107d8ae(intval(XUI::$rRequest['activity_id']));

			exit(json_encode(array('result' => true)));

		case 'pidsAreRunning':
			if (empty(XUI::$rRequest['pids']) || !is_array(XUI::$rRequest['pids']) || empty(XUI::$rRequest['program'])) {
				break;
			}

			$c078f3ed0fe7b4fa = array_map('intval', XUI::$rRequest['pids']);
			$B5f95fd45de6e486 = XUI::$rRequest['program'];
			$f433193a3297ffde = array();

			foreach ($c078f3ed0fe7b4fa as $f9b07d216a168dcc) {
				$f433193a3297ffde[$f9b07d216a168dcc] = false;

				if (!(file_exists('/proc/' . $f9b07d216a168dcc) && is_readable('/proc/' . $f9b07d216a168dcc . '/exe') && strpos(basename(readlink('/proc/' . $f9b07d216a168dcc . '/exe')), basename($B5f95fd45de6e486)) === 0)) {
				} else {
					$f433193a3297ffde[$f9b07d216a168dcc] = true;
				}
			}
			echo json_encode($f433193a3297ffde);

			exit();

		case 'getFile':
			if (empty(XUI::$rRequest['filename'])) {
				break;
			}

			$bc2874292e0d9ece = XUI::$rRequest['filename'];

			if (in_array(strtolower(pathinfo($bc2874292e0d9ece)['extension']), array('log', 'tar.gz', 'gz', 'zip', 'm3u8', 'mp4', 'mkv', 'avi', 'mpg', 'flv', '3gp', 'm4v', 'wmv', 'mov', 'ts', 'srt', 'sub', 'sbv', 'jpg', 'png', 'bmp', 'jpeg', 'gif', 'tif'))) {
				if (!(file_exists($bc2874292e0d9ece) && is_readable($bc2874292e0d9ece))) {
				} else {
					header('Content-Type: application/octet-stream');
					$e1644d67f855686d = @fopen($bc2874292e0d9ece, 'rb');
					$b6c1b012e942c0b8 = filesize($bc2874292e0d9ece);
					$f0434521ea9d1547 = $b6c1b012e942c0b8;
					$D031c48a1422c07e = 0;
					$ae0b1e2a40cbc62a = $b6c1b012e942c0b8 - 1;
					header('Accept-Ranges: 0-' . $f0434521ea9d1547);

					if (!isset($_SERVER['HTTP_RANGE'])) {
					} else {
						$e151114d7468d71c = $ae0b1e2a40cbc62a;
						list(, $c049b11cb92e6052) = explode('=', $_SERVER['HTTP_RANGE'], 2);

						if (strpos($c049b11cb92e6052, ',') === false) {
							if ($c049b11cb92e6052 == '-') {
								$f52aa5b1fe06dc56 = $b6c1b012e942c0b8 - substr($c049b11cb92e6052, 1);
							} else {
								$c049b11cb92e6052 = explode('-', $c049b11cb92e6052);
								$f52aa5b1fe06dc56 = $c049b11cb92e6052[0];
								$e151114d7468d71c = (isset($c049b11cb92e6052[1]) && is_numeric($c049b11cb92e6052[1]) ? $c049b11cb92e6052[1] : $b6c1b012e942c0b8);
							}

							$e151114d7468d71c = ($ae0b1e2a40cbc62a < $e151114d7468d71c ? $ae0b1e2a40cbc62a : $e151114d7468d71c);

							if (!($e151114d7468d71c < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 - 1 < $f52aa5b1fe06dc56 || $b6c1b012e942c0b8 <= $e151114d7468d71c)) {
								$D031c48a1422c07e = $f52aa5b1fe06dc56;
								$ae0b1e2a40cbc62a = $e151114d7468d71c;
								$f0434521ea9d1547 = $ae0b1e2a40cbc62a - $D031c48a1422c07e + 1;
								fseek($e1644d67f855686d, $D031c48a1422c07e);
								header('HTTP/1.1 206 Partial Content');
							} else {
								header('HTTP/1.1 416 Requested Range Not Satisfiable');
								header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

								exit();
							}
						} else {
							header('HTTP/1.1 416 Requested Range Not Satisfiable');
							header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);

							exit();
						}
					}

					header('Content-Range: bytes ' . $D031c48a1422c07e . '-' . $ae0b1e2a40cbc62a . '/' . $b6c1b012e942c0b8);
					header('Content-Length: ' . $f0434521ea9d1547);

					while (!feof($e1644d67f855686d) && ftell($e1644d67f855686d) <= $ae0b1e2a40cbc62a) {
						echo stream_get_line($e1644d67f855686d, (intval(XUI::$rSettings['read_buffer_size']) ?: 8192));
					}
					fclose($e1644d67f855686d);
				}

				exit();
			}

			exit(json_encode(array('result' => false, 'error' => 'Invalid file extension.')));

		case 'scandir_recursive':
			set_time_limit(30);
			$aba46ae86a79ad10 = urldecode(XUI::$rRequest['dir']);
			$E3b8f15bd840a0df = (!empty(XUI::$rRequest['allowed']) ? urldecode(XUI::$rRequest['allowed']) : null);

			if (!file_exists($aba46ae86a79ad10)) {
				exit(json_encode(array('result' => false)));
			}

			if ($E3b8f15bd840a0df) {
				$cf1c389bda3e30fd = '/usr/bin/find ' . escapeshellarg($aba46ae86a79ad10) . ' -regex ".*\\.\\(' . escapeshellcmd($E3b8f15bd840a0df) . '\\)"';
			} else {
				$cf1c389bda3e30fd = '/usr/bin/find ' . escapeshellarg($aba46ae86a79ad10);
			}

			exec($cf1c389bda3e30fd, $a85e1b7d42c346a0);
			echo json_encode($a85e1b7d42c346a0, JSON_UNESCAPED_UNICODE);

			exit();

		case 'scandir':
			set_time_limit(30);
			$aba46ae86a79ad10 = urldecode(XUI::$rRequest['dir']);
			$E3b8f15bd840a0df = (!empty(XUI::$rRequest['allowed']) ? explode('|', urldecode(XUI::$rRequest['allowed'])) : array());

			if (!file_exists($aba46ae86a79ad10)) {
				exit(json_encode(array('result' => false)));
			}

			$a85e1b7d42c346a0 = array('result' => true, 'dirs' => array(), 'files' => array());
			$b93e6a2691d72853 = scanDir($aba46ae86a79ad10);

			foreach ($b93e6a2691d72853 as $D3fa098be3f297cd => $b6842cb20051e925) {
				if (in_array($b6842cb20051e925, array('.', '..'))) {
				} else {
					if (is_dir($aba46ae86a79ad10 . '/' . $b6842cb20051e925)) {
						$a85e1b7d42c346a0['dirs'][] = $b6842cb20051e925;
					} else {
						$C6a7103a3e51b098 = strtolower(pathinfo($b6842cb20051e925)['extension']);

						if (!(is_array($E3b8f15bd840a0df) && in_array($C6a7103a3e51b098, $E3b8f15bd840a0df)) && $E3b8f15bd840a0df) {
						} else {
							$a85e1b7d42c346a0['files'][] = $b6842cb20051e925;
						}
					}
				}
			}
			echo json_encode($a85e1b7d42c346a0);

			exit();

		case 'get_free_space':
			exec('df -h', $a85e1b7d42c346a0);
			echo json_encode($a85e1b7d42c346a0);

			exit();

		case 'get_pids':
			exec('ps -e -o user,pid,%cpu,%mem,vsz,rss,tty,stat,time,etime,command', $a85e1b7d42c346a0);
			echo json_encode($a85e1b7d42c346a0);

			exit();

		case 'redirect_connection':
			if (empty(XUI::$rRequest['uuid']) || empty(XUI::$rRequest['stream_id'])) {
			} else {
				XUI::$rRequest['type'] = 'redirect';
				file_put_contents(SIGNALS_PATH . XUI::$rRequest['uuid'], json_encode(XUI::$rRequest));
			}

			break;

		case 'free_temp':
			exec('rm -rf ' . XUI_HOME . 'tmp/*');
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'cache.php');
			echo json_encode(array('result' => true));

			break;

		case 'free_streams':
			exec('rm ' . XUI_HOME . 'content/streams/*');
			echo json_encode(array('result' => true));

			break;

		case 'signal_send':
			if (empty(XUI::$rRequest['message']) || empty(XUI::$rRequest['uuid'])) {
			} else {
				XUI::$rRequest['type'] = 'signal';
				file_put_contents(SIGNALS_PATH . XUI::$rRequest['uuid'], json_encode(XUI::$rRequest));
			}

			break;

		case 'get_certificate_info':
			echo json_encode(XUI::ac86C84C80E63449());

			exit();

		case 'watch_force':
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'watch.php ' . intval(XUI::$rRequest['id']) . ' >/dev/null 2>/dev/null &');

			break;

		case 'plex_force':
			shell_exec(PHP_BIN . ' ' . CRON_PATH . 'plex.php ' . intval(XUI::$rRequest['id']) . ' >/dev/null 2>/dev/null &');

			break;

		case 'get_archive_files':
			$F26087d31c2bbe4d = intval(XUI::$rRequest['stream_id']);
			echo json_encode(array('result' => true, 'data' => glob(ARCHIVE_PATH . $F26087d31c2bbe4d . '/*.ts')));

			exit();

		case 'request_update':
			if (XUI::$rRequest['type'] == 0) {
				$e2f848a82a80c113 = LOADBALANCER_UPDATE;
			} else {
				$e2f848a82a80c113 = PROXY_UPDATE;
			}

			if (!file_exists($e2f848a82a80c113)) {
				exit(json_encode(array('result' => false)));
			}

			$Ba344b2758e3e955 = md5_file($e2f848a82a80c113);
			$C700a2b357e5ed65 = 'http://' . XUI::$rServers[SERVER_ID]['server_ip'] . ':' . XUI::$rServers[SERVER_ID]['http_broadcast_port'] . '/api?password=' . XUI::$rSettings['live_streaming_pass'] . '&action=getFile&filename=' . urlencode($e2f848a82a80c113);

			exit(json_encode(array('result' => true, 'md5' => $Ba344b2758e3e955, 'url' => $C700a2b357e5ed65, 'version' => XUI::$rServers[SERVER_ID]['xui_version'])));

		case 'kill_watch':
			if (file_exists(CACHE_TMP_PATH . 'watch_pid')) {
				$fa4e2ace7000737b = intval(file_get_contents(CACHE_TMP_PATH . 'watch_pid'));
			} else {
				$fa4e2ace7000737b = null;
			}

			if (!($fa4e2ace7000737b && XUI::dd714eE89C59FbF2($fa4e2ace7000737b, 'php'))) {
			} else {
				shell_exec('kill -9 ' . $fa4e2ace7000737b);
			}

			$c078f3ed0fe7b4fa = glob(WATCH_TMP_PATH . '*.wpid');

			foreach ($c078f3ed0fe7b4fa as $Afb8a491b33b9172) {
				$f9b07d216a168dcc = intval(basename($Afb8a491b33b9172, '.wpid'));

				if (!($f9b07d216a168dcc && XUI::dd714eE89c59Fbf2($f9b07d216a168dcc, 'php'))) {
				} else {
					shell_exec('kill -9 ' . $f9b07d216a168dcc);
				}

				unlink($Afb8a491b33b9172);
			}

			exit(json_encode(array('result' => true)));

		case 'kill_plex':
			if (file_exists(CACHE_TMP_PATH . 'plex_pid')) {
				$fa4e2ace7000737b = intval(file_get_contents(CACHE_TMP_PATH . 'plex_pid'));
			} else {
				$fa4e2ace7000737b = null;
			}

			if (!($fa4e2ace7000737b && XUI::Dd714EE89C59fBf2($fa4e2ace7000737b, 'php'))) {
			} else {
				shell_exec('kill -9 ' . $fa4e2ace7000737b);
			}

			$c078f3ed0fe7b4fa = glob(WATCH_TMP_PATH . '*.ppid');

			foreach ($c078f3ed0fe7b4fa as $Afb8a491b33b9172) {
				$f9b07d216a168dcc = intval(basename($Afb8a491b33b9172, '.ppid'));

				if (!($f9b07d216a168dcc && XUI::Dd714eE89c59fbf2($f9b07d216a168dcc, 'php'))) {
				} else {
					shell_exec('kill -9 ' . $f9b07d216a168dcc);
				}

				unlink($Afb8a491b33b9172);
			}

			exit(json_encode(array('result' => true)));

		case 'probe':
			if (empty(XUI::$rRequest['url'])) {
				exit(json_encode(array('result' => false)));
			}

			$C700a2b357e5ed65 = escapeshellcmd(XUI::$rRequest['url']);
			$f145176c7c32ac18 = array();

			if (!XUI::$rRequest['user_agent']) {
			} else {
				$f145176c7c32ac18[] = sprintf("-user_agent '%s'", escapeshellcmd(XUI::$rRequest['user_agent']));
			}

			if (!XUI::$rRequest['http_proxy']) {
			} else {
				$f145176c7c32ac18[] = sprintf("-http_proxy '%s'", escapeshellcmd(XUI::$rRequest['http_proxy']));
			}

			if (!XUI::$rRequest['cookies']) {
			} else {
				$f145176c7c32ac18[] = sprintf("-cookies '%s'", escapeshellcmd(XUI::$rRequest['cookies']));
			}

			$Ae2b613e51651b56 = (XUI::$rRequest['headers'] ? rtrim(XUI::$rRequest['headers'], "\r\n") . "\r\n" : '');
			$Ae2b613e51651b56 .= 'X-XUI-Prebuffer:1' . "\r\n";
			$f145176c7c32ac18[] = sprintf('-headers %s', escapeshellarg($Ae2b613e51651b56));

			exit(json_encode(array('result' => true, 'data' => XUI::c8851B830A0692CD($C700a2b357e5ed65, $f145176c7c32ac18, '', false))));

		default:
			exit(json_encode(array('result' => false)));
	}
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $Dab081f66facd7a3;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::FC8474658ec80360();
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}
}
