<?php

register_shutdown_function('shutdown');
include './stream/init.php';

if (!isset(XUI::$rRequest['data'])) {
} else {
	$c59ec257c284c894 = XUI::A9bc416Fa6fa55c3();
	$Bc16cc77a681d1ed = base64_decode(XUI::$rRequest['data']);
	$cb261e066dc5f336 = count(explode('/', $Bc16cc77a681d1ed));
	$D4253f9520627819 = $F26087d31c2bbe4d = null;

	if ($cb261e066dc5f336 == 3) {
		if ($F26087d31c2bbe4d) {
		} else {
			$A6d7047f2fda966c = '/\\/auth\\/(.*)$/m';
			preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

			if (count($b85ce31cd1118ad2) != 2) {
			} else {
				$a27e64cc6ce01033 = json_decode(Xui\Functions::decrypt($b85ce31cd1118ad2[1], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA), true);
				$F26087d31c2bbe4d = intval($a27e64cc6ce01033['stream_id']);
				$D4253f9520627819 = XUI::D7cA435aC70e9a78(null, $a27e64cc6ce01033['username'], $a27e64cc6ce01033['password'], true);
			}
		}

		if ($F26087d31c2bbe4d) {
		} else {
			$A6d7047f2fda966c = '/\\/play\\/(.*)$/m';
			preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

			if (count($b85ce31cd1118ad2) != 2) {
			} else {
				$a27e64cc6ce01033 = explode('/', Xui\Functions::decrypt($b85ce31cd1118ad2[1], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA));

				if ($a27e64cc6ce01033[0] != 'live') {
				} else {
					$F26087d31c2bbe4d = intval($a27e64cc6ce01033[3]);
					$D4253f9520627819 = XUI::D7ca435AC70e9A78(null, $a27e64cc6ce01033[1], $a27e64cc6ce01033[2], true);
				}
			}
		}
	} else {
		if ($cb261e066dc5f336 == 4) {
			if ($F26087d31c2bbe4d) {
			} else {
				$A6d7047f2fda966c = '/\\/play\\/(.*)\\/(.*)$/m';
				preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

				if (count($b85ce31cd1118ad2) != 3) {
				} else {
					$a27e64cc6ce01033 = explode('/', Xui\Functions::decrypt($b85ce31cd1118ad2[1], XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA));

					if ($a27e64cc6ce01033[0] != 'live') {
					} else {
						$F26087d31c2bbe4d = intval($a27e64cc6ce01033[3]);
						$D4253f9520627819 = XUI::D7ca435ac70e9a78(null, $a27e64cc6ce01033[1], $a27e64cc6ce01033[2], true);
					}
				}
			}

			if ($F26087d31c2bbe4d) {
			} else {
				$A6d7047f2fda966c = '/\\/live\\/(.*)\\/(\\d+)$/m';
				preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

				if (count($b85ce31cd1118ad2) != 3) {
				} else {
					$F26087d31c2bbe4d = intval($b85ce31cd1118ad2[2]);
					$D4253f9520627819 = XUI::D7Ca435Ac70e9A78(null, $b85ce31cd1118ad2[1], null, true);
				}
			}

			if ($F26087d31c2bbe4d) {
			} else {
				$A6d7047f2fda966c = '/\\/live\\/(.*)\\/(\\d+)\\.(.*)$/m';
				preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

				if (count($b85ce31cd1118ad2) != 4) {
				} else {
					$F26087d31c2bbe4d = intval($b85ce31cd1118ad2[2]);
					$D4253f9520627819 = XUI::D7CA435Ac70e9a78(null, $b85ce31cd1118ad2[1], null, true);
				}
			}

			if ($F26087d31c2bbe4d) {
			} else {
				$A6d7047f2fda966c = '/\\/(.*)\\/(.*)\\/(\\d+)\\.(.*)$/m';
				preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

				if (count($b85ce31cd1118ad2) != 5) {
				} else {
					$F26087d31c2bbe4d = intval($b85ce31cd1118ad2[3]);
					$D4253f9520627819 = XUI::d7CA435ac70E9a78(null, $b85ce31cd1118ad2[1], $b85ce31cd1118ad2[2], true);
				}
			}

			if ($F26087d31c2bbe4d) {
			} else {
				$A6d7047f2fda966c = '/\\/(.*)\\/(.*)\\/(\\d+)$/m';
				preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

				if (count($b85ce31cd1118ad2) != 4) {
				} else {
					$F26087d31c2bbe4d = intval($b85ce31cd1118ad2[3]);
					$D4253f9520627819 = XUI::D7CA435ac70E9a78(null, $b85ce31cd1118ad2[1], $b85ce31cd1118ad2[2], true);
				}
			}
		} else {
			if ($cb261e066dc5f336 != 5) {
			} else {
				if ($F26087d31c2bbe4d) {
				} else {
					$A6d7047f2fda966c = '/\\/live\\/(.*)\\/(.*)\\/(\\d+)\\.(.*)$/m';
					preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

					if (count($b85ce31cd1118ad2) != 5) {
					} else {
						$F26087d31c2bbe4d = intval($b85ce31cd1118ad2[3]);
						$D4253f9520627819 = XUI::D7ca435aC70e9A78(null, $b85ce31cd1118ad2[1], $b85ce31cd1118ad2[2], true);
					}
				}

				if ($F26087d31c2bbe4d) {
				} else {
					$A6d7047f2fda966c = '/\\/live\\/(.*)\\/(.*)\\/(\\d+)$/m';
					preg_match($A6d7047f2fda966c, $Bc16cc77a681d1ed, $b85ce31cd1118ad2);

					if (count($b85ce31cd1118ad2) != 4) {
					} else {
						$F26087d31c2bbe4d = intval($b85ce31cd1118ad2[3]);
						$D4253f9520627819 = XUI::d7ca435aC70e9A78(null, $b85ce31cd1118ad2[1], $b85ce31cd1118ad2[2], true);
					}
				}
			}
		}
	}

	if (!($F26087d31c2bbe4d && $D4253f9520627819)) {
	} else {
		if (is_null($D4253f9520627819['exp_date']) || $D4253f9520627819['exp_date'] > time()) {
		} else {
			dB709eD65AE02245();
		}

		if ($D4253f9520627819['admin_enabled'] != 0) {
		} else {
			Db709Ed65aE02245();
		}

		if ($D4253f9520627819['enabled'] != 0) {
		} else {
			DB709eD65AE02245();
		}

		if ($D4253f9520627819['is_restreamer']) {
		} else {
			DB709ED65ae02245();
		}

		$fca7edf85daa1695 = XUI::B3ed925e7969f61A($F26087d31c2bbe4d, 'ts', $D4253f9520627819, null, '', 'live');

		if (isset($fca7edf85daa1695['redirect_id']) && $fca7edf85daa1695['redirect_id'] != SERVER_ID) {
			$d58b4f8653a391d8 = $fca7edf85daa1695['redirect_id'];
		} else {
			$d58b4f8653a391d8 = SERVER_ID;
		}

		if (!(0 < $fca7edf85daa1695['monitor_pid'] && 0 < $fca7edf85daa1695['pid'] && XUI::$rServers[$d58b4f8653a391d8]['last_status'] == 1)) {
		} else {
			if (file_exists(STREAMS_PATH . $F26087d31c2bbe4d . '_.stream_info')) {
				$Eea1b980ebbe2a33 = file_get_contents(STREAMS_PATH . $F26087d31c2bbe4d . '_.stream_info');
			} else {
				$Eea1b980ebbe2a33 = $fca7edf85daa1695['stream_info'];
			}

			$Eea1b980ebbe2a33 = json_decode($Eea1b980ebbe2a33, true);
			echo json_encode(array('codecs' => $Eea1b980ebbe2a33['codecs'], 'container' => $Eea1b980ebbe2a33['container'], 'bitrate' => $Eea1b980ebbe2a33['bitrate']));

			exit();
		}
	}
}

Db709eD65AE02245();
function shutdown()
{
	if (!is_object(XUI::$db)) {
	} else {
		XUI::$db->close_mysql();
	}
}
