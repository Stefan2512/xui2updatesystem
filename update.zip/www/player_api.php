<?php

register_shutdown_function('shutdown');
require './stream/init.php';
set_time_limit(0);

if (!XUI::$rSettings['force_epg_timezone']) {
} else {
	date_default_timezone_set('UTC');
}

$Dab081f66facd7a3 = true;

if (!XUI::$rSettings['disable_player_api']) {
} else {
	$Dab081f66facd7a3 = false;
	generateError('PLAYER_API_DISABLED');
}

$Da373370efdfacde = false;

if (strtolower(explode('.', ltrim(parse_url($_SERVER['REQUEST_URI'])['path'], '/'))[0]) != 'panel_api') {
} else {
	if (!XUI::$rSettings['legacy_panel_api']) {
		$Dab081f66facd7a3 = false;
		generateError('LEGACY_PANEL_API_DISABLED');
	} else {
		$Da373370efdfacde = true;
	}
}

$c59ec257c284c894 = $_SERVER['REMOTE_ADDR'];
$b3374866087774a1 = trim($_SERVER['HTTP_USER_AGENT']);
$db752e19806388c2 = (empty(XUI::$rRequest['params']['offset']) ? 0 : abs(intval(XUI::$rRequest['params']['offset'])));
$E400a3101514583e = (empty(XUI::$rRequest['params']['items_per_page']) ? 0 : abs(intval(XUI::$rRequest['params']['items_per_page'])));
$e8ec22795e2f3e59 = array('live' => 'Live Streams', 'movie' => 'Movies', 'created_live' => 'Created Channels', 'radio_streams' => 'Radio Stations', 'series' => 'TV Series');
$Ca5a0830e8583ff3 = XUI::d55A1d8acd201840();
$Caecf2bcd39a1efe = parse_url($Ca5a0830e8583ff3)['host'];
$ac0505d5736210cf = array('get_epg', 200 => 'get_vod_categories', 201 => 'get_live_categories', 202 => 'get_live_streams', 203 => 'get_vod_streams', 204 => 'get_series_info', 205 => 'get_short_epg', 206 => 'get_series_categories', 207 => 'get_simple_data_table', 208 => 'get_series', 209 => 'get_vod_info');
$f433193a3297ffde = array();
$fa7da6c202358e0c = (!empty(XUI::$rRequest['action']) && (in_array(XUI::$rRequest['action'], $ac0505d5736210cf) || array_key_exists(XUI::$rRequest['action'], $ac0505d5736210cf)) ? XUI::$rRequest['action'] : '');

if (!isset($ac0505d5736210cf[$fa7da6c202358e0c])) {
} else {
	$fa7da6c202358e0c = $ac0505d5736210cf[$fa7da6c202358e0c];
}

if ($Da373370efdfacde && empty($fa7da6c202358e0c)) {
	$Ad082f0a5542a888 = true;
} else {
	$Ad082f0a5542a888 = in_array($fa7da6c202358e0c, array('get_series', 'get_vod_streams', 'get_live_streams'));
}

if (!$Ad082f0a5542a888) {
} else {
	XUI::$rBouquets = XUI::Abb674425a8B1b0D('bouquets');
}

if (!($Da373370efdfacde && empty($fa7da6c202358e0c) || in_array($fa7da6c202358e0c, array('get_vod_categories', 'get_series_categories', 'get_live_categories')))) {
} else {
	XUI::$rCategories = XUI::abb674425a8b1b0D('categories');
}

$f1633abde8f84cd1 = array('offset' => $db752e19806388c2, 'items_per_page' => $E400a3101514583e);

if (isset(XUI::$rRequest['username']) && isset(XUI::$rRequest['password'])) {
	$a71afc14d6cd090d = XUI::$rRequest['username'];
	$d5249dad8e8411b7 = XUI::$rRequest['password'];

	if (!(empty($a71afc14d6cd090d) || empty($d5249dad8e8411b7))) {
	} else {
		generateError('NO_CREDENTIALS');
	}

	$D4253f9520627819 = XUI::d7ca435AC70e9a78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, $Ad082f0a5542a888);
} else {
	if (!isset(XUI::$rRequest['token'])) {
	} else {
		$ea5296071288c730 = XUI::$rRequest['token'];

		if (!empty($ea5296071288c730)) {
		} else {
			generateError('NO_CREDENTIALS');
		}

		$D4253f9520627819 = XUI::D7ca435AC70E9a78(null, $ea5296071288c730, null, $Ad082f0a5542a888);
	}
}

ini_set('memory_limit', -1);

if ($D4253f9520627819) {
	$Dab081f66facd7a3 = false;
	$c779739c6e7f69b4 = false;

	if ($D4253f9520627819['admin_enabled'] == 1 && $D4253f9520627819['enabled'] == 1 && (is_null($D4253f9520627819['exp_date']) || time() < $D4253f9520627819['exp_date'])) {
		$c779739c6e7f69b4 = true;
	} else {
		if (!$D4253f9520627819['admin_enabled']) {
			generateError('BANNED');
		} else {
			if (!$D4253f9520627819['enabled']) {
				generateError('DISABLED');
			} else {
				generateError('EXPIRED');
			}
		}
	}

	XUI::d3e665b5427479fE($D4253f9520627819);
	header('Content-Type: application/json');

	if (!isset($_SERVER['HTTP_ORIGIN'])) {
	} else {
		header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
	}

	header('Access-Control-Allow-Credentials: true');

	switch ($fa7da6c202358e0c) {
		case 'get_epg':
			if (!empty(XUI::$rRequest['stream_id']) && (is_null($D4253f9520627819['exp_date']) || time() < $D4253f9520627819['exp_date'])) {
				$c273c95a4f247b1d = !empty(XUI::$rRequest['from_now']) && 0 < XUI::$rRequest['from_now'];

				if (is_numeric(XUI::$rRequest['stream_id']) && !isset(XUI::$rRequest['multi'])) {
					$caa6c2a1dcc4ac73 = false;
					$Cdb85875fd50f459 = array(intval(XUI::$rRequest['stream_id']));
				} else {
					$caa6c2a1dcc4ac73 = true;
					$Cdb85875fd50f459 = array_map('intval', explode(',', XUI::$rRequest['stream_id']));
				}

				$Bbb008a3f09c757f = array();

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
						if (!file_exists(EPG_PATH . 'stream_' . intval($F26087d31c2bbe4d))) {
						} else {
							$b3439582205053ea = igbinary_unserialize(file_get_contents(EPG_PATH . 'stream_' . $F26087d31c2bbe4d));

							foreach ($b3439582205053ea as $C740da31596f24ef) {
								if (!($c273c95a4f247b1d && $C740da31596f24ef['end'] < time())) {
									$C740da31596f24ef['title'] = base64_encode($C740da31596f24ef['title']);
									$C740da31596f24ef['description'] = base64_encode($C740da31596f24ef['description']);
									$C740da31596f24ef['start'] = intval($C740da31596f24ef['start']);
									$C740da31596f24ef['end'] = intval($C740da31596f24ef['end']);

									if ($caa6c2a1dcc4ac73) {
										$Bbb008a3f09c757f[$F26087d31c2bbe4d][] = $C740da31596f24ef;
									} else {
										$Bbb008a3f09c757f[] = $C740da31596f24ef;
									}
								}
							}
						}
					}
				}

				echo json_encode($Bbb008a3f09c757f);

				exit();
			}

			echo json_encode(array());

			exit();

		case 'get_series_info':
			$A2d65843292b5c59 = (empty(XUI::$rRequest['series_id']) ? 0 : intval(XUI::$rRequest['series_id']));

			if (XUI::$rCached) {
				$Be8acff8875eca91 = igbinary_unserialize(file_get_contents(SERIES_TMP_PATH . 'series_' . $A2d65843292b5c59));
				$b3439582205053ea = igbinary_unserialize(file_get_contents(SERIES_TMP_PATH . 'episodes_' . $A2d65843292b5c59));
			} else {
				XUI::$db->query('SELECT * FROM `streams_episodes` t1 INNER JOIN `streams` t2 ON t2.id=t1.stream_id WHERE t1.series_id = ? ORDER BY t1.season_num ASC, t1.episode_num ASC', $A2d65843292b5c59);
				$b3439582205053ea = XUI::$db->get_rows(true, 'season_num', false);
				XUI::$db->query('SELECT * FROM `streams_series` WHERE `id` = ?', $A2d65843292b5c59);
				$Be8acff8875eca91 = XUI::$db->get_row();
			}

			$f433193a3297ffde['seasons'] = array();

			foreach ((!empty($Be8acff8875eca91['seasons']) ? array_values(json_decode($Be8acff8875eca91['seasons'], true)) : array()) as $b550d8eef0f542ec) {
				$b550d8eef0f542ec['cover'] = XUI::b8f3dEF724810918($b550d8eef0f542ec['cover']);
				$b550d8eef0f542ec['cover_big'] = XUI::b8F3DEf724810918($b550d8eef0f542ec['cover_big']);
				$f433193a3297ffde['seasons'][] = $b550d8eef0f542ec;
			}
			$a4172772c6db9d25 = json_decode($Be8acff8875eca91['backdrop_path'], true);

			if (0 >= count($a4172772c6db9d25)) {
			} else {
				foreach (range(0, count($a4172772c6db9d25) - 1) as $Ea22c4a9ab5b2176) {
					$a4172772c6db9d25[$Ea22c4a9ab5b2176] = XUI::B8f3def724810918($a4172772c6db9d25[$Ea22c4a9ab5b2176]);
				}
			}

			$f433193a3297ffde['info'] = array('name' => XUI::ae6bb580bAA323c2($Be8acff8875eca91['title'], $Be8acff8875eca91['year']), 'title' => $Be8acff8875eca91['title'], 'year' => $Be8acff8875eca91['year'], 'cover' => XUI::b8f3dEf724810918($Be8acff8875eca91['cover']), 'plot' => $Be8acff8875eca91['plot'], 'cast' => $Be8acff8875eca91['cast'], 'director' => $Be8acff8875eca91['director'], 'genre' => $Be8acff8875eca91['genre'], 'release_date' => $Be8acff8875eca91['release_date'], 'releaseDate' => $Be8acff8875eca91['release_date'], 'last_modified' => $Be8acff8875eca91['last_modified'], 'rating' => number_format($Be8acff8875eca91['rating'], 0), 'rating_5based' => number_format($Be8acff8875eca91['rating'] * 0.5, 1) + 0, 'backdrop_path' => $a4172772c6db9d25, 'youtube_trailer' => $Be8acff8875eca91['youtube_trailer'], 'episode_run_time' => $Be8acff8875eca91['episode_run_time'], 'category_id' => strval(json_decode($Be8acff8875eca91['category_id'], true)[0]), 'category_ids' => json_decode($Be8acff8875eca91['category_id'], true));

			foreach ($b3439582205053ea as $b550d8eef0f542ec => $b1fa0ad0bb84d114) {
				$F80ea1676db4f3fe = 1;

				foreach ($b1fa0ad0bb84d114 as $Bd43537fab08ca31) {
					if (XUI::$rCached) {
						$Df5c1111e9792e21 = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($Bd43537fab08ca31['stream_id'])))['info'];
					} else {
						$Df5c1111e9792e21 = $Bd43537fab08ca31;
					}

					if (XUI::$rSettings['api_redirect']) {
						$b1a9a67f7480d1f6 = 'series/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Df5c1111e9792e21['id'] . '/' . $Df5c1111e9792e21['target_container'];
						$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
						$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;
					} else {
						$C700a2b357e5ed65 = '';
					}

					$D92b16dc36690ab9 = (!empty($Df5c1111e9792e21['movie_properties']) ? json_decode($Df5c1111e9792e21['movie_properties'], true) : '');
					$D92b16dc36690ab9['cover_big'] = XUI::b8F3DEf724810918($D92b16dc36690ab9['cover_big']);
					$D92b16dc36690ab9['movie_image'] = XUI::b8F3dEf724810918($D92b16dc36690ab9['movie_image']);

					if ($D92b16dc36690ab9['cover_big']) {
					} else {
						$D92b16dc36690ab9['cover_big'] = $D92b16dc36690ab9['movie_image'];
					}

					if (0 >= count($D92b16dc36690ab9['backdrop_path'])) {
					} else {
						foreach (range(0, count($D92b16dc36690ab9['backdrop_path']) - 1) as $Ea22c4a9ab5b2176) {
							if (!$D92b16dc36690ab9['backdrop_path'][$Ea22c4a9ab5b2176]) {
							} else {
								$D92b16dc36690ab9['backdrop_path'][$Ea22c4a9ab5b2176] = XUI::B8f3def724810918($D92b16dc36690ab9['backdrop_path'][$Ea22c4a9ab5b2176]);
							}
						}
					}

					$Eeedbc996b3feb87 = array();

					if (!is_array($D92b16dc36690ab9['subtitle'])) {
					} else {
						$Ea22c4a9ab5b2176 = 0;

						foreach ($D92b16dc36690ab9['subtitle'] as $F1769d8572d6356d) {
							$Eeedbc996b3feb87[] = array('index' => $Ea22c4a9ab5b2176, 'language' => ($F1769d8572d6356d['tags']['language'] ?: null), 'title' => ($F1769d8572d6356d['tags']['title'] ?: null));
							$Ea22c4a9ab5b2176++;
						}
					}

					foreach (array('audio', 'video', 'subtitle') as $D3fa098be3f297cd) {
						if (!isset($D92b16dc36690ab9[$D3fa098be3f297cd])) {
						} else {
							unset($D92b16dc36690ab9[$D3fa098be3f297cd]);
						}
					}
					$f433193a3297ffde['episodes'][$b550d8eef0f542ec][] = array('id' => $Bd43537fab08ca31['stream_id'], 'episode_num' => $Bd43537fab08ca31['episode_num'], 'title' => $Df5c1111e9792e21['stream_display_name'], 'container_extension' => $Df5c1111e9792e21['target_container'], 'info' => $D92b16dc36690ab9, 'subtitles' => $Eeedbc996b3feb87, 'custom_sid' => strval($Df5c1111e9792e21['custom_sid']), 'added' => ($Df5c1111e9792e21['added'] ?: ''), 'season' => $b550d8eef0f542ec, 'direct_source' => $C700a2b357e5ed65);
				}
			}

			break;

		case 'get_series':
			$B750c9b908ca927c = (empty(XUI::$rRequest['category_id']) ? null : intval(XUI::$rRequest['category_id']));
			$ba75fb553fb59075 = 0;

			if (0 >= count($D4253f9520627819['series_ids'])) {
			} else {
				if (XUI::$rCached) {
					if (!XUI::$rSettings['vod_sort_newest']) {
					} else {
						$D4253f9520627819['series_ids'] = XUI::sortSeries($D4253f9520627819['series_ids']);
					}

					foreach ($D4253f9520627819['series_ids'] as $A2d65843292b5c59) {
						$B2f4ba52951b74ae = igbinary_unserialize(file_get_contents(SERIES_TMP_PATH . 'series_' . $A2d65843292b5c59));
						$a4172772c6db9d25 = json_decode($B2f4ba52951b74ae['backdrop_path'], true);

						if (0 >= count($a4172772c6db9d25)) {
						} else {
							foreach (range(0, count($a4172772c6db9d25) - 1) as $Ea22c4a9ab5b2176) {
								$a4172772c6db9d25[$Ea22c4a9ab5b2176] = XUI::B8F3def724810918($a4172772c6db9d25[$Ea22c4a9ab5b2176]);
							}
						}

						$A38b42a281e3c3cf = json_decode($B2f4ba52951b74ae['category_id'], true);

						foreach ($A38b42a281e3c3cf as $Be965cdd996d4520) {
							if ($B750c9b908ca927c && $B750c9b908ca927c != $Be965cdd996d4520) {
							} else {
								$f433193a3297ffde[] = array('num' => ++$ba75fb553fb59075, 'name' => XUI::aE6bb580baA323c2($B2f4ba52951b74ae['title'], $B2f4ba52951b74ae['year']), 'title' => $B2f4ba52951b74ae['title'], 'year' => $B2f4ba52951b74ae['year'], 'stream_type' => 'series', 'series_id' => (int) $B2f4ba52951b74ae['id'], 'cover' => XUI::b8F3Def724810918($B2f4ba52951b74ae['cover']), 'plot' => $B2f4ba52951b74ae['plot'], 'cast' => $B2f4ba52951b74ae['cast'], 'director' => $B2f4ba52951b74ae['director'], 'genre' => $B2f4ba52951b74ae['genre'], 'release_date' => $B2f4ba52951b74ae['release_date'], 'releaseDate' => $B2f4ba52951b74ae['release_date'], 'last_modified' => $B2f4ba52951b74ae['last_modified'], 'rating' => number_format($B2f4ba52951b74ae['rating'], 0), 'rating_5based' => number_format($B2f4ba52951b74ae['rating'] * 0.5, 1) + 0, 'backdrop_path' => $a4172772c6db9d25, 'youtube_trailer' => $B2f4ba52951b74ae['youtube_trailer'], 'episode_run_time' => $B2f4ba52951b74ae['episode_run_time'], 'category_id' => strval($Be965cdd996d4520), 'category_ids' => $A38b42a281e3c3cf);
							}

							if ($B750c9b908ca927c || XUI::$rSettings['show_category_duplicates']) {
							} else {
								break;
							}
						}
					}
				} else {
					if (empty($D4253f9520627819['series_ids'])) {
					} else {
						if (XUI::$rSettings['vod_sort_newest']) {
							XUI::$db->query('SELECT *, (SELECT MAX(`streams`.`added`) FROM `streams_episodes` LEFT JOIN `streams` ON `streams`.`id` = `streams_episodes`.`stream_id` WHERE `streams_episodes`.`series_id` = `streams_series`.`id`) AS `last_modified_stream` FROM `streams_series` WHERE `id` IN (' . implode(',', array_map('intval', $D4253f9520627819['series_ids'])) . ') ORDER BY `last_modified_stream` DESC, `last_modified` DESC;');
						} else {
							XUI::$db->query('SELECT * FROM `streams_series` WHERE `id` IN (' . implode(',', array_map('intval', $D4253f9520627819['series_ids'])) . ') ORDER BY FIELD(`id`,' . implode(',', $D4253f9520627819['series_ids']) . ') ASC;');
						}

						$bbc84f53c534450d = XUI::$db->get_rows(true, 'id');

						foreach ($bbc84f53c534450d as $B2f4ba52951b74ae) {
							if (!isset($B2f4ba52951b74ae['last_modified_stream']) || empty($B2f4ba52951b74ae['last_modified_stream'])) {
							} else {
								$B2f4ba52951b74ae['last_modified'] = $B2f4ba52951b74ae['last_modified_stream'];
							}

							$a4172772c6db9d25 = json_decode($B2f4ba52951b74ae['backdrop_path'], true);

							if (0 >= count($a4172772c6db9d25)) {
							} else {
								foreach (range(0, count($a4172772c6db9d25) - 1) as $Ea22c4a9ab5b2176) {
									$a4172772c6db9d25[$Ea22c4a9ab5b2176] = XUI::B8f3deF724810918($a4172772c6db9d25[$Ea22c4a9ab5b2176]);
								}
							}

							$A38b42a281e3c3cf = json_decode($B2f4ba52951b74ae['category_id'], true);

							foreach ($A38b42a281e3c3cf as $Be965cdd996d4520) {
								if ($B750c9b908ca927c && $B750c9b908ca927c != $Be965cdd996d4520) {
								} else {
									$f433193a3297ffde[] = array('num' => ++$ba75fb553fb59075, 'name' => XUI::Ae6BB580BaA323C2($B2f4ba52951b74ae['title'], $B2f4ba52951b74ae['year']), 'title' => $B2f4ba52951b74ae['title'], 'year' => $B2f4ba52951b74ae['year'], 'stream_type' => 'series', 'series_id' => (int) $B2f4ba52951b74ae['id'], 'cover' => XUI::b8F3deF724810918($B2f4ba52951b74ae['cover']), 'plot' => $B2f4ba52951b74ae['plot'], 'cast' => $B2f4ba52951b74ae['cast'], 'director' => $B2f4ba52951b74ae['director'], 'genre' => $B2f4ba52951b74ae['genre'], 'release_date' => $B2f4ba52951b74ae['release_date'], 'releaseDate' => $B2f4ba52951b74ae['release_date'], 'last_modified' => $B2f4ba52951b74ae['last_modified'], 'rating' => number_format($B2f4ba52951b74ae['rating'], 0), 'rating_5based' => number_format($B2f4ba52951b74ae['rating'] * 0.5, 1) + 0, 'backdrop_path' => $a4172772c6db9d25, 'youtube_trailer' => $B2f4ba52951b74ae['youtube_trailer'], 'episode_run_time' => $B2f4ba52951b74ae['episode_run_time'], 'category_id' => strval($Be965cdd996d4520), 'category_ids' => $A38b42a281e3c3cf);
								}

								if ($B750c9b908ca927c || XUI::$rSettings['show_category_duplicates']) {
								} else {
									break;
								}
							}
						}
					}
				}
			}

			break;

		case 'get_vod_categories':
			$A5dcdeb6ecbbf6bd = XUI::C7BAbcbEC16c28ed('movie');

			foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
				if (!in_array($A1925ae53e9307eb['id'], $D4253f9520627819['category_ids'])) {
				} else {
					$f433193a3297ffde[] = array('category_id' => strval($A1925ae53e9307eb['id']), 'category_name' => $A1925ae53e9307eb['category_name'], 'parent_id' => 0);
				}
			}

			break;

		case 'get_series_categories':
			$A5dcdeb6ecbbf6bd = XUI::c7babCbeC16C28ed('series');

			foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
				if (!in_array($A1925ae53e9307eb['id'], $D4253f9520627819['category_ids'])) {
				} else {
					$f433193a3297ffde[] = array('category_id' => strval($A1925ae53e9307eb['id']), 'category_name' => $A1925ae53e9307eb['category_name'], 'parent_id' => 0);
				}
			}

			break;

		case 'get_live_categories':
			$A5dcdeb6ecbbf6bd = array_merge(XUI::C7BabCBeC16c28Ed('live'), XUI::c7bAbcbeC16C28ed('radio'));

			foreach ($A5dcdeb6ecbbf6bd as $A1925ae53e9307eb) {
				if (!in_array($A1925ae53e9307eb['id'], $D4253f9520627819['category_ids'])) {
				} else {
					$f433193a3297ffde[] = array('category_id' => strval($A1925ae53e9307eb['id']), 'category_name' => $A1925ae53e9307eb['category_name'], 'parent_id' => 0);
				}
			}

			break;

		case 'get_simple_data_table':
			$f433193a3297ffde['epg_listings'] = array();

			if (empty(XUI::$rRequest['stream_id'])) {
			} else {
				if (is_numeric(XUI::$rRequest['stream_id']) && !isset(XUI::$rRequest['multi'])) {
					$caa6c2a1dcc4ac73 = false;
					$Cdb85875fd50f459 = array(intval(XUI::$rRequest['stream_id']));
				} else {
					$caa6c2a1dcc4ac73 = true;
					$Cdb85875fd50f459 = array_map('intval', explode(',', XUI::$rRequest['stream_id']));
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$Ac46667df5353a3d = array();

					if (XUI::$rCached) {
						foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
							if (!file_exists(STREAMS_TMP_PATH . 'stream_' . intval($F26087d31c2bbe4d))) {
							} else {
								$C740da31596f24ef = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($F26087d31c2bbe4d)))['info'];
								$Ac46667df5353a3d[$F26087d31c2bbe4d] = intval($C740da31596f24ef['tv_archive_duration']);
							}
						}
					} else {
						$Fee0d5a474c96306->query('SELECT `id`, `tv_archive_duration` FROM `streams` WHERE `id` IN (' . implode(',', array_map('intval', $Cdb85875fd50f459)) . ');');

						if (0 >= $Fee0d5a474c96306->num_rows()) {
						} else {
							foreach ($Fee0d5a474c96306->get_rows() as $C740da31596f24ef) {
								$Ac46667df5353a3d[$C740da31596f24ef['id']] = intval($C740da31596f24ef['tv_archive_duration']);
							}
						}
					}

					foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
						if (!file_exists(EPG_PATH . 'stream_' . intval($F26087d31c2bbe4d))) {
						} else {
							$b3439582205053ea = igbinary_unserialize(file_get_contents(EPG_PATH . 'stream_' . $F26087d31c2bbe4d));

							foreach ($b3439582205053ea as $E05d5c8afb9dc282) {
								$bb241b603c7b5edb = $b317277ef36cf1c7 = 0;
								$E05d5c8afb9dc282['start_timestamp'] = $E05d5c8afb9dc282['start'];
								$E05d5c8afb9dc282['stop_timestamp'] = $E05d5c8afb9dc282['end'];

								if (!($E05d5c8afb9dc282['start_timestamp'] <= time() && time() <= $E05d5c8afb9dc282['stop_timestamp'])) {
								} else {
									$bb241b603c7b5edb = 1;
								}

								if (!(!empty($Ac46667df5353a3d[$F26087d31c2bbe4d]) && $E05d5c8afb9dc282['stop_timestamp'] < time() && strtotime('-' . $Ac46667df5353a3d[$F26087d31c2bbe4d] . ' days') <= $E05d5c8afb9dc282['stop_timestamp'])) {
								} else {
									$b317277ef36cf1c7 = 1;
								}

								$E05d5c8afb9dc282['now_playing'] = $bb241b603c7b5edb;
								$E05d5c8afb9dc282['has_archive'] = $b317277ef36cf1c7;
								$E05d5c8afb9dc282['title'] = base64_encode($E05d5c8afb9dc282['title']);
								$E05d5c8afb9dc282['description'] = base64_encode($E05d5c8afb9dc282['description']);
								$E05d5c8afb9dc282['start'] = date('Y-m-d H:i:s', $E05d5c8afb9dc282['start_timestamp']);
								$E05d5c8afb9dc282['end'] = date('Y-m-d H:i:s', $E05d5c8afb9dc282['stop_timestamp']);

								if ($caa6c2a1dcc4ac73) {
									$f433193a3297ffde['epg_listings'][$F26087d31c2bbe4d][] = $E05d5c8afb9dc282;
								} else {
									$f433193a3297ffde['epg_listings'][] = $E05d5c8afb9dc282;
								}
							}
						}
					}
				}
			}

			break;

		case 'get_short_epg':
			$f433193a3297ffde['epg_listings'] = array();

			if (empty(XUI::$rRequest['stream_id'])) {
			} else {
				$E400a3101514583e = (empty(XUI::$rRequest['limit']) ? 4 : intval(XUI::$rRequest['limit']));

				if (is_numeric(XUI::$rRequest['stream_id']) && !isset(XUI::$rRequest['multi'])) {
					$caa6c2a1dcc4ac73 = false;
					$Cdb85875fd50f459 = array(intval(XUI::$rRequest['stream_id']));
				} else {
					$caa6c2a1dcc4ac73 = true;
					$Cdb85875fd50f459 = array_map('intval', explode(',', XUI::$rRequest['stream_id']));
				}

				if (0 >= count($Cdb85875fd50f459)) {
				} else {
					$C4af185e24cf9086 = time();

					foreach ($Cdb85875fd50f459 as $F26087d31c2bbe4d) {
						if (!file_exists(EPG_PATH . 'stream_' . intval($F26087d31c2bbe4d))) {
						} else {
							$b3439582205053ea = igbinary_unserialize(file_get_contents(EPG_PATH . 'stream_' . $F26087d31c2bbe4d));

							foreach ($b3439582205053ea as $C740da31596f24ef) {
								if (!($C740da31596f24ef['start'] <= $C4af185e24cf9086 && $C4af185e24cf9086 <= $C740da31596f24ef['end'] || $C4af185e24cf9086 <= $C740da31596f24ef['start'])) {
								} else {
									$C740da31596f24ef['start_timestamp'] = $C740da31596f24ef['start'];
									$C740da31596f24ef['stop_timestamp'] = $C740da31596f24ef['end'];
									$C740da31596f24ef['title'] = base64_encode($C740da31596f24ef['title']);
									$C740da31596f24ef['description'] = base64_encode($C740da31596f24ef['description']);
									$C740da31596f24ef['start'] = date('Y-m-d H:i:s', $C740da31596f24ef['start']);
									$C740da31596f24ef['stop'] = date('Y-m-d H:i:s', $C740da31596f24ef['end']);

									if ($caa6c2a1dcc4ac73) {
										$f433193a3297ffde['epg_listings'][$F26087d31c2bbe4d][] = $C740da31596f24ef;
									} else {
										$f433193a3297ffde['epg_listings'][] = $C740da31596f24ef;
									}

									if ($E400a3101514583e > count($f433193a3297ffde['epg_listings'])) {
									} else {
										break;
									}
								}
							}
						}
					}
				}
			}

			break;

		case 'get_live_streams':
			$B750c9b908ca927c = (empty(XUI::$rRequest['category_id']) ? null : intval(XUI::$rRequest['category_id']));
			$b049d109ba819b18 = 0;
			$D4253f9520627819['live_ids'] = array_merge($D4253f9520627819['live_ids'], $D4253f9520627819['radio_ids']);

			if (empty($f1633abde8f84cd1['items_per_page'])) {
			} else {
				$D4253f9520627819['live_ids'] = array_slice($D4253f9520627819['live_ids'], $f1633abde8f84cd1['offset'], $f1633abde8f84cd1['items_per_page']);
			}

			$D4253f9520627819['live_ids'] = XUI::E43cB741Aa22a6d8($D4253f9520627819['live_ids']);

			if (!XUI::$rCached) {
				$f46da30a01f7b2d7 = array();

				if (0 >= count($D4253f9520627819['live_ids'])) {
				} else {
					$Df2582e36fdd6160 = $f86e19bdb1e7dae8 = array();

					if (empty($B750c9b908ca927c)) {
					} else {
						$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`category_id`, ?, '\$')";
						$Df2582e36fdd6160[] = $B750c9b908ca927c;
					}

					$f86e19bdb1e7dae8[] = '`t1`.`id` IN (' . implode(',', $D4253f9520627819['live_ids']) . ')';
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);

					if (XUI::$rSettings['channel_number_type'] != 'manual') {
						$c6c389b9adf3a40c = 'FIELD(`t1`.`id`,' . implode(',', $D4253f9520627819['live_ids']) . ')';
					} else {
						$c6c389b9adf3a40c = '`order`';
					}

					XUI::$db->query('SELECT t1.id,t1.epg_id,t1.added,t1.allow_record,t1.year,t1.channel_id,t1.movie_properties,t1.stream_source,t1.tv_archive_server_id,t1.vframes_server_id,t1.tv_archive_duration,t1.stream_icon,t1.custom_sid,t1.category_id,t1.stream_display_name,t1.series_no,t1.direct_source,t2.type_output,t1.target_container,t2.live,t1.rtmp_output,t1.order,t2.type_key FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type ' . $ff9d21c7a9d310b1 . ' ORDER BY ' . $c6c389b9adf3a40c . ';', ...$Df2582e36fdd6160);
					$f46da30a01f7b2d7 = XUI::$db->get_rows();
				}
			} else {
				$f46da30a01f7b2d7 = $D4253f9520627819['live_ids'];
			}

			foreach ($f46da30a01f7b2d7 as $Fe753328765ad26c) {
				if (!XUI::$rCached) {
				} else {
					$Fe753328765ad26c = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($Fe753328765ad26c)))['info'];
				}

				if (in_array($Fe753328765ad26c['type_key'], array('live', 'created_live', 'radio_streams'))) {
					$A38b42a281e3c3cf = json_decode($Fe753328765ad26c['category_id'], true);

					foreach ($A38b42a281e3c3cf as $Be965cdd996d4520) {
						if ($B750c9b908ca927c && $B750c9b908ca927c != $Be965cdd996d4520) {
						} else {
							$b3742bc37d4481cd = (XUI::b8F3DeF724810918($Fe753328765ad26c['stream_icon']) ?: '');
							$ecfa19276b727349 = (!empty($Fe753328765ad26c['tv_archive_server_id']) && !empty($Fe753328765ad26c['tv_archive_duration']) ? 1 : 0);

							if (XUI::$rSettings['api_redirect']) {
								$b1a9a67f7480d1f6 = 'live/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'];
								$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);

								if (XUI::$rSettings['cloudflare'] && XUI::$rSettings['api_container'] == 'ts') {
									$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;
								} else {
									$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730 . '/' . XUI::$rSettings['api_container'];
								}
							} else {
								$C700a2b357e5ed65 = '';
							}

							if ($Fe753328765ad26c['vframes_server_id']) {
								$b1a9a67f7480d1f6 = 'thumb/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'];
								$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
								$d7e02302834c503e = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;
							} else {
								$d7e02302834c503e = '';
							}

							$f433193a3297ffde[] = array('num' => ++$b049d109ba819b18, 'name' => $Fe753328765ad26c['stream_display_name'], 'stream_type' => $Fe753328765ad26c['type_key'], 'stream_id' => (int) $Fe753328765ad26c['id'], 'stream_icon' => $b3742bc37d4481cd, 'epg_channel_id' => $Fe753328765ad26c['channel_id'], 'added' => ($Fe753328765ad26c['added'] ?: ''), 'custom_sid' => strval($Fe753328765ad26c['custom_sid']), 'tv_archive' => $ecfa19276b727349, 'direct_source' => $C700a2b357e5ed65, 'tv_archive_duration' => ($ecfa19276b727349 ? intval($Fe753328765ad26c['tv_archive_duration']) : 0), 'category_id' => strval($Be965cdd996d4520), 'category_ids' => $A38b42a281e3c3cf, 'thumbnail' => $d7e02302834c503e);
						}

						if ($B750c9b908ca927c || XUI::$rSettings['show_category_duplicates']) {
						} else {
							break;
						}
					}
				}
			}

			break;

		case 'get_vod_info':
			$f433193a3297ffde['info'] = array();

			if (empty(XUI::$rRequest['vod_id'])) {
			} else {
				$a3be1da665f7ea99 = intval(XUI::$rRequest['vod_id']);

				if (XUI::$rCached) {
					$C740da31596f24ef = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($a3be1da665f7ea99)))['info'];
				} else {
					XUI::$db->query('SELECT * FROM `streams` WHERE `id` = ?', $a3be1da665f7ea99);
					$C740da31596f24ef = XUI::$db->get_row();
				}

				if (!$C740da31596f24ef) {
				} else {
					if (XUI::$rSettings['api_redirect']) {
						$b1a9a67f7480d1f6 = 'movie/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $C740da31596f24ef['id'] . '/' . $C740da31596f24ef['target_container'];
						$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
						$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;
					} else {
						$C700a2b357e5ed65 = '';
					}

					$f433193a3297ffde['info'] = json_decode($C740da31596f24ef['movie_properties'], true);
					$f433193a3297ffde['info']['tmdb_id'] = intval($f433193a3297ffde['info']['tmdb_id']);
					$f433193a3297ffde['info']['episode_run_time'] = intval($f433193a3297ffde['info']['episode_run_time']);
					$f433193a3297ffde['info']['releasedate'] = $f433193a3297ffde['info']['release_date'];
					$f433193a3297ffde['info']['cover_big'] = XUI::B8f3dEf724810918($f433193a3297ffde['info']['cover_big']);
					$f433193a3297ffde['info']['movie_image'] = XUI::B8f3dEF724810918($f433193a3297ffde['info']['movie_image']);
					$f433193a3297ffde['info']['rating'] = number_format($f433193a3297ffde['info']['rating'], 2) + 0;

					if (0 >= count($f433193a3297ffde['info']['backdrop_path'])) {
					} else {
						foreach (range(0, count($f433193a3297ffde['info']['backdrop_path']) - 1) as $Ea22c4a9ab5b2176) {
							$f433193a3297ffde['info']['backdrop_path'][$Ea22c4a9ab5b2176] = XUI::B8F3dEF724810918($f433193a3297ffde['info']['backdrop_path'][$Ea22c4a9ab5b2176]);
						}
					}

					$f433193a3297ffde['info']['subtitles'] = array();

					if (!is_array($f433193a3297ffde['info']['subtitle'])) {
					} else {
						$Ea22c4a9ab5b2176 = 0;

						foreach ($f433193a3297ffde['info']['subtitle'] as $F1769d8572d6356d) {
							$f433193a3297ffde['info']['subtitles'][] = array('index' => $Ea22c4a9ab5b2176, 'language' => ($F1769d8572d6356d['tags']['language'] ?: null), 'title' => ($F1769d8572d6356d['tags']['title'] ?: null));
							$Ea22c4a9ab5b2176++;
						}
					}

					foreach (array('audio', 'video', 'subtitle') as $D3fa098be3f297cd) {
						if (!isset($f433193a3297ffde['info'][$D3fa098be3f297cd])) {
						} else {
							unset($f433193a3297ffde['info'][$D3fa098be3f297cd]);
						}
					}
					$f433193a3297ffde['movie_data'] = array('stream_id' => (int) $C740da31596f24ef['id'], 'name' => XUI::ae6bb580BAA323C2($C740da31596f24ef['stream_display_name'], $C740da31596f24ef['year']), 'title' => $C740da31596f24ef['stream_display_name'], 'year' => $C740da31596f24ef['year'], 'added' => ($C740da31596f24ef['added'] ?: ''), 'category_id' => strval(json_decode($C740da31596f24ef['category_id'], true)[0]), 'category_ids' => json_decode($C740da31596f24ef['category_id'], true), 'container_extension' => $C740da31596f24ef['target_container'], 'custom_sid' => strval($C740da31596f24ef['custom_sid']), 'direct_source' => $C700a2b357e5ed65);
				}
			}

			break;

		case 'get_vod_streams':
			$B750c9b908ca927c = (empty(XUI::$rRequest['category_id']) ? null : intval(XUI::$rRequest['category_id']));
			$ba75fb553fb59075 = 0;

			if (empty($f1633abde8f84cd1['items_per_page'])) {
			} else {
				$D4253f9520627819['vod_ids'] = array_slice($D4253f9520627819['vod_ids'], $f1633abde8f84cd1['offset'], $f1633abde8f84cd1['items_per_page']);
			}

			$D4253f9520627819['vod_ids'] = XUI::E43CB741Aa22A6d8($D4253f9520627819['vod_ids']);

			if (!XUI::$rCached) {
				$f46da30a01f7b2d7 = array();

				if (0 >= count($D4253f9520627819['vod_ids'])) {
				} else {
					$Df2582e36fdd6160 = $f86e19bdb1e7dae8 = array();

					if (empty($B750c9b908ca927c)) {
					} else {
						$f86e19bdb1e7dae8[] = "JSON_CONTAINS(`category_id`, ?, '\$')";
						$Df2582e36fdd6160[] = $B750c9b908ca927c;
					}

					$f86e19bdb1e7dae8[] = '`t1`.`id` IN (' . implode(',', $D4253f9520627819['vod_ids']) . ')';
					$ff9d21c7a9d310b1 = 'WHERE ' . implode(' AND ', $f86e19bdb1e7dae8);

					if (XUI::$rSettings['channel_number_type'] != 'manual') {
						$c6c389b9adf3a40c = 'FIELD(`t1`.`id`,' . implode(',', $D4253f9520627819['vod_ids']) . ')';
					} else {
						$c6c389b9adf3a40c = '`order`';
					}

					XUI::$db->query('SELECT t1.id,t1.epg_id,t1.added,t1.allow_record,t1.year,t1.channel_id,t1.movie_properties,t1.stream_source,t1.tv_archive_server_id,t1.vframes_server_id,t1.tv_archive_duration,t1.stream_icon,t1.custom_sid,t1.category_id,t1.stream_display_name,t1.series_no,t1.direct_source,t2.type_output,t1.target_container,t2.live,t1.rtmp_output,t1.order,t2.type_key FROM `streams` t1 INNER JOIN `streams_types` t2 ON t2.type_id = t1.type ' . $ff9d21c7a9d310b1 . ' ORDER BY ' . $c6c389b9adf3a40c . ';', ...$Df2582e36fdd6160);
					$f46da30a01f7b2d7 = XUI::$db->get_rows();
				}
			} else {
				$f46da30a01f7b2d7 = $D4253f9520627819['vod_ids'];
			}

			foreach ($f46da30a01f7b2d7 as $Fe753328765ad26c) {
				if (!XUI::$rCached) {
				} else {
					$Fe753328765ad26c = igbinary_unserialize(file_get_contents(STREAMS_TMP_PATH . 'stream_' . intval($Fe753328765ad26c)))['info'];
				}

				if (in_array($Fe753328765ad26c['type_key'], array('movie'))) {
					$D92b16dc36690ab9 = json_decode($Fe753328765ad26c['movie_properties'], true);
					$A38b42a281e3c3cf = json_decode($Fe753328765ad26c['category_id'], true);

					foreach ($A38b42a281e3c3cf as $Be965cdd996d4520) {
						if ($B750c9b908ca927c && $B750c9b908ca927c != $Be965cdd996d4520) {
						} else {
							if (XUI::$rSettings['api_redirect']) {
								$b1a9a67f7480d1f6 = 'movie/' . $D4253f9520627819['username'] . '/' . $D4253f9520627819['password'] . '/' . $Fe753328765ad26c['id'] . '/' . $Fe753328765ad26c['target_container'];
								$ea5296071288c730 = Xui\Functions::encrypt($b1a9a67f7480d1f6, XUI::$rSettings['live_streaming_pass'], OPENSSL_EXTRA);
								$C700a2b357e5ed65 = $Ca5a0830e8583ff3 . 'play/' . $ea5296071288c730;
							} else {
								$C700a2b357e5ed65 = '';
							}

							$f433193a3297ffde[] = array('num' => ++$ba75fb553fb59075, 'name' => XUI::ae6bB580Baa323C2($Fe753328765ad26c['stream_display_name'], $Fe753328765ad26c['year']), 'title' => $Fe753328765ad26c['stream_display_name'], 'year' => $Fe753328765ad26c['year'], 'stream_type' => $Fe753328765ad26c['type_key'], 'stream_id' => (int) $Fe753328765ad26c['id'], 'stream_icon' => (XUI::B8f3deF724810918($D92b16dc36690ab9['movie_image']) ?: ''), 'rating' => number_format($D92b16dc36690ab9['rating'], 1) + 0, 'rating_5based' => number_format($D92b16dc36690ab9['rating'] * 0.5, 1) + 0, 'added' => ($Fe753328765ad26c['added'] ?: ''), 'plot' => $D92b16dc36690ab9['plot'], 'cast' => $D92b16dc36690ab9['cast'], 'director' => $D92b16dc36690ab9['director'], 'genre' => $D92b16dc36690ab9['genre'], 'release_date' => $D92b16dc36690ab9['release_date'], 'youtube_trailer' => $D92b16dc36690ab9['youtube_trailer'], 'episode_run_time' => $D92b16dc36690ab9['episode_run_time'], 'category_id' => strval($Be965cdd996d4520), 'category_ids' => $A38b42a281e3c3cf, 'container_extension' => $Fe753328765ad26c['target_container'], 'custom_sid' => strval($Fe753328765ad26c['custom_sid']), 'direct_source' => $C700a2b357e5ed65);
						}

						if ($B750c9b908ca927c || XUI::$rSettings['show_category_duplicates']) {
						} else {
							break;
						}
					}
				}
			}

			break;

		default:
			break;
	}
} else {
	XUI::b6f740FaBc7265BF(null, null, $a71afc14d6cd090d);
	generateError('INVALID_CREDENTIALS');
}

function getOutputFormats($F594df8bae655dd2)
{
	$Bd7fba16fdc8a0eb = array(1 => 'm3u8', 2 => 'ts', 3 => 'rtmp');
	$a85e1b7d42c346a0 = array();

	foreach ($F594df8bae655dd2 as $C496a3b18a6788ac) {
		$a85e1b7d42c346a0[] = $Bd7fba16fdc8a0eb[$C496a3b18a6788ac];
	}

	return $a85e1b7d42c346a0;
}

function shutdown()
{
	global $Dab081f66facd7a3;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::FC8474658EC80360();
	}

	if (!is_object(XUI::$db)) {
	} else {
		XUI::$db->close_mysql();
	}
}
