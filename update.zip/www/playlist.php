<?php

register_shutdown_function('shutdown');
require 'init.php';
set_time_limit(0);
header('Access-Control-Allow-Origin: *');
$Dab081f66facd7a3 = true;

if (strtolower(explode('.', ltrim(parse_url($_SERVER['REQUEST_URI'])['path'], '/'))[0]) != 'get' || XUI::$rSettings['legacy_get']) {
} else {
	$Dab081f66facd7a3 = false;
	generateError('LEGACY_GET_DISABLED');
}

$F4a4cac9883825e6 = false;
$c59ec257c284c894 = XUI::a9Bc416Fa6fa55c3();
$efc0f8f3059e4104 = XUI::B74f652c92ceC688($c59ec257c284c894)['country']['iso_code'];
$b3374866087774a1 = (empty($_SERVER['HTTP_USER_AGENT']) ? '' : htmlentities(trim($_SERVER['HTTP_USER_AGENT'])));
$a94d5d59ff9b8d05 = (empty(XUI::$rRequest['type']) ? 'm3u_plus' : XUI::$rRequest['type']);
$E6ba93c1fc86556a = (empty(XUI::$rRequest['key']) ? null : explode(',', XUI::$rRequest['key']));
$B5179d3aa5ad70dd = (empty(XUI::$rRequest['output']) ? '' : XUI::$rRequest['output']);
$b9b8c6585c0f1e33 = !empty(XUI::$rRequest['nocache']);

if (isset(XUI::$rRequest['username']) && isset(XUI::$rRequest['password'])) {
	$a71afc14d6cd090d = XUI::$rRequest['username'];
	$d5249dad8e8411b7 = XUI::$rRequest['password'];

	if (!(empty($a71afc14d6cd090d) || empty($d5249dad8e8411b7))) {
	} else {
		generateError('NO_CREDENTIALS');
	}

	$D4253f9520627819 = XUI::D7Ca435ac70e9a78(null, $a71afc14d6cd090d, $d5249dad8e8411b7, true, false, $c59ec257c284c894);
} else {
	if (isset(XUI::$rRequest['token'])) {
		$ea5296071288c730 = XUI::$rRequest['token'];

		if (!empty($ea5296071288c730)) {
		} else {
			generateError('NO_CREDENTIALS');
		}

		$D4253f9520627819 = XUI::D7ca435Ac70E9A78(null, $ea5296071288c730, null, true, false, $c59ec257c284c894);
	} else {
		generateError('NO_CREDENTIALS');
	}
}

ini_set('memory_limit', -1);

if ($D4253f9520627819) {
	$Dab081f66facd7a3 = false;

	if ($D4253f9520627819['is_restreamer'] || !XUI::$rSettings['disable_playlist']) {
	} else {
		generateError('PLAYLIST_DISABLED');
	}

	if (!($D4253f9520627819['is_restreamer'] && XUI::$rSettings['disable_playlist_restreamer'])) {
	} else {
		generateError('PLAYLIST_DISABLED');
	}

	if ($D4253f9520627819['bypass_ua'] != 0) {
	} else {
		if (!XUI::E416910Ca4dA4695($b3374866087774a1, true)) {
		} else {
			generateError('BLOCKED_USER_AGENT');
		}
	}

	if (is_null($D4253f9520627819['exp_date']) || $D4253f9520627819['exp_date'] > time()) {
	} else {
		generateError('EXPIRED');
	}

	if (!($D4253f9520627819['is_mag'] || $D4253f9520627819['is_e2'])) {
	} else {
		generateError('DEVICE_NOT_ALLOWED');
	}

	if ($D4253f9520627819['admin_enabled']) {
	} else {
		generateError('BANNED');
	}

	if ($D4253f9520627819['enabled']) {
	} else {
		generateError('DISABLED');
	}

	if (!XUI::$rSettings['restrict_playlists']) {
	} else {
		if (!(empty($b3374866087774a1) && XUI::$rSettings['disallow_empty_user_agents'] == 1)) {
		} else {
			generateError('EMPTY_USER_AGENT');
		}

		if (empty($D4253f9520627819['allowed_ips']) || in_array($c59ec257c284c894, array_map('gethostbyname', $D4253f9520627819['allowed_ips']))) {
		} else {
			generateError('NOT_IN_ALLOWED_IPS');
		}

		if (empty($efc0f8f3059e4104)) {
		} else {
			$ac720430e021c8c0 = !empty($D4253f9520627819['forced_country']);

			if (!($ac720430e021c8c0 && $D4253f9520627819['forced_country'] != 'ALL' && $efc0f8f3059e4104 != $D4253f9520627819['forced_country'])) {
			} else {
				generateError('FORCED_COUNTRY_INVALID');
			}

			if ($ac720430e021c8c0 || in_array('ALL', XUI::$rSettings['allow_countries']) || in_array($efc0f8f3059e4104, XUI::$rSettings['allow_countries'])) {
			} else {
				generateError('NOT_IN_ALLOWED_COUNTRY');
			}
		}

		if (empty($D4253f9520627819['allowed_ua']) || in_array($b3374866087774a1, $D4253f9520627819['allowed_ua'])) {
		} else {
			generateError('NOT_IN_ALLOWED_UAS');
		}

		if ($D4253f9520627819['isp_violate'] != 1) {
		} else {
			generateError('ISP_BLOCKED');
		}

		if ($D4253f9520627819['isp_is_server'] != 1 || $D4253f9520627819['is_restreamer']) {
		} else {
			generateError('ASN_BLOCKED');
		}
	}

	$F4a4cac9883825e6 = true;

	if (XUI::A93cAB970D8D7916('playlist', $D4253f9520627819, getmypid())) {
		$Fee0d5a474c96306 = new Database('TKbxeQrBXw2swDNwTh5yrj4jMV4RaLO0');
		XUI::$db = &$Fee0d5a474c96306;

		if (XUI::C8C03c8A7aFeB053($D4253f9520627819, $a94d5d59ff9b8d05, $B5179d3aa5ad70dd, $E6ba93c1fc86556a, $b9b8c6585c0f1e33, XUI::bb41388445081a3D($_SERVER['HTTP_X_IP']))) {
		} else {
			generateError('GENERATE_PLAYLIST_FAILED');
		}
	} else {
		generateError('DOWNLOAD_LIMIT_REACHED', false);
		http_response_code(429);

		exit();
	}
} else {
	XUI::b6F740fabC7265bF(null, null, $a71afc14d6cd090d);
	generateError('INVALID_CREDENTIALS');
}

function shutdown()
{
	global $Fee0d5a474c96306;
	global $Dab081f66facd7a3;
	global $F4a4cac9883825e6;
	global $D4253f9520627819;

	if (!$Dab081f66facd7a3) {
	} else {
		XUI::FC8474658Ec80360();
	}

	if (!is_object($Fee0d5a474c96306)) {
	} else {
		$Fee0d5a474c96306->close_mysql();
	}

	if (!$F4a4cac9883825e6) {
	} else {
		XUI::CD81a6df500DCfFD('playlist', $D4253f9520627819, getmypid());
	}
}
