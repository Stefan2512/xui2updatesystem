<?php
require_once __DIR__ . '/../includes/init.php';

if (!defined('XUI_VERSION')) {
    require_once('/home/xui/www/constants.php');
}

// Acces simplu
echo "XUI Admin Panel - Version: " . XUI_VERSION . " (Revision: " . XUI_REVISION . ")";
